/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree45 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 2.5) {
                if (fs[50] <= -987.5) {
                    if (fs[79] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[69] <= 9598.5) {
                                    if (fs[62] <= 0.5) {
                                        return 0.0893754121195;
                                    } else {
                                        return 0.165266492765;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.14626057525;
                                    } else {
                                        return -0.0242292807146;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[50] <= -1493.5) {
                                        return 0.14408664746;
                                    } else {
                                        return 0.0313069024185;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.114578654536;
                                    } else {
                                        return -0.000923515033121;
                                    }
                                }
                            }
                        } else {
                            if (fs[65] <= 1.5) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[69] <= 9993.5) {
                                        return -0.031589922011;
                                    } else {
                                        return -0.182699983749;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.104738530165;
                                    } else {
                                        return 0.07022252361;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[4] <= 2.5) {
                                        return -0.0614715289757;
                                    } else {
                                        return -0.0464741373037;
                                    }
                                } else {
                                    return -0.0237987345537;
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[69] <= 9923.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[50] <= -1868.0) {
                                        return 0.121470014413;
                                    } else {
                                        return -0.100555648583;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0933153726585;
                                    } else {
                                        return -0.142037931854;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1443.5) {
                                    if (fs[50] <= -1903.5) {
                                        return 0.238341915994;
                                    } else {
                                        return 0.0170861513728;
                                    }
                                } else {
                                    return 0.399849521737;
                                }
                            }
                        } else {
                            if (fs[50] <= -1478.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0934758282399;
                                    } else {
                                        return 0.111227390683;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.245991100128;
                                    } else {
                                        return -0.00717211263831;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.198428389414;
                                    } else {
                                        return 0.353455184006;
                                    }
                                } else {
                                    if (fs[69] <= 9807.0) {
                                        return -0.0252798480248;
                                    } else {
                                        return -0.301630366063;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[15] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.198247252227;
                                    } else {
                                        return 0.103215195227;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return 0.178290139434;
                                    } else {
                                        return 0.0710752500408;
                                    }
                                }
                            } else {
                                return -0.306587289255;
                            }
                        } else {
                            if (fs[46] <= -0.5) {
                                if (fs[46] <= -1.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.0349308080006;
                                    } else {
                                        return 0.181012591001;
                                    }
                                } else {
                                    if (fs[61] <= -996.5) {
                                        return 0.104460566731;
                                    } else {
                                        return -0.152202179243;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.117789017719;
                                    } else {
                                        return -0.00920793473125;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.066367384905;
                                    } else {
                                        return 0.293210476107;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[54] <= 0.5) {
                            if (fs[67] <= -3.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.0055330200621;
                                    } else {
                                        return 0.110714057982;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.192981122322;
                                    } else {
                                        return 0.0851583808521;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[69] <= 9712.5) {
                                        return -0.000132997656579;
                                    } else {
                                        return 0.0944222697242;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.045977160189;
                                    } else {
                                        return 0.0260968819418;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 1.5) {
                                if (fs[99] <= 0.5) {
                                    return 0.380733517713;
                                } else {
                                    return 0.225393541641;
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return 0.35758096585;
                                } else {
                                    return 0.415949359898;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 17.5) {
                    if (fs[2] <= 5.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.106083926746;
                                    } else {
                                        return -0.117905292567;
                                    }
                                } else {
                                    if (fs[82] <= 3.5) {
                                        return 0.0502831366358;
                                    } else {
                                        return 0.145499072686;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0116309854867;
                                    } else {
                                        return 0.11045635189;
                                    }
                                } else {
                                    if (fs[50] <= -978.0) {
                                        return 0.12980871071;
                                    } else {
                                        return -0.16733609306;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 150.0) {
                                if (fs[33] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0782624653784;
                                    } else {
                                        return 0.00828909672326;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.120464296767;
                                    } else {
                                        return 0.000577747278085;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    return 0.318018354113;
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.17156333365;
                                    } else {
                                        return 0.020363151354;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 75.0) {
                            if (fs[40] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.110108864996;
                                    } else {
                                        return 0.00647060044105;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.121153893369;
                                    } else {
                                        return 0.203662510432;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4229.0) {
                                    if (fs[50] <= -1538.0) {
                                        return 0.279577061465;
                                    } else {
                                        return -0.0315590671846;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.297832804858;
                                    } else {
                                        return -0.0637955596839;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 8.5) {
                                if (fs[6] <= 0.5) {
                                    return -0.131009219921;
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.137151874624;
                                    } else {
                                        return 0.0412176743848;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.187964155556;
                                    } else {
                                        return 0.293655642394;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.200918329388;
                                    } else {
                                        return 0.120116941499;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 11.5) {
                        if (fs[73] <= 25.0) {
                            if (fs[69] <= 9816.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[64] <= 0.5) {
                                        return -0.0762104232837;
                                    } else {
                                        return 0.131995102916;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0695209963271;
                                    } else {
                                        return 0.424235032783;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.25047900001;
                                    } else {
                                        return -0.201429985969;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.248650946591;
                                    } else {
                                        return -0.057528909555;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 35.5) {
                                if (fs[50] <= -1998.0) {
                                    if (fs[93] <= 0.5) {
                                        return 0.29304577784;
                                    } else {
                                        return 0.156819777309;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.050415598641;
                                    } else {
                                        return -0.330612516586;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1313.0) {
                                    if (fs[4] <= 41.5) {
                                        return -0.0923857215054;
                                    } else {
                                        return -0.348878356212;
                                    }
                                } else {
                                    return 0.118322677466;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 27.5) {
                            if (fs[95] <= 1.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[2] <= 12.5) {
                                        return 0.251596814968;
                                    } else {
                                        return 0.404652700376;
                                    }
                                } else {
                                    return 0.149263169132;
                                }
                            } else {
                                if (fs[4] <= 25.5) {
                                    if (fs[4] <= 21.5) {
                                        return 0.251600604693;
                                    } else {
                                        return 0.0243883298938;
                                    }
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return 0.230652763752;
                                    } else {
                                        return 0.289550835418;
                                    }
                                }
                            }
                        } else {
                            return 0.0968578407855;
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[50] <= -1478.5) {
                    if (fs[82] <= 6.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[28] <= 0.5) {
                                        return -0.00691166559057;
                                    } else {
                                        return 0.251659245488;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0436901983319;
                                    } else {
                                        return 0.159497135593;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0174097866733;
                                    } else {
                                        return 0.0204449175337;
                                    }
                                } else {
                                    if (fs[82] <= 3.5) {
                                        return 0.0342369274421;
                                    } else {
                                        return 0.317390059676;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[18] <= -0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.176383001651;
                                    } else {
                                        return -0.125923415825;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return 0.0537785692282;
                                    } else {
                                        return -0.017069435191;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.42771084561;
                                } else {
                                    return 0.0850740501439;
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[40] <= 0.5) {
                                        return -0.0870206883166;
                                    } else {
                                        return -0.0252331881387;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.102224054363;
                                    } else {
                                        return 0.229790107387;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[69] <= 9556.0) {
                                        return 0.0408247585554;
                                    } else {
                                        return 0.226116125599;
                                    }
                                } else {
                                    if (fs[69] <= 9996.5) {
                                        return -0.0443160451541;
                                    } else {
                                        return 0.267169045631;
                                    }
                                }
                            }
                        } else {
                            if (fs[43] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0122763334861;
                                    } else {
                                        return 0.404218403069;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.0673087513516;
                                    } else {
                                        return 0.206203199307;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9891.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0962683393109;
                                    } else {
                                        return 0.0975531377842;
                                    }
                                } else {
                                    return -0.326652057017;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[4] <= 23.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.124255165877;
                                    } else {
                                        return 0.0202290948795;
                                    }
                                } else {
                                    if (fs[50] <= -1128.0) {
                                        return 0.00577635636697;
                                    } else {
                                        return -0.0617728642277;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[4] <= 26.5) {
                                        return -0.0407396751308;
                                    } else {
                                        return -0.0187674498868;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return -0.0379328045252;
                                    } else {
                                        return 0.106358110776;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9985.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.0299971663901;
                                    } else {
                                        return -0.00232123304305;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0308258782529;
                                    } else {
                                        return 0.398176946435;
                                    }
                                }
                            } else {
                                if (fs[82] <= 3.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0818289252137;
                                    } else {
                                        return 0.033876485519;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.100435215011;
                                    } else {
                                        return 0.0192510824869;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[83] <= 0.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[2] <= 0.5) {
                                    return 0.0816615326567;
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.0222279755096;
                                    } else {
                                        return -0.0130095246218;
                                    }
                                }
                            } else {
                                if (fs[50] <= -976.0) {
                                    return 0.245424199099;
                                } else {
                                    return 0.0664491895011;
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                return -0.0411643252406;
                            } else {
                                if (fs[69] <= 9915.5) {
                                    if (fs[13] <= 0.5) {
                                        return -0.0294116490002;
                                    } else {
                                        return -0.0244106533056;
                                    }
                                } else {
                                    return -0.0770557941935;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 4.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[83] <= 0.5) {
                                        return 0.0131277654333;
                                    } else {
                                        return -0.00458992606591;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return 0.00222732309845;
                                    } else {
                                        return -0.015884041454;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0021850059471;
                                    } else {
                                        return -0.0107612202882;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0954514350009;
                                    } else {
                                        return -0.0116924250149;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1438.0) {
                                if (fs[43] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0448155855733;
                                    } else {
                                        return 0.213206949182;
                                    }
                                } else {
                                    return -0.117643826318;
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0018814490422;
                                    } else {
                                        return 0.0795472420521;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.161818967249;
                                    } else {
                                        return 0.323939770998;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 0.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[69] <= 9984.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0178203274437;
                                    } else {
                                        return 0.0528653366208;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0864522417309;
                                    } else {
                                        return -0.0570203384114;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9959.0) {
                                    if (fs[4] <= 11.5) {
                                        return -0.0127471430881;
                                    } else {
                                        return -0.00848064154879;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.045991237399;
                                    } else {
                                        return 0.00337839205554;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[50] <= -980.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.00873061358659;
                                    } else {
                                        return -0.00429436066649;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.0177490060852;
                                    } else {
                                        return -0.00969514654893;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0201827159095;
                                    } else {
                                        return 0.115957140571;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0140897312594;
                                    } else {
                                        return 0.0201957112393;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[54] <= 0.5) {
                        if (fs[69] <= 9997.5) {
                            if (fs[0] <= 20.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0048070668901;
                                    } else {
                                        return -0.00147934485443;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.00648857050942;
                                    } else {
                                        return 0.00218550274047;
                                    }
                                }
                            } else {
                                if (fs[15] <= 0.5) {
                                    if (fs[97] <= 1.5) {
                                        return -0.00637050466921;
                                    } else {
                                        return 0.00794661871582;
                                    }
                                } else {
                                    return 0.0529819053993;
                                }
                            }
                        } else {
                            if (fs[50] <= -1108.0) {
                                if (fs[12] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.0998184836574;
                                    } else {
                                        return 0.0134710853037;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0263544079417;
                                    } else {
                                        return 0.253805930168;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.0320236238226;
                                    } else {
                                        return -0.00336378254404;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.151234819547;
                                    } else {
                                        return -0.0114055882462;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 7.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0279790952154;
                                    } else {
                                        return 0.0564277283735;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.141171551553;
                                    } else {
                                        return 0.120583066606;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 7.0) {
                                        return -0.00889079940278;
                                    } else {
                                        return -0.0141528670095;
                                    }
                                } else {
                                    return -0.0408509055676;
                                }
                            }
                        } else {
                            return 0.639839976229;
                        }
                    }
                }
            }
        }
    }
}
