/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree23 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[57] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[67] <= -1.5) {
                            if (fs[50] <= -1138.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0534187694439;
                                    } else {
                                        return -0.0371352457322;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0811400730432;
                                    } else {
                                        return 0.196262315389;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1038.5) {
                                    if (fs[50] <= -1123.5) {
                                        return 0.316838035434;
                                    } else {
                                        return 0.343666075884;
                                    }
                                } else {
                                    if (fs[50] <= -988.0) {
                                        return 0.0989497109618;
                                    } else {
                                        return -0.0988454070972;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return 0.217508682278;
                            } else {
                                if (fs[0] <= 1.5) {
                                    return -0.111248190682;
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.0199876484109;
                                    } else {
                                        return -0.0571899340236;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[67] <= -1.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.29621093321;
                                    } else {
                                        return 0.330757500577;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.261185968736;
                                    } else {
                                        return 0.286792516529;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    return 0.230028268069;
                                } else {
                                    return -0.0250749047368;
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                return 0.275892440437;
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return 0.300045312431;
                                    } else {
                                        return 0.316876669351;
                                    }
                                } else {
                                    return 0.399592700714;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.251594238703;
                                    } else {
                                        return 0.299047686832;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.132767954947;
                                    } else {
                                        return -0.0945485747134;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.273174212819;
                                    } else {
                                        return 0.300110657052;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.29852762094;
                                    } else {
                                        return 0.294349866212;
                                    }
                                }
                            }
                        } else {
                            if (fs[39] <= 0.5) {
                                return 0.337951182026;
                            } else {
                                if (fs[69] <= 5000.0) {
                                    return 0.366016891355;
                                } else {
                                    return 0.378894383459;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.366717023657;
                                    } else {
                                        return 0.055192771686;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.236812073409;
                                    } else {
                                        return 0.0575116160257;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0948042411956;
                                    } else {
                                        return -0.0870309489329;
                                    }
                                } else {
                                    return -0.110467638585;
                                }
                            }
                        } else {
                            if (fs[34] <= 0.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[0] <= 25.5) {
                                        return 0.00900036536103;
                                    } else {
                                        return -0.0450289633133;
                                    }
                                } else {
                                    if (fs[50] <= -988.0) {
                                        return -0.0457864107015;
                                    } else {
                                        return -0.0353123207803;
                                    }
                                }
                            } else {
                                return 0.487193400956;
                            }
                        }
                    }
                }
            } else {
                if (fs[73] <= 100.0) {
                    if (fs[95] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0278083680734;
                                    } else {
                                        return 0.298319230968;
                                    }
                                } else {
                                    if (fs[50] <= -532.0) {
                                        return 0.326789646545;
                                    } else {
                                        return 0.206872040798;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.411395867289;
                                    } else {
                                        return 0.43748067328;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.327823674217;
                                    } else {
                                        return 0.321628953202;
                                    }
                                }
                            }
                        } else {
                            if (fs[67] <= -1.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 7.5) {
                                        return -0.0464944217731;
                                    } else {
                                        return 0.0115267265417;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.01515214575;
                                    } else {
                                        return -0.041254280274;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4905.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.229045796919;
                                    } else {
                                        return -0.0235957868414;
                                    }
                                } else {
                                    return -0.085440501964;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 4976.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[0] <= 3.5) {
                                    return 0.086479804138;
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0302133495007;
                                    } else {
                                        return -0.020824965665;
                                    }
                                }
                            } else {
                                if (fs[4] <= 26.5) {
                                    return 0.013460091255;
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0473542606047;
                                    } else {
                                        return -0.0399027093729;
                                    }
                                }
                            }
                        } else {
                            return -0.151688002318;
                        }
                    }
                } else {
                    if (fs[50] <= -1138.0) {
                        if (fs[50] <= -1568.0) {
                            if (fs[2] <= 3.5) {
                                return 0.0311264457047;
                            } else {
                                if (fs[4] <= 39.5) {
                                    return -0.0884455182953;
                                } else {
                                    return 0.0524085885551;
                                }
                            }
                        } else {
                            if (fs[50] <= -1538.0) {
                                if (fs[4] <= 33.5) {
                                    if (fs[0] <= 0.5) {
                                        return -0.199165165248;
                                    } else {
                                        return -0.0366011603372;
                                    }
                                } else {
                                    if (fs[4] <= 41.5) {
                                        return -0.0544061118335;
                                    } else {
                                        return -0.0427467693535;
                                    }
                                }
                            } else {
                                return -0.0159304810096;
                            }
                        }
                    } else {
                        if (fs[4] <= 19.5) {
                            return -0.0228602763142;
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.0327920434021;
                                    } else {
                                        return -0.0486174271335;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return -0.0237697407015;
                                    } else {
                                        return -0.0269296062717;
                                    }
                                }
                            } else {
                                return -0.0229550292067;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[97] <= 1.5) {
                if (fs[73] <= 25.0) {
                    if (fs[11] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.202168004219;
                                    } else {
                                        return 0.0726905383565;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.350023704617;
                                    } else {
                                        return 0.320030406603;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.000537439121079;
                                    } else {
                                        return -0.0507746616014;
                                    }
                                } else {
                                    if (fs[69] <= 4623.5) {
                                        return 0.0252109745599;
                                    } else {
                                        return 0.296154275782;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9995.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.0533539943981;
                                    } else {
                                        return -0.0143860927226;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.0230566762147;
                                    } else {
                                        return -0.0113836801294;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[0] <= 7.5) {
                                        return 0.155980100007;
                                    } else {
                                        return 0.00460716042086;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return 0.146295594472;
                                    } else {
                                        return -0.00685335287787;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[69] <= 9838.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.128498896453;
                                    } else {
                                        return -0.0546732891967;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return 0.17026921472;
                                    } else {
                                        return 0.272435956462;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.21752599775;
                                    } else {
                                        return 0.10202379085;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.339050707741;
                                    } else {
                                        return 0.41549468238;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9983.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0180716885338;
                                    } else {
                                        return -0.0135720648882;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.079996314311;
                                    } else {
                                        return -0.00780880538198;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.111680261521;
                                    } else {
                                        return 0.0514704666316;
                                    }
                                } else {
                                    if (fs[50] <= -1418.0) {
                                        return 0.0845560356431;
                                    } else {
                                        return 0.0033948162619;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[50] <= -1598.0) {
                            if (fs[49] <= 0.5) {
                                if (fs[4] <= 42.0) {
                                    if (fs[77] <= 0.5) {
                                        return 0.292573933892;
                                    } else {
                                        return -0.0560307716761;
                                    }
                                } else {
                                    return -0.398772413623;
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.163752893832;
                                    } else {
                                        return 0.331483389559;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.365038073394;
                                    } else {
                                        return 0.451517553629;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.197376602838;
                                    } else {
                                        return 0.0457228999451;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.305624721669;
                                    } else {
                                        return 0.218813839414;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.201432065239;
                                    } else {
                                        return 0.272102541728;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return 0.343736043403;
                                    } else {
                                        return 0.08954053944;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 6.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[50] <= -1458.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0765772112296;
                                    } else {
                                        return 0.238896712805;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.054057263214;
                                    } else {
                                        return -0.0682737381689;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.00459201966548;
                                    } else {
                                        return -0.022785961205;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.0189329221484;
                                    } else {
                                        return 0.130540032644;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1102.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.0112683802881;
                                    } else {
                                        return -0.0117508321654;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.180898428511;
                                    } else {
                                        return 0.0835958300362;
                                    }
                                }
                            } else {
                                if (fs[50] <= -57.0) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0299990200222;
                                    } else {
                                        return -0.0210065089818;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.00205395662228;
                                    } else {
                                        return -0.0194616937695;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[44] <= 0.5) {
                    if (fs[33] <= 0.5) {
                        if (fs[61] <= -996.5) {
                            if (fs[55] <= 0.5) {
                                if (fs[4] <= 1.5) {
                                    return 0.226452030817;
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.305679972443;
                                    } else {
                                        return 0.244708609034;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[59] <= -1.5) {
                                        return -0.0396263555588;
                                    } else {
                                        return 0.249235997928;
                                    }
                                } else {
                                    return 0.351645735512;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[50] <= -1014.0) {
                                    if (fs[73] <= 150.0) {
                                        return 0.337827632581;
                                    } else {
                                        return 0.252399178462;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0839101723354;
                                    } else {
                                        return 0.210677465981;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[59] <= -0.5) {
                                        return -0.0375313939743;
                                    } else {
                                        return 0.0531106758856;
                                    }
                                } else {
                                    if (fs[0] <= 41.0) {
                                        return 0.100393588212;
                                    } else {
                                        return 0.444055418403;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[46] <= -2.5) {
                                return -0.109960074141;
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0799121909639;
                                    } else {
                                        return 0.000285882383649;
                                    }
                                } else {
                                    return 0.331306537076;
                                }
                            }
                        } else {
                            if (fs[67] <= -4.0) {
                                return -0.119437349668;
                            } else {
                                if (fs[69] <= 9989.5) {
                                    if (fs[55] <= 0.5) {
                                        return -0.0455179120922;
                                    } else {
                                        return -0.0256900588969;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.229009769162;
                                    } else {
                                        return -0.0312552168851;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[59] <= -2.5) {
                            if (fs[61] <= -996.5) {
                                return 0.0776506235587;
                            } else {
                                if (fs[11] <= 0.5) {
                                    return -0.0414461951842;
                                } else {
                                    return 0.0368921909819;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return 0.0328478024781;
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0552038016187;
                                    } else {
                                        return -0.029103606791;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0189546205112;
                                    } else {
                                        return -0.0172777602307;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[59] <= -2.5) {
                            return 0.146248259505;
                        } else {
                            if (fs[4] <= 6.5) {
                                return 0.113530136835;
                            } else {
                                if (fs[0] <= 0.5) {
                                    return 0.186194486071;
                                } else {
                                    if (fs[50] <= -976.0) {
                                        return -0.0150163639529;
                                    } else {
                                        return -0.0218803992269;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
