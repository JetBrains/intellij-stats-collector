/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree79 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[95] <= 0.5) {
                if (fs[30] <= 0.5) {
                    if (fs[50] <= -988.0) {
                        if (fs[0] <= 0.5) {
                            if (fs[69] <= 9977.5) {
                                if (fs[6] <= 0.5) {
                                    return 0.0878504190328;
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0168306227799;
                                    } else {
                                        return 0.0854424833233;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.139038555001;
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0104387626316;
                                    } else {
                                        return 0.0368980130729;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0159189306479;
                                    } else {
                                        return 0.046994764212;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.00972552447142;
                                    } else {
                                        return 0.0736238364228;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0479880599533;
                                    } else {
                                        return 0.198900471238;
                                    }
                                } else {
                                    return 0.111961936592;
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return -0.0114777259671;
                                    } else {
                                        return -0.0453044210355;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.0462016930932;
                                    } else {
                                        return 0.0216101507255;
                                    }
                                }
                            } else {
                                return 0.126111793338;
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[69] <= 5000.0) {
                                    return -0.0979213304824;
                                } else {
                                    return 0.140936736517;
                                }
                            } else {
                                if (fs[0] <= 18.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.066268168147;
                                    } else {
                                        return 0.0942994757747;
                                    }
                                } else {
                                    return -0.0412642863262;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -471.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 3.5) {
                                return -0.032086440645;
                            } else {
                                return -0.297980520303;
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[40] <= 0.5) {
                                        return -0.0452899344818;
                                    } else {
                                        return -0.0741215040748;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0241580508651;
                                    } else {
                                        return -0.07728529965;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0212561616187;
                                    } else {
                                        return -0.0100814959742;
                                    }
                                } else {
                                    return -0.0471781881301;
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[0] <= 17.5) {
                                    return -0.0143486515397;
                                } else {
                                    return -0.00581379839809;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 13.5) {
                                        return -0.00879977714006;
                                    } else {
                                        return -0.00114050100544;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.00158024024406;
                                    } else {
                                        return 0.00448148425897;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 27.5) {
                                if (fs[57] <= 0.5) {
                                    return -0.0109105623147;
                                } else {
                                    return -0.0245011377108;
                                }
                            } else {
                                return -0.00993406600911;
                            }
                        }
                    }
                }
            } else {
                if (fs[11] <= 0.5) {
                    if (fs[69] <= 4976.5) {
                        if (fs[4] <= 24.0) {
                            return 0.0303855246266;
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[4] <= 60.0) {
                                    return -0.0896847180613;
                                } else {
                                    return 0.0126033382655;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[62] <= 0.5) {
                                        return -0.0142891099273;
                                    } else {
                                        return 0.00203732957477;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.0165934345543;
                                    } else {
                                        return -0.0307277140603;
                                    }
                                }
                            }
                        }
                    } else {
                        return -0.117971748807;
                    }
                } else {
                    if (fs[50] <= -1138.0) {
                        if (fs[4] <= 49.5) {
                            if (fs[0] <= 0.5) {
                                return 0.0514966758476;
                            } else {
                                if (fs[4] <= 48.5) {
                                    if (fs[69] <= 4847.0) {
                                        return -0.00113113233114;
                                    } else {
                                        return 0.0784210896117;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.034021027478;
                                    } else {
                                        return 0.0589163757293;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return -0.0653159049635;
                            } else {
                                if (fs[50] <= -1558.0) {
                                    return -0.0258857762679;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00618965138812;
                                    } else {
                                        return -0.01009800887;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            return -0.168030346991;
                        } else {
                            if (fs[50] <= -1068.0) {
                                if (fs[4] <= 18.5) {
                                    if (fs[4] <= 16.5) {
                                        return -0.0231927879321;
                                    } else {
                                        return -0.0144059127223;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0155916640776;
                                    } else {
                                        return -0.00354840648382;
                                    }
                                }
                            } else {
                                if (fs[0] <= 9.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.00786627535716;
                                    } else {
                                        return -7.5862259847e-06;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00105738914018;
                                    } else {
                                        return 0.000539440538157;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[61] <= -997.5) {
                if (fs[44] <= 0.5) {
                    if (fs[4] <= 21.5) {
                        if (fs[8] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[50] <= -1458.0) {
                                    if (fs[0] <= 5.5) {
                                        return 0.119566551412;
                                    } else {
                                        return -0.00625496735986;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0297326454128;
                                    } else {
                                        return 0.0351096043145;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0560011519059;
                                    } else {
                                        return -0.017821838235;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.167178813227;
                                    } else {
                                        return 0.084461041535;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                return -0.174996529138;
                            } else {
                                return -0.0398504089247;
                            }
                        }
                    } else {
                        return -0.150337568492;
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[4] <= 9.5) {
                                return -0.0621924375452;
                            } else {
                                if (fs[12] <= 0.5) {
                                    return -0.0143973400471;
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0263761684786;
                                    } else {
                                        return -0.0265090303241;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                return -0.0140275135564;
                            } else {
                                return -0.00158767059486;
                            }
                        }
                    } else {
                        if (fs[50] <= -986.5) {
                            if (fs[39] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00225192714241;
                                    } else {
                                        return -0.0199824394419;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.00437443214115;
                                    } else {
                                        return -0.00640868895197;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    return 0.086482223058;
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.0119221466933;
                                    } else {
                                        return -0.00369222759715;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.00614113781943;
                                    } else {
                                        return -0.00148149792623;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.000205792188308;
                                    } else {
                                        return -0.00287161055406;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    return -0.0367027691483;
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.0211163152463;
                                    } else {
                                        return -0.0102691601457;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[69] <= 9989.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.00767676128598;
                                    } else {
                                        return -0.0778010772963;
                                    }
                                } else {
                                    if (fs[82] <= 1.5) {
                                        return -0.0192189379416;
                                    } else {
                                        return 0.0186243124289;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[86] <= 0.5) {
                                        return 0.0273123547297;
                                    } else {
                                        return -0.107192465535;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.0855090478747;
                                    } else {
                                        return -0.102441283931;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00465932720929;
                                    } else {
                                        return -0.0299309453585;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return 0.137721424812;
                                    } else {
                                        return 0.327105219957;
                                    }
                                }
                            } else {
                                if (fs[4] <= 21.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.23467327756;
                                    } else {
                                        return 0.0321139736635;
                                    }
                                } else {
                                    if (fs[67] <= -4.5) {
                                        return 0.0453891432164;
                                    } else {
                                        return -0.0623524856078;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[79] <= 0.5) {
                                if (fs[82] <= 0.5) {
                                    if (fs[50] <= -37.0) {
                                        return 0.0219252812042;
                                    } else {
                                        return -0.012909651105;
                                    }
                                } else {
                                    if (fs[50] <= -1458.0) {
                                        return -0.0906464907527;
                                    } else {
                                        return 0.0414232399038;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[69] <= 9731.5) {
                                        return -0.0749044013127;
                                    } else {
                                        return 0.0269341590793;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return 0.075501612863;
                                    } else {
                                        return -0.230455795073;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 5.5) {
                                if (fs[4] <= 27.5) {
                                    if (fs[82] <= 1.5) {
                                        return 0.0260072785748;
                                    } else {
                                        return 0.11078718404;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.148729353654;
                                    } else {
                                        return -0.0128612889959;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00167081849458;
                                    } else {
                                        return 0.0386468247092;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.124975244916;
                                    } else {
                                        return 0.0912743878887;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 3.5) {
                        if (fs[54] <= 0.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.00282787375252;
                                    } else {
                                        return 0.00930907906475;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.00128412514677;
                                    } else {
                                        return 0.0503756321248;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.013926680943;
                                    } else {
                                        return -0.037957257954;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.0554487674146;
                                    } else {
                                        return 0.185674149736;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9998.5) {
                                if (fs[82] <= 3.0) {
                                    if (fs[50] <= -1128.0) {
                                        return 0.0836735524724;
                                    } else {
                                        return -0.0076077832853;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.152342870807;
                                    } else {
                                        return -0.0473400357384;
                                    }
                                }
                            } else {
                                return 0.194050711741;
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[50] <= -57.0) {
                                if (fs[61] <= -996.5) {
                                    if (fs[50] <= -1308.0) {
                                        return -0.0415616338973;
                                    } else {
                                        return 0.086400016501;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.00164109192825;
                                    } else {
                                        return 0.0463323963463;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0200821856946;
                                    } else {
                                        return -0.030444575991;
                                    }
                                } else {
                                    if (fs[69] <= 9978.5) {
                                        return 0.00664866654116;
                                    } else {
                                        return 0.0328456718038;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[59] <= -0.5) {
                                        return -0.0596470932597;
                                    } else {
                                        return 0.0099039014249;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return 0.0504152321121;
                                    } else {
                                        return 0.268201235295;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.00543408716188;
                                    } else {
                                        return 0.00400973389282;
                                    }
                                } else {
                                    if (fs[69] <= 9995.5) {
                                        return 0.0132265854534;
                                    } else {
                                        return 0.0747031582318;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
