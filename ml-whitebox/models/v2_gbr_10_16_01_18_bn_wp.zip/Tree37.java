/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree37 {
    public double calcTree(double... fs) {
        if (fs[39] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[99] <= 0.5) {
                        if (fs[50] <= -987.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.122013317422;
                                    } else {
                                        return 0.050695535261;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.328049628721;
                                    } else {
                                        return 0.290435873743;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1803.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.175190438584;
                                    } else {
                                        return 0.177600409182;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.13095068669;
                                    } else {
                                        return -0.00546945352989;
                                    }
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[61] <= -497.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.25052381377;
                                    } else {
                                        return 0.0905400372521;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0168459948578;
                                    } else {
                                        return 0.0750181250973;
                                    }
                                }
                            } else {
                                if (fs[59] <= -0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.392517969817;
                                    } else {
                                        return 0.214515519431;
                                    }
                                } else {
                                    if (fs[67] <= -4.5) {
                                        return 0.150369467839;
                                    } else {
                                        return 0.0293603675809;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9987.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[82] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0876732257879;
                                    } else {
                                        return -0.247029933625;
                                    }
                                } else {
                                    if (fs[50] <= -970.5) {
                                        return 0.070293849081;
                                    } else {
                                        return -0.080297741373;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.112888065132;
                                    } else {
                                        return 0.0929265058344;
                                    }
                                } else {
                                    if (fs[50] <= -1478.5) {
                                        return 0.0604672914843;
                                    } else {
                                        return 0.262120842896;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[86] <= 0.5) {
                                    return 0.351470989592;
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.066003936757;
                                    } else {
                                        return 0.190501259707;
                                    }
                                }
                            } else {
                                if (fs[50] <= -485.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0654933519019;
                                    } else {
                                        return 0.141335305702;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.203597561374;
                                    } else {
                                        return 0.0378599136435;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= -0.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.131768043582;
                                    } else {
                                        return -0.200330970612;
                                    }
                                } else {
                                    return -0.347222127981;
                                }
                            } else {
                                return 0.177061338929;
                            }
                        } else {
                            if (fs[50] <= -1248.0) {
                                return -0.163678658558;
                            } else {
                                return 0.247019862133;
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.138416008158;
                                    } else {
                                        return 0.0959531612544;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.056676590086;
                                    } else {
                                        return 0.154674810347;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.231403995855;
                                    } else {
                                        return 0.176169078135;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.136072878529;
                                    } else {
                                        return -0.122234849025;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.075674439762;
                                    } else {
                                        return -0.0618713798935;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return 0.111067271389;
                                    } else {
                                        return -0.0904384717508;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0224330491052;
                                    } else {
                                        return -0.17618601399;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.245770335837;
                                    } else {
                                        return 0.124342090145;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[69] <= 9868.5) {
                    if (fs[15] <= 0.5) {
                        if (fs[0] <= 3.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.00857232527499;
                                    } else {
                                        return -0.00943846478928;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.251198426183;
                                    } else {
                                        return 0.288562268447;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[50] <= -1488.5) {
                                        return 0.0549621761886;
                                    } else {
                                        return -0.00749211050043;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.0186537120517;
                                    } else {
                                        return -0.00839802375214;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 9.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00796750280844;
                                    } else {
                                        return 0.00800621024768;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.00451845901754;
                                    } else {
                                        return 0.0502575667795;
                                    }
                                }
                            } else {
                                if (fs[0] <= 20.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.00519285104891;
                                    } else {
                                        return -0.00860667252819;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.00920733506326;
                                    } else {
                                        return -0.0107316793576;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            return -0.0958335020077;
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[0] <= 25.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0318579862734;
                                    } else {
                                        return 0.0865651861412;
                                    }
                                } else {
                                    if (fs[0] <= 28.5) {
                                        return -0.0397026478079;
                                    } else {
                                        return -0.0691802771386;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return 0.0482659602362;
                                } else {
                                    return -0.0132454932164;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0227738366935;
                                    } else {
                                        return 0.147809107652;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.162701687249;
                                    } else {
                                        return 0.390488599486;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return -5.51985022316e-05;
                                    } else {
                                        return 0.105297325906;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0907108392582;
                                    } else {
                                        return 0.28751894637;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[86] <= 0.5) {
                                        return -0.106019448187;
                                    } else {
                                        return 0.202223468361;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0535129497853;
                                    } else {
                                        return 0.162719585487;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[52] <= 50.5) {
                                        return 0.0248662403178;
                                    } else {
                                        return 0.430345273268;
                                    }
                                } else {
                                    if (fs[69] <= 9893.0) {
                                        return -0.160691657405;
                                    } else {
                                        return 0.235675325388;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9998.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.0241401454595;
                                    } else {
                                        return -0.0184271263805;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0246897720751;
                                    } else {
                                        return -0.0103322445093;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[50] <= -1128.0) {
                                        return 0.0300284352059;
                                    } else {
                                        return 0.00722551780836;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.00891507835159;
                                    } else {
                                        return -0.00927289146512;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1072.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 39.5) {
                                        return 0.0517256463241;
                                    } else {
                                        return -0.0678564191045;
                                    }
                                } else {
                                    if (fs[0] <= 21.5) {
                                        return 0.133971094334;
                                    } else {
                                        return -0.0678309997001;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.00926138444107;
                                    } else {
                                        return -0.0174566332357;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.132585737545;
                                    } else {
                                        return 0.0285908971149;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[95] <= 0.5) {
                    if (fs[75] <= 0.5) {
                        if (fs[69] <= 5000.0) {
                            if (fs[11] <= 0.5) {
                                return 0.192146173078;
                            } else {
                                return 0.151079051659;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.256521771561;
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.203895944229;
                                } else {
                                    return 0.256092627957;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 1.5) {
                            return 0.408174614432;
                        } else {
                            if (fs[82] <= 1.0) {
                                if (fs[4] <= 3.5) {
                                    return 0.141512789882;
                                } else {
                                    if (fs[69] <= 9943.5) {
                                        return -0.158025575978;
                                    } else {
                                        return 0.0195742665024;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.180830669289;
                                    } else {
                                        return 0.0893640948722;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.479701179617;
                                    } else {
                                        return 0.0319813152903;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[8] <= 0.5) {
                        if (fs[59] <= -3.5) {
                            return -0.225082370411;
                        } else {
                            if (fs[4] <= 22.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.10929847505;
                                    } else {
                                        return 0.146549868565;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.0487451229965;
                                    } else {
                                        return -0.0986234423639;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    return 0.209803375946;
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.0291196909622;
                                    } else {
                                        return 0.0862132314248;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 250.0) {
                            if (fs[50] <= -1138.0) {
                                return -0.469885696169;
                            } else {
                                return -0.280507594878;
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                return -0.234562347043;
                            } else {
                                return 0.0301301650164;
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1068.0) {
                    if (fs[97] <= 1.5) {
                        if (fs[69] <= 9997.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 77.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.023649986907;
                                    } else {
                                        return -0.016168351672;
                                    }
                                } else {
                                    return 0.349814817131;
                                }
                            } else {
                                if (fs[59] <= -1.5) {
                                    return 0.17248955505;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.012942273713;
                                    } else {
                                        return 0.0561398710605;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1128.0) {
                                if (fs[4] <= 7.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.112274279419;
                                    } else {
                                        return 0.288362817113;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0233927324683;
                                    } else {
                                        return 0.0672895406815;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    return -0.0386148519089;
                                } else {
                                    if (fs[4] <= 19.0) {
                                        return 0.611344368121;
                                    } else {
                                        return 0.166901872721;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 21.5) {
                            if (fs[50] <= -1088.5) {
                                if (fs[61] <= -997.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.30890058731;
                                    } else {
                                        return 0.0745376637906;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return -0.0577463296103;
                                    } else {
                                        return 0.0447950057926;
                                    }
                                }
                            } else {
                                return 0.573867532862;
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                return 0.292768882377;
                            } else {
                                if (fs[0] <= 66.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.60924027939;
                                    } else {
                                        return 0.480260125972;
                                    }
                                } else {
                                    return 0.299246764428;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[6] <= 0.5) {
                        if (fs[73] <= 250.0) {
                            if (fs[8] <= 0.5) {
                                return -0.0170851578821;
                            } else {
                                if (fs[44] <= 0.5) {
                                    return -0.0133419075385;
                                } else {
                                    return -0.0106793957733;
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                return 0.464481750711;
                            } else {
                                return 0.00975294397402;
                            }
                        }
                    } else {
                        if (fs[4] <= 1.5) {
                            if (fs[49] <= 0.5) {
                                return 0.224247472808;
                            } else {
                                return 0.0683740652932;
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.00901279678519;
                                    } else {
                                        return 0.052805289395;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0209933656892;
                                    } else {
                                        return -0.0459423796854;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.130833356004;
                                    } else {
                                        return 0.0138616500273;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0111163804573;
                                    } else {
                                        return 0.00927930883967;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
