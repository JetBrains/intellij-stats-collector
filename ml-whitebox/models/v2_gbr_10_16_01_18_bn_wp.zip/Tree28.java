/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree28 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[50] <= -1093.5) {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 19.5) {
                        if (fs[50] <= -1138.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[69] <= 9983.0) {
                                        return 0.119985249502;
                                    } else {
                                        return 0.364394417562;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.217901725566;
                                    } else {
                                        return -0.220989820737;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.207563565069;
                                    } else {
                                        return 0.23490788428;
                                    }
                                } else {
                                    return 0.140632806157;
                                }
                            }
                        } else {
                            if (fs[69] <= 9997.5) {
                                if (fs[50] <= -1128.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.231421570452;
                                    } else {
                                        return 0.115617613516;
                                    }
                                } else {
                                    if (fs[50] <= -1118.5) {
                                        return 0.247172398468;
                                    } else {
                                        return 0.257901801166;
                                    }
                                }
                            } else {
                                return 0.262919994528;
                            }
                        }
                    } else {
                        return -0.0595325775143;
                    }
                } else {
                    if (fs[4] <= 2.5) {
                        if (fs[40] <= 0.5) {
                            return 0.350956539669;
                        } else {
                            return -0.0469460852926;
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0322250166468;
                                    } else {
                                        return 0.288234007167;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return -0.0155507634021;
                                    } else {
                                        return 0.0452191973471;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.228902956403;
                                    } else {
                                        return 0.496546719908;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0183205954114;
                                    } else {
                                        return 0.173646490395;
                                    }
                                }
                            }
                        } else {
                            if (fs[67] <= -1.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0477187299849;
                                    } else {
                                        return -0.0628275040298;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0306875887342;
                                    } else {
                                        return 0.0162008379672;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4847.0) {
                                    if (fs[95] <= 1.0) {
                                        return 0.163238205342;
                                    } else {
                                        return -0.0164369820171;
                                    }
                                } else {
                                    return 0.102769865827;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 3.5) {
                        if (fs[2] <= 1.5) {
                            return -0.21339431977;
                        } else {
                            return 0.123766558584;
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[50] <= -978.0) {
                                if (fs[68] <= 0.5) {
                                    return 0.271823811507;
                                } else {
                                    return 0.304868830692;
                                }
                            } else {
                                if (fs[67] <= -1.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0461848075527;
                                    } else {
                                        return 0.301621016721;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.109901813939;
                                    } else {
                                        return 0.272936760889;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.320332031845;
                                    } else {
                                        return 0.265844462472;
                                    }
                                } else {
                                    return 0.201649087274;
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return 0.236888520373;
                                } else {
                                    return 0.276459289069;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[49] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[68] <= 0.5) {
                                    return -0.0923742531608;
                                } else {
                                    return 0.0352196261104;
                                }
                            } else {
                                if (fs[95] <= 1.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.152139303901;
                                    } else {
                                        return 0.439248301521;
                                    }
                                } else {
                                    return -0.0324543369474;
                                }
                            }
                        } else {
                            if (fs[67] <= -1.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[30] <= 0.5) {
                                        return -0.0443265181305;
                                    } else {
                                        return -0.0263951366246;
                                    }
                                } else {
                                    return 0.0629417648598;
                                }
                            } else {
                                return 0.0766264233559;
                            }
                        }
                    } else {
                        if (fs[73] <= 100.0) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    return 0.0446608485006;
                                } else {
                                    return -0.0317337810638;
                                }
                            } else {
                                if (fs[67] <= -1.5) {
                                    if (fs[50] <= -933.5) {
                                        return -0.0639585691651;
                                    } else {
                                        return -0.0451702275523;
                                    }
                                } else {
                                    if (fs[69] <= 4984.0) {
                                        return -0.016896610672;
                                    } else {
                                        return -0.0918844440832;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 25.5) {
                                        return -0.0371206111061;
                                    } else {
                                        return -0.0352359386558;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0226890754857;
                                    } else {
                                        return -0.0208868938646;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 6.5) {
                                        return -0.0204029649032;
                                    } else {
                                        return -0.0166298176671;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0210078212594;
                                    } else {
                                        return -0.016315448125;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[97] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 26.5) {
                                        return 0.273045518068;
                                    } else {
                                        return 0.478757995746;
                                    }
                                } else {
                                    if (fs[92] <= 0.5) {
                                        return -0.180339657037;
                                    } else {
                                        return 0.196778435335;
                                    }
                                }
                            } else {
                                if (fs[59] <= -0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0944749544897;
                                    } else {
                                        return 0.234611219161;
                                    }
                                } else {
                                    if (fs[69] <= 9986.5) {
                                        return 0.056360698199;
                                    } else {
                                        return 0.146487065557;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9971.5) {
                                if (fs[50] <= -1558.5) {
                                    if (fs[67] <= -1.5) {
                                        return 0.218527833268;
                                    } else {
                                        return -0.214735481674;
                                    }
                                } else {
                                    if (fs[50] <= -1483.5) {
                                        return -0.0756042064214;
                                    } else {
                                        return 0.0142852227817;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1098.5) {
                                    if (fs[50] <= -1478.5) {
                                        return 0.0915168655052;
                                    } else {
                                        return 0.245160814539;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0171983036515;
                                    } else {
                                        return 0.0786150553684;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[50] <= -988.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.164033146975;
                                    } else {
                                        return 0.226543807376;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.112992580933;
                                    } else {
                                        return -0.219192122524;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    return -0.164749415554;
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0938182247268;
                                    } else {
                                        return -0.0809375879898;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[69] <= 9996.5) {
                                    if (fs[50] <= -1304.0) {
                                        return 0.339493619089;
                                    } else {
                                        return -0.0949339325742;
                                    }
                                } else {
                                    if (fs[50] <= -1303.0) {
                                        return 0.246417608312;
                                    } else {
                                        return -0.00489236003793;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.204825876765;
                                    } else {
                                        return 0.314483641801;
                                    }
                                } else {
                                    return -0.0478869751349;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= -0.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.130696262847;
                                    } else {
                                        return -0.0907819325792;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.189736915206;
                                    } else {
                                        return -0.364140876555;
                                    }
                                }
                            } else {
                                return 0.305355863467;
                            }
                        } else {
                            return 0.352713918225;
                        }
                    } else {
                        if (fs[97] <= 0.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[82] <= 2.5) {
                                        return 0.18486405924;
                                    } else {
                                        return 0.274337698183;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.180659492106;
                                    } else {
                                        return 0.115610062538;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.152739128339;
                                    } else {
                                        return 0.0720441602768;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.203452533096;
                                    } else {
                                        return 0.28809782866;
                                    }
                                }
                            }
                        } else {
                            if (fs[6] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.243796012383;
                                    } else {
                                        return 0.236822291693;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return -0.113898825739;
                                    } else {
                                        return 0.242637689289;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[4] <= 28.5) {
                                        return 0.214774277803;
                                    } else {
                                        return 0.00520699102908;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.304830276276;
                                    } else {
                                        return -0.0386055282845;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[69] <= 9981.5) {
                    if (fs[79] <= 0.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[50] <= -1368.0) {
                                    if (fs[52] <= 50.5) {
                                        return -0.00520022769193;
                                    } else {
                                        return 0.156060412136;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0123289739928;
                                    } else {
                                        return -0.0174649869652;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.00657822546356;
                                    } else {
                                        return -0.0103532504979;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0237431184775;
                                    } else {
                                        return 0.271439764563;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0401637683213;
                                    } else {
                                        return 0.0140680686569;
                                    }
                                } else {
                                    if (fs[0] <= 103.5) {
                                        return -0.00835823137861;
                                    } else {
                                        return 0.193955001584;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[61] <= -997.5) {
                                        return -0.0233933137549;
                                    } else {
                                        return -0.0155301507191;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return -0.0144258096488;
                                    } else {
                                        return -0.00776450063056;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 7.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0225462586725;
                                    } else {
                                        return 0.221995872487;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.0624656053196;
                                    } else {
                                        return -0.0153048716947;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0193352568583;
                                    } else {
                                        return -0.0142679374235;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.00822352000985;
                                    } else {
                                        return -0.0153012899302;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.00464170611768;
                                    } else {
                                        return -0.0334913880956;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.105649202799;
                                    } else {
                                        return -0.0304749875463;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1468.0) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0148302618224;
                                    } else {
                                        return 0.360675449394;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.061858054404;
                                    } else {
                                        return 0.103104229106;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[52] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0442887784036;
                                    } else {
                                        return 0.166184093345;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0157758902366;
                                    } else {
                                        return 0.27241220916;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.27829478732;
                                    } else {
                                        return 0.0986264877347;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return 0.0461699713393;
                                    } else {
                                        return 0.326360616055;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1418.0) {
                                if (fs[82] <= 6.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0357714711877;
                                    } else {
                                        return 0.14461943081;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.252479666045;
                                    } else {
                                        return -0.00317166956797;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0246669526715;
                                    } else {
                                        return 0.168270938997;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.00653125609501;
                                    } else {
                                        return -0.0147279319434;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[52] <= 995.0) {
                                return 0.417167315903;
                            } else {
                                return 0.114044528889;
                            }
                        } else {
                            return 0.534667554309;
                        }
                    }
                }
            }
        }
    }
}
