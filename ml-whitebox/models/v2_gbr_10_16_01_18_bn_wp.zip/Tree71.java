/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree71 {
    public double calcTree(double... fs) {
        if (fs[11] <= 0.5) {
            if (fs[95] <= 0.5) {
                if (fs[69] <= 9982.5) {
                    if (fs[71] <= 0.5) {
                        if (fs[75] <= 0.5) {
                            if (fs[0] <= 25.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.0306176983667;
                                    } else {
                                        return -0.0174294937657;
                                    }
                                } else {
                                    return 0.160873272362;
                                }
                            } else {
                                if (fs[0] <= 40.5) {
                                    if (fs[0] <= 28.5) {
                                        return -0.0502344271999;
                                    } else {
                                        return -0.085839264282;
                                    }
                                } else {
                                    return -0.0220443559489;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0647592115988;
                                    } else {
                                        return -0.0211327885332;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.0271716506539;
                                    } else {
                                        return -0.0707414735105;
                                    }
                                }
                            } else {
                                if (fs[50] <= 3.0) {
                                    if (fs[4] <= 14.5) {
                                        return 0.00160344066585;
                                    } else {
                                        return -0.00304715787784;
                                    }
                                } else {
                                    if (fs[76] <= 0.5) {
                                        return -0.00560184490975;
                                    } else {
                                        return -0.0170842277946;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 2.5) {
                                        return -0.0304775971548;
                                    } else {
                                        return -0.111456377588;
                                    }
                                } else {
                                    if (fs[69] <= 9892.5) {
                                        return 0.117778726777;
                                    } else {
                                        return 0.00342741452938;
                                    }
                                }
                            } else {
                                return 0.045811594568;
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0498777589244;
                                    } else {
                                        return 0.0385003481679;
                                    }
                                } else {
                                    return -0.0260709540666;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0199798346891;
                                    } else {
                                        return -0.00278575556855;
                                    }
                                } else {
                                    if (fs[69] <= 9966.0) {
                                        return 0.00292959542276;
                                    } else {
                                        return 0.115880259728;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[99] <= 0.5) {
                        if (fs[25] <= 0.5) {
                            if (fs[92] <= 0.5) {
                                if (fs[4] <= 21.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.00492326138693;
                                    } else {
                                        return 0.229920706033;
                                    }
                                } else {
                                    if (fs[50] <= -1207.0) {
                                        return -0.295100527063;
                                    } else {
                                        return -0.0725907933644;
                                    }
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0813445748585;
                                    } else {
                                        return 0.0188429884878;
                                    }
                                } else {
                                    if (fs[0] <= 39.5) {
                                        return -0.00583349853235;
                                    } else {
                                        return -0.0465445459928;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 12.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.138192052004;
                                    } else {
                                        return -0.116212926246;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.112175263317;
                                    } else {
                                        return 0.11013704438;
                                    }
                                }
                            } else {
                                if (fs[50] <= -982.0) {
                                    if (fs[4] <= 14.5) {
                                        return 0.191375678919;
                                    } else {
                                        return 0.0588691836872;
                                    }
                                } else {
                                    if (fs[0] <= 4.0) {
                                        return 0.0428210018314;
                                    } else {
                                        return -0.0220823187156;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.0477662043847;
                                    } else {
                                        return -0.142263917677;
                                    }
                                } else {
                                    if (fs[82] <= 2.5) {
                                        return 0.179407438169;
                                    } else {
                                        return -0.180814684944;
                                    }
                                }
                            } else {
                                return -0.24346804027;
                            }
                        } else {
                            if (fs[65] <= 1.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0159423847046;
                                    } else {
                                        return 0.0719099091814;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0290310534163;
                                    } else {
                                        return 0.022211347424;
                                    }
                                }
                            } else {
                                return 0.394609018085;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[50] <= -1363.0) {
                        if (fs[4] <= 17.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[42] <= 0.5) {
                                        return 0.112458759463;
                                    } else {
                                        return -0.0433467060282;
                                    }
                                } else {
                                    if (fs[67] <= -3.5) {
                                        return -0.103828596131;
                                    } else {
                                        return 0.0577121222036;
                                    }
                                }
                            } else {
                                if (fs[62] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0252402742315;
                                    } else {
                                        return 0.263569258785;
                                    }
                                } else {
                                    if (fs[69] <= 9983.5) {
                                        return -0.127137748523;
                                    } else {
                                        return -0.41592949643;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 24.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0498839304194;
                                    } else {
                                        return -0.0988684197733;
                                    }
                                } else {
                                    if (fs[69] <= 9996.5) {
                                        return 0.109832433067;
                                    } else {
                                        return -0.0833411014815;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 43.5) {
                                        return 0.126602993887;
                                    } else {
                                        return -0.124101351113;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.0494599581549;
                                    } else {
                                        return 0.134080726928;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[61] <= -997.5) {
                            if (fs[73] <= 150.0) {
                                if (fs[95] <= 1.5) {
                                    if (fs[69] <= 4999.0) {
                                        return 0.196843767906;
                                    } else {
                                        return 0.0584477135851;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.106291106556;
                                    } else {
                                        return -0.0439563241981;
                                    }
                                }
                            } else {
                                if (fs[55] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0459676537358;
                                    } else {
                                        return -0.0400219111482;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0509370830204;
                                    } else {
                                        return -0.00185767876911;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9998.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.0997808440191;
                                    } else {
                                        return -0.00466628602465;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0223795941996;
                                    } else {
                                        return 0.0638172876553;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[18] <= 0.5) {
                                        return 0.044940518212;
                                    } else {
                                        return -0.175253683077;
                                    }
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return 0.0232336698786;
                                    } else {
                                        return -0.237017352715;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1092.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[0] <= 10.5) {
                                if (fs[61] <= -499.0) {
                                    return 0.289796338144;
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0172121020409;
                                    } else {
                                        return 0.092252553817;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[0] <= 13.5) {
                                        return 0.282250886744;
                                    } else {
                                        return -0.037082681437;
                                    }
                                } else {
                                    return 0.541377024673;
                                }
                            }
                        } else {
                            if (fs[46] <= -2.5) {
                                return 0.246970987609;
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.184444186469;
                                    } else {
                                        return 0.004878733426;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return 0.0492795216438;
                                    } else {
                                        return 0.172323726069;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -37.0) {
                            if (fs[50] <= -976.5) {
                                if (fs[4] <= 5.5) {
                                    return -0.0711372099862;
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.012638765233;
                                    } else {
                                        return -0.00332797051594;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.0290831742406;
                                    } else {
                                        return 0.0101772349526;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return -0.0078770531788;
                                    } else {
                                        return -0.0711272865351;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 250.0) {
                                if (fs[0] <= 6.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0181926654136;
                                    } else {
                                        return -0.00365929825864;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.119449672765;
                                    } else {
                                        return -0.00501341919365;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[62] <= 0.5) {
                                        return -0.00450997276093;
                                    } else {
                                        return -0.014209632492;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.080798914055;
                                    } else {
                                        return -0.0169212588547;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[69] <= 9999.5) {
                if (fs[75] <= 0.5) {
                    if (fs[50] <= -1073.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.040215768275;
                                    } else {
                                        return -0.0129155521262;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0479778871317;
                                    } else {
                                        return -0.093578826088;
                                    }
                                }
                            } else {
                                if (fs[73] <= 100.0) {
                                    if (fs[2] <= 2.5) {
                                        return 0.017385372565;
                                    } else {
                                        return 0.0313884320426;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.000250135716858;
                                    } else {
                                        return -0.0083931867573;
                                    }
                                }
                            }
                        } else {
                            if (fs[56] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.023079678631;
                                    } else {
                                        return -0.220149532481;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.00587304916246;
                                    } else {
                                        return 0.534046036613;
                                    }
                                }
                            } else {
                                if (fs[73] <= 100.0) {
                                    if (fs[4] <= 4.0) {
                                        return 0.060797182148;
                                    } else {
                                        return 0.508266505428;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0264020757392;
                                    } else {
                                        return -0.006498266337;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[69] <= 9871.0) {
                                if (fs[67] <= -1.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0556474279092;
                                    } else {
                                        return -0.019396723638;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0546821015687;
                                    } else {
                                        return -0.00243422468362;
                                    }
                                }
                            } else {
                                return -0.156883110846;
                            }
                        } else {
                            return 0.118022340684;
                        }
                    }
                } else {
                    if (fs[2] <= 3.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[27] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.00491288982529;
                                    } else {
                                        return -0.00228213654551;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.023545328582;
                                    } else {
                                        return -0.00032275939947;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    return 0.359912634463;
                                } else {
                                    return 0.147844898877;
                                }
                            }
                        } else {
                            if (fs[50] <= -1113.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.154506366846;
                                    } else {
                                        return 0.110455180838;
                                    }
                                } else {
                                    return 0.0486507503709;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[69] <= 4969.5) {
                                        return 0.0682353125972;
                                    } else {
                                        return 0.488619571443;
                                    }
                                } else {
                                    if (fs[69] <= 9991.5) {
                                        return 0.00461415339124;
                                    } else {
                                        return 0.163305480723;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9868.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[82] <= 3.5) {
                                        return -0.00183236722442;
                                    } else {
                                        return 0.00946574589135;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0384238804059;
                                    } else {
                                        return 0.00352933292133;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0195644788126;
                                    } else {
                                        return 0.0832627858201;
                                    }
                                } else {
                                    if (fs[46] <= -1.5) {
                                        return 0.0658594341416;
                                    } else {
                                        return -0.00646777118711;
                                    }
                                }
                            }
                        } else {
                            if (fs[87] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.0376580504899;
                                    } else {
                                        return 0.0849497296235;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.0521068070205;
                                    } else {
                                        return -0.0272142980394;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -1478.0) {
                                        return -0.292187544375;
                                    } else {
                                        return -0.211864103362;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0757921771174;
                                    } else {
                                        return -0.0509190495874;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[6] <= 0.5) {
                    if (fs[4] <= 13.5) {
                        return -0.337077285364;
                    } else {
                        return -0.100266599004;
                    }
                } else {
                    if (fs[68] <= 0.5) {
                        if (fs[4] <= 12.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[50] <= -1067.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.17409675742;
                                    } else {
                                        return 0.0171092556565;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0291346743607;
                                    } else {
                                        return -0.140519048024;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0305054033086;
                                    } else {
                                        return 0.123072954083;
                                    }
                                } else {
                                    return -0.132590094434;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.163545736792;
                                    } else {
                                        return 0.218428162369;
                                    }
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return 0.0813611901346;
                                    } else {
                                        return -0.355914283449;
                                    }
                                }
                            } else {
                                if (fs[4] <= 22.5) {
                                    if (fs[50] <= -1488.0) {
                                        return -0.146930146195;
                                    } else {
                                        return 0.0152536072006;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.221451358489;
                                    } else {
                                        return 0.183881103705;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1052.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0393743071895;
                                    } else {
                                        return -0.134974499638;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.0484494321349;
                                    } else {
                                        return 0.254036037325;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[50] <= -1443.5) {
                                        return 0.133403425566;
                                    } else {
                                        return 0.370634925545;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.0440933258794;
                                    } else {
                                        return -0.220408630016;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 8.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0118397729311;
                                    } else {
                                        return 0.015751091441;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.234148183166;
                                    } else {
                                        return 0.155365425122;
                                    }
                                }
                            } else {
                                return -0.294985801926;
                            }
                        }
                    }
                }
            }
        }
    }
}
