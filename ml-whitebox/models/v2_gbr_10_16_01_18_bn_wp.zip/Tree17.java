/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree17 {
    public double calcTree(double... fs) {
        if (fs[39] <= 0.5) {
            if (fs[75] <= 0.5) {
                if (fs[4] <= 7.5) {
                    if (fs[57] <= 0.5) {
                        if (fs[50] <= -988.0) {
                            if (fs[4] <= 5.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.404482545894;
                                    } else {
                                        return 0.334203918549;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0691422804258;
                                    } else {
                                        return -0.00962080368622;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.373172728245;
                                    } else {
                                        return 0.647354976154;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.182910852555;
                                    } else {
                                        return 0.490758556659;
                                    }
                                }
                            }
                        } else {
                            if (fs[67] <= -1.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -978.0) {
                                        return -0.0868859538683;
                                    } else {
                                        return -0.11998045717;
                                    }
                                } else {
                                    return -0.128926720154;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.213084761534;
                                    } else {
                                        return 0.446436890871;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0181302726457;
                                    } else {
                                        return -0.092753765051;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[50] <= -1138.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.381709904355;
                                    } else {
                                        return 0.420171132311;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.344971656983;
                                    } else {
                                        return 0.116652499767;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.40408051666;
                                    } else {
                                        return 0.38876547454;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.02455679953;
                                    } else {
                                        return 0.211766571236;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                return 0.342659498916;
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.00561314550548;
                                    } else {
                                        return 0.457981395158;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.244816641266;
                                    } else {
                                        return 0.0338441149321;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 6.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[73] <= 100.0) {
                                if (fs[34] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.432532757935;
                                    } else {
                                        return -0.16087058435;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0406822300492;
                                    } else {
                                        return 0.390190452072;
                                    }
                                }
                            } else {
                                if (fs[4] <= 21.5) {
                                    return 0.223959757737;
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return -0.092524775946;
                                    } else {
                                        return 0.048641554489;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[67] <= -1.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.048936091229;
                                    } else {
                                        return -0.0675821025066;
                                    }
                                } else {
                                    return 0.0595656117355;
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[69] <= 4847.0) {
                                        return -0.0235474161852;
                                    } else {
                                        return 0.0872844014885;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0429130765678;
                                    } else {
                                        return -0.0299774505405;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 19.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[2] <= 8.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.411005350535;
                                    } else {
                                        return 0.417339091949;
                                    }
                                } else {
                                    return 0.422100492578;
                                }
                            } else {
                                if (fs[2] <= 8.5) {
                                    return 0.422989953481;
                                } else {
                                    return 0.449224969266;
                                }
                            }
                        } else {
                            if (fs[2] <= 7.5) {
                                return 0.00114233352197;
                            } else {
                                return -0.0513252346487;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[50] <= -1508.5) {
                                        return 0.390478805628;
                                    } else {
                                        return 0.235266323034;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.397689107116;
                                    } else {
                                        return -0.0823610751318;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.00903585296888;
                                    } else {
                                        return -0.0463719941005;
                                    }
                                } else {
                                    if (fs[69] <= 9911.5) {
                                        return -0.0509121913093;
                                    } else {
                                        return 0.346803454215;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[82] <= -0.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.110878716639;
                                    } else {
                                        return -0.158773811259;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.122577531371;
                                    } else {
                                        return 0.219524757236;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9972.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0789446717091;
                                    } else {
                                        return -0.0669729501256;
                                    }
                                } else {
                                    if (fs[50] <= -1578.0) {
                                        return 0.372902686781;
                                    } else {
                                        return 0.1419696699;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 6.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.313965385533;
                                    } else {
                                        return 0.230238398399;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.358443740198;
                                    } else {
                                        return 0.434215683592;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[50] <= -1538.0) {
                                        return 0.321959205633;
                                    } else {
                                        return 0.03342627656;
                                    }
                                } else {
                                    return 0.424294678557;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[69] <= 9738.0) {
                                        return 0.35227263334;
                                    } else {
                                        return 0.433012040586;
                                    }
                                } else {
                                    if (fs[50] <= -1468.0) {
                                        return 0.44270491474;
                                    } else {
                                        return 0.485213085945;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9763.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.354344402005;
                                    } else {
                                        return 0.212986063037;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.364551752245;
                                    } else {
                                        return 0.40442836649;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[69] <= 9902.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0207719388085;
                                    } else {
                                        return -0.0270775314119;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0789423205319;
                                    } else {
                                        return 0.184149963202;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0615957711354;
                                    } else {
                                        return -0.0105575308882;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0547544933843;
                                    } else {
                                        return 0.379790175289;
                                    }
                                }
                            }
                        } else {
                            if (fs[86] <= 0.5) {
                                if (fs[50] <= -941.5) {
                                    if (fs[50] <= -982.5) {
                                        return -0.0485376027866;
                                    } else {
                                        return -0.0148320092822;
                                    }
                                } else {
                                    return -0.0539702535036;
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0435779234552;
                                    } else {
                                        return 0.0447308425262;
                                    }
                                } else {
                                    if (fs[2] <= 10.5) {
                                        return -0.0308335463539;
                                    } else {
                                        return 0.121051083134;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 5.5) {
                            if (fs[69] <= 9866.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.0186846596137;
                                    } else {
                                        return -0.00780155938989;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.00628947267294;
                                    } else {
                                        return -0.0184167278481;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0292038538441;
                                    } else {
                                        return 0.177177541499;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.00553561909338;
                                    } else {
                                        return 0.230677337215;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9997.5) {
                                if (fs[0] <= 11.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0192915828652;
                                    } else {
                                        return -0.0262075711763;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0229094134463;
                                    } else {
                                        return -0.0245113847817;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1277.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0682042673354;
                                    } else {
                                        return 0.248018039049;
                                    }
                                } else {
                                    if (fs[50] <= -1108.0) {
                                        return 0.0531703817211;
                                    } else {
                                        return -0.0136822347692;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[97] <= 0.5) {
                    if (fs[49] <= 0.5) {
                        if (fs[50] <= -1273.5) {
                            if (fs[76] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    return -0.0232586465523;
                                } else {
                                    return 0.317746943637;
                                }
                            } else {
                                return -0.235466563602;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.441923720715;
                                    } else {
                                        return 0.0873173007761;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.482429757717;
                                    } else {
                                        return 0.108632996261;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.413937574512;
                                    } else {
                                        return 0.474588632616;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.187121195057;
                                    } else {
                                        return 0.550822401663;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[95] <= 0.5) {
                                if (fs[4] <= 13.0) {
                                    if (fs[94] <= 0.5) {
                                        return -0.0500751405021;
                                    } else {
                                        return 0.186675307044;
                                    }
                                } else {
                                    return -0.173776136506;
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[69] <= 4999.5) {
                                        return 0.175672090853;
                                    } else {
                                        return 0.303752744043;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.0774072722363;
                                    } else {
                                        return 0.00300421495198;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[69] <= 5000.0) {
                                    if (fs[73] <= 50.0) {
                                        return 0.147180489079;
                                    } else {
                                        return 0.430606072265;
                                    }
                                } else {
                                    return 0.485477811605;
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return -0.0238527431125;
                                    } else {
                                        return 0.182772427813;
                                    }
                                } else {
                                    return -0.250252162563;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[40] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[46] <= -3.5) {
                                return -0.119925985723;
                            } else {
                                if (fs[46] <= -0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.286042531483;
                                    } else {
                                        return 0.401490941521;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.37674396507;
                                    } else {
                                        return 0.31951113356;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 22.5) {
                                if (fs[50] <= -1014.0) {
                                    if (fs[73] <= 250.0) {
                                        return 0.432215623411;
                                    } else {
                                        return 0.341992528397;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0441083285023;
                                    } else {
                                        return 0.332513286685;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1528.0) {
                                    return 0.53167223582;
                                } else {
                                    if (fs[4] <= 24.5) {
                                        return 0.0725696225222;
                                    } else {
                                        return 0.2256224065;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            return 0.08529294859;
                        } else {
                            if (fs[49] <= 0.5) {
                                return 0.27145891441;
                            } else {
                                if (fs[97] <= 1.5) {
                                    return 0.0586484837446;
                                } else {
                                    return 0.126091206147;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[50] <= -1122.5) {
                        if (fs[73] <= 250.0) {
                            if (fs[97] <= 1.5) {
                                if (fs[69] <= 4999.0) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0487868294013;
                                    } else {
                                        return 0.0230489458181;
                                    }
                                } else {
                                    return 0.193349998746;
                                }
                            } else {
                                return 0.0589610322266;
                            }
                        } else {
                            if (fs[97] <= 1.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.069392128124;
                                    } else {
                                        return 0.241412713556;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.00535700552019;
                                    } else {
                                        return 0.0695924565243;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.333117940598;
                                    } else {
                                        return 0.117662595274;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.336308217698;
                                    } else {
                                        return 0.00178570652636;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.225158264911;
                                    } else {
                                        return 0.0927714847642;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.0246293009659;
                                    } else {
                                        return 0.0450560723827;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.00894077354607;
                                    } else {
                                        return -0.0388767488517;
                                    }
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return -0.0498479190502;
                                    } else {
                                        return -0.0336572343845;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 1.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.422578084738;
                                    } else {
                                        return 0.0859738950648;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return -0.0353595355522;
                                    } else {
                                        return 0.0491149717135;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return -0.0219788468758;
                                    } else {
                                        return -0.0493581947208;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.0784231508371;
                                    } else {
                                        return -0.0636566276433;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[59] <= -1.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    return 0.218504907476;
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.0289781965533;
                                    } else {
                                        return -0.0254872151059;
                                    }
                                }
                            } else {
                                if (fs[61] <= -995.5) {
                                    if (fs[50] <= -987.0) {
                                        return 0.0944178480322;
                                    } else {
                                        return -0.0231378263382;
                                    }
                                } else {
                                    return -0.0612540000956;
                                }
                            }
                        } else {
                            if (fs[46] <= -1.5) {
                                return 0.167563764455;
                            } else {
                                return 0.137817053132;
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0301946857427;
                                    } else {
                                        return 0.295939249754;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0115066100268;
                                    } else {
                                        return -0.0246314179382;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0212963299087;
                                    } else {
                                        return 0.0297520726025;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return 0.026612918237;
                                    } else {
                                        return 0.107364371381;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 124.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.0230902188223;
                                    } else {
                                        return 0.0281643370085;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0223013593804;
                                    } else {
                                        return -0.024982475389;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    return 0.0652046656278;
                                } else {
                                    return -0.0254275197695;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
