/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree13 {
    public double calcTree(double... fs) {
        if (fs[39] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.328634627829;
                                    } else {
                                        return 0.00209238938745;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.447744978788;
                                    } else {
                                        return 0.0318371543661;
                                    }
                                }
                            } else {
                                if (fs[82] <= 1.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0174576283567;
                                    } else {
                                        return -0.144817836175;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.202847915259;
                                    } else {
                                        return 0.325157073997;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    return -0.160478869997;
                                } else {
                                    if (fs[61] <= -499.0) {
                                        return 0.480560274268;
                                    } else {
                                        return 0.293530526157;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.265470432492;
                                    } else {
                                        return 0.0229970045295;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.112948071276;
                                    } else {
                                        return 0.568324540002;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1558.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[67] <= -1.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.104132568928;
                                    } else {
                                        return 0.452376063219;
                                    }
                                } else {
                                    return -0.0359230318742;
                                }
                            } else {
                                if (fs[82] <= 1.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0915370760819;
                                    } else {
                                        return -0.182833074881;
                                    }
                                } else {
                                    if (fs[50] <= -1958.0) {
                                        return 0.325433182506;
                                    } else {
                                        return 0.468573759011;
                                    }
                                }
                            }
                        } else {
                            if (fs[43] <= 0.5) {
                                if (fs[61] <= -995.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.513902682959;
                                    } else {
                                        return 0.352611165078;
                                    }
                                } else {
                                    if (fs[67] <= -3.5) {
                                        return 0.241083725354;
                                    } else {
                                        return 0.123499541078;
                                    }
                                }
                            } else {
                                if (fs[4] <= 23.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.40838812947;
                                    } else {
                                        return -0.122602435184;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.267827774693;
                                    } else {
                                        return -0.196014470404;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.495761068237;
                                    } else {
                                        return 0.456440544343;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.453805980091;
                                    } else {
                                        return 0.492132556441;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.447677790316;
                                    } else {
                                        return -0.0647685764049;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.397126534745;
                                    } else {
                                        return 0.247721291066;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.104915876093;
                                    } else {
                                        return 0.422005484821;
                                    }
                                } else {
                                    if (fs[73] <= 350.0) {
                                        return 0.0286192045227;
                                    } else {
                                        return 0.486839025918;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.0396843357088;
                                    } else {
                                        return 0.163995786307;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.486520953548;
                                    } else {
                                        return 0.394594731597;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[59] <= -0.5) {
                                        return 0.422217237182;
                                    } else {
                                        return 0.277985207809;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.515647176748;
                                    } else {
                                        return 0.373850869606;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[50] <= -1318.0) {
                                        return 0.573025217378;
                                    } else {
                                        return 0.494340855425;
                                    }
                                } else {
                                    return 0.589154296613;
                                }
                            }
                        } else {
                            if (fs[69] <= 9825.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.300382984362;
                                    } else {
                                        return 0.0918014030945;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0424111535088;
                                    } else {
                                        return 0.223787743306;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[50] <= -1458.0) {
                                        return 0.30511408438;
                                    } else {
                                        return 0.45603183836;
                                    }
                                } else {
                                    if (fs[50] <= -1062.5) {
                                        return 0.339125942709;
                                    } else {
                                        return 0.171807917623;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[69] <= 9868.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0645113339608;
                                    } else {
                                        return 0.0079710588263;
                                    }
                                } else {
                                    if (fs[59] <= -2.5) {
                                        return 0.123371123617;
                                    } else {
                                        return -0.0384739926123;
                                    }
                                }
                            } else {
                                if (fs[46] <= -0.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.546652825105;
                                    } else {
                                        return 0.327516664226;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return 0.0486970331717;
                                    } else {
                                        return 0.42128481948;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0207937424078;
                                    } else {
                                        return 0.0783667219006;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0079902339061;
                                    } else {
                                        return -0.0199626249553;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0171242008882;
                                    } else {
                                        return -0.0429167857836;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.701830095364;
                                    } else {
                                        return 0.229047554797;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[95] <= 0.5) {
                                if (fs[75] <= 0.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.00486765808444;
                                    } else {
                                        return -0.0438836868053;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return -0.028167167809;
                                    } else {
                                        return -0.0300870332978;
                                    }
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.0107679022352;
                                    } else {
                                        return -0.0166684019907;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0262136303107;
                                    } else {
                                        return -0.03128184328;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0180856130785;
                                    } else {
                                        return -0.031355041871;
                                    }
                                } else {
                                    if (fs[0] <= 20.5) {
                                        return -0.0169525458677;
                                    } else {
                                        return -0.0285305876701;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0254337449316;
                                    } else {
                                        return -0.0177668641405;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return -0.0307803435517;
                                    } else {
                                        return 0.00227046997547;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1418.0) {
                        if (fs[69] <= 9999.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[69] <= 9985.5) {
                                    if (fs[82] <= 2.5) {
                                        return 0.027681687964;
                                    } else {
                                        return -0.0317267366483;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0814368924387;
                                    } else {
                                        return 0.226293343815;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.260622418793;
                                    } else {
                                        return 0.0846850150674;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.626945157312;
                                    } else {
                                        return 0.275818986321;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[0] <= 20.5) {
                                    if (fs[63] <= 5.0) {
                                        return 0.318959881928;
                                    } else {
                                        return -0.140353054736;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.244312018104;
                                    } else {
                                        return -0.0858389118063;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    return -0.00917111708956;
                                } else {
                                    return -0.132632233642;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[69] <= 9994.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.135710811702;
                                    } else {
                                        return 0.00892339281681;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.110167230487;
                                    } else {
                                        return -0.0590765999937;
                                    }
                                }
                            } else {
                                if (fs[100] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00238761528616;
                                    } else {
                                        return 0.100505432611;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return 0.411394461434;
                                    } else {
                                        return 0.0619696236581;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9995.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0288127172512;
                                    } else {
                                        return -0.0570195392275;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0288990371601;
                                    } else {
                                        return 0.000952409963382;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0745477602078;
                                    } else {
                                        return 0.00608023718295;
                                    }
                                } else {
                                    if (fs[73] <= 350.0) {
                                        return -0.0147578055357;
                                    } else {
                                        return 0.102355164566;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[91] <= 0.5) {
                    if (fs[4] <= 10.5) {
                        if (fs[82] <= 4.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.465516878759;
                                    } else {
                                        return 0.546510752536;
                                    }
                                } else {
                                    return 0.556842956964;
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.216288581816;
                                    } else {
                                        return 0.397067065829;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.506242001204;
                                    } else {
                                        return 0.345073797475;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                return -0.261855783097;
                            } else {
                                return 0.415274990267;
                            }
                        }
                    } else {
                        if (fs[50] <= -1012.0) {
                            if (fs[94] <= 0.5) {
                                if (fs[97] <= 1.5) {
                                    if (fs[69] <= 9943.0) {
                                        return 0.11475177928;
                                    } else {
                                        return 0.449943041956;
                                    }
                                } else {
                                    return 0.498086057667;
                                }
                            } else {
                                return -0.216573164607;
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                return 0.249607403939;
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.136389930116;
                                    } else {
                                        return 0.210423200492;
                                    }
                                } else {
                                    return -0.186729658162;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[50] <= -436.0) {
                            if (fs[49] <= 0.5) {
                                if (fs[61] <= -995.5) {
                                    if (fs[55] <= 0.5) {
                                        return 0.487477142321;
                                    } else {
                                        return 0.363753500851;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return 0.343866814443;
                                    } else {
                                        return 0.425080471926;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.281731248013;
                                    } else {
                                        return 0.43946338737;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.440964655777;
                                    } else {
                                        return 0.135924091728;
                                    }
                                }
                            }
                        } else {
                            if (fs[46] <= -0.5) {
                                if (fs[61] <= -997.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.433725131807;
                                    } else {
                                        return 0.302459567946;
                                    }
                                } else {
                                    return 0.186417628127;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.117210145459;
                                    } else {
                                        return 0.128782350362;
                                    }
                                } else {
                                    return 0.112528703707;
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.477086752665;
                                    } else {
                                        return 0.443894833871;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.411024203771;
                                    } else {
                                        return 0.483472619577;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.172630918777;
                                    } else {
                                        return 0.407023115842;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.219953779301;
                                    } else {
                                        return -0.162194950362;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[49] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.190768129652;
                                    } else {
                                        return 0.364606156565;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.372983031681;
                                    } else {
                                        return 0.191849130306;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1128.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0685359157148;
                                    } else {
                                        return -0.0588066658919;
                                    }
                                } else {
                                    return 0.303518116592;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1112.5) {
                    if (fs[97] <= 1.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[95] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0115316269505;
                                    } else {
                                        return -0.0305955815636;
                                    }
                                } else {
                                    return 0.0772747503042;
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0465528076501;
                                    } else {
                                        return 0.502570800466;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.0121833286599;
                                    } else {
                                        return 0.151019669318;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.219731108656;
                                    } else {
                                        return 0.0430859398316;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.336137125051;
                                    } else {
                                        return 0.554709358757;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[4] <= 21.5) {
                                        return -0.00382018205214;
                                    } else {
                                        return 0.0806510882397;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0289718398729;
                                    } else {
                                        return 0.10020917861;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[59] <= -1.5) {
                            if (fs[61] <= -997.5) {
                                return 0.514234009168;
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.0896012743023;
                                } else {
                                    return 0.338078792931;
                                }
                            }
                        } else {
                            if (fs[61] <= -994.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.270102683592;
                                    } else {
                                        return 0.183063494148;
                                    }
                                } else {
                                    return 0.683220672786;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 7.5) {
                                        return 0.127703154189;
                                    } else {
                                        return 0.661417942415;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0553624324901;
                                    } else {
                                        return 0.134176083654;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[97] <= 1.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.00775920547918;
                                    } else {
                                        return 0.0973534636154;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return 0.546885379688;
                                    } else {
                                        return 0.239296444974;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0396976184564;
                                    } else {
                                        return -0.0269248213986;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return -0.019254991197;
                                    } else {
                                        return 0.0851928868282;
                                    }
                                }
                            }
                        } else {
                            if (fs[46] <= -2.5) {
                                return 0.0741101461453;
                            } else {
                                if (fs[50] <= -992.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.292256231336;
                                    } else {
                                        return 0.0608590706559;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0323590070153;
                                    } else {
                                        return -0.00350643675461;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[65] <= 1.5) {
                            if (fs[0] <= 5.5) {
                                if (fs[59] <= -2.5) {
                                    return 0.131488317974;
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0430415963816;
                                    } else {
                                        return -0.0221205532034;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0354810034511;
                                    } else {
                                        return -0.0455814412159;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0479157372134;
                                    } else {
                                        return -0.0300679781007;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                return 0.189832491298;
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0355184691161;
                                    } else {
                                        return -0.0321029103633;
                                    }
                                } else {
                                    return -0.0327175575603;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
