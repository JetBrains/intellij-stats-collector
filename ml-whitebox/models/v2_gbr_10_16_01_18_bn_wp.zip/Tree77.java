/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree77 {
    public double calcTree(double... fs) {
        if (fs[61] <= -997.5) {
            if (fs[44] <= 0.5) {
                if (fs[14] <= 0.5) {
                    if (fs[4] <= 21.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    return -0.0621626126377;
                                } else {
                                    if (fs[50] <= -476.5) {
                                        return 0.0120053232781;
                                    } else {
                                        return 0.142193835321;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[97] <= 1.5) {
                                        return -0.0719171083971;
                                    } else {
                                        return 0.0126002165316;
                                    }
                                } else {
                                    return -0.0647330890992;
                                }
                            }
                        } else {
                            if (fs[82] <= 5.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[50] <= -1123.5) {
                                        return 0.0403369362998;
                                    } else {
                                        return 0.0147741940906;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0247233794088;
                                    } else {
                                        return 0.0832168041785;
                                    }
                                }
                            } else {
                                if (fs[61] <= -998.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.068559567083;
                                    } else {
                                        return 0.0594230404035;
                                    }
                                } else {
                                    if (fs[69] <= 5000.0) {
                                        return -0.0265494871793;
                                    } else {
                                        return 0.161799770386;
                                    }
                                }
                            }
                        }
                    } else {
                        return -0.198267851825;
                    }
                } else {
                    return -0.212279639236;
                }
            } else {
                if (fs[61] <= -998.5) {
                    return -0.0286960822093;
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0662791256515;
                                    } else {
                                        return -0.0290007162191;
                                    }
                                } else {
                                    return -0.0143210915996;
                                }
                            } else {
                                return -0.0138615295295;
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.008652222538;
                                    } else {
                                        return -0.0166027800471;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.0121028883108;
                                    } else {
                                        return -0.0141489451485;
                                    }
                                }
                            } else {
                                return -0.0153849854823;
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                return -0.0159453874017;
                            } else {
                                return -0.0112791175577;
                            }
                        } else {
                            if (fs[46] <= -1.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 11.5) {
                                        return -0.0119712090041;
                                    } else {
                                        return -0.00988118103888;
                                    }
                                } else {
                                    return -0.0191345390737;
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.017350000108;
                                    } else {
                                        return -0.00715703711213;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0014005184842;
                                    } else {
                                        return -0.0109826144372;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[68] <= 0.5) {
                    if (fs[87] <= 0.5) {
                        if (fs[86] <= 0.5) {
                            if (fs[69] <= 9998.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[50] <= -1968.0) {
                                        return -0.26198673656;
                                    } else {
                                        return 0.051418192699;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.0775899162895;
                                    } else {
                                        return 0.157294938098;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1463.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.108630634177;
                                    } else {
                                        return -0.0236193592788;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.272661600598;
                                    } else {
                                        return 0.196387560565;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.0159876377042;
                                    } else {
                                        return 0.0469555384995;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0569658022679;
                                    } else {
                                        return -0.0259157145236;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0735960552705;
                                    } else {
                                        return 0.0417590873677;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0329570743631;
                                    } else {
                                        return -0.327035705453;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 15.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[50] <= -1473.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.255887793839;
                                    } else {
                                        return -0.00510829256845;
                                    }
                                } else {
                                    return 0.018324216525;
                                }
                            } else {
                                return -0.276617592304;
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[69] <= 9874.5) {
                                    return -0.0761200916407;
                                } else {
                                    return -0.171165141361;
                                }
                            } else {
                                return 0.081028421039;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 5.5) {
                        if (fs[50] <= -1143.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return -0.0262578331877;
                                    } else {
                                        return -0.135391167684;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.145958599117;
                                    } else {
                                        return 0.0681379746471;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[82] <= 4.5) {
                                        return -0.211827331756;
                                    } else {
                                        return 0.0269971794168;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.171595089254;
                                    } else {
                                        return 0.0784167298579;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[50] <= -1049.0) {
                                        return 0.0317980370491;
                                    } else {
                                        return -0.0993320209062;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.00700321639994;
                                    } else {
                                        return -0.0326455532535;
                                    }
                                }
                            } else {
                                if (fs[50] <= -472.0) {
                                    if (fs[50] <= -1108.5) {
                                        return 0.0295367698846;
                                    } else {
                                        return -0.126770884523;
                                    }
                                } else {
                                    if (fs[4] <= 1.5) {
                                        return 0.232744272589;
                                    } else {
                                        return 0.0538808211685;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[83] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[69] <= 9878.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.13994617962;
                                    } else {
                                        return -0.0278132714076;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.00182919206962;
                                    } else {
                                        return 0.0530444315989;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    if (fs[77] <= 0.5) {
                                        return -0.093983185125;
                                    } else {
                                        return -0.450274277178;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0202319252773;
                                    } else {
                                        return -0.0126915134474;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 26.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[4] <= 23.5) {
                                        return 0.0474865179809;
                                    } else {
                                        return -0.0375934978495;
                                    }
                                } else {
                                    if (fs[69] <= 9539.5) {
                                        return -0.0799627300501;
                                    } else {
                                        return 0.0467434178229;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[13] <= 0.5) {
                                        return -0.22569655696;
                                    } else {
                                        return 0.140281435101;
                                    }
                                } else {
                                    if (fs[69] <= 9972.0) {
                                        return 0.0925517913656;
                                    } else {
                                        return 0.325793928531;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[14] <= 0.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[4] <= 15.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[79] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.00281013547102;
                                    } else {
                                        return 0.0242667538046;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0119362904163;
                                    } else {
                                        return 0.123887486149;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.10025786207;
                                    } else {
                                        return 0.00748612829173;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return 0.149010294542;
                                    } else {
                                        return 0.0109935962832;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -3443.0) {
                                if (fs[4] <= 32.0) {
                                    return 0.196135087497;
                                } else {
                                    return 0.277222782197;
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return -0.0055651775321;
                                    } else {
                                        return 0.11310183372;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0851909475434;
                                    } else {
                                        return -0.12881933111;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[29] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[0] <= 118.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.00285075963554;
                                    } else {
                                        return -0.00141983031614;
                                    }
                                } else {
                                    if (fs[0] <= 121.5) {
                                        return 0.0786801556902;
                                    } else {
                                        return -0.00217767729022;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[97] <= 1.5) {
                                        return -0.00034601358166;
                                    } else {
                                        return 0.0357899812425;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.234150702312;
                                    } else {
                                        return 0.0187636189822;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9997.0) {
                                if (fs[4] <= 7.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00985314754128;
                                    } else {
                                        return -0.0832898219297;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.00262475498912;
                                    } else {
                                        return -0.0170968471037;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return -0.219466703596;
                                } else {
                                    return -0.114124751903;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 5.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0129681828827;
                                    } else {
                                        return -0.0246070421087;
                                    }
                                } else {
                                    return 0.0429005523865;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return 0.300210820966;
                                } else {
                                    return 0.0197449432989;
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[50] <= -491.5) {
                                    return -0.0655542416117;
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.123783645282;
                                    } else {
                                        return 0.16748670678;
                                    }
                                }
                            } else {
                                return 0.398598362897;
                            }
                        }
                    } else {
                        if (fs[73] <= 75.0) {
                            if (fs[50] <= -2833.0) {
                                return 0.104006544397;
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.00637249759692;
                                    } else {
                                        return -0.00932771176737;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0551531567548;
                                    } else {
                                        return 0.00771116466754;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[69] <= 9995.5) {
                                        return 0.147281729758;
                                    } else {
                                        return -0.0616217448168;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.0550485172642;
                                    } else {
                                        return -0.017942412095;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -986.0) {
                                        return -0.044396069372;
                                    } else {
                                        return 0.0515328709916;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.00294563764855;
                                    } else {
                                        return -0.00750979665171;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
