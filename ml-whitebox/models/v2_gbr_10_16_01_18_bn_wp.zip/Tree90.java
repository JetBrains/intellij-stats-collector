/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree90 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[14] <= 0.5) {
                if (fs[0] <= 1.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[50] <= -1138.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.010654029377;
                                    } else {
                                        return 0.0283031779208;
                                    }
                                } else {
                                    return -0.0923903495205;
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.00976755572199;
                                    } else {
                                        return -0.0659861408317;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.00589325054848;
                                    } else {
                                        return 0.0629206885963;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[50] <= -988.0) {
                                    if (fs[50] <= -1123.5) {
                                        return 0.0168838759579;
                                    } else {
                                        return 0.0341129092422;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.00329324114161;
                                    } else {
                                        return -0.157710032093;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    return -0.140921455861;
                                } else {
                                    return -0.0126200210393;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[57] <= 0.5) {
                                return -0.0858918036975;
                            } else {
                                return -0.290711979797;
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0374212810495;
                                    } else {
                                        return -0.0196367416009;
                                    }
                                } else {
                                    return -0.0715799054156;
                                }
                            } else {
                                return -0.0905777113828;
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1108.0) {
                        if (fs[4] <= 2.5) {
                            return 0.15813479359;
                        } else {
                            if (fs[34] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0498527625523;
                                    } else {
                                        return -0.00208859306338;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0101257112985;
                                    } else {
                                        return 0.0751871442038;
                                    }
                                }
                            } else {
                                return 0.185537796962;
                            }
                        }
                    } else {
                        if (fs[4] <= 2.5) {
                            return -0.111171077332;
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.00774532067511;
                                    } else {
                                        return -0.0379563323512;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.121118172761;
                                    } else {
                                        return -0.0484858892396;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0294876554214;
                                    } else {
                                        return -0.0509100280841;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0245609747634;
                                    } else {
                                        return -0.0043263241236;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 1.5) {
                    return 0.234641826114;
                } else {
                    if (fs[2] <= 2.5) {
                        return 0.070086523958;
                    } else {
                        return 0.0260020495568;
                    }
                }
            }
        } else {
            if (fs[23] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[18] <= -0.5) {
                        if (fs[50] <= -1473.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.183439370949;
                                    } else {
                                        return -0.322047473315;
                                    }
                                } else {
                                    return -0.146098839883;
                                }
                            } else {
                                return -0.0809686544473;
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    return -0.00555365472542;
                                } else {
                                    return -0.167942224064;
                                }
                            } else {
                                return 0.19814699499;
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[79] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0317901778337;
                                    } else {
                                        return -0.0134584116246;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return -0.00946399099223;
                                    } else {
                                        return 0.0336196378785;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[82] <= 6.0) {
                                        return -0.056554047926;
                                    } else {
                                        return 0.110331490428;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return 0.0220408092132;
                                    } else {
                                        return 0.336616544187;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[4] <= 27.5) {
                                    if (fs[50] <= -1493.5) {
                                        return 0.045860739493;
                                    } else {
                                        return 0.00822507040532;
                                    }
                                } else {
                                    if (fs[50] <= -2193.0) {
                                        return 0.0721458398742;
                                    } else {
                                        return -0.0725924052913;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[50] <= -481.5) {
                                        return 0.103016552732;
                                    } else {
                                        return 0.0514598746247;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0120421996184;
                                    } else {
                                        return 0.0506694275319;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[52] <= 0.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[50] <= -1368.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.00661169671942;
                                    } else {
                                        return -0.00103349012479;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.002805312477;
                                    } else {
                                        return 0.0316121315817;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.000725471290737;
                                    } else {
                                        return 0.00335690233085;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0267008658422;
                                    } else {
                                        return -0.00183865262124;
                                    }
                                }
                            }
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[69] <= 9998.5) {
                                        return -0.0443945364532;
                                    } else {
                                        return -0.179503027271;
                                    }
                                } else {
                                    if (fs[69] <= 9997.0) {
                                        return -0.00572398514919;
                                    } else {
                                        return -0.104517431124;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    return -0.0979294767058;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0502270968625;
                                    } else {
                                        return -0.0744235744178;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 5.5) {
                            if (fs[82] <= 2.5) {
                                if (fs[52] <= 993.5) {
                                    if (fs[50] <= -721.5) {
                                        return 0.25017420048;
                                    } else {
                                        return 0.131716677;
                                    }
                                } else {
                                    if (fs[52] <= 998.0) {
                                        return -0.092523586242;
                                    } else {
                                        return 0.035995758728;
                                    }
                                }
                            } else {
                                return 0.152458649041;
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    return 0.0366281251699;
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0471476729124;
                                    } else {
                                        return -0.0168539914416;
                                    }
                                }
                            } else {
                                return 0.068535297991;
                            }
                        }
                    }
                }
            } else {
                if (fs[44] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[50] <= -1138.0) {
                            if (fs[4] <= 8.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.04311448051;
                                    } else {
                                        return 0.144656625286;
                                    }
                                } else {
                                    if (fs[69] <= 9526.5) {
                                        return 0.100879726286;
                                    } else {
                                        return -0.132851658076;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.0) {
                                    if (fs[0] <= 0.5) {
                                        return 0.277229915314;
                                    } else {
                                        return 0.251980406425;
                                    }
                                } else {
                                    return 0.0226691158926;
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[50] <= -557.0) {
                                    return 0.0552241762815;
                                } else {
                                    return 0.331925382262;
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0633665961432;
                                    } else {
                                        return 0.00170318937364;
                                    }
                                } else {
                                    return -0.24272424444;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[69] <= 9901.0) {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.146237895136;
                                    } else {
                                        return 0.219175432918;
                                    }
                                } else {
                                    return 0.262099799068;
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0336393736423;
                                    } else {
                                        return 0.0461932854043;
                                    }
                                } else {
                                    return 0.184733478839;
                                }
                            }
                        } else {
                            return 0.0129607969361;
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[69] <= 9855.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[4] <= 14.5) {
                                    return -0.0291730940624;
                                } else {
                                    return -0.021364414324;
                                }
                            } else {
                                return -0.035273879084;
                            }
                        } else {
                            return -0.0954647369477;
                        }
                    } else {
                        if (fs[69] <= 9847.0) {
                            if (fs[0] <= 2.5) {
                                return -0.0160347829181;
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[0] <= 13.5) {
                                        return -0.00822180594767;
                                    } else {
                                        return -0.00271216783526;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.00615650207128;
                                    } else {
                                        return -0.0025079776853;
                                    }
                                }
                            }
                        } else {
                            return -0.030449419331;
                        }
                    }
                }
            }
        }
    }
}
