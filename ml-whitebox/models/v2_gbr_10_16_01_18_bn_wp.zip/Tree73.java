/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree73 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[54] <= 0.5) {
                if (fs[2] <= 3.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -988.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0216189828215;
                                    } else {
                                        return 0.0691450396102;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0063941795875;
                                    } else {
                                        return -0.0732320125098;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0424010559285;
                                    } else {
                                        return 0.0247394557893;
                                    }
                                } else {
                                    if (fs[69] <= 9902.0) {
                                        return -0.0652015767737;
                                    } else {
                                        return 0.0582074023029;
                                    }
                                }
                            }
                        } else {
                            if (fs[86] <= 0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.0562216862713;
                                    } else {
                                        return 0.165544797393;
                                    }
                                } else {
                                    if (fs[73] <= 150.0) {
                                        return -0.172241536742;
                                    } else {
                                        return -0.0983898154411;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[69] <= 9980.5) {
                                        return -0.0237305202583;
                                    } else {
                                        return 0.0190922653621;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.016984300375;
                                    } else {
                                        return -0.010361677388;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -546.5) {
                            if (fs[67] <= -4.0) {
                                if (fs[2] <= 2.5) {
                                    if (fs[69] <= 9996.5) {
                                        return 0.172067667462;
                                    } else {
                                        return 0.127339447338;
                                    }
                                } else {
                                    return 0.108627033849;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    return 0.0720514384046;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.23673596823;
                                    } else {
                                        return 0.154834300058;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9998.5) {
                                if (fs[69] <= 9983.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.140125356276;
                                    } else {
                                        return 0.100215184788;
                                    }
                                } else {
                                    return 0.259809746795;
                                }
                            } else {
                                return -0.288917382061;
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 10.5) {
                        if (fs[4] <= 14.5) {
                            if (fs[29] <= 0.5) {
                                if (fs[2] <= 5.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0344751650094;
                                    } else {
                                        return 0.011397799302;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0511562527268;
                                    } else {
                                        return -0.00867112517645;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.00213986790247;
                                    } else {
                                        return -0.289736835551;
                                    }
                                } else {
                                    return 0.0674955194692;
                                }
                            }
                        } else {
                            if (fs[4] <= 27.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[77] <= 0.5) {
                                        return 0.0112810945873;
                                    } else {
                                        return -0.127120425152;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.304595586557;
                                    } else {
                                        return 0.0316741454946;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[69] <= 9997.5) {
                                        return -0.0897805821146;
                                    } else {
                                        return 0.0499577911374;
                                    }
                                } else {
                                    return 0.197132453588;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 27.5) {
                            if (fs[82] <= 1.5) {
                                if (fs[2] <= 15.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.0714872846902;
                                    } else {
                                        return 0.230765242923;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.116703460105;
                                    } else {
                                        return 0.16994198622;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.0) {
                                    return 0.131478434698;
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.353978917009;
                                    } else {
                                        return 0.2044416867;
                                    }
                                }
                            }
                        } else {
                            return -0.0554070811421;
                        }
                    }
                }
            } else {
                if (fs[46] <= -0.5) {
                    if (fs[61] <= -998.5) {
                        return 0.01574360025;
                    } else {
                        if (fs[59] <= -1.5) {
                            if (fs[46] <= -2.5) {
                                if (fs[2] <= 1.5) {
                                    return -0.0226905871155;
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.120856945623;
                                    } else {
                                        return 0.0679964193586;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    return 0.149460325911;
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.103297039;
                                    } else {
                                        return 0.0596245763249;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                return -0.0529463968282;
                            } else {
                                return 0.106910084266;
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 1.5) {
                        if (fs[4] <= 20.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0926002737537;
                                    } else {
                                        return 0.21368599823;
                                    }
                                } else {
                                    return 0.135031059795;
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.307682082129;
                                    } else {
                                        return 0.190587193893;
                                    }
                                } else {
                                    return 0.0429299117256;
                                }
                            }
                        } else {
                            return 0.0601602965176;
                        }
                    } else {
                        if (fs[50] <= -546.5) {
                            return -0.202171615434;
                        } else {
                            if (fs[2] <= 2.5) {
                                return 0.0487426885434;
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.203452431063;
                                } else {
                                    return 0.103194800072;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[34] <= 0.5) {
                if (fs[69] <= 9999.5) {
                    if (fs[4] <= 25.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[0] <= 8.5) {
                                        return 0.000427541827194;
                                    } else {
                                        return -0.00136924614936;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.0923282023284;
                                    } else {
                                        return 0.043229346699;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[50] <= -1273.0) {
                                        return 0.0259678650052;
                                    } else {
                                        return 0.00169990089351;
                                    }
                                } else {
                                    if (fs[0] <= 10.0) {
                                        return 0.223529130428;
                                    } else {
                                        return 0.395900094533;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.00990855918929;
                                    } else {
                                        return -0.00162737289085;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.00325352084737;
                                    } else {
                                        return 0.00362066482892;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0110739131588;
                                    } else {
                                        return -0.00532404157724;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.00941714876352;
                                    } else {
                                        return -0.003805568804;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 16.5) {
                            if (fs[50] <= -3443.0) {
                                if (fs[0] <= 4.5) {
                                    return 0.230356821927;
                                } else {
                                    if (fs[0] <= 17.5) {
                                        return -0.0246061102533;
                                    } else {
                                        return -0.00842217121739;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[28] <= 0.5) {
                                        return -0.0110290235289;
                                    } else {
                                        return 0.0387735068651;
                                    }
                                } else {
                                    if (fs[50] <= -1498.0) {
                                        return -0.00492223180273;
                                    } else {
                                        return -0.00234449798449;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                return -0.0418497680703;
                            } else {
                                if (fs[2] <= 21.5) {
                                    return -0.14127740551;
                                } else {
                                    return -0.144960776753;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[67] <= -3.5) {
                        if (fs[82] <= 1.0) {
                            if (fs[44] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.240486292348;
                                    } else {
                                        return -0.104614724979;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.0942250270644;
                                    } else {
                                        return -0.150539955305;
                                    }
                                }
                            } else {
                                if (fs[4] <= 20.0) {
                                    return -0.0483976589246;
                                } else {
                                    return -0.092944777474;
                                }
                            }
                        } else {
                            return 0.165112284222;
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[50] <= -1968.0) {
                                if (fs[33] <= 0.5) {
                                    return 0.302565834195;
                                } else {
                                    return 0.0823330299005;
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[50] <= -1108.0) {
                                        return 0.0496849564862;
                                    } else {
                                        return 0.0103797853843;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.0902974043293;
                                    } else {
                                        return 0.0059614146715;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0182499167723;
                                    } else {
                                        return -0.00267240845647;
                                    }
                                } else {
                                    return 0.0659700699189;
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    return -0.0786926374299;
                                } else {
                                    return -0.0443492744641;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[50] <= -1138.0) {
                        return 0.0848963732896;
                    } else {
                        return 0.120832810854;
                    }
                } else {
                    return 0.227518640964;
                }
            }
        }
    }
}
