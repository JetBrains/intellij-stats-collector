/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree25 {
    public double calcTree(double... fs) {
        if (fs[97] <= 1.5) {
            if (fs[34] <= 0.5) {
                if (fs[11] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[96] <= 0.5) {
                                if (fs[7] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.31678554148;
                                    } else {
                                        return 0.200207220853;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0651080885867;
                                    } else {
                                        return -0.200227538521;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1143.5) {
                                    if (fs[52] <= -0.5) {
                                        return 0.288720716245;
                                    } else {
                                        return 0.377456552945;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.283007468858;
                                    } else {
                                        return 0.313217357474;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9902.0) {
                                if (fs[2] <= 3.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0304420191337;
                                    } else {
                                        return -0.164134705961;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.246756496375;
                                    } else {
                                        return 0.395492332057;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.282565150884;
                                    } else {
                                        return 0.325353456295;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0590697758434;
                                    } else {
                                        return 0.231010315652;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 0.5) {
                            if (fs[69] <= 9988.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0194005601039;
                                    } else {
                                        return 0.0908685506019;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.000941396227391;
                                    } else {
                                        return -0.0146813913844;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0921756258056;
                                    } else {
                                        return 0.0318835654778;
                                    }
                                } else {
                                    if (fs[50] <= -1092.5) {
                                        return 0.276371085758;
                                    } else {
                                        return -0.0207877397182;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.0459205277788;
                                    } else {
                                        return -0.00192444285869;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.016147192496;
                                    } else {
                                        return -0.0202728869983;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1098.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.126415228355;
                                    } else {
                                        return 0.522891621287;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0471998407036;
                                    } else {
                                        return -0.0253065771125;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[4] <= 10.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.200046056449;
                                    } else {
                                        return 0.142605284292;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.266022298503;
                                    } else {
                                        return 0.097870572062;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.188573543047;
                                    } else {
                                        return 0.125699364098;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0169420639792;
                                    } else {
                                        return 0.318347491834;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[50] <= -1618.0) {
                                    if (fs[67] <= -1.5) {
                                        return 0.304356715706;
                                    } else {
                                        return 0.0156701219764;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.0655723295579;
                                    } else {
                                        return 0.141664803044;
                                    }
                                }
                            } else {
                                if (fs[67] <= -3.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0990246145298;
                                    } else {
                                        return 0.310296620238;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.0377257138956;
                                    } else {
                                        return 0.239428372031;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[82] <= 7.5) {
                                if (fs[69] <= 9653.0) {
                                    if (fs[40] <= 0.5) {
                                        return -0.000301833982298;
                                    } else {
                                        return 0.0383113196646;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0427069013118;
                                    } else {
                                        return 0.183049188286;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[69] <= 9995.5) {
                                        return -0.0253578215339;
                                    } else {
                                        return 0.0662013573411;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0869706900358;
                                    } else {
                                        return 0.236182034617;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.00228205681014;
                                    } else {
                                        return -0.0193405745459;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.013579542273;
                                    } else {
                                        return 0.00289485490677;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[75] <= 0.5) {
                                        return -0.0333447486586;
                                    } else {
                                        return -0.0167659928431;
                                    }
                                } else {
                                    if (fs[0] <= 11.5) {
                                        return -0.0120477663038;
                                    } else {
                                        return -0.0159006652893;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 7.5) {
                    if (fs[50] <= -1098.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.270922231411;
                                    } else {
                                        return 0.286099448025;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.248394644703;
                                    } else {
                                        return 0.266976339613;
                                    }
                                }
                            } else {
                                return 0.457746676985;
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.234616949657;
                                    } else {
                                        return 0.261240429761;
                                    }
                                } else {
                                    return 0.268550163953;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.384310624956;
                                } else {
                                    return 0.400956959769;
                                }
                            }
                        }
                    } else {
                        return 0.175515931192;
                    }
                } else {
                    if (fs[50] <= -1138.0) {
                        return -0.0210454789568;
                    } else {
                        return 0.274859252502;
                    }
                }
            }
        } else {
            if (fs[44] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[33] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[73] <= 150.0) {
                                    return 0.349504939709;
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.251664133593;
                                    } else {
                                        return 0.147072929362;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1128.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.206807726582;
                                    } else {
                                        return 0.330949896945;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.292310554544;
                                    } else {
                                        return -0.00854993537304;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0966713712435;
                                    } else {
                                        return -0.113688553083;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.181030774763;
                                    } else {
                                        return 0.148637174902;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[50] <= -1128.0) {
                                        return 0.0295701631762;
                                    } else {
                                        return 0.0909984252729;
                                    }
                                } else {
                                    return -0.13087053654;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 4991.5) {
                            if (fs[55] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    return 0.072065731022;
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.31893638123;
                                    } else {
                                        return -0.0518095451746;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return -0.0449880993196;
                                } else {
                                    return 0.188169683885;
                                }
                            }
                        } else {
                            return -0.240376638017;
                        }
                    }
                } else {
                    if (fs[33] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[4] <= 3.5) {
                                        return 0.199392046405;
                                    } else {
                                        return 0.0457009883744;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.375416788619;
                                    } else {
                                        return 0.165802875466;
                                    }
                                }
                            } else {
                                if (fs[13] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.172267625861;
                                    } else {
                                        return 0.453309973774;
                                    }
                                } else {
                                    return 0.380913073344;
                                }
                            }
                        } else {
                            if (fs[59] <= -0.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[46] <= -0.5) {
                                        return 0.101106829138;
                                    } else {
                                        return -0.0716013832304;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.0666290339169;
                                    } else {
                                        return 0.164075769893;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0796017815687;
                                    } else {
                                        return 0.0153140036388;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return 0.0789004395638;
                                    } else {
                                        return 0.587742263672;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[69] <= 9982.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.0317451697264;
                                    } else {
                                        return -0.0460561862482;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.11401782521;
                                    } else {
                                        return -0.0646390230433;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 18.5) {
                                        return -0.0233618721758;
                                    } else {
                                        return -0.00935314414124;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0285614687115;
                                    } else {
                                        return 0.0766300279905;
                                    }
                                }
                            }
                        } else {
                            if (fs[55] <= 0.5) {
                                return -0.0623855586236;
                            } else {
                                return 0.157580576667;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    return 0.103678081637;
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[59] <= -2.5) {
                            return 0.084785052128;
                        } else {
                            if (fs[39] <= 0.5) {
                                if (fs[6] <= 0.5) {
                                    return -0.0510541560939;
                                } else {
                                    if (fs[50] <= -976.5) {
                                        return -0.0275217514567;
                                    } else {
                                        return -0.0321777220958;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[46] <= -0.5) {
                                        return -0.040180242281;
                                    } else {
                                        return 0.0293036577603;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0108420985929;
                                    } else {
                                        return -0.0249810575395;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -977.0) {
                            if (fs[4] <= 32.5) {
                                if (fs[61] <= -996.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0257756524136;
                                    } else {
                                        return -0.0193626180162;
                                    }
                                } else {
                                    if (fs[61] <= -496.5) {
                                        return -0.0283114811837;
                                    } else {
                                        return -0.0158823466135;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 33.5) {
                                        return 0.0899413007679;
                                    } else {
                                        return -0.0176975113828;
                                    }
                                } else {
                                    return -0.0183407330364;
                                }
                            }
                        } else {
                            if (fs[46] <= -2.5) {
                                return -0.0382488722031;
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0137959173238;
                                    } else {
                                        return -0.0168765272831;
                                    }
                                } else {
                                    if (fs[62] <= 0.5) {
                                        return -0.016787411453;
                                    } else {
                                        return -0.0231453316018;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
