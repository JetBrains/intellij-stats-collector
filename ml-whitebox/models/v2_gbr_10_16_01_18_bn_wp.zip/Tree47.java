/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree47 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[0] <= 0.5) {
                    if (fs[50] <= -1138.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[69] <= 4988.0) {
                                    if (fs[40] <= 0.5) {
                                        return 0.008011835108;
                                    } else {
                                        return 0.164743343301;
                                    }
                                } else {
                                    return 0.173182887913;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    return 0.127332060486;
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.00337697186457;
                                    } else {
                                        return 0.0885179070477;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.107615019659;
                                    } else {
                                        return 0.0667784454117;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.0940160498353;
                                    } else {
                                        return 0.100849905469;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.0813408043384;
                                    } else {
                                        return -0.097569560122;
                                    }
                                } else {
                                    return -0.166487174004;
                                }
                            }
                        }
                    } else {
                        if (fs[39] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[69] <= 9990.5) {
                                        return 0.0999737781516;
                                    } else {
                                        return -0.238956930357;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return 0.0845342970738;
                                    } else {
                                        return 0.128719352403;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.124753197459;
                                    } else {
                                        return -0.0731245053386;
                                    }
                                } else {
                                    return -0.0420521916904;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.214751372983;
                                    } else {
                                        return 0.283253005272;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.156003806263;
                                    } else {
                                        return 0.1378152599;
                                    }
                                }
                            } else {
                                return 0.130144480414;
                            }
                        }
                    }
                } else {
                    if (fs[57] <= 0.5) {
                        if (fs[50] <= -988.0) {
                            if (fs[33] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    return -0.0615999171472;
                                } else {
                                    return -0.0824679859451;
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.140686440742;
                                    } else {
                                        return -0.0410649820307;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.194181545984;
                                    } else {
                                        return 0.498923508452;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return -0.0711186297705;
                                    } else {
                                        return -0.0289417979792;
                                    }
                                } else {
                                    return -0.100224801217;
                                }
                            } else {
                                return -0.0984804494172;
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[68] <= 0.5) {
                                    return -0.0999752225057;
                                } else {
                                    if (fs[0] <= 24.5) {
                                        return -0.0214119230076;
                                    } else {
                                        return 0.199818942599;
                                    }
                                }
                            } else {
                                if (fs[0] <= 17.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0569105007437;
                                    } else {
                                        return 0.296295532713;
                                    }
                                } else {
                                    return -0.0507098234316;
                                }
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                if (fs[40] <= 0.5) {
                                    return 0.224526104213;
                                } else {
                                    return -0.0627633988381;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.022401701637;
                                    } else {
                                        return -0.0789168264783;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0286177949448;
                                    } else {
                                        return -0.00400797581771;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 6.5) {
                    if (fs[4] <= 10.5) {
                        if (fs[4] <= 9.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.114264773112;
                                    } else {
                                        return 0.175147121323;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0349961583035;
                                    } else {
                                        return 0.0309592688435;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[50] <= -1098.0) {
                                        return 0.0528988889879;
                                    } else {
                                        return -0.0297257977546;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.117036111275;
                                    } else {
                                        return 0.106361786963;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[67] <= -1.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.236107266003;
                                    } else {
                                        return 0.136295158491;
                                    }
                                } else {
                                    return 0.132069366009;
                                }
                            } else {
                                if (fs[50] <= -466.5) {
                                    return -0.00185334243444;
                                } else {
                                    return -0.0418801813339;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9745.0) {
                            if (fs[0] <= 0.5) {
                                if (fs[56] <= 0.5) {
                                    return 0.112237041369;
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.12644939108;
                                    } else {
                                        return -0.0110505186671;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[69] <= 4847.0) {
                                        return -0.0171257169092;
                                    } else {
                                        return 0.206441601685;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0196215979977;
                                    } else {
                                        return -0.00716288528386;
                                    }
                                }
                            }
                        } else {
                            return -0.137633151787;
                        }
                    }
                } else {
                    return 0.0721455284075;
                }
            }
        } else {
            if (fs[69] <= 9974.5) {
                if (fs[0] <= 0.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[73] <= 25.0) {
                            if (fs[4] <= 3.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.0937179824959;
                                    } else {
                                        return -0.0583444716779;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0678326504053;
                                    } else {
                                        return 0.150467545972;
                                    }
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.0625520322481;
                                    } else {
                                        return -0.0309992042364;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.130704537748;
                                    } else {
                                        return -0.00731732070489;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 47.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.184287024589;
                                    } else {
                                        return 0.0958477643955;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.0849943111284;
                                    } else {
                                        return 0.195780324961;
                                    }
                                }
                            } else {
                                return -0.355645695215;
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[25] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[50] <= -1558.5) {
                                        return 0.156758367828;
                                    } else {
                                        return -0.0140314189845;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.0708860807665;
                                    } else {
                                        return -0.0780483313149;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[2] <= 9.5) {
                                        return -0.0879819047747;
                                    } else {
                                        return 0.199327326622;
                                    }
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return 0.11318698287;
                                    } else {
                                        return -0.0979903483586;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 27.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0652886171474;
                                    } else {
                                        return -0.00415730516946;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.140898263406;
                                    } else {
                                        return 0.368054028993;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[88] <= 0.5) {
                                        return -0.183594945489;
                                    } else {
                                        return 0.140173264157;
                                    }
                                } else {
                                    if (fs[50] <= -1483.0) {
                                        return -0.140160084835;
                                    } else {
                                        return -0.0292699672765;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[95] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0571156611173;
                                    } else {
                                        return 0.0085637211555;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.00757315492811;
                                    } else {
                                        return -0.0142895365272;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0373811581266;
                                    } else {
                                        return -0.00716499014573;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.0328937590482;
                                    } else {
                                        return 0.515453340269;
                                    }
                                }
                            }
                        } else {
                            if (fs[54] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[4] <= 25.5) {
                                        return -0.0043759483;
                                    } else {
                                        return -0.0100167768481;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.00764282227527;
                                    } else {
                                        return -0.00688727845144;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    if (fs[50] <= -1007.0) {
                                        return 0.381330611711;
                                    } else {
                                        return 0.148930593101;
                                    }
                                } else {
                                    return -0.0409298197186;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0136612412488;
                                    } else {
                                        return 0.10230207951;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.000845441500605;
                                    } else {
                                        return 0.0273504312447;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.000102941589653;
                                    } else {
                                        return 0.0529978725728;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.193633522889;
                                    } else {
                                        return 0.0494632969382;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.00665466900556;
                                    } else {
                                        return -0.0042323971772;
                                    }
                                } else {
                                    if (fs[50] <= -3893.0) {
                                        return 0.0454082566326;
                                    } else {
                                        return -0.00634310151893;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[78] <= 0.5) {
                                        return -0.00562745838864;
                                    } else {
                                        return 0.000655744650331;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.00736617709929;
                                    } else {
                                        return -0.00704426319161;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[87] <= 0.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0763875568715;
                                    } else {
                                        return 0.224547387725;
                                    }
                                } else {
                                    if (fs[50] <= -1113.5) {
                                        return 0.0983545135286;
                                    } else {
                                        return 0.0287381613732;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.134951331077;
                                    } else {
                                        return -0.0152863625188;
                                    }
                                } else {
                                    return -0.17032198309;
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0112713767905;
                                    } else {
                                        return 0.0758107507196;
                                    }
                                } else {
                                    if (fs[4] <= 34.5) {
                                        return 0.111797738573;
                                    } else {
                                        return -0.307102857072;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0822904688607;
                                    } else {
                                        return 0.0200306016547;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.195608768843;
                                    } else {
                                        return 0.0790783374394;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 15.5) {
                            if (fs[95] <= 0.5) {
                                return -0.251198330868;
                            } else {
                                return -0.355041508523;
                            }
                        } else {
                            return -0.085765672737;
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[2] <= 7.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.00540501517207;
                                    } else {
                                        return 0.352884880558;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.321332308337;
                                    } else {
                                        return 0.0804644643593;
                                    }
                                }
                            } else {
                                if (fs[50] <= -731.5) {
                                    if (fs[69] <= 9995.5) {
                                        return 0.395681498041;
                                    } else {
                                        return 0.0253957913973;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.078763931265;
                                    } else {
                                        return -0.0142705098285;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[50] <= -1968.0) {
                                        return 0.273664850938;
                                    } else {
                                        return 0.0338044100697;
                                    }
                                } else {
                                    if (fs[89] <= 0.5) {
                                        return 0.0802766748876;
                                    } else {
                                        return 0.281083199711;
                                    }
                                }
                            } else {
                                return -0.218066343565;
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[0] <= 2.5) {
                                if (fs[67] <= -3.5) {
                                    if (fs[50] <= -1017.5) {
                                        return -0.138000588999;
                                    } else {
                                        return -0.0641599527302;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0652461239063;
                                    } else {
                                        return -0.00598145409529;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[4] <= 11.5) {
                                        return -0.0471136743319;
                                    } else {
                                        return -0.0222630788472;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.0346888381617;
                                    } else {
                                        return -0.0165864589179;
                                    }
                                }
                            }
                        } else {
                            if (fs[43] <= 0.5) {
                                if (fs[50] <= -1011.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.139968110469;
                                    } else {
                                        return -0.00556589106047;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.00928287395223;
                                    } else {
                                        return 0.101641407315;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[69] <= 9993.5) {
                                        return -0.0114161653002;
                                    } else {
                                        return -0.0160706363406;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.0143107215962;
                                    } else {
                                        return -0.0342474559775;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
