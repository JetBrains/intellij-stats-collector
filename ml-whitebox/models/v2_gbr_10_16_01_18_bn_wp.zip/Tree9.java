/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree9 {
    public double calcTree(double... fs) {
        if (fs[79] <= 0.5) {
            if (fs[50] <= -1083.5) {
                if (fs[39] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[4] <= 10.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.5365238007;
                                    } else {
                                        return 0.593271690366;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.663861219632;
                                    } else {
                                        return 0.602325108266;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[100] <= 0.5) {
                                        return 0.449963650704;
                                    } else {
                                        return 0.603329071299;
                                    }
                                } else {
                                    if (fs[69] <= 9851.0) {
                                        return 0.0639413212516;
                                    } else {
                                        return 0.552979418857;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 0.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[50] <= -1513.5) {
                                        return 0.513869553179;
                                    } else {
                                        return 0.320109359697;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.174858986567;
                                    } else {
                                        return 0.648176915418;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[69] <= 9980.0) {
                                        return 0.131792038817;
                                    } else {
                                        return 0.370518361212;
                                    }
                                } else {
                                    if (fs[52] <= -1.5) {
                                        return 0.438480339703;
                                    } else {
                                        return 0.59736443721;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[75] <= 0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 4.23979561782e-05;
                                    } else {
                                        return 0.342941176683;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return 0.394276773455;
                                    } else {
                                        return 0.0359026382679;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4847.0) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0495105259746;
                                    } else {
                                        return -0.0314267643304;
                                    }
                                } else {
                                    return 0.134049503538;
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0680140885283;
                                    } else {
                                        return 0.128645176986;
                                    }
                                } else {
                                    if (fs[46] <= -1.5) {
                                        return 0.499994585633;
                                    } else {
                                        return 0.00990425479229;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0154834877795;
                                    } else {
                                        return 0.0213861528377;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0311243116954;
                                    } else {
                                        return -0.0232254338212;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[97] <= 1.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[73] <= 100.0) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[4] <= 6.5) {
                                        return 0.363907215402;
                                    } else {
                                        return 0.115036795822;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.585323348483;
                                    } else {
                                        return 0.394274005088;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.538027863273;
                                    } else {
                                        return 0.417223073232;
                                    }
                                } else {
                                    return 0.142465620648;
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.107253566429;
                                    } else {
                                        return 0.0108868869266;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.00225248962452;
                                    } else {
                                        return -0.0267767303073;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0936101099462;
                                    } else {
                                        return 0.00719515265073;
                                    }
                                } else {
                                    if (fs[0] <= 47.5) {
                                        return 0.114803884353;
                                    } else {
                                        return 0.72221382339;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[61] <= -996.5) {
                                    if (fs[55] <= 0.5) {
                                        return 0.597797853421;
                                    } else {
                                        return 0.495136836699;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.54077344271;
                                    } else {
                                        return 0.396583281468;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.608795801987;
                                    } else {
                                        return 0.493563941857;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.375082066736;
                                    } else {
                                        return 0.150551225755;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 13.5) {
                                if (fs[61] <= -997.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.502272299506;
                                    } else {
                                        return 0.182183838049;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.150013973477;
                                    } else {
                                        return 0.0668637723687;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.379904238186;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.771181585359;
                                    } else {
                                        return 0.602351645711;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[11] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[61] <= -994.5) {
                            if (fs[46] <= -1.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.422198531913;
                                    } else {
                                        return 0.554039355661;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.523009765339;
                                    } else {
                                        return 0.673252972324;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[73] <= 100.0) {
                                        return 0.570476914997;
                                    } else {
                                        return 0.624038709321;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.416547733094;
                                    } else {
                                        return 0.639095611536;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9879.0) {
                                if (fs[75] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0379469913244;
                                    } else {
                                        return 0.6050426979;
                                    }
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return 0.306114379719;
                                    } else {
                                        return 0.40729068776;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.534109732479;
                                    } else {
                                        return 0.291800734801;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.351089751073;
                                    } else {
                                        return 0.571526951894;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 4.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0615970322134;
                                    } else {
                                        return 0.0122730074218;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.0777795114691;
                                    } else {
                                        return 7.40399887706e-05;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[89] <= 0.5) {
                                        return -0.0342496749284;
                                    } else {
                                        return -0.0456080575313;
                                    }
                                } else {
                                    return 0.18421370357;
                                }
                            }
                        } else {
                            if (fs[0] <= 8.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.135622768599;
                                    } else {
                                        return -0.0152010177548;
                                    }
                                } else {
                                    if (fs[46] <= -2.5) {
                                        return 0.0268098030276;
                                    } else {
                                        return -0.0365787471876;
                                    }
                                }
                            } else {
                                if (fs[75] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.00995310648359;
                                    } else {
                                        return 0.105471587063;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0294550392748;
                                    } else {
                                        return -0.0378547579966;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9995.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.355025435369;
                                    } else {
                                        return 0.131875458191;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.251002810349;
                                    } else {
                                        return 0.648881342696;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0550821748413;
                                    } else {
                                        return -0.0194944136006;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0351600092466;
                                    } else {
                                        return -0.0308360503811;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[69] <= 9978.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.364027716296;
                                    } else {
                                        return -0.012609415295;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.472728809153;
                                    } else {
                                        return 0.0544487069816;
                                    }
                                }
                            } else {
                                if (fs[59] <= -2.5) {
                                    return 0.12261980348;
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0320990949268;
                                    } else {
                                        return -0.0368695600325;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[82] <= 5.0) {
                                        return 0.312507592229;
                                    } else {
                                        return 0.503830979984;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0515568378353;
                                    } else {
                                        return 0.172482348177;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.338149769089;
                                    } else {
                                        return 0.470711128558;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.561212666815;
                                    } else {
                                        return 0.426747701607;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0626865523696;
                                    } else {
                                        return 0.192990080052;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0409118289907;
                                    } else {
                                        return -0.009973425892;
                                    }
                                }
                            } else {
                                if (fs[2] <= 8.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.028265166446;
                                    } else {
                                        return -0.0368244753687;
                                    }
                                } else {
                                    return 0.365472884586;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[69] <= 9971.5) {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[82] <= 6.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[43] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.142758741698;
                                    } else {
                                        return -0.0582125874323;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0222999510557;
                                    } else {
                                        return 0.426467509912;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[50] <= -1493.5) {
                                        return 0.515996023783;
                                    } else {
                                        return 0.17401430602;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.317998718732;
                                    } else {
                                        return 0.578065767707;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9296.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.562986996348;
                                    } else {
                                        return 0.200484537403;
                                    }
                                } else {
                                    return 0.629411152611;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.519359444769;
                                    } else {
                                        return 0.15147495788;
                                    }
                                } else {
                                    if (fs[69] <= 9810.5) {
                                        return 0.23674512358;
                                    } else {
                                        return 0.528612600636;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[84] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.112620443588;
                                    } else {
                                        return 0.398849704287;
                                    }
                                } else {
                                    if (fs[69] <= 9741.5) {
                                        return 0.00271709655408;
                                    } else {
                                        return 0.379598878747;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9339.0) {
                                    if (fs[4] <= 8.0) {
                                        return 0.478475485381;
                                    } else {
                                        return 0.654138778509;
                                    }
                                } else {
                                    return 0.01563358763;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.50847840593;
                                    } else {
                                        return 0.606797220891;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.578902691908;
                                    } else {
                                        return 0.409436144289;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.427149238101;
                                    } else {
                                        return 0.18429793291;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.0517017333059;
                                    } else {
                                        return 0.354474873523;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 8691.5) {
                        if (fs[82] <= 7.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.00882111373668;
                                    } else {
                                        return -0.0198181453501;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0367271165732;
                                    } else {
                                        return -0.0310521945825;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.203600736981;
                                    } else {
                                        return 0.367518460866;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0649987766198;
                                    } else {
                                        return 0.0124123279684;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.153743081085;
                                    } else {
                                        return -0.0531336957885;
                                    }
                                } else {
                                    if (fs[50] <= -1252.5) {
                                        return 0.0375238321588;
                                    } else {
                                        return -0.0402748310731;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.556358221152;
                                    } else {
                                        return 0.0470070361038;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0147847854535;
                                    } else {
                                        return 0.379691121335;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[50] <= -1413.5) {
                                        return 0.164902402266;
                                    } else {
                                        return 0.0284309058347;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.00349565920062;
                                    } else {
                                        return 0.240886455235;
                                    }
                                }
                            } else {
                                if (fs[69] <= 8973.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.601879389399;
                                    } else {
                                        return 0.730315075546;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return 0.0534399703599;
                                    } else {
                                        return 0.469840621414;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 6.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0148663538588;
                                    } else {
                                        return 0.0198270809938;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0307588578021;
                                    } else {
                                        return 0.383365956141;
                                    }
                                }
                            } else {
                                if (fs[0] <= 16.5) {
                                    if (fs[50] <= -1267.5) {
                                        return -0.00362035903627;
                                    } else {
                                        return -0.0295129551617;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0342495326732;
                                    } else {
                                        return -0.00872692112586;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[69] <= 9999.5) {
                        if (fs[37] <= 0.5) {
                            if (fs[50] <= -988.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.212983841592;
                                    } else {
                                        return 0.38035109761;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.361588600122;
                                    } else {
                                        return 0.564315830133;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.119192249878;
                                    } else {
                                        return -0.0949364114774;
                                    }
                                } else {
                                    return 0.0441053094325;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[69] <= 9991.5) {
                                        return 0.337493757069;
                                    } else {
                                        return 0.201403748006;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.497700124942;
                                    } else {
                                        return 0.328796091828;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[69] <= 9979.5) {
                                        return 0.68390993208;
                                    } else {
                                        return 0.569316992181;
                                    }
                                } else {
                                    return 0.458184352463;
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= -0.5) {
                            return -0.0850658903354;
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[82] <= 1.5) {
                                        return 0.373794999555;
                                    } else {
                                        return 0.503356783668;
                                    }
                                } else {
                                    if (fs[7] <= 0.5) {
                                        return 0.521182906861;
                                    } else {
                                        return 0.0958738793574;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.566678394629;
                                    } else {
                                        return 0.635145741889;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.336944643971;
                                    } else {
                                        return 0.545233563524;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1067.0) {
                        if (fs[82] <= 6.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[69] <= 9985.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.0437898685968;
                                    } else {
                                        return -0.0316710113798;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.131166078454;
                                    } else {
                                        return 0.0294443459208;
                                    }
                                }
                            } else {
                                if (fs[0] <= 21.5) {
                                    if (fs[63] <= 5.0) {
                                        return 0.370019699351;
                                    } else {
                                        return -0.130602065764;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.12540909118;
                                    } else {
                                        return -0.054656636;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 14.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.352802250154;
                                    } else {
                                        return 0.195352599769;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.430706331334;
                                    } else {
                                        return 0.783964371784;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9979.5) {
                                    return -0.0825959864404;
                                } else {
                                    return 0.117234641152;
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.155613253212;
                                    } else {
                                        return 0.655560209227;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.0931566203879;
                                    } else {
                                        return 0.291242192889;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9975.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.188978217513;
                                    } else {
                                        return 0.0470243115147;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0172409341637;
                                    } else {
                                        return -0.0346106990875;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 6.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0467505883457;
                                    } else {
                                        return -0.0237028800037;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.00608805221008;
                                    } else {
                                        return -0.0393443993487;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[4] <= 18.0) {
                                        return 0.133046870182;
                                    } else {
                                        return -0.0476812055101;
                                    }
                                } else {
                                    return 0.0921142504922;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
