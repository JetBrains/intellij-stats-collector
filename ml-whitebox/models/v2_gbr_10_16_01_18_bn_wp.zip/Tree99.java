/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree99 {
    public double calcTree(double... fs) {
        if (fs[54] <= 0.5) {
            if (fs[23] <= 0.5) {
                if (fs[61] <= -997.5) {
                    if (fs[8] <= 0.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[50] <= -2198.0) {
                                return -0.197916743261;
                            } else {
                                if (fs[50] <= -1458.0) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0238600911023;
                                    } else {
                                        return 0.143567539527;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0201457183237;
                                    } else {
                                        return -0.00161681467631;
                                    }
                                }
                            }
                        } else {
                            return -0.183295836406;
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            return -0.118472494124;
                        } else {
                            return -0.0203254831769;
                        }
                    }
                } else {
                    if (fs[75] <= 0.5) {
                        if (fs[4] <= 2.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0275150910851;
                                    } else {
                                        return 0.0701721232646;
                                    }
                                } else {
                                    return 0.0137082790276;
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    return 0.159304711253;
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.00649766221049;
                                    } else {
                                        return 0.156815264148;
                                    }
                                }
                            }
                        } else {
                            if (fs[39] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0102891327639;
                                    } else {
                                        return 0.000975398325182;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00242988391237;
                                    } else {
                                        return 0.032710461074;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0796737246171;
                                    } else {
                                        return 0.180398293928;
                                    }
                                } else {
                                    return -0.161753800886;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[27] <= 0.5) {
                                    if (fs[50] <= -5878.0) {
                                        return 0.117792607083;
                                    } else {
                                        return -0.000731861945028;
                                    }
                                } else {
                                    return 0.193910789307;
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    return 0.192164913031;
                                } else {
                                    if (fs[82] <= 2.5) {
                                        return 0.0274037102783;
                                    } else {
                                        return 0.11107069882;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[33] <= 0.5) {
                                        return -0.00783643744516;
                                    } else {
                                        return 0.0175061841889;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return 0.0164642740667;
                                    } else {
                                        return -0.0264947575085;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[52] <= 995.5) {
                                        return -0.00106023830585;
                                    } else {
                                        return 0.091942814547;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.00134338954582;
                                    } else {
                                        return 0.0160709555623;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 2.5) {
                    if (fs[50] <= 3.5) {
                        if (fs[69] <= 4692.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 15.0) {
                                    if (fs[68] <= 0.5) {
                                        return 0.149405672474;
                                    } else {
                                        return 0.124865460704;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0622092534464;
                                    } else {
                                        return 0.097322297317;
                                    }
                                }
                            } else {
                                return 0.148047480204;
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[49] <= 0.5) {
                                    return -0.164882370391;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0431035474379;
                                    } else {
                                        return 0.0317178432945;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.305830776594;
                                    } else {
                                        return 0.160687140541;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.101142309295;
                                    } else {
                                        return -0.0941926688401;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9913.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[57] <= 0.5) {
                                    return -0.0337418309523;
                                } else {
                                    return -0.0255698986798;
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[50] <= 7.5) {
                                        return -0.0146486964707;
                                    } else {
                                        return -0.0152592729684;
                                    }
                                } else {
                                    return -0.0135344151416;
                                }
                            }
                        } else {
                            return -0.0810359065084;
                        }
                    }
                } else {
                    if (fs[0] <= 10.5) {
                        if (fs[69] <= 9870.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[0] <= 5.5) {
                                    if (fs[50] <= 3.5) {
                                        return 0.041433122428;
                                    } else {
                                        return -0.00784334646011;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0263797356242;
                                    } else {
                                        return -0.0048695694562;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0109877306062;
                                    } else {
                                        return -0.00456977294165;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0130472188924;
                                    } else {
                                        return -0.0274134685687;
                                    }
                                }
                            }
                        } else {
                            return -0.0417802253434;
                        }
                    } else {
                        if (fs[4] <= 12.5) {
                            if (fs[50] <= 7.5) {
                                return -0.0182325442083;
                            } else {
                                return -0.00457508079741;
                            }
                        } else {
                            if (fs[50] <= 4.0) {
                                if (fs[0] <= 14.5) {
                                    return 0.205111053124;
                                } else {
                                    return 0.0440621489682;
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return -0.00183138608763;
                                } else {
                                    return -0.00125733383512;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[40] <= 0.5) {
                if (fs[18] <= 0.5) {
                    if (fs[69] <= 9990.5) {
                        if (fs[50] <= -461.0) {
                            if (fs[0] <= 4.5) {
                                if (fs[4] <= 7.5) {
                                    return 0.0457490006452;
                                } else {
                                    if (fs[46] <= -0.5) {
                                        return -0.145879512374;
                                    } else {
                                        return -0.0554492672273;
                                    }
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    return 0.0471127067569;
                                } else {
                                    return -0.0289738529682;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.0584659476093;
                                    } else {
                                        return 0.0179024093152;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0343744271092;
                                    } else {
                                        return 0.0233817355611;
                                    }
                                }
                            } else {
                                return 0.115490515806;
                            }
                        }
                    } else {
                        return -0.130645761296;
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[61] <= -995.0) {
                            if (fs[2] <= 2.5) {
                                if (fs[59] <= -2.5) {
                                    return -0.0533159928433;
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return 0.0731150277777;
                                    } else {
                                        return 0.0322101083031;
                                    }
                                }
                            } else {
                                if (fs[59] <= -1.5) {
                                    if (fs[73] <= 100.0) {
                                        return 0.0821653317716;
                                    } else {
                                        return 0.00729713254361;
                                    }
                                } else {
                                    return -0.0341737677893;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.0581848194442;
                                    } else {
                                        return 0.133689851822;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0413105504045;
                                    } else {
                                        return 0.211864176446;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.012024489812;
                                    } else {
                                        return -0.0860062816647;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.076611758686;
                                    } else {
                                        return 0.177430060208;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 150.0) {
                            return -0.0354874072443;
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 19.0) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0131341353258;
                                    } else {
                                        return -0.00321656702499;
                                    }
                                } else {
                                    return -0.0217125328099;
                                }
                            } else {
                                return -0.0227172646762;
                            }
                        }
                    }
                }
            } else {
                if (fs[99] <= 0.5) {
                    return -0.0939435259295;
                } else {
                    return -0.0846133667587;
                }
            }
        }
    }
}
