/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree53 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[40] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[50] <= -987.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.0236329822938;
                                    } else {
                                        return 0.0771282705726;
                                    }
                                } else {
                                    if (fs[64] <= 0.5) {
                                        return 0.205783684397;
                                    } else {
                                        return -0.276018303745;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.0363010478089;
                                    } else {
                                        return 0.0524520625453;
                                    }
                                } else {
                                    if (fs[50] <= -1478.5) {
                                        return 0.0604387276313;
                                    } else {
                                        return 0.217989391796;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0676714121141;
                                    } else {
                                        return 0.046417855426;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.038935902055;
                                    } else {
                                        return 0.0366419468356;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0655167026924;
                                    } else {
                                        return 0.227042699058;
                                    }
                                } else {
                                    if (fs[67] <= -4.5) {
                                        return 0.072752931914;
                                    } else {
                                        return 0.00593911875882;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 14.5) {
                            if (fs[69] <= 4692.5) {
                                if (fs[4] <= 9.5) {
                                    return 0.269929622529;
                                } else {
                                    return 0.498593263597;
                                }
                            } else {
                                if (fs[50] <= -546.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.155640938371;
                                    } else {
                                        return 0.261398845479;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.0976496942989;
                                    } else {
                                        return 0.149913978631;
                                    }
                                }
                            }
                        } else {
                            return -0.258273285869;
                        }
                    }
                } else {
                    if (fs[82] <= -0.5) {
                        if (fs[65] <= 1.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.106377026382;
                                    } else {
                                        return 0.19100579146;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.296821532461;
                                    } else {
                                        return -0.201490701477;
                                    }
                                }
                            } else {
                                return 0.224295757217;
                            }
                        } else {
                            return -0.300717761182;
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0794807154612;
                                    } else {
                                        return 0.0620921069015;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0177330365392;
                                    } else {
                                        return 0.0801820842981;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[95] <= 0.5) {
                                        return -0.107955134876;
                                    } else {
                                        return 0.0738088362108;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0940498998155;
                                    } else {
                                        return 0.0340144197699;
                                    }
                                }
                            }
                        } else {
                            if (fs[87] <= 0.5) {
                                if (fs[8] <= 0.5) {
                                    if (fs[2] <= 10.5) {
                                        return 0.074849581958;
                                    } else {
                                        return 0.165057330271;
                                    }
                                } else {
                                    if (fs[69] <= 4998.5) {
                                        return -0.280189355058;
                                    } else {
                                        return 0.0649526738376;
                                    }
                                }
                            } else {
                                return -0.162950133829;
                            }
                        }
                    }
                }
            } else {
                if (fs[73] <= 75.0) {
                    if (fs[68] <= 0.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                return -0.0345235769153;
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.106774854036;
                                    } else {
                                        return 0.0716490673319;
                                    }
                                } else {
                                    return 0.117447862787;
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[82] <= -0.5) {
                                    return 0.197973938155;
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return -0.0778885731347;
                                    } else {
                                        return -0.0020734620836;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    return 0.243877468526;
                                } else {
                                    return -0.0911420434264;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[18] <= 0.5) {
                                    if (fs[50] <= -481.5) {
                                        return -0.0296095158689;
                                    } else {
                                        return -0.257953708176;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.116390673025;
                                    } else {
                                        return 0.20839785687;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    return -0.0817227352948;
                                } else {
                                    return 0.170572392018;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[69] <= 9730.5) {
                                        return -0.174431083688;
                                    } else {
                                        return -0.314020502653;
                                    }
                                } else {
                                    return -0.357213280989;
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.0344150500074;
                                    } else {
                                        return -0.12865900802;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.249671938784;
                                    } else {
                                        return 0.042558488156;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[49] <= 0.5) {
                        if (fs[42] <= 0.5) {
                            if (fs[73] <= 350.0) {
                                if (fs[43] <= 0.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.0269905336938;
                                    } else {
                                        return -0.118985343751;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.0308955972569;
                                    } else {
                                        return 0.153040506834;
                                    }
                                }
                            } else {
                                return 0.180139723756;
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                return -0.335315206444;
                            } else {
                                if (fs[79] <= 0.5) {
                                    return -0.348570657801;
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.228884466144;
                                    } else {
                                        return 0.0324658211767;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 14.5) {
                            if (fs[50] <= -1448.0) {
                                if (fs[4] <= 3.5) {
                                    return -0.240097984389;
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0878490528476;
                                    } else {
                                        return 0.206790595679;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    return -0.252624405698;
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.20916966942;
                                    } else {
                                        return 0.00335652426778;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                return -0.166072778213;
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.125973591174;
                                } else {
                                    return 0.0311809643573;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[34] <= 0.5) {
                if (fs[0] <= 1.5) {
                    if (fs[82] <= -0.5) {
                        if (fs[39] <= 0.5) {
                            if (fs[69] <= 4983.0) {
                                if (fs[79] <= 0.5) {
                                    if (fs[50] <= -1128.0) {
                                        return -0.0349831712406;
                                    } else {
                                        return -0.0190673216871;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0418264784223;
                                    } else {
                                        return -0.0153597422397;
                                    }
                                }
                            } else {
                                return -0.0807259049892;
                            }
                        } else {
                            return 0.03726158666;
                        }
                    } else {
                        if (fs[4] <= 12.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0268699350379;
                                    } else {
                                        return -0.00339979284062;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.0151650318631;
                                    } else {
                                        return 0.04892516637;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[50] <= 7.5) {
                                        return -0.00781668899291;
                                    } else {
                                        return -0.0219229721955;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.035395162892;
                                    } else {
                                        return -0.0225275768855;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0149339241533;
                                    } else {
                                        return -0.084295210246;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return 0.218500466039;
                                    } else {
                                        return -0.0201124036859;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[69] <= 9997.5) {
                                        return -0.0115258532716;
                                    } else {
                                        return 0.021757023048;
                                    }
                                } else {
                                    if (fs[4] <= 24.5) {
                                        return 0.0328117522856;
                                    } else {
                                        return -0.0231759328987;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 3.5) {
                        if (fs[78] <= 0.5) {
                            if (fs[69] <= 9889.0) {
                                if (fs[73] <= 25.0) {
                                    if (fs[33] <= 0.5) {
                                        return -0.00758751784323;
                                    } else {
                                        return 0.0363990759764;
                                    }
                                } else {
                                    if (fs[50] <= -1063.0) {
                                        return 0.0633720471836;
                                    } else {
                                        return -0.0125156548759;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0386775185145;
                                    } else {
                                        return 0.0736269141572;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return 0.103719162395;
                                    } else {
                                        return -0.0232635098736;
                                    }
                                }
                            }
                        } else {
                            if (fs[75] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[50] <= -1063.0) {
                                        return 0.241761640839;
                                    } else {
                                        return -0.111567808177;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0869662102698;
                                    } else {
                                        return 0.00831170196093;
                                    }
                                }
                            } else {
                                if (fs[82] <= 3.5) {
                                    if (fs[97] <= 1.5) {
                                        return -0.00402051045876;
                                    } else {
                                        return 0.0418337223592;
                                    }
                                } else {
                                    if (fs[69] <= 9985.5) {
                                        return 0.0133906508849;
                                    } else {
                                        return 0.0614086895581;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0050460320747;
                                    } else {
                                        return -0.00306820136402;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.00787171756127;
                                    } else {
                                        return -0.00481649749961;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0444173235877;
                                    } else {
                                        return -0.0484546056797;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.022606963043;
                                    } else {
                                        return -0.012766969184;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.00264783283434;
                                    } else {
                                        return -0.0048593348007;
                                    }
                                } else {
                                    if (fs[82] <= 6.0) {
                                        return -0.00442939109129;
                                    } else {
                                        return 0.0125399128859;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0384604623767;
                                    } else {
                                        return 0.186412357995;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0178247140368;
                                    } else {
                                        return -0.00204751878525;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[4] <= 5.0) {
                        return 0.220635004843;
                    } else {
                        return 0.147512832684;
                    }
                } else {
                    return 0.282849059463;
                }
            }
        }
    }
}
