/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree91 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[54] <= 0.5) {
                if (fs[50] <= -1498.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[82] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[67] <= -1.5) {
                                    if (fs[4] <= 52.0) {
                                        return 0.0368182351204;
                                    } else {
                                        return -0.292503820668;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0292453682724;
                                    } else {
                                        return -0.225296299562;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1983.5) {
                                    return -0.041537393038;
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.222007102878;
                                    } else {
                                        return -0.0387896508;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 15.5) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.195218231521;
                                    } else {
                                        return -0.0287141485858;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.0665741234633;
                                    } else {
                                        return -0.193248851953;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[56] <= 0.5) {
                                        return -0.246026230413;
                                    } else {
                                        return -0.0461169442399;
                                    }
                                } else {
                                    return 0.0984692975445;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1618.0) {
                            if (fs[11] <= 0.5) {
                                if (fs[50] <= -2518.0) {
                                    return -0.0244311784131;
                                } else {
                                    if (fs[50] <= -1938.0) {
                                        return 0.165267559681;
                                    } else {
                                        return 0.075339304077;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[69] <= 4996.5) {
                                        return 0.157324577952;
                                    } else {
                                        return 0.101979988884;
                                    }
                                } else {
                                    if (fs[4] <= 23.0) {
                                        return 0.20750462939;
                                    } else {
                                        return 0.178605990885;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.0792579503624;
                                    } else {
                                        return 0.22927065954;
                                    }
                                } else {
                                    if (fs[50] <= -1608.0) {
                                        return 0.116833641735;
                                    } else {
                                        return -0.122011855966;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    return 0.0129295447402;
                                } else {
                                    return -0.157809182407;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 6.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[4] <= 15.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.00503145865305;
                                    } else {
                                        return -0.179157428374;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.0274898308111;
                                    } else {
                                        return 0.00188709151518;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0197122508524;
                                    } else {
                                        return -0.18326333937;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.0386750983226;
                                    } else {
                                        return 0.0966268965413;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 14.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[69] <= 9930.0) {
                                        return 0.137879173646;
                                    } else {
                                        return 0.0456786766247;
                                    }
                                } else {
                                    return 0.0851623730257;
                                }
                            } else {
                                return -0.179886354397;
                            }
                        }
                    } else {
                        if (fs[42] <= 0.5) {
                            if (fs[4] <= 31.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0402734268056;
                                    } else {
                                        return -0.0166642605056;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.0984128598537;
                                    } else {
                                        return 0.0578659013213;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    return 0.0194648670732;
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.165525571754;
                                    } else {
                                        return 0.380698991781;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 14.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.0898223143765;
                                    } else {
                                        return 0.118218246833;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.0898198108185;
                                    } else {
                                        return 0.0286024363492;
                                    }
                                }
                            } else {
                                return -0.316057339534;
                            }
                        }
                    }
                }
            } else {
                if (fs[18] <= 0.5) {
                    if (fs[82] <= 1.0) {
                        if (fs[61] <= -995.5) {
                            if (fs[97] <= 0.5) {
                                return 0.0200720932369;
                            } else {
                                return -0.0308824333495;
                            }
                        } else {
                            return 0.115381053015;
                        }
                    } else {
                        return -0.184872951978;
                    }
                } else {
                    if (fs[46] <= -0.5) {
                        if (fs[4] <= 7.5) {
                            return -0.0744457687448;
                        } else {
                            if (fs[4] <= 16.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.115666940676;
                                    } else {
                                        return 0.0695392812528;
                                    }
                                } else {
                                    return 0.0741208659151;
                                }
                            } else {
                                if (fs[2] <= 7.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0312461884643;
                                    } else {
                                        return 0.0785538644339;
                                    }
                                } else {
                                    return -0.0039167376115;
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    return 0.221240109562;
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.138398059346;
                                    } else {
                                        return -0.00536774136909;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.115261612348;
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0895198188517;
                                    } else {
                                        return 0.187095579106;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.262681909988;
                                    } else {
                                        return 0.206066130197;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0700873642028;
                                    } else {
                                        return 0.180915982988;
                                    }
                                }
                            } else {
                                return 0.0461703286224;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[4] <= 21.5) {
                if (fs[0] <= 1.5) {
                    if (fs[18] <= -0.5) {
                        if (fs[82] <= 7.5) {
                            if (fs[95] <= 0.5) {
                                return -0.0158666104346;
                            } else {
                                if (fs[50] <= -1488.0) {
                                    return -0.177615448397;
                                } else {
                                    return -0.104498913533;
                                }
                            }
                        } else {
                            return -0.256364627518;
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[67] <= -3.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0488852144773;
                                    } else {
                                        return 0.231191282741;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.00573912585879;
                                    } else {
                                        return 0.168947783703;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[89] <= 0.5) {
                                        return -0.00950978099941;
                                    } else {
                                        return 0.0321485978403;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.0922276475093;
                                    } else {
                                        return 0.118417137155;
                                    }
                                }
                            }
                        } else {
                            if (fs[63] <= 5.0) {
                                if (fs[99] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0112770633457;
                                    } else {
                                        return 0.292958631268;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0137588545672;
                                    } else {
                                        return -0.00715126544849;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9997.0) {
                                    return -0.139104888376;
                                } else {
                                    return -0.272831438898;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[14] <= 0.5) {
                        if (fs[2] <= 7.5) {
                            if (fs[59] <= -2.5) {
                                if (fs[50] <= -1077.0) {
                                    return 0.173500363909;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00793705090785;
                                    } else {
                                        return 0.112816144786;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.000990444052174;
                                    } else {
                                        return -7.85753823886e-05;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return 0.00989116169044;
                                    } else {
                                        return 0.369402500501;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[50] <= -1938.0) {
                                        return 0.0696851720774;
                                    } else {
                                        return -0.00509948376081;
                                    }
                                } else {
                                    if (fs[82] <= 3.5) {
                                        return 0.0185266429494;
                                    } else {
                                        return 0.144550453718;
                                    }
                                }
                            } else {
                                if (fs[73] <= 150.0) {
                                    if (fs[50] <= -1458.0) {
                                        return 0.00677431624598;
                                    } else {
                                        return -0.000895076747251;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.025250060102;
                                    } else {
                                        return -0.0130673578941;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9994.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[97] <= 1.5) {
                                    if (fs[4] <= 12.5) {
                                        return -0.0327418455814;
                                    } else {
                                        return 0.0125566733187;
                                    }
                                } else {
                                    return -0.1238012998;
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0457271610792;
                                    } else {
                                        return -0.0126310746685;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.00566693944877;
                                    } else {
                                        return 0.00784266314817;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[68] <= 0.5) {
                                    return 0.049143524572;
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0312872049512;
                                    } else {
                                        return 0.0281825689353;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    return -0.145320294391;
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.10481435818;
                                    } else {
                                        return -0.00868722981112;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[69] <= 9997.5) {
                    if (fs[77] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[50] <= -3233.0) {
                                return 0.270792483859;
                            } else {
                                if (fs[42] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return -0.0126147366095;
                                    } else {
                                        return 0.181805367853;
                                    }
                                } else {
                                    return 0.237842696953;
                                }
                            }
                        } else {
                            if (fs[0] <= 13.5) {
                                if (fs[59] <= -2.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0617964229707;
                                    } else {
                                        return 0.128214872568;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return -0.000750460045468;
                                    } else {
                                        return -0.00344995703418;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.00209329546278;
                                    } else {
                                        return 8.26529067993e-05;
                                    }
                                } else {
                                    if (fs[50] <= -1052.5) {
                                        return -0.00456033205441;
                                    } else {
                                        return -0.000311513843853;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 24.5) {
                                if (fs[4] <= 22.5) {
                                    return -0.0573775434882;
                                } else {
                                    if (fs[69] <= 4936.5) {
                                        return -0.0910937451119;
                                    } else {
                                        return -0.1377410232;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0663501346973;
                                    } else {
                                        return 0.000893170269866;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.00895672943607;
                                    } else {
                                        return 0.0716214148664;
                                    }
                                }
                            }
                        } else {
                            if (fs[86] <= 0.5) {
                                return 0.0676387938152;
                            } else {
                                if (fs[50] <= -1468.0) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0313730253219;
                                    } else {
                                        return -0.0814094831948;
                                    }
                                } else {
                                    if (fs[50] <= -1428.0) {
                                        return 0.0451296540021;
                                    } else {
                                        return -0.00366195912829;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[67] <= -4.5) {
                        if (fs[0] <= 1.5) {
                            return -0.179633428285;
                        } else {
                            return -0.0653943310952;
                        }
                    } else {
                        if (fs[2] <= 5.5) {
                            if (fs[50] <= -1928.0) {
                                if (fs[0] <= 2.5) {
                                    return -0.0188438218189;
                                } else {
                                    return 0.219054536358;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 26.5) {
                                        return -0.00664088214898;
                                    } else {
                                        return 0.0869396441092;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.0492493951773;
                                    } else {
                                        return -0.00562328482178;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[79] <= 0.5) {
                                    return 0.0496254213468;
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return 0.390615723875;
                                    } else {
                                        return 0.159081946432;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    return 0.103058362133;
                                } else {
                                    return -0.130699555997;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
