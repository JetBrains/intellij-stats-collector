/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree29 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 11.5) {
                if (fs[82] <= -0.5) {
                    if (fs[2] <= 4.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[50] <= -1473.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.181064705384;
                                    } else {
                                        return -0.147123664345;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.0669293859692;
                                    } else {
                                        return -0.117256777638;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.441476109866;
                                    } else {
                                        return -0.184644836845;
                                    }
                                } else {
                                    return -0.354058431873;
                                }
                            }
                        } else {
                            if (fs[4] <= 5.0) {
                                return 0.181813622497;
                            } else {
                                return 0.0494313593218;
                            }
                        }
                    } else {
                        return 0.301784170537;
                    }
                } else {
                    if (fs[50] <= -1043.0) {
                        if (fs[40] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[92] <= 0.5) {
                                        return 0.200268504104;
                                    } else {
                                        return 0.272329544417;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.131007182604;
                                    } else {
                                        return 0.214885942487;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[50] <= -1143.5) {
                                        return -0.0474885586163;
                                    } else {
                                        return 0.0471971750183;
                                    }
                                } else {
                                    if (fs[69] <= 9902.0) {
                                        return 0.0097724520586;
                                    } else {
                                        return 0.21260446719;
                                    }
                                }
                            }
                        } else {
                            if (fs[75] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.276663541194;
                                    } else {
                                        return 0.230986306652;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.0470346565805;
                                    } else {
                                        return -0.0311193311626;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[50] <= -1488.5) {
                                        return 0.0111764939067;
                                    } else {
                                        return -0.0770396137708;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.198339666282;
                                    } else {
                                        return 0.0457437991465;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[6] <= 0.5) {
                                    if (fs[100] <= 0.5) {
                                        return -0.103267820783;
                                    } else {
                                        return 0.205269543284;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.239532617931;
                                    } else {
                                        return -0.204574948946;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.212905041933;
                                    } else {
                                        return 0.0371528440881;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.149918991864;
                                    } else {
                                        return 0.204268112823;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[50] <= -446.5) {
                                        return -0.180169588685;
                                    } else {
                                        return -0.00762322960913;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0735917423678;
                                    } else {
                                        return 0.210908462751;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    return -0.0365081809139;
                                } else {
                                    if (fs[4] <= 8.0) {
                                        return 0.37044561481;
                                    } else {
                                        return 0.181037371589;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -2003.5) {
                    if (fs[67] <= -1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[50] <= -2358.5) {
                                if (fs[50] <= -2423.0) {
                                    if (fs[50] <= -9088.5) {
                                        return 0.416670373416;
                                    } else {
                                        return 0.212458162443;
                                    }
                                } else {
                                    return -0.0525061610446;
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    return 0.261524353031;
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.407234084194;
                                    } else {
                                        return 0.355915964911;
                                    }
                                }
                            }
                        } else {
                            if (fs[77] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.428754282505;
                                    } else {
                                        return 0.328310447246;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.395913966986;
                                    } else {
                                        return -0.265772530281;
                                    }
                                }
                            } else {
                                return 0.181700274172;
                            }
                        }
                    } else {
                        return 0.00915513306048;
                    }
                } else {
                    if (fs[73] <= 250.0) {
                        if (fs[2] <= 5.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.254419531887;
                                    } else {
                                        return 0.154783205532;
                                    }
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return 0.25461908903;
                                    } else {
                                        return 0.0576216046692;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[69] <= 9845.5) {
                                        return 0.00152601611875;
                                    } else {
                                        return 0.10980296392;
                                    }
                                } else {
                                    if (fs[67] <= -3.5) {
                                        return 0.26635324786;
                                    } else {
                                        return -0.0797079831605;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.344833230249;
                                    } else {
                                        return 0.252806026094;
                                    }
                                } else {
                                    if (fs[2] <= 9.5) {
                                        return 0.0957210709319;
                                    } else {
                                        return 0.283276124534;
                                    }
                                }
                            } else {
                                return -0.18024644567;
                            }
                        }
                    } else {
                        if (fs[4] <= 27.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.107516387369;
                                    } else {
                                        return 0.159821564435;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.228765288927;
                                    } else {
                                        return 0.0685220067958;
                                    }
                                }
                            } else {
                                if (fs[46] <= -3.5) {
                                    return -0.186577474137;
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.206682708372;
                                    } else {
                                        return 0.109878661133;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= -2.5) {
                                return 0.244644201233;
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[77] <= 0.5) {
                                        return -0.0708799237996;
                                    } else {
                                        return -0.213810936301;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.156671740106;
                                    } else {
                                        return -0.102138180295;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[95] <= 0.5) {
                if (fs[4] <= 7.5) {
                    if (fs[73] <= 75.0) {
                        if (fs[4] <= 3.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[69] <= 9993.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.0164633744774;
                                    } else {
                                        return 0.020105512177;
                                    }
                                } else {
                                    if (fs[100] <= 0.5) {
                                        return -0.0639060862151;
                                    } else {
                                        return 0.0848449014266;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1058.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.0571801830447;
                                    } else {
                                        return 0.0202039644772;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.0023045703212;
                                    } else {
                                        return 0.0386604956613;
                                    }
                                }
                            }
                        } else {
                            if (fs[75] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[50] <= -1053.0) {
                                        return 0.160947935666;
                                    } else {
                                        return -0.0628595986334;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00115043790547;
                                    } else {
                                        return 0.175444028649;
                                    }
                                }
                            } else {
                                if (fs[82] <= 1.5) {
                                    if (fs[69] <= 9995.5) {
                                        return -0.0127478449672;
                                    } else {
                                        return 0.047845549529;
                                    }
                                } else {
                                    if (fs[69] <= 9996.5) {
                                        return -0.00643239764479;
                                    } else {
                                        return 0.0315429870353;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1448.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[82] <= 5.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.136442175665;
                                    } else {
                                        return 0.0352711798416;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00224663747192;
                                    } else {
                                        return 0.108321155486;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.189205171882;
                                    } else {
                                        return -0.0536303288276;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0891563593123;
                                    } else {
                                        return 0.278390759499;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[0] <= 10.5) {
                                    if (fs[69] <= 9775.5) {
                                        return -0.0167432782952;
                                    } else {
                                        return 0.0678183417145;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0215655724511;
                                    } else {
                                        return 0.00068568971707;
                                    }
                                }
                            } else {
                                if (fs[50] <= -992.0) {
                                    if (fs[40] <= 0.5) {
                                        return -0.0293640027358;
                                    } else {
                                        return 0.0861067259566;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0381618034052;
                                    } else {
                                        return -0.0195913802541;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 3.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.00326250643722;
                                    } else {
                                        return -0.0259298271452;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.0216786349999;
                                    } else {
                                        return 0.00627996559427;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[50] <= -1478.0) {
                                        return 0.078620923925;
                                    } else {
                                        return 0.0187666288315;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.00714486811311;
                                    } else {
                                        return 0.0220165045672;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[69] <= 9995.5) {
                                        return 0.0417149247698;
                                    } else {
                                        return 0.105280756037;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.00686251881902;
                                    } else {
                                        return 0.0610175319646;
                                    }
                                }
                            } else {
                                if (fs[82] <= 2.5) {
                                    if (fs[4] <= 21.5) {
                                        return 0.0138905922745;
                                    } else {
                                        return -0.0342955345687;
                                    }
                                } else {
                                    if (fs[50] <= -1513.0) {
                                        return 0.155446759438;
                                    } else {
                                        return -0.0186379063553;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[69] <= 9944.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0137150446971;
                                    } else {
                                        return -0.0122700959402;
                                    }
                                } else {
                                    if (fs[50] <= -1428.0) {
                                        return 0.0352491085602;
                                    } else {
                                        return -0.0088377727284;
                                    }
                                }
                            } else {
                                if (fs[67] <= -4.0) {
                                    return -0.0587967563492;
                                } else {
                                    if (fs[50] <= -495.5) {
                                        return -0.0329950943069;
                                    } else {
                                        return 0.232666003183;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[57] <= 0.5) {
                                        return -0.013690926407;
                                    } else {
                                        return -0.0120248639673;
                                    }
                                } else {
                                    if (fs[69] <= 9172.5) {
                                        return -0.00662356194189;
                                    } else {
                                        return 0.0389766713219;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.015985153188;
                                    } else {
                                        return -0.00784533534945;
                                    }
                                } else {
                                    return 0.178032983425;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[12] <= 0.5) {
                    if (fs[49] <= 0.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[59] <= -1.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.00134926193296;
                                    } else {
                                        return 0.0814728451172;
                                    }
                                } else {
                                    if (fs[61] <= -996.5) {
                                        return 0.504962702851;
                                    } else {
                                        return 0.00372728652114;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0273267169033;
                                    } else {
                                        return -0.0148660757424;
                                    }
                                } else {
                                    if (fs[50] <= -1118.0) {
                                        return 0.119192521922;
                                    } else {
                                        return -0.0139545626564;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.138787909986;
                                    } else {
                                        return 0.0305821115632;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.150834134922;
                                    } else {
                                        return -0.00624949752396;
                                    }
                                }
                            } else {
                                if (fs[4] <= 25.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.342255169621;
                                    } else {
                                        return 0.665475512909;
                                    }
                                } else {
                                    return -0.0780923692506;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[50] <= -1468.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.104784353386;
                                    } else {
                                        return -0.11644886749;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0585699835634;
                                    } else {
                                        return 0.0245095806047;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1.0) {
                                    if (fs[52] <= 496.5) {
                                        return -0.00724220394781;
                                    } else {
                                        return 0.306315560245;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.108899056141;
                                    } else {
                                        return 0.00633179154157;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.0145475079848;
                                    } else {
                                        return -0.00347063072539;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.325426637435;
                                    } else {
                                        return -0.017563065961;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.00450737216834;
                                    } else {
                                        return -0.014321605086;
                                    }
                                } else {
                                    if (fs[0] <= 10.5) {
                                        return -0.0109157130092;
                                    } else {
                                        return -0.0146968905351;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[50] <= -1398.0) {
                            if (fs[61] <= -996.5) {
                                if (fs[50] <= -1803.0) {
                                    return 0.122973828814;
                                } else {
                                    return 0.552576270489;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0876950977254;
                                    } else {
                                        return -0.0330474029121;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.172983764868;
                                    } else {
                                        return 0.0951179225155;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[50] <= -21.0) {
                                    if (fs[69] <= 9997.5) {
                                        return -0.0866886784048;
                                    } else {
                                        return 0.119822624949;
                                    }
                                } else {
                                    if (fs[69] <= 9585.0) {
                                        return 0.142702444147;
                                    } else {
                                        return -0.0458404982741;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 23.5) {
                                        return 0.0455480254348;
                                    } else {
                                        return -0.0175783763348;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return -0.0166078976703;
                                    } else {
                                        return 0.0291345991878;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[0] <= 7.5) {
                                if (fs[59] <= -2.5) {
                                    return 0.267844683704;
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0280095844818;
                                    } else {
                                        return 0.00319401699366;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.254811849673;
                                    } else {
                                        return -0.00937481003988;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.422921594826;
                                    } else {
                                        return 0.10428714681;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[59] <= -2.5) {
                                    return 0.0309687130904;
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0121827284394;
                                    } else {
                                        return 0.00232227762789;
                                    }
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0251244080663;
                                    } else {
                                        return -0.0173465733855;
                                    }
                                } else {
                                    if (fs[61] <= -996.5) {
                                        return -0.0213528130532;
                                    } else {
                                        return -0.0154585830248;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
