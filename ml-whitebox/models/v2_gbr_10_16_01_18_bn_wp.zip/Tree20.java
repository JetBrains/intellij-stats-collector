/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree20 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9985.5) {
            if (fs[73] <= 250.0) {
                if (fs[15] <= 0.5) {
                    if (fs[25] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.306762449849;
                                    } else {
                                        return 0.347528602013;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.027268714271;
                                    } else {
                                        return -0.171308589339;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.171913568407;
                                    } else {
                                        return -0.0297164104984;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.227357918642;
                                    } else {
                                        return 0.330381437411;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.0219287554588;
                                    } else {
                                        return 0.401332910579;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.00709896430114;
                                    } else {
                                        return -0.0159072658081;
                                    }
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.00813358386989;
                                    } else {
                                        return -0.0241409787246;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return -0.0192076842078;
                                    } else {
                                        return 0.0788666823491;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[50] <= -1063.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0899753231642;
                                    } else {
                                        return 0.31265542664;
                                    }
                                } else {
                                    if (fs[50] <= -1679.0) {
                                        return 0.478515215085;
                                    } else {
                                        return 0.28238213238;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[50] <= -858.0) {
                                        return -0.169363712316;
                                    } else {
                                        return 0.0101437905854;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.0191584221396;
                                    } else {
                                        return 0.414734740676;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00387743123041;
                                    } else {
                                        return 0.15434798485;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0169251017762;
                                    } else {
                                        return -0.0210593520887;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0324459175903;
                                    } else {
                                        return 0.0519709033658;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.00372084394418;
                                    } else {
                                        return 0.423721676476;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[33] <= 0.5) {
                        if (fs[50] <= -1118.5) {
                            if (fs[2] <= 1.5) {
                                return 0.350895844743;
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.346895103537;
                                    } else {
                                        return 0.339105432808;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.342370987168;
                                    } else {
                                        return 0.336931242806;
                                    }
                                }
                            }
                        } else {
                            return 0.313884615545;
                        }
                    } else {
                        return 0.236419439393;
                    }
                }
            } else {
                if (fs[12] <= 0.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[97] <= 1.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00523276796807;
                                    } else {
                                        return 0.241842293064;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0362202735472;
                                    } else {
                                        return 0.0230551726907;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.16111550945;
                                    } else {
                                        return 0.297720692355;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.00175346780525;
                                    } else {
                                        return -0.0237323803344;
                                    }
                                }
                            }
                        } else {
                            if (fs[39] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.288617271492;
                                    } else {
                                        return -0.248172003172;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.281666204894;
                                    } else {
                                        return -0.0351806017261;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.178068840446;
                                    } else {
                                        return 0.28932446476;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0930756150437;
                                    } else {
                                        return 0.0332716566263;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[46] <= -2.5) {
                            if (fs[50] <= -931.5) {
                                return -0.045254175693;
                            } else {
                                return 0.137528953149;
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[50] <= -476.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.163260431484;
                                    } else {
                                        return 0.312637991872;
                                    }
                                } else {
                                    return -0.0776862000785;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[14] <= 0.5) {
                                        return -0.0312164184946;
                                    } else {
                                        return 0.00712670437181;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.0222744868312;
                                    } else {
                                        return -0.0206423038256;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[59] <= -3.5) {
                            if (fs[39] <= 0.5) {
                                return 0.127912538315;
                            } else {
                                return -0.10898579202;
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.345693568646;
                                    } else {
                                        return 0.321251148643;
                                    }
                                } else {
                                    if (fs[50] <= -1063.0) {
                                        return 0.211782944667;
                                    } else {
                                        return 0.445543406294;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return 0.40767391463;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.00443522341991;
                                    } else {
                                        return 0.203516519664;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1068.0) {
                            if (fs[97] <= 1.5) {
                                if (fs[50] <= -1468.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.224652469385;
                                    } else {
                                        return 0.0846231843584;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.237982116828;
                                    } else {
                                        return -0.00214030875118;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0746886287707;
                                    } else {
                                        return -0.00379607021566;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0659508062813;
                                    } else {
                                        return 0.239284803277;
                                    }
                                }
                            }
                        } else {
                            if (fs[67] <= -4.5) {
                                if (fs[0] <= 2.5) {
                                    return 0.0749996868719;
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.040209499785;
                                    } else {
                                        return -0.0379484070098;
                                    }
                                }
                            } else {
                                if (fs[46] <= -1.5) {
                                    if (fs[50] <= 3.5) {
                                        return 0.0157913739062;
                                    } else {
                                        return -0.0305119755471;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0246976675858;
                                    } else {
                                        return -0.0180225932814;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[2] <= 1.5) {
                if (fs[50] <= -1047.5) {
                    if (fs[69] <= 9998.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[50] <= -1473.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.437580874865;
                                    } else {
                                        return 0.0682679533643;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.357037828444;
                                    } else {
                                        return 0.110402596314;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.535705129503;
                                    } else {
                                        return 0.342665873497;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.278510973219;
                                    } else {
                                        return -0.0621576843048;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0794689890999;
                                    } else {
                                        return 0.0288571329348;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return -0.00161293232704;
                                    } else {
                                        return 0.118594739083;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0137485766548;
                                    } else {
                                        return -0.0155115716517;
                                    }
                                } else {
                                    return 0.245491851164;
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.302870784728;
                                    } else {
                                        return -0.0581082949249;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.18296643606;
                                    } else {
                                        return 0.0967879869157;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[73] <= 150.0) {
                                        return 0.277910201606;
                                    } else {
                                        return 0.218211694843;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0379899911055;
                                    } else {
                                        return 0.145440939104;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 8.5) {
                                        return 0.262658886181;
                                    } else {
                                        return 0.0271914866759;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.12295314993;
                                    } else {
                                        return -0.0625017099802;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1128.5) {
                                    return 0.490415941269;
                                } else {
                                    return 0.340809453207;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[61] <= -498.0) {
                                if (fs[82] <= 1.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.390711935001;
                                    } else {
                                        return 0.301290092488;
                                    }
                                } else {
                                    return 0.457932632195;
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.242735809455;
                                    } else {
                                        return 0.0887694817272;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.0501358651852;
                                    } else {
                                        return 0.258903478493;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0580124818565;
                                    } else {
                                        return -0.0289844081752;
                                    }
                                } else {
                                    return -0.0746672546587;
                                }
                            } else {
                                if (fs[50] <= -477.0) {
                                    if (fs[73] <= 25.0) {
                                        return 0.19371351952;
                                    } else {
                                        return 0.00482616523266;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0206363310977;
                                    } else {
                                        return 0.0208535403433;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9999.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[67] <= -3.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.283427338102;
                                    } else {
                                        return 0.102526990664;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return 0.0253132373397;
                                    } else {
                                        return 0.184543236485;
                                    }
                                }
                            } else {
                                if (fs[67] <= -3.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.322734190348;
                                    } else {
                                        return 0.071264627441;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0300677124306;
                                    } else {
                                        return -0.00379214532333;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 250.0) {
                                if (fs[37] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0769111047947;
                                    } else {
                                        return -0.0156571217648;
                                    }
                                } else {
                                    return 0.277368650047;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.0114464708477;
                                    } else {
                                        return 0.0883005809549;
                                    }
                                } else {
                                    if (fs[50] <= 3.5) {
                                        return -0.0311442719198;
                                    } else {
                                        return -0.0230771165871;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 8.5) {
                        if (fs[95] <= 1.5) {
                            if (fs[77] <= 0.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.337063378461;
                                    } else {
                                        return 0.380744020962;
                                    }
                                } else {
                                    return 0.0339198620149;
                                }
                            } else {
                                return -0.151209009827;
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[7] <= 0.5) {
                                    if (fs[42] <= 0.5) {
                                        return 0.352334444233;
                                    } else {
                                        return 0.044829780284;
                                    }
                                } else {
                                    return -0.174872884786;
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.401369088102;
                                    } else {
                                        return 0.247004362504;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0671505296455;
                                    } else {
                                        return 0.293019926958;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 5.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[50] <= -2423.0) {
                                    if (fs[69] <= 9996.5) {
                                        return 0.39978971839;
                                    } else {
                                        return 0.509257336941;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.255911126447;
                                    } else {
                                        return -0.174441923765;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.171144680925;
                                    } else {
                                        return 0.274745405487;
                                    }
                                } else {
                                    if (fs[61] <= -498.0) {
                                        return 0.364310087017;
                                    } else {
                                        return 0.0701002651614;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 14.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.383644115672;
                                    } else {
                                        return 0.325731384803;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.314365254513;
                                    } else {
                                        return -0.0330432524237;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0226979095574;
                                    } else {
                                        return 0.316480063063;
                                    }
                                } else {
                                    if (fs[69] <= 9996.5) {
                                        return 0.0936637012144;
                                    } else {
                                        return 0.320022569775;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[71] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[50] <= -1418.0) {
                                if (fs[82] <= 6.5) {
                                    if (fs[82] <= 3.5) {
                                        return 0.12418576917;
                                    } else {
                                        return -0.0510564203496;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.338450551971;
                                    } else {
                                        return -0.0392188059392;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.120770098041;
                                    } else {
                                        return 0.0487470432108;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.00136905831091;
                                    } else {
                                        return 0.349794963069;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= 17.5) {
                                if (fs[76] <= 0.5) {
                                    if (fs[62] <= 0.5) {
                                        return -0.0240228229856;
                                    } else {
                                        return 0.0451384349384;
                                    }
                                } else {
                                    return -0.0805783931573;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.144111495959;
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.0257820245667;
                                    } else {
                                        return -1.89505043107e-05;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[0] <= 4.5) {
                                return 0.539988349289;
                            } else {
                                if (fs[0] <= 6.5) {
                                    return 0.361046770033;
                                } else {
                                    return 0.184033048005;
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[0] <= 9.0) {
                                    if (fs[2] <= 2.5) {
                                        return 0.127160679376;
                                    } else {
                                        return 0.406645126203;
                                    }
                                } else {
                                    return 0.0504087526575;
                                }
                            } else {
                                return 0.101736258381;
                            }
                        }
                    }
                }
            }
        }
    }
}
