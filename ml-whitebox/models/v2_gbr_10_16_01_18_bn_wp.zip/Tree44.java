/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree44 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[0] <= 0.5) {
                if (fs[40] <= 0.5) {
                    if (fs[82] <= -0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[50] <= -1138.0) {
                                return -0.0829469652593;
                            } else {
                                return 0.13711125052;
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[67] <= -4.0) {
                                    return -0.397582135175;
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.141226471937;
                                    } else {
                                        return -0.334088661347;
                                    }
                                }
                            } else {
                                return 0.196909400818;
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[50] <= -880.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0873683511511;
                                    } else {
                                        return -0.0543480131808;
                                    }
                                } else {
                                    if (fs[61] <= -996.5) {
                                        return 0.125018167297;
                                    } else {
                                        return -0.000268360528866;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.106128618016;
                                    } else {
                                        return -0.16943396846;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.419981781268;
                                    } else {
                                        return -0.143948581989;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[50] <= -1027.0) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0121664798373;
                                    } else {
                                        return 0.080711042279;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.0607492895665;
                                    } else {
                                        return -0.175851677656;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[69] <= 9296.5) {
                                        return 0.153700970324;
                                    } else {
                                        return 0.106617336107;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.028917297752;
                                    } else {
                                        return 0.168418175529;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[68] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[73] <= 25.0) {
                                return 0.0237909753332;
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.123867911943;
                                    } else {
                                        return 0.340730907133;
                                    }
                                } else {
                                    return 0.363717131048;
                                }
                            }
                        } else {
                            if (fs[82] <= 2.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.141695234232;
                                    } else {
                                        return -0.111360410673;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.0278192361773;
                                    } else {
                                        return 0.253978928279;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    return -0.0177617575305;
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0443291080655;
                                    } else {
                                        return 0.230998121102;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[50] <= -1488.5) {
                                        return -0.351794690845;
                                    } else {
                                        return -0.225584179373;
                                    }
                                } else {
                                    if (fs[69] <= 9920.0) {
                                        return -0.118136055032;
                                    } else {
                                        return -0.20694365132;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0658200071612;
                                    } else {
                                        return -0.276170135461;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0278870116194;
                                    } else {
                                        return -0.0679099651382;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[86] <= 0.5) {
                                    return 0.161830687198;
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.055876556507;
                                    } else {
                                        return -0.2433772102;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.00496607837691;
                                    } else {
                                        return 0.237067691947;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.297222109145;
                                    } else {
                                        return -0.102697547882;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[34] <= 0.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[50] <= -1478.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0286033394338;
                                    } else {
                                        return 0.246999366061;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.0018891269139;
                                    } else {
                                        return -0.0275156140778;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[82] <= 7.5) {
                                        return 0.0241771600772;
                                    } else {
                                        return -0.120054626663;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0307122013423;
                                    } else {
                                        return 0.13817743833;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 19.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0168051623897;
                                    } else {
                                        return -0.0101421444508;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return -0.0187342672806;
                                    } else {
                                        return 0.207769573696;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    if (fs[50] <= -921.5) {
                                        return -0.0184773397223;
                                    } else {
                                        return 0.0147552602059;
                                    }
                                } else {
                                    if (fs[50] <= -1458.0) {
                                        return 0.0204175919926;
                                    } else {
                                        return -0.0358198953986;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 18.5) {
                            if (fs[0] <= 7.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.00323536547303;
                                    } else {
                                        return -0.0088825889566;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.00842704036207;
                                    } else {
                                        return 0.00591935999525;
                                    }
                                }
                            } else {
                                if (fs[50] <= 3.5) {
                                    if (fs[46] <= -2.5) {
                                        return 0.278653176459;
                                    } else {
                                        return -0.00583727263627;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.0080318630773;
                                    } else {
                                        return -0.00647018963431;
                                    }
                                }
                            }
                        } else {
                            if (fs[28] <= 0.5) {
                                if (fs[61] <= -996.5) {
                                    if (fs[46] <= -2.5) {
                                        return 0.237705431317;
                                    } else {
                                        return 0.0115991969132;
                                    }
                                } else {
                                    if (fs[50] <= -1383.5) {
                                        return -0.00655947571446;
                                    } else {
                                        return -0.00772768042586;
                                    }
                                }
                            } else {
                                if (fs[4] <= 22.5) {
                                    if (fs[0] <= 34.5) {
                                        return 0.0205968333452;
                                    } else {
                                        return 0.298151959871;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0101635612424;
                                    } else {
                                        return 0.0139213295253;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1138.0) {
                        if (fs[4] <= 5.0) {
                            return 0.299858282069;
                        } else {
                            return -0.00741678687682;
                        }
                    } else {
                        return 0.248745853571;
                    }
                }
            }
        } else {
            if (fs[50] <= -1052.5) {
                if (fs[0] <= 0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[87] <= 0.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.114679249929;
                                    } else {
                                        return 0.16219555089;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.163167436828;
                                    } else {
                                        return 0.387985678896;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[42] <= 0.5) {
                                        return 0.0947201790637;
                                    } else {
                                        return -0.361877374735;
                                    }
                                } else {
                                    if (fs[73] <= 350.0) {
                                        return -0.0300963405846;
                                    } else {
                                        return 0.211071326533;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 15.5) {
                                return -0.311570023885;
                            } else {
                                return -0.0913748595339;
                            }
                        }
                    } else {
                        if (fs[95] <= 1.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.105226254539;
                                    } else {
                                        return 0.156296310416;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.101538814634;
                                    } else {
                                        return 0.241511357886;
                                    }
                                }
                            } else {
                                if (fs[4] <= 20.5) {
                                    return -0.396758154841;
                                } else {
                                    return 0.139665213221;
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.159906732891;
                                    } else {
                                        return -0.178814310279;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.245267887045;
                                    } else {
                                        return 0.00374207845641;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    return 0.304123130911;
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.0997816046371;
                                    } else {
                                        return 0.0998426193095;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[52] <= 0.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[63] <= 5.0) {
                                    if (fs[0] <= 6.5) {
                                        return 0.087167505366;
                                    } else {
                                        return -0.0473447170914;
                                    }
                                } else {
                                    return -0.231074501035;
                                }
                            } else {
                                if (fs[50] <= -1137.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0683585822729;
                                    } else {
                                        return 0.0170800037371;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0398334272957;
                                    } else {
                                        return 0.164126535547;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -2238.0) {
                                        return 0.303741319424;
                                    } else {
                                        return 0.0192369768672;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return 0.0616680706189;
                                    } else {
                                        return 0.203534047383;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.0) {
                                    if (fs[73] <= 25.0) {
                                        return 0.0121657663023;
                                    } else {
                                        return 0.273578487675;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.327252732292;
                                    } else {
                                        return 0.559540738697;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.363338502848;
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 4.5) {
                        if (fs[82] <= 6.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.165733613785;
                                    } else {
                                        return -0.0388438205455;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0323239129304;
                                    } else {
                                        return 0.124911851896;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.175033782663;
                                    } else {
                                        return 0.213698700032;
                                    }
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return 0.279481504235;
                                    } else {
                                        return 0.170867478467;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.335634235773;
                                    } else {
                                        return 0.0207108642426;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0871827187906;
                                    } else {
                                        return 0.089744817952;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.231384787155;
                                    } else {
                                        return 0.158165492033;
                                    }
                                } else {
                                    return -0.00596391608763;
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[67] <= -4.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.147497893085;
                                    } else {
                                        return 0.250815530986;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.130431620682;
                                    } else {
                                        return -0.0667404951989;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[54] <= 0.5) {
                                        return -0.00135636990312;
                                    } else {
                                        return 0.371829662341;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.117907982323;
                                    } else {
                                        return -0.0335168805425;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.0826149561013;
                                    } else {
                                        return 0.166089885119;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.107415598039;
                                    } else {
                                        return -0.0535166313293;
                                    }
                                }
                            } else {
                                if (fs[61] <= -997.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.214234959295;
                                    } else {
                                        return 0.169373378225;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.0398537736235;
                                    } else {
                                        return -0.0146204016157;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 3.5) {
                        if (fs[91] <= 0.5) {
                            if (fs[6] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[92] <= 0.5) {
                                        return 0.0534637926141;
                                    } else {
                                        return -0.0641403712621;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.18505703329;
                                    } else {
                                        return -0.108374469648;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.00557933910916;
                                    } else {
                                        return 0.122039164679;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0299345220315;
                                    } else {
                                        return 0.0141362070606;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[50] <= 3.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0404925797185;
                                    } else {
                                        return -0.0121287714355;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0106066259404;
                                    } else {
                                        return 0.012428886161;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    return 0.24323007404;
                                } else {
                                    return 0.112271272958;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 6.5) {
                            if (fs[0] <= 4.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.166732816411;
                                    } else {
                                        return 0.26915352773;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.172607682641;
                                    } else {
                                        return 0.0346358471455;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return 0.055448743521;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00739361664056;
                                    } else {
                                        return -0.0788245266487;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0424612576619;
                                    } else {
                                        return -0.0310387545715;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0232259242409;
                                    } else {
                                        return 0.333788043505;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.232973390581;
                                    } else {
                                        return -0.0366069116885;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0688930656817;
                                    } else {
                                        return -0.00860872339676;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
