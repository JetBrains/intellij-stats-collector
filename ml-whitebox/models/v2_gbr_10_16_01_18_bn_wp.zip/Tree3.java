/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree3 {
    public double calcTree(double... fs) {
        if (fs[34] <= 0.5) {
            if (fs[69] <= 9996.5) {
                if (fs[75] <= 0.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.51369103317;
                                    } else {
                                        return 0.778131312618;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.774920542289;
                                    } else {
                                        return 0.804682950561;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.333593386202;
                                    } else {
                                        return 0.308209248514;
                                    }
                                } else {
                                    return 0.760857124449;
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[40] <= 0.5) {
                                        return -0.023674946016;
                                    } else {
                                        return 0.683478795863;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.402170755464;
                                    } else {
                                        return -0.120429689837;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.1620898076;
                                    } else {
                                        return 0.0971109104774;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0221481147968;
                                    } else {
                                        return 0.038629078238;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 19.5) {
                                if (fs[50] <= -532.0) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.798459018821;
                                    } else {
                                        return 0.822992407102;
                                    }
                                } else {
                                    return 0.667753223217;
                                }
                            } else {
                                if (fs[4] <= 29.5) {
                                    if (fs[4] <= 25.5) {
                                        return 0.0842489056021;
                                    } else {
                                        return -0.0712723733786;
                                    }
                                } else {
                                    if (fs[4] <= 32.5) {
                                        return 0.392911086017;
                                    } else {
                                        return 0.0468074300523;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[67] <= -1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0408923415247;
                                    } else {
                                        return -0.0160558734303;
                                    }
                                } else {
                                    if (fs[50] <= -1107.5) {
                                        return 0.228759287257;
                                    } else {
                                        return -0.034792746757;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4847.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0409247458767;
                                    } else {
                                        return -0.049689230012;
                                    }
                                } else {
                                    return 0.06072088362;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[50] <= -1309.0) {
                                        return 0.0233317295755;
                                    } else {
                                        return 0.40525591913;
                                    }
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return 0.405990292283;
                                    } else {
                                        return 0.697978170384;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[50] <= -1548.5) {
                                        return 0.79945288516;
                                    } else {
                                        return 0.507578908267;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.494962026555;
                                    } else {
                                        return 0.722580896564;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.714165384981;
                                    } else {
                                        return 0.574297502305;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.401416588038;
                                    } else {
                                        return 0.199938012799;
                                    }
                                }
                            } else {
                                if (fs[59] <= -0.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.788439087569;
                                    } else {
                                        return 0.631103252374;
                                    }
                                } else {
                                    if (fs[50] <= -1283.5) {
                                        return 0.734188395456;
                                    } else {
                                        return 0.458064045393;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[99] <= 0.5) {
                                    if (fs[69] <= 9902.5) {
                                        return 0.0340278652584;
                                    } else {
                                        return 0.132789918069;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0339389974019;
                                    } else {
                                        return 0.0269873148449;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[97] <= 1.5) {
                                        return 0.0590915172205;
                                    } else {
                                        return 0.118546868005;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.148653479618;
                                    } else {
                                        return 0.368049775971;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0255196830836;
                                    } else {
                                        return 0.0233075257312;
                                    }
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return -0.047759591041;
                                    } else {
                                        return 0.187101459266;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[69] <= 8722.5) {
                                        return -0.0428874934099;
                                    } else {
                                        return -0.0191873421024;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0487199059214;
                                    } else {
                                        return -0.0454053071682;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[50] <= -968.0) {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[50] <= -1473.5) {
                                        return 0.562813575694;
                                    } else {
                                        return 0.68599904907;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.574470471105;
                                    } else {
                                        return 0.41577394262;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.74781590288;
                                    } else {
                                        return 0.319037737825;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.645722399485;
                                    } else {
                                        return 0.564105774675;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 3.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.296490984614;
                                    } else {
                                        return 0.581072822205;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.744230080466;
                                    } else {
                                        return -0.0159223212957;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[67] <= -3.5) {
                                        return 0.701500892301;
                                    } else {
                                        return 0.511865251732;
                                    }
                                } else {
                                    return 0.753287234409;
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 1.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[59] <= -0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.826681941508;
                                    } else {
                                        return 0.824772902286;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.687750147656;
                                    } else {
                                        return 0.569790487113;
                                    }
                                }
                            } else {
                                if (fs[46] <= -0.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.655559641102;
                                    } else {
                                        return 0.830986441624;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.540089030169;
                                    } else {
                                        return 0.341283247272;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1088.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.565259465122;
                                    } else {
                                        return 0.723362879812;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.271437755263;
                                    } else {
                                        return 0.478837759469;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.606552865848;
                                    } else {
                                        return 0.661145680938;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.735485637674;
                                    } else {
                                        return 0.411112385249;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[50] <= -1428.0) {
                                if (fs[4] <= 11.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.233269309138;
                                    } else {
                                        return 0.554434330851;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.132190534082;
                                    } else {
                                        return -0.0502370332785;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0849542362441;
                                    } else {
                                        return 0.157859948008;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.000777260951773;
                                    } else {
                                        return 0.0537950369869;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.372184407533;
                                    } else {
                                        return 0.187621171038;
                                    }
                                } else {
                                    if (fs[50] <= -1408.0) {
                                        return 0.422574619358;
                                    } else {
                                        return 0.00612565006769;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.14937608581;
                                    } else {
                                        return 0.0333065394011;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0760111665669;
                                    } else {
                                        return -0.0653340352514;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 7.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[4] <= 19.5) {
                                        return -0.0494712446087;
                                    } else {
                                        return -0.0408903384823;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.0894576361958;
                                    } else {
                                        return -0.0510410795646;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0084809569447;
                                    } else {
                                        return -0.0437912236473;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.060861383972;
                                    } else {
                                        return 0.0960801764099;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.0) {
                                return 0.215901608853;
                            } else {
                                return -0.0513267439038;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    return 0.737754453875;
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                return 0.808542518644;
                            } else {
                                return 0.767868186929;
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                return 0.80998222039;
                            } else {
                                if (fs[50] <= -1138.0) {
                                    return 0.810167070544;
                                } else {
                                    return 0.809388340109;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[15] <= 0.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.810167070544;
                                    } else {
                                        return 0.811467559223;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.809388340109;
                                    } else {
                                        return 0.810677092291;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    return 0.808866981177;
                                } else {
                                    return 0.808088250742;
                                }
                            }
                        } else {
                            return 0.773341290844;
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[50] <= -1138.0) {
                        return 0.589659842317;
                    } else {
                        return 0.687017201057;
                    }
                } else {
                    return 0.783665462844;
                }
            }
        }
    }
}
