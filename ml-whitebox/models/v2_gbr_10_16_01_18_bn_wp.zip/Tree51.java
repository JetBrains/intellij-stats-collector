/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree51 {
    public double calcTree(double... fs) {
        if (fs[4] <= 7.5) {
            if (fs[0] <= 0.5) {
                if (fs[12] <= 0.5) {
                    if (fs[71] <= 0.5) {
                        if (fs[85] <= 0.5) {
                            if (fs[50] <= -987.5) {
                                if (fs[50] <= -1128.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0632421270736;
                                    } else {
                                        return 0.00385097113928;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.102154779449;
                                    } else {
                                        return -0.166266651467;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0349810536538;
                                    } else {
                                        return -0.124087354734;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.0903720927264;
                                    } else {
                                        return 0.235657677762;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1098.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.205439121456;
                                    } else {
                                        return 0.249745931262;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.193094907887;
                                    } else {
                                        return 0.119605321307;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[69] <= 9987.0) {
                                        return 0.0217538387116;
                                    } else {
                                        return 0.302842322037;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.262899705882;
                                    } else {
                                        return 0.084216668846;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9902.0) {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.00474084412668;
                                    } else {
                                        return -0.0441019044093;
                                    }
                                } else {
                                    if (fs[50] <= -1123.5) {
                                        return -0.198117918904;
                                    } else {
                                        return 0.217682626878;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    return 0.159473968316;
                                } else {
                                    return 0.253795100767;
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[4] <= 2.5) {
                                    return -0.0511542715713;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.131570482728;
                                    } else {
                                        return 0.0855426179689;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.368885652138;
                                    } else {
                                        return 0.0958812175241;
                                    }
                                } else {
                                    if (fs[69] <= 9992.5) {
                                        return -0.146489632525;
                                    } else {
                                        return 0.0653070107818;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[29] <= 0.5) {
                        if (fs[50] <= -1488.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[50] <= -1963.0) {
                                        return 0.0447768377544;
                                    } else {
                                        return 0.254461638806;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.128209098267;
                                    } else {
                                        return 0.222036899515;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0910658140241;
                                    } else {
                                        return 0.160577896762;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.256392897595;
                                    } else {
                                        return 0.090204172725;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[82] <= 5.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0483661553119;
                                    } else {
                                        return 0.0738382857353;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return 0.139068598608;
                                    } else {
                                        return 0.0953157189392;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0222831174945;
                                    } else {
                                        return -0.223846678796;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0824916491634;
                                    } else {
                                        return -0.224624731324;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[46] <= -0.5) {
                            return 0.273001589881;
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[50] <= -1308.0) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0753465209348;
                                    } else {
                                        return -0.353215938553;
                                    }
                                } else {
                                    return 0.274264728418;
                                }
                            } else {
                                if (fs[82] <= 4.5) {
                                    return -0.249724191056;
                                } else {
                                    return -0.00495855146702;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[82] <= 6.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[73] <= 75.0) {
                            if (fs[75] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return 0.160329710357;
                                    } else {
                                        return -0.108112124965;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0126943362975;
                                    } else {
                                        return 0.0624737923248;
                                    }
                                }
                            } else {
                                if (fs[61] <= -997.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.111505547296;
                                    } else {
                                        return 0.368381324611;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.0100110580285;
                                    } else {
                                        return 0.0330751071765;
                                    }
                                }
                            }
                        } else {
                            if (fs[65] <= 1.5) {
                                if (fs[50] <= -1132.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0242305320712;
                                    } else {
                                        return 0.0774516274512;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0210329963839;
                                    } else {
                                        return -0.0960731105384;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.299413854476;
                                } else {
                                    return 0.289203857035;
                                }
                            }
                        }
                    } else {
                        if (fs[93] <= 0.5) {
                            if (fs[69] <= 9995.5) {
                                if (fs[61] <= -997.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.00379454043336;
                                    } else {
                                        return 0.107185496407;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return -0.00416136786971;
                                    } else {
                                        return -0.0256421681354;
                                    }
                                }
                            } else {
                                if (fs[0] <= 20.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0303427644149;
                                    } else {
                                        return 0.220593105166;
                                    }
                                } else {
                                    if (fs[0] <= 39.5) {
                                        return -0.0110806829951;
                                    } else {
                                        return -0.0744059249208;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1488.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.00909434212906;
                                    } else {
                                        return 0.0523098729509;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.167415236874;
                                    } else {
                                        return -0.0222954050556;
                                    }
                                }
                            } else {
                                if (fs[61] <= -998.5) {
                                    return 0.178138480393;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00256599479574;
                                    } else {
                                        return 0.0175228077164;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[73] <= 75.0) {
                        if (fs[78] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[50] <= -1242.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.135876750758;
                                    } else {
                                        return -0.017439092943;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0182216840995;
                                    } else {
                                        return -0.0361884000038;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.0674531228729;
                                    } else {
                                        return -0.0574844996246;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0338784006341;
                                    } else {
                                        return 0.406977345163;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.017456031186;
                                    } else {
                                        return 0.0357494112348;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0229696005481;
                                    } else {
                                        return -0.111378757602;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.00917391304841;
                                    } else {
                                        return -0.00687594629873;
                                    }
                                } else {
                                    return 0.232208300013;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1458.0) {
                            if (fs[2] <= 1.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[50] <= -1488.0) {
                                        return -0.0139044256887;
                                    } else {
                                        return 0.285847061063;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0636335983176;
                                    } else {
                                        return 0.251456947271;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0918319353007;
                                    } else {
                                        return 0.200870632473;
                                    }
                                } else {
                                    if (fs[69] <= 4537.0) {
                                        return 0.00442252079152;
                                    } else {
                                        return -0.086418100861;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -498.0) {
                                if (fs[69] <= 9948.0) {
                                    if (fs[50] <= -977.0) {
                                        return -0.0675623051276;
                                    } else {
                                        return -0.1311553155;
                                    }
                                } else {
                                    if (fs[69] <= 9993.5) {
                                        return 0.0765836673525;
                                    } else {
                                        return -0.0481673441676;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0479927925701;
                                    } else {
                                        return -0.0174044197274;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.0410956412316;
                                    } else {
                                        return -0.0546248720537;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 4.5) {
                    if (fs[25] <= 0.5) {
                        if (fs[50] <= -880.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[50] <= -1558.5) {
                                    if (fs[73] <= 150.0) {
                                        return 0.144449613046;
                                    } else {
                                        return 0.0980653711829;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0305023453615;
                                    } else {
                                        return 0.0865685801751;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[4] <= 13.5) {
                                        return 0.350321080102;
                                    } else {
                                        return 0.0721403510683;
                                    }
                                } else {
                                    return 0.190388180791;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.0567964884474;
                                    } else {
                                        return -0.0870390614222;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0166272743874;
                                    } else {
                                        return 0.118691703681;
                                    }
                                }
                            } else {
                                if (fs[46] <= -0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0965630127952;
                                    } else {
                                        return 0.297319137878;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.0278728114153;
                                    } else {
                                        return -0.312794538091;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[95] <= 0.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[82] <= 4.5) {
                                        return -0.031203620905;
                                    } else {
                                        return -0.139695544151;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.00188699237471;
                                    } else {
                                        return 0.204664192337;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[50] <= -1873.5) {
                                        return 0.114859189934;
                                    } else {
                                        return -0.0101963860773;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return 0.220296459269;
                                    } else {
                                        return -0.164899101347;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 26.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.11029177932;
                                    } else {
                                        return 0.212166444499;
                                    }
                                } else {
                                    if (fs[50] <= -968.0) {
                                        return 0.082220563194;
                                    } else {
                                        return -0.177713117063;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[69] <= 4729.5) {
                                        return -0.0701691218193;
                                    } else {
                                        return -0.214569322688;
                                    }
                                } else {
                                    return 0.287404705332;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[42] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0995773348681;
                                    } else {
                                        return 0.135017318307;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0249928311253;
                                    } else {
                                        return 0.159379079051;
                                    }
                                }
                            } else {
                                if (fs[2] <= 10.5) {
                                    if (fs[4] <= 47.0) {
                                        return 0.0272935551643;
                                    } else {
                                        return -0.326515227444;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.186144883881;
                                    } else {
                                        return 0.0488642124247;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1128.0) {
                                if (fs[56] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.137300470857;
                                    } else {
                                        return 0.135029800387;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.251004475276;
                                    } else {
                                        return 0.0971859653669;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    return 0.25098738699;
                                } else {
                                    return -0.0682537187371;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1478.0) {
                            if (fs[69] <= 4229.0) {
                                if (fs[91] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.160774571081;
                                    } else {
                                        return 0.0432510695207;
                                    }
                                } else {
                                    return -0.215690426336;
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    return -0.262061306448;
                                } else {
                                    return 0.0287548130376;
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                return 0.00803467422879;
                            } else {
                                return -0.287814797578;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 3.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.00520307095863;
                                    } else {
                                        return 0.104302738149;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0757540613464;
                                    } else {
                                        return -0.0507303926765;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0166583548301;
                                    } else {
                                        return 0.138880149133;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0878379917789;
                                    } else {
                                        return 0.370226870713;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[80] <= 0.5) {
                                    if (fs[50] <= -987.0) {
                                        return -0.00625719259377;
                                    } else {
                                        return -0.0197661463639;
                                    }
                                } else {
                                    if (fs[52] <= -1.5) {
                                        return -0.00418599195072;
                                    } else {
                                        return -0.0236708482226;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.0100945400476;
                                    } else {
                                        return 0.0035304170751;
                                    }
                                } else {
                                    return 0.265171037022;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[82] <= 4.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.00692260121742;
                                    } else {
                                        return 0.0344774958875;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0203352219861;
                                    } else {
                                        return 0.00968104949022;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[95] <= 1.5) {
                                        return 0.00460323252799;
                                    } else {
                                        return 0.0288911499591;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0255186346626;
                                    } else {
                                        return -0.00997825649526;
                                    }
                                }
                            }
                        } else {
                            if (fs[67] <= -1.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[69] <= 8713.5) {
                                        return 0.0188023655075;
                                    } else {
                                        return 0.0819416783751;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.00111223205887;
                                    } else {
                                        return 0.0255657359213;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[69] <= 9886.5) {
                                        return -0.0208429493262;
                                    } else {
                                        return -0.110167447325;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0432053199945;
                                    } else {
                                        return -0.0759056310591;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[54] <= 0.5) {
                        if (fs[52] <= 998.0) {
                            if (fs[82] <= 5.5) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.00401270319305;
                                    } else {
                                        return -0.00576005637397;
                                    }
                                } else {
                                    if (fs[50] <= -1098.0) {
                                        return 0.0812616063144;
                                    } else {
                                        return -0.00706222472352;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[82] <= 6.5) {
                                        return -0.00972733193959;
                                    } else {
                                        return -0.004682007889;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return -0.00558758144057;
                                    } else {
                                        return 0.0739071223477;
                                    }
                                }
                            }
                        } else {
                            return 0.20299999031;
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            return -0.0530680138728;
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[4] <= 17.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.132411247806;
                                    } else {
                                        return 0.349626899437;
                                    }
                                } else {
                                    return -0.0189264061126;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 12.5) {
                                        return -0.0110513327483;
                                    } else {
                                        return -0.00568499819704;
                                    }
                                } else {
                                    return -0.0362649119802;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
