/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree27 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[97] <= 1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[75] <= 0.5) {
                        if (fs[4] <= 19.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.141915499356;
                                    } else {
                                        return 0.235069801317;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.234964738399;
                                    } else {
                                        return 0.25185401211;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.381613540223;
                                    } else {
                                        return 0.377530192522;
                                    }
                                } else {
                                    if (fs[50] <= -1128.0) {
                                        return 0.282714762547;
                                    } else {
                                        return 0.359087739782;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[4] <= 29.5) {
                                    if (fs[50] <= -1563.0) {
                                        return -0.0768569111384;
                                    } else {
                                        return -0.181773656599;
                                    }
                                } else {
                                    if (fs[4] <= 32.5) {
                                        return 0.286304202452;
                                    } else {
                                        return -0.0759028146892;
                                    }
                                }
                            } else {
                                return -0.220609134811;
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[50] <= -1504.0) {
                                if (fs[99] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return 0.272011935844;
                                    } else {
                                        return -0.179098127706;
                                    }
                                } else {
                                    if (fs[82] <= 1.5) {
                                        return -0.16403806951;
                                    } else {
                                        return 0.31253274239;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0236249886632;
                                    } else {
                                        return 0.142375765421;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.132566344601;
                                    } else {
                                        return -0.00818397922192;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.230571768158;
                                    } else {
                                        return -0.107214706065;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.133899062256;
                                    } else {
                                        return 0.227778008574;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00988087870419;
                                    } else {
                                        return 0.305627143038;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.156508065777;
                                    } else {
                                        return 0.252828854981;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 11.5) {
                        if (fs[75] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0379001652641;
                                    } else {
                                        return 0.180594333048;
                                    }
                                } else {
                                    if (fs[0] <= 25.5) {
                                        return 0.0718289473602;
                                    } else {
                                        return -0.073393495712;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1053.0) {
                                    if (fs[34] <= 0.5) {
                                        return 0.0467186666811;
                                    } else {
                                        return 0.363623969695;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0743112737869;
                                    } else {
                                        return -0.0408061624014;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[69] <= 9968.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0143005684035;
                                    } else {
                                        return -0.00764811511218;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.0108971635424;
                                    } else {
                                        return 0.232981199504;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.032728401661;
                                    } else {
                                        return 0.135573913229;
                                    }
                                } else {
                                    if (fs[50] <= -1108.0) {
                                        return 0.00561280206201;
                                    } else {
                                        return -0.0137795483958;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[69] <= 9860.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.00471657294117;
                                    } else {
                                        return -0.0140227314586;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0803390717577;
                                    } else {
                                        return -0.00493547954958;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[47] <= 0.5) {
                                        return -0.0271455820173;
                                    } else {
                                        return 0.0853586687954;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return -0.015609062007;
                                    } else {
                                        return 0.00838385423006;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 16.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.0733339909587;
                                    } else {
                                        return 0.00873505389181;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return 0.00366916179837;
                                    } else {
                                        return 0.343783345512;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[73] <= 150.0) {
                                        return 0.010033954076;
                                    } else {
                                        return -0.00885566456289;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.0129719823202;
                                    } else {
                                        return -0.0162663875404;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1043.0) {
                    if (fs[57] <= 0.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[39] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[50] <= -1318.5) {
                                        return 0.371410617454;
                                    } else {
                                        return 0.326170471921;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0852432805812;
                                    } else {
                                        return 0.302836286579;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[59] <= -0.5) {
                                        return 0.164539705384;
                                    } else {
                                        return 0.0386737216268;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.254233228402;
                                    } else {
                                        return 0.126196163901;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 18.5) {
                                if (fs[69] <= 9989.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.033541174129;
                                    } else {
                                        return 0.0914307151277;
                                    }
                                } else {
                                    return -0.121663129714;
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[4] <= 19.5) {
                                        return 0.0849600917469;
                                    } else {
                                        return -0.0327672449042;
                                    }
                                } else {
                                    return 0.51832804785;
                                }
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.230796658923;
                                    } else {
                                        return -0.0197984779527;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0661020416994;
                                    } else {
                                        return 0.217085274588;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[50] <= -1128.5) {
                                        return 0.195547760114;
                                    } else {
                                        return 0.259195202972;
                                    }
                                } else {
                                    if (fs[50] <= -1083.5) {
                                        return 0.049797882558;
                                    } else {
                                        return 0.651503665756;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[40] <= 0.5) {
                                    return -0.0239218052436;
                                } else {
                                    return 0.11526804381;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -1313.0) {
                                        return 0.0514755844926;
                                    } else {
                                        return -0.0877763562057;
                                    }
                                } else {
                                    if (fs[0] <= 11.5) {
                                        return -0.0317005876731;
                                    } else {
                                        return 0.0204137040012;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[59] <= -1.5) {
                        if (fs[59] <= -3.5) {
                            return -0.0370450176122;
                        } else {
                            if (fs[0] <= 0.5) {
                                return 0.372047383052;
                            } else {
                                if (fs[46] <= -2.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0147403573271;
                                    } else {
                                        return 0.0939607070385;
                                    }
                                } else {
                                    if (fs[50] <= -475.5) {
                                        return -0.0265627645527;
                                    } else {
                                        return 0.00871870962693;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -993.5) {
                            return -0.0929477051861;
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.123784149593;
                                    } else {
                                        return 0.134342606407;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.386582714975;
                                    } else {
                                        return 0.180853724079;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0409933495468;
                                    } else {
                                        return -0.0147476150383;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.17878095047;
                                    } else {
                                        return -0.0287507688558;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[50] <= -987.5) {
                    if (fs[18] <= -0.5) {
                        if (fs[69] <= 9998.5) {
                            return -0.296372683873;
                        } else {
                            if (fs[84] <= 0.5) {
                                return 0.00311150517134;
                            } else {
                                return -0.246438365564;
                            }
                        }
                    } else {
                        if (fs[93] <= 0.5) {
                            if (fs[50] <= -1578.0) {
                                if (fs[28] <= 0.5) {
                                    if (fs[50] <= -1938.0) {
                                        return 0.262021485516;
                                    } else {
                                        return 0.377306710344;
                                    }
                                } else {
                                    return -0.0603976636263;
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.266164527773;
                                    } else {
                                        return 0.227428861562;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.177603493894;
                                    } else {
                                        return 0.00702714756348;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 35.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.276426338542;
                                    } else {
                                        return 0.210293336566;
                                    }
                                } else {
                                    return -0.226551962436;
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.411385627226;
                                    } else {
                                        return -0.0759196762994;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.111665117381;
                                    } else {
                                        return 0.295124069183;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[46] <= -0.5) {
                                if (fs[68] <= 0.5) {
                                    return 0.313780170846;
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.31478691024;
                                    } else {
                                        return 0.243311211925;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.322359141043;
                                    } else {
                                        return 0.211978136853;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.232882252016;
                                    } else {
                                        return 0.135867602782;
                                    }
                                }
                            }
                        } else {
                            if (fs[67] <= -3.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.447126315303;
                                    } else {
                                        return 0.119619618276;
                                    }
                                } else {
                                    if (fs[4] <= 13.0) {
                                        return 0.195722474945;
                                    } else {
                                        return 0.530668874551;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0822634532084;
                                    } else {
                                        return 0.0801437896305;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0713825388645;
                                    } else {
                                        return -0.0128455345571;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[95] <= 1.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.307776241219;
                                    } else {
                                        return 0.256192463861;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.203706946039;
                                    } else {
                                        return 0.265454919309;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.232400087632;
                                    } else {
                                        return 0.407135470223;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0723792615987;
                                    } else {
                                        return 0.199299713324;
                                    }
                                }
                            }
                        } else {
                            if (fs[67] <= -3.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.248724611668;
                                    } else {
                                        return 0.0793773741617;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return 0.326617635743;
                                    } else {
                                        return 0.40957886663;
                                    }
                                }
                            } else {
                                if (fs[61] <= -498.0) {
                                    if (fs[59] <= -1.5) {
                                        return 0.254696496218;
                                    } else {
                                        return 0.376742213489;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0599731371401;
                                    } else {
                                        return 0.159261887384;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1418.0) {
                    if (fs[50] <= -1443.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[4] <= 18.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.0571453859224;
                                    } else {
                                        return 0.143279116625;
                                    }
                                } else {
                                    return 0.393706227848;
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0248147052884;
                                    } else {
                                        return -0.0646635941955;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.283994279093;
                                    } else {
                                        return 0.0211412315484;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[63] <= 5.0) {
                                    if (fs[0] <= 21.5) {
                                        return 0.211971575966;
                                    } else {
                                        return -0.0507351339247;
                                    }
                                } else {
                                    return -0.178347927723;
                                }
                            } else {
                                if (fs[4] <= 12.0) {
                                    return -0.183320436452;
                                } else {
                                    return -0.094906081956;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9999.5) {
                            return 0.182214868123;
                        } else {
                            return 0.421518367496;
                        }
                    }
                } else {
                    if (fs[4] <= 4.5) {
                        if (fs[37] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[50] <= -1138.5) {
                                    return 0.309434756704;
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0747142757887;
                                    } else {
                                        return 0.0540906783792;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 19.5) {
                                        return 0.0990818393807;
                                    } else {
                                        return -0.0125570836614;
                                    }
                                } else {
                                    if (fs[100] <= 0.5) {
                                        return 0.033146574591;
                                    } else {
                                        return 0.376123660273;
                                    }
                                }
                            }
                        } else {
                            return 0.416268435999;
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[73] <= 75.0) {
                                if (fs[65] <= 1.5) {
                                    if (fs[61] <= -498.5) {
                                        return 0.289281793595;
                                    } else {
                                        return 0.0353917847241;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.149054534406;
                                    } else {
                                        return 0.381837833918;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.120446682381;
                                    } else {
                                        return 0.448884555971;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0709653169963;
                                    } else {
                                        return -0.00621912161037;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[50] <= -1108.0) {
                                    if (fs[50] <= -1128.0) {
                                        return 0.00158957559077;
                                    } else {
                                        return 0.19460588275;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0430652170981;
                                    } else {
                                        return -0.0173277105573;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return 0.283300934126;
                                } else {
                                    if (fs[0] <= 63.0) {
                                        return 0.0140632238406;
                                    } else {
                                        return 0.337393498877;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
