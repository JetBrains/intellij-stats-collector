/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree94 {
    public double calcTree(double... fs) {
        if (fs[61] <= -997.5) {
            if (fs[57] <= 0.5) {
                if (fs[93] <= 0.5) {
                    if (fs[2] <= 2.5) {
                        return 0.0294960086574;
                    } else {
                        return -0.0959405270313;
                    }
                } else {
                    if (fs[73] <= 250.0) {
                        if (fs[50] <= -476.5) {
                            return -0.0830732870779;
                        } else {
                            return 0.0953971629165;
                        }
                    } else {
                        if (fs[97] <= 1.5) {
                            if (fs[59] <= -1.5) {
                                if (fs[50] <= -1118.0) {
                                    return -0.126991017364;
                                } else {
                                    return -0.0533328743948;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    return 0.0116862328571;
                                } else {
                                    return -0.0185388891084;
                                }
                            }
                        } else {
                            if (fs[46] <= -1.5) {
                                if (fs[4] <= 10.5) {
                                    return -0.0811720283298;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0995664947957;
                                    } else {
                                        return 0.0774764627586;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0244422154635;
                                    } else {
                                        return -0.00488245274815;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0995938394452;
                                    } else {
                                        return -0.00480495361027;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[44] <= 0.5) {
                    if (fs[4] <= 18.5) {
                        if (fs[97] <= 1.5) {
                            if (fs[50] <= -992.0) {
                                if (fs[68] <= 0.5) {
                                    return 0.30438193446;
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.0659444998269;
                                    } else {
                                        return -0.0588053952631;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.00265128341856;
                                    } else {
                                        return 0.0386170902158;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.254963522973;
                                    } else {
                                        return 0.144490181725;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0099851299981;
                                    } else {
                                        return -0.0287728459408;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.079450683358;
                                    } else {
                                        return 0.0260835673932;
                                    }
                                }
                            } else {
                                return 0.194375480907;
                            }
                        }
                    } else {
                        if (fs[95] <= 1.5) {
                            return -0.177754116892;
                        } else {
                            return -0.0292989091898;
                        }
                    }
                } else {
                    if (fs[61] <= -998.5) {
                        return -0.022331759285;
                    } else {
                        if (fs[95] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[0] <= 9.5) {
                                    return -0.00707855413163;
                                } else {
                                    return 2.68768559872e-06;
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    return -0.0318593312566;
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return -0.0138827983629;
                                    } else {
                                        return -0.0084062075755;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -986.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.0122678566652;
                                    } else {
                                        return -0.038006850392;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00232068504924;
                                    } else {
                                        return 0.0326041536097;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0161081830467;
                                    } else {
                                        return -0.000115122375549;
                                    }
                                } else {
                                    if (fs[50] <= -976.0) {
                                        return -0.0169541503877;
                                    } else {
                                        return -0.00828231323434;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 18.5) {
                    if (fs[88] <= 0.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return 0.0352591161558;
                                    } else {
                                        return 0.167292296526;
                                    }
                                } else {
                                    if (fs[50] <= -1483.5) {
                                        return -0.00441101733541;
                                    } else {
                                        return 0.01581972767;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.00210588688438;
                                    } else {
                                        return 0.0239737412743;
                                    }
                                } else {
                                    if (fs[50] <= -456.5) {
                                        return -0.028468121669;
                                    } else {
                                        return -0.111347045841;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[82] <= 1.0) {
                                    if (fs[50] <= -1303.0) {
                                        return -0.161721748952;
                                    } else {
                                        return 0.207347435386;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.251395301454;
                                    } else {
                                        return -0.0479362390758;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[50] <= -1478.0) {
                                        return -0.214750359114;
                                    } else {
                                        return -0.405522092631;
                                    }
                                } else {
                                    return -0.103744132441;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9662.5) {
                            if (fs[50] <= -1473.5) {
                                if (fs[82] <= 5.0) {
                                    if (fs[82] <= 0.5) {
                                        return 0.0950988993504;
                                    } else {
                                        return 0.246359159515;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.020257535057;
                                    } else {
                                        return -0.0785073689013;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[50] <= -1468.5) {
                                        return 0.258204340462;
                                    } else {
                                        return -0.215260719717;
                                    }
                                } else {
                                    if (fs[73] <= 125.0) {
                                        return -0.21140814376;
                                    } else {
                                        return -0.124865810069;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[73] <= 25.0) {
                                    return -0.275501872081;
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.10166747498;
                                    } else {
                                        return 0.0755533974898;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.320916761372;
                                    } else {
                                        return 0.191260199685;
                                    }
                                } else {
                                    if (fs[69] <= 9995.5) {
                                        return -0.263981481351;
                                    } else {
                                        return 0.173918204825;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[52] <= 548.5) {
                        if (fs[25] <= 0.5) {
                            if (fs[55] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.00770479120766;
                                    } else {
                                        return -0.0814761878795;
                                    }
                                } else {
                                    if (fs[50] <= -1468.0) {
                                        return -0.0320474877324;
                                    } else {
                                        return 0.0174525544249;
                                    }
                                }
                            } else {
                                return -0.278220240186;
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[50] <= -2253.0) {
                                    if (fs[2] <= 4.5) {
                                        return 0.11077975745;
                                    } else {
                                        return -0.099916960522;
                                    }
                                } else {
                                    if (fs[69] <= 9983.0) {
                                        return -0.0412148073973;
                                    } else {
                                        return -0.135451074795;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.14221400734;
                                    } else {
                                        return 0.0146196453979;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return -0.0431949560085;
                                    } else {
                                        return 0.265759039255;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.323716985622;
                    }
                }
            } else {
                if (fs[14] <= 0.5) {
                    if (fs[2] <= 17.5) {
                        if (fs[63] <= 5.0) {
                            if (fs[49] <= 0.5) {
                                if (fs[69] <= 8516.0) {
                                    if (fs[73] <= 250.0) {
                                        return -0.000489610846286;
                                    } else {
                                        return -0.00351368678132;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.00566307349318;
                                    } else {
                                        return -0.0389403346998;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.0531525048374;
                                    } else {
                                        return 0.00375598038548;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.000454269321017;
                                    } else {
                                        return 0.00214817543818;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9937.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0395983386964;
                                    } else {
                                        return -0.006383784771;
                                    }
                                } else {
                                    if (fs[50] <= -1938.0) {
                                        return -0.137875471432;
                                    } else {
                                        return -0.0412720312291;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return -0.0440521635329;
                                } else {
                                    return -0.227594176878;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[12] <= 0.5) {
                                return -0.0962203461584;
                            } else {
                                return -0.155723086784;
                            }
                        } else {
                            return -0.0386938395559;
                        }
                    }
                } else {
                    if (fs[4] <= 5.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[0] <= 4.5) {
                                if (fs[50] <= -21.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.00492218479184;
                                    } else {
                                        return 0.0600559082544;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0237066574613;
                                    } else {
                                        return 0.221524491738;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[0] <= 29.5) {
                                        return -0.0365377214682;
                                    } else {
                                        return 0.032096635086;
                                    }
                                } else {
                                    return 0.0571866021106;
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                return 0.281686095025;
                            } else {
                                return 0.0763369981369;
                            }
                        }
                    } else {
                        if (fs[93] <= 0.5) {
                            if (fs[73] <= 75.0) {
                                if (fs[69] <= 9993.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.00432500005958;
                                    } else {
                                        return 0.015009103047;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0229550767784;
                                    } else {
                                        return -0.0927947282219;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1308.0) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0430648436571;
                                    } else {
                                        return 0.191525624365;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.00552876884423;
                                    } else {
                                        return -0.120799393078;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                return 0.308170704417;
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.00566210210071;
                                    } else {
                                        return 0.134784739636;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0217558136344;
                                    } else {
                                        return -0.0149831421099;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
