/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree43 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[0] <= 0.5) {
                if (fs[50] <= -987.5) {
                    if (fs[25] <= 0.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[86] <= 0.5) {
                                        return 0.153766968924;
                                    } else {
                                        return 0.0962496216787;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.272328250695;
                                    } else {
                                        return 0.290465452365;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[69] <= 9902.0) {
                                        return -0.0795355169856;
                                    } else {
                                        return 0.104297034897;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.0559777947928;
                                    } else {
                                        return 0.186847108203;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1273.0) {
                                if (fs[2] <= 6.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.091867155611;
                                    } else {
                                        return -0.302397270807;
                                    }
                                } else {
                                    return -0.156205290467;
                                }
                            } else {
                                return 0.18293792012;
                            }
                        }
                    } else {
                        if (fs[93] <= 0.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[82] <= 6.0) {
                                    if (fs[2] <= 7.5) {
                                        return -0.0837314765517;
                                    } else {
                                        return 0.081452209019;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.237296944869;
                                    } else {
                                        return -0.0599072611812;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.116183942134;
                                    } else {
                                        return 0.00565193059677;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0137159498659;
                                    } else {
                                        return 0.0785318132797;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[42] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.233494855522;
                                    } else {
                                        return 0.157557566939;
                                    }
                                } else {
                                    return -0.116710355326;
                                }
                            } else {
                                if (fs[50] <= -1493.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.225002563871;
                                    } else {
                                        return 0.0727902921748;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00571086476998;
                                    } else {
                                        return 0.105708959448;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[59] <= -0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0897455547351;
                                    } else {
                                        return 0.0627888832988;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.387822076351;
                                    } else {
                                        return 0.0680991580397;
                                    }
                                }
                            } else {
                                if (fs[61] <= -996.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.160241916363;
                                    } else {
                                        return 0.249687442858;
                                    }
                                } else {
                                    if (fs[59] <= -2.5) {
                                        return 0.235852213449;
                                    } else {
                                        return 0.00522151211497;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[50] <= -472.0) {
                                    if (fs[82] <= -0.5) {
                                        return -0.0544332343364;
                                    } else {
                                        return -0.174095862499;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00325508900462;
                                    } else {
                                        return 0.120023815224;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0340884645405;
                                    } else {
                                        return -0.10026129043;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.140783795691;
                                    } else {
                                        return 0.00989198966899;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 3.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.173362636255;
                                    } else {
                                        return -0.179994161476;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0271112036619;
                                    } else {
                                        return 0.119758942392;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.170087557488;
                                    } else {
                                        return 0.148951862355;
                                    }
                                } else {
                                    return 0.316019073104;
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.127597629805;
                                    } else {
                                        return 0.264642623751;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.197693790085;
                                    } else {
                                        return 0.31521528124;
                                    }
                                }
                            } else {
                                if (fs[4] <= 18.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.25795360768;
                                    } else {
                                        return 0.11771579439;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.155314009298;
                                    } else {
                                        return -0.343962819082;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[4] <= 19.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.014754675425;
                                    } else {
                                        return -0.00303230386167;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0742188820876;
                                    } else {
                                        return -0.00570239422652;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.279750551671;
                                    } else {
                                        return 0.068838066772;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0375779275105;
                                    } else {
                                        return -0.00961464260253;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return -0.0234986918288;
                                    } else {
                                        return 0.257018841549;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0648386739468;
                                    } else {
                                        return 0.355656873427;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9984.0) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0122925312961;
                                    } else {
                                        return 0.0548907263963;
                                    }
                                } else {
                                    return -0.172345549564;
                                }
                            }
                        }
                    } else {
                        if (fs[65] <= 1.5) {
                            if (fs[83] <= 0.5) {
                                if (fs[2] <= 11.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.013234363697;
                                    } else {
                                        return -0.0217394157981;
                                    }
                                } else {
                                    return 0.103404691736;
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[50] <= -957.0) {
                                        return -0.0360972240693;
                                    } else {
                                        return -0.0417097429942;
                                    }
                                } else {
                                    return -0.0283218340099;
                                }
                            }
                        } else {
                            return 0.0982323574921;
                        }
                    }
                } else {
                    if (fs[54] <= 0.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[0] <= 5.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[82] <= 5.5) {
                                        return -0.00324889072592;
                                    } else {
                                        return -0.0147456267816;
                                    }
                                } else {
                                    if (fs[50] <= -1383.0) {
                                        return 0.0453212904504;
                                    } else {
                                        return -0.00617917258355;
                                    }
                                }
                            } else {
                                if (fs[0] <= 18.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.00478460570059;
                                    } else {
                                        return -0.00703224837771;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return -0.00693342459071;
                                    } else {
                                        return 0.0600738959474;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[50] <= -2468.0) {
                                        return 0.281937334937;
                                    } else {
                                        return 0.00198803823235;
                                    }
                                } else {
                                    if (fs[50] <= -1082.5) {
                                        return 0.00501210376992;
                                    } else {
                                        return -0.00810019299572;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00768686855485;
                                    } else {
                                        return 0.0546308516914;
                                    }
                                } else {
                                    if (fs[0] <= 37.0) {
                                        return 0.042154422182;
                                    } else {
                                        return -0.0364394070204;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 7.5) {
                            if (fs[73] <= 100.0) {
                                if (fs[50] <= -466.5) {
                                    if (fs[50] <= -1057.0) {
                                        return -0.0264281596141;
                                    } else {
                                        return -0.0512643280642;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0233455482414;
                                    } else {
                                        return 0.0828653923252;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.00195642721133;
                                    } else {
                                        return 0.334739414405;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0103496586024;
                                    } else {
                                        return -0.036766176595;
                                    }
                                }
                            }
                        } else {
                            return 0.499075963323;
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[33] <= 0.5) {
                    if (fs[18] <= -0.5) {
                        if (fs[4] <= 15.5) {
                            return -0.300974508913;
                        } else {
                            return -0.0306813609512;
                        }
                    } else {
                        if (fs[4] <= 35.5) {
                            if (fs[8] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0905807173475;
                                    } else {
                                        return 0.123008727921;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.156894634026;
                                    } else {
                                        return -0.17597993785;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    return 0.223932495517;
                                } else {
                                    return -0.378416737112;
                                }
                            }
                        } else {
                            if (fs[95] <= 1.5) {
                                return -0.00337030617595;
                            } else {
                                return -0.505871240818;
                            }
                        }
                    }
                } else {
                    if (fs[95] <= 1.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[50] <= -1088.5) {
                                if (fs[67] <= -1.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.207208200817;
                                    } else {
                                        return 0.106384816904;
                                    }
                                } else {
                                    return 0.279728736999;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0834383794094;
                                    } else {
                                        return 0.15756086605;
                                    }
                                } else {
                                    if (fs[67] <= -4.5) {
                                        return 0.113823828164;
                                    } else {
                                        return -0.0147365925413;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0943048951884;
                                    } else {
                                        return -0.119530836209;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.174814954838;
                                    } else {
                                        return 0.101617197082;
                                    }
                                }
                            } else {
                                return 0.37148353148;
                            }
                        }
                    } else {
                        if (fs[4] <= 5.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    return 0.157595831926;
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.264481679857;
                                    } else {
                                        return 0.318380573869;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.144323504395;
                                    } else {
                                        return 0.0450932149324;
                                    }
                                } else {
                                    return 0.396524351566;
                                }
                            }
                        } else {
                            if (fs[59] <= -0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.206067132656;
                                    } else {
                                        return 0.4161108578;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0134502894127;
                                    } else {
                                        return 0.170373852962;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1288.0) {
                                    if (fs[4] <= 23.5) {
                                        return 0.0696475389497;
                                    } else {
                                        return 0.297420493978;
                                    }
                                } else {
                                    if (fs[67] <= -3.5) {
                                        return 0.0951106616198;
                                    } else {
                                        return -0.035877791809;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1082.5) {
                    if (fs[49] <= 0.5) {
                        if (fs[4] <= 8.5) {
                            if (fs[50] <= -1133.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.02964413805;
                                    } else {
                                        return 0.138896419107;
                                    }
                                } else {
                                    return -0.15589891547;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.389552354833;
                                } else {
                                    return 0.175699748616;
                                }
                            }
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.057635913347;
                                    } else {
                                        return -0.109609040729;
                                    }
                                } else {
                                    if (fs[63] <= 5.0) {
                                        return -0.0283348173828;
                                    } else {
                                        return -0.275153132689;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0815926127343;
                                    } else {
                                        return -0.0094247785184;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return -0.0817311315407;
                                    } else {
                                        return 0.44492214426;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[50] <= -1123.5) {
                                if (fs[0] <= 39.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0279913673517;
                                    } else {
                                        return 0.0773490831345;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.0569551387618;
                                    } else {
                                        return -0.182356643998;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.186248759344;
                                    } else {
                                        return -0.0185443281626;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.395612571783;
                                    } else {
                                        return 0.580027254165;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 11.0) {
                                if (fs[73] <= 25.0) {
                                    return -0.0158523644864;
                                } else {
                                    return 0.377714652901;
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.615776905437;
                                    } else {
                                        return 0.503181494063;
                                    }
                                } else {
                                    if (fs[0] <= 13.0) {
                                        return 0.235131796643;
                                    } else {
                                        return 0.482063529985;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[97] <= 0.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0255996487125;
                                    } else {
                                        return 0.0726000510702;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0247993422083;
                                    } else {
                                        return -0.012530446413;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.125926505463;
                                    } else {
                                        return -0.00191154836791;
                                    }
                                } else {
                                    return 0.107456279936;
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.00208010886614;
                                    } else {
                                        return -0.0531050936299;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.00843952742357;
                                    } else {
                                        return 0.108426386175;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return -0.106225133888;
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return 0.123203874747;
                                    } else {
                                        return 0.334173831993;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[7] <= 0.5) {
                            if (fs[6] <= 0.5) {
                                if (fs[69] <= 9999.5) {
                                    return 0.26365010117;
                                } else {
                                    return -0.142160625932;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[55] <= 0.5) {
                                        return -0.00490104759417;
                                    } else {
                                        return -0.0711395071307;
                                    }
                                } else {
                                    if (fs[50] <= 3.5) {
                                        return -0.024289767229;
                                    } else {
                                        return -0.010440434614;
                                    }
                                }
                            }
                        } else {
                            return -0.122442278231;
                        }
                    }
                }
            }
        }
    }
}
