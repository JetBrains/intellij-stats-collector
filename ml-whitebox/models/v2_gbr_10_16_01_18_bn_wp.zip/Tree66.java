/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree66 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9981.5) {
            if (fs[39] <= 0.5) {
                if (fs[34] <= 0.5) {
                    if (fs[54] <= 0.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[73] <= 75.0) {
                                if (fs[61] <= -997.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.135742215005;
                                    } else {
                                        return -0.00123729479138;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0212795753695;
                                    } else {
                                        return -0.00171960896169;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -1289.0) {
                                        return 0.0199152553595;
                                    } else {
                                        return -0.00460390655714;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0581018990822;
                                    } else {
                                        return -0.0136653473844;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 6.5) {
                                if (fs[59] <= -1.5) {
                                    if (fs[50] <= -1093.0) {
                                        return 0.086181062417;
                                    } else {
                                        return 0.0212398476781;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.00218424043626;
                                    } else {
                                        return 0.0371728159724;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[2] <= 10.5) {
                                        return 0.0522487387276;
                                    } else {
                                        return 0.128910513165;
                                    }
                                } else {
                                    if (fs[82] <= 3.5) {
                                        return 0.000905642979722;
                                    } else {
                                        return 0.0360073714922;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0251071002115;
                                    } else {
                                        return 0.124656760565;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.176441127591;
                                    } else {
                                        return 0.122320047382;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[61] <= -995.0) {
                                        return 0.110910853579;
                                    } else {
                                        return 0.223528080082;
                                    }
                                } else {
                                    if (fs[4] <= 19.0) {
                                        return 0.270567603592;
                                    } else {
                                        return 0.117929481239;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[73] <= 100.0) {
                                        return -0.0151318863104;
                                    } else {
                                        return 0.144626312029;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0459913639722;
                                    } else {
                                        return 0.386501567404;
                                    }
                                }
                            } else {
                                if (fs[50] <= -946.0) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0176122735511;
                                    } else {
                                        return -0.0335822760129;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0286977062693;
                                    } else {
                                        return -0.00534494736829;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 7.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0974759770433;
                                    } else {
                                        return 0.0433036207078;
                                    }
                                } else {
                                    return 0.0358643699064;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0316725928717;
                                    } else {
                                        return 0.0351950489389;
                                    }
                                } else {
                                    return 0.166194251042;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.00911151133015;
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0468234295369;
                                    } else {
                                        return 0.0394842953541;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0349495278755;
                                    } else {
                                        return 0.0237524104364;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            return -0.143213697422;
                        } else {
                            return 0.0857116465179;
                        }
                    }
                }
            } else {
                if (fs[44] <= 0.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[97] <= 0.5) {
                            if (fs[4] <= 1.5) {
                                if (fs[91] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.223909413733;
                                    } else {
                                        return 0.43651290022;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.105783464364;
                                    } else {
                                        return 0.0954631466247;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[91] <= 0.5) {
                                        return -0.0365248330481;
                                    } else {
                                        return 0.122292798072;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0918220814745;
                                    } else {
                                        return -0.0292464541307;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1132.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0243599270166;
                                    } else {
                                        return -0.00275195600549;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.05063035043;
                                    } else {
                                        return 0.0252463154803;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1123.5) {
                                    if (fs[97] <= 1.5) {
                                        return 0.20528296239;
                                    } else {
                                        return 0.104540418217;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return 0.0271921611525;
                                    } else {
                                        return 0.0587259048353;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[59] <= -1.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[61] <= -995.5) {
                                    return 0.171926482962;
                                } else {
                                    return -0.127161787637;
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    return 0.350663838136;
                                } else {
                                    return 0.102636140838;
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[91] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.000588173700215;
                                    } else {
                                        return -0.0425006021385;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.144102431973;
                                    } else {
                                        return -0.0167140697186;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.000366023085166;
                                    } else {
                                        return 0.0903962626537;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.364171797865;
                                    } else {
                                        return 0.0512569306321;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[57] <= 0.5) {
                        if (fs[46] <= -2.5) {
                            return -0.0535025120159;
                        } else {
                            if (fs[46] <= -0.5) {
                                if (fs[46] <= -1.5) {
                                    if (fs[50] <= -486.5) {
                                        return -0.0258852844041;
                                    } else {
                                        return -0.0139189393554;
                                    }
                                } else {
                                    return -0.0304016667674;
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[55] <= 0.5) {
                                        return -0.00617394555129;
                                    } else {
                                        return 0.00995109839618;
                                    }
                                } else {
                                    return -0.0283947261041;
                                }
                            }
                        }
                    } else {
                        if (fs[46] <= -2.5) {
                            return 0.0417240113624;
                        } else {
                            if (fs[4] <= 17.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.00302523301186;
                                    } else {
                                        return -0.0196256009695;
                                    }
                                } else {
                                    return 0.0309194933165;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[61] <= -995.5) {
                                        return 0.192292651489;
                                    } else {
                                        return 0.0047235304527;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.00517071686185;
                                    } else {
                                        return -0.00194091938615;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[87] <= 0.5) {
                    if (fs[4] <= 4.5) {
                        if (fs[69] <= 9994.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[82] <= 1.5) {
                                    if (fs[69] <= 9992.5) {
                                        return 0.0671887304313;
                                    } else {
                                        return 0.16114925076;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0842793258173;
                                    } else {
                                        return 0.0344145030707;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return 0.273375566139;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0739226357702;
                                    } else {
                                        return 0.153302349343;
                                    }
                                }
                            }
                        } else {
                            if (fs[29] <= 0.5) {
                                if (fs[82] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.076254490898;
                                    } else {
                                        return -0.157734548776;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.018750058334;
                                    } else {
                                        return 0.0466632065249;
                                    }
                                }
                            } else {
                                return -0.210634691672;
                            }
                        }
                    } else {
                        if (fs[67] <= -4.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[82] <= 5.0) {
                                    if (fs[4] <= 24.5) {
                                        return -0.0444063105304;
                                    } else {
                                        return 0.216012766875;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.11072323967;
                                    } else {
                                        return 0.225478929459;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.151605723473;
                                    } else {
                                        return -0.0495306761399;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.106350460626;
                                    } else {
                                        return 0.172987909014;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[50] <= -1488.0) {
                                    if (fs[52] <= 548.5) {
                                        return 0.0165204472597;
                                    } else {
                                        return 0.278098691398;
                                    }
                                } else {
                                    if (fs[50] <= -977.0) {
                                        return 0.0629086751234;
                                    } else {
                                        return 0.00909047756708;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0100686836628;
                                    } else {
                                        return 0.0572653644096;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return -0.0321853156387;
                                    } else {
                                        return 0.174930202788;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 15.5) {
                        if (fs[69] <= 9996.0) {
                            return -0.347981434252;
                        } else {
                            return -0.205929444668;
                        }
                    } else {
                        return -0.097341938759;
                    }
                }
            } else {
                if (fs[4] <= 8.5) {
                    if (fs[2] <= 3.5) {
                        if (fs[37] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[69] <= 9983.5) {
                                        return 0.167652798648;
                                    } else {
                                        return 0.0435319821418;
                                    }
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return 0.0421430831497;
                                    } else {
                                        return -0.0380091889138;
                                    }
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return -0.00638776500712;
                                    } else {
                                        return 0.01672071548;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0572221919919;
                                    } else {
                                        return 0.312994865229;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9982.5) {
                                return 0.352390469751;
                            } else {
                                if (fs[69] <= 9993.5) {
                                    if (fs[82] <= 3.5) {
                                        return -0.0114570754742;
                                    } else {
                                        return 0.306250016935;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0964364253722;
                                    } else {
                                        return 0.345220710063;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[50] <= -1458.0) {
                                if (fs[82] <= 5.5) {
                                    if (fs[82] <= 1.0) {
                                        return 0.233617464844;
                                    } else {
                                        return -0.220429556112;
                                    }
                                } else {
                                    if (fs[69] <= 9995.5) {
                                        return 0.473933083036;
                                    } else {
                                        return 0.208220789595;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0651907504953;
                                    } else {
                                        return 0.394373758369;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.136684907693;
                                    } else {
                                        return -0.0344530057899;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9987.5) {
                                return 0.297485466966;
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.0294889900734;
                                    } else {
                                        return 0.446254718541;
                                    }
                                } else {
                                    return -0.329258138206;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 6.5) {
                        if (fs[77] <= 0.5) {
                            if (fs[91] <= 0.5) {
                                if (fs[61] <= -498.5) {
                                    return 0.20118607828;
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.00126714577096;
                                    } else {
                                        return 0.136560425306;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0210081734253;
                                    } else {
                                        return -0.0559628687992;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return -0.00268604714187;
                                    } else {
                                        return 0.176737262793;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -1468.0) {
                                        return -0.0856990540321;
                                    } else {
                                        return 0.0093887973067;
                                    }
                                } else {
                                    if (fs[50] <= -1247.5) {
                                        return -0.133656609027;
                                    } else {
                                        return -0.0506871666032;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[56] <= 0.5) {
                                        return -0.0109745946414;
                                    } else {
                                        return 0.0740566634008;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0148360199668;
                                    } else {
                                        return -0.0471531791155;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[69] <= 9984.5) {
                                return 0.159562674444;
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[2] <= 8.5) {
                                        return -0.0474565886402;
                                    } else {
                                        return -0.170893612468;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0686864536515;
                                    } else {
                                        return 0.158117727544;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1438.0) {
                                if (fs[50] <= -1478.0) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.193466431128;
                                    } else {
                                        return 0.0242536670677;
                                    }
                                } else {
                                    return 0.4035265278;
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.0227844536874;
                                    } else {
                                        return 0.243828229611;
                                    }
                                } else {
                                    if (fs[50] <= -1128.0) {
                                        return -0.130227635922;
                                    } else {
                                        return 0.0413960479387;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
