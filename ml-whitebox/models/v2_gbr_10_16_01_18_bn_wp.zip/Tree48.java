/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree48 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[0] <= 0.5) {
                if (fs[11] <= 0.5) {
                    if (fs[68] <= 0.5) {
                        if (fs[43] <= 0.5) {
                            if (fs[50] <= -5413.5) {
                                return 0.298534821637;
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.173261583269;
                                    } else {
                                        return -0.0183239043765;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.122306143789;
                                    } else {
                                        return 0.302481905145;
                                    }
                                }
                            }
                        } else {
                            if (fs[56] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[50] <= -1948.0) {
                                        return -0.0554413280116;
                                    } else {
                                        return 0.217080063179;
                                    }
                                } else {
                                    if (fs[4] <= 32.5) {
                                        return -0.0389731154611;
                                    } else {
                                        return 0.251881881644;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.19116897165;
                                    } else {
                                        return 0.110699612134;
                                    }
                                } else {
                                    if (fs[4] <= 28.0) {
                                        return 0.206877113606;
                                    } else {
                                        return 0.29857413274;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[46] <= -0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0830572825849;
                                    } else {
                                        return -0.0762784752526;
                                    }
                                } else {
                                    if (fs[59] <= -3.5) {
                                        return -0.126919695895;
                                    } else {
                                        return 0.097235585607;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.206149434638;
                                    } else {
                                        return 0.123642031295;
                                    }
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return 0.2010789711;
                                    } else {
                                        return 0.146469515586;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -977.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.0824235857599;
                                    } else {
                                        return -0.146357624732;
                                    }
                                } else {
                                    if (fs[69] <= 9902.0) {
                                        return -0.0451654652548;
                                    } else {
                                        return 0.0881207893248;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.0235589118228;
                                    } else {
                                        return 0.0820195914355;
                                    }
                                } else {
                                    if (fs[82] <= 3.5) {
                                        return 0.0345416637468;
                                    } else {
                                        return 0.175067434762;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[99] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0741294985814;
                                    } else {
                                        return 0.0412813303314;
                                    }
                                } else {
                                    if (fs[50] <= -546.5) {
                                        return 0.257224588643;
                                    } else {
                                        return 0.130961680183;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1618.0) {
                                    if (fs[88] <= 0.5) {
                                        return 0.157408269132;
                                    } else {
                                        return 0.310223116847;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.0199629534415;
                                    } else {
                                        return -0.115323934727;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[68] <= 0.5) {
                                        return 0.100575089997;
                                    } else {
                                        return -0.00138970229208;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.143550783172;
                                    } else {
                                        return 0.200489354038;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.366084818059;
                                    } else {
                                        return -0.0797549252405;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0542717180544;
                                    } else {
                                        return 0.0872771890397;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 1.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[50] <= -1488.0) {
                                        return -0.248211306915;
                                    } else {
                                        return -0.0998811373316;
                                    }
                                } else {
                                    if (fs[82] <= -0.5) {
                                        return -0.165367766821;
                                    } else {
                                        return -0.262821392251;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.163480904104;
                                    } else {
                                        return 0.136539673697;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0848623324978;
                                    } else {
                                        return -0.0307652887772;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.162097650061;
                                    } else {
                                        return 0.025043168034;
                                    }
                                } else {
                                    if (fs[82] <= 2.5) {
                                        return -0.0109405514251;
                                    } else {
                                        return 0.123811068185;
                                    }
                                }
                            } else {
                                if (fs[82] <= 4.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.0168896036775;
                                    } else {
                                        return 0.158288798946;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.137624707871;
                                    } else {
                                        return 0.0134870133183;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[73] <= 25.0) {
                    if (fs[79] <= 0.5) {
                        if (fs[34] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0343126977744;
                                    } else {
                                        return -0.00348751721678;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0167369553805;
                                    } else {
                                        return -0.00078879079566;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9879.0) {
                                    if (fs[60] <= 0.5) {
                                        return -0.00774596042232;
                                    } else {
                                        return -0.0168375504811;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0656779280401;
                                    } else {
                                        return -0.0271478465532;
                                    }
                                }
                            }
                        } else {
                            return 0.207994710408;
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[69] <= 9832.5) {
                                if (fs[50] <= -987.0) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0151971327762;
                                    } else {
                                        return 0.169379369454;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return -0.0235910451929;
                                    } else {
                                        return -0.0463971675632;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[82] <= 6.0) {
                                        return 0.0158741110337;
                                    } else {
                                        return 0.270005323339;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0981700726299;
                                    } else {
                                        return 0.607712719853;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[69] <= 9927.5) {
                                        return -0.00553298837595;
                                    } else {
                                        return 0.00118272085345;
                                    }
                                } else {
                                    if (fs[7] <= 0.5) {
                                        return -0.00749900324845;
                                    } else {
                                        return 0.0658001190214;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1418.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0377083294791;
                                    } else {
                                        return 0.153017470638;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.050636900189;
                                    } else {
                                        return -0.0237616477958;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[50] <= -1398.5) {
                            if (fs[82] <= 5.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0697008018647;
                                    } else {
                                        return 0.163617106176;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0646612326146;
                                    } else {
                                        return 0.00835036907851;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0616335437771;
                                    } else {
                                        return -0.0181790531581;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0490718593332;
                                    } else {
                                        return 0.142243765043;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.126647542674;
                                    } else {
                                        return 0.0158876421487;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.0134943666478;
                                    } else {
                                        return -0.0168294201394;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1128.0) {
                                    return 0.20196081384;
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0536913431384;
                                    } else {
                                        return -0.0154961529966;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 11.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[82] <= 5.5) {
                                    if (fs[0] <= 7.5) {
                                        return 0.00630440504306;
                                    } else {
                                        return -0.00246543123331;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.00969893712248;
                                    } else {
                                        return 0.000455666655604;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.043756192124;
                                    } else {
                                        return 0.179677513542;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return 0.0235482121733;
                                    } else {
                                        return 0.165166322559;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[86] <= 0.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.0152105169555;
                                    } else {
                                        return 0.0548384539213;
                                    }
                                } else {
                                    if (fs[73] <= 150.0) {
                                        return -0.00196412589971;
                                    } else {
                                        return -0.00604902874561;
                                    }
                                }
                            } else {
                                if (fs[0] <= 10.5) {
                                    if (fs[69] <= 9949.5) {
                                        return -0.00986839530316;
                                    } else {
                                        return -0.0459050825348;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0022731122832;
                                    } else {
                                        return -0.00624659603286;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[2] <= 1.5) {
                if (fs[50] <= -1047.5) {
                    if (fs[71] <= 0.5) {
                        if (fs[37] <= 0.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.10130200015;
                                    } else {
                                        return 0.0239146659802;
                                    }
                                } else {
                                    return 0.348668214041;
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0449443345645;
                                    } else {
                                        return -0.0456001743539;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0534808256678;
                                    } else {
                                        return 0.222952874017;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[82] <= 7.0) {
                                    return 0.0744392507868;
                                } else {
                                    return 0.284622857631;
                                }
                            } else {
                                if (fs[50] <= -1478.0) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.227689490748;
                                    } else {
                                        return 0.160427641223;
                                    }
                                } else {
                                    return 0.374525074019;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[50] <= -1138.0) {
                                if (fs[4] <= 3.5) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0409712437988;
                                    } else {
                                        return 0.101682748182;
                                    }
                                } else {
                                    return 0.0195942861935;
                                }
                            } else {
                                return 0.237094512499;
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return -0.379793215726;
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0682270718922;
                                    } else {
                                        return -0.0955998754708;
                                    }
                                } else {
                                    return 0.076506574577;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[61] <= -995.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[95] <= 1.5) {
                                if (fs[46] <= -1.5) {
                                    return 0.0551756356883;
                                } else {
                                    if (fs[82] <= 1.0) {
                                        return 0.100789075294;
                                    } else {
                                        return 0.281832874046;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return 0.160176933564;
                                } else {
                                    return 0.249220997001;
                                }
                            }
                        } else {
                            return -0.0474511238638;
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[67] <= -3.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0259428101823;
                                    } else {
                                        return 0.0979315869034;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.0138148615539;
                                    } else {
                                        return -0.0707773558656;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0409169724499;
                                    } else {
                                        return -0.00615043871852;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0414004894779;
                                    } else {
                                        return 0.277722783777;
                                    }
                                }
                            }
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0728530461728;
                                    } else {
                                        return -0.0367759426413;
                                    }
                                } else {
                                    return -0.117741445325;
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0772574113978;
                                    } else {
                                        return -0.0184704912283;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.115622800859;
                                    } else {
                                        return -0.000517687918299;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 6.5) {
                    if (fs[0] <= 4.5) {
                        if (fs[97] <= 1.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.100107257635;
                                    } else {
                                        return 0.0520789099847;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.117981273496;
                                    } else {
                                        return 0.278687459599;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1058.0) {
                                    return 0.376997853118;
                                } else {
                                    return 0.111874736262;
                                }
                            }
                        } else {
                            return -0.268685491289;
                        }
                    } else {
                        if (fs[4] <= 5.5) {
                            if (fs[50] <= -1048.0) {
                                if (fs[95] <= 1.0) {
                                    if (fs[0] <= 16.5) {
                                        return 0.0855652947488;
                                    } else {
                                        return 0.288876019748;
                                    }
                                } else {
                                    return 0.527176487996;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[69] <= 9997.5) {
                                        return 0.0383323834067;
                                    } else {
                                        return -0.0977464092272;
                                    }
                                } else {
                                    return 0.0864259158267;
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.0677290362498;
                                    } else {
                                        return -0.0423370753318;
                                    }
                                } else {
                                    return 0.144302782207;
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    return -0.118316908288;
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.139494669181;
                                    } else {
                                        return -0.262750955573;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1408.0) {
                        if (fs[40] <= 0.5) {
                            if (fs[6] <= 0.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.180926646945;
                                    } else {
                                        return -0.195857195987;
                                    }
                                } else {
                                    return -0.376320070055;
                                }
                            } else {
                                if (fs[87] <= 0.5) {
                                    if (fs[52] <= 497.0) {
                                        return 0.0929792478871;
                                    } else {
                                        return 0.378701871395;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.251627672879;
                                    } else {
                                        return -0.0344173352802;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                return 0.250371324811;
                            } else {
                                if (fs[73] <= 150.0) {
                                    if (fs[11] <= 0.5) {
                                        return -0.108263546633;
                                    } else {
                                        return -0.30252916598;
                                    }
                                } else {
                                    return -0.0649430607648;
                                }
                            }
                        }
                    } else {
                        if (fs[61] <= -498.0) {
                            if (fs[67] <= -4.0) {
                                return 0.0468183193472;
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.133666984333;
                                    } else {
                                        return 0.235608242605;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.212949247696;
                                    } else {
                                        return 0.115139155469;
                                    }
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.0677771714267;
                                    } else {
                                        return 0.000945868970538;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.0265800269514;
                                    } else {
                                        return 0.0530720050513;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[50] <= -1108.0) {
                                        return 0.0681288657873;
                                    } else {
                                        return 0.0136303574499;
                                    }
                                } else {
                                    if (fs[7] <= 0.5) {
                                        return -0.0279845790726;
                                    } else {
                                        return -0.221947544269;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
