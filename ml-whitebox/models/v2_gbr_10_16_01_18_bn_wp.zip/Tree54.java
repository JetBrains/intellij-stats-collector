/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree54 {
    public double calcTree(double... fs) {
        if (fs[97] <= 1.5) {
            if (fs[0] <= 0.5) {
                if (fs[50] <= -1513.5) {
                    if (fs[50] <= -2003.5) {
                        if (fs[61] <= -996.5) {
                            return -0.0301754453905;
                        } else {
                            if (fs[67] <= -1.5) {
                                if (fs[50] <= -2048.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.167446826043;
                                    } else {
                                        return 0.110187293104;
                                    }
                                } else {
                                    if (fs[50] <= -2028.5) {
                                        return 0.278690326937;
                                    } else {
                                        return 0.18809205177;
                                    }
                                }
                            } else {
                                return -0.144510270833;
                            }
                        }
                    } else {
                        if (fs[67] <= -1.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[50] <= -1878.0) {
                                    if (fs[86] <= 0.5) {
                                        return 0.237790319981;
                                    } else {
                                        return 0.0506060982549;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.182949924508;
                                    } else {
                                        return 0.104174200247;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[50] <= -1978.0) {
                                        return -0.190576637924;
                                    } else {
                                        return 0.0226440138572;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.146562442482;
                                    } else {
                                        return 0.0685275985316;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[50] <= -1558.0) {
                                    if (fs[75] <= 0.5) {
                                        return 0.0683549419908;
                                    } else {
                                        return -0.158543510988;
                                    }
                                } else {
                                    if (fs[4] <= 27.0) {
                                        return -0.190671786419;
                                    } else {
                                        return -0.180548337667;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    return -0.143327493042;
                                } else {
                                    return -0.39842362221;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[68] <= 0.5) {
                        if (fs[4] <= 10.5) {
                            if (fs[18] <= -0.5) {
                                if (fs[69] <= 4508.0) {
                                    return -0.0449732451005;
                                } else {
                                    return -0.395681695457;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.109225633735;
                                    } else {
                                        return 0.0247611062288;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0386728068687;
                                    } else {
                                        return 0.0700692532374;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0912935516627;
                                    } else {
                                        return -0.0199580582018;
                                    }
                                } else {
                                    if (fs[82] <= 4.5) {
                                        return 0.0142442160113;
                                    } else {
                                        return -0.130715695453;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.120183552474;
                                    } else {
                                        return -0.0715776991727;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.206705737707;
                                    } else {
                                        return 0.125682018148;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0281823214221;
                                    } else {
                                        return -0.176959656609;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.266756703554;
                                    } else {
                                        return 0.0721449172848;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[69] <= 9992.5) {
                                        return -0.0900274714234;
                                    } else {
                                        return 0.0119519176674;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.013807313493;
                                    } else {
                                        return -0.128015349822;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[61] <= -995.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.161441276724;
                                    } else {
                                        return 0.0933496525907;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return 0.0413865023822;
                                    } else {
                                        return -0.172872490538;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[73] <= 150.0) {
                                        return -0.0285706210328;
                                    } else {
                                        return 0.230388830811;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.216805548084;
                                    } else {
                                        return -0.0840536072017;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 2.5) {
                    if (fs[82] <= 6.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[82] <= 5.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.00827575234773;
                                    } else {
                                        return -0.0052808731583;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.0677490074244;
                                    } else {
                                        return 6.78156966095e-05;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0285369778207;
                                    } else {
                                        return -0.0135032259883;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.00915611458805;
                                    } else {
                                        return 0.178897202807;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 11.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[80] <= 0.5) {
                                        return -0.0121170841731;
                                    } else {
                                        return -0.0223043235756;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.190369254238;
                                    } else {
                                        return -0.00613195293208;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    return -0.0116546043929;
                                } else {
                                    return 0.171125489449;
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.0108221947068;
                                    } else {
                                        return -0.0171564012493;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.140800490914;
                                    } else {
                                        return -0.0326065046345;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4799.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.165259248993;
                                    } else {
                                        return -0.042006135041;
                                    }
                                } else {
                                    return 0.374707637873;
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[4] <= 3.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.023437053663;
                                    } else {
                                        return 0.13274656445;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.00491220654907;
                                    } else {
                                        return 0.0704996053198;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.00034642371814;
                                    } else {
                                        return 0.247608807549;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.15190068433;
                                    } else {
                                        return 0.197032455675;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[54] <= 0.5) {
                        if (fs[0] <= 7.5) {
                            if (fs[4] <= 22.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.00116230567188;
                                    } else {
                                        return 0.193189775911;
                                    }
                                } else {
                                    if (fs[2] <= 7.5) {
                                        return -0.00416840991238;
                                    } else {
                                        return 0.0166567559878;
                                    }
                                }
                            } else {
                                if (fs[35] <= 0.5) {
                                    if (fs[77] <= 0.5) {
                                        return -0.00652466837058;
                                    } else {
                                        return -0.0323624389011;
                                    }
                                } else {
                                    return 0.153551867822;
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.0254137990047;
                                    } else {
                                        return -0.0011862766201;
                                    }
                                } else {
                                    if (fs[0] <= 20.5) {
                                        return -0.00338656798097;
                                    } else {
                                        return -0.00417034039427;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.0102545215648;
                                    } else {
                                        return 0.077453199956;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.179041207725;
                                    } else {
                                        return 0.00268713700304;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[82] <= 7.5) {
                                if (fs[73] <= 100.0) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0687779370458;
                                    } else {
                                        return 0.0175048199222;
                                    }
                                } else {
                                    if (fs[4] <= 11.0) {
                                        return 0.167815822874;
                                    } else {
                                        return 0.375877750994;
                                    }
                                }
                            } else {
                                return 0.534838131674;
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[97] <= 0.5) {
                                    return -0.017034087247;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0323380595083;
                                    } else {
                                        return -0.00593188177045;
                                    }
                                }
                            } else {
                                return -0.0349619662619;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[50] <= -1043.0) {
                if (fs[33] <= 0.5) {
                    if (fs[50] <= -1128.0) {
                        if (fs[43] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0145233625927;
                                    } else {
                                        return 0.188159625883;
                                    }
                                } else {
                                    if (fs[50] <= -1143.5) {
                                        return 0.0276961984248;
                                    } else {
                                        return 0.0638688581432;
                                    }
                                }
                            } else {
                                if (fs[0] <= 13.5) {
                                    if (fs[50] <= -1498.0) {
                                        return 0.151937860239;
                                    } else {
                                        return 0.0354981329156;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.465781227605;
                                    } else {
                                        return 0.32145506985;
                                    }
                                }
                            }
                        } else {
                            return 0.15738997801;
                        }
                    } else {
                        if (fs[0] <= 19.5) {
                            if (fs[4] <= 20.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.099731644397;
                                    } else {
                                        return 0.35978198274;
                                    }
                                } else {
                                    if (fs[50] <= -1088.0) {
                                        return 0.052657233327;
                                    } else {
                                        return 0.220808628729;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 24.5) {
                                        return -0.129512534794;
                                    } else {
                                        return -0.301476806126;
                                    }
                                } else {
                                    return 0.183687345792;
                                }
                            }
                        } else {
                            return 0.460891845954;
                        }
                    }
                } else {
                    if (fs[2] <= 8.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[69] <= 9989.5) {
                                if (fs[59] <= -1.5) {
                                    return -0.185082593562;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0530319002804;
                                    } else {
                                        return -0.070127867801;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    return -0.285456998722;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.147716369311;
                                    } else {
                                        return -0.123499604847;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9986.0) {
                                if (fs[4] <= 24.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0290742709012;
                                    } else {
                                        return -0.0121107788063;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0234037222775;
                                    } else {
                                        return 0.0524607031718;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    return -0.0515339584816;
                                } else {
                                    return -0.0860195985459;
                                }
                            }
                        }
                    } else {
                        return 0.312946461351;
                    }
                }
            } else {
                if (fs[44] <= 0.5) {
                    if (fs[4] <= 8.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                return -0.216683415066;
                            } else {
                                return -0.0795394255627;
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.0152409541538;
                                    } else {
                                        return -0.0439481689457;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0521140783226;
                                    } else {
                                        return -0.0858203236314;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    return -0.0817563681739;
                                } else {
                                    return 0.07657245857;
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[4] <= 31.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0254026193698;
                                    } else {
                                        return -0.0372445147431;
                                    }
                                } else {
                                    return 0.0943795135132;
                                }
                            } else {
                                return -0.107002169621;
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[0] <= 0.5) {
                                    return 0.162164505052;
                                } else {
                                    return 0.0994176576289;
                                }
                            } else {
                                if (fs[59] <= -0.5) {
                                    return -0.0625053796403;
                                } else {
                                    return 0.0129212108082;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 30.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[46] <= -1.5) {
                                if (fs[4] <= 14.5) {
                                    return 0.124434150148;
                                } else {
                                    return 0.0123364102785;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0281625962952;
                                    } else {
                                        return -0.0199588165774;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return -0.0374828156268;
                                    } else {
                                        return 0.013617752046;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -998.5) {
                                return -0.0227927004566;
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[50] <= -977.0) {
                                        return -0.00234199573692;
                                    } else {
                                        return -0.0041047839095;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00881048114268;
                                    } else {
                                        return -0.0241633063289;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[4] <= 75.5) {
                                if (fs[4] <= 67.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0155634532149;
                                    } else {
                                        return -0.0055638995112;
                                    }
                                } else {
                                    return 0.056379345857;
                                }
                            } else {
                                return -0.0358372202637;
                            }
                        } else {
                            if (fs[4] <= 33.5) {
                                return 0.0607928703568;
                            } else {
                                if (fs[4] <= 67.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0199363791626;
                                    } else {
                                        return -0.00555032070457;
                                    }
                                } else {
                                    return -0.00520398650874;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
