/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree7 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[39] <= 0.5) {
                if (fs[75] <= 0.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.553058083621;
                                    } else {
                                        return 0.402741422063;
                                    }
                                } else {
                                    if (fs[50] <= -1038.5) {
                                        return 0.653798329766;
                                    } else {
                                        return 0.450003010163;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.657315985824;
                                    } else {
                                        return 0.645206276761;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.257201681896;
                                    } else {
                                        return 0.614930169026;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 25.5) {
                                        return 0.130624960519;
                                    } else {
                                        return -0.0485299227561;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.0464344932168;
                                    } else {
                                        return -0.00125966211452;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.0663186671606;
                                    } else {
                                        return 0.599997246619;
                                    }
                                } else {
                                    if (fs[50] <= -988.0) {
                                        return 0.273554161691;
                                    } else {
                                        return -0.0756567073986;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 10.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.685870307997;
                                    } else {
                                        return 0.343304461033;
                                    }
                                } else {
                                    return 0.0113348835626;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return 0.66737348812;
                                    } else {
                                        return 0.658781220173;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.0456730256982;
                                    } else {
                                        return -0.0184226009495;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 13.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.605324089676;
                                    } else {
                                        return 0.64257120952;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0478501525868;
                                    } else {
                                        return 0.0168167788347;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1568.0) {
                                    if (fs[4] <= 31.5) {
                                        return -0.0161420343928;
                                    } else {
                                        return 0.108062675429;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.057063872036;
                                    } else {
                                        return -0.03672082942;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0910530625035;
                                    } else {
                                        return 0.575995069831;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.330258712048;
                                    } else {
                                        return 0.504165178407;
                                    }
                                }
                            } else {
                                if (fs[82] <= 4.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.307757820802;
                                    } else {
                                        return 0.448023898531;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.00932333981751;
                                    } else {
                                        return 0.280451126656;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[79] <= 0.5) {
                                    if (fs[69] <= 4956.5) {
                                        return 0.166015452685;
                                    } else {
                                        return 0.385330413914;
                                    }
                                } else {
                                    if (fs[50] <= -1488.5) {
                                        return 0.150995339241;
                                    } else {
                                        return -0.019993219042;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.160457278813;
                                    } else {
                                        return 0.278685142785;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.166824015694;
                                    } else {
                                        return 0.636532884348;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[0] <= 2.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0139703886706;
                                    } else {
                                        return 0.0740044254371;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0311918049367;
                                    } else {
                                        return -0.0392253535377;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0861590942145;
                                    } else {
                                        return -0.00608718213253;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.032275695366;
                                    } else {
                                        return 0.00162619781504;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0559389471566;
                                    } else {
                                        return 0.00936126718566;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.106239832127;
                                    } else {
                                        return -0.0443138888011;
                                    }
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0202233465816;
                                    } else {
                                        return 0.00143502352947;
                                    }
                                } else {
                                    if (fs[0] <= 15.5) {
                                        return -0.0306616134653;
                                    } else {
                                        return -0.0373455580025;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[73] <= 250.0) {
                        if (fs[95] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.555934923405;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.648498868999;
                                    } else {
                                        return 0.758457832292;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1012.0) {
                                    if (fs[4] <= 19.5) {
                                        return 0.198183250731;
                                    } else {
                                        return -0.161289431389;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.393942544671;
                                    } else {
                                        return -0.0504535117882;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 1.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -522.0) {
                                        return 0.348268672698;
                                    } else {
                                        return 0.0321001808174;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.567741367397;
                                    } else {
                                        return 0.313991769818;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    return 0.724689085717;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.682286783731;
                                    } else {
                                        return 0.561749712955;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[50] <= -988.5) {
                                        return 0.516327024621;
                                    } else {
                                        return 0.0837267428204;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.311118787649;
                                    } else {
                                        return 0.319249402327;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.56351848231;
                                    } else {
                                        return 0.354092529466;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.612878642084;
                                    } else {
                                        return 0.22492870181;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[59] <= -3.5) {
                                    return -0.0170014647369;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.596746478498;
                                    } else {
                                        return 0.61915275493;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.432281801118;
                                    } else {
                                        return 0.323556372014;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.27423565125;
                                    } else {
                                        return 0.173688973769;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1112.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[73] <= 250.0) {
                                    if (fs[40] <= 0.5) {
                                        return 0.00702021539944;
                                    } else {
                                        return 0.330480025285;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return 0.0629943832969;
                                    } else {
                                        return 0.161537325567;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[97] <= 1.5) {
                                        return 0.392925053628;
                                    } else {
                                        return 0.497470247591;
                                    }
                                } else {
                                    return 0.348790581949;
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[97] <= 1.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.218551479259;
                                    } else {
                                        return 0.00847471915284;
                                    }
                                } else {
                                    if (fs[61] <= -499.0) {
                                        return 0.587467030966;
                                    } else {
                                        return 0.13206166519;
                                    }
                                }
                            } else {
                                if (fs[59] <= -1.5) {
                                    if (fs[4] <= 21.5) {
                                        return 0.566668050927;
                                    } else {
                                        return -0.0092807730512;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.0123933038857;
                                    } else {
                                        return 0.0704581504752;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0244728715542;
                                    } else {
                                        return -0.0403429886145;
                                    }
                                } else {
                                    return 0.243807758057;
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0220935703538;
                                    } else {
                                        return 0.0234256890323;
                                    }
                                } else {
                                    return 0.305466623888;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[50] <= -932.0) {
                                    if (fs[59] <= -2.5) {
                                        return 0.113352712074;
                                    } else {
                                        return -0.0280947950136;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return -0.0437810836782;
                                    } else {
                                        return -0.0379740344292;
                                    }
                                }
                            } else {
                                if (fs[50] <= -972.5) {
                                    if (fs[69] <= 9992.5) {
                                        return -0.0393999147618;
                                    } else {
                                        return -0.00462305839264;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return -0.0067369415526;
                                    } else {
                                        return -0.0411530869913;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[50] <= -1052.5) {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 8.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.542029263818;
                                    } else {
                                        return 0.657339983624;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.361223178057;
                                    } else {
                                        return 0.575495826815;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1478.0) {
                                    if (fs[84] <= 0.5) {
                                        return 0.431409119116;
                                    } else {
                                        return 0.527206616658;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.596154475694;
                                    } else {
                                        return 0.491447726305;
                                    }
                                }
                            }
                        } else {
                            if (fs[29] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.650701146264;
                                    } else {
                                        return 0.60371058664;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.567716104499;
                                    } else {
                                        return 0.432411889863;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    return 0.320284519454;
                                } else {
                                    return 0.179626500707;
                                }
                            }
                        }
                    } else {
                        if (fs[79] <= 0.5) {
                            if (fs[39] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.621025631154;
                                    } else {
                                        return 0.45396979709;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.356257616889;
                                    } else {
                                        return 0.660498896099;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 26.0) {
                                        return 0.542703247786;
                                    } else {
                                        return 0.0307618551964;
                                    }
                                } else {
                                    if (fs[46] <= -1.5) {
                                        return 0.702949945427;
                                    } else {
                                        return 0.596020729215;
                                    }
                                }
                            }
                        } else {
                            if (fs[87] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.386984192207;
                                    } else {
                                        return 0.528516786302;
                                    }
                                } else {
                                    if (fs[4] <= 34.0) {
                                        return 0.622894211304;
                                    } else {
                                        return 0.164956570842;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    return -0.121825549192;
                                } else {
                                    return 0.110247892698;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[79] <= 0.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[4] <= 10.5) {
                                if (fs[0] <= 27.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.122279010621;
                                    } else {
                                        return 0.385234920197;
                                    }
                                } else {
                                    return -0.00583131498433;
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.0919196437664;
                                    } else {
                                        return 0.166855274673;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0107897778639;
                                    } else {
                                        return 0.0724068570325;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[0] <= 16.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.300698925304;
                                    } else {
                                        return 0.118659924058;
                                    }
                                } else {
                                    if (fs[0] <= 39.5) {
                                        return 0.0824660596296;
                                    } else {
                                        return -0.0378272216572;
                                    }
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[50] <= -1128.0) {
                                        return 0.157819421562;
                                    } else {
                                        return 0.671124276709;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.642551011283;
                                    } else {
                                        return 0.326955537239;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 6.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[50] <= -1448.0) {
                                        return 0.128254058776;
                                    } else {
                                        return 0.407812244885;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.279479485706;
                                    } else {
                                        return 0.571625061957;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.525236944549;
                                    } else {
                                        return 0.326604288728;
                                    }
                                } else {
                                    return -0.0645815767037;
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.278179052275;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.542188279013;
                                    } else {
                                        return 0.597294248304;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.18959788775;
                                    } else {
                                        return 0.54042583669;
                                    }
                                } else {
                                    return -0.0967675538198;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[44] <= 0.5) {
                    if (fs[46] <= -0.5) {
                        if (fs[95] <= 1.5) {
                            if (fs[69] <= 9999.5) {
                                return 0.337344617066;
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[82] <= 3.0) {
                                        return 0.60291808925;
                                    } else {
                                        return 0.726656822434;
                                    }
                                } else {
                                    return 0.579819229541;
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[46] <= -1.5) {
                                    return 0.732300135351;
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.714583470184;
                                    } else {
                                        return 0.693104640037;
                                    }
                                }
                            } else {
                                return 0.626514011712;
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[82] <= 5.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.325015003346;
                                    } else {
                                        return 0.530562142911;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.432763841549;
                                    } else {
                                        return 0.283107975267;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.529727886057;
                                    } else {
                                        return 0.242229532382;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.585284744325;
                                    } else {
                                        return 0.670791429071;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0449714515013;
                                    } else {
                                        return 0.148946189256;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.158406886412;
                                    } else {
                                        return 0.529688024385;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.0644623026017;
                                    } else {
                                        return 0.289616823274;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.01308873139;
                                    } else {
                                        return 0.0951734377934;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[12] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            return 0.46001669992;
                        } else {
                            if (fs[2] <= 8.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[94] <= 0.5) {
                                        return -0.039828095767;
                                    } else {
                                        return -0.0684226860394;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0457228067539;
                                    } else {
                                        return 0.0877965697597;
                                    }
                                }
                            } else {
                                return 0.0566858339604;
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[50] <= 13.5) {
                                if (fs[67] <= -3.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0677798187143;
                                    } else {
                                        return -0.0510949858519;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0790260941943;
                                    } else {
                                        return -0.038854196713;
                                    }
                                }
                            } else {
                                return 0.107168088078;
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                return 0.399124136681;
                            } else {
                                if (fs[4] <= 9.5) {
                                    return -0.0517348083483;
                                } else {
                                    return -0.00427271205318;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
