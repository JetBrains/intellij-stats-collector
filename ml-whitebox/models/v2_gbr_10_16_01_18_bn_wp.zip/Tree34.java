/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree34 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 10.5) {
                if (fs[40] <= 0.5) {
                    if (fs[68] <= 0.5) {
                        if (fs[87] <= 0.5) {
                            if (fs[82] <= 1.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[50] <= -1533.5) {
                                        return 0.253712858091;
                                    } else {
                                        return 0.15652586724;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.176236307431;
                                    } else {
                                        return 0.315560863836;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0915453664266;
                                    } else {
                                        return 0.175458294226;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.247210048238;
                                    } else {
                                        return 0.204833937619;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                return -0.181447879613;
                            } else {
                                return -0.429008754847;
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[50] <= -987.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.00430081725169;
                                    } else {
                                        return 0.13261646038;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.158470311626;
                                    } else {
                                        return 0.114510887004;
                                    }
                                }
                            } else {
                                if (fs[59] <= -0.5) {
                                    if (fs[61] <= -498.5) {
                                        return 0.226181695802;
                                    } else {
                                        return 0.0732081058911;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0752130374971;
                                    } else {
                                        return -0.159469969184;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 1.5) {
                                if (fs[69] <= 9985.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0435943302129;
                                    } else {
                                        return -0.225568828038;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0893132214035;
                                    } else {
                                        return 0.320711317199;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0851297413878;
                                    } else {
                                        return 0.128625080103;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.199087120772;
                                    } else {
                                        return -0.425460497854;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[57] <= 0.5) {
                        if (fs[50] <= -1128.0) {
                            if (fs[33] <= 0.5) {
                                if (fs[82] <= 2.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.0438280174042;
                                    } else {
                                        return 0.13131053445;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.0924900207487;
                                    } else {
                                        return 0.248749241655;
                                    }
                                }
                            } else {
                                if (fs[75] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.197764157274;
                                    } else {
                                        return 0.213488707583;
                                    }
                                } else {
                                    return -0.153251699537;
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                return -0.452772214175;
                            } else {
                                if (fs[2] <= 4.5) {
                                    return -0.193507392396;
                                } else {
                                    return -0.0210191077815;
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 75.0) {
                            if (fs[33] <= 0.5) {
                                if (fs[69] <= 4229.0) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0600248734625;
                                    } else {
                                        return -0.202941415384;
                                    }
                                } else {
                                    if (fs[69] <= 9994.0) {
                                        return -0.221663672648;
                                    } else {
                                        return -0.0757545489589;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[75] <= 0.5) {
                                        return -0.0247287001853;
                                    } else {
                                        return -0.125053940693;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return -0.18997383542;
                                    } else {
                                        return 0.0292848196034;
                                    }
                                }
                            }
                        } else {
                            if (fs[65] <= 1.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.0619915251509;
                                    } else {
                                        return -0.0981450392834;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0280944700024;
                                    } else {
                                        return 0.100816626606;
                                    }
                                }
                            } else {
                                return 0.291881298734;
                            }
                        }
                    }
                }
            } else {
                if (fs[11] <= 0.5) {
                    if (fs[50] <= -967.0) {
                        if (fs[56] <= 0.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[61] <= -996.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.19364882211;
                                    } else {
                                        return 0.00262494454913;
                                    }
                                } else {
                                    if (fs[50] <= -1498.5) {
                                        return 0.179809831948;
                                    } else {
                                        return 0.117291093643;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1978.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.344638051209;
                                    } else {
                                        return 0.410564949612;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return -0.0919019744417;
                                    } else {
                                        return 0.148695820738;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.209252076664;
                                    } else {
                                        return -0.0496411114621;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.00393158839222;
                                    } else {
                                        return 0.259253508542;
                                    }
                                }
                            } else {
                                return -0.306354846747;
                            }
                        }
                    } else {
                        if (fs[59] <= -0.5) {
                            if (fs[59] <= -2.5) {
                                if (fs[18] <= 0.5) {
                                    return 0.164648491861;
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.333656921181;
                                    } else {
                                        return 0.265281651616;
                                    }
                                }
                            } else {
                                if (fs[4] <= 23.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.149210189275;
                                    } else {
                                        return 0.417079630492;
                                    }
                                } else {
                                    return -0.209823242819;
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[89] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return -0.00311196003603;
                                    } else {
                                        return 0.406261324245;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.268912272126;
                                    } else {
                                        return 0.120033293144;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.0) {
                                    if (fs[4] <= 24.5) {
                                        return 0.144293274997;
                                    } else {
                                        return -0.275418050855;
                                    }
                                } else {
                                    return 0.38733169853;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 5.5) {
                        if (fs[25] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[69] <= 9731.0) {
                                        return -0.066267339141;
                                    } else {
                                        return 0.156864733946;
                                    }
                                } else {
                                    if (fs[50] <= -1288.0) {
                                        return 0.288505338083;
                                    } else {
                                        return 0.125574192289;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return 0.163018936763;
                                    } else {
                                        return -0.040481505501;
                                    }
                                } else {
                                    if (fs[46] <= -0.5) {
                                        return 0.298418306552;
                                    } else {
                                        return 0.0224092491005;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9998.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[50] <= -1523.0) {
                                        return 0.138027423325;
                                    } else {
                                        return -0.0764356644376;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.166089659582;
                                    } else {
                                        return -0.00149236030284;
                                    }
                                }
                            } else {
                                if (fs[82] <= 4.0) {
                                    if (fs[50] <= -1898.0) {
                                        return 0.303100322196;
                                    } else {
                                        return 0.142599243728;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.160019561793;
                                    } else {
                                        return 0.381369738401;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 1.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0693341420846;
                                    } else {
                                        return 0.190300953821;
                                    }
                                } else {
                                    if (fs[50] <= -1438.0) {
                                        return 0.272563049657;
                                    } else {
                                        return -0.0390586943734;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0332676773439;
                                    } else {
                                        return -0.311229514798;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.13047118054;
                                    } else {
                                        return -0.26256298534;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 5.0) {
                                if (fs[50] <= -1468.0) {
                                    if (fs[69] <= 9985.0) {
                                        return 0.44462938849;
                                    } else {
                                        return 0.345738771869;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.311842134064;
                                    } else {
                                        return 0.145888644233;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[2] <= 8.5) {
                                        return -0.0418409773226;
                                    } else {
                                        return 0.231090186628;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.401993322371;
                                    } else {
                                        return 0.18019795015;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[84] <= 0.5) {
                if (fs[69] <= 9982.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0123376229888;
                                    } else {
                                        return 0.0423029897043;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0202537252527;
                                    } else {
                                        return 0.0154499329995;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9762.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0132576452152;
                                    } else {
                                        return 0.0649317653535;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.0504639078344;
                                    } else {
                                        return -0.0690924287765;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.0170168002782;
                                    } else {
                                        return 0.0572997015343;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.158325347585;
                                    } else {
                                        return 0.0481693093985;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[69] <= 8685.5) {
                                        return 0.0742440071208;
                                    } else {
                                        return -0.0850420159693;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.247302954553;
                                    } else {
                                        return 0.183981822997;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[34] <= 0.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0105562822184;
                                    } else {
                                        return -0.00749891308457;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return 0.00721008224839;
                                    } else {
                                        return -0.00967160084015;
                                    }
                                }
                            } else {
                                if (fs[59] <= -2.5) {
                                    return 0.174848983335;
                                } else {
                                    if (fs[0] <= 120.5) {
                                        return -0.0108808992454;
                                    } else {
                                        return -0.00624382648019;
                                    }
                                }
                            }
                        } else {
                            return 0.406209101953;
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[50] <= -1108.0) {
                            if (fs[37] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return 0.0607155699646;
                                    } else {
                                        return 0.227019323067;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.335713920419;
                                    } else {
                                        return -0.0249867477095;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9992.5) {
                                    return 0.487031037733;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.35899829577;
                                    } else {
                                        return 0.110265367611;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.00708047680556;
                                    } else {
                                        return 0.0692166827127;
                                    }
                                } else {
                                    if (fs[50] <= -1.0) {
                                        return -0.0878896399298;
                                    } else {
                                        return 0.063147325759;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0176504259408;
                                    } else {
                                        return 0.189946522791;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.171234985003;
                                    } else {
                                        return -0.128015054833;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1418.0) {
                            if (fs[50] <= -1488.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0848126404861;
                                    } else {
                                        return 0.24146755934;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.0166722607963;
                                    } else {
                                        return 0.159710835033;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[69] <= 9988.5) {
                                        return -0.000852868523528;
                                    } else {
                                        return 0.120889240015;
                                    }
                                } else {
                                    if (fs[69] <= 9986.5) {
                                        return 0.550076319723;
                                    } else {
                                        return 0.263153453878;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.0527587595007;
                                    } else {
                                        return 0.115673927521;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.00204980375732;
                                    } else {
                                        return 0.129381998273;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.0123332976927;
                                    } else {
                                        return -0.0117275329915;
                                    }
                                } else {
                                    if (fs[69] <= 9983.5) {
                                        return 0.0775117401701;
                                    } else {
                                        return -0.0207469404315;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1438.0) {
                    if (fs[0] <= 1.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[77] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.108129493799;
                                    } else {
                                        return -0.139514575692;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.0815504278697;
                                    } else {
                                        return 0.158061973405;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0164773052504;
                                    } else {
                                        return 0.243065998628;
                                    }
                                } else {
                                    if (fs[69] <= 9973.5) {
                                        return -0.0153618997932;
                                    } else {
                                        return -0.0895040395134;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.182909529727;
                                    } else {
                                        return -0.00671249280743;
                                    }
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return 0.297700264941;
                                    } else {
                                        return 0.179871777864;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9982.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.332993284753;
                                    } else {
                                        return 0.110660071868;
                                    }
                                } else {
                                    if (fs[4] <= 31.0) {
                                        return 0.0530450198803;
                                    } else {
                                        return -0.16412901524;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 11.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.0939849715975;
                                    } else {
                                        return -0.0356120380375;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0256712848406;
                                    } else {
                                        return 0.406600128855;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.18755094888;
                                    } else {
                                        return 0.364130686281;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0536912773525;
                                    } else {
                                        return 0.149484037557;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[61] <= -995.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.137093909594;
                                    } else {
                                        return 0.196620728535;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.0149085491566;
                                    } else {
                                        return -0.0117362031019;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0286900693245;
                                    } else {
                                        return 0.19603000708;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.266500493273;
                                    } else {
                                        return 0.0175586351694;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[59] <= -1.5) {
                                    if (fs[2] <= 7.5) {
                                        return 0.139516763718;
                                    } else {
                                        return -0.126414226223;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0136667746858;
                                    } else {
                                        return 0.104535353207;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[46] <= -2.5) {
                                        return 0.21790049238;
                                    } else {
                                        return 0.00209665298647;
                                    }
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return 0.0705476429474;
                                    } else {
                                        return -0.016677717328;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[8] <= 0.5) {
                                    if (fs[97] <= 1.5) {
                                        return 0.0274627869998;
                                    } else {
                                        return 0.0736251627892;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0287042171081;
                                    } else {
                                        return 0.391972580063;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.0414330598511;
                                    } else {
                                        return -0.00773808223588;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.00286192263428;
                                    } else {
                                        return -0.0150486868573;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.00738850026995;
                                    } else {
                                        return 0.0684257800863;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0146928577128;
                                    } else {
                                        return -0.0214613239201;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0297190558599;
                                    } else {
                                        return -0.0195754885586;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.0923235943345;
                                    } else {
                                        return -0.0486308821216;
                                    }
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[50] <= -1112.0) {
                                        return -0.0348654610145;
                                    } else {
                                        return -0.0142816662352;
                                    }
                                } else {
                                    if (fs[50] <= 7.5) {
                                        return -0.0413784301415;
                                    } else {
                                        return 0.0613895432559;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[0] <= 8.5) {
                                        return -0.0125724387708;
                                    } else {
                                        return -0.0108303914265;
                                    }
                                } else {
                                    if (fs[59] <= -2.5) {
                                        return 0.0308791030132;
                                    } else {
                                        return -0.0101339150477;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
