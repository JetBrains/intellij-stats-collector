/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree83 {
    public double calcTree(double... fs) {
        if (fs[11] <= 0.5) {
            if (fs[73] <= 75.0) {
                if (fs[0] <= 1.5) {
                    if (fs[95] <= 0.5) {
                        if (fs[50] <= -1208.5) {
                            if (fs[50] <= -1488.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0317392766214;
                                    } else {
                                        return 0.0374648101167;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0404349505272;
                                    } else {
                                        return 0.200930700309;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9820.0) {
                                    if (fs[40] <= 0.5) {
                                        return -0.0494338966315;
                                    } else {
                                        return 0.0318030175847;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.250505049042;
                                    } else {
                                        return 0.00660303654108;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[8] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.00903807259903;
                                    } else {
                                        return 0.0290212616532;
                                    }
                                } else {
                                    return -0.160372118904;
                                }
                            } else {
                                if (fs[86] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0386582573443;
                                    } else {
                                        return 0.0014119742169;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return -0.00940428093307;
                                    } else {
                                        return -0.0895432845555;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= 0.5) {
                            if (fs[61] <= -997.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0504349520569;
                                    } else {
                                        return 0.107967187102;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.10391176244;
                                    } else {
                                        return -0.174017991065;
                                    }
                                }
                            } else {
                                if (fs[4] <= 42.5) {
                                    if (fs[50] <= -1043.0) {
                                        return 0.0485903602687;
                                    } else {
                                        return 0.0116229718275;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.204603501483;
                                    } else {
                                        return -0.0748553387291;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[69] <= 9830.5) {
                                    if (fs[4] <= 18.0) {
                                        return -0.070408624213;
                                    } else {
                                        return 0.114307983317;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.335440877375;
                                    } else {
                                        return -0.195421021365;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    return 0.162635894353;
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0754275050159;
                                    } else {
                                        return 0.0757410294902;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 8.5) {
                        if (fs[69] <= 9196.0) {
                            if (fs[78] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[67] <= -3.5) {
                                        return 0.134521473778;
                                    } else {
                                        return -0.00569086762399;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.034606118671;
                                    } else {
                                        return 0.344453393265;
                                    }
                                }
                            } else {
                                if (fs[13] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.00302249221612;
                                    } else {
                                        return 0.024000201786;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0322779033667;
                                    } else {
                                        return 0.088666196194;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1128.0) {
                                if (fs[69] <= 9458.0) {
                                    return 0.304130990017;
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0864210323429;
                                    } else {
                                        return 0.0103445537412;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0537895089549;
                                    } else {
                                        return 0.0257471285807;
                                    }
                                } else {
                                    if (fs[69] <= 9668.0) {
                                        return 0.177768974905;
                                    } else {
                                        return -0.0237048911724;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[54] <= 0.5) {
                            if (fs[69] <= 9998.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 44.5) {
                                        return 0.000865861897876;
                                    } else {
                                        return -0.00363161501842;
                                    }
                                } else {
                                    if (fs[0] <= 11.5) {
                                        return -0.000131356912475;
                                    } else {
                                        return -0.00234126760438;
                                    }
                                }
                            } else {
                                if (fs[0] <= 39.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0178428889685;
                                    } else {
                                        return -0.0486072005233;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.00979003956958;
                                    } else {
                                        return -0.0798702202718;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 23.5) {
                                return 0.202656668543;
                            } else {
                                return -0.0309156598368;
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1418.0) {
                    if (fs[62] <= 0.5) {
                        if (fs[4] <= 8.5) {
                            if (fs[69] <= 9870.0) {
                                if (fs[0] <= 0.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.0888300354052;
                                    } else {
                                        return 0.0339298725862;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.113763298955;
                                    } else {
                                        return 0.326182104063;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    return 0.207876628331;
                                } else {
                                    if (fs[69] <= 9920.5) {
                                        return -0.143489012807;
                                    } else {
                                        return 0.0397209546755;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1488.0) {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.0462313324303;
                                    } else {
                                        return 0.0543152841532;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.00961410344617;
                                    } else {
                                        return 0.0186715287099;
                                    }
                                }
                            } else {
                                if (fs[4] <= 24.5) {
                                    if (fs[0] <= 6.5) {
                                        return 0.063484377352;
                                    } else {
                                        return 0.172491439152;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0188907222248;
                                    } else {
                                        return 0.11065803022;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9999.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[69] <= 9780.5) {
                                        return -0.141586291345;
                                    } else {
                                        return 0.0880545169427;
                                    }
                                } else {
                                    return -0.277709978748;
                                }
                            } else {
                                if (fs[69] <= 9905.0) {
                                    if (fs[82] <= 6.5) {
                                        return 0.00290921246104;
                                    } else {
                                        return -0.0971870353162;
                                    }
                                } else {
                                    return 0.14885684234;
                                }
                            }
                        } else {
                            return -0.342861712608;
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[69] <= 4316.0) {
                            if (fs[0] <= 15.5) {
                                if (fs[73] <= 250.0) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0124908212655;
                                    } else {
                                        return 0.0375240612928;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.0116567188164;
                                    } else {
                                        return 0.218312305092;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[0] <= 150.5) {
                                        return -0.0196495218769;
                                    } else {
                                        return 0.148373426404;
                                    }
                                } else {
                                    if (fs[0] <= 59.0) {
                                        return 0.0187418237063;
                                    } else {
                                        return 0.379829606313;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 250.0) {
                                if (fs[43] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return -0.146241310015;
                                    } else {
                                        return -0.0388608253208;
                                    }
                                } else {
                                    return 0.140283374903;
                                }
                            } else {
                                if (fs[7] <= 0.5) {
                                    if (fs[95] <= 1.0) {
                                        return 0.19283452502;
                                    } else {
                                        return 0.0252614886037;
                                    }
                                } else {
                                    return -0.179530271067;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    return 0.0826034029451;
                                } else {
                                    return 0.0980658177951;
                                }
                            } else {
                                return 0.0666116804779;
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.00428341220721;
                                    } else {
                                        return -0.0127965415593;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0134789859201;
                                    } else {
                                        return -0.0245588073064;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9997.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.00262997705779;
                                    } else {
                                        return 0.0116412747208;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0331723931882;
                                    } else {
                                        return 0.0230590717239;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[69] <= 9999.5) {
                if (fs[23] <= 0.5) {
                    if (fs[4] <= 3.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[50] <= -1143.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.019207323075;
                                    } else {
                                        return -0.0794623156517;
                                    }
                                } else {
                                    if (fs[50] <= -1478.5) {
                                        return 0.118132795447;
                                    } else {
                                        return -0.0499963422379;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[69] <= 9902.5) {
                                        return 0.0305394966475;
                                    } else {
                                        return -0.0311082858828;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0338096827917;
                                    } else {
                                        return 0.131573695136;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 3.5) {
                                if (fs[69] <= 9995.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.0278280738655;
                                    } else {
                                        return -0.00321965590766;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0621981413822;
                                    } else {
                                        return 0.0340751332742;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.00196436883844;
                                    } else {
                                        return -0.0431347955724;
                                    }
                                } else {
                                    if (fs[0] <= 32.5) {
                                        return 0.0226437952059;
                                    } else {
                                        return 0.127558794807;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[27] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.00252400424797;
                                    } else {
                                        return -0.000835808593991;
                                    }
                                } else {
                                    return 0.254580216915;
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0211459584904;
                                    } else {
                                        return 0.138831921616;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.093955373342;
                                    } else {
                                        return -0.12178703076;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[2] <= 8.5) {
                                        return 0.0080930693421;
                                    } else {
                                        return 0.04279362876;
                                    }
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return 0.0269670279525;
                                    } else {
                                        return -0.0623092172301;
                                    }
                                }
                            } else {
                                if (fs[69] <= 8724.0) {
                                    if (fs[97] <= 1.5) {
                                        return -0.000227770544296;
                                    } else {
                                        return 0.0218743248425;
                                    }
                                } else {
                                    if (fs[69] <= 8746.5) {
                                        return 0.446558320638;
                                    } else {
                                        return 0.0096852421188;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1113.5) {
                        if (fs[4] <= 15.0) {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0567121826625;
                                    } else {
                                        return 0.131955067674;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.26998704188;
                                    } else {
                                        return 0.245414792993;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return 0.109538043851;
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.0671544799564;
                                    } else {
                                        return 0.34865938559;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return -0.0997332188335;
                            } else {
                                return 0.123520865786;
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            return 0.213566167808;
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[69] <= 9876.0) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0213821791283;
                                    } else {
                                        return -0.0144596607296;
                                    }
                                } else {
                                    return -0.172924295686;
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.135361596787;
                                    } else {
                                        return 0.00581573893954;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0377841479678;
                                    } else {
                                        return -0.00991335690546;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1098.5) {
                    if (fs[4] <= 30.5) {
                        if (fs[82] <= -0.5) {
                            return -0.465204110446;
                        } else {
                            if (fs[50] <= -1123.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[4] <= 22.5) {
                                        return 0.0454941926998;
                                    } else {
                                        return 0.208467793448;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return 0.0243814578999;
                                    } else {
                                        return -0.324499459798;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.031190995899;
                                    } else {
                                        return 0.152345228707;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.158464059947;
                                    } else {
                                        return 0.353402434598;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                return -0.401203043646;
                            } else {
                                return -0.182101061368;
                            }
                        } else {
                            return -0.0967024189465;
                        }
                    }
                } else {
                    if (fs[68] <= 0.5) {
                        if (fs[82] <= 5.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[67] <= -4.5) {
                                    if (fs[4] <= 11.5) {
                                        return -0.032610574995;
                                    } else {
                                        return 0.117274153143;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0265904765349;
                                    } else {
                                        return -0.0776561920118;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    return -0.282986494143;
                                } else {
                                    return 0.00508101449883;
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.179831036129;
                                    } else {
                                        return 0.200910947167;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0952467050235;
                                    } else {
                                        return 0.0532043556863;
                                    }
                                }
                            } else {
                                return -0.03997512131;
                            }
                        }
                    } else {
                        if (fs[6] <= 0.5) {
                            return -0.224049595872;
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0681869385209;
                                    } else {
                                        return -0.0162785906423;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0480410003516;
                                    } else {
                                        return 0.028629105803;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[50] <= -978.0) {
                                        return -0.0456321230816;
                                    } else {
                                        return -0.0955480431108;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.00328586298301;
                                    } else {
                                        return -0.0570242626723;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
