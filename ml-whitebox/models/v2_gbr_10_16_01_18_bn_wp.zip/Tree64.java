/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree64 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 3.5) {
                    if (fs[25] <= 0.5) {
                        if (fs[54] <= 0.5) {
                            if (fs[50] <= -861.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[50] <= -1142.5) {
                                        return 0.0264973577794;
                                    } else {
                                        return 0.0530368358174;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0453368209963;
                                    } else {
                                        return -0.0904171814751;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0209430512383;
                                    } else {
                                        return -0.107329757271;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.0124660051838;
                                    } else {
                                        return -0.222591823868;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -994.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.0339588163609;
                                    } else {
                                        return -0.0646289138024;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.0242285493476;
                                    } else {
                                        return 0.158629843024;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.170396726286;
                                    } else {
                                        return 0.259144431784;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.150187999688;
                                    } else {
                                        return 0.153223957094;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[87] <= 0.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0475472191039;
                                    } else {
                                        return 0.0976652749008;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.102456568466;
                                    } else {
                                        return 0.0100179609667;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1473.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.164158173582;
                                    } else {
                                        return -0.290369015982;
                                    }
                                } else {
                                    return 0.0620384172619;
                                }
                            }
                        } else {
                            if (fs[4] <= 14.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[42] <= 0.5) {
                                        return 0.117535336444;
                                    } else {
                                        return 0.0430131840213;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.0786684497797;
                                    } else {
                                        return 0.0673892481915;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9993.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0836856608462;
                                    } else {
                                        return 0.00919427467444;
                                    }
                                } else {
                                    return -0.292423505145;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 8.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[4] <= 27.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.052161543642;
                                    } else {
                                        return -0.299147843499;
                                    }
                                } else {
                                    if (fs[50] <= -1468.5) {
                                        return 0.0384619648159;
                                    } else {
                                        return -0.0627209066058;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1978.0) {
                                    return 0.123567325832;
                                } else {
                                    if (fs[4] <= 28.5) {
                                        return -0.238620822689;
                                    } else {
                                        return -0.0422380512484;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[2] <= 5.5) {
                                    return -0.153109121903;
                                } else {
                                    return -0.352054130899;
                                }
                            } else {
                                return 0.0923457754603;
                            }
                        }
                    } else {
                        if (fs[67] <= -3.5) {
                            if (fs[95] <= 0.5) {
                                return 0.238181882109;
                            } else {
                                if (fs[91] <= 0.5) {
                                    return 0.146696253897;
                                } else {
                                    return 0.215784270594;
                                }
                            }
                        } else {
                            if (fs[69] <= 9993.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.0727456339669;
                                    } else {
                                        return 0.133023178476;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return -0.0860771420464;
                                    } else {
                                        return 0.100073664804;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9995.5) {
                                    return -0.342131523714;
                                } else {
                                    return -0.0196870580543;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 2.5) {
                    if (fs[82] <= 6.5) {
                        if (fs[82] <= 5.5) {
                            if (fs[4] <= 19.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[95] <= 1.5) {
                                        return -0.0018475650882;
                                    } else {
                                        return 0.0249729357757;
                                    }
                                } else {
                                    if (fs[50] <= -1408.0) {
                                        return 0.0435500463504;
                                    } else {
                                        return 0.0016924317015;
                                    }
                                }
                            } else {
                                if (fs[59] <= -1.5) {
                                    if (fs[4] <= 36.5) {
                                        return 0.0907950579039;
                                    } else {
                                        return -0.091516943726;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return -0.00941146430033;
                                    } else {
                                        return 0.0469208816139;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[69] <= 9836.5) {
                                        return -0.0144996334673;
                                    } else {
                                        return -0.0492043644528;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.0857687218246;
                                    } else {
                                        return 0.0304468020185;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 20.5) {
                                        return -0.0293607364;
                                    } else {
                                        return 0.0431461354288;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return 0.194380706635;
                                    } else {
                                        return 0.0397552440384;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 6.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[69] <= 9995.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0123508124429;
                                    } else {
                                        return 0.0485537038167;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0543409697893;
                                    } else {
                                        return -0.166442546407;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0203431136281;
                                    } else {
                                        return 0.1816266371;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.0117729923057;
                                    } else {
                                        return -0.292681968609;
                                    }
                                }
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[50] <= -1418.0) {
                                    if (fs[2] <= 5.5) {
                                        return -0.00283064958131;
                                    } else {
                                        return 0.106930068297;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.00591096409306;
                                    } else {
                                        return -0.0224982502053;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[50] <= -1363.0) {
                                        return 0.135452216399;
                                    } else {
                                        return -0.0166439507507;
                                    }
                                } else {
                                    if (fs[50] <= -1258.0) {
                                        return 0.225177964172;
                                    } else {
                                        return 0.0564504544866;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 22.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[46] <= -2.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.141588897359;
                                    } else {
                                        return 0.0756053755048;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.00196622713955;
                                    } else {
                                        return 0.000316438460155;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.00702348598993;
                                    } else {
                                        return -0.00400693936963;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.00219218798023;
                                    } else {
                                        return -0.00336367139759;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0155020325282;
                                    } else {
                                        return 0.126951791908;
                                    }
                                } else {
                                    if (fs[69] <= 9993.5) {
                                        return 0.0071617345912;
                                    } else {
                                        return -0.0722551185301;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.0188403351934;
                                    } else {
                                        return 0.254511889638;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0365197638082;
                                    } else {
                                        return 0.0235324283595;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 6.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[42] <= 0.5) {
                                    if (fs[59] <= -2.5) {
                                        return 0.0581800534369;
                                    } else {
                                        return -0.00631542905271;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return -0.0299545985684;
                                    } else {
                                        return 0.0999852509385;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.12667123187;
                                    } else {
                                        return -0.00861276297845;
                                    }
                                } else {
                                    if (fs[50] <= -1123.0) {
                                        return 0.0089779000895;
                                    } else {
                                        return -0.0156182104511;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9864.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[0] <= 19.5) {
                                        return -0.00336704168821;
                                    } else {
                                        return -0.0024001450822;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.00669131037076;
                                    } else {
                                        return -0.00320686453537;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0765049075882;
                                    } else {
                                        return -0.0331015009379;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return 0.0109636108812;
                                    } else {
                                        return -0.0124587529814;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[50] <= -1088.5) {
                if (fs[88] <= 0.5) {
                    if (fs[63] <= 5.0) {
                        if (fs[87] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[50] <= -1133.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0159852818979;
                                    } else {
                                        return 0.047579133952;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0628200243482;
                                    } else {
                                        return 0.128577730893;
                                    }
                                }
                            } else {
                                if (fs[82] <= 2.5) {
                                    if (fs[52] <= 998.0) {
                                        return 0.192310646718;
                                    } else {
                                        return 0.283777416333;
                                    }
                                } else {
                                    return 0.11313841467;
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                return -0.233932957335;
                            } else {
                                if (fs[73] <= 150.0) {
                                    if (fs[0] <= 0.5) {
                                        return -0.129644944273;
                                    } else {
                                        return -0.222671139743;
                                    }
                                } else {
                                    return -0.0587732226506;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            return -0.136659018717;
                        } else {
                            return -0.265167451312;
                        }
                    }
                } else {
                    if (fs[79] <= 0.5) {
                        if (fs[73] <= 150.0) {
                            return -0.376258029258;
                        } else {
                            return 0.177672634957;
                        }
                    } else {
                        if (fs[50] <= -1488.0) {
                            if (fs[4] <= 29.5) {
                                if (fs[82] <= 7.0) {
                                    if (fs[82] <= 0.5) {
                                        return 0.155271269116;
                                    } else {
                                        return 0.264237682902;
                                    }
                                } else {
                                    return -0.0206361905259;
                                }
                            } else {
                                return -0.325805973662;
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0484467353587;
                                    } else {
                                        return 0.199789029792;
                                    }
                                } else {
                                    return 0.240634936056;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.39938172423;
                                    } else {
                                        return 0.302152270823;
                                    }
                                } else {
                                    return 0.326919473507;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[82] <= 1.5) {
                    if (fs[61] <= -995.5) {
                        if (fs[73] <= 250.0) {
                            if (fs[4] <= 9.5) {
                                if (fs[95] <= 0.5) {
                                    return 0.000138559442149;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.084552743303;
                                    } else {
                                        return 0.127587384596;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    return 0.219015641282;
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.0797896904303;
                                    } else {
                                        return 0.16958382017;
                                    }
                                }
                            }
                        } else {
                            return 0.0102555569529;
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0830792215355;
                                    } else {
                                        return -0.00228057104456;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.241695670892;
                                    } else {
                                        return 0.0139447888098;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.00783372796756;
                                    } else {
                                        return 0.241861569691;
                                    }
                                } else {
                                    return -0.0248519485197;
                                }
                            }
                        } else {
                            if (fs[7] <= 0.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.00418366504952;
                                    } else {
                                        return 0.0927913279473;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.0487358858416;
                                    } else {
                                        return 0.0294974867993;
                                    }
                                }
                            } else {
                                return -0.203316352499;
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[68] <= 0.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[4] <= 15.0) {
                                    if (fs[4] <= 13.5) {
                                        return 0.0822966163145;
                                    } else {
                                        return 0.329609275661;
                                    }
                                } else {
                                    if (fs[82] <= 7.0) {
                                        return -0.257211948227;
                                    } else {
                                        return 0.15040583804;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return 0.0270421461263;
                                } else {
                                    if (fs[50] <= 3.5) {
                                        return -0.0271032987727;
                                    } else {
                                        return -0.00570735009883;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[82] <= 5.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0320834935759;
                                    } else {
                                        return -0.0219078437709;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.271357904782;
                                    } else {
                                        return 0.0464457769057;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0329823522718;
                                    } else {
                                        return -0.0187827330759;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.00683487618007;
                                    } else {
                                        return -0.0428535944179;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0742140374714;
                                    } else {
                                        return 0.0288355552975;
                                    }
                                } else {
                                    return -0.0762858867966;
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return 0.0758121709564;
                                } else {
                                    if (fs[82] <= 4.5) {
                                        return 0.259283240622;
                                    } else {
                                        return 0.146052532258;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                return -0.0334424796998;
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[69] <= 9997.5) {
                                        return 0.0856854596912;
                                    } else {
                                        return 0.114317368879;
                                    }
                                } else {
                                    return 0.0162951394139;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
