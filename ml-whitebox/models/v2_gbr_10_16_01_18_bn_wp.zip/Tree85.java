/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree85 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[50] <= -1513.5) {
                if (fs[4] <= 36.5) {
                    if (fs[67] <= -1.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[50] <= -1583.5) {
                                        return 0.0609686055977;
                                    } else {
                                        return 0.146197744039;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.0434883172928;
                                    } else {
                                        return -0.0258462643828;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4699.0) {
                                    if (fs[73] <= 25.0) {
                                        return -0.083037589122;
                                    } else {
                                        return 0.0952866088456;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.148850147673;
                                    } else {
                                        return -0.0433919540965;
                                    }
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0707483038929;
                                    } else {
                                        return 0.165716802267;
                                    }
                                } else {
                                    if (fs[50] <= -1608.0) {
                                        return 0.141292396339;
                                    } else {
                                        return 0.299702277644;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[2] <= 8.5) {
                                        return 0.097995092175;
                                    } else {
                                        return -0.211149610675;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.195925016558;
                                    } else {
                                        return 0.0609615782262;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[75] <= 0.5) {
                            return -0.000183049391352;
                        } else {
                            if (fs[95] <= 1.0) {
                                return -0.159194904336;
                            } else {
                                return -0.240337467094;
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1978.0) {
                        if (fs[4] <= 48.5) {
                            if (fs[12] <= 0.5) {
                                return 0.0987598103519;
                            } else {
                                return 0.239090728953;
                            }
                        } else {
                            return -0.212230294293;
                        }
                    } else {
                        if (fs[91] <= 0.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[4] <= 44.5) {
                                    return -0.000622205658558;
                                } else {
                                    return -0.0968709420235;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return -0.133517256378;
                                } else {
                                    return -0.352805435393;
                                }
                            }
                        } else {
                            return -0.303856184993;
                        }
                    }
                }
            } else {
                if (fs[37] <= 0.5) {
                    if (fs[54] <= 0.5) {
                        if (fs[4] <= 8.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.01916854299;
                                    } else {
                                        return 0.00608444721295;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.0586145184867;
                                    } else {
                                        return 0.0168026987115;
                                    }
                                }
                            } else {
                                if (fs[50] <= -977.0) {
                                    if (fs[50] <= -1478.5) {
                                        return 0.0274012816585;
                                    } else {
                                        return 0.0873407389579;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0256369493127;
                                    } else {
                                        return 0.0497797205409;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 4.5) {
                                if (fs[61] <= -996.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.0378094494165;
                                    } else {
                                        return 0.205053008969;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.00917162091275;
                                    } else {
                                        return 0.0284806493611;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[50] <= -1488.0) {
                                        return -0.17929607331;
                                    } else {
                                        return -0.00599173128213;
                                    }
                                } else {
                                    if (fs[69] <= 9804.0) {
                                        return -0.0394100125962;
                                    } else {
                                        return 0.0300679639725;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    return 0.142487683443;
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.0963311919823;
                                    } else {
                                        return -0.0269409269791;
                                    }
                                }
                            } else {
                                return -0.201291560107;
                            }
                        } else {
                            if (fs[46] <= -0.5) {
                                if (fs[95] <= 0.5) {
                                    return -0.0909002324157;
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.111567189194;
                                    } else {
                                        return 0.058001813956;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0499718125909;
                                    } else {
                                        return 0.142473910347;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.188861808762;
                                    } else {
                                        return 0.0965760303064;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[73] <= 25.0) {
                        if (fs[4] <= 23.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[69] <= 9383.5) {
                                    if (fs[50] <= -1478.0) {
                                        return -0.224538261755;
                                    } else {
                                        return -0.0621882359685;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0241860741839;
                                    } else {
                                        return 0.0651822058985;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1242.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.29900669607;
                                    } else {
                                        return 0.138437445432;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0565606574371;
                                    } else {
                                        return -0.0193780608253;
                                    }
                                }
                            }
                        } else {
                            return -0.41876257749;
                        }
                    } else {
                        if (fs[50] <= -481.5) {
                            if (fs[50] <= -1458.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 27.5) {
                                        return -0.014162496524;
                                    } else {
                                        return 0.240267917384;
                                    }
                                } else {
                                    if (fs[4] <= 26.0) {
                                        return 0.110059410676;
                                    } else {
                                        return -0.297335493302;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    return 0.252084750197;
                                } else {
                                    return 0.311786006378;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0384665763229;
                                    } else {
                                        return -0.138025575157;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.0253288126729;
                                    } else {
                                        return 0.138351524308;
                                    }
                                }
                            } else {
                                if (fs[82] <= 3.0) {
                                    if (fs[4] <= 12.5) {
                                        return 0.0341738635179;
                                    } else {
                                        return 0.128287103176;
                                    }
                                } else {
                                    return 0.0708796012803;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[52] <= 0.5) {
                if (fs[50] <= -4913.0) {
                    return 0.149960606062;
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[34] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.000617893638562;
                                    } else {
                                        return 0.0296399634072;
                                    }
                                } else {
                                    if (fs[69] <= 9925.5) {
                                        return -0.00222798763148;
                                    } else {
                                        return -0.0144447122109;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.00161386625219;
                                    } else {
                                        return 0.0493693099313;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -5.96358798588e-05;
                                    } else {
                                        return -0.00133698327856;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 5.0) {
                                    return 0.0948448494214;
                                } else {
                                    return 0.0823474109127;
                                }
                            } else {
                                return 0.112196625652;
                            }
                        }
                    } else {
                        if (fs[69] <= 8690.0) {
                            if (fs[95] <= 1.5) {
                                if (fs[75] <= 0.5) {
                                    if (fs[50] <= -1128.0) {
                                        return 0.133157106681;
                                    } else {
                                        return -0.0339256351128;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.000791000196223;
                                    } else {
                                        return 0.00686643949594;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.0149479123276;
                                    } else {
                                        return 0.107446388921;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.00131930826967;
                                    } else {
                                        return 0.173648535336;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 8730.5) {
                                if (fs[2] <= 4.5) {
                                    return 0.103571537064;
                                } else {
                                    return 0.546711853482;
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.00978743452805;
                                    } else {
                                        return 0.0665343816627;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0214761367442;
                                    } else {
                                        return 0.0132596091662;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[64] <= 0.5) {
                        return 0.103352118264;
                    } else {
                        return 0.263631462211;
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[43] <= 0.5) {
                            if (fs[69] <= 9989.5) {
                                return -0.0450661289342;
                            } else {
                                return 0.396291184224;
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                return 0.0825951385933;
                            } else {
                                if (fs[4] <= 12.5) {
                                    return -0.0363893314654;
                                } else {
                                    if (fs[0] <= 12.5) {
                                        return -0.0230880327447;
                                    } else {
                                        return -0.0180956865331;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 996.5) {
                            if (fs[4] <= 21.0) {
                                return -0.0214277588725;
                            } else {
                                return -0.00984505993593;
                            }
                        } else {
                            return -0.0439259210685;
                        }
                    }
                }
            }
        }
    }
}
