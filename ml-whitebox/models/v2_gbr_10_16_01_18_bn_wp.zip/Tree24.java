/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree24 {
    public double calcTree(double... fs) {
        if (fs[4] <= 7.5) {
            if (fs[91] <= 0.5) {
                if (fs[69] <= 9969.5) {
                    if (fs[75] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.235170541198;
                                    } else {
                                        return 0.119584522155;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.260149936342;
                                    } else {
                                        return 0.298103717142;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.0206228344363;
                                    } else {
                                        return 0.170976493788;
                                    }
                                } else {
                                    if (fs[50] <= -988.0) {
                                        return 0.0091836472373;
                                    } else {
                                        return -0.0287155262495;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.236060775962;
                                    } else {
                                        return -0.0466314938149;
                                    }
                                } else {
                                    return -0.103010552826;
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.283576400926;
                                    } else {
                                        return 0.0704991760062;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.319383043586;
                                    } else {
                                        return 0.112264843422;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.268998524553;
                                    } else {
                                        return 0.0582370016736;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.1724686112;
                                    } else {
                                        return 0.000191118682387;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0522418151831;
                                    } else {
                                        return 0.0429314357717;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.0586917215471;
                                    } else {
                                        return 0.324016632079;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0017121722724;
                                    } else {
                                        return -0.0155492428512;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0421265908202;
                                    } else {
                                        return -0.00320489981442;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1458.0) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0562927611926;
                                    } else {
                                        return 0.230391188194;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0310757730915;
                                    } else {
                                        return -0.0133880446045;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9999.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1488.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0474629146909;
                                    } else {
                                        return 0.334463810731;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.136137519276;
                                    } else {
                                        return 0.245208439971;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.289361877629;
                                    } else {
                                        return 0.206834206122;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.243302219708;
                                    } else {
                                        return 0.022513476479;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.16557667479;
                                    } else {
                                        return 0.0492294570456;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.19280328262;
                                    } else {
                                        return -0.0427280544436;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0247678748403;
                                    } else {
                                        return 0.105829288057;
                                    }
                                } else {
                                    if (fs[0] <= 20.5) {
                                        return 0.00999126510703;
                                    } else {
                                        return -0.0213120215677;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1098.5) {
                            if (fs[0] <= 7.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.320122626595;
                                    } else {
                                        return 0.237594755788;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.183784050617;
                                    } else {
                                        return 0.234413989175;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    return -0.0767740868399;
                                } else {
                                    return 0.0184678818738;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[50] <= 3.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.343134977581;
                                    } else {
                                        return 0.243198510381;
                                    }
                                } else {
                                    return -0.0160512466053;
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.202940928736;
                                    } else {
                                        return 0.0501620181128;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.430016705184;
                                    } else {
                                        return 0.161359996276;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[39] <= 0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[50] <= -1068.5) {
                            if (fs[29] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0630621136918;
                                    } else {
                                        return 0.226801766088;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.201852218909;
                                    } else {
                                        return 0.316161672109;
                                    }
                                }
                            } else {
                                return -0.128658509789;
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[56] <= 0.5) {
                                        return -0.0539104946178;
                                    } else {
                                        return -0.0110807037788;
                                    }
                                } else {
                                    return 0.069893797278;
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.235674720961;
                                    } else {
                                        return -0.00230946375968;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0540686350109;
                                    } else {
                                        return -0.0208975543844;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[55] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.20740904691;
                                    } else {
                                        return 0.0709649426524;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.18746994968;
                                    } else {
                                        return -0.0633270779211;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[2] <= 2.5) {
                                        return 0.494311247859;
                                    } else {
                                        return 0.445111913024;
                                    }
                                } else {
                                    return 0.297693977593;
                                }
                            }
                        } else {
                            if (fs[0] <= 63.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0295007013479;
                                    } else {
                                        return -0.0569410647844;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.020666186464;
                                    } else {
                                        return 0.212217275269;
                                    }
                                }
                            } else {
                                return 0.304479431008;
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[16] <= 0.5) {
                                        return 0.207352592567;
                                    } else {
                                        return 0.0630497169106;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0501055962361;
                                    } else {
                                        return 0.283948729801;
                                    }
                                }
                            } else {
                                if (fs[59] <= -0.5) {
                                    if (fs[55] <= 0.5) {
                                        return 0.291316046136;
                                    } else {
                                        return 0.245979971017;
                                    }
                                } else {
                                    if (fs[50] <= -977.5) {
                                        return 0.256273664828;
                                    } else {
                                        return -0.0355303589944;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[50] <= -1093.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0972165859056;
                                    } else {
                                        return 0.0353920653563;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0809001365129;
                                    } else {
                                        return 0.0129526650739;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[69] <= 9994.5) {
                                        return -0.0183541709185;
                                    } else {
                                        return -0.0223803046117;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0796228458186;
                                    } else {
                                        return -0.0170267089946;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.268995770408;
                                    } else {
                                        return 0.216165675385;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.287190132666;
                                    } else {
                                        return 0.149915149024;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.118387331185;
                                    } else {
                                        return 0.18691216213;
                                    }
                                } else {
                                    if (fs[69] <= 4996.0) {
                                        return 0.0279395092657;
                                    } else {
                                        return 0.194995691947;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0410399002813;
                                    } else {
                                        return -0.0188495596966;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0510662557025;
                                    } else {
                                        return -0.0219483164381;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    return 0.048594155567;
                                } else {
                                    return -0.0256800027652;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[69] <= 9996.5) {
                if (fs[84] <= 0.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[61] <= -995.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 21.5) {
                                    if (fs[54] <= 0.5) {
                                        return 0.256344541131;
                                    } else {
                                        return 0.424372451326;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.119966577616;
                                    } else {
                                        return 0.130112053308;
                                    }
                                }
                            } else {
                                if (fs[59] <= -2.5) {
                                    return 0.281788189808;
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return -0.0335982199481;
                                    } else {
                                        return -0.00168265837287;
                                    }
                                }
                            }
                        } else {
                            if (fs[80] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.256216384693;
                                    } else {
                                        return 0.116333309462;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.00918721404689;
                                    } else {
                                        return -0.0204746713694;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.14358093568;
                                    } else {
                                        return 0.0501351675661;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.0286246363316;
                                    } else {
                                        return -0.0194936889558;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[69] <= 9833.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0892418602125;
                                    } else {
                                        return -0.0150704473796;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.153320935662;
                                    } else {
                                        return 0.000392686409894;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.0174909896141;
                                    } else {
                                        return -0.0229903293651;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return -0.0129879329624;
                                    } else {
                                        return 0.311588971331;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 8689.0) {
                                if (fs[73] <= 25.0) {
                                    if (fs[75] <= 0.5) {
                                        return 0.29840739345;
                                    } else {
                                        return -0.00891064904191;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.165352625608;
                                    } else {
                                        return 0.0231213812166;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.287264289263;
                                    } else {
                                        return 0.109439050379;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.189087321727;
                                    } else {
                                        return 0.0119865178991;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[97] <= 1.5) {
                        if (fs[50] <= -1393.0) {
                            if (fs[0] <= 0.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return 0.254768823309;
                                    } else {
                                        return -0.335596281693;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.000987814203407;
                                    } else {
                                        return 0.13724892989;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.00217320319789;
                                    } else {
                                        return 0.0646694356324;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0747683204135;
                                    } else {
                                        return 0.169680334869;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.149318581957;
                                    } else {
                                        return 0.0108019813534;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.39659547465;
                                    } else {
                                        return 0.239468716526;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[50] <= -22.0) {
                                        return 0.253520918135;
                                    } else {
                                        return -0.196168296294;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.0210443166251;
                                    } else {
                                        return -0.0185519905386;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.261584282326;
                                    } else {
                                        return 0.21031174937;
                                    }
                                } else {
                                    if (fs[46] <= -0.5) {
                                        return 0.335403157685;
                                    } else {
                                        return 0.115707318273;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1068.0) {
                                    if (fs[61] <= -994.5) {
                                        return 0.247259787382;
                                    } else {
                                        return 0.0571184443315;
                                    }
                                } else {
                                    if (fs[64] <= 0.5) {
                                        return -0.0173594657498;
                                    } else {
                                        return 0.00615918410131;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 8.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.124378417341;
                                    } else {
                                        return -0.0222551605308;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0218933656331;
                                    } else {
                                        return 0.046741165601;
                                    }
                                }
                            } else {
                                return 0.233954793082;
                            }
                        }
                    }
                }
            } else {
                if (fs[79] <= 0.5) {
                    if (fs[68] <= 0.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[50] <= -1057.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.343031170153;
                                    } else {
                                        return 0.182945216229;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.176501265418;
                                    } else {
                                        return -0.0147567196427;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.114762686909;
                                    } else {
                                        return -0.00742332167266;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.149341629711;
                                    } else {
                                        return 0.0143563639625;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.317989717757;
                                    } else {
                                        return 0.258509586388;
                                    }
                                } else {
                                    if (fs[4] <= 15.0) {
                                        return 0.45309904452;
                                    } else {
                                        return 0.34380884952;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    return 0.00923858414495;
                                } else {
                                    return -0.0508888458008;
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.140304477006;
                                    } else {
                                        return 0.208571674645;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.200693661645;
                                    } else {
                                        return 0.0894089185879;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.00789939761358;
                                    } else {
                                        return 0.286875318178;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0370569687358;
                                    } else {
                                        return 0.244379247631;
                                    }
                                }
                            }
                        } else {
                            if (fs[65] <= 1.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0187649334445;
                                    } else {
                                        return 0.00195149824101;
                                    }
                                } else {
                                    return 0.166562771302;
                                }
                            } else {
                                return 0.18259289884;
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9999.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[18] <= -0.5) {
                                return -0.305147947899;
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.10996687138;
                                    } else {
                                        return 0.245136902938;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.0230703785056;
                                    } else {
                                        return -0.329611748323;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1097.5) {
                                if (fs[50] <= -1458.0) {
                                    if (fs[87] <= 0.5) {
                                        return 0.0867493743812;
                                    } else {
                                        return -0.186994436733;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.408603971613;
                                    } else {
                                        return 0.241282025193;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0721076178141;
                                    } else {
                                        return 0.0874773689489;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.0299711057887;
                                    } else {
                                        return 0.00323399719296;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1398.0) {
                            if (fs[50] <= -1478.0) {
                                if (fs[63] <= 5.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.298988644512;
                                    } else {
                                        return 0.197257526711;
                                    }
                                } else {
                                    return -0.224168828744;
                                }
                            } else {
                                if (fs[82] <= 5.0) {
                                    if (fs[4] <= 10.5) {
                                        return 0.17481029395;
                                    } else {
                                        return 0.433428550244;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.457644561743;
                                    } else {
                                        return 0.0425979162365;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[37] <= 0.5) {
                                    return -0.0834863399442;
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.381702226607;
                                    } else {
                                        return 0.153819370856;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0800327992268;
                                    } else {
                                        return 0.323065403922;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0231903275952;
                                    } else {
                                        return -0.0395613911126;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
