/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree18 {
    public double calcTree(double... fs) {
        if (fs[97] <= 1.5) {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[50] <= -987.0) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.255495434408;
                                    } else {
                                        return 0.379288794618;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.110652220165;
                                    } else {
                                        return 0.218620500076;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0751865224876;
                                    } else {
                                        return 0.270827858758;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.0743791194972;
                                    } else {
                                        return 0.297326979766;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 1.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[82] <= -0.5) {
                                        return 0.0114341628873;
                                    } else {
                                        return -0.0329541162805;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0764443724069;
                                    } else {
                                        return -0.181387266894;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1088.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.227345288701;
                                    } else {
                                        return 0.354841203892;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.487122000074;
                                    } else {
                                        return 0.128135818176;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[92] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[50] <= -1588.0) {
                                    if (fs[2] <= 0.5) {
                                        return -0.134637035906;
                                    } else {
                                        return 0.355478255442;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return 0.352582221683;
                                    } else {
                                        return 0.0710737595263;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.314835822027;
                                    } else {
                                        return 0.41967259605;
                                    }
                                } else {
                                    if (fs[50] <= -1503.0) {
                                        return 0.338126197478;
                                    } else {
                                        return 0.170387413457;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[50] <= -1108.0) {
                                        return 0.394550274759;
                                    } else {
                                        return 0.00127975253986;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.00167834211273;
                                    } else {
                                        return 0.0891752337906;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9979.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.393531415702;
                                    } else {
                                        return 0.23281260954;
                                    }
                                } else {
                                    if (fs[50] <= -531.5) {
                                        return 0.411610185544;
                                    } else {
                                        return 0.231917610662;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[75] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[50] <= -1443.5) {
                                if (fs[50] <= -1568.0) {
                                    if (fs[4] <= 40.5) {
                                        return 0.163322531831;
                                    } else {
                                        return -0.15367251991;
                                    }
                                } else {
                                    return -0.160114698505;
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.360990665378;
                                    } else {
                                        return 0.381737180936;
                                    }
                                } else {
                                    return 0.13584091776;
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[4] <= 2.5) {
                                    return 0.0266646205703;
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.383754984563;
                                    } else {
                                        return 0.183527415944;
                                    }
                                }
                            } else {
                                return -0.0117730879815;
                            }
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[69] <= 9844.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.152854214946;
                                    } else {
                                        return 0.264212924746;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.361258071084;
                                    } else {
                                        return 0.261490501334;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[50] <= -1458.0) {
                                        return 0.287733459646;
                                    } else {
                                        return 0.364787074459;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.371833525508;
                                    } else {
                                        return 0.192369099133;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[50] <= -1423.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.12840282309;
                                    } else {
                                        return 0.339049610988;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.328008840918;
                                    } else {
                                        return -0.0860486973727;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[4] <= 26.5) {
                                        return 0.375589326865;
                                    } else {
                                        return 0.0148543860884;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.331169592099;
                                    } else {
                                        return 0.132330413968;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[50] <= -1478.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.0887669622972;
                                    } else {
                                        return 0.189868519474;
                                    }
                                } else {
                                    if (fs[63] <= 5.0) {
                                        return 0.0360930158901;
                                    } else {
                                        return -0.0963688946116;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0629618506419;
                                    } else {
                                        return 0.0208466330533;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0480719020348;
                                    } else {
                                        return 0.0384246637339;
                                    }
                                }
                            }
                        } else {
                            if (fs[83] <= 0.5) {
                                if (fs[47] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.0270230070655;
                                    } else {
                                        return 0.103028883626;
                                    }
                                } else {
                                    return 0.0806983364845;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -941.5) {
                                        return -0.0209669673347;
                                    } else {
                                        return -0.0526894290364;
                                    }
                                } else {
                                    if (fs[52] <= -0.5) {
                                        return -0.0530129456903;
                                    } else {
                                        return -0.0502958445167;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[82] <= 7.5) {
                                if (fs[91] <= 0.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.0919955798829;
                                    } else {
                                        return 0.00956778853689;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.157526745822;
                                    } else {
                                        return 0.00348418412696;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1298.0) {
                                    if (fs[4] <= 5.5) {
                                        return -0.197131030072;
                                    } else {
                                        return 0.320958177759;
                                    }
                                } else {
                                    if (fs[69] <= 9989.5) {
                                        return -0.0390886245656;
                                    } else {
                                        return 0.151988996376;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 4.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.00382822247729;
                                    } else {
                                        return 0.0394629663698;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.023737578636;
                                    } else {
                                        return -0.0339137221275;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0387072741061;
                                    } else {
                                        return -0.0159990169331;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.105419862777;
                                    } else {
                                        return 0.265832310877;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 4.5) {
                        if (fs[69] <= 9974.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0695767130461;
                                    } else {
                                        return -0.00711270379201;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0189802124483;
                                    } else {
                                        return -0.022155196952;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[82] <= 1.5) {
                                        return -0.0286509289334;
                                    } else {
                                        return -0.0191804835765;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.000598008625479;
                                    } else {
                                        return 0.112421221003;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0215459109465;
                                    } else {
                                        return -0.0254996974247;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.092679079074;
                                    } else {
                                        return 0.364823253706;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0192184689187;
                                    } else {
                                        return 0.106005244665;
                                    }
                                } else {
                                    if (fs[69] <= 9996.5) {
                                        return 0.0773013550791;
                                    } else {
                                        return 0.266705182461;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9977.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[0] <= 9.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.0186993416673;
                                    } else {
                                        return -0.0120217341291;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0229984758003;
                                    } else {
                                        return -0.0205721146367;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.025857045921;
                                    } else {
                                        return -0.024381934665;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.0282849302266;
                                    } else {
                                        return -0.0265062632026;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.022861526835;
                                    } else {
                                        return 0.161185553301;
                                    }
                                } else {
                                    if (fs[50] <= -1057.0) {
                                        return -0.0557160530996;
                                    } else {
                                        return -0.0266629607818;
                                    }
                                }
                            } else {
                                if (fs[0] <= 81.0) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0212448523596;
                                    } else {
                                        return -0.0172860399089;
                                    }
                                } else {
                                    return 0.364668727045;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[33] <= 0.5) {
                    if (fs[46] <= -0.5) {
                        if (fs[61] <= -996.5) {
                            if (fs[55] <= 0.5) {
                                if (fs[61] <= -998.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.390308356621;
                                    } else {
                                        return 0.395433002848;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.376636402736;
                                    } else {
                                        return 0.416704349143;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    return 0.42943492366;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.354536718512;
                                    } else {
                                        return 0.250960788407;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 19.5) {
                                if (fs[4] <= 17.5) {
                                    return 0.146253610372;
                                } else {
                                    return 0.0591628535878;
                                }
                            } else {
                                if (fs[61] <= -995.5) {
                                    return 0.468836294657;
                                } else {
                                    return 0.483298056563;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -987.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.278395508371;
                                    } else {
                                        return 0.355074284395;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0702387021766;
                                    } else {
                                        return 0.401125101508;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 20.5) {
                                        return 0.353967182802;
                                    } else {
                                        return 0.180475572664;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.24205294507;
                                    } else {
                                        return 0.0907201107577;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                return -0.248564750345;
                            } else {
                                if (fs[50] <= 4.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.172068232032;
                                    } else {
                                        return -0.158043912436;
                                    }
                                } else {
                                    return 0.385013163448;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[4] <= 9.5) {
                            if (fs[57] <= 0.5) {
                                return -0.111585302961;
                            } else {
                                return -0.214875914059;
                            }
                        } else {
                            if (fs[55] <= 0.5) {
                                return -0.0597087758323;
                            } else {
                                return 0.128473162688;
                            }
                        }
                    } else {
                        if (fs[50] <= -1012.0) {
                            if (fs[4] <= 11.5) {
                                return 0.0982771980947;
                            } else {
                                return -0.0712759513216;
                            }
                        } else {
                            return 0.469170104908;
                        }
                    }
                }
            } else {
                if (fs[50] <= -1068.0) {
                    if (fs[33] <= 0.5) {
                        if (fs[0] <= 12.5) {
                            if (fs[50] <= -1088.5) {
                                if (fs[61] <= -996.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.326363217904;
                                    } else {
                                        return 0.0821313265308;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0755157339533;
                                    } else {
                                        return 0.519959927151;
                                    }
                                }
                            } else {
                                return 0.704929683573;
                            }
                        } else {
                            if (fs[61] <= -498.0) {
                                return 0.66467598617;
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.17991069425;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.477770057442;
                                    } else {
                                        return 0.542559040689;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 7.5) {
                            if (fs[4] <= 24.5) {
                                if (fs[69] <= 9997.0) {
                                    if (fs[40] <= 0.5) {
                                        return -0.0509259790028;
                                    } else {
                                        return 0.00195973766854;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return -0.111892149041;
                                    } else {
                                        return -0.085281488205;
                                    }
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    if (fs[75] <= 0.5) {
                                        return -0.0161605302277;
                                    } else {
                                        return -0.0600267953552;
                                    }
                                } else {
                                    if (fs[4] <= 36.5) {
                                        return 0.130457441424;
                                    } else {
                                        return -0.0332323030737;
                                    }
                                }
                            }
                        } else {
                            return 0.268385053316;
                        }
                    }
                } else {
                    if (fs[7] <= 0.5) {
                        if (fs[67] <= -4.0) {
                            return 0.0510699671126;
                        } else {
                            if (fs[46] <= -2.5) {
                                if (fs[12] <= 0.5) {
                                    return 0.150511293022;
                                } else {
                                    if (fs[55] <= 0.5) {
                                        return 0.0576092951757;
                                    } else {
                                        return -0.0608290130046;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4953.0) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0360919389971;
                                    } else {
                                        return -0.0232927013138;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0702738331295;
                                    } else {
                                        return -0.0314553744711;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            return 0.0812620379349;
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[0] <= 4.5) {
                                    return 0.00448068754614;
                                } else {
                                    return -0.0298928261905;
                                }
                            } else {
                                return -0.0417268585847;
                            }
                        }
                    }
                }
            }
        }
    }
}
