/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree82 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[50] <= -1498.5) {
                    if (fs[50] <= -1923.5) {
                        if (fs[50] <= -1983.5) {
                            if (fs[50] <= -2418.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0869298540587;
                                    } else {
                                        return 0.0551949991534;
                                    }
                                } else {
                                    if (fs[82] <= 1.0) {
                                        return -0.0432914357985;
                                    } else {
                                        return 0.227574810028;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[69] <= 9990.0) {
                                        return 0.198894818394;
                                    } else {
                                        return 0.0784633175328;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.135784371781;
                                    } else {
                                        return 0.060154914709;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0308296933768;
                                    } else {
                                        return 0.0494075856966;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.0478950690365;
                                    } else {
                                        return 0.14338769001;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4337.5) {
                                    if (fs[82] <= 1.5) {
                                        return -0.257621528984;
                                    } else {
                                        return 0.0698134667675;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.174215457796;
                                    } else {
                                        return -0.0408425042803;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1553.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0826667481931;
                                    } else {
                                        return 0.00935345439166;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0764203682382;
                                    } else {
                                        return 0.13211201829;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    return 0.088990562022;
                                } else {
                                    return -0.0730746510338;
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                return 0.228734384696;
                            } else {
                                if (fs[91] <= 0.5) {
                                    return 0.0630955922446;
                                } else {
                                    return 0.169121528113;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[54] <= 0.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.00974320797646;
                                    } else {
                                        return -0.0342146546062;
                                    }
                                } else {
                                    if (fs[50] <= -1488.5) {
                                        return 0.0395099254392;
                                    } else {
                                        return 0.0192071895021;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.00505203931218;
                                    } else {
                                        return -0.0592992302514;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.047026099525;
                                    } else {
                                        return -0.0901552969576;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 14.5) {
                                if (fs[50] <= -546.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.133689951717;
                                    } else {
                                        return 0.099283540378;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return 0.105574816587;
                                    } else {
                                        return -0.135838124848;
                                    }
                                }
                            } else {
                                return -0.238450003491;
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[61] <= -996.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0565150326014;
                                    } else {
                                        return -0.0824165975127;
                                    }
                                } else {
                                    return 0.122109416366;
                                }
                            } else {
                                return -0.252733657363;
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[61] <= -498.0) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0104657570003;
                                    } else {
                                        return 0.0966804386072;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.186783885668;
                                    } else {
                                        return 0.0874418159677;
                                    }
                                }
                            } else {
                                if (fs[82] <= 3.0) {
                                    return -0.0135434842139;
                                } else {
                                    return 0.142350050674;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 12.5) {
                    if (fs[50] <= -2423.5) {
                        if (fs[4] <= 22.5) {
                            if (fs[50] <= -3363.5) {
                                return -0.44786321607;
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.0127195929777;
                                    } else {
                                        return 0.150264394759;
                                    }
                                } else {
                                    return -0.0417149268022;
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.0218963184791;
                                    } else {
                                        return 0.14974095458;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.0703512474;
                                    } else {
                                        return 0.173539287401;
                                    }
                                }
                            } else {
                                return -0.0387551232977;
                            }
                        }
                    } else {
                        if (fs[4] <= 27.5) {
                            if (fs[95] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0316667814267;
                                    } else {
                                        return -0.127854148491;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.0866015765134;
                                    } else {
                                        return 0.110826382781;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1438.0) {
                                    if (fs[67] <= -4.5) {
                                        return -0.254331449164;
                                    } else {
                                        return -0.0191184720802;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.0972705727691;
                                    } else {
                                        return 0.0114621856751;
                                    }
                                }
                            }
                        } else {
                            if (fs[96] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[67] <= -4.5) {
                                        return 0.105475196543;
                                    } else {
                                        return -0.0775699239872;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.00826874884184;
                                    } else {
                                        return 0.229601570345;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9976.5) {
                                    if (fs[56] <= 0.5) {
                                        return -0.170320042764;
                                    } else {
                                        return 0.0826560670167;
                                    }
                                } else {
                                    if (fs[69] <= 9996.5) {
                                        return 0.32790191518;
                                    } else {
                                        return 0.216532750769;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[95] <= 1.5) {
                        if (fs[73] <= 25.0) {
                            return 0.24721940549;
                        } else {
                            return 0.0885762645772;
                        }
                    } else {
                        if (fs[56] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                return 0.0585831197066;
                            } else {
                                return 0.142766132143;
                            }
                        } else {
                            return -0.0360771458642;
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[14] <= 0.5) {
                    if (fs[48] <= 0.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.00613766674775;
                                    } else {
                                        return -0.00900546973149;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.00682990776492;
                                    } else {
                                        return -0.0730803528689;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[82] <= 4.0) {
                                        return 0.146012440031;
                                    } else {
                                        return -0.0258218510104;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.280804557381;
                                    } else {
                                        return -0.0246442485962;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.00861815647649;
                                    } else {
                                        return -0.0111731320034;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.0455600630649;
                                    } else {
                                        return -0.0937636587851;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.000553857461345;
                                    } else {
                                        return 0.0221064053267;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0788768258407;
                                    } else {
                                        return 0.00777894528862;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[82] <= 2.0) {
                                if (fs[50] <= -1128.5) {
                                    if (fs[95] <= 1.5) {
                                        return -0.119908937761;
                                    } else {
                                        return 0.0291044647007;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return -0.0254302331931;
                                    } else {
                                        return 0.0186488174023;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0983645157627;
                                    } else {
                                        return 0.105632818396;
                                    }
                                } else {
                                    return 0.203591631366;
                                }
                            }
                        } else {
                            if (fs[50] <= -561.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.526589313418;
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.178991380637;
                                    } else {
                                        return 0.0147471753297;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return 0.15750458087;
                                } else {
                                    return 0.0557293384514;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 7.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.00496235615519;
                                    } else {
                                        return -0.140103088582;
                                    }
                                } else {
                                    return 0.189885396708;
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.306284075902;
                                    } else {
                                        return 0.123931636626;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.00513944812944;
                                    } else {
                                        return -0.0717250163828;
                                    }
                                }
                            }
                        } else {
                            return -0.154404698459;
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            return 0.362301491181;
                        } else {
                            return 0.110367450088;
                        }
                    }
                }
            } else {
                if (fs[46] <= -2.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[61] <= -995.5) {
                            if (fs[2] <= 1.5) {
                                return 0.0258004214204;
                            } else {
                                return 0.359495442236;
                            }
                        } else {
                            return -0.0227339720968;
                        }
                    } else {
                        if (fs[61] <= -996.5) {
                            return 0.0550789339459;
                        } else {
                            if (fs[50] <= -252.0) {
                                if (fs[11] <= 0.5) {
                                    return -0.0400215581946;
                                } else {
                                    return -0.0291809237829;
                                }
                            } else {
                                if (fs[61] <= -995.5) {
                                    return -0.0246564171833;
                                } else {
                                    return -0.00881202226282;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[52] <= 0.5) {
                        if (fs[34] <= 0.5) {
                            if (fs[73] <= 350.0) {
                                if (fs[4] <= 25.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.000281827845119;
                                    } else {
                                        return -0.0011711865074;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0080050890316;
                                    } else {
                                        return -0.00169959879355;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.014095119317;
                                    } else {
                                        return -0.03862974958;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return -0.00724544669251;
                                    } else {
                                        return 0.0767755898318;
                                    }
                                }
                            }
                        } else {
                            return 0.143622484744;
                        }
                    } else {
                        if (fs[69] <= 9989.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.225259155896;
                                    } else {
                                        return 0.00634626259889;
                                    }
                                } else {
                                    return -0.0201103280676;
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    return -0.0743630766723;
                                } else {
                                    return -0.0126454721689;
                                }
                            }
                        } else {
                            return 0.178855063055;
                        }
                    }
                }
            }
        }
    }
}
