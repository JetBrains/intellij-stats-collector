/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree89 {
    public double calcTree(double... fs) {
        if (fs[46] <= -1.5) {
            if (fs[44] <= 0.5) {
                if (fs[33] <= 0.5) {
                    if (fs[61] <= -995.5) {
                        if (fs[50] <= -1313.5) {
                            if (fs[50] <= -1568.5) {
                                return -0.110542995516;
                            } else {
                                return -0.189188179137;
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[50] <= -1128.0) {
                                        return 0.0239696053883;
                                    } else {
                                        return -0.124754378201;
                                    }
                                } else {
                                    return -0.193545151458;
                                }
                            } else {
                                if (fs[50] <= -1038.0) {
                                    if (fs[4] <= 25.0) {
                                        return 0.0467198364056;
                                    } else {
                                        return 0.226638784024;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0256777564557;
                                    } else {
                                        return -0.11471320055;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[61] <= -994.5) {
                            return -0.225156583091;
                        } else {
                            return 0.0341385774491;
                        }
                    }
                } else {
                    if (fs[61] <= -996.5) {
                        if (fs[50] <= -1028.0) {
                            if (fs[93] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[69] <= 4995.5) {
                                        return 0.180855895717;
                                    } else {
                                        return 0.211760537724;
                                    }
                                } else {
                                    return 0.632716443194;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.163044953271;
                                    } else {
                                        return 0.11727362754;
                                    }
                                } else {
                                    return 0.00332788987108;
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0571146669131;
                                    } else {
                                        return 0.000558909585732;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.148583650596;
                                    } else {
                                        return 0.0606525160299;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    return -0.0887561720174;
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.0183109279502;
                                    } else {
                                        return 0.0250901238801;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[59] <= -2.5) {
                            if (fs[73] <= 250.0) {
                                if (fs[54] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.0905836583042;
                                    } else {
                                        return 0.184306744461;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0624902558;
                                    } else {
                                        return 0.0435939895053;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    return 0.0877014749392;
                                } else {
                                    if (fs[55] <= 0.5) {
                                        return -0.0153667585811;
                                    } else {
                                        return -0.159547828663;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return 0.105693765804;
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0417099991098;
                                    } else {
                                        return 0.00536169311871;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.110387082068;
                                    } else {
                                        return -0.0449258128678;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 23.5) {
                    if (fs[55] <= 0.5) {
                        if (fs[33] <= 0.5) {
                            if (fs[50] <= -976.0) {
                                return 0.107769192114;
                            } else {
                                if (fs[59] <= -2.5) {
                                    return -0.0426533918618;
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return -0.00758439969457;
                                    } else {
                                        return -0.00978447070248;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[97] <= 1.5) {
                                    if (fs[4] <= 20.5) {
                                        return -0.0139468155275;
                                    } else {
                                        return 0.0281530380196;
                                    }
                                } else {
                                    return 0.0380532398062;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0143581227865;
                                    } else {
                                        return -0.0206358110863;
                                    }
                                } else {
                                    return -0.0125200031415;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 15.5) {
                            if (fs[39] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    return -0.0176214653009;
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.00915395601315;
                                    } else {
                                        return -0.00598598543359;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    return -0.0294423303813;
                                } else {
                                    return -0.00838330279365;
                                }
                            }
                        } else {
                            if (fs[59] <= -2.5) {
                                if (fs[0] <= 4.0) {
                                    return -0.0678944342995;
                                } else {
                                    return -0.0228097140644;
                                }
                            } else {
                                return -0.015634490595;
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        return 0.0785176290038;
                    } else {
                        if (fs[59] <= -2.5) {
                            return -0.0177671031447;
                        } else {
                            return -0.00310442870386;
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[50] <= -1498.5) {
                    if (fs[2] <= 0.5) {
                        return -0.182610783813;
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[86] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.0929821678783;
                                    } else {
                                        return 0.067329512368;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.228802828172;
                                    } else {
                                        return 0.0918319521809;
                                    }
                                }
                            } else {
                                if (fs[67] <= -1.5) {
                                    if (fs[82] <= 2.5) {
                                        return 0.0257214073503;
                                    } else {
                                        return 0.114646076095;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return -0.018443361091;
                                    } else {
                                        return -0.136044387609;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 8.5) {
                                if (fs[59] <= -0.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.133160150505;
                                    } else {
                                        return 0.193880723114;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.0855821928009;
                                    } else {
                                        return 0.0441938086219;
                                    }
                                }
                            } else {
                                return -0.137411543525;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 14.5) {
                        if (fs[68] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[50] <= -1483.5) {
                                    if (fs[73] <= 150.0) {
                                        return -0.000469260438042;
                                    } else {
                                        return -0.275957759775;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.0169542942732;
                                    } else {
                                        return 0.0890850455131;
                                    }
                                }
                            } else {
                                if (fs[87] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.0786612480018;
                                    } else {
                                        return 0.0413458418609;
                                    }
                                } else {
                                    return -0.30150958881;
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[50] <= -987.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.00846339106319;
                                    } else {
                                        return -0.0146345102897;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.0533695735234;
                                    } else {
                                        return -0.0157701636394;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[82] <= 2.5) {
                                        return 0.0263442406062;
                                    } else {
                                        return -0.0365916568404;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0334511357002;
                                    } else {
                                        return 0.140794332121;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 1.5) {
                            if (fs[69] <= 9803.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.0663480352763;
                                    } else {
                                        return 0.00388180045415;
                                    }
                                } else {
                                    if (fs[4] <= 28.5) {
                                        return -0.00199803435388;
                                    } else {
                                        return 0.303001040499;
                                    }
                                }
                            } else {
                                if (fs[82] <= -0.5) {
                                    return -0.425729384943;
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return -0.353823237173;
                                    } else {
                                        return 0.00664783448523;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.005377328457;
                                    } else {
                                        return 0.11152690938;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.331350899241;
                                    } else {
                                        return -0.056736011322;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    return 0.127564019096;
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.259903269829;
                                    } else {
                                        return -0.0616679383372;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[52] <= 0.5) {
                    if (fs[34] <= 0.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[38] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return -0.00055565321846;
                                    } else {
                                        return 0.00716914412461;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0510960402215;
                                    } else {
                                        return -0.0144042510829;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0882050517166;
                                    } else {
                                        return 0.149011732557;
                                    }
                                } else {
                                    return -0.0156153429762;
                                }
                            }
                        } else {
                            if (fs[54] <= 0.5) {
                                if (fs[8] <= 0.5) {
                                    if (fs[67] <= -3.5) {
                                        return -0.0735600720739;
                                    } else {
                                        return 0.010749602825;
                                    }
                                } else {
                                    return -0.162298698892;
                                }
                            } else {
                                return 0.326310341171;
                            }
                        }
                    } else {
                        if (fs[50] <= -1138.0) {
                            if (fs[4] <= 5.0) {
                                return 0.121927252824;
                            } else {
                                return -0.0486011509208;
                            }
                        } else {
                            return 0.125249474958;
                        }
                    }
                } else {
                    if (fs[69] <= 9989.5) {
                        if (fs[82] <= 2.5) {
                            if (fs[4] <= 15.0) {
                                if (fs[4] <= 9.5) {
                                    return -0.0624112485443;
                                } else {
                                    return 0.106790075043;
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    return -0.0510729274701;
                                } else {
                                    if (fs[52] <= 994.5) {
                                        return -0.0194510499959;
                                    } else {
                                        return 0.0196274974223;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 12.5) {
                                return 0.0282762124295;
                            } else {
                                return 0.295917229444;
                            }
                        }
                    } else {
                        if (fs[52] <= 995.0) {
                            return 0.228774246007;
                        } else {
                            return 0.11976536354;
                        }
                    }
                }
            }
        }
    }
}
