/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree52 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[40] <= 0.5) {
                    if (fs[50] <= -987.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[50] <= -1138.0) {
                                if (fs[71] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.02910502574;
                                    } else {
                                        return 0.0642443171412;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return -0.0351056372714;
                                    } else {
                                        return 0.0106940079807;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9969.0) {
                                    if (fs[82] <= 1.5) {
                                        return 0.0801181874771;
                                    } else {
                                        return 0.193715257848;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.123999301302;
                                    } else {
                                        return -0.044271230397;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                return 0.145174405172;
                            } else {
                                if (fs[69] <= 9989.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.286240842578;
                                    } else {
                                        return 0.179475967326;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.19119716087;
                                    } else {
                                        return 0.201857678328;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0634232939086;
                                    } else {
                                        return -0.0180714930044;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.107971525652;
                                    } else {
                                        return 0.0117418761483;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.00115923086865;
                                    } else {
                                        return 0.046128605338;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.096197131615;
                                    } else {
                                        return 0.129943785877;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.203233600095;
                                    } else {
                                        return -0.00602054049609;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.147403118115;
                                    } else {
                                        return -0.0514246661925;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9992.0) {
                                    return 0.390617547431;
                                } else {
                                    return 0.0709386899993;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[68] <= 0.5) {
                        if (fs[82] <= 1.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[69] <= 9931.0) {
                                        return -0.0756819682543;
                                    } else {
                                        return 0.158289205916;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.10429493458;
                                    } else {
                                        return -0.155691485176;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    return 0.103564533525;
                                } else {
                                    return 0.00473649033827;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                return 0.258242784618;
                            } else {
                                if (fs[82] <= 2.5) {
                                    return 0.00684728862612;
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.206561673003;
                                    } else {
                                        return 0.0936137972354;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[57] <= 0.5) {
                                    return -0.301506574618;
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.110070370637;
                                    } else {
                                        return -0.0122410053599;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[69] <= 9963.5) {
                                        return 0.0248562488473;
                                    } else {
                                        return 0.29927399764;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.00537579406183;
                                    } else {
                                        return -0.081015567781;
                                    }
                                }
                            }
                        } else {
                            return 0.212537417656;
                        }
                    }
                }
            } else {
                if (fs[25] <= 0.5) {
                    if (fs[50] <= -22.0) {
                        if (fs[2] <= 7.5) {
                            if (fs[55] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[97] <= 1.5) {
                                        return 0.0334276759439;
                                    } else {
                                        return 0.0990198867277;
                                    }
                                } else {
                                    if (fs[61] <= -995.5) {
                                        return 0.145976842052;
                                    } else {
                                        return 0.0118335601912;
                                    }
                                }
                            } else {
                                return -0.2094078733;
                            }
                        } else {
                            if (fs[50] <= -1448.0) {
                                if (fs[4] <= 27.0) {
                                    if (fs[68] <= 0.5) {
                                        return 0.325331075067;
                                    } else {
                                        return -0.0230044799905;
                                    }
                                } else {
                                    return -0.0723308410863;
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[85] <= 0.5) {
                                        return 0.261067071055;
                                    } else {
                                        return 0.132332262498;
                                    }
                                } else {
                                    if (fs[69] <= 4995.0) {
                                        return -0.0328067629221;
                                    } else {
                                        return 0.280306486352;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[89] <= 0.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[59] <= -1.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.229732386896;
                                    } else {
                                        return -0.0555644121837;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return -0.0508940465835;
                                    } else {
                                        return -0.168875184498;
                                    }
                                }
                            } else {
                                if (fs[4] <= 29.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.219517881644;
                                    } else {
                                        return 0.0941200828227;
                                    }
                                } else {
                                    if (fs[4] <= 32.5) {
                                        return 0.00442076142618;
                                    } else {
                                        return -0.136373757132;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.0428327079001;
                            } else {
                                if (fs[69] <= 9999.5) {
                                    return 0.362840691377;
                                } else {
                                    return 0.244549575583;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[12] <= 0.5) {
                        if (fs[50] <= -2268.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[50] <= -2608.0) {
                                    if (fs[50] <= -2883.0) {
                                        return 0.255587748354;
                                    } else {
                                        return 0.347798084751;
                                    }
                                } else {
                                    if (fs[50] <= -2368.0) {
                                        return 0.0677485131387;
                                    } else {
                                        return 0.262861591118;
                                    }
                                }
                            } else {
                                return -0.148534269046;
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[2] <= 10.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0628169687463;
                                    } else {
                                        return -0.149764106654;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0948753062;
                                    } else {
                                        return 0.283725311545;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1478.0) {
                                    if (fs[4] <= 19.5) {
                                        return -0.37250783819;
                                    } else {
                                        return 0.0702996369089;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.184544571553;
                                    } else {
                                        return 0.326938927419;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 26.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.300732160761;
                                    } else {
                                        return 0.0138328425783;
                                    }
                                } else {
                                    if (fs[69] <= 9993.0) {
                                        return 0.0231779641975;
                                    } else {
                                        return 0.256989492901;
                                    }
                                }
                            } else {
                                if (fs[4] <= 22.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.25976367137;
                                    } else {
                                        return 0.200805162149;
                                    }
                                } else {
                                    if (fs[69] <= 4999.5) {
                                        return 0.135347111845;
                                    } else {
                                        return 0.193989109625;
                                    }
                                }
                            }
                        } else {
                            if (fs[56] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    return -0.0527518948733;
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.219377289001;
                                    } else {
                                        return -0.101266957893;
                                    }
                                }
                            } else {
                                return 0.219763571677;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[34] <= 0.5) {
                if (fs[0] <= 1.5) {
                    if (fs[4] <= 12.5) {
                        if (fs[50] <= -1068.0) {
                            if (fs[73] <= 25.0) {
                                if (fs[25] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0414042707709;
                                    } else {
                                        return 0.00491563733518;
                                    }
                                } else {
                                    if (fs[82] <= 6.0) {
                                        return -0.013472191813;
                                    } else {
                                        return 0.10816346973;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0493710900928;
                                    } else {
                                        return 0.00319767056294;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.0582608728685;
                                    } else {
                                        return 0.119437549864;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -42.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[69] <= 4309.5) {
                                        return -0.0350235291768;
                                    } else {
                                        return -0.0874680270483;
                                    }
                                } else {
                                    if (fs[67] <= -3.5) {
                                        return -0.0470075006538;
                                    } else {
                                        return -0.0137699712726;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.00405393615028;
                                    } else {
                                        return 0.0220708438944;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0587118676966;
                                    } else {
                                        return 0.231906951997;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 50.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return -0.0115153593347;
                                    } else {
                                        return 0.162558587347;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.00275332348203;
                                    } else {
                                        return 0.125812360082;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.113762812418;
                                    } else {
                                        return 0.00296062576937;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0392794620841;
                                    } else {
                                        return 0.307209983061;
                                    }
                                }
                            }
                        } else {
                            return 0.23402715082;
                        }
                    }
                } else {
                    if (fs[0] <= 7.5) {
                        if (fs[4] <= 15.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[69] <= 9905.5) {
                                        return 0.00207955082577;
                                    } else {
                                        return 0.0417060956433;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.00239094921956;
                                    } else {
                                        return -0.00988426412913;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1408.0) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0353709642423;
                                    } else {
                                        return 0.00466368469344;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.00056720381398;
                                    } else {
                                        return -0.0193109216156;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[59] <= -2.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.162093437385;
                                    } else {
                                        return -0.0254953573674;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.00816449284028;
                                    } else {
                                        return -0.00155285575676;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00845501450762;
                                    } else {
                                        return 0.0167512797018;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0412511264748;
                                    } else {
                                        return -0.110193944524;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9999.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[4] <= 21.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.00427577278544;
                                    } else {
                                        return -0.00326632233955;
                                    }
                                } else {
                                    if (fs[69] <= 9896.5) {
                                        return -0.00493197661151;
                                    } else {
                                        return -0.0171024650781;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return -0.0234865389917;
                                    } else {
                                        return 0.0409177070958;
                                    }
                                } else {
                                    if (fs[50] <= -490.5) {
                                        return -0.0394564026901;
                                    } else {
                                        return 0.269666691738;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1277.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.118306357951;
                                    } else {
                                        return 0.325045192832;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return -0.232297334549;
                                    } else {
                                        return 0.0479487814394;
                                    }
                                }
                            } else {
                                if (fs[0] <= 57.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.103090275609;
                                    } else {
                                        return -0.00642019727513;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.20930843636;
                                    } else {
                                        return 0.0557145325774;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                return 0.202686250926;
            }
        }
    }
}
