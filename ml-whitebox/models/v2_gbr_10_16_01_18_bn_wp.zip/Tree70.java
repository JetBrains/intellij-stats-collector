/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree70 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[40] <= 0.5) {
                    if (fs[50] <= -1498.5) {
                        if (fs[2] <= 6.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[69] <= 4352.5) {
                                    if (fs[50] <= -1928.5) {
                                        return -0.0189073846873;
                                    } else {
                                        return 0.152777964464;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.145610348414;
                                    } else {
                                        return 0.0705068807448;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[82] <= 1.0) {
                                        return 0.142758985443;
                                    } else {
                                        return 0.0684568820734;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0412901348186;
                                    } else {
                                        return 0.134047336829;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 13.5) {
                                if (fs[79] <= 0.5) {
                                    return 0.0483511613829;
                                } else {
                                    if (fs[69] <= 4923.0) {
                                        return -0.307808197688;
                                    } else {
                                        return 0.0750187831392;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1748.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.210608817234;
                                    } else {
                                        return 0.140945570355;
                                    }
                                } else {
                                    return -0.125828038819;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[86] <= 0.5) {
                                        return 0.0763613235185;
                                    } else {
                                        return 0.0260277367127;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.0257152666176;
                                    } else {
                                        return -0.125105125351;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0280650834199;
                                    } else {
                                        return -0.0035298025075;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0971338866156;
                                    } else {
                                        return 0.178830652247;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 8.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.0317808331561;
                                    } else {
                                        return -0.191556171152;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.173496276513;
                                    } else {
                                        return 0.13086086939;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1468.0) {
                                    if (fs[69] <= 9997.5) {
                                        return 0.149446070987;
                                    } else {
                                        return 0.0274573091208;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0295968633519;
                                    } else {
                                        return 0.0945950767807;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[68] <= 0.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[50] <= -1493.5) {
                                if (fs[93] <= 0.5) {
                                    return 0.144500418856;
                                } else {
                                    return 0.321984829287;
                                }
                            } else {
                                if (fs[50] <= -1048.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0276217330291;
                                    } else {
                                        return -0.0927105731122;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.139874918198;
                                    } else {
                                        return -0.173867096979;
                                    }
                                }
                            }
                        } else {
                            if (fs[42] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.138375875691;
                                    } else {
                                        return -0.105461812364;
                                    }
                                } else {
                                    return 0.291868169668;
                                }
                            } else {
                                return 0.263418937143;
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.101820560933;
                                    } else {
                                        return -0.00678413532227;
                                    }
                                } else {
                                    return -0.302627184609;
                                }
                            } else {
                                if (fs[74] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.229810353767;
                                    } else {
                                        return -0.0232305357511;
                                    }
                                } else {
                                    return 0.144337861821;
                                }
                            }
                        } else {
                            return 0.188437688451;
                        }
                    }
                }
            } else {
                if (fs[84] <= 0.5) {
                    if (fs[37] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[69] <= 4725.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.104424777219;
                                    } else {
                                        return -0.00439995494902;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.145746261415;
                                    } else {
                                        return 0.0229292044394;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 22.5) {
                                        return -0.0533487914659;
                                    } else {
                                        return 0.0715870934493;
                                    }
                                } else {
                                    if (fs[69] <= 9990.5) {
                                        return 0.247675996765;
                                    } else {
                                        return 0.0967150724699;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= -0.5) {
                                return 0.192795300826;
                            } else {
                                if (fs[69] <= 9975.5) {
                                    if (fs[50] <= -2458.0) {
                                        return 0.259876842901;
                                    } else {
                                        return -0.0798733228398;
                                    }
                                } else {
                                    if (fs[50] <= -1458.0) {
                                        return -0.0426414623074;
                                    } else {
                                        return 0.0867003153754;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 24.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[69] <= 4782.0) {
                                    return 0.179196064711;
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.0763235575742;
                                    } else {
                                        return -0.217760119656;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[50] <= -721.5) {
                                        return 0.309834505403;
                                    } else {
                                        return -0.0742546106202;
                                    }
                                } else {
                                    return 0.311605759344;
                                }
                            }
                        } else {
                            if (fs[14] <= 0.5) {
                                if (fs[73] <= 75.0) {
                                    return -0.445769018866;
                                } else {
                                    return 0.00700187528882;
                                }
                            } else {
                                return 0.302684418811;
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9986.5) {
                        if (fs[86] <= 0.5) {
                            return 0.303146056841;
                        } else {
                            if (fs[4] <= 42.5) {
                                if (fs[59] <= -3.5) {
                                    return -0.205203265163;
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.018761814128;
                                    } else {
                                        return 0.0349249812326;
                                    }
                                }
                            } else {
                                return 0.261264764853;
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[4] <= 25.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.40592478515;
                                    } else {
                                        return -0.0361997023166;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.506457077414;
                                    } else {
                                        return -0.293534996759;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[4] <= 30.5) {
                                        return 0.336015005388;
                                    } else {
                                        return -0.117239349182;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.119074647182;
                                    } else {
                                        return -0.036194411419;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.313727998604;
                                    } else {
                                        return -0.422598104142;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.120653758821;
                                    } else {
                                        return 0.052489038119;
                                    }
                                }
                            } else {
                                if (fs[50] <= -436.0) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.0032851926649;
                                    } else {
                                        return 0.143271977557;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0918142481905;
                                    } else {
                                        return -0.0972373459321;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[52] <= 0.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[63] <= 5.0) {
                            if (fs[29] <= 0.5) {
                                if (fs[50] <= -1478.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.0666482600832;
                                    } else {
                                        return 0.00513096997052;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.0556819738148;
                                    } else {
                                        return 0.0073427792589;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0439200145755;
                                    } else {
                                        return -0.088024253816;
                                    }
                                } else {
                                    return 0.0693150390292;
                                }
                            }
                        } else {
                            if (fs[50] <= -1488.0) {
                                if (fs[69] <= 9997.0) {
                                    return -0.180505438502;
                                } else {
                                    return -0.221774962928;
                                }
                            } else {
                                return 0.0563504336033;
                            }
                        }
                    } else {
                        if (fs[4] <= 19.5) {
                            if (fs[59] <= -0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[50] <= -1118.0) {
                                        return -0.0758766103447;
                                    } else {
                                        return -0.0217959524199;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.0109968514412;
                                    } else {
                                        return 0.136685045342;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[75] <= 0.5) {
                                        return -0.0504617124164;
                                    } else {
                                        return -0.00562471836925;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.003400454278;
                                    } else {
                                        return 0.0268240243231;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9997.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[50] <= -2328.0) {
                                        return -0.0748297474064;
                                    } else {
                                        return -0.0137617380538;
                                    }
                                } else {
                                    return 0.254620242369;
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0246143188339;
                                    } else {
                                        return 0.169567019259;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.15070410031;
                                    } else {
                                        return 0.0102046609427;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[52] <= 994.0) {
                        return 0.387759168757;
                    } else {
                        return -0.0216389406346;
                    }
                }
            } else {
                if (fs[54] <= 0.5) {
                    if (fs[4] <= 3.5) {
                        if (fs[33] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[69] <= 9912.5) {
                                        return -0.0060471537616;
                                    } else {
                                        return 0.0443726775368;
                                    }
                                } else {
                                    if (fs[0] <= 12.5) {
                                        return 0.0463223667787;
                                    } else {
                                        return -0.00350935597377;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1058.0) {
                                    if (fs[0] <= 10.5) {
                                        return 0.0458167158579;
                                    } else {
                                        return 0.390578680749;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return -0.0312801138236;
                                    } else {
                                        return 0.00974865890983;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 3.0) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.0271325869337;
                                    } else {
                                        return -0.00118916817146;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.080042054122;
                                    } else {
                                        return 0.101919440764;
                                    }
                                }
                            } else {
                                if (fs[0] <= 32.5) {
                                    if (fs[0] <= 16.5) {
                                        return 0.0298056386809;
                                    } else {
                                        return -0.00619989928531;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.0147814573214;
                                    } else {
                                        return 0.327643362197;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[37] <= 0.5) {
                                        return -0.00172406624456;
                                    } else {
                                        return 0.0016260274559;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.000975561657143;
                                    } else {
                                        return 0.00492040585732;
                                    }
                                }
                            } else {
                                return 0.208522770006;
                            }
                        } else {
                            if (fs[0] <= 27.5) {
                                if (fs[82] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.00363798648959;
                                    } else {
                                        return 0.0334938160446;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.00201471207566;
                                    } else {
                                        return 0.00583358686042;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    if (fs[62] <= 0.5) {
                                        return -0.00141568598234;
                                    } else {
                                        return -0.00452617277107;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00565504696371;
                                    } else {
                                        return 0.0119679954793;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[50] <= -1138.0) {
                                if (fs[4] <= 13.5) {
                                    return -0.00964760747692;
                                } else {
                                    return -0.0498300709535;
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[82] <= 1.0) {
                                        return -0.00740558768987;
                                    } else {
                                        return -0.0280466248391;
                                    }
                                } else {
                                    return 0.101500990818;
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.0858569807729;
                                    } else {
                                        return 0.00369069010145;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.183590634206;
                                    } else {
                                        return -0.0133682199815;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    return 0.227836941719;
                                } else {
                                    return 0.448030336282;
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 250.0) {
                            if (fs[50] <= -932.5) {
                                return -0.030308877483;
                            } else {
                                return -0.0146689422739;
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[50] <= 7.5) {
                                        return -0.002132197256;
                                    } else {
                                        return -0.00354388147752;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.00884467003328;
                                    } else {
                                        return -0.00704661917231;
                                    }
                                }
                            } else {
                                return -0.0284034281047;
                            }
                        }
                    }
                }
            }
        }
    }
}
