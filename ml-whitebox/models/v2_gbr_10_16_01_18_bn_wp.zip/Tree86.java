/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree86 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[37] <= 0.5) {
                if (fs[82] <= -0.5) {
                    if (fs[65] <= 1.5) {
                        if (fs[67] <= -4.0) {
                            return -0.307998230347;
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0236283838881;
                                    } else {
                                        return -0.100927093069;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.238909743836;
                                    } else {
                                        return 0.0338020896854;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4999.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.140529273743;
                                    } else {
                                        return -0.0906747429224;
                                    }
                                } else {
                                    return -0.183326411249;
                                }
                            }
                        }
                    } else {
                        return -0.26609724524;
                    }
                } else {
                    if (fs[50] <= -1498.5) {
                        if (fs[67] <= -1.5) {
                            if (fs[88] <= 0.5) {
                                if (fs[50] <= -2003.5) {
                                    if (fs[4] <= 52.0) {
                                        return 0.0832174546671;
                                    } else {
                                        return -0.254705735129;
                                    }
                                } else {
                                    if (fs[50] <= -1953.5) {
                                        return -0.0267525084167;
                                    } else {
                                        return 0.0595876721275;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9809.5) {
                                    if (fs[50] <= -1968.0) {
                                        return 0.0482421837559;
                                    } else {
                                        return 0.321237794185;
                                    }
                                } else {
                                    return 0.191069966452;
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    return -0.277071718138;
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return -0.0976707503713;
                                    } else {
                                        return 0.0159400421639;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    return -0.225968093172;
                                } else {
                                    return -0.288274916334;
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0209260397328;
                                    } else {
                                        return -0.0152905430342;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0115133924293;
                                    } else {
                                        return -0.23884941856;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[14] <= 0.5) {
                                        return -0.0376637555387;
                                    } else {
                                        return 0.217913064152;
                                    }
                                } else {
                                    if (fs[62] <= 0.5) {
                                        return 0.0222379877673;
                                    } else {
                                        return -0.233810409734;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1483.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[91] <= 0.5) {
                                        return -0.00488669293363;
                                    } else {
                                        return 0.0584607324123;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0779609687761;
                                    } else {
                                        return -0.0160350666049;
                                    }
                                }
                            } else {
                                if (fs[50] <= -987.5) {
                                    if (fs[69] <= 9848.5) {
                                        return 0.00682138298379;
                                    } else {
                                        return 0.0400659822071;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.00911179030218;
                                    } else {
                                        return -0.091867287323;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 29.5) {
                    if (fs[82] <= 0.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[2] <= 2.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.11351732758;
                                    } else {
                                        return -0.254887224503;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.179819573855;
                                    } else {
                                        return 0.0484413508852;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -712.0) {
                                        return 0.0815031835043;
                                    } else {
                                        return -0.0704216022738;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0288621499618;
                                    } else {
                                        return 0.108206578368;
                                    }
                                }
                            }
                        } else {
                            if (fs[14] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[69] <= 9982.5) {
                                        return 0.235047580961;
                                    } else {
                                        return 0.122262847682;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.127886781027;
                                    } else {
                                        return -0.0164316906564;
                                    }
                                }
                            } else {
                                return -0.0394055502499;
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[50] <= -491.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 27.0) {
                                        return 0.0156489387752;
                                    } else {
                                        return 0.270326896951;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.213165283136;
                                    } else {
                                        return 0.109015953999;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.0) {
                                    if (fs[2] <= 7.5) {
                                        return 0.0649257136939;
                                    } else {
                                        return -0.0492271607331;
                                    }
                                } else {
                                    if (fs[69] <= 9867.0) {
                                        return -0.254572803775;
                                    } else {
                                        return 0.000412193177286;
                                    }
                                }
                            }
                        } else {
                            return -0.223560594115;
                        }
                    }
                } else {
                    return -0.343034756335;
                }
            }
        } else {
            if (fs[29] <= 0.5) {
                if (fs[4] <= 17.5) {
                    if (fs[73] <= 25.0) {
                        if (fs[69] <= 9999.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00150232516149;
                                    } else {
                                        return 0.0161382104615;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.1123527969;
                                    } else {
                                        return -0.00432920386819;
                                    }
                                }
                            } else {
                                if (fs[82] <= -0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.00949334954317;
                                    } else {
                                        return -0.00356955179587;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.000348248233336;
                                    } else {
                                        return 0.0049843659191;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 1.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[67] <= -3.5) {
                                        return -0.0875526149885;
                                    } else {
                                        return 0.024092224222;
                                    }
                                } else {
                                    return -0.206036833591;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.190292726188;
                                    } else {
                                        return 0.0794100966749;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.091208349435;
                                    } else {
                                        return 0.282988259651;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1408.5) {
                            if (fs[82] <= 5.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[0] <= 7.5) {
                                        return 0.0120461287558;
                                    } else {
                                        return 0.000716811544148;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0570239558526;
                                    } else {
                                        return 0.00915117291295;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.00410013972856;
                                    } else {
                                        return 0.0826959571624;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return -0.00625882573234;
                                    } else {
                                        return -0.0396711653162;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0609156369886;
                                    } else {
                                        return -0.00561682428414;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.00847741372798;
                                    } else {
                                        return -0.00194295911792;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0298103871572;
                                    } else {
                                        return -0.0271842023264;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return 0.00621166283075;
                                    } else {
                                        return -0.00413591154553;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[61] <= -996.5) {
                        if (fs[50] <= -1108.0) {
                            if (fs[4] <= 22.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 19.5) {
                                        return 0.227764706219;
                                    } else {
                                        return 0.364812943462;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return -0.0245046569041;
                                    } else {
                                        return 0.108723104384;
                                    }
                                }
                            } else {
                                if (fs[4] <= 30.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.126759591826;
                                    } else {
                                        return -0.0202667362281;
                                    }
                                } else {
                                    return 0.0764328379107;
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[73] <= 250.0) {
                                        return -0.00927864027658;
                                    } else {
                                        return 0.222281399582;
                                    }
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return -0.0107309315788;
                                    } else {
                                        return 0.0207968683133;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    return -0.0649366183517;
                                } else {
                                    return -0.0452631705987;
                                }
                            }
                        }
                    } else {
                        if (fs[77] <= 0.5) {
                            if (fs[2] <= 18.5) {
                                if (fs[91] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00127953932605;
                                    } else {
                                        return 0.00366964577347;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.00295654658254;
                                    } else {
                                        return 0.0477722951717;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    return -0.0304908229689;
                                } else {
                                    return -0.119404732184;
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[0] <= 62.5) {
                                    if (fs[4] <= 18.5) {
                                        return -0.0781617423429;
                                    } else {
                                        return -0.0305267172903;
                                    }
                                } else {
                                    return 0.0680608789885;
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    return 0.13482593262;
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0199705577754;
                                    } else {
                                        return -0.00222424692564;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[61] <= -997.5) {
                        return -0.0152642946633;
                    } else {
                        if (fs[50] <= -982.0) {
                            if (fs[99] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[50] <= -1283.0) {
                                        return -0.0726734542262;
                                    } else {
                                        return -0.0507843224091;
                                    }
                                } else {
                                    return -0.121374244844;
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return -0.119418085672;
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0236664325722;
                                    } else {
                                        return -0.0770581476918;
                                    }
                                }
                            }
                        } else {
                            return 0.00863281192986;
                        }
                    }
                } else {
                    if (fs[0] <= 8.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[69] <= 9997.0) {
                                if (fs[50] <= -1458.0) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0114980446538;
                                    } else {
                                        return 0.0262953484126;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0280180737685;
                                    } else {
                                        return -0.00682450322538;
                                    }
                                }
                            } else {
                                return -0.105604793816;
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[2] <= 1.5) {
                                    return -0.0533694862543;
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.0926613619224;
                                    } else {
                                        return -0.0989285832062;
                                    }
                                }
                            } else {
                                return -0.0249839717109;
                            }
                        }
                    } else {
                        if (fs[91] <= 0.5) {
                            if (fs[0] <= 9.5) {
                                if (fs[50] <= -1488.0) {
                                    if (fs[82] <= 1.0) {
                                        return 0.0416830084184;
                                    } else {
                                        return 0.017465426054;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.00122573856853;
                                    } else {
                                        return -0.00755434438346;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.00805242762659;
                                    } else {
                                        return -0.0329351901294;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return -0.00927927566804;
                                    } else {
                                        return -0.00181095213689;
                                    }
                                }
                            }
                        } else {
                            return -0.0631514633724;
                        }
                    }
                }
            }
        }
    }
}
