/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree35 {
    public double calcTree(double... fs) {
        if (fs[11] <= 0.5) {
            if (fs[97] <= 1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[29] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[89] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.169105447679;
                                    } else {
                                        return 0.118125761486;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0156807521315;
                                    } else {
                                        return -0.209145103054;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    return 0.281020729871;
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.20360428429;
                                    } else {
                                        return 0.0283993845863;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[69] <= 9904.5) {
                                        return -0.013169999509;
                                    } else {
                                        return 0.172721456835;
                                    }
                                } else {
                                    if (fs[69] <= 9881.0) {
                                        return -0.0627976645904;
                                    } else {
                                        return 0.208673595597;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9902.0) {
                                    if (fs[2] <= 3.5) {
                                        return -0.111649336809;
                                    } else {
                                        return 0.223382594155;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0131297777086;
                                    } else {
                                        return 0.182620317439;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 6.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[61] <= -499.5) {
                                    return 0.282939647366;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.159110046704;
                                    } else {
                                        return -0.0504073602373;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    return -0.326109348473;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.112088027224;
                                    } else {
                                        return 0.0480812345883;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 1.5) {
                                if (fs[82] <= 1.0) {
                                    return -0.0915133252251;
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.403539694487;
                                    } else {
                                        return -0.264799696254;
                                    }
                                }
                            } else {
                                return -0.0529233310736;
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9999.5) {
                        if (fs[78] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.10186987649;
                                    } else {
                                        return 0.000996021063708;
                                    }
                                } else {
                                    if (fs[69] <= 9995.5) {
                                        return -0.00965232700078;
                                    } else {
                                        return 0.036056490182;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[50] <= -1242.5) {
                                        return 0.0935152083013;
                                    } else {
                                        return -0.0233692691631;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return 0.201146606347;
                                    } else {
                                        return 0.0119064844554;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[54] <= 0.5) {
                                        return 0.0185722780325;
                                    } else {
                                        return 0.153553168296;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0485814033617;
                                    } else {
                                        return -0.0123661779448;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.00568139591583;
                                    } else {
                                        return -0.0132918111078;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0286944643501;
                                    } else {
                                        return 0.208702241489;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[37] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[0] <= 16.5) {
                                        return 0.0805195629665;
                                    } else {
                                        return -0.00762583584678;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.249952860926;
                                    } else {
                                        return -0.0437154344458;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[50] <= -1138.0) {
                                        return -0.121241348883;
                                    } else {
                                        return -0.0151779390858;
                                    }
                                } else {
                                    return 0.213205477111;
                                }
                            }
                        } else {
                            return 0.329559821463;
                        }
                    }
                }
            } else {
                if (fs[50] <= -1038.0) {
                    if (fs[0] <= 0.5) {
                        if (fs[46] <= -3.5) {
                            return -0.119069818026;
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.0136135470319;
                                    } else {
                                        return 0.156157953195;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.271916041303;
                                    } else {
                                        return 0.203120705085;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0171184157849;
                                    } else {
                                        return 0.120679641675;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.319046978498;
                                    } else {
                                        return -0.118247010436;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1138.0) {
                            if (fs[49] <= 0.5) {
                                if (fs[0] <= 8.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0257598942026;
                                    } else {
                                        return -0.050425623335;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0333483023255;
                                    } else {
                                        return 0.282171693475;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.321581029272;
                                    } else {
                                        return 0.121325251105;
                                    }
                                } else {
                                    return -0.0132907082408;
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[46] <= -0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.212273800882;
                                    } else {
                                        return 0.48330650839;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.301426341959;
                                    } else {
                                        return 0.164331026717;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.121658713429;
                                    } else {
                                        return -0.113666519753;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0624229069169;
                                    } else {
                                        return -0.0380971421259;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 6.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[44] <= 0.5) {
                                return 0.217907632479;
                            } else {
                                return 0.0826003385855;
                            }
                        } else {
                            if (fs[0] <= 6.5) {
                                if (fs[57] <= 0.5) {
                                    return -0.033542082123;
                                } else {
                                    if (fs[50] <= 7.5) {
                                        return -0.0244394641847;
                                    } else {
                                        return -0.0159412655959;
                                    }
                                }
                            } else {
                                if (fs[0] <= 12.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0167156742157;
                                    } else {
                                        return 0.0538456806025;
                                    }
                                } else {
                                    return -0.0141568922819;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[13] <= 0.5) {
                                if (fs[46] <= -1.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.128481725885;
                                    } else {
                                        return -0.0102081650779;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.083173193517;
                                    } else {
                                        return -0.0100145414987;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    return -0.117666468533;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0427120027748;
                                    } else {
                                        return -0.015950334151;
                                    }
                                }
                            }
                        } else {
                            return 0.167568547944;
                        }
                    }
                }
            }
        } else {
            if (fs[75] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[50] <= -1318.5) {
                        if (fs[50] <= -1568.0) {
                            if (fs[4] <= 40.5) {
                                return 0.0665781212299;
                            } else {
                                return -0.166875790142;
                            }
                        } else {
                            return -0.165933839298;
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.0561137861422;
                                    } else {
                                        return 0.17576838416;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.337420848763;
                                    } else {
                                        return 0.241381743584;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4995.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0847621025203;
                                    } else {
                                        return 0.140499336474;
                                    }
                                } else {
                                    return -0.040528413121;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.157976249986;
                                    } else {
                                        return 0.173126485317;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return 0.127561445263;
                                    } else {
                                        return 0.14743348522;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0888202724197;
                                    } else {
                                        return 0.16990239046;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.131606334724;
                                    } else {
                                        return -0.250914824675;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[49] <= 0.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0743291032137;
                                    } else {
                                        return -0.115307853534;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.0407118822395;
                                    } else {
                                        return -0.0760916078066;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0877848345966;
                                    } else {
                                        return 0.0244284498377;
                                    }
                                } else {
                                    return -0.143556764663;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[50] <= -566.5) {
                                        return -0.0497330344104;
                                    } else {
                                        return -0.0303529159058;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0244643260992;
                                    } else {
                                        return -0.0294529623127;
                                    }
                                }
                            } else {
                                return 0.0212229857803;
                            }
                        }
                    } else {
                        if (fs[67] <= -1.5) {
                            if (fs[50] <= -1108.0) {
                                if (fs[4] <= 7.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.155465985365;
                                    } else {
                                        return 0.0494059477963;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.0534372011238;
                                    } else {
                                        return -0.0299803812404;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0467272276811;
                                    } else {
                                        return -0.0931065215834;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0145239595246;
                                    } else {
                                        return -0.0323032321363;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0937621414513;
                                    } else {
                                        return -0.132975982046;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0735354978749;
                                    } else {
                                        return -0.0218518742315;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.0) {
                                    if (fs[50] <= 3.5) {
                                        return -0.0316578791863;
                                    } else {
                                        return -0.0367434798375;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00926649642954;
                                    } else {
                                        return -0.014706936656;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 18.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[50] <= -1504.0) {
                                    if (fs[4] <= 3.5) {
                                        return -0.152115297703;
                                    } else {
                                        return 0.198920713891;
                                    }
                                } else {
                                    if (fs[82] <= -0.5) {
                                        return -0.165066337279;
                                    } else {
                                        return 0.0430045275585;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.0828922070346;
                                    } else {
                                        return 0.205469075535;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.198541741799;
                                    } else {
                                        return 0.148331031083;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[50] <= -1049.0) {
                                        return 0.130938509793;
                                    } else {
                                        return -0.00528269132467;
                                    }
                                } else {
                                    if (fs[50] <= -1493.5) {
                                        return 0.274890555356;
                                    } else {
                                        return 0.0675452423333;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return -0.343125699273;
                                    } else {
                                        return -0.103196279386;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.146994913098;
                                    } else {
                                        return -0.38667791937;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 0.5) {
                            if (fs[69] <= 9788.0) {
                                if (fs[50] <= -1378.0) {
                                    if (fs[25] <= 0.5) {
                                        return 0.021769792522;
                                    } else {
                                        return -0.0745899873359;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.165517707836;
                                    } else {
                                        return 0.0280691075404;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[69] <= 9996.5) {
                                        return 0.394176240915;
                                    } else {
                                        return 0.0843752708154;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return -0.137183116734;
                                    } else {
                                        return 0.105533038352;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[50] <= -1618.0) {
                                    if (fs[4] <= 29.5) {
                                        return 0.225292045795;
                                    } else {
                                        return 0.395396102224;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.118175195869;
                                    } else {
                                        return 0.0327221513458;
                                    }
                                }
                            } else {
                                if (fs[50] <= -2253.0) {
                                    if (fs[4] <= 19.5) {
                                        return 0.0179536015326;
                                    } else {
                                        return 0.344466557232;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.120918170826;
                                    } else {
                                        return 0.04760904468;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[69] <= 9653.0) {
                            if (fs[40] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0109036964462;
                                    } else {
                                        return 0.00856791112213;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0470597203361;
                                    } else {
                                        return -0.000705940425768;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.344971709694;
                                    } else {
                                        return 0.0145893417628;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0976342808359;
                                    } else {
                                        return 0.26113442353;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.159511214761;
                                    } else {
                                        return 0.00443892798743;
                                    }
                                } else {
                                    if (fs[50] <= 3.5) {
                                        return 0.202123562229;
                                    } else {
                                        return -0.100423151486;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.0384492684369;
                                    } else {
                                        return 0.16258244474;
                                    }
                                } else {
                                    if (fs[50] <= -1252.5) {
                                        return 0.190941973444;
                                    } else {
                                        return 0.18048629254;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 3.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[82] <= 5.5) {
                                        return -0.00459373135693;
                                    } else {
                                        return -0.0197288082485;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.0386871070912;
                                    } else {
                                        return -0.00103274696503;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1383.0) {
                                    if (fs[40] <= 0.5) {
                                        return 0.036365256504;
                                    } else {
                                        return 0.236150709551;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.000164157300967;
                                    } else {
                                        return -0.0540510783218;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9997.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[69] <= 9996.5) {
                                        return -0.0105860275123;
                                    } else {
                                        return -0.041876015657;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.00814451390638;
                                    } else {
                                        return -0.0101657173232;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[50] <= -1428.0) {
                                        return 0.17457556192;
                                    } else {
                                        return 0.0135685931988;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0258701078766;
                                    } else {
                                        return -0.00386274608841;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
