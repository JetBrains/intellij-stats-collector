/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree4 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[39] <= 0.5) {
                if (fs[75] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[50] <= -1123.5) {
                                        return 0.695080231913;
                                    } else {
                                        return 0.76029163573;
                                    }
                                } else {
                                    return 0.256486630237;
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.509305041319;
                                    } else {
                                        return 0.755114861089;
                                    }
                                } else {
                                    if (fs[50] <= -1138.5) {
                                        return 0.519795086117;
                                    } else {
                                        return 0.732642891904;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 31.5) {
                                return -0.00820164143133;
                            } else {
                                return 0.0778495226269;
                            }
                        }
                    } else {
                        if (fs[4] <= 19.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.770741598254;
                                    } else {
                                        return 0.768943547481;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.752583572985;
                                    } else {
                                        return 0.483380643377;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.257559016889;
                                    } else {
                                        return 0.597426467531;
                                    }
                                } else {
                                    return 0.133244599726;
                                }
                            }
                        } else {
                            if (fs[4] <= 49.0) {
                                if (fs[2] <= 4.5) {
                                    if (fs[4] <= 29.5) {
                                        return 0.0315557315506;
                                    } else {
                                        return 0.270704929078;
                                    }
                                } else {
                                    return -0.0377741159236;
                                }
                            } else {
                                return -0.0775701741902;
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[50] <= -977.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.60754801776;
                                    } else {
                                        return 0.764070609615;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return 0.30526067259;
                                    } else {
                                        return 0.557397030003;
                                    }
                                }
                            } else {
                                if (fs[61] <= -995.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.478984733821;
                                    } else {
                                        return 0.646764952713;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.337753870831;
                                    } else {
                                        return 0.540928966062;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[50] <= -1504.0) {
                                        return 0.515684762648;
                                    } else {
                                        return 0.212986850525;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.310078701832;
                                    } else {
                                        return 0.49414198117;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.790570962274;
                                    } else {
                                        return 0.655620122147;
                                    }
                                } else {
                                    return 0.24217983531;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 10.5) {
                            if (fs[69] <= 9856.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.579184405971;
                                    } else {
                                        return 0.197678466106;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.0503250970734;
                                    } else {
                                        return 0.664506004341;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.611638656407;
                                    } else {
                                        return 0.251633838032;
                                    }
                                } else {
                                    if (fs[18] <= -0.5) {
                                        return -0.0406270599199;
                                    } else {
                                        return 0.706486328106;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[50] <= -967.0) {
                                    if (fs[56] <= 0.5) {
                                        return 0.54883215882;
                                    } else {
                                        return 0.69658864208;
                                    }
                                } else {
                                    if (fs[64] <= 0.5) {
                                        return 0.414384650765;
                                    } else {
                                        return 0.123725845418;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.450102805961;
                                    } else {
                                        return 0.382826335383;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.141069639599;
                                    } else {
                                        return 0.485306820409;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[97] <= 0.5) {
                    if (fs[49] <= 0.5) {
                        if (fs[75] <= 0.5) {
                            return 0.764800248352;
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[61] <= -996.5) {
                                    return 0.579501227783;
                                } else {
                                    if (fs[82] <= 2.0) {
                                        return 0.242352676939;
                                    } else {
                                        return 0.549640019719;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.611771779515;
                                    } else {
                                        return 0.758063755167;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.451092309381;
                                    } else {
                                        return -0.135918479184;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[93] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                return 0.831098298345;
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[50] <= -1093.5) {
                                        return 0.227148218823;
                                    } else {
                                        return -0.0591806112809;
                                    }
                                } else {
                                    if (fs[50] <= -1012.0) {
                                        return 0.583390191463;
                                    } else {
                                        return 0.227467898115;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.397219271675;
                                    } else {
                                        return 0.67095479778;
                                    }
                                } else {
                                    return 0.703701003999;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.592790953274;
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.178302594072;
                                    } else {
                                        return 0.503729147144;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[46] <= -0.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[61] <= -998.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.687129974685;
                                    } else {
                                        return 0.649879849704;
                                    }
                                } else {
                                    return 0.493397023143;
                                }
                            } else {
                                return 0.740802581094;
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[97] <= 1.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.627353478824;
                                    } else {
                                        return 0.225272494805;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.685064483769;
                                    } else {
                                        return 0.213670571504;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[50] <= -1008.0) {
                                        return 0.54702603056;
                                    } else {
                                        return 0.192390630072;
                                    }
                                } else {
                                    if (fs[4] <= 1.5) {
                                        return 0.491195426564;
                                    } else {
                                        return 0.605443446855;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[6] <= 0.5) {
                            return 0.232268361411;
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[61] <= -997.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.754786481257;
                                    } else {
                                        return 0.772909462502;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.70572000842;
                                    } else {
                                        return 0.462915006318;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.414479254827;
                                    } else {
                                        return 0.23322686274;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.397244313409;
                                    } else {
                                        return 0.299825443302;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 2.5) {
                if (fs[82] <= 7.5) {
                    if (fs[99] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[69] <= 9893.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.0463028282368;
                                    } else {
                                        return 0.105724492369;
                                    }
                                } else {
                                    if (fs[2] <= 11.5) {
                                        return -0.0485146871992;
                                    } else {
                                        return 0.1263102698;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1428.0) {
                                    if (fs[14] <= 0.5) {
                                        return 0.200111985657;
                                    } else {
                                        return 0.683041828277;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.0912669419274;
                                    } else {
                                        return 0.356346254683;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.0619922467764;
                                    } else {
                                        return 0.00179257060466;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0645947838543;
                                    } else {
                                        return 0.019773410291;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4666.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0449048438919;
                                    } else {
                                        return 0.00552166488056;
                                    }
                                } else {
                                    if (fs[50] <= -1037.0) {
                                        return 0.260366923364;
                                    } else {
                                        return -0.0333988415746;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9985.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.0176370752176;
                                    } else {
                                        return 0.0592429116366;
                                    }
                                } else {
                                    if (fs[82] <= 1.5) {
                                        return -0.0488575440699;
                                    } else {
                                        return -0.00356707986827;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.0251362691258;
                                    } else {
                                        return -0.0475348862588;
                                    }
                                } else {
                                    if (fs[4] <= 20.0) {
                                        return -0.0119798226107;
                                    } else {
                                        return 0.225226854739;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.231982558527;
                                    } else {
                                        return 0.0717066385188;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0802962072602;
                                    } else {
                                        return 0.171381099121;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return 0.135410952106;
                                } else {
                                    return 0.571579056078;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[73] <= 75.0) {
                        if (fs[4] <= 10.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[69] <= 9965.0) {
                                        return -0.00495625961189;
                                    } else {
                                        return 0.120889927482;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.109254175906;
                                    } else {
                                        return 0.278083447718;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.228507710139;
                                    } else {
                                        return 0.0994647941934;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0737012962388;
                                    } else {
                                        return -0.0598387536025;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= -0.5) {
                                if (fs[4] <= 15.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.125727464821;
                                    } else {
                                        return 0.0548289773672;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0317193824822;
                                    } else {
                                        return -0.0586869032805;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1343.0) {
                                    return 0.068575906752;
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.0260440612953;
                                    } else {
                                        return 0.163030221682;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 6.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0767884912455;
                                    } else {
                                        return -0.0440587174573;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.213464795751;
                                    } else {
                                        return 0.529479570634;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[50] <= -1223.0) {
                                        return 0.730431235383;
                                    } else {
                                        return -0.023888018406;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.31402862474;
                                    } else {
                                        return 0.633243727982;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                return 0.428194742925;
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0829224865402;
                                    } else {
                                        return -0.0327628289545;
                                    }
                                } else {
                                    return 0.129439110137;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 6.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[4] <= 25.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[69] <= 9996.5) {
                                        return -0.0219842391297;
                                    } else {
                                        return 0.186947341924;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return 0.0157103140538;
                                    } else {
                                        return 0.158431194478;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9993.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.0128280516298;
                                    } else {
                                        return -0.0439377549183;
                                    }
                                } else {
                                    return 0.039610550341;
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[69] <= 4329.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0324048600834;
                                    } else {
                                        return 0.19080725437;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0212640555593;
                                    } else {
                                        return 0.199164218874;
                                    }
                                }
                            } else {
                                if (fs[46] <= -2.5) {
                                    return 0.00302890861733;
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0437713573759;
                                    } else {
                                        return -0.00610925854521;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[69] <= 9900.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0475659682123;
                                    } else {
                                        return 0.150633556087;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0253515457396;
                                    } else {
                                        return -0.0462010641255;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[50] <= -1067.0) {
                                        return 0.0451246032385;
                                    } else {
                                        return -0.0116909136498;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.203776163815;
                                    } else {
                                        return 0.0130740566489;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[69] <= 9929.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0466312762921;
                                    } else {
                                        return -0.0298927560432;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0423997710167;
                                    } else {
                                        return 0.0106159004828;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0156520842984;
                                    } else {
                                        return -0.0290802076304;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0381426554311;
                                    } else {
                                        return 0.346962659265;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 12.5) {
                        if (fs[69] <= 9833.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0437992524204;
                                    } else {
                                        return -0.0361043195314;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return -0.0394770070815;
                                    } else {
                                        return 0.0299358541047;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[75] <= 0.5) {
                                        return 0.062505302677;
                                    } else {
                                        return -0.0364808481014;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.021404717149;
                                    } else {
                                        return 0.31476469709;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1097.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[69] <= 9996.5) {
                                        return 0.0037854118577;
                                    } else {
                                        return 0.113331823286;
                                    }
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return 0.441271461143;
                                    } else {
                                        return 0.21862766027;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0212699285905;
                                    } else {
                                        return -0.0473338453485;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.26228147826;
                                    } else {
                                        return -0.0560010536134;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[69] <= 9977.5) {
                                        return -0.0469843767259;
                                    } else {
                                        return 0.00635602358861;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0446045759204;
                                    } else {
                                        return -0.0322426360488;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0280196934103;
                                    } else {
                                        return -0.0475551661569;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0456786756312;
                                    } else {
                                        return -0.0338836635362;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0257839039339;
                                    } else {
                                        return -0.0424216375228;
                                    }
                                } else {
                                    if (fs[0] <= 32.5) {
                                        return 0.0164558039533;
                                    } else {
                                        return 0.239238699543;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0479721209978;
                                    } else {
                                        return -0.0476175182322;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0480629768309;
                                    } else {
                                        return -0.0472988895744;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
