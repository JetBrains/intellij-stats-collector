/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree2 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[75] <= 0.5) {
                if (fs[95] <= 0.5) {
                    if (fs[34] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.72436010135;
                                    } else {
                                        return 0.247185389514;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.817570767334;
                                    } else {
                                        return 0.0545424281218;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.543380813467;
                                    } else {
                                        return 0.821431311057;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0911624531148;
                                    } else {
                                        return -0.0260399501481;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.821314750171;
                                    } else {
                                        return 0.839753640853;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.794070205335;
                                    } else {
                                        return 0.33164750795;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0197639482631;
                                    } else {
                                        return 0.20482786144;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.0495461830771;
                                    } else {
                                        return -0.00222240660395;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.819032939536;
                                    } else {
                                        return 0.823565179151;
                                    }
                                } else {
                                    if (fs[50] <= -1118.5) {
                                        return 0.845034726887;
                                    } else {
                                        return 0.81110604143;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return 0.686629321547;
                                } else {
                                    return 0.82491101352;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.305033213409;
                                } else {
                                    return 0.434252523279;
                                }
                            } else {
                                return 0.814043464046;
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1568.0) {
                        return 0.0579052000366;
                    } else {
                        if (fs[69] <= 4847.0) {
                            if (fs[0] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[50] <= -1328.0) {
                                        return -0.0690710969597;
                                    } else {
                                        return 0.308003273961;
                                    }
                                } else {
                                    return 0.348585487243;
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 31.5) {
                                        return -0.0441825456277;
                                    } else {
                                        return -0.0516133601952;
                                    }
                                } else {
                                    if (fs[4] <= 78.5) {
                                        return -0.0524111431961;
                                    } else {
                                        return -0.0530647849563;
                                    }
                                }
                            }
                        } else {
                            return 0.0577237500839;
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[73] <= 250.0) {
                        if (fs[2] <= 2.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[98] <= 0.5) {
                                        return 0.503687244853;
                                    } else {
                                        return 0.792042458143;
                                    }
                                } else {
                                    if (fs[50] <= -1143.5) {
                                        return 0.00315668374791;
                                    } else {
                                        return 0.297112486732;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.275690485016;
                                    } else {
                                        return 0.38568197865;
                                    }
                                } else {
                                    if (fs[50] <= -1593.5) {
                                        return 0.735659983097;
                                    } else {
                                        return 0.459140063388;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.702114429657;
                                    } else {
                                        return 0.6145289521;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.5008958906;
                                    } else {
                                        return 0.273188347157;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.346297824303;
                                    } else {
                                        return 0.0973431438117;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.28812704532;
                                    } else {
                                        return 0.553764949076;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[39] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.643056494319;
                                    } else {
                                        return 0.357894479208;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return 0.288188806296;
                                    } else {
                                        return 0.0388844492768;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.862827883387;
                                    } else {
                                        return 0.712354029316;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.197111140998;
                                    } else {
                                        return 0.513720363576;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.658120814291;
                                    } else {
                                        return 0.401874556151;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return 0.652003961191;
                                    } else {
                                        return 0.781653468321;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 20.5) {
                                        return 0.798462275347;
                                    } else {
                                        return 0.589994051375;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.757007302564;
                                    } else {
                                        return 0.734082118996;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[84] <= 0.5) {
                        if (fs[73] <= 25.0) {
                            if (fs[0] <= 2.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[69] <= 9851.5) {
                                        return -0.0254626039598;
                                    } else {
                                        return 0.0851784128853;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0444147893259;
                                    } else {
                                        return 0.00045295021385;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0313488213221;
                                    } else {
                                        return -0.0466722849181;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0516923176362;
                                    } else {
                                        return -0.0469655775292;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.102175513185;
                                    } else {
                                        return 0.0106325394005;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.339674545927;
                                    } else {
                                        return 0.659433603485;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0709183213357;
                                    } else {
                                        return -0.0273236885705;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.0317465691616;
                                    } else {
                                        return -0.0485316266297;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[97] <= 1.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.156834913411;
                                    } else {
                                        return 0.0725935094812;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.0185740885487;
                                    } else {
                                        return 0.0437350617856;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.242320216609;
                                    } else {
                                        return 0.144398065661;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0491761024712;
                                    } else {
                                        return 0.0113845927654;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= -2.5) {
                                if (fs[50] <= -457.0) {
                                    if (fs[61] <= -995.5) {
                                        return 0.0830873632835;
                                    } else {
                                        return -0.0551469790271;
                                    }
                                } else {
                                    if (fs[55] <= 0.5) {
                                        return -0.0532852351836;
                                    } else {
                                        return -0.053975066338;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return -0.031244877153;
                                    } else {
                                        return -0.0519674604611;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.049849884469;
                                    } else {
                                        return -0.0461051956506;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[57] <= 0.5) {
                    if (fs[4] <= 10.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[50] <= -1103.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.6487782524;
                                    } else {
                                        return 0.780613652173;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.432511447173;
                                    } else {
                                        return 0.19913284905;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[82] <= 1.5) {
                                        return 0.495580922821;
                                    } else {
                                        return 0.720110989665;
                                    }
                                } else {
                                    if (fs[13] <= 0.5) {
                                        return 0.816527591946;
                                    } else {
                                        return 0.701677775038;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.747949411166;
                                    } else {
                                        return 0.84019108963;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.394525775553;
                                    } else {
                                        return 0.43280124029;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    return 0.855649373898;
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.853035716192;
                                    } else {
                                        return 0.796596683154;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1022.0) {
                            if (fs[87] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.641153170374;
                                    } else {
                                        return 0.854466157266;
                                    }
                                } else {
                                    return 0.108460925043;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    return 0.12550655099;
                                } else {
                                    return -0.0810126679482;
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                return 0.798140980081;
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.332993445187;
                                    } else {
                                        return 0.560252183967;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.374679539752;
                                    } else {
                                        return -0.109306757199;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[39] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[50] <= -987.5) {
                                        return 0.529737727491;
                                    } else {
                                        return 0.246874115537;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.850592017144;
                                    } else {
                                        return 0.78604437289;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[50] <= -1103.5) {
                                        return 0.686655704568;
                                    } else {
                                        return 0.356703299068;
                                    }
                                } else {
                                    if (fs[50] <= -1023.0) {
                                        return 0.648729000229;
                                    } else {
                                        return 0.235581587617;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[46] <= -0.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.784214311063;
                                    } else {
                                        return 0.649575107179;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.563063632547;
                                    } else {
                                        return 0.414358304158;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.68994839814;
                                    } else {
                                        return 0.78726316519;
                                    }
                                } else {
                                    return 0.574717041095;
                                }
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[8] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.783913887835;
                                    } else {
                                        return 0.326759128737;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.585012038846;
                                    } else {
                                        return 0.688731983375;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    return 0.609320563085;
                                } else {
                                    return -0.0436184604899;
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.796987438959;
                                    } else {
                                        return 0.734931878833;
                                    }
                                } else {
                                    if (fs[50] <= -1318.0) {
                                        return 0.871904974441;
                                    } else {
                                        return 0.70161756226;
                                    }
                                }
                            } else {
                                if (fs[82] <= 1.0) {
                                    if (fs[46] <= -0.5) {
                                        return 0.785617358802;
                                    } else {
                                        return 0.445678033892;
                                    }
                                } else {
                                    if (fs[67] <= -3.5) {
                                        return 0.833750355612;
                                    } else {
                                        return 0.613815898833;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[50] <= -1413.0) {
                        if (fs[82] <= 7.5) {
                            if (fs[52] <= 50.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.284307634512;
                                    } else {
                                        return 0.590162759755;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.232335190792;
                                    } else {
                                        return -0.00837925140958;
                                    }
                                }
                            } else {
                                return 0.81857144414;
                            }
                        } else {
                            if (fs[4] <= 8.0) {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.416874679467;
                                    } else {
                                        return 0.820174734508;
                                    }
                                } else {
                                    return 0.625473386056;
                                }
                            } else {
                                return 0.216314365877;
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[83] <= 0.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.140384961091;
                                    } else {
                                        return 0.0717295030091;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.211783040019;
                                    } else {
                                        return 0.0055776615932;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.531516092509;
                                } else {
                                    return 0.195839932248;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0235841775304;
                                    } else {
                                        return 0.0670380302338;
                                    }
                                } else {
                                    return 0.120807433999;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0591535363872;
                                    } else {
                                        return 0.0586327369416;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.00153009196107;
                                    } else {
                                        return -0.0538422878977;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[50] <= -1428.0) {
                            if (fs[69] <= 9999.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.0759405845351;
                                    } else {
                                        return 0.159895099417;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.29861103074;
                                    } else {
                                        return 0.132216862302;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    return 0.0444041854823;
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.416690350596;
                                    } else {
                                        return 0.634795189617;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00958174441146;
                                    } else {
                                        return 0.12359395937;
                                    }
                                } else {
                                    if (fs[62] <= 0.5) {
                                        return 0.266426645809;
                                    } else {
                                        return 0.927397043723;
                                    }
                                }
                            } else {
                                if (fs[61] <= -995.5) {
                                    return 0.58947065768;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.018985130874;
                                    } else {
                                        return 0.0813732060909;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 75.0) {
                            if (fs[56] <= 0.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[4] <= 16.5) {
                                        return -0.0524872608835;
                                    } else {
                                        return -0.0275700021569;
                                    }
                                } else {
                                    return 0.0583636370378;
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0570255869992;
                                    } else {
                                        return -0.0624874434498;
                                    }
                                } else {
                                    return 0.207921719895;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0411763882037;
                                    } else {
                                        return -0.0504040894714;
                                    }
                                } else {
                                    return 0.0301538517176;
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0503171811801;
                                    } else {
                                        return 0.00295271575706;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.0607503750492;
                                    } else {
                                        return -0.0523750905042;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
