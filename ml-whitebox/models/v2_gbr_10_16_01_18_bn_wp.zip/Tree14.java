/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree14 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[75] <= 0.5) {
                if (fs[40] <= 0.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[4] <= 3.5) {
                                        return 0.294735709259;
                                    } else {
                                        return 0.400992326436;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.432467440513;
                                    } else {
                                        return 0.480746874712;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.470725747126;
                                    } else {
                                        return 0.465153763713;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.506373414557;
                                    } else {
                                        return 0.498561739549;
                                    }
                                }
                            }
                        } else {
                            if (fs[64] <= 0.5) {
                                return 0.357327213777;
                            } else {
                                return 0.302411002521;
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[50] <= -1138.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.414828348037;
                                    } else {
                                        return 0.492117055302;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return 0.242103307346;
                                    } else {
                                        return 0.384792397174;
                                    }
                                }
                            } else {
                                if (fs[67] <= -1.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.479142786766;
                                    } else {
                                        return 0.436284789577;
                                    }
                                } else {
                                    return 0.282959352767;
                                }
                            }
                        } else {
                            if (fs[4] <= 19.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.422596945655;
                                    } else {
                                        return 0.466194790614;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.439579215905;
                                    } else {
                                        return 0.468381410857;
                                    }
                                }
                            } else {
                                if (fs[4] <= 49.0) {
                                    if (fs[4] <= 39.5) {
                                        return -0.0266687637569;
                                    } else {
                                        return 0.333904458421;
                                    }
                                } else {
                                    return -0.138662380288;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[57] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[50] <= -1138.0) {
                                return 0.486507670051;
                            } else {
                                return 0.488788083177;
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[50] <= -1138.0) {
                                    return 0.430256780032;
                                } else {
                                    return 0.474075603645;
                                }
                            } else {
                                return 0.403726518017;
                            }
                        }
                    } else {
                        if (fs[4] <= 3.5) {
                            if (fs[15] <= 0.5) {
                                return 0.023884709846;
                            } else {
                                return -0.0358965570751;
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                return 0.314705342981;
                            } else {
                                if (fs[50] <= -1138.0) {
                                    return 0.264073009076;
                                } else {
                                    return 0.112396109751;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[73] <= 25.0) {
                    if (fs[79] <= 0.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[50] <= -970.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.365878371256;
                                    } else {
                                        return -0.0209948440583;
                                    }
                                } else {
                                    if (fs[69] <= 9635.0) {
                                        return 0.291971529765;
                                    } else {
                                        return 0.392185290775;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.24763395962;
                                    } else {
                                        return 0.3598488971;
                                    }
                                } else {
                                    if (fs[46] <= -0.5) {
                                        return 0.379716736246;
                                    } else {
                                        return 0.127730331814;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.402321490679;
                                    } else {
                                        return 0.151751353323;
                                    }
                                } else {
                                    if (fs[82] <= 1.0) {
                                        return 0.223521836478;
                                    } else {
                                        return -0.14718820986;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.438691998072;
                                    } else {
                                        return 0.0527351562062;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.186093429883;
                                    } else {
                                        return 0.316463584339;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.407940304214;
                                    } else {
                                        return 0.200566849147;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.120494130206;
                                    } else {
                                        return 0.116230177769;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[82] <= 6.0) {
                                        return -0.0194248933818;
                                    } else {
                                        return 0.428228679015;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.211353516108;
                                    } else {
                                        return -0.0109525934238;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 1.5) {
                                if (fs[69] <= 9319.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.171189538228;
                                    } else {
                                        return 0.651036254388;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.208782651533;
                                    } else {
                                        return -0.165551141463;
                                    }
                                }
                            } else {
                                if (fs[4] <= 23.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.532786726844;
                                    } else {
                                        return 0.426335349852;
                                    }
                                } else {
                                    return 0.189428594119;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[39] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[54] <= 0.5) {
                                        return 0.322214276687;
                                    } else {
                                        return 0.5814684383;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return 0.164412702505;
                                    } else {
                                        return 0.46016234899;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.208497081607;
                                    } else {
                                        return 0.304353620284;
                                    }
                                } else {
                                    if (fs[50] <= -1543.5) {
                                        return 0.425277650296;
                                    } else {
                                        return 0.0662161392714;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[42] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.429306762262;
                                    } else {
                                        return 0.248181475226;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0639978039789;
                                    } else {
                                        return 0.416976989531;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.345040123233;
                                    } else {
                                        return 0.0930381036888;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.0411442131658;
                                    } else {
                                        return 0.357076375907;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[59] <= -0.5) {
                                        return 0.448945307783;
                                    } else {
                                        return 0.404955364968;
                                    }
                                } else {
                                    if (fs[50] <= -1008.5) {
                                        return 0.354198085534;
                                    } else {
                                        return 0.00775864511423;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.442138653926;
                                    } else {
                                        return 0.361882444263;
                                    }
                                } else {
                                    if (fs[50] <= -551.5) {
                                        return 0.111383806551;
                                    } else {
                                        return -0.026725946615;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[56] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.229510233078;
                                    } else {
                                        return 0.409090705765;
                                    }
                                } else {
                                    return 0.408476403736;
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.12643205353;
                                    } else {
                                        return 0.273374498669;
                                    }
                                } else {
                                    return -0.252117829136;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[69] <= 9653.0) {
                    if (fs[95] <= 0.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.00921853849188;
                                    } else {
                                        return 0.0412120051816;
                                    }
                                } else {
                                    if (fs[92] <= 0.5) {
                                        return -0.0354405538176;
                                    } else {
                                        return -0.0506037118981;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    return 0.383491843289;
                                } else {
                                    if (fs[4] <= 5.0) {
                                        return 0.575830801372;
                                    } else {
                                        return 0.549318126696;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.00800497142203;
                                    } else {
                                        return -0.0285780377317;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.0219525162607;
                                    } else {
                                        return 0.265746073727;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1448.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.201883561577;
                                    } else {
                                        return 0.449263449115;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.114676065091;
                                    } else {
                                        return -0.00223290547102;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[39] <= 0.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.0580043471256;
                                    } else {
                                        return -0.00894731476305;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0162395686786;
                                    } else {
                                        return 0.339428318881;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.112853361703;
                                    } else {
                                        return -0.0322941140917;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0460933168177;
                                    } else {
                                        return -0.0311016899349;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[61] <= -997.5) {
                                    if (fs[50] <= -556.5) {
                                        return 0.422443209018;
                                    } else {
                                        return 0.255163209469;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.101081976608;
                                    } else {
                                        return 0.360231564349;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0146196901545;
                                    } else {
                                        return 0.0155145231117;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.046239479601;
                                    } else {
                                        return -0.0316047846348;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[40] <= 0.5) {
                        if (fs[50] <= -1408.5) {
                            if (fs[69] <= 9998.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0458343154023;
                                    } else {
                                        return 0.12008881711;
                                    }
                                } else {
                                    if (fs[18] <= -0.5) {
                                        return -0.232429788906;
                                    } else {
                                        return 0.315123658639;
                                    }
                                }
                            } else {
                                if (fs[52] <= 50.5) {
                                    if (fs[4] <= 30.5) {
                                        return 0.25950168849;
                                    } else {
                                        return -0.141950409219;
                                    }
                                } else {
                                    return 0.613396421844;
                                }
                            }
                        } else {
                            if (fs[65] <= 1.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0875437554349;
                                    } else {
                                        return -0.0468262491534;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return 0.0278688106135;
                                    } else {
                                        return 0.649436649714;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[50] <= -982.0) {
                                        return 0.287539343269;
                                    } else {
                                        return -0.100300582865;
                                    }
                                } else {
                                    return 0.0928950603793;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 10.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[50] <= -481.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.101758122082;
                                    } else {
                                        return -0.104842737749;
                                    }
                                } else {
                                    if (fs[69] <= 9931.0) {
                                        return -0.045169933184;
                                    } else {
                                        return 0.272428571615;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return 0.618362076992;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.131122931083;
                                    } else {
                                        return 0.250331671926;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[69] <= 9989.5) {
                                    if (fs[50] <= -1488.0) {
                                        return -0.125383922209;
                                    } else {
                                        return -0.113533817795;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.316765028482;
                                    } else {
                                        return -0.0651099336582;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    return 0.443096328885;
                                } else {
                                    return -0.125278844756;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[95] <= 0.5) {
                    if (fs[75] <= 0.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[15] <= 0.5) {
                                        return -0.00538800040059;
                                    } else {
                                        return 0.0683889728139;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.12989071945;
                                    } else {
                                        return 0.397827705657;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    return 0.151180409002;
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0416211543499;
                                    } else {
                                        return -0.0645036097061;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[4] <= 2.5) {
                                    return 0.441138220601;
                                } else {
                                    if (fs[50] <= -1058.0) {
                                        return 0.088660798829;
                                    } else {
                                        return -0.0702534230328;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.075445324244;
                                    } else {
                                        return -0.0350807712387;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.0333155776168;
                                    } else {
                                        return -0.0599671156292;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9977.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0156055218937;
                                    } else {
                                        return -0.0260496635988;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0267617806594;
                                    } else {
                                        return -0.0289483495337;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.111538636424;
                                    } else {
                                        return 0.00169302581068;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0111815462403;
                                    } else {
                                        return -0.0263892472312;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0260330010694;
                                    } else {
                                        return 0.118655734356;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.00803362618125;
                                    } else {
                                        return -0.0330441458994;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[50] <= -1133.5) {
                                        return 0.214890145255;
                                    } else {
                                        return 0.0008096647615;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.389348714993;
                                    } else {
                                        return 0.0444028350087;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 4.5) {
                        if (fs[4] <= 17.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0118709032516;
                                    } else {
                                        return 0.0377462442562;
                                    }
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return 0.048885671555;
                                    } else {
                                        return 0.606806260121;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0389425647889;
                                    } else {
                                        return -0.0274392149417;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.123913734085;
                                    } else {
                                        return -0.0222902462837;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9976.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0179925508352;
                                    } else {
                                        return 0.00980492186583;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0253230185854;
                                    } else {
                                        return -0.0299284761758;
                                    }
                                }
                            } else {
                                if (fs[73] <= 150.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00749505106532;
                                    } else {
                                        return 0.0995307294914;
                                    }
                                } else {
                                    if (fs[50] <= -1098.0) {
                                        return 0.0128583592671;
                                    } else {
                                        return -0.0291588222319;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[69] <= 9997.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[0] <= 14.5) {
                                        return -0.00789692266366;
                                    } else {
                                        return -0.0230659336736;
                                    }
                                } else {
                                    if (fs[46] <= -2.5) {
                                        return 0.206828335017;
                                    } else {
                                        return -0.0253306110166;
                                    }
                                }
                            } else {
                                if (fs[0] <= 63.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.136189151011;
                                    } else {
                                        return 0.0368428025508;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.293329520413;
                                    } else {
                                        return 0.334146333155;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= -2.5) {
                                if (fs[0] <= 5.5) {
                                    return 0.0614288506779;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0377030934342;
                                    } else {
                                        return -0.0339049379974;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.0297056115342;
                                    } else {
                                        return -0.0197740543918;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0285872039569;
                                    } else {
                                        return -0.0229051465737;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
