/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree93 {
    public double calcTree(double... fs) {
        if (fs[54] <= 0.5) {
            if (fs[23] <= 0.5) {
                if (fs[61] <= -997.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[55] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[97] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0137998390696;
                                    } else {
                                        return 0.0474734820866;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0174554195797;
                                    } else {
                                        return 0.225171172853;
                                    }
                                }
                            } else {
                                return -0.175024721578;
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                return 0.0451420691742;
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0558831001123;
                                    } else {
                                        return -0.229051904403;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.0967614486685;
                                    } else {
                                        return 0.139316875511;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[97] <= 1.5) {
                                        return -0.0252402327421;
                                    } else {
                                        return -0.0676458635401;
                                    }
                                } else {
                                    if (fs[55] <= 0.5) {
                                        return 0.00699473486938;
                                    } else {
                                        return -0.0116290754051;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0278598843625;
                                    } else {
                                        return -0.0137739890585;
                                    }
                                } else {
                                    if (fs[50] <= -986.5) {
                                        return 0.0678428249218;
                                    } else {
                                        return -0.00787065691696;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 1.5) {
                                if (fs[0] <= 4.5) {
                                    return -0.0119047470662;
                                } else {
                                    return -0.00185478848546;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.00264439871063;
                                    } else {
                                        return 0.000907050505786;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.00637279518944;
                                    } else {
                                        return -0.0117612006625;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[75] <= 0.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[39] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[50] <= -1063.5) {
                                        return 0.053296322857;
                                    } else {
                                        return -0.1615901931;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.00823134175198;
                                    } else {
                                        return -0.00247500430087;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    return 0.121337565041;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.102838809628;
                                    } else {
                                        return 0.0588045316715;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -953.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0345691869556;
                                    } else {
                                        return -0.275491477434;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0158922727387;
                                    } else {
                                        return -0.0631077705805;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.000144669947169;
                                    } else {
                                        return -0.0190498856025;
                                    }
                                } else {
                                    if (fs[0] <= 16.5) {
                                        return -0.0106735160965;
                                    } else {
                                        return -0.00634014490778;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[69] <= 9915.5) {
                                        return 0.000198054270561;
                                    } else {
                                        return 0.0245082487325;
                                    }
                                } else {
                                    if (fs[50] <= -5878.0) {
                                        return 0.112803717512;
                                    } else {
                                        return -0.000979419974486;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.000737020338984;
                                    } else {
                                        return 0.0258454803093;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return 4.34354544351e-05;
                                    } else {
                                        return -0.0353675767688;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[12] <= 0.5) {
                                    if (fs[82] <= 2.5) {
                                        return -0.0245231430556;
                                    } else {
                                        return 0.105696705199;
                                    }
                                } else {
                                    return 0.141861161806;
                                }
                            } else {
                                if (fs[50] <= -1463.5) {
                                    if (fs[69] <= 9745.0) {
                                        return 0.220509496093;
                                    } else {
                                        return 0.133617637441;
                                    }
                                } else {
                                    return -0.0381008581413;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1118.5) {
                    if (fs[4] <= 8.5) {
                        if (fs[4] <= 4.5) {
                            return 0.0180498047181;
                        } else {
                            if (fs[49] <= 0.5) {
                                return 0.133143418454;
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[69] <= 4746.0) {
                                        return 0.103134124778;
                                    } else {
                                        return 0.0400056865838;
                                    }
                                } else {
                                    return 0.170057340643;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9894.0) {
                            if (fs[4] <= 13.5) {
                                if (fs[56] <= 0.5) {
                                    return 0.245500038048;
                                } else {
                                    return 0.210051079558;
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    return -0.106763496477;
                                } else {
                                    return 0.0260579271673;
                                }
                            }
                        } else {
                            if (fs[69] <= 9989.5) {
                                return 0.34472213826;
                            } else {
                                return 0.193312623385;
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[69] <= 9795.0) {
                                if (fs[0] <= 4.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0543482388099;
                                    } else {
                                        return -0.0324487386117;
                                    }
                                } else {
                                    return 0.0668815925676;
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    return 0.161293075585;
                                } else {
                                    return -0.038179458772;
                                }
                            }
                        } else {
                            if (fs[69] <= 9947.0) {
                                if (fs[0] <= 0.5) {
                                    return 0.127221999496;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.026922804513;
                                    } else {
                                        return -0.00276173946075;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    return -0.00469075229363;
                                } else {
                                    return 0.266288089757;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9941.0) {
                            if (fs[0] <= 2.5) {
                                if (fs[68] <= 0.5) {
                                    return -0.029175850093;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.0277955003738;
                                    } else {
                                        return -0.0174417641269;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return -0.0114269803786;
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.00622777607516;
                                    } else {
                                        return -0.00238781341165;
                                    }
                                }
                            }
                        } else {
                            return -0.0720172382258;
                        }
                    }
                }
            }
        } else {
            if (fs[26] <= 0.5) {
                if (fs[44] <= 0.5) {
                    if (fs[82] <= 3.0) {
                        if (fs[4] <= 8.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0632160762414;
                                    } else {
                                        return -0.0257775417225;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.172207188855;
                                    } else {
                                        return -0.085524833945;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    return 0.198168404869;
                                } else {
                                    return 0.203599803892;
                                }
                            }
                        } else {
                            if (fs[4] <= 13.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[12] <= 0.5) {
                                        return -0.031625106713;
                                    } else {
                                        return 0.158747831487;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0404545810066;
                                    } else {
                                        return 0.169886413799;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.166547852677;
                                    } else {
                                        return 0.0407816091944;
                                    }
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return 0.0515153250369;
                                    } else {
                                        return 0.132731463545;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 10.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[69] <= 9990.5) {
                                        return 0.0335367008899;
                                    } else {
                                        return 0.0653169548547;
                                    }
                                } else {
                                    return 0.11386385547;
                                }
                            } else {
                                return 0.1516455021;
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                return 0.216334492999;
                            } else {
                                return 0.352139074266;
                            }
                        }
                    }
                } else {
                    if (fs[97] <= 0.5) {
                        if (fs[18] <= 0.5) {
                            return -0.0230474063975;
                        } else {
                            return -0.0337328901159;
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 12.5) {
                                return -0.0258092157167;
                            } else {
                                return -0.0141495200959;
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    return -0.00850813838349;
                                } else {
                                    return -0.00199447816409;
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    return -0.0214004472152;
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0036064017248;
                                    } else {
                                        return -0.000225720124095;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 19.5) {
                    return -0.0959359627329;
                } else {
                    return -0.0316848958046;
                }
            }
        }
    }
}
