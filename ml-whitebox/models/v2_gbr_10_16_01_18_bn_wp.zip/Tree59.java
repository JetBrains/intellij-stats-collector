/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree59 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 9.5) {
                if (fs[73] <= 75.0) {
                    if (fs[40] <= 0.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[86] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.104422587553;
                                    } else {
                                        return -0.11631156586;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.0401203485695;
                                    } else {
                                        return 0.151903934189;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0321236194419;
                                    } else {
                                        return -0.0539248131633;
                                    }
                                } else {
                                    if (fs[69] <= 9892.5) {
                                        return 0.12793036529;
                                    } else {
                                        return 0.0606005999064;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[37] <= 0.5) {
                                    if (fs[82] <= 6.0) {
                                        return -0.106300549158;
                                    } else {
                                        return 0.16567527182;
                                    }
                                } else {
                                    if (fs[82] <= -0.5) {
                                        return 0.350792270854;
                                    } else {
                                        return 0.0487364007406;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.0) {
                                    if (fs[4] <= 4.5) {
                                        return -0.051277639683;
                                    } else {
                                        return 0.059926734389;
                                    }
                                } else {
                                    if (fs[50] <= -1478.5) {
                                        return 0.0568135410767;
                                    } else {
                                        return 0.128463759672;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[82] <= 6.0) {
                                    if (fs[69] <= 9979.5) {
                                        return -0.05391556318;
                                    } else {
                                        return 0.138151924673;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.246547910981;
                                    } else {
                                        return -0.00490452655929;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0606982510882;
                                    } else {
                                        return -0.0662683638679;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0253994434765;
                                    } else {
                                        return 0.421457758252;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 1.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[50] <= -1123.0) {
                                        return -0.17536345546;
                                    } else {
                                        return 0.176127973109;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.107910700709;
                                    } else {
                                        return -0.171131754853;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    return 0.141503312053;
                                } else {
                                    return -0.0827044103777;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[50] <= -1488.0) {
                                if (fs[95] <= 1.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.116252726443;
                                    } else {
                                        return 0.0266799342898;
                                    }
                                } else {
                                    if (fs[50] <= -1493.5) {
                                        return 0.133491665246;
                                    } else {
                                        return 0.0407896718085;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1423.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.227199477339;
                                    } else {
                                        return 0.130097278139;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0555054972807;
                                    } else {
                                        return 0.0223982050215;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.090167496088;
                                    } else {
                                        return 0.0624586939608;
                                    }
                                } else {
                                    return -0.271342158502;
                                }
                            } else {
                                if (fs[82] <= 4.5) {
                                    if (fs[97] <= 1.5) {
                                        return 0.0837431006882;
                                    } else {
                                        return 0.0498204236768;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.196930059542;
                                    } else {
                                        return 0.0255288616419;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9990.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00992236760436;
                                    } else {
                                        return -0.0768785821468;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0286083620836;
                                    } else {
                                        return 0.0942673313994;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return 0.20230400656;
                                } else {
                                    return 0.116499649694;
                                }
                            }
                        } else {
                            if (fs[54] <= 0.5) {
                                if (fs[67] <= -4.0) {
                                    return 0.260633419095;
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.130557025364;
                                    } else {
                                        return 0.126809737149;
                                    }
                                }
                            } else {
                                return 0.282267781382;
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 6.5) {
                    if (fs[50] <= -1493.5) {
                        if (fs[75] <= 0.5) {
                            if (fs[4] <= 31.5) {
                                return -0.114117042711;
                            } else {
                                if (fs[4] <= 40.5) {
                                    if (fs[50] <= -1568.0) {
                                        return 0.250037298115;
                                    } else {
                                        return -0.14429896371;
                                    }
                                } else {
                                    return -0.14885445086;
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[50] <= -1999.0) {
                                    if (fs[78] <= 0.5) {
                                        return 0.159138757269;
                                    } else {
                                        return 0.0905084446384;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return 0.094830043448;
                                    } else {
                                        return -0.0344670169255;
                                    }
                                }
                            } else {
                                if (fs[50] <= -2013.5) {
                                    if (fs[50] <= -2043.5) {
                                        return 0.16381071314;
                                    } else {
                                        return 0.266011387368;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.136418315009;
                                    } else {
                                        return 0.0323271985339;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[69] <= 9825.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.111609065978;
                                    } else {
                                        return -0.048665199001;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.0176158482511;
                                    } else {
                                        return 0.221132633187;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[52] <= -1.5) {
                                        return -0.0311635741881;
                                    } else {
                                        return 0.0909133915192;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.236355847645;
                                    } else {
                                        return 0.0719476882584;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -996.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.0716164780683;
                                    } else {
                                        return 0.139514021682;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.0821390333208;
                                    } else {
                                        return 0.0701638102647;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    if (fs[50] <= -1318.0) {
                                        return -0.424992233804;
                                    } else {
                                        return -0.119563590304;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.0197731574004;
                                    } else {
                                        return 0.208173820671;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[73] <= 75.0) {
                        if (fs[2] <= 10.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[82] <= 5.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.00988534318942;
                                    } else {
                                        return 0.0906715739295;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.0262801885816;
                                    } else {
                                        return -0.25234005408;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[82] <= 1.0) {
                                        return 0.125610308254;
                                    } else {
                                        return 0.235378693811;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.0985411796537;
                                    } else {
                                        return -0.0240457947846;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9993.5) {
                                if (fs[82] <= 3.0) {
                                    if (fs[4] <= 12.5) {
                                        return 0.0818387502602;
                                    } else {
                                        return 0.18379233996;
                                    }
                                } else {
                                    return 0.366240463098;
                                }
                            } else {
                                if (fs[50] <= -1468.0) {
                                    return 0.0964332942436;
                                } else {
                                    return -0.220890190941;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 13.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return 0.133438148578;
                                    } else {
                                        return 0.197011406981;
                                    }
                                } else {
                                    return 0.0307351726392;
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    return -0.249349015007;
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0721555982874;
                                    } else {
                                        return 0.194819192865;
                                    }
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0811985681338;
                                    } else {
                                        return -0.183682626769;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0911952084853;
                                    } else {
                                        return -0.148245062171;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.246226488612;
                                    } else {
                                        return 0.0433623841941;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.250586066445;
                                    } else {
                                        return 0.0479250699409;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[99] <= 0.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[88] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[69] <= 9930.5) {
                                        return 0.0425043768999;
                                    } else {
                                        return 0.157178835492;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.02289384934;
                                    } else {
                                        return -0.0552651177048;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.00598288011232;
                                    } else {
                                        return 0.124720362227;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.182695214493;
                                    } else {
                                        return -0.0536256569963;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9991.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[50] <= -1703.0) {
                                        return -0.0569640778874;
                                    } else {
                                        return 0.062674226553;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.151836467205;
                                    } else {
                                        return 0.371124258304;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    return 0.493735446082;
                                } else {
                                    return 0.102164498227;
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 0.5) {
                            if (fs[69] <= 9655.5) {
                                if (fs[50] <= -941.5) {
                                    if (fs[50] <= -961.5) {
                                        return -0.0167255739657;
                                    } else {
                                        return 0.0756855869526;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0284361080684;
                                    } else {
                                        return 0.0110787163419;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0988970442058;
                                    } else {
                                        return -0.0606621955991;
                                    }
                                } else {
                                    return 0.00691179784815;
                                }
                            }
                        } else {
                            if (fs[2] <= 11.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.0132982431676;
                                    } else {
                                        return 0.0101026533631;
                                    }
                                } else {
                                    return 0.163624384013;
                                }
                            } else {
                                return 0.168497220783;
                            }
                        }
                    }
                } else {
                    if (fs[73] <= 25.0) {
                        if (fs[69] <= 9985.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[69] <= 9870.5) {
                                        return -0.00924311540842;
                                    } else {
                                        return -0.0592273344851;
                                    }
                                } else {
                                    return 0.366558500233;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0330362928668;
                                    } else {
                                        return 0.0571517754505;
                                    }
                                } else {
                                    return 0.404672791592;
                                }
                            }
                        } else {
                            if (fs[4] <= 13.5) {
                                if (fs[82] <= 0.5) {
                                    return 0.233750288602;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0272744917484;
                                    } else {
                                        return 0.101706696902;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[82] <= 3.5) {
                                        return -0.139969981761;
                                    } else {
                                        return -0.0645563755365;
                                    }
                                } else {
                                    return 0.0192770062382;
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.200924172184;
                                    } else {
                                        return -0.0418849920561;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0110014756727;
                                    } else {
                                        return 0.326833516142;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.178240715969;
                                    } else {
                                        return 0.0946179722817;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0200858917913;
                                    } else {
                                        return 0.10129480688;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 4.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[69] <= 9718.5) {
                                        return 0.0900562287648;
                                    } else {
                                        return -0.141717559743;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.665396289658;
                                    } else {
                                        return 0.260426610883;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.0210723165552;
                                    } else {
                                        return -0.139143204398;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.117168990902;
                                    } else {
                                        return 0.00717811820923;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[54] <= 0.5) {
                    if (fs[0] <= 7.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[46] <= -2.5) {
                                    return 0.180415300695;
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.00263774804075;
                                    } else {
                                        return 0.0109706254111;
                                    }
                                }
                            } else {
                                if (fs[50] <= -37.0) {
                                    if (fs[39] <= 0.5) {
                                        return -0.00701178527139;
                                    } else {
                                        return 0.00801146415484;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0107688355586;
                                    } else {
                                        return 0.00103932211315;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= -0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.0159705622577;
                                    } else {
                                        return -0.0990361001861;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0690096759723;
                                    } else {
                                        return -0.0196732297333;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.00950937682969;
                                    } else {
                                        return -0.00482886120443;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.000806877642853;
                                    } else {
                                        return -0.006086028202;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[61] <= -996.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[11] <= 0.5) {
                                    return 0.240384408833;
                                } else {
                                    if (fs[61] <= -998.5) {
                                        return -0.00905463723433;
                                    } else {
                                        return 0.0796302480725;
                                    }
                                }
                            } else {
                                if (fs[59] <= -1.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.0398754706532;
                                    } else {
                                        return -0.00767379211222;
                                    }
                                } else {
                                    if (fs[50] <= -1072.5) {
                                        return 0.0624013356948;
                                    } else {
                                        return -0.00808172883668;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[50] <= -1122.5) {
                                        return -0.002842790944;
                                    } else {
                                        return -0.00383613075574;
                                    }
                                } else {
                                    return 0.111883155492;
                                }
                            } else {
                                if (fs[0] <= 25.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.00262514304804;
                                    } else {
                                        return -3.54114961058e-06;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.00325321762381;
                                    } else {
                                        return 0.0174257017163;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[50] <= -466.5) {
                                    return 0.050651756361;
                                } else {
                                    return 0.218711401374;
                                }
                            } else {
                                return -0.0340451278157;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.14775841917;
                            } else {
                                return 0.387095896655;
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[82] <= 3.0) {
                                    if (fs[69] <= 9994.5) {
                                        return -0.0410226435341;
                                    } else {
                                        return 0.101180692346;
                                    }
                                } else {
                                    return 0.379047529667;
                                }
                            } else {
                                if (fs[50] <= -1268.0) {
                                    return -0.0439789986367;
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.321839613507;
                                    } else {
                                        return 0.134907536829;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[59] <= -0.5) {
                                        return -0.0174192246915;
                                    } else {
                                        return -0.0127935774205;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.0148348694779;
                                    } else {
                                        return -0.0046831500643;
                                    }
                                }
                            } else {
                                return -0.0316994471915;
                            }
                        }
                    }
                }
            }
        }
    }
}
