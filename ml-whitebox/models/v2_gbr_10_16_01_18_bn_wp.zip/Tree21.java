/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree21 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[50] <= -987.5) {
                if (fs[50] <= -1143.5) {
                    if (fs[73] <= 25.0) {
                        if (fs[95] <= 0.5) {
                            if (fs[69] <= 9848.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[62] <= 0.5) {
                                        return -0.0434042874724;
                                    } else {
                                        return 0.0584619365514;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.332137973218;
                                    } else {
                                        return 0.0404192202155;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1518.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.401285234153;
                                    } else {
                                        return 0.284680425468;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.187458841595;
                                    } else {
                                        return -0.110320161139;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[50] <= -1978.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.397079525658;
                                    } else {
                                        return 0.194486487827;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.178599650978;
                                    } else {
                                        return 0.234872823765;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[69] <= 9995.5) {
                                        return 0.151726375111;
                                    } else {
                                        return -0.177243962254;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0294802127982;
                                    } else {
                                        return -0.149676582403;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[42] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[7] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.296468099049;
                                    } else {
                                        return 0.37411670501;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.131882968049;
                                    } else {
                                        return -0.0873333705723;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.196368911576;
                                    } else {
                                        return 0.290227430871;
                                    }
                                } else {
                                    if (fs[50] <= -1588.0) {
                                        return 0.38186933977;
                                    } else {
                                        return 0.101103130051;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1928.0) {
                                if (fs[69] <= 9992.5) {
                                    return 0.4512502333;
                                } else {
                                    return 0.0441074852426;
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.030585324925;
                                    } else {
                                        return 0.307259655756;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return -0.000942490669151;
                                    } else {
                                        return -0.306436975885;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.300143854389;
                                    } else {
                                        return 0.248520566403;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.302614935991;
                                    } else {
                                        return 0.328381186777;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1133.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.2260618624;
                                    } else {
                                        return 0.253942145426;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.28179216901;
                                    } else {
                                        return -0.142471397097;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.33037300753;
                                    } else {
                                        return 0.369634965578;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.11423919483;
                                    } else {
                                        return 0.0431852409531;
                                    }
                                }
                            } else {
                                return -0.258580058746;
                            }
                        }
                    } else {
                        if (fs[50] <= -1133.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.299284110993;
                                    } else {
                                        return 0.125329127926;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.00787564640217;
                                    } else {
                                        return 0.122805923747;
                                    }
                                }
                            } else {
                                if (fs[2] <= 8.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.369291841775;
                                    } else {
                                        return 0.241966546471;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.500652791976;
                                    } else {
                                        return 0.40437969061;
                                    }
                                }
                            }
                        } else {
                            if (fs[55] <= 0.5) {
                                if (fs[4] <= 27.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.396152650639;
                                    } else {
                                        return 0.289796489005;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.264344333092;
                                    } else {
                                        return -0.0943987658969;
                                    }
                                }
                            } else {
                                return -0.300344867941;
                            }
                        }
                    }
                }
            } else {
                if (fs[25] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[61] <= -996.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[69] <= 5000.0) {
                                        return 0.175802353642;
                                    } else {
                                        return 0.405284702493;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.374536713502;
                                    } else {
                                        return 0.236310685711;
                                    }
                                }
                            } else {
                                if (fs[75] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.332674844914;
                                    } else {
                                        return 0.396080958417;
                                    }
                                } else {
                                    if (fs[69] <= 9988.0) {
                                        return 0.0693757747213;
                                    } else {
                                        return 0.197071494478;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9974.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0023235004476;
                                    } else {
                                        return -0.0931566217348;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return 0.287386084785;
                                    } else {
                                        return 0.0418724930317;
                                    }
                                }
                            } else {
                                if (fs[67] <= -4.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.220999379006;
                                    } else {
                                        return 0.352601233443;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.157245503327;
                                    } else {
                                        return 0.0560888518419;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[82] <= -0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.218990682645;
                                    } else {
                                        return 0.114276170751;
                                    }
                                } else {
                                    return 0.460932066195;
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.269764145248;
                                    } else {
                                        return 0.370367891322;
                                    }
                                } else {
                                    if (fs[69] <= 9396.5) {
                                        return 0.0132053711106;
                                    } else {
                                        return 0.210712939769;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -994.5) {
                                if (fs[46] <= -1.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.462124757819;
                                    } else {
                                        return 0.374966552524;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.443183487779;
                                    } else {
                                        return 0.184042905475;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.16138081596;
                                    } else {
                                        return 0.292044132264;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0485931084756;
                                    } else {
                                        return 0.245015755368;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -858.0) {
                        if (fs[82] <= 7.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.133616009213;
                                    } else {
                                        return 0.0591668462036;
                                    }
                                } else {
                                    return 0.517949129402;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.179011738038;
                                    } else {
                                        return -0.269664638351;
                                    }
                                } else {
                                    return 0.0606647004559;
                                }
                            }
                        } else {
                            return 0.512675543573;
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[43] <= 0.5) {
                                return 0.202750558411;
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.249827737248;
                                    } else {
                                        return 0.464836890727;
                                    }
                                } else {
                                    return 0.408740424553;
                                }
                            }
                        } else {
                            if (fs[69] <= 4273.5) {
                                if (fs[82] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.25461150671;
                                    } else {
                                        return 0.19500826083;
                                    }
                                } else {
                                    return -0.151953958884;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    return 0.0861605296339;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.194029529394;
                                    } else {
                                        return -0.0582837560732;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[84] <= 0.5) {
                if (fs[73] <= 25.0) {
                    if (fs[0] <= 2.5) {
                        if (fs[75] <= 0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.0478766877271;
                                    } else {
                                        return -0.0802114375653;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.039284334999;
                                    } else {
                                        return 0.265888932064;
                                    }
                                }
                            } else {
                                if (fs[67] <= -1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0470664925577;
                                    } else {
                                        return -0.022996320959;
                                    }
                                } else {
                                    if (fs[50] <= -1053.0) {
                                        return 0.216551440542;
                                    } else {
                                        return -0.0537056426917;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9982.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.00309443456349;
                                    } else {
                                        return -0.0211425433143;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.0117514858198;
                                    } else {
                                        return 0.16677242531;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0324528619366;
                                    } else {
                                        return 0.085738119547;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0415153365279;
                                    } else {
                                        return 0.31846799669;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9982.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.00950890304772;
                                    } else {
                                        return 0.0270177826124;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.0123215697223;
                                    } else {
                                        return -0.0185342686716;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9363.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.0214399221249;
                                    } else {
                                        return -0.0201486892071;
                                    }
                                } else {
                                    if (fs[50] <= -1267.5) {
                                        return -0.00128384541644;
                                    } else {
                                        return -0.021215391399;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[0] <= 16.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0457800112178;
                                    } else {
                                        return 0.0013092347926;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return -0.0328443896751;
                                    } else {
                                        return -0.010739500814;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.267328170853;
                                    } else {
                                        return 0.10067587559;
                                    }
                                } else {
                                    if (fs[82] <= 3.5) {
                                        return 0.0156490642367;
                                    } else {
                                        return -0.0346322179235;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 7.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.0815901806498;
                                    } else {
                                        return 0.00598645498295;
                                    }
                                } else {
                                    if (fs[50] <= -1428.5) {
                                        return 0.201006277267;
                                    } else {
                                        return 0.0438605992333;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[50] <= -1398.0) {
                                        return 0.0454488617992;
                                    } else {
                                        return -0.0166503451097;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0457906181574;
                                    } else {
                                        return 0.0426720755814;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 7.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0304985743584;
                                    } else {
                                        return -0.00550750811286;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0181300388345;
                                    } else {
                                        return 0.00804570052941;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1128.0) {
                                    if (fs[69] <= 9944.5) {
                                        return -0.0165674873059;
                                    } else {
                                        return 0.0745790978444;
                                    }
                                } else {
                                    if (fs[82] <= 1.5) {
                                        return -0.0201667329614;
                                    } else {
                                        return -0.0219147534294;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.235749720929;
                                    } else {
                                        return 0.109470040788;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.034580839496;
                                    } else {
                                        return -0.134027625555;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0493827488443;
                                    } else {
                                        return -0.0352452436699;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0518505352061;
                                    } else {
                                        return -0.0525325930675;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.127671014732;
                                    } else {
                                        return -0.0325039157259;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.0297806235977;
                                    } else {
                                        return 0.0173027403939;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1237.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.48021749788;
                                    } else {
                                        return 0.33417656958;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.0617470714515;
                                    } else {
                                        return -0.0707322419012;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[25] <= 0.5) {
                    if (fs[33] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[59] <= -0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.095626147331;
                                    } else {
                                        return -0.0532213783362;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0794681244354;
                                    } else {
                                        return 0.241089043007;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.169647560919;
                                    } else {
                                        return -0.0111284777847;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0298420903642;
                                    } else {
                                        return 0.212688184912;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[50] <= -987.0) {
                                        return -0.0148245639644;
                                    } else {
                                        return -0.0202590051339;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return -0.0146162278987;
                                    } else {
                                        return 0.0791127444573;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0279014013451;
                                    } else {
                                        return -0.0209880862771;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0167977369332;
                                    } else {
                                        return 0.0457745124833;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.295037621912;
                                    } else {
                                        return 0.0754351336986;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.0534480656831;
                                    } else {
                                        return -0.087357207195;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.163130005993;
                                    } else {
                                        return -0.00738167118889;
                                    }
                                } else {
                                    if (fs[50] <= -951.5) {
                                        return -0.0316808316508;
                                    } else {
                                        return -0.02510654789;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[54] <= 0.5) {
                                        return -0.00762845182719;
                                    } else {
                                        return 0.389751022076;
                                    }
                                } else {
                                    if (fs[50] <= -1088.0) {
                                        return 0.0266642964146;
                                    } else {
                                        return -0.00140860073688;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[50] <= -1453.5) {
                                        return 0.23088856672;
                                    } else {
                                        return -0.0160988316632;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.0176812684979;
                                    } else {
                                        return -0.0216881161062;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 5.5) {
                        if (fs[77] <= 0.5) {
                            if (fs[50] <= -1133.0) {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.138196719337;
                                    } else {
                                        return 0.243542766368;
                                    }
                                } else {
                                    if (fs[50] <= -1468.0) {
                                        return 0.0688588925533;
                                    } else {
                                        return 0.213518298375;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.00160137284759;
                                    } else {
                                        return -0.0582710815422;
                                    }
                                } else {
                                    if (fs[69] <= 9995.5) {
                                        return 0.0577465409457;
                                    } else {
                                        return 0.501541946379;
                                    }
                                }
                            }
                        } else {
                            if (fs[43] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.357776325353;
                                    } else {
                                        return 0.0276899270847;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0246761657854;
                                    } else {
                                        return -0.0865575571443;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1938.0) {
                                    return 0.184842553331;
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return 0.0746061847613;
                                    } else {
                                        return -0.0436859953458;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[91] <= 0.5) {
                            if (fs[50] <= -1418.0) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.125123083081;
                                    } else {
                                        return 0.0444851661591;
                                    }
                                } else {
                                    return 0.466344645784;
                                }
                            } else {
                                if (fs[0] <= 10.5) {
                                    if (fs[4] <= 28.5) {
                                        return -0.0279957465651;
                                    } else {
                                        return 0.136258252789;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0281057676317;
                                    } else {
                                        return -0.0131934031728;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[86] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.0116438596005;
                                    } else {
                                        return 0.311633230095;
                                    }
                                } else {
                                    if (fs[50] <= -1468.0) {
                                        return 0.0107198157852;
                                    } else {
                                        return -0.0331742638517;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[0] <= 18.5) {
                                        return 0.0125590758976;
                                    } else {
                                        return -0.024087369159;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return -0.0238817916988;
                                    } else {
                                        return -0.0217653044755;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
