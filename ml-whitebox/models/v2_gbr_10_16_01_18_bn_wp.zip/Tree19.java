/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree19 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 9.5) {
                if (fs[75] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[50] <= -1138.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.360594969826;
                                    } else {
                                        return 0.330447008635;
                                    }
                                } else {
                                    return -0.14320933407;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.226160043655;
                                    } else {
                                        return 0.354361516791;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0571343463189;
                                    } else {
                                        return 0.207160275134;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1028.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.334783379531;
                                    } else {
                                        return 0.368498040871;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.384763285079;
                                    } else {
                                        return 0.380355756591;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.191625208815;
                                    } else {
                                        return -0.286607050412;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.436720233929;
                                    } else {
                                        return 0.371510720695;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.370022264104;
                                    } else {
                                        return 0.40198543769;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return 0.378634198241;
                                    } else {
                                        return 0.330225316217;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.37260013399;
                                    } else {
                                        return 0.278836896887;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.364415645776;
                                    } else {
                                        return 0.403842086476;
                                    }
                                }
                            }
                        } else {
                            return 0.238875986056;
                        }
                    }
                } else {
                    if (fs[97] <= 0.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[83] <= 0.5) {
                                        return 0.262910575812;
                                    } else {
                                        return 0.408182377016;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.1604102496;
                                    } else {
                                        return 0.453705459122;
                                    }
                                }
                            } else {
                                return 0.0297493988445;
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[42] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.360629778396;
                                    } else {
                                        return 0.107184096175;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.00209248765338;
                                    } else {
                                        return 0.291057107184;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9884.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.284687727751;
                                    } else {
                                        return 0.128791767084;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.342600887876;
                                    } else {
                                        return 0.210316034079;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.336429693957;
                                    } else {
                                        return 0.0330731925437;
                                    }
                                } else {
                                    if (fs[50] <= -988.5) {
                                        return 0.285943537154;
                                    } else {
                                        return -0.0040608489121;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.424714192722;
                                    } else {
                                        return 0.400416368126;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.352951170831;
                                    } else {
                                        return 0.169368902332;
                                    }
                                }
                            }
                        } else {
                            if (fs[55] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.460061411113;
                                    } else {
                                        return 0.129587511621;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.25457572199;
                                    } else {
                                        return 0.421440427459;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4991.5) {
                                    return -0.00590941514723;
                                } else {
                                    return -0.395146954705;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[73] <= 250.0) {
                    if (fs[43] <= 0.5) {
                        if (fs[50] <= -1588.0) {
                            if (fs[73] <= 25.0) {
                                if (fs[78] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.00880393027562;
                                    } else {
                                        return 0.242572760296;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.442683996204;
                                    } else {
                                        return 0.316286247194;
                                    }
                                }
                            } else {
                                if (fs[2] <= 0.5) {
                                    return -0.0252532385096;
                                } else {
                                    if (fs[50] <= -2193.0) {
                                        return 0.476217388139;
                                    } else {
                                        return 0.356080557586;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= -0.5) {
                                if (fs[61] <= -995.5) {
                                    if (fs[54] <= 0.5) {
                                        return 0.32071390904;
                                    } else {
                                        return 0.482300776163;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.0739077158234;
                                    } else {
                                        return 0.271696469295;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[69] <= 9972.5) {
                                        return 0.0589133330387;
                                    } else {
                                        return 0.15193797521;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.260960902196;
                                    } else {
                                        return 0.0564239146844;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.381189562729;
                                    } else {
                                        return 0.323974092943;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.182321626189;
                                    } else {
                                        return 0.226244592265;
                                    }
                                }
                            } else {
                                if (fs[87] <= 0.5) {
                                    if (fs[76] <= 0.5) {
                                        return 0.214371427653;
                                    } else {
                                        return 0.355574590035;
                                    }
                                } else {
                                    if (fs[69] <= 4918.0) {
                                        return -0.0691546137702;
                                    } else {
                                        return -0.215102469372;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[69] <= 4881.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0742369252352;
                                    } else {
                                        return 0.262087651824;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.231207601969;
                                    } else {
                                        return -0.277486663248;
                                    }
                                }
                            } else {
                                return 0.073383653533;
                            }
                        }
                    }
                } else {
                    if (fs[43] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[97] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[77] <= 0.5) {
                                        return 0.134212945907;
                                    } else {
                                        return 0.0470523734765;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.258746737545;
                                    } else {
                                        return 0.445949837901;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    return -0.0249214264196;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.316714127094;
                                    } else {
                                        return 0.241735679476;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 28.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.296831435195;
                                    } else {
                                        return 0.356697134386;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.219286174748;
                                    } else {
                                        return 0.00172649093358;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.234317347858;
                                    } else {
                                        return 0.0841743949253;
                                    }
                                } else {
                                    return -0.126671837635;
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[69] <= 9989.0) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[4] <= 15.5) {
                                        return 0.411146447235;
                                    } else {
                                        return 0.213923707282;
                                    }
                                } else {
                                    return -0.0146195040468;
                                }
                            } else {
                                return -0.162218931139;
                            }
                        } else {
                            if (fs[4] <= 24.0) {
                                return -0.202198807627;
                            } else {
                                return 0.052279052158;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[69] <= 9867.5) {
                if (fs[95] <= 0.5) {
                    if (fs[82] <= 6.5) {
                        if (fs[75] <= 0.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[50] <= -1108.0) {
                                    if (fs[4] <= 2.5) {
                                        return 0.329092329386;
                                    } else {
                                        return 0.0392772452054;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.00845707512323;
                                    } else {
                                        return -0.0527075234432;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0817491494805;
                                    } else {
                                        return -0.0940069312525;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0409018228967;
                                    } else {
                                        return -0.0515690510964;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return -0.0180284761827;
                                    } else {
                                        return -0.0218660117902;
                                    }
                                } else {
                                    if (fs[52] <= 50.5) {
                                        return -0.0229220385046;
                                    } else {
                                        return 0.280205829184;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.00545385386746;
                                    } else {
                                        return 0.150171518591;
                                    }
                                } else {
                                    if (fs[50] <= 3.5) {
                                        return -0.017361312744;
                                    } else {
                                        return -0.0254834481884;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 75.0) {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0700058920506;
                                    } else {
                                        return 0.00858970743641;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.0156941673331;
                                    } else {
                                        return -0.0233879955249;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.371847823399;
                                    } else {
                                        return -0.00376254920619;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0540965273647;
                                    } else {
                                        return -0.0134211764689;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.00868526746432;
                                    } else {
                                        return 0.349488397154;
                                    }
                                } else {
                                    if (fs[50] <= -1128.0) {
                                        return 0.039204950718;
                                    } else {
                                        return -0.0330507655982;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.252280094395;
                                    } else {
                                        return -0.0479773349018;
                                    }
                                } else {
                                    if (fs[0] <= 11.5) {
                                        return 0.470861124571;
                                    } else {
                                        return -0.00020981814497;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 13.5) {
                        if (fs[50] <= -1093.5) {
                            if (fs[73] <= 75.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[47] <= 0.5) {
                                        return -0.0132175928246;
                                    } else {
                                        return 0.120018748542;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0246598598223;
                                    } else {
                                        return 0.183230991315;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0951350632272;
                                    } else {
                                        return 0.00693653376718;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0131005145223;
                                    } else {
                                        return 0.0654288850634;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[50] <= -436.5) {
                                        return -0.0580215876049;
                                    } else {
                                        return 0.0428623148484;
                                    }
                                } else {
                                    if (fs[50] <= -47.5) {
                                        return -0.0187309034742;
                                    } else {
                                        return -0.02714755182;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.00421931756766;
                                    } else {
                                        return -0.0228190812802;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.0183657507482;
                                    } else {
                                        return -0.0228651140792;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[50] <= -1468.0) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0716933308821;
                                    } else {
                                        return 0.175590859848;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return 0.0450634094908;
                                    } else {
                                        return -0.0076609690142;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0177270815509;
                                    } else {
                                        return -0.0080374694001;
                                    }
                                } else {
                                    return 0.128784760691;
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[86] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0380926365745;
                                    } else {
                                        return 0.20902911611;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0209046114081;
                                    } else {
                                        return 0.00342022180208;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[46] <= -2.5) {
                                        return 0.0630353329626;
                                    } else {
                                        return -0.0235730268457;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return -0.0152599413596;
                                    } else {
                                        return -0.0215366945852;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[65] <= 1.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[50] <= -1528.0) {
                                        return 0.158209247002;
                                    } else {
                                        return 0.0276790998958;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.051326943651;
                                    } else {
                                        return 0.248560939255;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    return 0.441989523965;
                                } else {
                                    return 0.240085165325;
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.175472700132;
                                    } else {
                                        return -0.0304965006968;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.417503766392;
                                    } else {
                                        return 0.199107347954;
                                    }
                                }
                            } else {
                                return 0.441325885092;
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[50] <= -1488.0) {
                                if (fs[73] <= 75.0) {
                                    if (fs[4] <= 6.5) {
                                        return -0.07472545899;
                                    } else {
                                        return 0.289779395996;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return 0.175330913271;
                                    } else {
                                        return 0.389039353415;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.275755366729;
                                    } else {
                                        return 0.128858060227;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.0325767258515;
                                    } else {
                                        return 0.313936141076;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 6.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.0651495232586;
                                    } else {
                                        return 0.25130027923;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0435241664418;
                                    } else {
                                        return 0.000417197963752;
                                    }
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.13671346189;
                                    } else {
                                        return 0.26705265982;
                                    }
                                } else {
                                    return -0.129076305932;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 6.5) {
                        if (fs[50] <= -1067.0) {
                            if (fs[78] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[69] <= 9991.5) {
                                        return 0.0583935595662;
                                    } else {
                                        return 0.195686045905;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0319819609218;
                                    } else {
                                        return -0.0368950257862;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1118.0) {
                                    if (fs[61] <= -995.5) {
                                        return 0.173152964991;
                                    } else {
                                        return 0.000233309727892;
                                    }
                                } else {
                                    return 0.22342336645;
                                }
                            }
                        } else {
                            if (fs[65] <= 1.5) {
                                if (fs[50] <= -11.0) {
                                    if (fs[84] <= 0.5) {
                                        return -0.046093921119;
                                    } else {
                                        return -0.0214749857816;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.00917565918886;
                                    } else {
                                        return -0.046074602395;
                                    }
                                }
                            } else {
                                if (fs[50] <= -476.5) {
                                    return -0.0542597223922;
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.355406970343;
                                    } else {
                                        return 0.154407217295;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1403.0) {
                            if (fs[11] <= 0.5) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0124997335655;
                                    } else {
                                        return 0.250346465795;
                                    }
                                } else {
                                    if (fs[0] <= 28.0) {
                                        return 0.443664899016;
                                    } else {
                                        return -0.0278025491546;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    return 0.298752824738;
                                } else {
                                    if (fs[50] <= -1438.0) {
                                        return 0.0230982020121;
                                    } else {
                                        return 0.342275136915;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[4] <= 4.5) {
                                    if (fs[69] <= 9996.5) {
                                        return 0.00200617391953;
                                    } else {
                                        return 0.0822681795767;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.0165197635534;
                                    } else {
                                        return 0.250251756109;
                                    }
                                }
                            } else {
                                if (fs[0] <= 62.5) {
                                    if (fs[37] <= 0.5) {
                                        return -0.0263301505891;
                                    } else {
                                        return 0.00818716908835;
                                    }
                                } else {
                                    if (fs[50] <= -1037.0) {
                                        return 0.156141389989;
                                    } else {
                                        return -0.0163478961369;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
