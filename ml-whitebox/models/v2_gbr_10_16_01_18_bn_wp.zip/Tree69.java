/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree69 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9980.5) {
            if (fs[0] <= 0.5) {
                if (fs[25] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 24.5) {
                                        return 0.0757806427442;
                                    } else {
                                        return -0.144627340338;
                                    }
                                } else {
                                    if (fs[50] <= -1493.5) {
                                        return 0.0764335727274;
                                    } else {
                                        return -0.0744784445179;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.0468637198096;
                                    } else {
                                        return 0.00967380596784;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return 0.0621335897308;
                                    } else {
                                        return 0.195183876818;
                                    }
                                }
                            }
                        } else {
                            if (fs[46] <= -0.5) {
                                if (fs[82] <= 5.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0628954469646;
                                    } else {
                                        return 0.225734260184;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return -0.0927620984646;
                                    } else {
                                        return 0.062039551955;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.252527576237;
                                    } else {
                                        return -0.0557197831894;
                                    }
                                } else {
                                    if (fs[50] <= -1093.5) {
                                        return 0.102035939359;
                                    } else {
                                        return -0.0846254740924;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1978.0) {
                            if (fs[18] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[50] <= -2468.0) {
                                        return 0.141702297937;
                                    } else {
                                        return 0.0574656765869;
                                    }
                                } else {
                                    return 0.258438945812;
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.246676321817;
                                    } else {
                                        return 0.210507206504;
                                    }
                                } else {
                                    return 0.122185892356;
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[4] <= 26.5) {
                                        return 0.0313534406394;
                                    } else {
                                        return -0.0364245210026;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.128112617858;
                                    } else {
                                        return 0.0471524311654;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1097.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.189226477051;
                                    } else {
                                        return -0.281312362938;
                                    }
                                } else {
                                    return -0.423922002466;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[68] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[4] <= 27.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.129214728576;
                                    } else {
                                        return 0.0864105847548;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.229375505959;
                                    } else {
                                        return 0.158002332122;
                                    }
                                }
                            } else {
                                return -0.271514751433;
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[95] <= 1.5) {
                                        return -0.0434688255097;
                                    } else {
                                        return 0.0209223179554;
                                    }
                                } else {
                                    if (fs[50] <= -1478.5) {
                                        return 0.0354982755841;
                                    } else {
                                        return 0.157986283308;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.076302506422;
                                    } else {
                                        return -0.271201358866;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return 0.0460268229361;
                                    } else {
                                        return -0.355357130474;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[69] <= 8694.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[50] <= -2009.0) {
                                        return 0.125053126558;
                                    } else {
                                        return -0.083659975379;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.120023980694;
                                    } else {
                                        return -0.155710370123;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -1488.0) {
                                        return -0.127972919685;
                                    } else {
                                        return 0.116892269396;
                                    }
                                } else {
                                    if (fs[50] <= -1948.0) {
                                        return 0.30528814037;
                                    } else {
                                        return 0.0204000795973;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9868.0) {
                                if (fs[49] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.0852317098554;
                                    } else {
                                        return 0.0408132929572;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0262711251071;
                                    } else {
                                        return 0.096896045996;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.117708087905;
                                    } else {
                                        return 0.0527232744953;
                                    }
                                } else {
                                    if (fs[69] <= 9911.0) {
                                        return -0.183646287709;
                                    } else {
                                        return 0.00716649739343;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[99] <= 0.5) {
                        if (fs[69] <= 9895.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0200723916803;
                                    } else {
                                        return 0.0179063449856;
                                    }
                                } else {
                                    if (fs[4] <= 22.0) {
                                        return 0.341567229504;
                                    } else {
                                        return -0.0198376116318;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 24.5) {
                                        return 0.00383696390327;
                                    } else {
                                        return -0.0233370194953;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.197881714994;
                                    } else {
                                        return -0.0489691858768;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.129367104333;
                                    } else {
                                        return -0.0606243991185;
                                    }
                                } else {
                                    return 0.16454512963;
                                }
                            } else {
                                if (fs[50] <= -1938.0) {
                                    return 0.281276996108;
                                } else {
                                    if (fs[69] <= 9942.5) {
                                        return 0.142951335521;
                                    } else {
                                        return 0.00218573048157;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1363.0) {
                            if (fs[4] <= 8.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[33] <= 0.5) {
                                        return -0.00599811295335;
                                    } else {
                                        return 0.14908725876;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0147480168517;
                                    } else {
                                        return 0.0869854134102;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return -0.0143614349841;
                                    } else {
                                        return 0.0352911317863;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0406031279452;
                                    } else {
                                        return 0.111998535369;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0222971588946;
                                    } else {
                                        return -0.0458020855403;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.0239350830966;
                                    } else {
                                        return 0.345056614802;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.0279688172556;
                                    } else {
                                        return -0.156603169376;
                                    }
                                } else {
                                    if (fs[69] <= 9848.0) {
                                        return 0.001615283811;
                                    } else {
                                        return -0.0639114062979;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[54] <= 0.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00327203184777;
                                    } else {
                                        return 0.0205602569453;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return 0.0416719439066;
                                    } else {
                                        return 0.00576854472383;
                                    }
                                }
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return -0.00192335002745;
                                    } else {
                                        return 0.0078559938115;
                                    }
                                } else {
                                    return 0.216071460679;
                                }
                            }
                        } else {
                            if (fs[50] <= -57.0) {
                                if (fs[73] <= 25.0) {
                                    if (fs[82] <= 3.5) {
                                        return -0.00223328134022;
                                    } else {
                                        return 0.00587212148436;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0843361724051;
                                    } else {
                                        return 0.00296323791049;
                                    }
                                }
                            } else {
                                if (fs[50] <= -47.0) {
                                    if (fs[49] <= 0.5) {
                                        return -0.00199642671735;
                                    } else {
                                        return 0.246219061762;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return 0.0107499438373;
                                    } else {
                                        return -0.00027748139577;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[82] <= 7.5) {
                                if (fs[91] <= 0.5) {
                                    if (fs[67] <= -4.0) {
                                        return -0.0551255656439;
                                    } else {
                                        return -0.0106774106828;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.267945141283;
                                    } else {
                                        return 0.0158409531168;
                                    }
                                }
                            } else {
                                return 0.319119392382;
                            }
                        } else {
                            return 0.183501574826;
                        }
                    }
                }
            }
        } else {
            if (fs[4] <= 4.5) {
                if (fs[2] <= 1.5) {
                    if (fs[68] <= 0.5) {
                        if (fs[50] <= -1138.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[50] <= -1488.0) {
                                    return -0.0306545767235;
                                } else {
                                    return 0.192281855658;
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[50] <= -1478.0) {
                                        return 0.0864206749895;
                                    } else {
                                        return 0.167689745897;
                                    }
                                } else {
                                    return 0.318390765513;
                                }
                            }
                        } else {
                            if (fs[69] <= 9995.5) {
                                if (fs[69] <= 9994.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.181105552657;
                                    } else {
                                        return -0.0126444725574;
                                    }
                                } else {
                                    return -0.136042474675;
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0454510752206;
                                    } else {
                                        return 0.144826808072;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.225571328104;
                                    } else {
                                        return 0.0355357709965;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[69] <= 9991.5) {
                                if (fs[11] <= 0.5) {
                                    return 0.108066622771;
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.000342541903475;
                                    } else {
                                        return -0.0513245661561;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[95] <= 1.5) {
                                        return -0.078610254913;
                                    } else {
                                        return 0.119217063587;
                                    }
                                } else {
                                    if (fs[82] <= 5.0) {
                                        return -0.0369385317613;
                                    } else {
                                        return 0.108223066924;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0299814926168;
                                    } else {
                                        return -0.0356760208898;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.206951553022;
                                    } else {
                                        return -0.158223763487;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9993.5) {
                                    if (fs[50] <= -1468.5) {
                                        return -0.0627112251467;
                                    } else {
                                        return 0.00469834899679;
                                    }
                                } else {
                                    return -0.188763678851;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[29] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.076079960457;
                                    } else {
                                        return 0.0415036641;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.0381003108321;
                                    } else {
                                        return 0.0786342495625;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[68] <= 0.5) {
                                        return 0.111793888536;
                                    } else {
                                        return 0.249770834107;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0791568797712;
                                    } else {
                                        return -0.0335440074314;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0561768754442;
                                    } else {
                                        return 0.113905989439;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.198537651652;
                                    } else {
                                        return 0.113753043102;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9988.5) {
                                    return 0.00114408503229;
                                } else {
                                    if (fs[69] <= 9994.5) {
                                        return 0.0985402859708;
                                    } else {
                                        return 0.0338036570311;
                                    }
                                }
                            }
                        }
                    } else {
                        return -0.256203695094;
                    }
                }
            } else {
                if (fs[88] <= 0.5) {
                    if (fs[50] <= -1403.5) {
                        if (fs[50] <= -1478.0) {
                            if (fs[4] <= 32.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0024580754435;
                                    } else {
                                        return 0.0421357889367;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.171923208478;
                                    } else {
                                        return 0.310225726915;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1838.5) {
                                    if (fs[4] <= 37.0) {
                                        return 0.136391559501;
                                    } else {
                                        return -0.0850849204752;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.21099384992;
                                    } else {
                                        return -0.115111368372;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 21.5) {
                                        return 0.0256589545047;
                                    } else {
                                        return 0.26085615449;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return -0.0518263010337;
                                    } else {
                                        return -0.328478746213;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[18] <= -0.5) {
                                        return -0.193492690012;
                                    } else {
                                        return 0.136882483428;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0427370799988;
                                    } else {
                                        return -0.154851861806;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[61] <= -995.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.085747328338;
                                    } else {
                                        return 0.191543427449;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0582302343695;
                                    } else {
                                        return 0.124302645686;
                                    }
                                }
                            } else {
                                if (fs[73] <= 100.0) {
                                    return 0.201239691569;
                                } else {
                                    return 0.119748958641;
                                }
                            }
                        } else {
                            if (fs[82] <= 5.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[54] <= 0.5) {
                                        return -0.00399336996342;
                                    } else {
                                        return 0.150648815912;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0422004759591;
                                    } else {
                                        return -0.180088076429;
                                    }
                                }
                            } else {
                                if (fs[67] <= -3.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.0719149351446;
                                    } else {
                                        return 0.207954654661;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.00544300988076;
                                    } else {
                                        return 0.0660275260921;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 29.5) {
                        if (fs[4] <= 10.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.0355610691542;
                                    } else {
                                        return 0.159822909516;
                                    }
                                } else {
                                    return -0.205633524971;
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    return -0.13037690479;
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0222031655358;
                                    } else {
                                        return -0.0138104889477;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 15.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.429115755493;
                                    } else {
                                        return 0.29237045718;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.10868911296;
                                    } else {
                                        return 0.228060104665;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[69] <= 9997.5) {
                                        return 0.127225859264;
                                    } else {
                                        return -0.308975086169;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.232580877522;
                                    } else {
                                        return 0.15068919346;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            return -0.193843772606;
                        } else {
                            return -0.122716585818;
                        }
                    }
                }
            }
        }
    }
}
