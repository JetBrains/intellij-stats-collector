/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree16 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[50] <= -987.5) {
                if (fs[4] <= 11.5) {
                    if (fs[71] <= 0.5) {
                        if (fs[50] <= -1143.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[78] <= 0.5) {
                                    if (fs[69] <= 9888.5) {
                                        return 0.0523282220931;
                                    } else {
                                        return 0.291809851922;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.400065570618;
                                    } else {
                                        return -0.0333074434673;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.323480779518;
                                    } else {
                                        return 0.385786636124;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0784785592701;
                                    } else {
                                        return 0.283323485319;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.333197935211;
                                    } else {
                                        return 0.414672158779;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.364286861601;
                                    } else {
                                        return 0.270150794107;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.408719598336;
                                    } else {
                                        return 0.215749506887;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.316909568715;
                                    } else {
                                        return 0.0672529649562;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[65] <= 1.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.0196162664557;
                                } else {
                                    if (fs[69] <= 4639.5) {
                                        return -0.0516667390996;
                                    } else {
                                        return -0.125419308164;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9914.0) {
                                    if (fs[50] <= -1123.5) {
                                        return 0.0371342190848;
                                    } else {
                                        return 0.372577386494;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.236083517855;
                                    } else {
                                        return 0.437872869334;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[50] <= -1318.0) {
                                    return -0.0609903142258;
                                } else {
                                    return 0.190441538684;
                                }
                            } else {
                                if (fs[69] <= 4619.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.382685657739;
                                    } else {
                                        return 0.561374398609;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.441906426979;
                                    } else {
                                        return 0.462974026117;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 4.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[2] <= 7.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[50] <= -1498.0) {
                                        return 0.400513392161;
                                    } else {
                                        return 0.247536915395;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.172307559663;
                                    } else {
                                        return -0.0790900356575;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[93] <= 0.5) {
                                        return 0.351706692957;
                                    } else {
                                        return 0.198225106468;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.452261424145;
                                    } else {
                                        return -0.0166800265412;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 17.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.368041212576;
                                    } else {
                                        return 0.469494796024;
                                    }
                                } else {
                                    if (fs[46] <= -1.5) {
                                        return 0.519324962707;
                                    } else {
                                        return 0.254036059887;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[50] <= -1938.0) {
                                        return 0.4208909418;
                                    } else {
                                        return 0.0783949704819;
                                    }
                                } else {
                                    if (fs[4] <= 42.5) {
                                        return 0.306419751352;
                                    } else {
                                        return -0.059420455512;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[37] <= 0.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.208808858191;
                                    } else {
                                        return 0.535734866944;
                                    }
                                } else {
                                    if (fs[50] <= -1413.0) {
                                        return 0.361472082654;
                                    } else {
                                        return -0.145285626322;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.146668520429;
                                    } else {
                                        return 0.309005178136;
                                    }
                                } else {
                                    if (fs[4] <= 14.0) {
                                        return 0.674984455665;
                                    } else {
                                        return -0.0606527742526;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 17.0) {
                                if (fs[14] <= 0.5) {
                                    return 0.557277871791;
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.546708019349;
                                    } else {
                                        return 0.445050954357;
                                    }
                                }
                            } else {
                                if (fs[4] <= 23.0) {
                                    if (fs[2] <= 6.5) {
                                        return 0.117205756403;
                                    } else {
                                        return 0.408581723217;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.457847499142;
                                    } else {
                                        return 0.330759295865;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 1.5) {
                    if (fs[61] <= -496.5) {
                        if (fs[69] <= 5000.0) {
                            if (fs[68] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    return -0.0796030431436;
                                } else {
                                    return 0.320925455423;
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.296788369682;
                                    } else {
                                        return 0.0425467813624;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.465531061246;
                                    } else {
                                        return 0.377136516144;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                return 0.509571116992;
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[82] <= 1.0) {
                                        return 0.336898425247;
                                    } else {
                                        return 0.454745898303;
                                    }
                                } else {
                                    return 0.466816096059;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9997.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.216681585598;
                                    } else {
                                        return 0.476716895566;
                                    }
                                } else {
                                    return -0.291690968271;
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[89] <= 0.5) {
                                        return 0.0207617313962;
                                    } else {
                                        return 0.23801028436;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return 0.162714812316;
                                    } else {
                                        return -0.0933752630084;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.548784675925;
                                    } else {
                                        return 0.28411648346;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.352852619638;
                                    } else {
                                        return 0.143523901243;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.267684075941;
                                    } else {
                                        return -0.161718872792;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0116427161862;
                                    } else {
                                        return 0.111775429179;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 10.5) {
                        if (fs[25] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.422301082166;
                                    } else {
                                        return 0.493388628797;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.402269513678;
                                    } else {
                                        return 0.0781792175309;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.396643594318;
                                    } else {
                                        return 0.238499076477;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.395673446715;
                                    } else {
                                        return 0.474445453492;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -461.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[56] <= 0.5) {
                                        return -0.171812117312;
                                    } else {
                                        return 0.0487934689688;
                                    }
                                } else {
                                    return 0.412508918539;
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.611738155438;
                                    } else {
                                        return 0.227157547612;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.318382775869;
                                    } else {
                                        return 0.0108285825451;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[69] <= 9703.0) {
                                    if (fs[2] <= 2.5) {
                                        return 0.147856587157;
                                    } else {
                                        return 0.271651504907;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.393113049868;
                                    } else {
                                        return 0.175565507754;
                                    }
                                }
                            } else {
                                if (fs[61] <= -994.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.468319216328;
                                    } else {
                                        return 0.310357797888;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0768046028964;
                                    } else {
                                        return -0.17331361368;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[91] <= 0.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.318822414242;
                                    } else {
                                        return 0.183415913367;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.537765397881;
                                    } else {
                                        return 0.299278162784;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0671913678285;
                                    } else {
                                        return -0.250327870116;
                                    }
                                } else {
                                    return 0.406755346482;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[95] <= 0.5) {
                if (fs[69] <= 9867.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[82] <= 7.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[75] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.080339858266;
                                    } else {
                                        return -0.03612958744;
                                    }
                                } else {
                                    if (fs[82] <= -0.5) {
                                        return -0.0381293857091;
                                    } else {
                                        return -0.00694651113707;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[4] <= 5.0) {
                                        return 0.540100924084;
                                    } else {
                                        return 0.312382052331;
                                    }
                                } else {
                                    return 0.472875015866;
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0123724787758;
                                    } else {
                                        return 0.0543131997107;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.178618710724;
                                    } else {
                                        return 0.0186618576241;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.132854391337;
                                    } else {
                                        return 0.569002353871;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0886720287011;
                                    } else {
                                        return 0.279137157054;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 8.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0333779235753;
                                    } else {
                                        return -0.0178369393548;
                                    }
                                } else {
                                    if (fs[50] <= -1428.0) {
                                        return 0.0710554441291;
                                    } else {
                                        return -0.0170426744009;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0167500248945;
                                    } else {
                                        return -0.025390721458;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.198013675751;
                                    } else {
                                        return -0.0327503314903;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= 3.0) {
                                if (fs[33] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.0257732777263;
                                    } else {
                                        return -0.0240562331625;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return -0.0102788562924;
                                    } else {
                                        return -0.0231090177348;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0276580073643;
                                    } else {
                                        return -0.0295922871761;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0269024188464;
                                    } else {
                                        return -0.0280350823843;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[50] <= -1138.5) {
                            if (fs[18] <= -0.5) {
                                return -0.164019832611;
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0069087236813;
                                    } else {
                                        return 0.130727673941;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0744685006491;
                                    } else {
                                        return 0.223735254078;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0881560659283;
                                    } else {
                                        return 0.276780871504;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0329465800619;
                                    } else {
                                        return 0.110814389901;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.0960200747859;
                                    } else {
                                        return -0.0999821076991;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return -0.0911646222454;
                                    } else {
                                        return -0.00642400819606;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 8.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0258035641006;
                                    } else {
                                        return -0.00668001970164;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.0730269129089;
                                    } else {
                                        return 0.371119527953;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0849518362208;
                                    } else {
                                        return 0.354052383643;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.141312894869;
                                    } else {
                                        return -0.0248030785562;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0117558936457;
                                    } else {
                                        return -0.017224649349;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0349142164207;
                                    } else {
                                        return -0.0283433333542;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 12.5) {
                                        return 0.0926472395141;
                                    } else {
                                        return 0.00444945011619;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0271073021386;
                                    } else {
                                        return 0.52155096331;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 13.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[39] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[69] <= 9971.5) {
                                        return -0.0101143444544;
                                    } else {
                                        return 0.0532823172045;
                                    }
                                } else {
                                    if (fs[73] <= 150.0) {
                                        return 0.054227477742;
                                    } else {
                                        return 0.0130908133129;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1283.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.213329948374;
                                    } else {
                                        return 0.0934254681891;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0490609027196;
                                    } else {
                                        return -0.00546792679242;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 1.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.076585213638;
                                    } else {
                                        return -0.00082575579272;
                                    }
                                } else {
                                    return 0.547535337959;
                                }
                            } else {
                                if (fs[50] <= -988.0) {
                                    if (fs[0] <= 9.5) {
                                        return 0.099123738531;
                                    } else {
                                        return 0.449881703776;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0365555809302;
                                    } else {
                                        return -0.0586833374951;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[46] <= -1.5) {
                            if (fs[97] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.044512897874;
                                    } else {
                                        return -0.0367790356217;
                                    }
                                } else {
                                    return -0.0321574909633;
                                }
                            } else {
                                if (fs[61] <= -997.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0303019333849;
                                    } else {
                                        return -0.0277731474339;
                                    }
                                } else {
                                    if (fs[50] <= -986.5) {
                                        return -0.0315540205905;
                                    } else {
                                        return -0.0387117016292;
                                    }
                                }
                            }
                        } else {
                            if (fs[65] <= 1.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return -0.0254587719144;
                                    } else {
                                        return 0.14126969834;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0305712804873;
                                    } else {
                                        return -0.0271429086622;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.00747345831367;
                                    } else {
                                        return -0.0284343385307;
                                    }
                                } else {
                                    if (fs[0] <= 10.5) {
                                        return 0.325946281355;
                                    } else {
                                        return -0.0291002562898;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[73] <= 150.0) {
                            if (fs[14] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0267570680767;
                                    } else {
                                        return 0.0911628921417;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0998666168477;
                                    } else {
                                        return -0.0414208255134;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[4] <= 16.5) {
                                        return 0.224338246967;
                                    } else {
                                        return -0.0424145947354;
                                    }
                                } else {
                                    return 0.66747660899;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0957768758506;
                                    } else {
                                        return 0.403186635039;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0140393970491;
                                    } else {
                                        return 0.270657102757;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.00445094170102;
                                    } else {
                                        return 0.0574186195629;
                                    }
                                } else {
                                    if (fs[50] <= -1958.5) {
                                        return 0.270577076;
                                    } else {
                                        return -0.0239851837517;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 3.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[67] <= -1.5) {
                                    if (fs[69] <= 9983.5) {
                                        return 0.00703591013993;
                                    } else {
                                        return 0.0413137703971;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return -0.0277248568626;
                                    } else {
                                        return -0.0445510097142;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[95] <= 1.5) {
                                        return -0.012512433751;
                                    } else {
                                        return -0.0261559089748;
                                    }
                                } else {
                                    if (fs[50] <= -937.0) {
                                        return -0.0150906827878;
                                    } else {
                                        return 0.0533429293354;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 8.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.0126895089865;
                                    } else {
                                        return -0.0237637686083;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.138413390646;
                                    } else {
                                        return -0.00866851064224;
                                    }
                                }
                            } else {
                                if (fs[61] <= -995.5) {
                                    if (fs[0] <= 49.5) {
                                        return -0.0149305023487;
                                    } else {
                                        return 0.182894747408;
                                    }
                                } else {
                                    if (fs[0] <= 72.5) {
                                        return -0.0255799623326;
                                    } else {
                                        return -0.0141158411775;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
