/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree62 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 3.5) {
                if (fs[50] <= -1498.5) {
                    if (fs[67] <= -1.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[50] <= -1838.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0417075828057;
                                    } else {
                                        return 0.109390477573;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return 0.107678397516;
                                    } else {
                                        return 0.316128863869;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[62] <= 0.5) {
                                        return 0.174534067597;
                                    } else {
                                        return 0.101528332507;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.119262504839;
                                    } else {
                                        return -0.0611113413834;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 1.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.089818456164;
                                    } else {
                                        return -0.230603585168;
                                    }
                                } else {
                                    if (fs[82] <= -0.5) {
                                        return -0.0480136045961;
                                    } else {
                                        return -0.189477766393;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    if (fs[50] <= -1618.0) {
                                        return 0.19870298519;
                                    } else {
                                        return 0.0316394256881;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.0366920855655;
                                    } else {
                                        return -0.256357081742;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[75] <= 0.5) {
                            if (fs[50] <= -1568.0) {
                                if (fs[2] <= 1.5) {
                                    return -0.0658468381526;
                                } else {
                                    return 0.127168813289;
                                }
                            } else {
                                return -0.128090202226;
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[4] <= 36.0) {
                                    return -0.372792486011;
                                } else {
                                    return -0.0558275869267;
                                }
                            } else {
                                return -0.128675668492;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0822901863368;
                                    } else {
                                        return 0.0024673110002;
                                    }
                                } else {
                                    if (fs[4] <= 1.5) {
                                        return -0.0176645464454;
                                    } else {
                                        return 0.0316487966397;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0395748543546;
                                    } else {
                                        return -0.279552284402;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0100651440247;
                                    } else {
                                        return 0.0226754583748;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 4.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0409538169164;
                                    } else {
                                        return -0.0207668779549;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0197884271791;
                                    } else {
                                        return 0.201701381044;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0885967776029;
                                    } else {
                                        return 0.0559847129311;
                                    }
                                } else {
                                    return -0.104152371245;
                                }
                            }
                        }
                    } else {
                        if (fs[97] <= 0.5) {
                            if (fs[86] <= 0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[4] <= 29.5) {
                                        return 0.0810042251523;
                                    } else {
                                        return -0.179115896588;
                                    }
                                } else {
                                    if (fs[73] <= 150.0) {
                                        return -0.205699849689;
                                    } else {
                                        return -0.124168704306;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9986.5) {
                                    if (fs[50] <= -1488.0) {
                                        return -0.0888151181184;
                                    } else {
                                        return -0.0245158257701;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0189683487844;
                                    } else {
                                        return -0.0691809543732;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0255971300731;
                                    } else {
                                        return -0.0759950839584;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.00959615871105;
                                    } else {
                                        return 0.0373803658399;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[4] <= 26.5) {
                                        return 0.0439303003097;
                                    } else {
                                        return -0.0458100989837;
                                    }
                                } else {
                                    if (fs[61] <= -994.5) {
                                        return 0.0886427475491;
                                    } else {
                                        return 0.241679483792;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[8] <= 0.5) {
                    if (fs[2] <= 10.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[4] <= 21.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0509097805382;
                                    } else {
                                        return 0.0897700923318;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.0114282171521;
                                    } else {
                                        return -0.03640767905;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1468.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0505535263963;
                                    } else {
                                        return 0.0070535163841;
                                    }
                                } else {
                                    if (fs[69] <= 8781.0) {
                                        return -0.0959533442665;
                                    } else {
                                        return 0.0300448515753;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    return -0.119238563717;
                                } else {
                                    return 0.11640052022;
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    return -0.334153816034;
                                } else {
                                    return -0.180346263231;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 27.5) {
                            if (fs[76] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[2] <= 13.5) {
                                        return 0.123795603649;
                                    } else {
                                        return 0.182787523629;
                                    }
                                } else {
                                    if (fs[82] <= 3.0) {
                                        return 0.161320934707;
                                    } else {
                                        return 0.283133674077;
                                    }
                                }
                            } else {
                                return 0.0327852745737;
                            }
                        } else {
                            return -0.00544277733135;
                        }
                    }
                } else {
                    if (fs[69] <= 4998.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[4] <= 12.5) {
                                return -0.210883350738;
                            } else {
                                return -0.232663658759;
                            }
                        } else {
                            return -0.347047012733;
                        }
                    } else {
                        return 0.0564950203309;
                    }
                }
            }
        } else {
            if (fs[14] <= 0.5) {
                if (fs[0] <= 2.5) {
                    if (fs[4] <= 18.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[25] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.00620393406417;
                                    } else {
                                        return 0.112087118802;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.018090573013;
                                    } else {
                                        return -0.00617439882642;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1408.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0414335372052;
                                    } else {
                                        return 0.00537519247636;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.0020262312651;
                                    } else {
                                        return 0.195398156458;
                                    }
                                }
                            }
                        } else {
                            if (fs[65] <= 1.5) {
                                if (fs[50] <= -981.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.0161143438009;
                                    } else {
                                        return -0.00112425255993;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.014178884197;
                                    } else {
                                        return 0.0238424469347;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    return 0.185440527164;
                                } else {
                                    return -0.0128767733656;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -4488.0) {
                            return 0.354539377163;
                        } else {
                            if (fs[28] <= 0.5) {
                                if (fs[52] <= 50.5) {
                                    if (fs[37] <= 0.5) {
                                        return -0.00864687549684;
                                    } else {
                                        return 0.0250084043063;
                                    }
                                } else {
                                    return 0.154050381793;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.198490644846;
                                    } else {
                                        return 0.0379737618699;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0881833450122;
                                    } else {
                                        return -0.0560967390454;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 3.5) {
                        if (fs[82] <= 3.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 1.5) {
                                    if (fs[91] <= 0.5) {
                                        return -0.0139805475658;
                                    } else {
                                        return -0.0517585020008;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.00476921308279;
                                    } else {
                                        return 0.0247257458201;
                                    }
                                }
                            } else {
                                if (fs[75] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.205047807454;
                                    } else {
                                        return 0.00661646701047;
                                    }
                                } else {
                                    if (fs[92] <= 0.5) {
                                        return -0.00301451766829;
                                    } else {
                                        return 0.024391862185;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0224849748153;
                                    } else {
                                        return 0.0315729096056;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return -0.0234823313984;
                                    } else {
                                        return -0.0214171655567;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.00279408250079;
                                    } else {
                                        return 0.0538342580426;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0388666654454;
                                    } else {
                                        return -0.0207005033664;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[0] <= 20.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.00110569802566;
                                    } else {
                                        return -0.00469363438837;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.00300857215243;
                                    } else {
                                        return 0.0137664547896;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 118.5) {
                                        return -0.00316698261514;
                                    } else {
                                        return 1.34619910407e-05;
                                    }
                                } else {
                                    return 0.0794008487841;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[69] <= 8918.5) {
                                    if (fs[50] <= -996.5) {
                                        return -0.00274754407927;
                                    } else {
                                        return -0.0035943791583;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.0242680124443;
                                    } else {
                                        return -0.004849357302;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9867.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.00260683489071;
                                    } else {
                                        return 0.00284125633729;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.0205686129431;
                                    } else {
                                        return 0.150078516838;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 5.5) {
                    if (fs[67] <= -4.0) {
                        if (fs[99] <= 0.5) {
                            if (fs[0] <= 9.5) {
                                return -0.0474213883966;
                            } else {
                                if (fs[0] <= 17.0) {
                                    return 0.0677751942814;
                                } else {
                                    return -0.0154761708485;
                                }
                            }
                        } else {
                            return -0.0348520217526;
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[82] <= 6.5) {
                                    return -0.0355862623494;
                                } else {
                                    return 0.0968857859426;
                                }
                            } else {
                                return 0.136410580193;
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                return 0.131848945027;
                            } else {
                                return 0.47721228787;
                            }
                        }
                    }
                } else {
                    if (fs[95] <= 1.5) {
                        if (fs[69] <= 9919.0) {
                            if (fs[73] <= 75.0) {
                                if (fs[29] <= 0.5) {
                                    if (fs[50] <= -1128.0) {
                                        return -0.0105605274002;
                                    } else {
                                        return 0.00453880654032;
                                    }
                                } else {
                                    return 0.183811991825;
                                }
                            } else {
                                if (fs[4] <= 21.5) {
                                    if (fs[4] <= 20.5) {
                                        return 0.0136639735948;
                                    } else {
                                        return 0.266773881183;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0590802393943;
                                    } else {
                                        return -0.00755068798545;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9992.5) {
                                if (fs[50] <= -1232.0) {
                                    return 0.511077036055;
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return 0.182468582376;
                                    } else {
                                        return 0.0149087529444;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[82] <= 1.0) {
                                        return 0.234723826805;
                                    } else {
                                        return -0.0585679016778;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.00679758424597;
                                    } else {
                                        return -0.0988011078565;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.25770254065;
                                    } else {
                                        return 0.0720813688654;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.128137612329;
                                    } else {
                                        return 0.044694451612;
                                    }
                                }
                            } else {
                                if (fs[50] <= -21.0) {
                                    if (fs[73] <= 250.0) {
                                        return -0.00249011910868;
                                    } else {
                                        return 0.15765970512;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.20162661628;
                                    } else {
                                        return 0.475367642389;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                return 0.354027242321;
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0313754769003;
                                    } else {
                                        return 0.046346356727;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0649446321541;
                                    } else {
                                        return -0.0071321550989;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
