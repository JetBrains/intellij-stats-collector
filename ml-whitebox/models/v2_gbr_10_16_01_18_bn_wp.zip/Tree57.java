/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree57 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9981.5) {
            if (fs[75] <= 0.5) {
                if (fs[11] <= 0.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[50] <= -1138.0) {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0331607353474;
                                    } else {
                                        return -0.0345401411588;
                                    }
                                } else {
                                    if (fs[7] <= 0.5) {
                                        return 0.0625984424533;
                                    } else {
                                        return 0.151377370669;
                                    }
                                }
                            } else {
                                if (fs[15] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.074310603656;
                                    } else {
                                        return -0.0032774139763;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.00512399791069;
                                    } else {
                                        return 0.0511616795258;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.136217144701;
                                    } else {
                                        return 0.0957442807071;
                                    }
                                } else {
                                    return -0.0917824908209;
                                }
                            } else {
                                if (fs[50] <= -983.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0720057829582;
                                    } else {
                                        return 0.0589768398913;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0338307879002;
                                    } else {
                                        return 0.132346613677;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            return -0.118513890843;
                        } else {
                            if (fs[50] <= -1488.0) {
                                return 0.0421194797113;
                            } else {
                                if (fs[4] <= 26.5) {
                                    return -0.0309190267296;
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0431273820349;
                                    } else {
                                        return -0.0150515428199;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0782499898383;
                                    } else {
                                        return 0.0137709529072;
                                    }
                                } else {
                                    if (fs[50] <= -983.0) {
                                        return 0.0661837325943;
                                    } else {
                                        return -0.0573593089693;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0568919163913;
                                    } else {
                                        return 0.037485213139;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0324150398661;
                                    } else {
                                        return 0.0541489592438;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 19.5) {
                                if (fs[33] <= 0.5) {
                                    return -0.0641587188381;
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0939857848221;
                                    } else {
                                        return 0.121378722733;
                                    }
                                }
                            } else {
                                if (fs[4] <= 29.5) {
                                    if (fs[4] <= 22.5) {
                                        return -0.0423854672239;
                                    } else {
                                        return -0.181331369951;
                                    }
                                } else {
                                    return 0.027540458522;
                                }
                            }
                        }
                    } else {
                        if (fs[34] <= 0.5) {
                            if (fs[50] <= -1108.0) {
                                if (fs[49] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0308121553531;
                                    } else {
                                        return -0.0599622388182;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.046905485383;
                                    } else {
                                        return -0.0105943174306;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return -0.0257826179538;
                                    } else {
                                        return -0.0102412324744;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.075335153998;
                                    } else {
                                        return -0.0687739557635;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                return 0.106345230943;
                            } else {
                                return 0.236349585373;
                            }
                        }
                    }
                }
            } else {
                if (fs[93] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[82] <= 6.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[50] <= -1504.0) {
                                        return 0.100387025065;
                                    } else {
                                        return 0.00714774577201;
                                    }
                                } else {
                                    if (fs[50] <= -1509.0) {
                                        return 0.182623948838;
                                    } else {
                                        return 0.06559815227;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.00936237708476;
                                    } else {
                                        return 0.0726391405312;
                                    }
                                } else {
                                    if (fs[82] <= 1.5) {
                                        return -0.150983490497;
                                    } else {
                                        return -0.0346897174297;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -967.5) {
                                    if (fs[50] <= -1478.5) {
                                        return -0.00805457779325;
                                    } else {
                                        return 0.133029540696;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.093529979516;
                                    } else {
                                        return -0.249129713244;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[4] <= 23.5) {
                                        return 0.0759538241366;
                                    } else {
                                        return -0.405733469138;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.194596420222;
                                    } else {
                                        return -0.101710297094;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[18] <= 0.5) {
                                if (fs[67] <= -3.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0403040912983;
                                    } else {
                                        return 0.00354736812583;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.00749040931394;
                                    } else {
                                        return -0.00341250658952;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.00608839109276;
                                    } else {
                                        return -0.00544334887571;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return -0.00183156952216;
                                    } else {
                                        return -0.00472712274276;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00133196301385;
                                    } else {
                                        return 0.0637487965071;
                                    }
                                } else {
                                    if (fs[50] <= -1308.0) {
                                        return 0.0415543551077;
                                    } else {
                                        return -0.00286526364821;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.00436442021471;
                                    } else {
                                        return -0.00506565212612;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0173127944814;
                                    } else {
                                        return 0.0801232083418;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0408753839071;
                                    } else {
                                        return 0.0674558896843;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return 0.00255607899861;
                                    } else {
                                        return -0.27042348387;
                                    }
                                }
                            } else {
                                if (fs[59] <= -0.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.146652333725;
                                    } else {
                                        return 0.0440903882658;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.296087216478;
                                    } else {
                                        return 0.210049507788;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[69] <= 9946.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.112683518603;
                                    } else {
                                        return 0.00288782344394;
                                    }
                                } else {
                                    return -0.255476925027;
                                }
                            } else {
                                if (fs[50] <= -1928.0) {
                                    return 0.3442504338;
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.139922623008;
                                    } else {
                                        return -0.0319948460235;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 19.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00833962618604;
                                    } else {
                                        return 0.0224866446485;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0166077431082;
                                    } else {
                                        return 0.0609511425575;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.0145852285696;
                                    } else {
                                        return 0.265582086841;
                                    }
                                } else {
                                    return 0.140618986468;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0383251860767;
                                    } else {
                                        return 0.00827206446918;
                                    }
                                } else {
                                    if (fs[0] <= 81.5) {
                                        return -0.00195021902641;
                                    } else {
                                        return 0.0845073708299;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.0041050054169;
                                    } else {
                                        return 0.0301843251282;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.00333367870948;
                                    } else {
                                        return -0.00549462880939;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[50] <= -1052.5) {
                if (fs[87] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[37] <= 0.5) {
                            if (fs[73] <= 75.0) {
                                if (fs[50] <= -1608.0) {
                                    if (fs[50] <= -1733.5) {
                                        return 0.110524835012;
                                    } else {
                                        return 0.219373651855;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0729054294149;
                                    } else {
                                        return 0.0263565130117;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[50] <= -1473.5) {
                                        return 0.0285837866345;
                                    } else {
                                        return 0.0960256663695;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.212068137542;
                                    } else {
                                        return 0.0321762107729;
                                    }
                                }
                            }
                        } else {
                            if (fs[14] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.226966882539;
                                    } else {
                                        return 0.109526258327;
                                    }
                                } else {
                                    return 0.0777914875293;
                                }
                            } else {
                                if (fs[4] <= 18.0) {
                                    if (fs[95] <= 1.0) {
                                        return 0.109791436668;
                                    } else {
                                        return 0.224247954426;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return -0.131263290624;
                                    } else {
                                        return 0.00483641781818;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[73] <= 150.0) {
                                    if (fs[50] <= -1117.5) {
                                        return 0.0207220507913;
                                    } else {
                                        return 0.349925690521;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.0225646089238;
                                    } else {
                                        return 0.0410952540705;
                                    }
                                }
                            } else {
                                if (fs[63] <= 5.0) {
                                    if (fs[4] <= 30.5) {
                                        return 0.0631000133043;
                                    } else {
                                        return -0.171981560194;
                                    }
                                } else {
                                    return -0.254927472857;
                                }
                            }
                        } else {
                            if (fs[50] <= -1488.0) {
                                if (fs[4] <= 21.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.078086661466;
                                    } else {
                                        return -0.167873006748;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.156116838694;
                                    } else {
                                        return 0.488413916991;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.139056914527;
                                    } else {
                                        return 0.462505975935;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.182170510716;
                                    } else {
                                        return -0.0108183939468;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9998.5) {
                        if (fs[73] <= 150.0) {
                            if (fs[0] <= 0.5) {
                                return -0.343999237269;
                            } else {
                                if (fs[95] <= 0.5) {
                                    return -0.147342514826;
                                } else {
                                    return -0.189530634954;
                                }
                            }
                        } else {
                            return -0.166636419272;
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            return -0.0449629948041;
                        } else {
                            return -0.217599013003;
                        }
                    }
                }
            } else {
                if (fs[25] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return -0.0105112863312;
                                    } else {
                                        return 0.0769803509821;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.159926181249;
                                    } else {
                                        return 0.0548472248906;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.11179285423;
                                    } else {
                                        return 0.0484719650924;
                                    }
                                } else {
                                    return -0.271870646949;
                                }
                            }
                        } else {
                            if (fs[62] <= 0.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[61] <= -498.0) {
                                        return 0.123765687308;
                                    } else {
                                        return -0.0141768284853;
                                    }
                                } else {
                                    return 0.259688214499;
                                }
                            } else {
                                return -0.336745180188;
                            }
                        }
                    } else {
                        if (fs[73] <= 150.0) {
                            if (fs[49] <= 0.5) {
                                if (fs[61] <= -498.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.112122768928;
                                    } else {
                                        return 0.234446876957;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.01529119526;
                                    } else {
                                        return -0.0175031426385;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.129808581029;
                                    } else {
                                        return 0.0306598862328;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.00870666133237;
                                    } else {
                                        return 0.0425647576468;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0426894016336;
                                    } else {
                                        return -0.009591187772;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return 0.0832744626433;
                                    } else {
                                        return -0.00688237451171;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.0) {
                                    if (fs[33] <= 0.5) {
                                        return -0.00136696392631;
                                    } else {
                                        return 0.359276627394;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0792171097949;
                                    } else {
                                        return -0.010534738328;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 7.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    return 0.370610680638;
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.130752621414;
                                    } else {
                                        return -0.0533148742535;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.053996874419;
                                    } else {
                                        return -0.110142451554;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.0324160142301;
                                    } else {
                                        return 0.208043232518;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[69] <= 9987.5) {
                                    return -0.104724575856;
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.301808392377;
                                    } else {
                                        return -0.242247961451;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 15.5) {
                                        return -0.0849316675685;
                                    } else {
                                        return -0.00558644517203;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.0479501139335;
                                    } else {
                                        return -0.0232005148369;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 12.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[69] <= 9995.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0240257163938;
                                    } else {
                                        return -0.0295614491767;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0487603632541;
                                    } else {
                                        return -0.0620691264018;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return -0.00509973365056;
                                    } else {
                                        return -0.0086044225076;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.0234737094771;
                                    } else {
                                        return -0.0121570880436;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.119716099306;
                                    } else {
                                        return -0.00466751628341;
                                    }
                                } else {
                                    if (fs[50] <= 3.5) {
                                        return -0.0213738598057;
                                    } else {
                                        return -0.00444605508826;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    return 0.109444512283;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.00988913895284;
                                    } else {
                                        return 0.011200012426;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
