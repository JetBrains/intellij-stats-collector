/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree88 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[50] <= -1493.5) {
                    if (fs[4] <= 12.5) {
                        if (fs[73] <= 75.0) {
                            if (fs[25] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[82] <= 3.5) {
                                        return 0.0831501809824;
                                    } else {
                                        return -0.0570192339859;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.0928608102002;
                                    } else {
                                        return 0.0597563594964;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1574.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.333228750619;
                                    } else {
                                        return 0.0562925794185;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.131575383778;
                                    } else {
                                        return -0.0546909886884;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[50] <= -2473.5) {
                                        return -0.111929396037;
                                    } else {
                                        return 0.0446289002253;
                                    }
                                } else {
                                    return 0.107389438376;
                                }
                            } else {
                                if (fs[50] <= -2473.5) {
                                    return 0.0152404800055;
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.179487411854;
                                    } else {
                                        return 0.103754335233;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 0.5) {
                            return -0.289256923735;
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.0322251714283;
                                    } else {
                                        return 0.0358115070173;
                                    }
                                } else {
                                    if (fs[50] <= -1568.0) {
                                        return 0.0647699047868;
                                    } else {
                                        return 0.145339782443;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    return 0.144363817688;
                                } else {
                                    if (fs[50] <= -2018.0) {
                                        return 0.122246630326;
                                    } else {
                                        return -0.0395098203583;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1488.5) {
                        if (fs[37] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[69] <= 9297.0) {
                                        return -0.0455620101713;
                                    } else {
                                        return -0.140467679899;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.0196426985712;
                                    } else {
                                        return 0.127720827948;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[69] <= 9991.5) {
                                        return -0.0540148747689;
                                    } else {
                                        return -0.0140511932583;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.00325968113431;
                                    } else {
                                        return 0.0774280308928;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[69] <= 4768.0) {
                                    return -0.09527903555;
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.173519229235;
                                    } else {
                                        return -0.0544434830152;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.0) {
                                    return 0.279369353975;
                                } else {
                                    return 0.1399635601;
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[50] <= -861.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.0102153841491;
                                    } else {
                                        return -0.150739506718;
                                    }
                                } else {
                                    if (fs[50] <= -982.0) {
                                        return 0.0302575658189;
                                    } else {
                                        return 0.255012370221;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return -0.0315203701548;
                                    } else {
                                        return -0.340291268264;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0614267552145;
                                    } else {
                                        return 0.0248768800748;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.045534318447;
                                    } else {
                                        return 0.0212324566778;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.107548258291;
                                    } else {
                                        return -0.0476804940905;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.093283020107;
                                    } else {
                                        return 0.220386380339;
                                    }
                                } else {
                                    return -0.264448841689;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[67] <= -3.5) {
                    if (fs[82] <= -0.5) {
                        return -0.351360489974;
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[4] <= 16.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0578362088304;
                                    } else {
                                        return -0.000590455691579;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0947936324542;
                                    } else {
                                        return -0.354116467226;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.0) {
                                    if (fs[4] <= 24.5) {
                                        return -0.142161779235;
                                    } else {
                                        return 0.136986033426;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.293618418971;
                                    } else {
                                        return 0.449262364404;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9997.5) {
                                if (fs[4] <= 15.5) {
                                    if (fs[2] <= 8.5) {
                                        return 0.13909100941;
                                    } else {
                                        return 0.196770973018;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.11653827179;
                                    } else {
                                        return 0.163714879389;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    return 0.0318015124774;
                                } else {
                                    return -0.00703387878657;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 9.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[50] <= -1443.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0360891208333;
                                    } else {
                                        return 0.067486857811;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0148474395984;
                                    } else {
                                        return -0.0217943982786;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0235762924422;
                                    } else {
                                        return -0.00373062162642;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.0404831917894;
                                    } else {
                                        return 0.171283681287;
                                    }
                                }
                            }
                        } else {
                            if (fs[89] <= 0.5) {
                                if (fs[47] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.0219480965095;
                                    } else {
                                        return 0.242906085497;
                                    }
                                } else {
                                    return -0.252522728692;
                                }
                            } else {
                                return 0.180558359313;
                            }
                        }
                    } else {
                        if (fs[4] <= 10.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[50] <= -1478.0) {
                                    if (fs[69] <= 9900.5) {
                                        return 0.154633089906;
                                    } else {
                                        return -0.0471738623958;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.00100659318457;
                                    } else {
                                        return -0.0930960941787;
                                    }
                                }
                            } else {
                                return -0.231104339336;
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[92] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.139346348272;
                                    } else {
                                        return 0.096326067768;
                                    }
                                } else {
                                    if (fs[2] <= 11.5) {
                                        return -0.0482670561946;
                                    } else {
                                        return 0.0276813143503;
                                    }
                                }
                            } else {
                                if (fs[4] <= 20.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0142548212151;
                                    } else {
                                        return 0.103755561865;
                                    }
                                } else {
                                    if (fs[2] <= 16.5) {
                                        return -0.0663322524741;
                                    } else {
                                        return 0.121069393073;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[52] <= 0.5) {
                if (fs[69] <= 9999.5) {
                    if (fs[50] <= -4913.0) {
                        return 0.172616695079;
                    } else {
                        if (fs[29] <= 0.5) {
                            if (fs[59] <= -1.5) {
                                if (fs[50] <= -1093.0) {
                                    if (fs[61] <= -996.5) {
                                        return 0.165719248024;
                                    } else {
                                        return 0.0183633976471;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.119830279962;
                                    } else {
                                        return 0.00120667897151;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.000110248949948;
                                    } else {
                                        return -0.000980388402856;
                                    }
                                } else {
                                    if (fs[69] <= 9897.0) {
                                        return 0.00152826704779;
                                    } else {
                                        return 0.0705089959649;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0946526938294;
                                    } else {
                                        return -0.0211461384607;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.046315289798;
                                    } else {
                                        return -0.00552295460009;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1092.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0917946699729;
                                    } else {
                                        return -0.00483547881987;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0186781964687;
                                    } else {
                                        return -0.04760510166;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[54] <= 0.5) {
                        if (fs[50] <= -1968.0) {
                            if (fs[0] <= 2.5) {
                                if (fs[91] <= 0.5) {
                                    return 0.0662488841336;
                                } else {
                                    return 0.228581258934;
                                }
                            } else {
                                return 0.336002712813;
                            }
                        } else {
                            if (fs[4] <= 18.5) {
                                if (fs[50] <= -1108.0) {
                                    if (fs[4] <= 13.5) {
                                        return 0.0207086889196;
                                    } else {
                                        return 0.102525342629;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.00105133801014;
                                    } else {
                                        return -0.132774404574;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0734177019687;
                                    } else {
                                        return -0.00933217658509;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.181738276736;
                                    } else {
                                        return -0.00551605753136;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.330568173351;
                    }
                }
            } else {
                if (fs[0] <= 5.5) {
                    if (fs[73] <= 75.0) {
                        if (fs[52] <= 547.0) {
                            if (fs[50] <= -42.5) {
                                return 0.279166433005;
                            } else {
                                return 0.102038277546;
                            }
                        } else {
                            return -0.118884805554;
                        }
                    } else {
                        return 0.207346826872;
                    }
                } else {
                    if (fs[50] <= -1262.5) {
                        return 0.057699209592;
                    } else {
                        if (fs[52] <= 995.5) {
                            if (fs[4] <= 11.5) {
                                return 0.0166410508183;
                            } else {
                                if (fs[0] <= 10.5) {
                                    return -0.0151379755604;
                                } else {
                                    if (fs[0] <= 14.5) {
                                        return -0.00731447458765;
                                    } else {
                                        return -0.0109469372359;
                                    }
                                }
                            }
                        } else {
                            return -0.0345661708429;
                        }
                    }
                }
            }
        }
    }
}
