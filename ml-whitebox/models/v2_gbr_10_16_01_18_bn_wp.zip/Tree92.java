/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree92 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[61] <= -997.5) {
                if (fs[57] <= 0.5) {
                    if (fs[95] <= 0.5) {
                        return -0.248050195772;
                    } else {
                        if (fs[73] <= 250.0) {
                            if (fs[84] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    return 0.11055071006;
                                } else {
                                    return 0.0326214694182;
                                }
                            } else {
                                return 0.0433512512817;
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[61] <= -998.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0714519719932;
                                    } else {
                                        return -0.0597683514;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.164890469203;
                                    } else {
                                        return -0.037102129729;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.102916852688;
                                    } else {
                                        return -0.0120815804101;
                                    }
                                } else {
                                    if (fs[50] <= -1042.5) {
                                        return 0.0688723189932;
                                    } else {
                                        return -0.00978131958835;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[14] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[4] <= 21.5) {
                                if (fs[50] <= -1458.0) {
                                    if (fs[82] <= 1.0) {
                                        return 0.134216056328;
                                    } else {
                                        return 0.00291400139973;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return -0.0178362335566;
                                    } else {
                                        return 0.0308444864585;
                                    }
                                }
                            } else {
                                return -0.187452245253;
                            }
                        } else {
                            if (fs[61] <= -998.5) {
                                return -0.0250711869655;
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.00945292542369;
                                    } else {
                                        return -0.00212619301039;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0119150655752;
                                    } else {
                                        return -0.0165884307772;
                                    }
                                }
                            }
                        }
                    } else {
                        return -0.138764639434;
                    }
                }
            } else {
                if (fs[54] <= 0.5) {
                    if (fs[84] <= 0.5) {
                        if (fs[59] <= -2.5) {
                            if (fs[33] <= 0.5) {
                                return -0.0069164849216;
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.294029207423;
                                } else {
                                    return 0.0654660247672;
                                }
                            }
                        } else {
                            if (fs[75] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0361447027945;
                                    } else {
                                        return 0.133505230731;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.00811814758191;
                                    } else {
                                        return -0.00134100298113;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9981.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.00446638296043;
                                    } else {
                                        return -0.000592621134546;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0130987395902;
                                    } else {
                                        return -0.00735230739963;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[79] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00654265956006;
                                    } else {
                                        return -0.0200583010572;
                                    }
                                } else {
                                    if (fs[59] <= -3.5) {
                                        return -0.295941546086;
                                    } else {
                                        return 0.0151964791228;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1948.0) {
                                    if (fs[0] <= 2.5) {
                                        return 0.113137886359;
                                    } else {
                                        return -0.00538053993068;
                                    }
                                } else {
                                    if (fs[69] <= 9989.5) {
                                        return -4.7428557963e-05;
                                    } else {
                                        return -0.012925107097;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9345.0) {
                                if (fs[50] <= -1282.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.0506075326067;
                                    } else {
                                        return 0.149232744609;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.101190313455;
                                    } else {
                                        return -0.00921691086023;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0847408463973;
                                    } else {
                                        return -0.0105777060358;
                                    }
                                } else {
                                    return 0.325516465784;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[82] <= 3.0) {
                                if (fs[0] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.00368613842559;
                                    } else {
                                        return 0.0962859279575;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0766505121617;
                                    } else {
                                        return 0.00899414326413;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0909113845037;
                                    } else {
                                        return 0.155876244417;
                                    }
                                } else {
                                    return -0.0728865972812;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[73] <= 250.0) {
                                    if (fs[73] <= 100.0) {
                                        return 0.034115765351;
                                    } else {
                                        return 0.311186571956;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0689435297527;
                                    } else {
                                        return 0.0370541181688;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[61] <= -995.0) {
                                        return 0.0529486258515;
                                    } else {
                                        return 0.142398956394;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.114597752123;
                                    } else {
                                        return 0.332123949194;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 250.0) {
                            if (fs[50] <= -956.5) {
                                return -0.037503911594;
                            } else {
                                return -0.0198111922428;
                            }
                        } else {
                            if (fs[50] <= -476.5) {
                                if (fs[11] <= 0.5) {
                                    return -0.0209749654811;
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.0106793039687;
                                    } else {
                                        return -0.00361846874523;
                                    }
                                }
                            } else {
                                if (fs[0] <= 15.5) {
                                    return -0.00239768746971;
                                } else {
                                    return -0.00968105369537;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[63] <= 5.0) {
                if (fs[42] <= 0.5) {
                    if (fs[4] <= 5.5) {
                        if (fs[55] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0186164168231;
                                    } else {
                                        return -0.0483356368688;
                                    }
                                } else {
                                    if (fs[50] <= -1293.0) {
                                        return -0.202640697923;
                                    } else {
                                        return 0.118871300975;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0632534276528;
                                    } else {
                                        return 0.226361842367;
                                    }
                                } else {
                                    if (fs[0] <= 19.5) {
                                        return 0.0264853554627;
                                    } else {
                                        return 0.291887876858;
                                    }
                                }
                            }
                        } else {
                            return -0.186293192277;
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[82] <= -0.5) {
                                if (fs[50] <= -1133.0) {
                                    return -0.348915290021;
                                } else {
                                    if (fs[50] <= 7.5) {
                                        return -0.0145776998162;
                                    } else {
                                        return -0.0303698428531;
                                    }
                                }
                            } else {
                                if (fs[4] <= 35.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0120560178268;
                                    } else {
                                        return 0.120201568775;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0653824992558;
                                    } else {
                                        return -0.165036086152;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0703948111347;
                                    } else {
                                        return -0.00719264546672;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return 0.242442527104;
                                    } else {
                                        return 0.0155880327382;
                                    }
                                }
                            } else {
                                return 0.430819828106;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.0) {
                        return 0.0691749768449;
                    } else {
                        if (fs[69] <= 9998.5) {
                            if (fs[50] <= -1468.0) {
                                if (fs[4] <= 13.5) {
                                    return -0.331143485011;
                                } else {
                                    return -0.199237415001;
                                }
                            } else {
                                return -0.0357419698919;
                            }
                        } else {
                            return 0.0363648088978;
                        }
                    }
                }
            } else {
                if (fs[4] <= 7.5) {
                    return -0.131204271305;
                } else {
                    return -0.237596455453;
                }
            }
        }
    }
}
