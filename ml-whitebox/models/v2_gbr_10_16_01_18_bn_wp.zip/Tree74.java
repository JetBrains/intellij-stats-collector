/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree74 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[2] <= 1.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[69] <= 9996.0) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0277266153742;
                                    } else {
                                        return -0.0175750716621;
                                    }
                                } else {
                                    return 0.124616118718;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    return -0.122837982824;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0455250758396;
                                    } else {
                                        return -0.0848382127968;
                                    }
                                }
                            }
                        } else {
                            return 0.229052991381;
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            if (fs[50] <= -1053.0) {
                                if (fs[4] <= 5.5) {
                                    return -0.0208725915322;
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0697184808968;
                                    } else {
                                        return 0.262301335402;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0681092441461;
                                    } else {
                                        return -0.0200287199158;
                                    }
                                } else {
                                    return 0.110715815761;
                                }
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.136029137999;
                                    } else {
                                        return 0.206046744898;
                                    }
                                } else {
                                    return 0.0788303979673;
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[40] <= 0.5) {
                                        return -0.021593126075;
                                    } else {
                                        return -0.0828475068237;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.00882318926567;
                                    } else {
                                        return 0.102916845809;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[30] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0444624008806;
                                    } else {
                                        return 0.0240928479055;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0106314690542;
                                    } else {
                                        return -0.0496800439322;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0245857464278;
                                    } else {
                                        return -0.0228050974014;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0378991904178;
                                    } else {
                                        return -0.0650090318056;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    return 0.0325675265093;
                                } else {
                                    return -0.0213898222629;
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.158375222626;
                                    } else {
                                        return 0.578333473016;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0279093171173;
                                    } else {
                                        return -0.0693333256244;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            return 0.000764558130938;
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 3.5) {
                                    return -0.0345733435575;
                                } else {
                                    return -0.0815078841647;
                                }
                            } else {
                                if (fs[0] <= 11.0) {
                                    if (fs[50] <= -1058.0) {
                                        return -0.0140100274345;
                                    } else {
                                        return -0.00635521587096;
                                    }
                                } else {
                                    return 0.00250039084935;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 19.5) {
                        if (fs[33] <= 0.5) {
                            return -0.0749488821007;
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.21892032426;
                                    } else {
                                        return 0.118576479928;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0451088983337;
                                    } else {
                                        return 0.114138042081;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    return 0.101653571265;
                                } else {
                                    return 0.0298036940565;
                                }
                            }
                        }
                    } else {
                        return -0.0455937120791;
                    }
                } else {
                    if (fs[4] <= 12.5) {
                        if (fs[50] <= -1128.0) {
                            if (fs[0] <= 7.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0428505443189;
                                    } else {
                                        return -0.0442082374868;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return -0.0268289748544;
                                    } else {
                                        return 0.0621212453957;
                                    }
                                }
                            } else {
                                return 0.0395167601714;
                            }
                        } else {
                            if (fs[50] <= -1058.0) {
                                return 0.119794527686;
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return -0.0145568242815;
                                    } else {
                                        return 0.0075153575649;
                                    }
                                } else {
                                    return 0.0323126336483;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1138.0) {
                            if (fs[4] <= 16.5) {
                                return 0.089016598253;
                            } else {
                                if (fs[4] <= 31.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.00743940355473;
                                    } else {
                                        return -0.00923596955157;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.00666423224908;
                                    } else {
                                        return 0.00975920988918;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 4847.0) {
                                if (fs[73] <= 100.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0110954589095;
                                    } else {
                                        return -0.0183921059272;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0166938416915;
                                    } else {
                                        return -0.00374966404266;
                                    }
                                }
                            } else {
                                return 0.0308480729537;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[69] <= 9985.5) {
                if (fs[95] <= 1.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[82] <= 6.5) {
                            if (fs[27] <= 0.5) {
                                if (fs[82] <= 5.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.00170534204393;
                                    } else {
                                        return 0.0221717191504;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.0551178806541;
                                    } else {
                                        return -0.00470677132542;
                                    }
                                }
                            } else {
                                return 0.376133023959;
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0254528209245;
                                    } else {
                                        return 0.000656987074778;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0634866660455;
                                    } else {
                                        return 0.0160347303067;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9825.5) {
                                    if (fs[54] <= 0.5) {
                                        return -0.00436875940019;
                                    } else {
                                        return 0.087442677304;
                                    }
                                } else {
                                    if (fs[50] <= -1428.0) {
                                        return 0.0752872131585;
                                    } else {
                                        return -0.000921546446451;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 15.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[69] <= 9866.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.152037452085;
                                    } else {
                                        return 0.00676466773059;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0738665877959;
                                    } else {
                                        return 0.142788490228;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.131090483016;
                                    } else {
                                        return 0.201659997429;
                                    }
                                } else {
                                    return 0.0258415793633;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return -0.286636575252;
                            } else {
                                if (fs[67] <= -4.0) {
                                    if (fs[0] <= 2.5) {
                                        return 0.106683744938;
                                    } else {
                                        return -0.0029596783026;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0208951481779;
                                    } else {
                                        return -0.0211078202139;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[54] <= 0.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[50] <= -1083.0) {
                                if (fs[2] <= 1.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00450976531663;
                                    } else {
                                        return 0.0221892687655;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0725721772699;
                                    } else {
                                        return 0.0293857743477;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0122675179301;
                                    } else {
                                        return -0.0034398660883;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.121026355426;
                                    } else {
                                        return -0.0147744106447;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.0177691814225;
                                    } else {
                                        return -0.233841868009;
                                    }
                                } else {
                                    if (fs[50] <= -4913.0) {
                                        return 0.236135784533;
                                    } else {
                                        return -0.000867652159556;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0438748132422;
                                    } else {
                                        return 0.183742057648;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.0505027243313;
                                    } else {
                                        return 0.0362848928721;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[59] <= -0.5) {
                                if (fs[61] <= -998.5) {
                                    return -0.0561345033579;
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.0696192381585;
                                    } else {
                                        return 0.140416231955;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[50] <= -1128.0) {
                                        return 0.299526103934;
                                    } else {
                                        return 0.159427998516;
                                    }
                                } else {
                                    return 0.069167974063;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 6.5) {
                                    return -0.0256854670611;
                                } else {
                                    return -0.0323540983567;
                                }
                            } else {
                                if (fs[50] <= -457.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0217866707237;
                                    } else {
                                        return -0.00613392395707;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.00535257307093;
                                    } else {
                                        return -0.00214172681266;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 4.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[68] <= 0.5) {
                            if (fs[95] <= 1.5) {
                                if (fs[82] <= 5.0) {
                                    if (fs[82] <= 1.5) {
                                        return 0.0520306913566;
                                    } else {
                                        return -0.102851823665;
                                    }
                                } else {
                                    if (fs[69] <= 9994.5) {
                                        return 0.289893310542;
                                    } else {
                                        return 0.126844309429;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.268247198348;
                                    } else {
                                        return 0.0265384704434;
                                    }
                                } else {
                                    return -0.0119280643045;
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[0] <= 39.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.0138559210277;
                                    } else {
                                        return -0.0215394967114;
                                    }
                                } else {
                                    if (fs[69] <= 9991.5) {
                                        return 0.0313180637668;
                                    } else {
                                        return -0.0707233720829;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return 0.138732787294;
                                } else {
                                    return -0.0589052429781;
                                }
                            }
                        }
                    } else {
                        if (fs[98] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[50] <= -481.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0214014477869;
                                    } else {
                                        return -0.0361662407107;
                                    }
                                } else {
                                    if (fs[69] <= 9995.5) {
                                        return 0.133029451827;
                                    } else {
                                        return 0.05536913321;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0513019981147;
                                    } else {
                                        return -0.128879762642;
                                    }
                                } else {
                                    return 0.0398584922776;
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.00796821757833;
                                    } else {
                                        return 0.0709793720561;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0397618075639;
                                    } else {
                                        return 0.287054441064;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9994.5) {
                                    return 0.0832430750309;
                                } else {
                                    return 0.0184046131176;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 0.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[50] <= -1403.5) {
                                if (fs[50] <= -1478.0) {
                                    if (fs[37] <= 0.5) {
                                        return 0.00450552667498;
                                    } else {
                                        return 0.101604945076;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return -0.141290214386;
                                    } else {
                                        return 0.115739981156;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return -0.00311033841161;
                                    } else {
                                        return 0.0694478036679;
                                    }
                                } else {
                                    if (fs[69] <= 9994.5) {
                                        return -0.0206684208372;
                                    } else {
                                        return -0.0738149678696;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.0232155382494;
                                    } else {
                                        return 0.0782991782584;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.18383514005;
                                    } else {
                                        return -0.0479716717193;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.0160028333631;
                                    } else {
                                        return -0.034339857105;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.11599642348;
                                    } else {
                                        return -0.311566454551;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 34.0) {
                            if (fs[44] <= 0.5) {
                                if (fs[69] <= 9987.5) {
                                    return -0.0829835334928;
                                } else {
                                    if (fs[69] <= 9992.5) {
                                        return 0.255401745159;
                                    } else {
                                        return 0.119921293167;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    return -0.0167143783523;
                                } else {
                                    return -0.0378098086561;
                                }
                            }
                        } else {
                            return -0.202344095523;
                        }
                    }
                }
            }
        }
    }
}
