/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree60 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9985.5) {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 19.5) {
                    if (fs[40] <= 0.5) {
                        if (fs[50] <= -1498.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[67] <= -1.5) {
                                    if (fs[69] <= 9781.5) {
                                        return 0.116254297022;
                                    } else {
                                        return 0.218693804174;
                                    }
                                } else {
                                    return -0.305219563982;
                                }
                            } else {
                                if (fs[69] <= 4352.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.0124713752097;
                                    } else {
                                        return 0.192319385441;
                                    }
                                } else {
                                    if (fs[50] <= -1978.0) {
                                        return 0.156424919169;
                                    } else {
                                        return 0.29962263812;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0586030968345;
                                    } else {
                                        return 0.0332230077022;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.045838717975;
                                    } else {
                                        return 0.0259534215007;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0712675969113;
                                    } else {
                                        return 0.0831717317199;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.123806373814;
                                    } else {
                                        return -0.0141339793196;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 75.0) {
                            if (fs[75] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0155283432178;
                                    } else {
                                        return 0.306257864901;
                                    }
                                } else {
                                    return -0.211679205825;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0625950116108;
                                    } else {
                                        return -0.187214293724;
                                    }
                                } else {
                                    if (fs[69] <= 9920.5) {
                                        return -0.0435805285747;
                                    } else {
                                        return 0.109006405665;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[50] <= -1488.0) {
                                        return -0.0306183045035;
                                    } else {
                                        return 0.18637632012;
                                    }
                                } else {
                                    if (fs[69] <= 9949.0) {
                                        return -0.017440078546;
                                    } else {
                                        return -0.208691031336;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0750071249837;
                                    } else {
                                        return -0.172041788047;
                                    }
                                } else {
                                    return 0.145542329479;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 8.5) {
                        if (fs[50] <= -1988.0) {
                            if (fs[2] <= 5.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[50] <= -2038.0) {
                                        return 0.052426763405;
                                    } else {
                                        return 0.234257992043;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.229541178726;
                                    } else {
                                        return 0.129768619518;
                                    }
                                }
                            } else {
                                return -0.101306601134;
                            }
                        } else {
                            if (fs[4] <= 27.5) {
                                if (fs[69] <= 9975.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.116150801059;
                                    } else {
                                        return -0.0251550171142;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.409443544097;
                                    } else {
                                        return 0.195245143357;
                                    }
                                }
                            } else {
                                if (fs[4] <= 28.5) {
                                    if (fs[96] <= 0.5) {
                                        return -0.221333495299;
                                    } else {
                                        return 0.0888584524152;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0882231958126;
                                    } else {
                                        return 0.0550199034877;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 27.5) {
                            if (fs[4] <= 25.5) {
                                if (fs[73] <= 250.0) {
                                    if (fs[95] <= 1.5) {
                                        return 0.199816613968;
                                    } else {
                                        return -0.0584941774893;
                                    }
                                } else {
                                    return -0.0948267231231;
                                }
                            } else {
                                if (fs[2] <= 11.5) {
                                    return 0.333993831784;
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return 0.127364015208;
                                    } else {
                                        return 0.206867997555;
                                    }
                                }
                            }
                        } else {
                            if (fs[86] <= 0.5) {
                                return 0.209303719571;
                            } else {
                                if (fs[78] <= 0.5) {
                                    return -0.278492470562;
                                } else {
                                    return 0.144690857436;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[84] <= 0.5) {
                    if (fs[15] <= 0.5) {
                        if (fs[67] <= -1.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[75] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.147382696834;
                                    } else {
                                        return 0.000598784190883;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.00345806572269;
                                    } else {
                                        return -0.00186883321075;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.00296865888762;
                                    } else {
                                        return 0.00662302026266;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.0282787861325;
                                    } else {
                                        return 0.000104851281242;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                return 0.113221548999;
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.00476479767864;
                                    } else {
                                        return -0.0111539106449;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0516022192803;
                                    } else {
                                        return -0.0164276603513;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.0267055770465;
                    }
                } else {
                    if (fs[50] <= -1418.0) {
                        if (fs[4] <= 11.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.0880765932249;
                                    } else {
                                        return 0.00696719168575;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.103661128153;
                                    } else {
                                        return -0.0459717520751;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1468.0) {
                                    if (fs[69] <= 9957.0) {
                                        return 0.112617928171;
                                    } else {
                                        return -0.0348244547158;
                                    }
                                } else {
                                    return 0.334079971399;
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[4] <= 37.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0127575317809;
                                    } else {
                                        return 0.0552028443479;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.0627658824131;
                                    } else {
                                        return 0.334437489136;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[0] <= 62.5) {
                                        return -0.00509413061666;
                                    } else {
                                        return 0.399725048649;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.201476775633;
                                    } else {
                                        return 0.0384618752542;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[73] <= 250.0) {
                                    if (fs[73] <= 150.0) {
                                        return 0.000705169922289;
                                    } else {
                                        return 0.0400761301218;
                                    }
                                } else {
                                    if (fs[61] <= -998.5) {
                                        return 0.124240906347;
                                    } else {
                                        return -0.00463583424395;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1032.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.11035258526;
                                    } else {
                                        return -0.0143400195525;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0131771077318;
                                    } else {
                                        return -0.00338258236347;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.0131483404576;
                                    } else {
                                        return -0.00997460903262;
                                    }
                                } else {
                                    if (fs[0] <= 60.5) {
                                        return 0.0358201693937;
                                    } else {
                                        return 0.472857085063;
                                    }
                                }
                            } else {
                                if (fs[2] <= 10.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0195586815677;
                                    } else {
                                        return -0.00402522916617;
                                    }
                                } else {
                                    return -0.0480731465983;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 4.5) {
                    if (fs[4] <= 3.5) {
                        if (fs[82] <= 7.5) {
                            if (fs[67] <= -4.5) {
                                if (fs[12] <= 0.5) {
                                    return 0.0588048517115;
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.119564660986;
                                    } else {
                                        return 0.179734908293;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9995.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0476799739252;
                                    } else {
                                        return 0.140463456124;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0351020721942;
                                    } else {
                                        return 0.0558273592141;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.22086298174;
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.132598526935;
                                    } else {
                                        return 0.10772616488;
                                    }
                                } else {
                                    return 0.0625401100258;
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[29] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[50] <= -557.0) {
                                        return 0.0925886487279;
                                    } else {
                                        return 0.161835585896;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0379407512384;
                                    } else {
                                        return 0.135175890088;
                                    }
                                }
                            } else {
                                return -0.270146170314;
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.0451941837419;
                                    } else {
                                        return 0.116237493997;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return 0.265574315602;
                                    } else {
                                        return 0.0976246506322;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0482787598006;
                                    } else {
                                        return 0.0933407036078;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0418687084885;
                                    } else {
                                        return -0.123773625248;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[33] <= 0.5) {
                        if (fs[4] <= 35.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[18] <= -0.5) {
                                    if (fs[95] <= 1.5) {
                                        return -0.243713524222;
                                    } else {
                                        return -0.308177896923;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.0415089794489;
                                    } else {
                                        return -0.0459078482825;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    if (fs[98] <= 0.5) {
                                        return -0.248106015318;
                                    } else {
                                        return 0.0603962168243;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.0778601549663;
                                    } else {
                                        return -0.0707004329084;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1733.0) {
                                return 0.159270791011;
                            } else {
                                if (fs[49] <= 0.5) {
                                    return -0.517307293025;
                                } else {
                                    return -0.287312880169;
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 1.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.078150924392;
                                    } else {
                                        return 0.0254608410672;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.0775680187405;
                                    } else {
                                        return -0.00599240583886;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.103228515804;
                                    } else {
                                        return 0.0363706403917;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.130468442872;
                                    } else {
                                        return 0.0729462011747;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0499643347162;
                                    } else {
                                        return -0.0484405304251;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.307656683344;
                                    } else {
                                        return 0.155725203797;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[69] <= 9995.5) {
                                        return 0.117429450063;
                                    } else {
                                        return 0.200229305101;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.177148172745;
                                    } else {
                                        return -0.0624479045568;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1418.0) {
                    if (fs[18] <= -0.5) {
                        if (fs[4] <= 8.5) {
                            return -0.257252945534;
                        } else {
                            if (fs[69] <= 9996.0) {
                                return -0.117651991871;
                            } else {
                                return -0.242708127983;
                            }
                        }
                    } else {
                        if (fs[63] <= 5.0) {
                            if (fs[4] <= 32.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0500273893901;
                                    } else {
                                        return -0.068437681676;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.233908802511;
                                    } else {
                                        return 0.428457249664;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1478.0) {
                                    if (fs[68] <= 0.5) {
                                        return -0.134756791988;
                                    } else {
                                        return -0.0510591414887;
                                    }
                                } else {
                                    return 0.0606202965011;
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                return -0.22670940899;
                            } else {
                                return -0.166629921754;
                            }
                        }
                    }
                } else {
                    if (fs[46] <= -0.5) {
                        if (fs[50] <= -1047.0) {
                            return 0.430635816232;
                        } else {
                            if (fs[95] <= 0.5) {
                                return 0.278632082364;
                            } else {
                                if (fs[4] <= 10.5) {
                                    return -0.0795985580273;
                                } else {
                                    return 0.103369238749;
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[82] <= 1.5) {
                                        return -0.0169267922923;
                                    } else {
                                        return 0.0220693895368;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0916975988768;
                                    } else {
                                        return 0.0116556949387;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.00175375943316;
                                    } else {
                                        return 0.079314201151;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0229031586875;
                                    } else {
                                        return -0.0043291407958;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0400798343325;
                                    } else {
                                        return -0.00433499882694;
                                    }
                                } else {
                                    if (fs[50] <= -1108.0) {
                                        return 0.010615964123;
                                    } else {
                                        return -0.0100405424609;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.189294452806;
                                    } else {
                                        return 0.406634405553;
                                    }
                                } else {
                                    return -0.14400651591;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
