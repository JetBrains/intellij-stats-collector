/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree10 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[50] <= -1043.0) {
                if (fs[50] <= -1228.5) {
                    if (fs[73] <= 25.0) {
                        if (fs[33] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[82] <= 6.0) {
                                    if (fs[84] <= 0.5) {
                                        return -0.029448769847;
                                    } else {
                                        return 0.31736886371;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.5972513814;
                                    } else {
                                        return 0.217199051602;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[13] <= 0.5) {
                                        return 0.150475775059;
                                    } else {
                                        return 0.58888688133;
                                    }
                                } else {
                                    if (fs[69] <= 9339.0) {
                                        return 0.580312563121;
                                    } else {
                                        return 0.319530150373;
                                    }
                                }
                            }
                        } else {
                            if (fs[67] <= -1.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.517308920397;
                                    } else {
                                        return 0.382002840174;
                                    }
                                } else {
                                    return 0.25376100751;
                                }
                            } else {
                                if (fs[50] <= -1783.0) {
                                    return 0.194498794083;
                                } else {
                                    if (fs[50] <= -1568.0) {
                                        return -0.187547824465;
                                    } else {
                                        return -0.0920901933034;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[91] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.463782050096;
                                    } else {
                                        return 0.300885616573;
                                    }
                                } else {
                                    if (fs[50] <= -1493.5) {
                                        return 0.567715754853;
                                    } else {
                                        return 0.39315547353;
                                    }
                                }
                            } else {
                                if (fs[42] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.510883703619;
                                    } else {
                                        return 0.341299290981;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.0556944388462;
                                    } else {
                                        return 0.3533783476;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 42.0) {
                                    if (fs[64] <= 0.5) {
                                        return 0.497393416584;
                                    } else {
                                        return 0.252891577112;
                                    }
                                } else {
                                    return -0.133637466619;
                                }
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.311195525622;
                                    } else {
                                        return 0.0739270212933;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.420069427845;
                                    } else {
                                        return -0.0598712020753;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 10.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.514711152265;
                                    } else {
                                        return 0.41594727505;
                                    }
                                } else {
                                    if (fs[50] <= -1138.5) {
                                        return 0.358203412093;
                                    } else {
                                        return 0.535166501928;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.551171461073;
                                    } else {
                                        return 0.506537957417;
                                    }
                                } else {
                                    if (fs[69] <= 4619.5) {
                                        return 0.224843103736;
                                    } else {
                                        return 0.559443660651;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[50] <= -1138.0) {
                                    return 0.553378109716;
                                } else {
                                    return 0.557354630587;
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[73] <= 350.0) {
                                        return 0.131113549302;
                                    } else {
                                        return 0.600057506991;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.205915866953;
                                    } else {
                                        return 0.300820546305;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.518024871762;
                                    } else {
                                        return 0.380561210086;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return 0.438535577699;
                                    } else {
                                        return 0.124722580116;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.335963041475;
                                    } else {
                                        return 0.100470300742;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.256202223761;
                                    } else {
                                        return 0.450878876059;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -995.5) {
                                if (fs[57] <= 0.5) {
                                    return 0.664751474606;
                                } else {
                                    if (fs[46] <= -1.5) {
                                        return 0.629761881626;
                                    } else {
                                        return 0.418541897384;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.133845529468;
                                    } else {
                                        return 0.245836995621;
                                    }
                                } else {
                                    if (fs[82] <= 2.5) {
                                        return 0.4218392721;
                                    } else {
                                        return 0.703255437056;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 10.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[59] <= -0.5) {
                            if (fs[95] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    return 0.192309632173;
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.167993650682;
                                    } else {
                                        return 0.542091087493;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    return 0.63264376697;
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.37307866326;
                                    } else {
                                        return 0.535321830596;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.146702509852;
                                    } else {
                                        return 0.429276545263;
                                    }
                                } else {
                                    if (fs[69] <= 5000.0) {
                                        return 0.426158703896;
                                    } else {
                                        return 0.717052893211;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.524369963476;
                                    } else {
                                        return 0.238297657075;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.184100362092;
                                    } else {
                                        return 0.310749137325;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -461.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[79] <= 0.5) {
                                    return 0.405972674903;
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.172325446003;
                                    } else {
                                        return -0.0606741496417;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9746.0) {
                                    if (fs[4] <= 7.5) {
                                        return 0.450757426356;
                                    } else {
                                        return -0.0463089341393;
                                    }
                                } else {
                                    return 0.643455507402;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[67] <= -4.5) {
                                        return 0.477858195655;
                                    } else {
                                        return 0.551823063189;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.552689993677;
                                    } else {
                                        return 0.0828166510042;
                                    }
                                }
                            } else {
                                if (fs[82] <= -0.5) {
                                    if (fs[69] <= 4999.5) {
                                        return -0.0563675218081;
                                    } else {
                                        return 0.572224738735;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.472093060742;
                                    } else {
                                        return 0.363180564695;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[46] <= -0.5) {
                        if (fs[59] <= -1.5) {
                            if (fs[59] <= -2.5) {
                                if (fs[18] <= 0.5) {
                                    return 0.537816796422;
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.676398700472;
                                    } else {
                                        return 0.628099320456;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    return 0.365399833045;
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.468326348335;
                                    } else {
                                        return 0.623693687786;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                return 0.674377366773;
                            } else {
                                if (fs[4] <= 22.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.402230647526;
                                    } else {
                                        return 0.508637044313;
                                    }
                                } else {
                                    return -0.279013262793;
                                }
                            }
                        }
                    } else {
                        if (fs[67] <= -3.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.310143976455;
                                    } else {
                                        return 0.150864098165;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.400361480893;
                                    } else {
                                        return 0.545655418407;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0843333913913;
                                    } else {
                                        return 0.340462817547;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.644127781807;
                                    } else {
                                        return 0.449118386384;
                                    }
                                }
                            }
                        } else {
                            if (fs[98] <= 0.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.182353273179;
                                    } else {
                                        return 0.320810306233;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0256880736922;
                                    } else {
                                        return 0.154931366289;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.403720838224;
                                    } else {
                                        return 0.659417264113;
                                    }
                                } else {
                                    if (fs[69] <= 4944.0) {
                                        return -0.0901548720982;
                                    } else {
                                        return 0.59463249069;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[95] <= 0.5) {
                if (fs[69] <= 9866.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[82] <= 7.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.0270540614925;
                                    } else {
                                        return 0.140405873041;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0423913222964;
                                    } else {
                                        return 0.342165046677;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[82] <= 1.5) {
                                        return -0.0427524269774;
                                    } else {
                                        return 0.0257191052253;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.0350191657348;
                                    } else {
                                        return 0.11836434753;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[40] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0192585462874;
                                    } else {
                                        return 0.254107360852;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.277535318427;
                                    } else {
                                        return 0.0702449209798;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0446516123209;
                                    } else {
                                        return 0.371117111253;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.123663507875;
                                    } else {
                                        return 0.554277671849;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0341332489253;
                                    } else {
                                        return -0.00331026859675;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0100555521043;
                                    } else {
                                        return -0.0232159519526;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0238908363256;
                                    } else {
                                        return -0.0342547618187;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0356762147702;
                                    } else {
                                        return -0.0323460542411;
                                    }
                                }
                            }
                        } else {
                            if (fs[75] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    return 0.449000407296;
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0483297458971;
                                    } else {
                                        return -0.0176758039758;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[54] <= 0.5) {
                                        return -0.0233973194822;
                                    } else {
                                        return 0.183673444086;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0243636504176;
                                    } else {
                                        return -0.0320397172549;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.165173813814;
                                    } else {
                                        return 0.0448704530687;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0402746952126;
                                    } else {
                                        return -0.0257558909168;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.163053859427;
                                    } else {
                                        return -0.121948534871;
                                    }
                                } else {
                                    if (fs[50] <= -496.5) {
                                        return 0.237503092757;
                                    } else {
                                        return 0.0466026660801;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[71] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return 0.10360989068;
                                    } else {
                                        return 0.319907019473;
                                    }
                                } else {
                                    return 0.28330635219;
                                }
                            } else {
                                if (fs[50] <= -1082.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.401593479772;
                                    } else {
                                        return 0.0726487829859;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.353607467796;
                                    } else {
                                        return -0.052531507105;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1128.0) {
                            if (fs[2] <= 1.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[0] <= 8.5) {
                                        return 0.0345350239266;
                                    } else {
                                        return -0.0121055838511;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.103683090965;
                                    } else {
                                        return 0.37427059615;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[69] <= 9987.5) {
                                        return 0.0425345451033;
                                    } else {
                                        return 0.374769952629;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return 0.0507279524215;
                                    } else {
                                        return 0.191134281397;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.0413136109272;
                                    } else {
                                        return 0.0486640725456;
                                    }
                                } else {
                                    if (fs[69] <= 9985.5) {
                                        return -0.0246332437083;
                                    } else {
                                        return 0.00233791012249;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.288084090697;
                                    } else {
                                        return 0.0651582888431;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0220860323867;
                                    } else {
                                        return -0.0217165967605;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[11] <= 0.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[50] <= -1398.0) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0972058035834;
                                    } else {
                                        return 0.205927739953;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.587929970597;
                                    } else {
                                        return 0.273663797906;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[97] <= 1.5) {
                                        return 0.0904528321861;
                                    } else {
                                        return 0.17250881285;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0402612028668;
                                    } else {
                                        return 0.105461167866;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    return 0.0904785889787;
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return -0.0215215954495;
                                    } else {
                                        return 0.0905420948322;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1026.5) {
                                    return 0.00446661915232;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0312062116467;
                                    } else {
                                        return -0.0440874681128;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[0] <= 4.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return 0.0552931274774;
                                    } else {
                                        return 0.236054198568;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.0392151220686;
                                    } else {
                                        return 0.0140785818537;
                                    }
                                }
                            } else {
                                if (fs[61] <= -997.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.134062093416;
                                    } else {
                                        return 0.475632048523;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return -0.0141340609389;
                                    } else {
                                        return 0.184215191421;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= -2.5) {
                                if (fs[4] <= 17.5) {
                                    return 0.100885802404;
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.039805463289;
                                    } else {
                                        return -0.0444948696537;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.037662145046;
                                    } else {
                                        return -0.0323183355769;
                                    }
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return -0.0381865110901;
                                    } else {
                                        return -0.0357910610495;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[4] <= 16.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0418281715433;
                                    } else {
                                        return 0.222631958893;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.139908947257;
                                    } else {
                                        return 0.0615620375543;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[69] <= 9998.5) {
                                        return -0.0179856615701;
                                    } else {
                                        return 0.175733167546;
                                    }
                                } else {
                                    if (fs[52] <= 496.5) {
                                        return 0.0398732374712;
                                    } else {
                                        return 0.607205239827;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[46] <= -1.5) {
                                    return 0.0638080679316;
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.0334393703947;
                                    } else {
                                        return -0.0448573100267;
                                    }
                                }
                            } else {
                                if (fs[2] <= 8.5) {
                                    if (fs[69] <= 4346.0) {
                                        return -0.0492293758171;
                                    } else {
                                        return 0.0412446175182;
                                    }
                                } else {
                                    return 0.200651563595;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= 3.5) {
                            if (fs[69] <= 9978.5) {
                                if (fs[0] <= 5.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.00212664242976;
                                    } else {
                                        return -0.0323435937767;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return -0.0245982179876;
                                    } else {
                                        return -0.0315145711869;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1418.0) {
                                    if (fs[4] <= 5.5) {
                                        return 0.388327749397;
                                    } else {
                                        return 0.0931016927597;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.0214200363842;
                                    } else {
                                        return -0.0123425436814;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.0358510914956;
                                    } else {
                                        return -0.0351812583668;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.0156725371354;
                                    } else {
                                        return -0.0359446099397;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[0] <= 6.5) {
                                        return 0.0362787563001;
                                    } else {
                                        return -0.0381724940216;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.026965929539;
                                    } else {
                                        return -0.0358048252765;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
