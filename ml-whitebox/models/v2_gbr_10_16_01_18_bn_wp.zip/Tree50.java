/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree50 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[2] <= 1.5) {
                    if (fs[61] <= -996.5) {
                        if (fs[68] <= 0.5) {
                            if (fs[95] <= 0.5) {
                                return -0.107791018698;
                            } else {
                                return 0.0912222740482;
                            }
                        } else {
                            if (fs[50] <= -1448.0) {
                                if (fs[50] <= -1559.0) {
                                    if (fs[84] <= 0.5) {
                                        return 0.22804684548;
                                    } else {
                                        return -0.0257690388962;
                                    }
                                } else {
                                    return -0.143985160967;
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[69] <= 4997.5) {
                                        return 0.0887696821243;
                                    } else {
                                        return 0.178376176465;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.154109823689;
                                    } else {
                                        return 0.0820053121621;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[50] <= -988.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.0154090487928;
                                    } else {
                                        return 0.0759603218717;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.115146552413;
                                    } else {
                                        return 0.201837189572;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0206308296484;
                                    } else {
                                        return 0.103193068861;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.121050749576;
                                    } else {
                                        return -0.312613433275;
                                    }
                                }
                            }
                        } else {
                            if (fs[43] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.00817656712257;
                                    } else {
                                        return 0.0391307078222;
                                    }
                                } else {
                                    return 0.19409852777;
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0760246866713;
                                    } else {
                                        return -0.30527309552;
                                    }
                                } else {
                                    if (fs[69] <= 9922.0) {
                                        return 0.0698242281497;
                                    } else {
                                        return 0.286702150884;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[68] <= 0.5) {
                        if (fs[18] <= -0.5) {
                            return -0.183684097964;
                        } else {
                            if (fs[2] <= 8.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0691970815107;
                                    } else {
                                        return 0.109387255578;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.116302639331;
                                    } else {
                                        return 0.341113670254;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1468.0) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0273615651089;
                                    } else {
                                        return 0.228509744385;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.284116625108;
                                    } else {
                                        return 0.0921001755956;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= -0.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[50] <= -968.5) {
                                        return -0.0366978676212;
                                    } else {
                                        return 0.106234937056;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.171194142092;
                                    } else {
                                        return 0.124262769736;
                                    }
                                }
                            } else {
                                return 0.0716942488607;
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[50] <= -1143.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.0750045436546;
                                    } else {
                                        return 0.0778101061003;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0843725214191;
                                    } else {
                                        return -0.117448546791;
                                    }
                                }
                            } else {
                                if (fs[46] <= -0.5) {
                                    if (fs[97] <= 1.5) {
                                        return 0.130951862831;
                                    } else {
                                        return 0.0824507013225;
                                    }
                                } else {
                                    if (fs[50] <= -987.0) {
                                        return 0.0615095527127;
                                    } else {
                                        return 0.00501431974245;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1988.0) {
                    if (fs[99] <= 0.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[4] <= 22.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.148425976169;
                                    } else {
                                        return -0.0204977676878;
                                    }
                                } else {
                                    return -0.203378138248;
                                }
                            } else {
                                if (fs[50] <= -2418.5) {
                                    if (fs[4] <= 24.5) {
                                        return 0.0446882946488;
                                    } else {
                                        return 0.238120242729;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return 0.236808779174;
                                    } else {
                                        return -0.00768369618626;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.365286751063;
                                    } else {
                                        return 0.291846993641;
                                    }
                                } else {
                                    if (fs[69] <= 4998.5) {
                                        return 0.271037788385;
                                    } else {
                                        return 0.219525455779;
                                    }
                                }
                            } else {
                                return 0.110810973236;
                            }
                        }
                    } else {
                        return -0.213641430899;
                    }
                } else {
                    if (fs[2] <= 10.5) {
                        if (fs[97] <= 0.5) {
                            if (fs[76] <= 0.5) {
                                if (fs[46] <= -1.5) {
                                    if (fs[46] <= -2.5) {
                                        return 0.279950537065;
                                    } else {
                                        return 0.199859451595;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.059377784738;
                                    } else {
                                        return -0.00638618148255;
                                    }
                                }
                            } else {
                                if (fs[4] <= 33.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.070718668244;
                                    } else {
                                        return 0.204395960714;
                                    }
                                } else {
                                    return -0.140972235308;
                                }
                            }
                        } else {
                            if (fs[77] <= 0.5) {
                                if (fs[4] <= 29.5) {
                                    if (fs[50] <= -1968.0) {
                                        return -0.184666899938;
                                    } else {
                                        return 0.0638249248774;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.00768206392932;
                                    } else {
                                        return -0.122854447258;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.0851312921353;
                                    } else {
                                        return 0.332313165122;
                                    }
                                } else {
                                    return -0.356084600949;
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 75.0) {
                            if (fs[4] <= 28.0) {
                                if (fs[2] <= 12.5) {
                                    if (fs[4] <= 20.5) {
                                        return 0.286907415515;
                                    } else {
                                        return 0.101302160662;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.374042520915;
                                    } else {
                                        return 0.221357989412;
                                    }
                                }
                            } else {
                                return 0.0134256137688;
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[4] <= 23.0) {
                                    return -0.282854203257;
                                } else {
                                    return 0.0837531517694;
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    return 0.279013702064;
                                } else {
                                    return 0.0231762628984;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[11] <= 0.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[73] <= 75.0) {
                                if (fs[12] <= 0.5) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0246873318347;
                                    } else {
                                        return 0.236481743224;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.00526415754271;
                                    } else {
                                        return 0.388608986878;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0373671547797;
                                    } else {
                                        return -0.148464904991;
                                    }
                                } else {
                                    if (fs[82] <= 4.5) {
                                        return 0.167503405867;
                                    } else {
                                        return 0.062171148607;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 36.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.178340002716;
                                    } else {
                                        return 0.0342173601781;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.26004453006;
                                    } else {
                                        return 0.367835571881;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.00730188573195;
                                    } else {
                                        return -0.147695731553;
                                    }
                                } else {
                                    return -0.208784608272;
                                }
                            }
                        }
                    } else {
                        if (fs[74] <= 0.5) {
                            if (fs[50] <= -1047.0) {
                                return -0.101996718776;
                            } else {
                                if (fs[82] <= 7.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.00551612811083;
                                    } else {
                                        return -0.015614021979;
                                    }
                                } else {
                                    return 0.0733701053922;
                                }
                            }
                        } else {
                            if (fs[52] <= -0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -971.5) {
                                        return -0.0102343198546;
                                    } else {
                                        return -0.0349328325384;
                                    }
                                } else {
                                    if (fs[52] <= -1.5) {
                                        return -0.0305710755639;
                                    } else {
                                        return -0.0361586954203;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9898.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0169278011933;
                                    } else {
                                        return -0.0321114166102;
                                    }
                                } else {
                                    if (fs[69] <= 9988.5) {
                                        return -0.0754243367911;
                                    } else {
                                        return -0.0672335216873;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[49] <= 0.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0460543160507;
                                    } else {
                                        return -0.090656623059;
                                    }
                                } else {
                                    if (fs[50] <= -471.5) {
                                        return 0.0230936616919;
                                    } else {
                                        return -0.0447671214385;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0209391491738;
                                    } else {
                                        return -0.00300673564008;
                                    }
                                } else {
                                    if (fs[50] <= -1928.0) {
                                        return 0.188014392189;
                                    } else {
                                        return -0.0627962053582;
                                    }
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.0148336286463;
                                    } else {
                                        return 0.0572590711621;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.428218486384;
                                    } else {
                                        return 0.17696411937;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    return -0.0680683126442;
                                } else {
                                    return 0.0179862924651;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 19.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[25] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.00885744789683;
                                    } else {
                                        return 0.0628440325487;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0122294051078;
                                    } else {
                                        return 0.0546213750673;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0251081246556;
                                    } else {
                                        return 0.0848301579879;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.0330968090782;
                                    } else {
                                        return -0.0259448090199;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[69] <= 9994.5) {
                                        return -0.016832929714;
                                    } else {
                                        return -0.122061274171;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.0574048160559;
                                    } else {
                                        return 0.328392781204;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.0594234896121;
                                    } else {
                                        return 0.31230225623;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0640664300896;
                                    } else {
                                        return 0.0721418486614;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[69] <= 9998.5) {
                    if (fs[0] <= 3.5) {
                        if (fs[67] <= -1.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[50] <= 3.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0011582847685;
                                    } else {
                                        return 0.00715610029969;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0151600625626;
                                    } else {
                                        return -0.00875166597336;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.00375279216273;
                                    } else {
                                        return -0.00865276399214;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return -0.000190571766664;
                                    } else {
                                        return 0.321807186289;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[86] <= 0.5) {
                                        return -0.0163043817433;
                                    } else {
                                        return 0.068862865352;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0217906602652;
                                    } else {
                                        return -0.012633557621;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[50] <= -1012.0) {
                                        return -0.0598717230095;
                                    } else {
                                        return -0.0174959946718;
                                    }
                                } else {
                                    return -0.00811833918481;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 11.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.00378341136981;
                                    } else {
                                        return -0.0113971981551;
                                    }
                                } else {
                                    if (fs[59] <= -2.5) {
                                        return 0.113641050827;
                                    } else {
                                        return -0.00451690138035;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[69] <= 9996.5) {
                                        return -0.00589669243102;
                                    } else {
                                        return -0.0416839068638;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return -0.00303204778624;
                                    } else {
                                        return 0.0393010248991;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 118.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[50] <= -47.5) {
                                        return -0.00486134832429;
                                    } else {
                                        return -0.00620146205584;
                                    }
                                } else {
                                    if (fs[0] <= 25.5) {
                                        return -0.00394775394193;
                                    } else {
                                        return -0.00496505963446;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[69] <= 9944.5) {
                                        return -0.00520448082912;
                                    } else {
                                        return 0.0120751794474;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.00108835039985;
                                    } else {
                                        return 0.122757117442;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[50] <= -2408.0) {
                                return 0.24049774235;
                            } else {
                                if (fs[0] <= 73.0) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0112253072398;
                                    } else {
                                        return -0.102688162801;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.277359908315;
                                    } else {
                                        return 0.0673243496013;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 17.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[50] <= -1128.0) {
                                        return -0.0942566718321;
                                    } else {
                                        return 0.170088454831;
                                    }
                                } else {
                                    if (fs[50] <= -1213.0) {
                                        return 0.200197582566;
                                    } else {
                                        return 0.095272207814;
                                    }
                                }
                            } else {
                                if (fs[0] <= 12.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.117291952245;
                                    } else {
                                        return -0.137348764449;
                                    }
                                } else {
                                    if (fs[0] <= 29.0) {
                                        return -0.100889397652;
                                    } else {
                                        return -0.204308735009;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 1.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[11] <= 0.5) {
                                    return -0.0765354243017;
                                } else {
                                    return -0.0492685691715;
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.0508057441065;
                                    } else {
                                        return -0.0115045888893;
                                    }
                                } else {
                                    if (fs[50] <= -976.0) {
                                        return 0.0131152966532;
                                    } else {
                                        return -0.0328444935338;
                                    }
                                }
                            }
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0184819665224;
                                    } else {
                                        return -0.0598237763855;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.176237211854;
                                    } else {
                                        return -0.0224132873561;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0643746562443;
                                    } else {
                                        return -0.00553330927045;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.00509097616009;
                                    } else {
                                        return -0.00882576444624;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
