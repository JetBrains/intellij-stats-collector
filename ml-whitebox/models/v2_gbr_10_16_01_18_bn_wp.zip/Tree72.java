/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree72 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[61] <= -996.5) {
                if (fs[0] <= 0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[55] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[61] <= -998.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0484080688282;
                                    } else {
                                        return 0.219269317075;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.150960390025;
                                    } else {
                                        return 0.0228432610189;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    return 0.266552973172;
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0352312940425;
                                    } else {
                                        return 0.0750905335278;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 1.5) {
                                return -0.214835008472;
                            } else {
                                if (fs[59] <= -1.5) {
                                    return -0.0203037391103;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0530365005663;
                                    } else {
                                        return -0.0786662377965;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[12] <= 0.5) {
                                return -0.158877066131;
                            } else {
                                if (fs[57] <= 0.5) {
                                    return -0.0997084990423;
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.122619061736;
                                    } else {
                                        return -0.024350916509;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.22849215178;
                                    } else {
                                        return 0.148565909924;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.111780067913;
                                    } else {
                                        return 0.0392754785669;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.256299882324;
                                } else {
                                    return 0.286199509293;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1098.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[4] <= 22.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[61] <= -998.5) {
                                        return -0.0596612190897;
                                    } else {
                                        return 0.00643091998064;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.0457197925846;
                                    } else {
                                        return 0.237260411859;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    return 0.00475737471915;
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.0627397055571;
                                    } else {
                                        return -0.0232300573461;
                                    }
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[46] <= -1.5) {
                                    return 0.660832089996;
                                } else {
                                    return 0.123674524233;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0288818551913;
                                    } else {
                                        return 0.0327610639982;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.0443163300561;
                                    } else {
                                        return 0.143830339982;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[46] <= -2.5) {
                            if (fs[57] <= 0.5) {
                                return -0.00634582820537;
                            } else {
                                return 0.143601156613;
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 29.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0306137984634;
                                    } else {
                                        return -0.0111748432118;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return -0.0156726495464;
                                    } else {
                                        return 0.122601972118;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.0785644815937;
                                    } else {
                                        return -0.00663931984404;
                                    }
                                } else {
                                    return -0.0605768911415;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[75] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[50] <= -1128.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.0147643840192;
                                    } else {
                                        return 0.0296226252681;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0330809905144;
                                    } else {
                                        return 0.0198707909603;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1038.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.0498837215269;
                                    } else {
                                        return 0.040132912253;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.0346168085517;
                                    } else {
                                        return -0.216625226034;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    return -0.125263713425;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.120077438394;
                                    } else {
                                        return 0.0551759884221;
                                    }
                                }
                            } else {
                                if (fs[73] <= 100.0) {
                                    if (fs[69] <= 4914.0) {
                                        return 0.0759985041047;
                                    } else {
                                        return 0.0123104272064;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0725045174513;
                                    } else {
                                        return 0.0221211059013;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[65] <= 1.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[50] <= -1068.0) {
                                    if (fs[40] <= 0.5) {
                                        return 0.159672651756;
                                    } else {
                                        return -0.107112873217;
                                    }
                                } else {
                                    return -0.126775289069;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.0101900859527;
                                    } else {
                                        return -0.0528473785412;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00362329351868;
                                    } else {
                                        return 0.0422999215002;
                                    }
                                }
                            }
                        } else {
                            if (fs[56] <= 0.5) {
                                return 0.183731923427;
                            } else {
                                return -0.0249358889873;
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[73] <= 25.0) {
                            if (fs[11] <= 0.5) {
                                if (fs[50] <= -1938.0) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0985820747307;
                                    } else {
                                        return 0.236412641796;
                                    }
                                } else {
                                    if (fs[50] <= -1238.5) {
                                        return -0.0263120898625;
                                    } else {
                                        return 0.0235462093086;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[69] <= 9838.5) {
                                        return -0.0384121174455;
                                    } else {
                                        return 0.0415155131241;
                                    }
                                } else {
                                    if (fs[69] <= 9339.0) {
                                        return 0.0481548125099;
                                    } else {
                                        return -0.0726429380799;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0202615388189;
                                    } else {
                                        return -0.0224342276435;
                                    }
                                } else {
                                    if (fs[69] <= 4405.0) {
                                        return 0.042204556183;
                                    } else {
                                        return -0.0523553655062;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.0283761742186;
                                    } else {
                                        return 0.0905944228427;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.0884323609064;
                                    } else {
                                        return 0.267825229513;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[67] <= -1.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[4] <= 25.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.000510174187802;
                                    } else {
                                        return 0.0114294153817;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0156153090431;
                                    } else {
                                        return -0.000495673512327;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[73] <= 250.0) {
                                        return -0.00134577245219;
                                    } else {
                                        return -0.00267069577435;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.00811735436793;
                                    } else {
                                        return -0.0335849107468;
                                    }
                                }
                            }
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.00490054415633;
                                    } else {
                                        return 0.00577516987316;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.0313196487033;
                                    } else {
                                        return -0.00932784555917;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0221436054113;
                                    } else {
                                        return -0.0402855570877;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.00576094271361;
                                    } else {
                                        return 0.0104446216915;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[50] <= -1052.5) {
                if (fs[82] <= -0.5) {
                    return -0.341213228117;
                } else {
                    if (fs[4] <= 18.5) {
                        if (fs[88] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[50] <= -1123.5) {
                                        return 0.0392063566601;
                                    } else {
                                        return 0.150817695093;
                                    }
                                } else {
                                    if (fs[73] <= 150.0) {
                                        return -0.164209875584;
                                    } else {
                                        return 0.0888869521234;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0131254242899;
                                    } else {
                                        return 0.0872241776304;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.103561677984;
                                    } else {
                                        return 0.00695527251447;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.0622650206272;
                                    } else {
                                        return 0.21316256537;
                                    }
                                } else {
                                    return 0.00317305094156;
                                }
                            } else {
                                return -0.00027116890848;
                            }
                        }
                    } else {
                        if (fs[4] <= 19.5) {
                            if (fs[77] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.0457857408088;
                                    } else {
                                        return -0.174835245912;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.186571482311;
                                    } else {
                                        return -0.325556454959;
                                    }
                                }
                            } else {
                                return -0.352718116553;
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.0107768957493;
                                    } else {
                                        return 0.159674494541;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0307263547477;
                                    } else {
                                        return -0.119146979947;
                                    }
                                }
                            } else {
                                if (fs[18] <= -0.5) {
                                    return -0.16743743085;
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.0604583336447;
                                    } else {
                                        return 0.0717229898754;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 5.5) {
                    if (fs[73] <= 25.0) {
                        if (fs[2] <= 1.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0351134251217;
                                    } else {
                                        return 0.013172380089;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.0379722725715;
                                    } else {
                                        return 0.159576886398;
                                    }
                                }
                            } else {
                                if (fs[67] <= -4.0) {
                                    return 0.211219703956;
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0387313918374;
                                    } else {
                                        return 0.136883643861;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0430204560486;
                                    } else {
                                        return 0.100989130883;
                                    }
                                } else {
                                    return 0.146063773004;
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0457890280873;
                                    } else {
                                        return 0.137215792899;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.104288707823;
                                    } else {
                                        return -0.000401904670407;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[50] <= -498.0) {
                                return -0.145917871007;
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0437584714831;
                                    } else {
                                        return 0.0194309336658;
                                    }
                                } else {
                                    return 0.0919076780785;
                                }
                            }
                        } else {
                            if (fs[67] <= -4.0) {
                                return 0.168325265361;
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0423753312362;
                                    } else {
                                        return 0.0970683039316;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0514741672981;
                                    } else {
                                        return -0.00356044205974;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 5.5) {
                        if (fs[46] <= -0.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.161868079917;
                                    } else {
                                        return 0.112842840974;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.282936173811;
                                    } else {
                                        return 0.0572233339191;
                                    }
                                }
                            } else {
                                return -0.086508871282;
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[75] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.123855002245;
                                    } else {
                                        return 0.0797134204057;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return -0.0107407219939;
                                    } else {
                                        return 0.166290682181;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0838021118043;
                                    } else {
                                        return -0.0282091521365;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return -0.198208354124;
                                    } else {
                                        return 0.0149156752058;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[67] <= -3.5) {
                            if (fs[18] <= 0.5) {
                                return 0.265679505585;
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.12742127517;
                                    } else {
                                        return 0.155854617775;
                                    }
                                } else {
                                    if (fs[4] <= 13.0) {
                                        return -0.0945763884352;
                                    } else {
                                        return 0.163236084899;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0347406869046;
                                    } else {
                                        return 0.0805735101567;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 9.69219285874e-05;
                                    } else {
                                        return -0.047427415133;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.220042813201;
                                    } else {
                                        return -0.00953049166903;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.042523431019;
                                    } else {
                                        return 0.0291768910861;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
