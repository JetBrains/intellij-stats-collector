/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree95 {
    public double calcTree(double... fs) {
        if (fs[0] <= 1.5) {
            if (fs[11] <= 0.5) {
                if (fs[68] <= 0.5) {
                    if (fs[52] <= 0.5) {
                        if (fs[26] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.200682902398;
                                    } else {
                                        return 0.0534856741908;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.0388487427288;
                                    } else {
                                        return 0.0933516188898;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1478.0) {
                                    if (fs[69] <= 9996.5) {
                                        return 0.0453241163848;
                                    } else {
                                        return 0.000604642870057;
                                    }
                                } else {
                                    if (fs[4] <= 36.5) {
                                        return 0.000491363908706;
                                    } else {
                                        return 0.176982801238;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -531.5) {
                                return 0.0302648415163;
                            } else {
                                if (fs[69] <= 5000.0) {
                                    return 0.272881254679;
                                } else {
                                    return 0.0916198475414;
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 3.0) {
                            return 0.18204652678;
                        } else {
                            return 0.0918883989429;
                        }
                    }
                } else {
                    if (fs[77] <= 0.5) {
                        if (fs[4] <= 42.5) {
                            if (fs[61] <= -996.5) {
                                if (fs[50] <= -1938.0) {
                                    if (fs[69] <= 4999.5) {
                                        return -0.0511292287182;
                                    } else {
                                        return -0.243417213898;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.0411573336272;
                                    } else {
                                        return 0.0138407473954;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.5) {
                                    if (fs[59] <= -0.5) {
                                        return 0.110104702145;
                                    } else {
                                        return 0.0233985668664;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return 0.0172011586249;
                                    } else {
                                        return 0.00260259603025;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[73] <= 25.0) {
                                    return -0.0655850381065;
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.190411490415;
                                    } else {
                                        return -0.269424323453;
                                    }
                                }
                            } else {
                                return 0.000421732451459;
                            }
                        }
                    } else {
                        if (fs[6] <= 0.5) {
                            return -0.256531524696;
                        } else {
                            if (fs[97] <= 0.5) {
                                return -0.263431518125;
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return -0.174183781643;
                                    } else {
                                        return 0.025900442989;
                                    }
                                } else {
                                    return 0.1470454551;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 1.5) {
                    if (fs[50] <= -1543.5) {
                        if (fs[4] <= 24.5) {
                            if (fs[50] <= -1953.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[69] <= 9714.0) {
                                        return 0.0982105184119;
                                    } else {
                                        return 0.0139960624983;
                                    }
                                } else {
                                    if (fs[2] <= 0.5) {
                                        return -0.243780005016;
                                    } else {
                                        return -0.00407600356851;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[82] <= 1.5) {
                                        return 0.0804174657074;
                                    } else {
                                        return 0.262346862051;
                                    }
                                } else {
                                    if (fs[82] <= 5.0) {
                                        return 0.0505048235198;
                                    } else {
                                        return -0.0355766938197;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9993.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0512080606472;
                                    } else {
                                        return 0.0367682277323;
                                    }
                                } else {
                                    return 0.144759530675;
                                }
                            } else {
                                return -0.157343266376;
                            }
                        }
                    } else {
                        if (fs[65] <= 1.5) {
                            if (fs[50] <= -1488.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0534941403406;
                                    } else {
                                        return 0.00482374957655;
                                    }
                                } else {
                                    if (fs[69] <= 9125.0) {
                                        return -0.00642728375696;
                                    } else {
                                        return 0.155297712584;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.00505637167635;
                                    } else {
                                        return 0.0496120675185;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return 0.00712470710619;
                                    } else {
                                        return -0.0139535902333;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.145178717491;
                                    } else {
                                        return 0.140002909977;
                                    }
                                } else {
                                    return 0.419232765405;
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.15544234116;
                                    } else {
                                        return 0.0300938282052;
                                    }
                                } else {
                                    if (fs[69] <= 9984.5) {
                                        return -0.00349442206225;
                                    } else {
                                        return -0.116547931143;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 27.5) {
                        if (fs[2] <= 6.5) {
                            if (fs[48] <= 0.5) {
                                if (fs[69] <= 9921.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.00190963825335;
                                    } else {
                                        return 0.0119218406281;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.0226578288849;
                                    } else {
                                        return -0.00118662819342;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.175280890084;
                                    } else {
                                        return 0.0944634943164;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.0977677396877;
                                    } else {
                                        return -0.0216654302414;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 1.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[69] <= 9993.5) {
                                        return 0.0166515161071;
                                    } else {
                                        return -0.0329106260858;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0558307455682;
                                    } else {
                                        return -0.0708407746765;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0925808441844;
                                    } else {
                                        return -0.0341369382477;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return -0.194861659142;
                                    } else {
                                        return 0.126528366539;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9997.5) {
                            if (fs[50] <= -2943.0) {
                                return 0.24086559451;
                            } else {
                                if (fs[69] <= 9533.0) {
                                    if (fs[88] <= 0.5) {
                                        return -0.0311704589124;
                                    } else {
                                        return 0.161076692497;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.18674697363;
                                    } else {
                                        return -0.00195392007027;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 41.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[50] <= -1463.0) {
                                        return -0.0177436762399;
                                    } else {
                                        return 0.239681705754;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.052899971247;
                                    } else {
                                        return -0.21538499293;
                                    }
                                }
                            } else {
                                return 0.281246358424;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[52] <= 0.5) {
                if (fs[4] <= 25.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[54] <= 0.5) {
                            if (fs[0] <= 20.5) {
                                if (fs[73] <= 250.0) {
                                    if (fs[73] <= 75.0) {
                                        return 6.48148373503e-05;
                                    } else {
                                        return 0.00525490565444;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.0237144876611;
                                    } else {
                                        return -0.00670049966871;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[28] <= 0.5) {
                                        return -0.000704361823873;
                                    } else {
                                        return 0.0213350664908;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.022593355616;
                                    } else {
                                        return 0.207315279977;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 14.5) {
                                        return -0.0183254936548;
                                    } else {
                                        return 0.103671483194;
                                    }
                                } else {
                                    if (fs[82] <= 1.0) {
                                        return 0.0243368265436;
                                    } else {
                                        return 0.1101923981;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[82] <= 1.0) {
                                        return -0.0523141894603;
                                    } else {
                                        return 0.136084886386;
                                    }
                                } else {
                                    return 0.242160319199;
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 6.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return -0.00416952513151;
                                    } else {
                                        return -0.0150351951459;
                                    }
                                } else {
                                    if (fs[69] <= 9994.5) {
                                        return -0.00141909375609;
                                    } else {
                                        return -0.00696221980212;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.000392352693889;
                                    } else {
                                        return -0.00226396621759;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.000566893960051;
                                    } else {
                                        return -0.00206050900222;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[73] <= 50.0) {
                                        return -0.0211526801363;
                                    } else {
                                        return -0.0474018661933;
                                    }
                                } else {
                                    if (fs[50] <= -966.0) {
                                        return -0.00158911778301;
                                    } else {
                                        return -0.0142415921534;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0101587131977;
                                    } else {
                                        return -0.00642909126903;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.00260639514755;
                                    } else {
                                        return -0.0320942853303;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[42] <= 0.5) {
                        if (fs[69] <= 9987.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[61] <= -995.5) {
                                    return 0.0709333326314;
                                } else {
                                    if (fs[69] <= 9975.5) {
                                        return -0.00746252151555;
                                    } else {
                                        return 0.0508179699526;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9985.5) {
                                    if (fs[50] <= -4043.0) {
                                        return 0.0534067864959;
                                    } else {
                                        return -0.00123249169896;
                                    }
                                } else {
                                    return 0.164879849565;
                                }
                            }
                        } else {
                            if (fs[88] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0284389835034;
                                    } else {
                                        return -0.000417820471183;
                                    }
                                } else {
                                    if (fs[50] <= -1288.0) {
                                        return -0.207221288068;
                                    } else {
                                        return -0.0250114007081;
                                    }
                                }
                            } else {
                                return -0.106310630001;
                            }
                        }
                    } else {
                        if (fs[0] <= 8.5) {
                            if (fs[4] <= 29.5) {
                                if (fs[50] <= -1488.0) {
                                    return 0.20723284614;
                                } else {
                                    return -0.0342956930648;
                                }
                            } else {
                                if (fs[4] <= 36.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0210697853705;
                                    } else {
                                        return -0.0472865335498;
                                    }
                                } else {
                                    return 0.202108955735;
                                }
                            }
                        } else {
                            if (fs[0] <= 39.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[0] <= 21.5) {
                                        return -0.00443764808613;
                                    } else {
                                        return -0.00157338659602;
                                    }
                                } else {
                                    if (fs[4] <= 34.5) {
                                        return -0.00980868978976;
                                    } else {
                                        return -0.00527100117856;
                                    }
                                }
                            } else {
                                return 0.023333231842;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 5.5) {
                    if (fs[99] <= 0.5) {
                        if (fs[4] <= 12.5) {
                            return 0.258960434657;
                        } else {
                            return 0.0460395782568;
                        }
                    } else {
                        return -0.00458751229031;
                    }
                } else {
                    if (fs[0] <= 37.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 18.5) {
                                return 0.0291036788034;
                            } else {
                                return -0.0113812570982;
                            }
                        } else {
                            if (fs[52] <= 995.5) {
                                if (fs[50] <= -1027.0) {
                                    return -0.0335684213673;
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return -0.0159427557617;
                                    } else {
                                        return -0.00608961290675;
                                    }
                                }
                            } else {
                                return -0.036365695893;
                            }
                        }
                    } else {
                        return 0.0815897747305;
                    }
                }
            }
        }
    }
}
