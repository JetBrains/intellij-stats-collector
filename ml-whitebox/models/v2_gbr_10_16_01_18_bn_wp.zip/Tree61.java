/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree61 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[11] <= 0.5) {
                if (fs[82] <= 4.5) {
                    if (fs[4] <= 17.5) {
                        if (fs[82] <= 3.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[86] <= 0.5) {
                                        return 0.0881911559381;
                                    } else {
                                        return 0.0412517197965;
                                    }
                                } else {
                                    if (fs[50] <= -1138.5) {
                                        return -0.0215764554508;
                                    } else {
                                        return 0.0614732482246;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[69] <= 9392.0) {
                                        return -0.0263066830728;
                                    } else {
                                        return 0.129678345397;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.331810684336;
                                    } else {
                                        return 0.104615302069;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[50] <= -1458.0) {
                                    if (fs[73] <= 25.0) {
                                        return -0.309942407176;
                                    } else {
                                        return 0.141495619834;
                                    }
                                } else {
                                    return 0.147692336926;
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[50] <= -1052.0) {
                                        return 0.185988139396;
                                    } else {
                                        return 0.0185982641621;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.148229054625;
                                    } else {
                                        return 0.005651266868;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[89] <= 0.5) {
                            if (fs[4] <= 48.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[95] <= 0.5) {
                                        return -0.116250893457;
                                    } else {
                                        return 0.0147796126699;
                                    }
                                } else {
                                    if (fs[59] <= -3.5) {
                                        return -0.192815717441;
                                    } else {
                                        return 0.0339850279569;
                                    }
                                }
                            } else {
                                return -0.263257254514;
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[2] <= 5.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.107309014625;
                                    } else {
                                        return 0.00839831334347;
                                    }
                                } else {
                                    return -0.0710706563084;
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    return 0.236340002811;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.06550235134;
                                    } else {
                                        return 0.130027005913;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[62] <= 0.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[50] <= -1533.0) {
                                    if (fs[82] <= 6.5) {
                                        return 0.259166005581;
                                    } else {
                                        return 0.139201876161;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.107152652768;
                                    } else {
                                        return 0.0354407272586;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.124201797847;
                                    } else {
                                        return 0.0537566491009;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return 0.162741479637;
                                    } else {
                                        return 0.0703582112929;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.0) {
                                return -0.0472836938641;
                            } else {
                                return -0.298987867559;
                            }
                        }
                    } else {
                        if (fs[79] <= 0.5) {
                            return -0.147499348385;
                        } else {
                            return -0.286045295157;
                        }
                    }
                }
            } else {
                if (fs[50] <= -1052.5) {
                    if (fs[82] <= 6.5) {
                        if (fs[82] <= 5.5) {
                            if (fs[4] <= 27.5) {
                                if (fs[50] <= -1132.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0211433027277;
                                    } else {
                                        return 0.0501646276456;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.226756396544;
                                    } else {
                                        return 0.0780862125072;
                                    }
                                }
                            } else {
                                if (fs[50] <= -2138.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.140282972427;
                                    } else {
                                        return 0.233811144151;
                                    }
                                } else {
                                    if (fs[4] <= 42.5) {
                                        return -0.115539225072;
                                    } else {
                                        return 0.0732206587391;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.296297278994;
                                    } else {
                                        return 0.134471483462;
                                    }
                                } else {
                                    return -0.0289215053515;
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0586552838319;
                                    } else {
                                        return -0.153097949067;
                                    }
                                } else {
                                    if (fs[50] <= -1463.5) {
                                        return -0.189497778965;
                                    } else {
                                        return 0.189953714809;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 23.5) {
                            if (fs[4] <= 10.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.136996964618;
                                    } else {
                                        return 0.0712266608237;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.0458523031017;
                                    } else {
                                        return -0.11566307612;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.27832507889;
                                    } else {
                                        return 0.165081100184;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return 0.219900872718;
                                    } else {
                                        return -0.0330430155457;
                                    }
                                }
                            }
                        } else {
                            return -0.321867896182;
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[69] <= 9997.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.0487971891758;
                                    } else {
                                        return 0.00863219292491;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.182869498661;
                                    } else {
                                        return 0.263281403788;
                                    }
                                }
                            } else {
                                if (fs[67] <= -4.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0594917761196;
                                    } else {
                                        return -0.255379753828;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0803092536853;
                                    } else {
                                        return -0.197615772337;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 5.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0638340617038;
                                    } else {
                                        return 0.0870464415763;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0333200300695;
                                    } else {
                                        return 0.0129318861991;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.370637015711;
                                    } else {
                                        return -0.0938536762575;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.171300181362;
                                    } else {
                                        return 0.0162723323904;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[4] <= 7.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0745769453853;
                                    } else {
                                        return -0.0631707820393;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.0579417105757;
                                    } else {
                                        return -0.0339179219062;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0630593629881;
                                    } else {
                                        return 0.112197061529;
                                    }
                                } else {
                                    return -0.137429535594;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.0930055898814;
                                    } else {
                                        return -0.00819964892607;
                                    }
                                } else {
                                    return 0.250854535714;
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[50] <= -971.5) {
                                        return -0.0299855994399;
                                    } else {
                                        return -0.142818618731;
                                    }
                                } else {
                                    if (fs[4] <= 12.0) {
                                        return -0.214952885969;
                                    } else {
                                        return -0.426478927286;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[2] <= 1.5) {
                    if (fs[4] <= 4.5) {
                        if (fs[67] <= -3.5) {
                            if (fs[69] <= 9998.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[50] <= -1128.5) {
                                        return 0.269739839658;
                                    } else {
                                        return 0.221859521252;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.0164802534095;
                                    } else {
                                        return 0.0823761774241;
                                    }
                                }
                            } else {
                                return -0.0586132188311;
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[75] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00854097315762;
                                    } else {
                                        return 0.0618753690888;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0118823268977;
                                    } else {
                                        return 0.0230725759041;
                                    }
                                }
                            } else {
                                return 0.201909219184;
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[50] <= -1458.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.15456390742;
                                    } else {
                                        return 0.0392451500285;
                                    }
                                } else {
                                    if (fs[61] <= -995.5) {
                                        return 0.0607072116551;
                                    } else {
                                        return 0.00839748738069;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9901.0) {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0999174330647;
                                    } else {
                                        return -0.0974331344492;
                                    }
                                } else {
                                    return -0.0962439235916;
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.0442564597797;
                                    } else {
                                        return 0.0544211296563;
                                    }
                                } else {
                                    if (fs[50] <= -1303.0) {
                                        return -0.271389525892;
                                    } else {
                                        return -0.0907091889292;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0178241532446;
                                    } else {
                                        return -0.0240837887059;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.0185757839809;
                                    } else {
                                        return 0.0109985739475;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 7.5) {
                        if (fs[69] <= 9985.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.0128946503967;
                                    } else {
                                        return 0.0484919891497;
                                    }
                                } else {
                                    if (fs[2] <= 11.5) {
                                        return -0.0118040397132;
                                    } else {
                                        return 0.103655095519;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.0112619038031;
                                    } else {
                                        return 0.186724198503;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.00308464153106;
                                    } else {
                                        return 0.102126610816;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 3.5) {
                                if (fs[2] <= 5.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.013527289166;
                                    } else {
                                        return 0.214771773545;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.104410665447;
                                    } else {
                                        return -0.0123777413215;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.249113356759;
                                    } else {
                                        return 0.130470206826;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.114655473014;
                                    } else {
                                        return 0.187564159987;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[56] <= 0.5) {
                            if (fs[69] <= 9910.5) {
                                if (fs[67] <= -4.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0787094020558;
                                    } else {
                                        return -0.0358460742196;
                                    }
                                } else {
                                    if (fs[69] <= 9040.5) {
                                        return 0.0240254724237;
                                    } else {
                                        return -0.164869830245;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.169825736176;
                                    } else {
                                        return 0.0780927730871;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0284237170598;
                                    } else {
                                        return -0.176377898309;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                return -0.42356917811;
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.212555130388;
                                    } else {
                                        return -0.0471570849524;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.140451047965;
                                    } else {
                                        return -0.208340398884;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[54] <= 0.5) {
                    if (fs[69] <= 9999.5) {
                        if (fs[0] <= 7.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[50] <= -341.5) {
                                        return -0.000496049136881;
                                    } else {
                                        return 0.00608127550461;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.00228880834089;
                                    } else {
                                        return -0.00509702808439;
                                    }
                                }
                            } else {
                                if (fs[50] <= -21.5) {
                                    if (fs[42] <= 0.5) {
                                        return -0.0045263328217;
                                    } else {
                                        return 0.113287821002;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.00610531675908;
                                    } else {
                                        return -0.0152642082696;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 118.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00332421155237;
                                    } else {
                                        return 0.0992060594391;
                                    }
                                } else {
                                    if (fs[0] <= 18.5) {
                                        return -0.00176699931887;
                                    } else {
                                        return -0.00276450745681;
                                    }
                                }
                            } else {
                                if (fs[0] <= 121.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.00741707573253;
                                    } else {
                                        return 0.16790313286;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.00397927605761;
                                    } else {
                                        return 0.00416807222515;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[50] <= -2213.0) {
                                return 0.434013349909;
                            } else {
                                if (fs[50] <= -1032.0) {
                                    if (fs[2] <= 8.5) {
                                        return 0.0481704821849;
                                    } else {
                                        return -0.178716675668;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0358658036826;
                                    } else {
                                        return 0.0298679629849;
                                    }
                                }
                            }
                        } else {
                            if (fs[96] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[95] <= 1.0) {
                                        return -0.0559013587595;
                                    } else {
                                        return -0.0181469851947;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0132049555728;
                                    } else {
                                        return -0.00509168097328;
                                    }
                                }
                            } else {
                                return -0.0676842809468;
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[4] <= 8.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[4] <= 6.5) {
                                    return 0.219949556498;
                                } else {
                                    return -0.038682480406;
                                }
                            } else {
                                if (fs[82] <= 3.0) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0655969864792;
                                    } else {
                                        return -0.0111807190113;
                                    }
                                } else {
                                    return 0.325697036967;
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[95] <= 1.0) {
                                    if (fs[0] <= 16.5) {
                                        return -0.0633071249817;
                                    } else {
                                        return -0.035358538608;
                                    }
                                } else {
                                    return 0.0589607664356;
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    return 0.423633433363;
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.29376753465;
                                    } else {
                                        return 0.0908934919033;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 250.0) {
                            if (fs[0] <= 8.5) {
                                return -0.0391893929644;
                            } else {
                                if (fs[67] <= -4.0) {
                                    return -0.026899147624;
                                } else {
                                    return -0.014918855904;
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[50] <= -976.0) {
                                    return -0.00647037916041;
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.00788246998901;
                                    } else {
                                        return -0.00324583744753;
                                    }
                                }
                            } else {
                                return -0.030109588804;
                            }
                        }
                    }
                }
            }
        }
    }
}
