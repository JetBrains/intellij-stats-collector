/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree65 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[23] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[50] <= -1498.5) {
                        if (fs[2] <= 0.5) {
                            return -0.179412503245;
                        } else {
                            if (fs[4] <= 18.5) {
                                if (fs[50] <= -1953.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0130525699829;
                                    } else {
                                        return 0.099925313763;
                                    }
                                } else {
                                    if (fs[50] <= -1943.5) {
                                        return 0.208380877489;
                                    } else {
                                        return 0.11057514917;
                                    }
                                }
                            } else {
                                if (fs[67] <= -1.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0963084030457;
                                    } else {
                                        return 0.0281098507751;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return -0.0667351604745;
                                    } else {
                                        return -0.1411859771;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0414823534019;
                                    } else {
                                        return -0.0454063056884;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0342149323078;
                                    } else {
                                        return 0.0253839250169;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9981.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.211758037158;
                                    } else {
                                        return -0.0291074593174;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0789956562917;
                                    } else {
                                        return 0.0624325203851;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0277132958883;
                                    } else {
                                        return -0.179851855629;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return 0.0294442577936;
                                    } else {
                                        return -0.0105114409361;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1483.5) {
                                    if (fs[69] <= 9994.5) {
                                        return -0.0940845109131;
                                    } else {
                                        return -0.00453995267814;
                                    }
                                } else {
                                    if (fs[50] <= -987.5) {
                                        return 0.0802308426149;
                                    } else {
                                        return -0.101208031378;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[8] <= 0.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[50] <= -1143.5) {
                                        return -0.0233955692651;
                                    } else {
                                        return 0.0413025293984;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0555390546976;
                                    } else {
                                        return -0.00351325862033;
                                    }
                                }
                            } else {
                                return -0.364374518382;
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[50] <= -491.5) {
                                        return -0.0937721902624;
                                    } else {
                                        return -0.257074902927;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.017637869243;
                                    } else {
                                        return 0.214274413392;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0623044737882;
                                    } else {
                                        return -0.103436076193;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0580886431103;
                                    } else {
                                        return 0.133269908936;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[46] <= -0.5) {
                            if (fs[59] <= -3.5) {
                                return -0.163484632028;
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.258094970746;
                                    } else {
                                        return 0.11851986341;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0317595492156;
                                    } else {
                                        return 0.0886078175068;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1988.0) {
                                if (fs[4] <= 52.0) {
                                    if (fs[84] <= 0.5) {
                                        return 0.178102276246;
                                    } else {
                                        return 0.107389820481;
                                    }
                                } else {
                                    return -0.317247950143;
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[73] <= 250.0) {
                                        return -0.00343222624131;
                                    } else {
                                        return 0.0316128593369;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0394351962755;
                                    } else {
                                        return 0.0811943948356;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[69] <= 9931.5) {
                    if (fs[67] <= -4.0) {
                        if (fs[50] <= -1138.0) {
                            return 0.247122689766;
                        } else {
                            return 0.0212355343652;
                        }
                    } else {
                        if (fs[69] <= 9787.0) {
                            if (fs[4] <= 8.5) {
                                if (fs[49] <= 0.5) {
                                    return 0.217919396316;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.386541980671;
                                    } else {
                                        return 0.258229233134;
                                    }
                                }
                            } else {
                                return 0.147377766344;
                            }
                        } else {
                            return 0.171089408052;
                        }
                    }
                } else {
                    if (fs[4] <= 7.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[69] <= 9956.5) {
                                return -0.0917955616195;
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.166914100033;
                                    } else {
                                        return 0.108754759094;
                                    }
                                } else {
                                    return 0.0443529380891;
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[69] <= 9994.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.122435722177;
                                    } else {
                                        return 0.312583449794;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.12064585717;
                                    } else {
                                        return 0.0764373342848;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.0254974288957;
                                } else {
                                    return 0.142548528545;
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            return 0.279495150908;
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[50] <= -1138.0) {
                                    return 0.240867236432;
                                } else {
                                    return 0.11766187817;
                                }
                            } else {
                                return 0.00163452944499;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[69] <= 9999.5) {
                if (fs[0] <= 2.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[61] <= -997.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.316278614698;
                                    } else {
                                        return -0.0345507226781;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.344329247145;
                                    } else {
                                        return 0.126270816223;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1478.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0210123079457;
                                    } else {
                                        return 0.0664641572677;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0276611544747;
                                    } else {
                                        return 0.0032848981303;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[69] <= 9880.0) {
                                    if (fs[46] <= -0.5) {
                                        return -0.0423198800822;
                                    } else {
                                        return -0.0127480962784;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0566012800022;
                                    } else {
                                        return -0.0754317578145;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.00520815086579;
                                    } else {
                                        return 0.0515447535644;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.0469930139675;
                                    } else {
                                        return -0.0196887069311;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0813190987263;
                                    } else {
                                        return -0.0184484458336;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0797485247239;
                                    } else {
                                        return -0.0433092554063;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.0596294834815;
                                    } else {
                                        return -0.00782576176183;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0132699166255;
                                    } else {
                                        return -0.119289345583;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.000701807022596;
                                    } else {
                                        return 0.022757870609;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0190400490289;
                                    } else {
                                        return -0.0107393166857;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0224146661783;
                                    } else {
                                        return 0.241684534675;
                                    }
                                } else {
                                    if (fs[50] <= -1468.0) {
                                        return 0.140364247489;
                                    } else {
                                        return 0.00397136325474;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[14] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.00322713363326;
                                    } else {
                                        return -0.00197066706368;
                                    }
                                } else {
                                    if (fs[50] <= -721.5) {
                                        return 0.122177018343;
                                    } else {
                                        return 0.0486362945952;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0128273069267;
                                    } else {
                                        return 0.106472064902;
                                    }
                                } else {
                                    return 0.528333546365;
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                if (fs[75] <= 0.5) {
                                    if (fs[30] <= 0.5) {
                                        return -0.0392207204858;
                                    } else {
                                        return -0.000425129576778;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.0038382080622;
                                    } else {
                                        return -0.00769100270794;
                                    }
                                }
                            } else {
                                if (fs[0] <= 12.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.00327258110659;
                                    } else {
                                        return 0.0174162815474;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.00237277830981;
                                    } else {
                                        return -0.00152054107658;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 4.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[4] <= 4.5) {
                                    return 0.0753872582408;
                                } else {
                                    return 0.55893937844;
                                }
                            } else {
                                if (fs[50] <= -1978.0) {
                                    return 0.0973964982259;
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0157971038849;
                                    } else {
                                        return 0.0409874672472;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[0] <= 7.5) {
                                        return -0.0100138916645;
                                    } else {
                                        return -0.00366426362902;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00878755566142;
                                    } else {
                                        return -0.021606049954;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0330699469774;
                                    } else {
                                        return 0.00554416869438;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0396282056546;
                                    } else {
                                        return -0.0044517379314;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1108.0) {
                    if (fs[50] <= -1128.0) {
                        if (fs[97] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[0] <= 21.5) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.0473729433762;
                                    } else {
                                        return 0.116598693283;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.144407476995;
                                    } else {
                                        return -0.0183039061262;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return -0.273528006947;
                                } else {
                                    return -0.154873919976;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0942176569468;
                                    } else {
                                        return -0.00506646512011;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return -0.0652221680798;
                                    } else {
                                        return -0.187952612761;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.22664723746;
                                    } else {
                                        return 0.113271743808;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.030041913854;
                                    } else {
                                        return -0.0940531332602;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[91] <= 0.5) {
                            return -0.0958407372903;
                        } else {
                            if (fs[49] <= 0.5) {
                                return -0.0201840247001;
                            } else {
                                if (fs[4] <= 15.0) {
                                    return 0.20120683381;
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.415571256439;
                                    } else {
                                        return 0.529884837578;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[67] <= -3.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[95] <= 0.5) {
                                    return -0.0327358338966;
                                } else {
                                    return -0.0564876455008;
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.162606256373;
                                    } else {
                                        return -0.135015510732;
                                    }
                                } else {
                                    return -0.104062368214;
                                }
                            }
                        } else {
                            return 0.131966881067;
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[95] <= 1.5) {
                                if (fs[82] <= 3.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.106319347878;
                                    } else {
                                        return -0.0108700373788;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0527565280738;
                                    } else {
                                        return 0.0493772590133;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    return 0.00381085668476;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0835431090919;
                                    } else {
                                        return 0.37388023883;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.164522418158;
                                    } else {
                                        return -0.0365339327688;
                                    }
                                } else {
                                    if (fs[50] <= 17.5) {
                                        return -0.00752188082358;
                                    } else {
                                        return 0.0292498479528;
                                    }
                                }
                            } else {
                                return 0.104101400213;
                            }
                        }
                    }
                }
            }
        }
    }
}
