/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree78 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[84] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[43] <= 0.5) {
                        if (fs[75] <= 0.5) {
                            if (fs[39] <= 0.5) {
                                if (fs[2] <= 0.5) {
                                    return -0.226643676133;
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0174335931415;
                                    } else {
                                        return 0.0219071210341;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.121298418145;
                                    } else {
                                        return 0.126175691259;
                                    }
                                } else {
                                    return 0.072836184822;
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[82] <= 2.5) {
                                        return 4.89426575211e-05;
                                    } else {
                                        return 0.0393565590867;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0725793560022;
                                    } else {
                                        return 0.00208669404239;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[50] <= -1503.5) {
                                        return 0.0581137377001;
                                    } else {
                                        return -0.043901887065;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.0143030935957;
                                    } else {
                                        return 0.0778174109917;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return 0.0209793785489;
                                    } else {
                                        return 0.0572755118351;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.106825399047;
                                    } else {
                                        return -0.223235348696;
                                    }
                                }
                            } else {
                                if (fs[4] <= 25.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.130678728853;
                                    } else {
                                        return 0.097866532731;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.244533513898;
                                    } else {
                                        return 0.0573684654333;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1118.5) {
                                if (fs[65] <= 1.5) {
                                    return -0.0325907364397;
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0447354616235;
                                    } else {
                                        return -0.0402552709081;
                                    }
                                }
                            } else {
                                return 0.172577641299;
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[34] <= 0.5) {
                            if (fs[73] <= 150.0) {
                                if (fs[69] <= 9813.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.0014208382759;
                                    } else {
                                        return 0.00445937968646;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0016653549867;
                                    } else {
                                        return 0.0793261909492;
                                    }
                                }
                            } else {
                                if (fs[50] <= -2518.0) {
                                    return 0.278087099252;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0215749121376;
                                    } else {
                                        return -0.00398530862371;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[4] <= 5.0) {
                                    return 0.186774911757;
                                } else {
                                    return -0.0810180997049;
                                }
                            } else {
                                return 0.108064856369;
                            }
                        }
                    } else {
                        if (fs[93] <= 0.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[50] <= -1142.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0291259557146;
                                    } else {
                                        return 0.002753215548;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.00866847744992;
                                    } else {
                                        return -0.00103177515265;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return 0.204909108168;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.0168092982658;
                                    } else {
                                        return -0.00643449845908;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0118075967224;
                                    } else {
                                        return -0.0759403826684;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.105307283379;
                                    } else {
                                        return 0.0381376126283;
                                    }
                                }
                            } else {
                                if (fs[13] <= 0.5) {
                                    if (fs[69] <= 9992.5) {
                                        return 0.000144329399707;
                                    } else {
                                        return -0.0377250829655;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.045120675617;
                                    } else {
                                        return -0.0308455395267;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[69] <= 9994.5) {
                        if (fs[91] <= 0.5) {
                            if (fs[4] <= 37.5) {
                                if (fs[69] <= 9950.5) {
                                    if (fs[73] <= 150.0) {
                                        return 0.0448344261657;
                                    } else {
                                        return 0.145284349526;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.15893591372;
                                    } else {
                                        return 0.015887509665;
                                    }
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[4] <= 42.0) {
                                        return 0.144051842626;
                                    } else {
                                        return 0.357534170456;
                                    }
                                } else {
                                    return 0.421585742268;
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[4] <= 26.5) {
                                    if (fs[55] <= 0.5) {
                                        return 0.0256461050262;
                                    } else {
                                        return -0.0478046057474;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.192427873813;
                                    } else {
                                        return 0.0135761694534;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 37.5) {
                                        return 0.00388654927823;
                                    } else {
                                        return -0.252857384019;
                                    }
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return 0.0743577910144;
                                    } else {
                                        return 0.210364481474;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[91] <= 0.5) {
                            if (fs[95] <= 1.5) {
                                return 0.0631286020836;
                            } else {
                                if (fs[68] <= 0.5) {
                                    return 0.118155986974;
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.122971415237;
                                    } else {
                                        return -0.087080310061;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return -0.0309383925541;
                                    } else {
                                        return -0.485619736506;
                                    }
                                } else {
                                    return -0.446767007412;
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    return -0.0758106542755;
                                } else {
                                    return 0.0380571056447;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1418.0) {
                        if (fs[91] <= 0.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[50] <= -2468.0) {
                                        return 0.215892115982;
                                    } else {
                                        return 0.0320472755888;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.140171553639;
                                    } else {
                                        return 0.0347063146799;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0379290274387;
                                    } else {
                                        return -0.00299453785598;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.125907291792;
                                    } else {
                                        return 0.0306968141714;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.021504325137;
                                    } else {
                                        return 0.0949176925374;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.127058102574;
                                    } else {
                                        return -0.0606722776866;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0663585248921;
                                    } else {
                                        return 0.231805669746;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.0100255933981;
                                    } else {
                                        return 0.094441136235;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[59] <= -1.5) {
                                if (fs[50] <= -1093.0) {
                                    if (fs[61] <= -996.5) {
                                        return 0.163068381906;
                                    } else {
                                        return 0.0225774465667;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.00479590985834;
                                    } else {
                                        return -0.0729766686592;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1137.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.0145289820815;
                                    } else {
                                        return -0.0174252158162;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.010415836327;
                                    } else {
                                        return -0.000941119164376;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.0103456593068;
                                    } else {
                                        return -0.00916424054681;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.0226187564214;
                                    } else {
                                        return 0.369508606791;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.0175585454275;
                                    } else {
                                        return -0.0639899370982;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.00564243979266;
                                    } else {
                                        return -0.00208924876691;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 35.5) {
                    if (fs[84] <= 0.5) {
                        if (fs[59] <= -0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[82] <= 3.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0201660042313;
                                    } else {
                                        return 0.0423929611566;
                                    }
                                } else {
                                    return 0.138717940944;
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.107385286118;
                                    } else {
                                        return 0.301633048499;
                                    }
                                } else {
                                    return 0.230090446179;
                                }
                            }
                        } else {
                            if (fs[4] <= 22.5) {
                                if (fs[73] <= 300.0) {
                                    if (fs[4] <= 17.5) {
                                        return 0.0220859610218;
                                    } else {
                                        return -0.0435320352163;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.211610842501;
                                    } else {
                                        return 0.0781488171423;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9997.5) {
                                    return -0.17880677028;
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.0605784976628;
                                    } else {
                                        return 0.190062678194;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[7] <= 0.5) {
                                if (fs[6] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.119875940792;
                                    } else {
                                        return -0.329588519442;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.0404948846016;
                                    } else {
                                        return -0.175753023944;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return -0.465523940281;
                                    } else {
                                        return -0.205085947408;
                                    }
                                } else {
                                    return -0.148702792933;
                                }
                            }
                        } else {
                            if (fs[73] <= 250.0) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[73] <= 100.0) {
                                        return 0.0537649184743;
                                    } else {
                                        return 0.0866038493136;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.0354698273888;
                                    } else {
                                        return -0.11410761006;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.012355605798;
                                    } else {
                                        return -0.314356530888;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.0235808990407;
                                    } else {
                                        return 0.223858026748;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1733.0) {
                        return -0.00482480931556;
                    } else {
                        if (fs[11] <= 0.5) {
                            return -0.431890580881;
                        } else {
                            if (fs[33] <= 0.5) {
                                return -0.208894834048;
                            } else {
                                return -0.0533126575042;
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 6.5) {
                    if (fs[50] <= -2423.0) {
                        if (fs[25] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                return -0.0680298917395;
                            } else {
                                return 0.109041942696;
                            }
                        } else {
                            return 0.328410812124;
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[61] <= -995.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.181165267917;
                                    } else {
                                        return -0.0291136099468;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0711685761686;
                                    } else {
                                        return -0.00526283235312;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0995743158451;
                                    } else {
                                        return 0.298925765375;
                                    }
                                } else {
                                    return -0.070344105244;
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[0] <= 19.5) {
                                        return 0.0343030806456;
                                    } else {
                                        return -0.0316092107966;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0458886135243;
                                    } else {
                                        return 0.204608549536;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0536280976096;
                                    } else {
                                        return 0.000932241332922;
                                    }
                                } else {
                                    if (fs[50] <= -1077.5) {
                                        return 0.263905797828;
                                    } else {
                                        return 0.0150023778202;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 14.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[4] <= 12.5) {
                                return 0.0885282630862;
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[50] <= -1128.0) {
                                        return -0.207428543456;
                                    } else {
                                        return -0.0344450726566;
                                    }
                                } else {
                                    return 0.110247275713;
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[50] <= -1488.0) {
                                    if (fs[4] <= 21.0) {
                                        return -0.0291218258544;
                                    } else {
                                        return 0.30287705237;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.280053197382;
                                    } else {
                                        return 0.159733048124;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    return -0.215070409524;
                                } else {
                                    return 0.150781780953;
                                }
                            }
                        }
                    } else {
                        return -0.113632406936;
                    }
                }
            }
        }
    }
}
