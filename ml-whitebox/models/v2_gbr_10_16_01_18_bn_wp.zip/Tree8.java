/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree8 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[50] <= -1043.5) {
                if (fs[50] <= -1228.5) {
                    if (fs[73] <= 25.0) {
                        if (fs[33] <= 0.5) {
                            if (fs[95] <= 0.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[69] <= 9848.5) {
                                        return 0.0438989923898;
                                    } else {
                                        return 0.312110885721;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.545631042757;
                                    } else {
                                        return 0.0729310115226;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.040631008679;
                                    } else {
                                        return 0.365977761597;
                                    }
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return 0.38693778269;
                                    } else {
                                        return 0.0917299728123;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 16.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[50] <= -1478.0) {
                                        return 0.6175590653;
                                    } else {
                                        return 0.513602736261;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.471663101049;
                                    } else {
                                        return 0.572867691256;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.15094242777;
                                    } else {
                                        return 0.380334723852;
                                    }
                                } else {
                                    if (fs[50] <= -1918.0) {
                                        return 0.599189926253;
                                    } else {
                                        return 0.303698227831;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.360610977951;
                                    } else {
                                        return 0.544679810116;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.530571147351;
                                    } else {
                                        return 0.608394780315;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.121611102014;
                                    } else {
                                        return 0.369103352908;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.651580418297;
                                    } else {
                                        return 0.376665531211;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.436576904086;
                                    } else {
                                        return 0.590315230005;
                                    }
                                } else {
                                    if (fs[4] <= 35.5) {
                                        return 0.341010197436;
                                    } else {
                                        return 0.0366993770114;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.614632264221;
                                    } else {
                                        return 0.421896664069;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.0144141510549;
                                    } else {
                                        return 0.383619809567;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[75] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.586076381177;
                                    } else {
                                        return 0.566837850339;
                                    }
                                } else {
                                    return 0.154910913326;
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.482995609733;
                                    } else {
                                        return 0.661709537087;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.546142923704;
                                    } else {
                                        return 0.596158540889;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 13.0) {
                                if (fs[4] <= 3.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.611797650377;
                                    } else {
                                        return 0.56455909643;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.595384256174;
                                    } else {
                                        return 0.625708105495;
                                    }
                                }
                            } else {
                                return 0.179592822996;
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.646651787771;
                                    } else {
                                        return 0.566262636974;
                                    }
                                } else {
                                    if (fs[69] <= 4623.5) {
                                        return 0.18557199152;
                                    } else {
                                        return 0.586135763171;
                                    }
                                }
                            } else {
                                if (fs[76] <= 0.5) {
                                    if (fs[82] <= 3.5) {
                                        return 0.407131874292;
                                    } else {
                                        return 0.556241161101;
                                    }
                                } else {
                                    if (fs[50] <= -1123.5) {
                                        return 0.634095714772;
                                    } else {
                                        return 0.698125548678;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[100] <= 0.5) {
                                        return 0.516494542147;
                                    } else {
                                        return 0.613464760652;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.27855205821;
                                    } else {
                                        return 0.00388596965744;
                                    }
                                }
                            } else {
                                if (fs[61] <= -995.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.54142745719;
                                    } else {
                                        return 0.633811296846;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.265967130667;
                                    } else {
                                        return 0.486094464915;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 1.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[61] <= -496.5) {
                            if (fs[67] <= -4.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0652552122466;
                                    } else {
                                        return 0.364320651075;
                                    }
                                } else {
                                    return 0.682931295382;
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.480463280911;
                                    } else {
                                        return 0.656699456805;
                                    }
                                } else {
                                    if (fs[46] <= -1.5) {
                                        return 0.589400238155;
                                    } else {
                                        return 0.45517189073;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[89] <= 0.5) {
                                        return -0.170350602775;
                                    } else {
                                        return 0.291613835723;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.674878013305;
                                    } else {
                                        return 0.451493886211;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.356294749994;
                                    } else {
                                        return -0.196502452462;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.203991951515;
                                    } else {
                                        return -0.107213080037;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[69] <= 9861.0) {
                                    if (fs[75] <= 0.5) {
                                        return 0.333723960863;
                                    } else {
                                        return 0.0761795523566;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.248739418094;
                                    } else {
                                        return 0.161054794247;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    return 0.673949303982;
                                } else {
                                    return 0.561981432199;
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.122406717645;
                                    } else {
                                        return -0.156033393813;
                                    }
                                } else {
                                    if (fs[82] <= -0.5) {
                                        return -0.133449464412;
                                    } else {
                                        return 0.0271177961539;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    return -0.146790065517;
                                } else {
                                    return 0.126011398377;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 5.5) {
                        if (fs[25] <= 0.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[82] <= -0.5) {
                                        return -0.0351866091818;
                                    } else {
                                        return 0.494387423732;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return 0.528990040676;
                                    } else {
                                        return 0.290516728669;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.594443733561;
                                    } else {
                                        return 0.225180807333;
                                    }
                                } else {
                                    return 0.0618703870999;
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0339614033971;
                                    } else {
                                        return 0.57445298207;
                                    }
                                } else {
                                    if (fs[69] <= 9991.0) {
                                        return -0.162180131311;
                                    } else {
                                        return 0.0411854159257;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    return 0.601550897638;
                                } else {
                                    if (fs[69] <= 9859.5) {
                                        return 0.575775354639;
                                    } else {
                                        return 0.164644771465;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9970.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.644318725613;
                                    } else {
                                        return 0.548221603568;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.175382260834;
                                    } else {
                                        return 0.674972145903;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.61403828232;
                                    } else {
                                        return 0.41048850906;
                                    }
                                } else {
                                    if (fs[67] <= -3.5) {
                                        return 0.314618410462;
                                    } else {
                                        return 0.0423305200768;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[78] <= 0.5) {
                                    return 0.644165735762;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.431023982192;
                                    } else {
                                        return 0.598232380582;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    if (fs[73] <= 50.0) {
                                        return 0.62286039896;
                                    } else {
                                        return 0.681809150426;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.603844323103;
                                    } else {
                                        return 0.499302784154;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 2.5) {
                if (fs[4] <= 7.5) {
                    if (fs[69] <= 8866.5) {
                        if (fs[82] <= 7.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[25] <= 0.5) {
                                    if (fs[50] <= -1093.5) {
                                        return 0.0585984362567;
                                    } else {
                                        return 0.00599170840732;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0407230370059;
                                    } else {
                                        return 0.14240267645;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0759006908736;
                                    } else {
                                        return -0.0270039615195;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.114834849819;
                                    } else {
                                        return -0.0455690300573;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[50] <= -490.5) {
                                        return -0.022194600294;
                                    } else {
                                        return 0.0398057867873;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0356516589126;
                                    } else {
                                        return -0.0679023851507;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.10730035511;
                                    } else {
                                        return -0.0434149493092;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.0338354779861;
                                    } else {
                                        return 0.463127520006;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 7.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0311395932844;
                                    } else {
                                        return 0.0785721316698;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0397593366713;
                                    } else {
                                        return 0.168046275213;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.13980077447;
                                    } else {
                                        return 0.0784498065791;
                                    }
                                } else {
                                    if (fs[69] <= 9981.5) {
                                        return 0.115203456341;
                                    } else {
                                        return 0.499451902539;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0139261746913;
                                    } else {
                                        return 0.241798415645;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.167248657932;
                                    } else {
                                        return 0.590235993993;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1058.0) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0938928886367;
                                    } else {
                                        return 0.567457988463;
                                    }
                                } else {
                                    if (fs[69] <= 9991.5) {
                                        return -0.0646661320554;
                                    } else {
                                        return 0.398393304519;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[99] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0520890308238;
                                    } else {
                                        return 0.0123702176608;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.117031855206;
                                    } else {
                                        return 0.0522130666375;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[50] <= -1128.0) {
                                        return 0.307023368147;
                                    } else {
                                        return 0.108206797815;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.140082269233;
                                    } else {
                                        return -0.0384327974947;
                                    }
                                }
                            }
                        } else {
                            if (fs[89] <= 0.5) {
                                if (fs[2] <= 11.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0389819641321;
                                    } else {
                                        return 0.0372509524321;
                                    }
                                } else {
                                    if (fs[50] <= -961.5) {
                                        return -0.0245127923056;
                                    } else {
                                        return 0.268571205937;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[47] <= 0.5) {
                                        return -0.0496509288865;
                                    } else {
                                        return -0.0517279406466;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0477570709977;
                                    } else {
                                        return -0.044147206481;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 6.5) {
                            if (fs[69] <= 9987.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0032725599215;
                                    } else {
                                        return -0.0253056138067;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0408404012575;
                                    } else {
                                        return -0.000406005197219;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.314007405969;
                                    } else {
                                        return 0.0193699885057;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.661214171341;
                                    } else {
                                        return 0.205956630334;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 8.5) {
                                    if (fs[69] <= 9542.0) {
                                        return -0.0067744146313;
                                    } else {
                                        return 0.0843237470143;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return 0.460584108943;
                                    } else {
                                        return 0.156733616684;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.325898120805;
                                    } else {
                                        return 0.823348842897;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.36413854261;
                                    } else {
                                        return 0.024154176178;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[95] <= 0.5) {
                    if (fs[25] <= 0.5) {
                        if (fs[69] <= 9977.5) {
                            if (fs[0] <= 5.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.486027518458;
                                    } else {
                                        return -0.0217559880276;
                                    }
                                } else {
                                    if (fs[82] <= -0.5) {
                                        return -0.0403962985213;
                                    } else {
                                        return -0.0230752494226;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[82] <= -0.5) {
                                        return -0.0396968305056;
                                    } else {
                                        return -0.0334242555113;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0387984888845;
                                    } else {
                                        return -0.0395199178579;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[69] <= 9995.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.00211304934623;
                                    } else {
                                        return 0.0518297713178;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0715007221009;
                                    } else {
                                        return 0.271894912125;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0488196571306;
                                    } else {
                                        return -0.00313279888167;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.297765159491;
                                    } else {
                                        return 0.0672506807461;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9999.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0379313399757;
                                    } else {
                                        return -0.0390114887562;
                                    }
                                } else {
                                    if (fs[82] <= 1.5) {
                                        return -0.0233834041155;
                                    } else {
                                        return -0.0389174444527;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.111562413638;
                                    } else {
                                        return -0.0238565808246;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0271226670449;
                                    } else {
                                        return -0.04023445724;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1413.0) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.467289713704;
                                    } else {
                                        return -0.0436822305123;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.599229535175;
                                    } else {
                                        return 0.823739489253;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0412209502263;
                                    } else {
                                        return -0.0706803174138;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.0573298858792;
                                    } else {
                                        return -0.0415273543673;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[0] <= 6.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[50] <= -1438.0) {
                                    if (fs[97] <= 0.5) {
                                        return 0.020965130739;
                                    } else {
                                        return 0.088835790769;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.00308278178779;
                                    } else {
                                        return 0.254183515254;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0271100340928;
                                    } else {
                                        return -0.00648419163334;
                                    }
                                } else {
                                    if (fs[50] <= -1418.0) {
                                        return 0.0396475675641;
                                    } else {
                                        return -0.011761006322;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0304350850517;
                                    } else {
                                        return -0.035489808645;
                                    }
                                } else {
                                    if (fs[50] <= -1423.0) {
                                        return 0.206132464765;
                                    } else {
                                        return 0.0367757255981;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[0] <= 81.5) {
                                        return -0.0231862456534;
                                    } else {
                                        return 0.217028587725;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.209514391019;
                                    } else {
                                        return 0.557540471034;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 5.5) {
                            if (fs[59] <= -2.5) {
                                if (fs[97] <= 1.5) {
                                    return -0.0465649758453;
                                } else {
                                    return 0.0595738605394;
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0341335503174;
                                    } else {
                                        return -0.00612164299041;
                                    }
                                } else {
                                    if (fs[50] <= -980.5) {
                                        return -0.0364582602666;
                                    } else {
                                        return -0.0389651951748;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9998.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.038820549316;
                                    } else {
                                        return -0.0373648703236;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0401658558899;
                                    } else {
                                        return -0.0391822530148;
                                    }
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0389256746697;
                                    } else {
                                        return -0.0441096865821;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.0800988239909;
                                    } else {
                                        return -0.0315991168338;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
