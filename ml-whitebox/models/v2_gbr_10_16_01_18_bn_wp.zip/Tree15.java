/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree15 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[97] <= 1.5) {
                if (fs[75] <= 0.5) {
                    if (fs[73] <= 100.0) {
                        if (fs[34] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.0420578087471;
                                    } else {
                                        return 0.174582034645;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.200603747035;
                                    } else {
                                        return -0.0597365048333;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.416496914495;
                                    } else {
                                        return 0.0280520246128;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.439286685075;
                                    } else {
                                        return 0.162513183631;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[0] <= 0.5) {
                                        return 0.391797458659;
                                    } else {
                                        return 0.502285575633;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.438017255549;
                                    } else {
                                        return 0.424348677457;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.443014032834;
                                    } else {
                                        return 0.440120088748;
                                    }
                                } else {
                                    return 0.447528313502;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 4847.0) {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 21.5) {
                                    return 0.241396758588;
                                } else {
                                    return -0.0057425558299;
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0178516360908;
                                    } else {
                                        return -0.035430369601;
                                    }
                                } else {
                                    if (fs[50] <= -1578.0) {
                                        return 0.0428585311807;
                                    } else {
                                        return -0.0314888711988;
                                    }
                                }
                            }
                        } else {
                            return 0.0869034170671;
                        }
                    }
                } else {
                    if (fs[95] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[82] <= -0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.125339090946;
                                    } else {
                                        return -0.108195345322;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.233063019853;
                                    } else {
                                        return 0.137478133397;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.359617152783;
                                    } else {
                                        return 0.0943315394826;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.247552192272;
                                    } else {
                                        return 0.0733501737242;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[50] <= -1478.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.00690338686368;
                                    } else {
                                        return 0.292297735718;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.00599121242903;
                                    } else {
                                        return -0.0380127807249;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[0] <= 7.5) {
                                        return -0.020620228086;
                                    } else {
                                        return -0.0263391692206;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.012645266951;
                                    } else {
                                        return -0.022745979766;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.502076407973;
                                    } else {
                                        return 0.271805109087;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.318445556423;
                                    } else {
                                        return 0.391300036509;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.0681280148798;
                                    } else {
                                        return -0.00767166398275;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.0291376856643;
                                    } else {
                                        return -0.00401282914758;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[50] <= -1588.0) {
                                    if (fs[69] <= 9986.5) {
                                        return 0.460753527416;
                                    } else {
                                        return 0.190418165273;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.174214223034;
                                    } else {
                                        return 0.289484294237;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0282762227211;
                                    } else {
                                        return -0.030308382003;
                                    }
                                } else {
                                    if (fs[50] <= 3.5) {
                                        return -0.0205727516073;
                                    } else {
                                        return -0.0280350114414;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[50] <= -1019.0) {
                                if (fs[49] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.469215655527;
                                    } else {
                                        return 0.41371762098;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.377964909074;
                                    } else {
                                        return 0.295625944447;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[61] <= -498.5) {
                                        return 0.45173206198;
                                    } else {
                                        return 0.188884047379;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.00290512204588;
                                    } else {
                                        return 0.0465146551598;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.294636284124;
                                    } else {
                                        return 0.157510623835;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.242723486431;
                                    } else {
                                        return -0.0438631776252;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.0792125923686;
                                    } else {
                                        return 0.371282151233;
                                    }
                                } else {
                                    return -0.0499423292632;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1012.0) {
                            if (fs[4] <= 26.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[2] <= 3.5) {
                                        return 0.000536817990548;
                                    } else {
                                        return 0.308170466957;
                                    }
                                } else {
                                    return -0.115480386902;
                                }
                            } else {
                                return -0.130171941933;
                            }
                        } else {
                            return 0.337737792768;
                        }
                    }
                } else {
                    if (fs[33] <= 0.5) {
                        if (fs[50] <= -992.5) {
                            if (fs[61] <= -994.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.132950990978;
                                    } else {
                                        return 0.28510525533;
                                    }
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return 0.371095577894;
                                    } else {
                                        return 0.516006873811;
                                    }
                                }
                            } else {
                                if (fs[0] <= 13.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.0928918032812;
                                    } else {
                                        return 0.603240897567;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.532081097324;
                                    } else {
                                        return 0.285440184965;
                                    }
                                }
                            }
                        } else {
                            if (fs[46] <= -2.5) {
                                return 0.0763241587846;
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[50] <= -972.5) {
                                        return -0.0216729418918;
                                    } else {
                                        return -0.0279031551977;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.110063878063;
                                    } else {
                                        return -0.0472637017352;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[67] <= -4.0) {
                                        return 0.00418811455764;
                                    } else {
                                        return -0.0448673430127;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.04272306661;
                                    } else {
                                        return -0.0763118018866;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0286596655706;
                                    } else {
                                        return -0.0260785129814;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.031231752352;
                                    } else {
                                        return -0.0357287754436;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    return 0.0600075669839;
                                } else {
                                    return 0.294916075008;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.0858013561903;
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return -0.0354829014535;
                                    } else {
                                        return -0.0298715876336;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[50] <= -1052.5) {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 8.5) {
                        if (fs[18] <= -0.5) {
                            return -0.134684018258;
                        } else {
                            if (fs[29] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.457084937237;
                                    } else {
                                        return 0.0664389678568;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.406193338334;
                                    } else {
                                        return 0.345030801921;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    return 0.193840261205;
                                } else {
                                    return 0.0449088159055;
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[42] <= 0.5) {
                                if (fs[50] <= -1478.0) {
                                    if (fs[87] <= 0.5) {
                                        return 0.356640606406;
                                    } else {
                                        return -0.101006149641;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return 0.455272560198;
                                    } else {
                                        return 0.196906725507;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    return 0.11430938194;
                                } else {
                                    return -0.293576186977;
                                }
                            }
                        } else {
                            if (fs[39] <= 0.5) {
                                if (fs[50] <= -1578.0) {
                                    if (fs[73] <= 250.0) {
                                        return 0.445506809733;
                                    } else {
                                        return 0.266940610869;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.149911389802;
                                    } else {
                                        return 0.283517057604;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.284294245431;
                                    } else {
                                        return 0.408707450403;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.436376825245;
                                    } else {
                                        return 0.33977519918;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9999.5) {
                        if (fs[82] <= 6.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[73] <= 150.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.143089899412;
                                    } else {
                                        return 0.0407676257799;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0484861476694;
                                    } else {
                                        return -0.0674904094906;
                                    }
                                }
                            } else {
                                if (fs[82] <= 1.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0809202957828;
                                    } else {
                                        return 0.217436043491;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.131935597864;
                                    } else {
                                        return -0.0268554905386;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1488.0) {
                                if (fs[2] <= 1.5) {
                                    if (fs[69] <= 9998.5) {
                                        return -0.0812189560822;
                                    } else {
                                        return 0.1207600265;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.448341677255;
                                    } else {
                                        return 0.179200766231;
                                    }
                                }
                            } else {
                                return 0.459170715152;
                            }
                        }
                    } else {
                        if (fs[50] <= -1418.0) {
                            if (fs[4] <= 30.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[63] <= 5.0) {
                                        return 0.29365749955;
                                    } else {
                                        return -0.103436303125;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0529867370662;
                                    } else {
                                        return -0.104835371648;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    return -0.154446247357;
                                } else {
                                    return 0.0282144017949;
                                }
                            }
                        } else {
                            if (fs[50] <= -1123.5) {
                                if (fs[0] <= 10.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.310509560397;
                                    } else {
                                        return 0.0667785849151;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0554785884852;
                                    } else {
                                        return -0.0421928807829;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0607258612817;
                                    } else {
                                        return 0.192898264107;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.509425966606;
                                    } else {
                                        return 0.78418221876;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= 3.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[59] <= -0.5) {
                                    if (fs[61] <= -498.0) {
                                        return 0.459835472828;
                                    } else {
                                        return 0.275033334951;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.317888808431;
                                    } else {
                                        return 0.165438377367;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.211899518918;
                                    } else {
                                        return 0.100752490245;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.172085080778;
                                    } else {
                                        return -0.0147444411699;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.456264223118;
                                    } else {
                                        return 0.389668171503;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.247758743903;
                                    } else {
                                        return 0.412701763118;
                                    }
                                }
                            } else {
                                if (fs[46] <= -0.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.409401041398;
                                    } else {
                                        return 0.50025344431;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.286661209192;
                                    } else {
                                        return 0.10936498039;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -16.0) {
                            if (fs[2] <= 6.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0447348201771;
                                    } else {
                                        return -0.0715508992674;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.0307672044548;
                                    } else {
                                        return 0.119562789952;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    return 0.21718074957;
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.114361357967;
                                    } else {
                                        return -0.0513597350039;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0786695985813;
                                    } else {
                                        return 0.0250037520642;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.146570735479;
                                    } else {
                                        return 0.0395452101478;
                                    }
                                }
                            } else {
                                if (fs[4] <= 45.0) {
                                    if (fs[8] <= 0.5) {
                                        return 0.00876412759503;
                                    } else {
                                        return 0.316656313297;
                                    }
                                } else {
                                    return 0.281076514424;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[60] <= 0.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.00929651847909;
                                    } else {
                                        return -0.0356744639768;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0014226195852;
                                    } else {
                                        return -0.0282982837908;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return 0.101962527145;
                                } else {
                                    return -0.0328575470485;
                                }
                            }
                        } else {
                            return 0.0561151621333;
                        }
                    } else {
                        if (fs[4] <= 16.5) {
                            if (fs[69] <= 9999.5) {
                                return 0.0532469888605;
                            } else {
                                return -0.0465670577796;
                            }
                        } else {
                            if (fs[4] <= 22.5) {
                                return 0.244272114021;
                            } else {
                                return -0.0526612255729;
                            }
                        }
                    }
                }
            }
        }
    }
}
