/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree81 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[95] <= 0.5) {
                if (fs[4] <= 2.5) {
                    if (fs[0] <= 1.5) {
                        return 0.0421212690035;
                    } else {
                        if (fs[50] <= -1068.0) {
                            if (fs[0] <= 2.5) {
                                return 0.115685633458;
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.20747085044;
                                    } else {
                                        return 0.245933636774;
                                    }
                                } else {
                                    return 0.149139062068;
                                }
                            }
                        } else {
                            return -0.121968201278;
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[50] <= -1138.0) {
                            if (fs[2] <= 2.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.00665392459647;
                                    } else {
                                        return 0.0962280678227;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.00633741194716;
                                    } else {
                                        return 0.172127667498;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0212922993316;
                                    } else {
                                        return -0.0784343076075;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0204334846035;
                                    } else {
                                        return 0.152398217862;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[69] <= 9990.5) {
                                        return 0.0311033852256;
                                    } else {
                                        return -0.150723062792;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0959292792051;
                                    } else {
                                        return 0.124920772989;
                                    }
                                }
                            } else {
                                if (fs[50] <= -471.5) {
                                    if (fs[50] <= -983.0) {
                                        return 0.0101435398426;
                                    } else {
                                        return -0.190221384063;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.0177549611376;
                                    } else {
                                        return 0.10052030722;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.032066350982;
                                    } else {
                                        return -0.0104926982294;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.0112160900915;
                                    } else {
                                        return 0.100808962584;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1058.0) {
                                    return 0.382263387693;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0362425649149;
                                    } else {
                                        return -0.0661548470364;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                return -0.0194398142553;
                            } else {
                                if (fs[0] <= 18.5) {
                                    if (fs[50] <= -571.5) {
                                        return -0.0235962361722;
                                    } else {
                                        return 0.180841943939;
                                    }
                                } else {
                                    return -0.0219132828679;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1438.0) {
                    if (fs[73] <= 100.0) {
                        if (fs[2] <= 1.5) {
                            return 0.0110497500882;
                        } else {
                            return -0.0420285388452;
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 25.5) {
                                if (fs[4] <= 22.5) {
                                    return -0.0177839749661;
                                } else {
                                    return -0.0218724178907;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    return -0.0830197043511;
                                } else {
                                    if (fs[4] <= 33.5) {
                                        return -0.0379646065066;
                                    } else {
                                        return -0.0203962602103;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1568.0) {
                                if (fs[2] <= 3.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.103090511933;
                                    } else {
                                        return -0.0215088082208;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0444031163045;
                                    } else {
                                        return 0.0074970244171;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1538.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0571736653255;
                                    } else {
                                        return -0.0122385530377;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0175431172023;
                                    } else {
                                        return -0.00494548566606;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[50] <= -1138.0) {
                            if (fs[0] <= 1.5) {
                                if (fs[0] <= 0.5) {
                                    return 0.104633193775;
                                } else {
                                    return 0.0802487284381;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 20.5) {
                                        return -0.00726452434307;
                                    } else {
                                        return -0.000365800852958;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.0176890537725;
                                    } else {
                                        return -0.000949043369408;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    return -0.0339710605111;
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0165820532117;
                                    } else {
                                        return -3.82190945829e-05;
                                    }
                                }
                            } else {
                                if (fs[4] <= 72.0) {
                                    if (fs[33] <= 0.5) {
                                        return 0.00555490001754;
                                    } else {
                                        return -0.00128515138904;
                                    }
                                } else {
                                    return 0.0484557108485;
                                }
                            }
                        }
                    } else {
                        if (fs[43] <= 0.5) {
                            if (fs[4] <= 26.5) {
                                if (fs[2] <= 5.5) {
                                    if (fs[4] <= 17.5) {
                                        return -0.018760407826;
                                    } else {
                                        return -0.00788581937775;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.00962035260281;
                                    } else {
                                        return -0.00290779736061;
                                    }
                                }
                            } else {
                                return -0.00398051872707;
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                return -0.0664810450073;
                            } else {
                                if (fs[4] <= 29.5) {
                                    return -0.0144801412487;
                                } else {
                                    return -0.0196510870261;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[54] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[40] <= 0.5) {
                        if (fs[37] <= 0.5) {
                            if (fs[50] <= -1498.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 36.5) {
                                        return 0.0673492365349;
                                    } else {
                                        return -0.0683019596991;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0447051412859;
                                    } else {
                                        return -0.048358696063;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.0190401998772;
                                    } else {
                                        return -0.19642822994;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0101872554646;
                                    } else {
                                        return -0.010210802856;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[4] <= 29.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.00834109374349;
                                    } else {
                                        return 0.0488058894849;
                                    }
                                } else {
                                    return -0.503406624165;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0217386038825;
                                    } else {
                                        return 0.168758013087;
                                    }
                                } else {
                                    if (fs[4] <= 18.0) {
                                        return 0.154317502693;
                                    } else {
                                        return -0.260245875107;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[91] <= 0.5) {
                                        return -0.0797314405948;
                                    } else {
                                        return 0.287379031727;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.128576519757;
                                    } else {
                                        return 0.0296111534702;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0117739311098;
                                    } else {
                                        return -0.160182669336;
                                    }
                                } else {
                                    return -0.245813015576;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1543.0) {
                                    return -0.382455000143;
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.12846434198;
                                    } else {
                                        return -0.0476116009489;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[50] <= -456.5) {
                                        return -0.0287261407865;
                                    } else {
                                        return -0.112109985687;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.108118453363;
                                    } else {
                                        return 0.134647581608;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[67] <= -1.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.000429162921186;
                                    } else {
                                        return -0.00263575323355;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.000954906487079;
                                    } else {
                                        return 0.00209163603807;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.000206702110788;
                                    } else {
                                        return 0.0227877489352;
                                    }
                                } else {
                                    if (fs[2] <= 18.5) {
                                        return -0.000761977740703;
                                    } else {
                                        return -0.0987814157558;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1242.5) {
                                if (fs[69] <= 9989.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.128905813978;
                                    } else {
                                        return -0.0241786415126;
                                    }
                                } else {
                                    return 0.25827620726;
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    return 0.127789848878;
                                } else {
                                    if (fs[0] <= 15.5) {
                                        return -0.0199676165942;
                                    } else {
                                        return 0.000828322626387;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9969.0) {
                            if (fs[65] <= 1.5) {
                                if (fs[91] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.00586153222885;
                                    } else {
                                        return 0.0115758188096;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0486514499098;
                                    } else {
                                        return -0.0160697444209;
                                    }
                                }
                            } else {
                                return 0.121725411733;
                            }
                        } else {
                            if (fs[50] <= -1042.0) {
                                if (fs[2] <= 1.5) {
                                    return -0.0790210221567;
                                } else {
                                    return -0.108255739291;
                                }
                            } else {
                                if (fs[63] <= 5.0) {
                                    return -0.043057822478;
                                } else {
                                    return -0.0797877865777;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[18] <= 0.5) {
                    if (fs[69] <= 9989.5) {
                        if (fs[46] <= -2.5) {
                            return 0.0691122019526;
                        } else {
                            if (fs[50] <= -932.5) {
                                if (fs[4] <= 7.5) {
                                    return 0.0214590807996;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.190743616072;
                                    } else {
                                        return -0.0531006093057;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0424600212264;
                                    } else {
                                        return -0.0419033072751;
                                    }
                                } else {
                                    return 0.106236908211;
                                }
                            }
                        }
                    } else {
                        return -0.258079214971;
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.057731260364;
                                    } else {
                                        return 0.137723489457;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.048476097775;
                                    } else {
                                        return -0.0816144792186;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[2] <= 5.5) {
                                        return 0.187284402859;
                                    } else {
                                        return -0.0575179338119;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.000966716482042;
                                    } else {
                                        return 0.180083691488;
                                    }
                                }
                            }
                        } else {
                            return -0.125774526788;
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[11] <= 0.5) {
                                    return -0.0265679878075;
                                } else {
                                    return -0.0172207177797;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[50] <= -477.0) {
                                        return -0.00590515507433;
                                    } else {
                                        return -0.00300898557721;
                                    }
                                } else {
                                    return -0.0231297095319;
                                }
                            }
                        } else {
                            return -0.0337565970606;
                        }
                    }
                }
            }
        }
    }
}
