/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree11 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[97] <= 1.5) {
                if (fs[79] <= 0.5) {
                    if (fs[34] <= 0.5) {
                        if (fs[50] <= -1083.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.454694093776;
                                    } else {
                                        return 0.271101209508;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.000700160235425;
                                    } else {
                                        return 0.292585931968;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0555801146166;
                                    } else {
                                        return 0.00853609249651;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.0298054653065;
                                    } else {
                                        return -0.0231810950733;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.137654839843;
                                    } else {
                                        return -0.00823508110549;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return 0.460191212056;
                                    } else {
                                        return 0.0548108270813;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.234102298832;
                                    } else {
                                        return 0.373721582032;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0289255371448;
                                    } else {
                                        return -0.0149213917582;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1084.0) {
                            if (fs[50] <= -1138.0) {
                                if (fs[15] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.476441741939;
                                    } else {
                                        return 0.543240767018;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.52929587408;
                                    } else {
                                        return 0.541347208876;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.548755688802;
                                    } else {
                                        return 0.505251130327;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.542782651998;
                                    } else {
                                        return 0.537971167535;
                                    }
                                }
                            }
                        } else {
                            return -0.0375874815064;
                        }
                    }
                } else {
                    if (fs[91] <= 0.5) {
                        if (fs[69] <= 9819.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0281394172637;
                                    } else {
                                        return 0.135579065885;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.424336737978;
                                    } else {
                                        return 0.280703134626;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[95] <= 1.5) {
                                        return -0.0331385220253;
                                    } else {
                                        return -0.0270167662431;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return -0.0232622075509;
                                    } else {
                                        return 0.0862696724557;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[50] <= -1238.0) {
                                        return 0.118893531696;
                                    } else {
                                        return -0.00256888949887;
                                    }
                                } else {
                                    if (fs[50] <= -1653.5) {
                                        return 0.241567298149;
                                    } else {
                                        return -0.00878944796535;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.142048859256;
                                    } else {
                                        return 0.261993988809;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0594582220984;
                                    } else {
                                        return -0.0360024859306;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.357343457523;
                                    } else {
                                        return 0.523029460435;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.553831818775;
                                    } else {
                                        return 0.488227135854;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.0862845112178;
                                    } else {
                                        return 0.503478931066;
                                    }
                                } else {
                                    if (fs[69] <= 9983.0) {
                                        return 0.592979037764;
                                    } else {
                                        return 0.116808652012;
                                    }
                                }
                            }
                        } else {
                            if (fs[86] <= 0.5) {
                                if (fs[69] <= 4688.0) {
                                    if (fs[44] <= 0.5) {
                                        return 0.143096251467;
                                    } else {
                                        return -0.031432558203;
                                    }
                                } else {
                                    if (fs[18] <= -0.5) {
                                        return -0.0588875971406;
                                    } else {
                                        return 0.063564764027;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[69] <= 9986.5) {
                                        return -0.0301733838822;
                                    } else {
                                        return 0.0369847360854;
                                    }
                                } else {
                                    if (fs[50] <= -1423.0) {
                                        return 0.0588563352222;
                                    } else {
                                        return -0.0307463647118;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[33] <= 0.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.482911702585;
                                    } else {
                                        return 0.521598993227;
                                    }
                                } else {
                                    if (fs[46] <= -0.5) {
                                        return 0.577614786471;
                                    } else {
                                        return 0.310098014716;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.169884821287;
                                    } else {
                                        return 0.365611594335;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.181598967737;
                                    } else {
                                        return 0.0615034366713;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.559006372728;
                                    } else {
                                        return 0.344468448718;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.530345974213;
                                    } else {
                                        return 0.45347995492;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[50] <= -986.0) {
                                        return 0.481232553975;
                                    } else {
                                        return 0.13827496761;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.281377882964;
                                    } else {
                                        return 0.144647206446;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0214036271256;
                                    } else {
                                        return 0.1981575456;
                                    }
                                } else {
                                    return 0.155896738647;
                                }
                            } else {
                                return -0.165137853561;
                            }
                        } else {
                            if (fs[4] <= 18.0) {
                                if (fs[11] <= 0.5) {
                                    return 0.411031226174;
                                } else {
                                    return 0.245096994666;
                                }
                            } else {
                                return 0.110272665114;
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1068.0) {
                        if (fs[33] <= 0.5) {
                            if (fs[0] <= 13.5) {
                                if (fs[50] <= -1133.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.306082382568;
                                    } else {
                                        return 0.100224293992;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.285844302599;
                                    } else {
                                        return 0.133574606492;
                                    }
                                }
                            } else {
                                if (fs[61] <= -498.0) {
                                    return 0.785555348166;
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.30777931781;
                                    } else {
                                        return 0.569723350884;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 24.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0695278542825;
                                    } else {
                                        return -0.0472071807769;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0602553925777;
                                    } else {
                                        return -0.0898616438623;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0384844890131;
                                    } else {
                                        return 0.00164755747062;
                                    }
                                } else {
                                    return 0.194292140294;
                                }
                            }
                        }
                    } else {
                        if (fs[13] <= 0.5) {
                            if (fs[4] <= 25.5) {
                                if (fs[46] <= -1.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.146797432043;
                                    } else {
                                        return -0.023632602815;
                                    }
                                } else {
                                    if (fs[50] <= -992.5) {
                                        return 0.0125554992976;
                                    } else {
                                        return -0.0335784842587;
                                    }
                                }
                            } else {
                                if (fs[61] <= -994.5) {
                                    return 0.130548900228;
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0314396043799;
                                    } else {
                                        return -0.00575754104893;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 12.5) {
                                return 0.0654689013911;
                            } else {
                                if (fs[18] <= 0.5) {
                                    return -0.0679453538111;
                                } else {
                                    return -0.0431279350115;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[33] <= 0.5) {
                    if (fs[18] <= -0.5) {
                        if (fs[4] <= 15.5) {
                            return -0.20579775051;
                        } else {
                            return 0.0312531565143;
                        }
                    } else {
                        if (fs[86] <= 0.5) {
                            if (fs[4] <= 26.0) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.380498135153;
                                    } else {
                                        return 0.530372173087;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.543506987077;
                                    } else {
                                        return 0.594316409978;
                                    }
                                }
                            } else {
                                return 0.0674357261808;
                            }
                        } else {
                            if (fs[6] <= 0.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.216400633233;
                                    } else {
                                        return 0.611077827791;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.14180118923;
                                    } else {
                                        return 0.364132422115;
                                    }
                                }
                            } else {
                                if (fs[42] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.357090206494;
                                    } else {
                                        return 0.479151742077;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.147537434416;
                                    } else {
                                        return -0.153022136297;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[67] <= -3.5) {
                            if (fs[82] <= 5.0) {
                                if (fs[50] <= -1513.0) {
                                    return 0.576071013838;
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.484076842395;
                                    } else {
                                        return 0.285479988497;
                                    }
                                }
                            } else {
                                if (fs[50] <= -551.5) {
                                    return 0.592818659028;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.48523196895;
                                    } else {
                                        return 0.464402744798;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.42495752251;
                                    } else {
                                        return 0.322280891086;
                                    }
                                } else {
                                    if (fs[50] <= -1598.0) {
                                        return 0.460604358336;
                                    } else {
                                        return 0.21421604554;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.656523296157;
                                    } else {
                                        return 0.443906115792;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.299176889671;
                                    } else {
                                        return 0.144660666349;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.410560926398;
                                    } else {
                                        return 0.520836515521;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.542035945299;
                                    } else {
                                        return 0.472934845922;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.540688539133;
                                    } else {
                                        return 0.347049822599;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.317952788614;
                                    } else {
                                        return 0.470254703603;
                                    }
                                }
                            }
                        } else {
                            if (fs[46] <= -0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.579492509516;
                                    } else {
                                        return 0.428556172715;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.591547089099;
                                    } else {
                                        return 0.505548064907;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.225851523974;
                                    } else {
                                        return 0.363672667789;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.483786589695;
                                    } else {
                                        return 0.282722346409;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1277.5) {
                    if (fs[4] <= 17.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[69] <= 9998.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0770544682578;
                                    } else {
                                        return 0.208211901885;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.0890561431896;
                                    } else {
                                        return 0.204882540059;
                                    }
                                }
                            } else {
                                if (fs[63] <= 5.0) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.277027907529;
                                    } else {
                                        return 0.413328539734;
                                    }
                                } else {
                                    return -0.107158409556;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                return 0.160621556091;
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0808764567303;
                                    } else {
                                        return 0.0254080171831;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return -0.1370934292;
                                    } else {
                                        return -0.0772646831294;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 496.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[73] <= 150.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00682258086016;
                                    } else {
                                        return 0.128761609727;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0104524187747;
                                    } else {
                                        return -0.102519677911;
                                    }
                                }
                            } else {
                                if (fs[4] <= 20.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0983407295906;
                                    } else {
                                        return 0.194490038951;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.384222662126;
                                    } else {
                                        return 0.0446886357903;
                                    }
                                }
                            }
                        } else {
                            return 0.666586948026;
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[78] <= 0.5) {
                                        return 0.275446913102;
                                    } else {
                                        return 0.0900137364159;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0140282634794;
                                    } else {
                                        return 0.0681460552755;
                                    }
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0649935239751;
                                    } else {
                                        return 0.0075309761296;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return 0.27316231118;
                                    } else {
                                        return 0.0214863078874;
                                    }
                                }
                            }
                        } else {
                            if (fs[98] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0840256913463;
                                    } else {
                                        return 0.186261662399;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.0899794395595;
                                    } else {
                                        return 0.00806493102342;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    return 0.673041020783;
                                } else {
                                    return 0.423787714961;
                                }
                            }
                        }
                    } else {
                        if (fs[65] <= 1.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[2] <= 8.5) {
                                    if (fs[4] <= 19.5) {
                                        return -0.036177558109;
                                    } else {
                                        return -0.0271009213829;
                                    }
                                } else {
                                    return 0.0575285276602;
                                }
                            } else {
                                if (fs[50] <= 13.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0509064069197;
                                    } else {
                                        return -0.0158693481868;
                                    }
                                } else {
                                    return 0.0981226378827;
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                return 0.098278315139;
                            } else {
                                if (fs[0] <= 21.5) {
                                    return 0.0494381646911;
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0345228783491;
                                    } else {
                                        return -0.0365300281658;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
