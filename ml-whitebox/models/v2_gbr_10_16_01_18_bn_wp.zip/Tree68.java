/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree68 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 3.5) {
                if (fs[50] <= -1498.5) {
                    if (fs[4] <= 17.5) {
                        if (fs[61] <= -996.5) {
                            if (fs[59] <= -1.5) {
                                return -0.057993021127;
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0166001397616;
                                    } else {
                                        return 0.108214248624;
                                    }
                                } else {
                                    return -0.288142035616;
                                }
                            }
                        } else {
                            if (fs[50] <= -1953.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0961716867311;
                                    } else {
                                        return 0.267455114785;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0913773647905;
                                    } else {
                                        return 0.0838126692199;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.133359962321;
                                    } else {
                                        return 0.0518171127677;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.118607714801;
                                    } else {
                                        return 0.173085882725;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[67] <= -1.5) {
                            if (fs[50] <= -2008.0) {
                                if (fs[73] <= 75.0) {
                                    if (fs[50] <= -2048.0) {
                                        return 0.103034947011;
                                    } else {
                                        return 0.217284606157;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return -0.155658021949;
                                    } else {
                                        return 0.118313552463;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[50] <= -1588.0) {
                                        return -0.00502863732104;
                                    } else {
                                        return 0.168048866721;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return 0.205825190284;
                                    } else {
                                        return -0.0903086317113;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1558.0) {
                                if (fs[95] <= 0.5) {
                                    return -0.11682423694;
                                } else {
                                    return 0.0269887098764;
                                }
                            } else {
                                if (fs[4] <= 23.5) {
                                    return -0.19104146114;
                                } else {
                                    return -0.133143019584;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 9.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[96] <= 0.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.0317287918793;
                                    } else {
                                        return 0.0699110816148;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return 0.148688185272;
                                    } else {
                                        return 0.0717655931529;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.0124818237647;
                                    } else {
                                        return 0.0646976782703;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0398619329709;
                                    } else {
                                        return 0.135241581683;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1133.5) {
                                if (fs[69] <= 9902.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0485784132264;
                                    } else {
                                        return -0.244016237837;
                                    }
                                } else {
                                    return 0.0292276378809;
                                }
                            } else {
                                if (fs[69] <= 4968.5) {
                                    if (fs[50] <= -1118.5) {
                                        return -0.0468426624236;
                                    } else {
                                        return 0.206136119974;
                                    }
                                } else {
                                    if (fs[69] <= 9991.0) {
                                        return 0.181647760992;
                                    } else {
                                        return 0.058210983332;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[46] <= -0.5) {
                            if (fs[46] <= -3.5) {
                                return -0.100391366921;
                            } else {
                                if (fs[4] <= 28.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.0812442065601;
                                    } else {
                                        return 0.0353759799058;
                                    }
                                } else {
                                    return -0.244809409449;
                                }
                            }
                        } else {
                            if (fs[73] <= 250.0) {
                                if (fs[85] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.00423394098069;
                                    } else {
                                        return -0.0420057713726;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.0608940572634;
                                    } else {
                                        return -0.225247111454;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[77] <= 0.5) {
                                        return -0.00142158887489;
                                    } else {
                                        return -0.0721755105694;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0133546977878;
                                    } else {
                                        return 0.0529658046514;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 14.5) {
                    if (fs[4] <= 13.5) {
                        if (fs[2] <= 6.5) {
                            if (fs[8] <= 0.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0412677893368;
                                    } else {
                                        return 0.0164465509495;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.191076959364;
                                    } else {
                                        return 0.102007020519;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    return -0.321110129488;
                                } else {
                                    return -0.157838769994;
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[2] <= 8.5) {
                                        return 0.0441366307225;
                                    } else {
                                        return -0.00847380864326;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.129090080149;
                                    } else {
                                        return 0.0246831141009;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0286808631776;
                                    } else {
                                        return 0.1398024706;
                                    }
                                } else {
                                    return 0.312356912337;
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                return 0.0397117105926;
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0569054380179;
                                    } else {
                                        return 0.226299268886;
                                    }
                                } else {
                                    return 0.0690595234263;
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[68] <= 0.5) {
                                    return 0.125266772917;
                                } else {
                                    if (fs[50] <= -495.5) {
                                        return 0.0832966619594;
                                    } else {
                                        return -0.0875021595417;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0683362135823;
                                    } else {
                                        return 0.174317485926;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0888971820273;
                                    } else {
                                        return 0.0810475272644;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 11.5) {
                        if (fs[77] <= 0.5) {
                            if (fs[50] <= -1733.0) {
                                if (fs[12] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.0614452509078;
                                    } else {
                                        return 0.155333335305;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0288241468239;
                                    } else {
                                        return -0.288019089582;
                                    }
                                }
                            } else {
                                if (fs[82] <= -0.5) {
                                    return -0.269726044831;
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return 0.000595261723428;
                                    } else {
                                        return 0.0516647959849;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9998.0) {
                                if (fs[4] <= 15.5) {
                                    return 0.0499438427776;
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.288164957204;
                                    } else {
                                        return -0.196027499017;
                                    }
                                }
                            } else {
                                return 0.124710376579;
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.347055984108;
                                    } else {
                                        return 0.134395404926;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.160212111705;
                                    } else {
                                        return 0.0176741109551;
                                    }
                                }
                            } else {
                                if (fs[4] <= 24.5) {
                                    if (fs[69] <= 9984.5) {
                                        return 0.128113746108;
                                    } else {
                                        return -0.0683326837842;
                                    }
                                } else {
                                    return -0.264296330921;
                                }
                            }
                        } else {
                            return 0.319720601077;
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[11] <= 0.5) {
                    if (fs[50] <= -1478.5) {
                        if (fs[33] <= 0.5) {
                            if (fs[63] <= 5.0) {
                                if (fs[73] <= 25.0) {
                                    if (fs[28] <= 0.5) {
                                        return -0.0302256647791;
                                    } else {
                                        return 0.104275082552;
                                    }
                                } else {
                                    if (fs[64] <= 0.5) {
                                        return 0.0674597185611;
                                    } else {
                                        return -0.115128306967;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    return -0.0915556218147;
                                } else {
                                    return -0.21642748108;
                                }
                            }
                        } else {
                            if (fs[50] <= -1508.0) {
                                if (fs[50] <= -2498.0) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0938640363901;
                                    } else {
                                        return 0.246358581132;
                                    }
                                } else {
                                    if (fs[82] <= 3.0) {
                                        return -0.00890288651408;
                                    } else {
                                        return 0.308779907385;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.261901606273;
                                    } else {
                                        return 0.150208833904;
                                    }
                                } else {
                                    return -0.201338565716;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[82] <= 3.0) {
                                    if (fs[73] <= 350.0) {
                                        return -0.023592998604;
                                    } else {
                                        return -0.146785925922;
                                    }
                                } else {
                                    if (fs[50] <= -1138.5) {
                                        return 0.152364903467;
                                    } else {
                                        return 0.0371668403751;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[50] <= -983.0) {
                                        return 0.100694214741;
                                    } else {
                                        return -0.0283031088014;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.0472818329971;
                                    } else {
                                        return -0.0764527500613;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[50] <= -942.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.072722160282;
                                    } else {
                                        return -0.0132727916699;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.0999263978707;
                                    } else {
                                        return 0.00636536435112;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1273.0) {
                                    return 0.288515498564;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.010419516423;
                                    } else {
                                        return 0.0664310011876;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[49] <= 0.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[48] <= 0.5) {
                                if (fs[59] <= -0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0156181122145;
                                    } else {
                                        return -0.0725418794544;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return -0.0542325961614;
                                    } else {
                                        return -0.0128425320123;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[73] <= 350.0) {
                                        return 0.0890291908168;
                                    } else {
                                        return 0.1731271003;
                                    }
                                } else {
                                    return 0.00494468754503;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0395585614018;
                                    } else {
                                        return -0.011216254999;
                                    }
                                } else {
                                    return 0.223227197716;
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[69] <= 9996.5) {
                                        return 0.0259748753959;
                                    } else {
                                        return 0.170896840565;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return -0.0167252892236;
                                    } else {
                                        return 0.0312652169644;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 24.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.00810237284895;
                                    } else {
                                        return 0.111822112264;
                                    }
                                } else {
                                    if (fs[69] <= 9985.5) {
                                        return -0.00739287073538;
                                    } else {
                                        return 0.0163366819695;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[69] <= 9997.5) {
                                        return -0.0280591845546;
                                    } else {
                                        return 0.0648639835129;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.0609818605073;
                                    } else {
                                        return -0.0196914740765;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0158323382638;
                                    } else {
                                        return 0.0447110134878;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0780341759243;
                                    } else {
                                        return -0.143733325572;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.180385809408;
                                    } else {
                                        return 0.0653703744864;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.40921213844;
                                    } else {
                                        return 0.0153440878682;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[54] <= 0.5) {
                    if (fs[4] <= 25.5) {
                        if (fs[0] <= 7.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[50] <= -2468.0) {
                                        return 0.0922876266488;
                                    } else {
                                        return 0.00339512525105;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.00747278982964;
                                    } else {
                                        return 0.0344989259458;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.00633506291441;
                                    } else {
                                        return 3.75874806651e-05;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.00771511937823;
                                    } else {
                                        return -0.00209470297558;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 1.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.00184471887688;
                                    } else {
                                        return -0.00397618798007;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.024293659986;
                                    } else {
                                        return -0.00843621212701;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1072.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.215048766535;
                                    } else {
                                        return 0.0139755998961;
                                    }
                                } else {
                                    if (fs[50] <= 3.5) {
                                        return -0.00553183965233;
                                    } else {
                                        return -0.00147521653663;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[69] <= 9977.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.00759227427223;
                                    } else {
                                        return 0.10246649907;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0426697484458;
                                    } else {
                                        return 0.00189564092761;
                                    }
                                }
                            } else {
                                if (fs[4] <= 35.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0106577511693;
                                    } else {
                                        return -0.0500770539178;
                                    }
                                } else {
                                    if (fs[4] <= 37.0) {
                                        return -0.182772019373;
                                    } else {
                                        return -0.0391514805649;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -4043.0) {
                                return 0.0627518616589;
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[77] <= 0.5) {
                                        return -0.00319810695882;
                                    } else {
                                        return -0.0176099405434;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.00770263122185;
                                    } else {
                                        return 0.118303490132;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9998.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[82] <= 7.5) {
                                if (fs[4] <= 3.5) {
                                    return -0.106735040523;
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0451161938767;
                                    } else {
                                        return -0.01145221175;
                                    }
                                }
                            } else {
                                return 0.339093226044;
                            }
                        } else {
                            return 0.169601131164;
                        }
                    } else {
                        return 0.182730905652;
                    }
                }
            }
        }
    }
}
