/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree80 {
    public double calcTree(double... fs) {
        if (fs[54] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 18.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.0128854991356;
                                    } else {
                                        return 0.0300769719816;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.000100833348727;
                                    } else {
                                        return 0.0446525621617;
                                    }
                                }
                            } else {
                                if (fs[82] <= 4.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.0243171772517;
                                    } else {
                                        return 0.0496894577051;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.019079009849;
                                    } else {
                                        return -0.069037795913;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0366944707452;
                                    } else {
                                        return 0.195266517307;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0169704005278;
                                    } else {
                                        return -0.13232469582;
                                    }
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return -0.162018946054;
                                    } else {
                                        return -0.0365583592731;
                                    }
                                } else {
                                    return -0.297553961346;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -546.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[69] <= 9954.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.118628399671;
                                    } else {
                                        return 0.186405367519;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0423594532462;
                                    } else {
                                        return 0.106947702157;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[69] <= 9982.5) {
                                        return 0.26961260855;
                                    } else {
                                        return 0.145352901663;
                                    }
                                } else {
                                    return 0.0454410633003;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0289222222841;
                                    } else {
                                        return 0.109109928653;
                                    }
                                } else {
                                    return -0.0797591649489;
                                }
                            } else {
                                return 0.246428228782;
                            }
                        }
                    }
                } else {
                    if (fs[96] <= 0.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[4] <= 30.5) {
                                if (fs[50] <= -1378.0) {
                                    if (fs[37] <= 0.5) {
                                        return -0.0284380004936;
                                    } else {
                                        return 0.0794857505721;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return 0.121517591003;
                                    } else {
                                        return -0.0923101879511;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.145278563066;
                                    } else {
                                        return -0.291961949627;
                                    }
                                } else {
                                    return -0.319453821599;
                                }
                            }
                        } else {
                            if (fs[50] <= -1478.0) {
                                if (fs[50] <= -2008.0) {
                                    if (fs[4] <= 44.0) {
                                        return 0.0842295086444;
                                    } else {
                                        return -0.26224005549;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.085065423149;
                                    } else {
                                        return -0.0206839577672;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[59] <= -3.5) {
                                        return -0.185362387962;
                                    } else {
                                        return 0.0188873232283;
                                    }
                                } else {
                                    return 0.302532725812;
                                }
                            }
                        }
                    } else {
                        if (fs[39] <= 0.5) {
                            if (fs[50] <= -991.0) {
                                if (fs[22] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0236844960181;
                                    } else {
                                        return -0.185175399374;
                                    }
                                } else {
                                    if (fs[50] <= -1518.0) {
                                        return 0.103510326536;
                                    } else {
                                        return 0.0470415324789;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[69] <= 9994.5) {
                                        return 0.0454321353749;
                                    } else {
                                        return 0.0116589102834;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.306408604508;
                                    } else {
                                        return 0.167004190569;
                                    }
                                }
                            }
                        } else {
                            return -0.264027175887;
                        }
                    }
                }
            } else {
                if (fs[69] <= 9999.5) {
                    if (fs[34] <= 0.5) {
                        if (fs[4] <= 25.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.00216920631523;
                                    } else {
                                        return 0.0044244078401;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.0008225028461;
                                    } else {
                                        return 0.0410328657146;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[75] <= 0.5) {
                                        return -0.0362597300094;
                                    } else {
                                        return -0.00469480451319;
                                    }
                                } else {
                                    if (fs[2] <= 11.5) {
                                        return -0.00184250800955;
                                    } else {
                                        return 0.082030793192;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[42] <= 0.5) {
                                    if (fs[50] <= -3443.0) {
                                        return 0.17823514887;
                                    } else {
                                        return -0.0136689259706;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.0638759642075;
                                    } else {
                                        return 0.327447902705;
                                    }
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    if (fs[42] <= 0.5) {
                                        return -0.00207346284731;
                                    } else {
                                        return 0.0119303568269;
                                    }
                                } else {
                                    if (fs[50] <= -1468.0) {
                                        return -0.0406971844468;
                                    } else {
                                        return -0.00250035655092;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.120479753282;
                    }
                } else {
                    if (fs[63] <= 5.0) {
                        if (fs[8] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.27801454126;
                                    } else {
                                        return 0.0259955434856;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.00869877668792;
                                    } else {
                                        return 0.0821405886498;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1478.0) {
                                    if (fs[93] <= 0.5) {
                                        return -0.302621782978;
                                    } else {
                                        return -0.22874938292;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.108134173928;
                                    } else {
                                        return -0.0898588973475;
                                    }
                                }
                            }
                        } else {
                            return -0.193493335285;
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            return -0.207896470357;
                        } else {
                            return -0.206421763961;
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[46] <= -0.5) {
                    if (fs[95] <= 0.5) {
                        return -0.173764127262;
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[61] <= -997.5) {
                                return 0.14464669731;
                            } else {
                                return 0.0879813189288;
                            }
                        } else {
                            if (fs[39] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    return 0.115208522169;
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0783683141669;
                                    } else {
                                        return 0.0757467103422;
                                    }
                                }
                            } else {
                                return -0.0162337824765;
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        return -0.0321498446435;
                    } else {
                        if (fs[73] <= 250.0) {
                            if (fs[99] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.187166460134;
                                    } else {
                                        return -0.126793032422;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.319076249116;
                                    } else {
                                        return 0.196790368644;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.151469990377;
                                    } else {
                                        return 0.0351063929754;
                                    }
                                } else {
                                    return 0.221354232838;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 10.5) {
                                    return 0.0369149533871;
                                } else {
                                    return 0.0689521051645;
                                }
                            } else {
                                return 0.179710064806;
                            }
                        }
                    }
                }
            } else {
                if (fs[82] <= 7.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[73] <= 100.0) {
                                if (fs[0] <= 1.5) {
                                    return 0.12909603195;
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0966133020705;
                                    } else {
                                        return 0.00219542124526;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.0) {
                                    return 0.0612684762535;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.143203589805;
                                    } else {
                                        return 0.350067501577;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return -0.0270883767956;
                            } else {
                                return -0.0296142519004;
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                return 0.0760838422081;
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[50] <= -1128.0) {
                                        return -0.138835767623;
                                    } else {
                                        return -0.0453852744206;
                                    }
                                } else {
                                    if (fs[0] <= 16.5) {
                                        return -0.0134857498776;
                                    } else {
                                        return -0.00378689532419;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[73] <= 100.0) {
                                    return -0.0520089804791;
                                } else {
                                    return -0.128383249729;
                                }
                            } else {
                                if (fs[82] <= 3.0) {
                                    if (fs[0] <= 2.5) {
                                        return 0.113140810898;
                                    } else {
                                        return 0.00430804264352;
                                    }
                                } else {
                                    return 0.135227234092;
                                }
                            }
                        }
                    }
                } else {
                    return 0.190205764248;
                }
            }
        }
    }
}
