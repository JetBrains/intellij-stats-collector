/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree67 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9985.5) {
            if (fs[0] <= 0.5) {
                if (fs[25] <= 0.5) {
                    if (fs[50] <= -977.0) {
                        if (fs[2] <= 3.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[86] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.080024492282;
                                    } else {
                                        return 0.214246523494;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.0253925204776;
                                    } else {
                                        return 0.201004967504;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.00146139316523;
                                    } else {
                                        return -0.0396127580621;
                                    }
                                } else {
                                    if (fs[50] <= -1123.5) {
                                        return -0.164164190265;
                                    } else {
                                        return 0.246461710047;
                                    }
                                }
                            }
                        } else {
                            if (fs[29] <= 0.5) {
                                if (fs[50] <= -1888.0) {
                                    if (fs[95] <= 1.5) {
                                        return 0.21590690194;
                                    } else {
                                        return 0.0756366086316;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0684106235257;
                                    } else {
                                        return 0.0401450504321;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0536707238973;
                                    } else {
                                        return -0.323568052583;
                                    }
                                } else {
                                    return -0.23366606045;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.1021412837;
                                    } else {
                                        return 0.163251018687;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.365106146868;
                                    } else {
                                        return 0.114114272247;
                                    }
                                }
                            } else {
                                if (fs[59] <= -0.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.116825368263;
                                    } else {
                                        return 0.0366822891062;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.00278835546781;
                                    } else {
                                        return -0.0552158075568;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[82] <= 3.5) {
                                        return 0.0795477025066;
                                    } else {
                                        return 0.161999576548;
                                    }
                                } else {
                                    return -0.170229556042;
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0908154590546;
                                    } else {
                                        return -0.00236875159086;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0392839795389;
                                    } else {
                                        return 0.119831486215;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[73] <= 25.0) {
                        if (fs[93] <= 0.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[69] <= 9848.5) {
                                    if (fs[2] <= 10.5) {
                                        return -0.0938506862643;
                                    } else {
                                        return 0.15811477076;
                                    }
                                } else {
                                    if (fs[69] <= 9864.5) {
                                        return 0.385898577699;
                                    } else {
                                        return 0.0253008883679;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[50] <= -1698.5) {
                                        return 0.194588454917;
                                    } else {
                                        return -0.0315389686262;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return 0.0462764560407;
                                    } else {
                                        return 0.275414934279;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0213168174083;
                                    } else {
                                        return 0.201166983432;
                                    }
                                } else {
                                    if (fs[69] <= 9868.0) {
                                        return -0.149022902002;
                                    } else {
                                        return 0.0975699599737;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1458.5) {
                                    if (fs[69] <= 9321.5) {
                                        return 0.231196342279;
                                    } else {
                                        return -0.0791905567562;
                                    }
                                } else {
                                    if (fs[4] <= 17.0) {
                                        return 0.0303149906609;
                                    } else {
                                        return -0.164486352122;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[69] <= 9438.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0864948079908;
                                    } else {
                                        return 0.00174169004621;
                                    }
                                } else {
                                    if (fs[50] <= -1493.5) {
                                        return 0.279330687836;
                                    } else {
                                        return -0.0676100013621;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[50] <= -1463.5) {
                                        return -0.0633723184129;
                                    } else {
                                        return 0.0670459962989;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.061858307698;
                                    } else {
                                        return 0.0723017038394;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9984.5) {
                                if (fs[42] <= 0.5) {
                                    if (fs[2] <= 8.5) {
                                        return 0.047874206667;
                                    } else {
                                        return 0.113559123978;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0887157923681;
                                    } else {
                                        return 0.000129153665362;
                                    }
                                }
                            } else {
                                return -0.369624811129;
                            }
                        }
                    }
                }
            } else {
                if (fs[84] <= 0.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[75] <= 0.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[50] <= -1068.0) {
                                        return 0.200900850303;
                                    } else {
                                        return -0.138380498109;
                                    }
                                } else {
                                    return -0.110036316494;
                                }
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.012861984773;
                                    } else {
                                        return -0.00847316243159;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.138675326658;
                                    } else {
                                        return 0.132337633461;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[82] <= 5.5) {
                                        return -0.002187862152;
                                    } else {
                                        return -0.00545603713332;
                                    }
                                } else {
                                    if (fs[50] <= -1368.0) {
                                        return 0.0113370030821;
                                    } else {
                                        return -0.00242595566482;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.000240178970937;
                                    } else {
                                        return -0.00387168924064;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.00218742470745;
                                    } else {
                                        return 0.0204990874325;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0543101441239;
                                    } else {
                                        return -0.0310394734839;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0518207130602;
                                    } else {
                                        return -0.0412191239424;
                                    }
                                }
                            } else {
                                return -0.0918795973357;
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    return -0.0145104591611;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00563979649433;
                                    } else {
                                        return -0.00348094223717;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return -0.0222877499688;
                                } else {
                                    if (fs[50] <= -978.0) {
                                        return -0.0160652031544;
                                    } else {
                                        return -0.00665764106293;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1302.5) {
                        if (fs[91] <= 0.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.130325773746;
                                    } else {
                                        return 0.0305182226218;
                                    }
                                } else {
                                    if (fs[50] <= -1958.0) {
                                        return 0.181432708027;
                                    } else {
                                        return 0.0536670694665;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[4] <= 37.5) {
                                        return 0.00243816315096;
                                    } else {
                                        return 0.133622192365;
                                    }
                                } else {
                                    if (fs[73] <= 150.0) {
                                        return 0.050043313755;
                                    } else {
                                        return 0.266782968252;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9939.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.0177420239415;
                                    } else {
                                        return -0.0412123981516;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.226042145099;
                                    } else {
                                        return 0.0797931436211;
                                    }
                                }
                            } else {
                                if (fs[87] <= 0.5) {
                                    if (fs[4] <= 15.0) {
                                        return -0.0110727850858;
                                    } else {
                                        return -0.102505218906;
                                    }
                                } else {
                                    return -0.111493689202;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[73] <= 250.0) {
                                if (fs[2] <= 3.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.051961291559;
                                    } else {
                                        return 0.0240709581948;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.102338621311;
                                    } else {
                                        return 0.0856215246593;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.0134618026361;
                                    } else {
                                        return 0.230039031893;
                                    }
                                } else {
                                    if (fs[2] <= 9.5) {
                                        return -0.0204086366612;
                                    } else {
                                        return 0.126554603042;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.0402899122795;
                                    } else {
                                        return -0.00389369141548;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.128923512173;
                                    } else {
                                        return 0.00547806816365;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1142.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.010914235739;
                                    } else {
                                        return 0.123622327673;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.00216189702106;
                                    } else {
                                        return -0.00248172556835;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[2] <= 2.5) {
                if (fs[4] <= 4.5) {
                    if (fs[67] <= -4.5) {
                        if (fs[73] <= 100.0) {
                            if (fs[50] <= -1123.5) {
                                return 0.003991917704;
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.163871240583;
                                    } else {
                                        return 0.0859595187721;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0590188470918;
                                    } else {
                                        return 0.120902634175;
                                    }
                                }
                            }
                        } else {
                            return 0.144852981262;
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.10110278906;
                                    } else {
                                        return 0.0014371490683;
                                    }
                                } else {
                                    return -0.148683444876;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0898807617346;
                                    } else {
                                        return 0.00985915627;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.00519644412981;
                                    } else {
                                        return 0.13863405088;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[62] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return -0.0746517274852;
                                    } else {
                                        return 0.0452424475046;
                                    }
                                } else {
                                    if (fs[50] <= -1138.5) {
                                        return -0.00100009506544;
                                    } else {
                                        return 0.138669246717;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0765994043121;
                                    } else {
                                        return 0.00141474977466;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0174467610342;
                                    } else {
                                        return 0.183174702644;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1403.5) {
                        if (fs[50] <= -1478.0) {
                            if (fs[37] <= 0.5) {
                                if (fs[18] <= -0.5) {
                                    return -0.184673286006;
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.0228582107687;
                                    } else {
                                        return -0.0338320995251;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[69] <= 9990.5) {
                                        return 0.294975333194;
                                    } else {
                                        return 0.090102018346;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.285519778349;
                                    } else {
                                        return 0.136153557306;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1443.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0858010974904;
                                    } else {
                                        return 0.0931888917027;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0545007314402;
                                    } else {
                                        return 0.132341979782;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1423.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.342178452963;
                                    } else {
                                        return 0.235759665781;
                                    }
                                } else {
                                    return 0.112159385855;
                                }
                            }
                        }
                    } else {
                        if (fs[46] <= -0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[82] <= 4.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0446490104404;
                                    } else {
                                        return 0.110541024557;
                                    }
                                } else {
                                    return 0.274682654705;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.0242564713339;
                                    } else {
                                        return 0.0787812064557;
                                    }
                                } else {
                                    return 0.186360548244;
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[64] <= 0.5) {
                                        return -0.00222191144182;
                                    } else {
                                        return -0.112166756695;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.187753134216;
                                    } else {
                                        return 0.0670281259906;
                                    }
                                }
                            } else {
                                return -0.0547464159624;
                            }
                        }
                    }
                }
            } else {
                if (fs[73] <= 150.0) {
                    if (fs[84] <= 0.5) {
                        if (fs[87] <= 0.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.0615340928042;
                                    } else {
                                        return 0.0319170820845;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.156343938042;
                                    } else {
                                        return -0.251598172928;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.0360399785194;
                                    } else {
                                        return -0.0407030485062;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.322799898316;
                                    } else {
                                        return 0.0479989495289;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 15.5) {
                                return -0.171257959285;
                            } else {
                                return -0.154047259064;
                            }
                        }
                    } else {
                        if (fs[65] <= 1.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[4] <= 35.5) {
                                        return 0.0425835798274;
                                    } else {
                                        return -0.113820369632;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.151547417724;
                                    } else {
                                        return 0.126981050738;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.103556370511;
                                    } else {
                                        return 0.0362909919137;
                                    }
                                } else {
                                    if (fs[69] <= 9989.5) {
                                        return 0.183861151764;
                                    } else {
                                        return -0.017315336649;
                                    }
                                }
                            }
                        } else {
                            return -0.343861612634;
                        }
                    }
                } else {
                    if (fs[4] <= 18.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[67] <= -3.5) {
                                return -0.321403140443;
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[69] <= 9996.5) {
                                        return 0.0096013386969;
                                    } else {
                                        return 0.0792599738091;
                                    }
                                } else {
                                    return -0.21179432537;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                return 0.176552295852;
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00320027462352;
                                    } else {
                                        return -0.0846800332133;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.280577165314;
                                    } else {
                                        return 0.0472305168417;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 24.5) {
                                        return -0.136491442104;
                                    } else {
                                        return -0.0195829508666;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return -0.0220665000011;
                                    } else {
                                        return 0.127719963289;
                                    }
                                }
                            } else {
                                return -0.336241591197;
                            }
                        } else {
                            if (fs[69] <= 9998.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[69] <= 9994.5) {
                                        return -0.0885140552301;
                                    } else {
                                        return -0.277242458144;
                                    }
                                } else {
                                    if (fs[69] <= 9990.5) {
                                        return 0.0770106843983;
                                    } else {
                                        return -0.0343022611923;
                                    }
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    if (fs[50] <= -1483.0) {
                                        return -0.383055943236;
                                    } else {
                                        return -0.136611466052;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.168526392888;
                                    } else {
                                        return 0.0536203788437;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
