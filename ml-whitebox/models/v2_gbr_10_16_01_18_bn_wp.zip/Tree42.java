/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree42 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 19.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[4] <= 9.5) {
                            if (fs[50] <= -1138.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0961107350014;
                                    } else {
                                        return 0.112272740623;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.00637319670776;
                                    } else {
                                        return 0.090394836298;
                                    }
                                }
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.130133806494;
                                    } else {
                                        return 0.113664533438;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.101260691981;
                                    } else {
                                        return 0.115034703392;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 12.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.279661743965;
                                    } else {
                                        return 0.205865032967;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.167085039719;
                                    } else {
                                        return 0.132126638327;
                                    }
                                }
                            } else {
                                return 0.140566377468;
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            return -0.0224476809144;
                        } else {
                            return -0.128821353085;
                        }
                    }
                } else {
                    if (fs[50] <= -1568.0) {
                        if (fs[2] <= 3.5) {
                            if (fs[4] <= 32.5) {
                                return 0.1666919663;
                            } else {
                                return -0.0817636906608;
                            }
                        } else {
                            return -0.0958472996326;
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            return -0.0770978069436;
                        } else {
                            return -0.166400143274;
                        }
                    }
                }
            } else {
                if (fs[34] <= 0.5) {
                    if (fs[4] <= 2.5) {
                        return 0.235602906193;
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.07436297319;
                                    } else {
                                        return 0.0299933143259;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.0106741015659;
                                    } else {
                                        return 0.48819586867;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0426160881848;
                                    } else {
                                        return -0.0158298790412;
                                    }
                                } else {
                                    return 0.50810506383;
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0661667408149;
                                    } else {
                                        return -0.0324764599511;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0227121780968;
                                    } else {
                                        return -0.0087121297943;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0158167300321;
                                    } else {
                                        return -0.0301198932243;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return -0.00971646154309;
                                    } else {
                                        return 0.0260240324622;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        return 0.184002337593;
                    } else {
                        return 0.291129991827;
                    }
                }
            }
        } else {
            if (fs[97] <= 1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[73] <= 25.0) {
                        if (fs[69] <= 9838.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[50] <= -1504.0) {
                                        return 0.16022867789;
                                    } else {
                                        return 0.0297124849935;
                                    }
                                } else {
                                    if (fs[82] <= 6.0) {
                                        return -0.0851312262292;
                                    } else {
                                        return 0.232985764657;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[50] <= -1273.5) {
                                        return -0.0104929078294;
                                    } else {
                                        return 0.117441956704;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return -0.340035678985;
                                    } else {
                                        return -0.00898757203965;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -948.0) {
                                if (fs[18] <= -0.5) {
                                    return -0.264959084201;
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.112853181381;
                                    } else {
                                        return 0.246837800895;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.185528117;
                                    } else {
                                        return 0.108004858173;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.029646857481;
                                    } else {
                                        return 0.0893147298421;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1598.0) {
                            if (fs[4] <= 42.0) {
                                if (fs[49] <= 0.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.224099793638;
                                    } else {
                                        return 0.133105877241;
                                    }
                                } else {
                                    if (fs[50] <= -2328.5) {
                                        return 0.276782465338;
                                    } else {
                                        return 0.192022929292;
                                    }
                                }
                            } else {
                                return -0.462965932244;
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0133150044089;
                                    } else {
                                        return 0.0906755073947;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.0975695440539;
                                    } else {
                                        return -0.108307284339;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.162445414372;
                                    } else {
                                        return 0.297283893167;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0739489191991;
                                    } else {
                                        return 0.181932129969;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[82] <= 6.5) {
                            if (fs[82] <= 5.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0126505952811;
                                    } else {
                                        return -0.00674824908633;
                                    }
                                } else {
                                    if (fs[2] <= 11.5) {
                                        return -0.0176185864012;
                                    } else {
                                        return 0.0746670096428;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.00396327016348;
                                    } else {
                                        return -0.0276740937426;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0109594714771;
                                    } else {
                                        return 0.160012271276;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[40] <= 0.5) {
                                    if (fs[54] <= 0.5) {
                                        return 0.00233333878172;
                                    } else {
                                        return 0.220055188436;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0238924786564;
                                    } else {
                                        return 0.121397195825;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0263208492202;
                                    } else {
                                        return 0.200843406946;
                                    }
                                } else {
                                    if (fs[18] <= -0.5) {
                                        return -0.297737752033;
                                    } else {
                                        return -0.0630758181009;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 7.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.000974976779627;
                                    } else {
                                        return -0.00659243368886;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.00308537832014;
                                    } else {
                                        return 0.0753575985001;
                                    }
                                }
                            } else {
                                if (fs[42] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.0101069755099;
                                    } else {
                                        return 0.00734799976476;
                                    }
                                } else {
                                    return 0.116866763098;
                                }
                            }
                        } else {
                            if (fs[4] <= 21.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.00674640336434;
                                    } else {
                                        return 0.0180095875967;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.198555821674;
                                    } else {
                                        return -0.0213507907231;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.00733413447978;
                                    } else {
                                        return -0.0086259881785;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0121672727057;
                                    } else {
                                        return -0.00731049515281;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[46] <= -0.5) {
                        if (fs[46] <= -3.5) {
                            return -0.12983399096;
                        } else {
                            if (fs[55] <= 0.5) {
                                if (fs[4] <= 21.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.128808319604;
                                    } else {
                                        return -0.0159703398447;
                                    }
                                } else {
                                    if (fs[4] <= 24.5) {
                                        return 0.23034866665;
                                    } else {
                                        return 0.272088350108;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[59] <= -1.5) {
                                        return -0.0195666364413;
                                    } else {
                                        return 0.022347544761;
                                    }
                                } else {
                                    return 0.150852074331;
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[91] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.172848080976;
                                    } else {
                                        return 0.22161395864;
                                    }
                                } else {
                                    return 0.0786948740312;
                                }
                            } else {
                                if (fs[50] <= -1033.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0970619425203;
                                    } else {
                                        return -0.0721599711713;
                                    }
                                } else {
                                    if (fs[50] <= 7.5) {
                                        return -0.129877594814;
                                    } else {
                                        return 0.144077577104;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[57] <= 0.5) {
                                    return -0.205479846911;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0742685910297;
                                    } else {
                                        return -0.0106869500143;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1128.0) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0545910784963;
                                    } else {
                                        return -0.130824706184;
                                    }
                                } else {
                                    return -0.00502395504855;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1068.0) {
                        if (fs[50] <= -1083.5) {
                            if (fs[50] <= -1133.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.0227672152422;
                                    } else {
                                        return 0.423902169419;
                                    }
                                } else {
                                    if (fs[69] <= 9997.0) {
                                        return -0.0218750860495;
                                    } else {
                                        return -0.11243492055;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0694780165635;
                                    } else {
                                        return -0.0359864608204;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.0825835813604;
                                    } else {
                                        return -0.0897649643921;
                                    }
                                }
                            }
                        } else {
                            return 0.450230251741;
                        }
                    } else {
                        if (fs[7] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.082254407879;
                                    } else {
                                        return -0.0434887959863;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0280095884506;
                                    } else {
                                        return -0.0597920773024;
                                    }
                                }
                            } else {
                                if (fs[59] <= -2.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0145420782043;
                                    } else {
                                        return 0.0770036831667;
                                    }
                                } else {
                                    if (fs[69] <= 9983.5) {
                                        return -0.00721324263444;
                                    } else {
                                        return -0.0181590362936;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[18] <= 0.5) {
                                    return -0.000991432986067;
                                } else {
                                    return -0.0245536432999;
                                }
                            } else {
                                return 0.104216715348;
                            }
                        }
                    }
                }
            }
        }
    }
}
