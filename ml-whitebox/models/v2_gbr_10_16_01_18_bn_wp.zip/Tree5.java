/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree5 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 9.5) {
                if (fs[50] <= -987.5) {
                    if (fs[50] <= -1143.5) {
                        if (fs[6] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[86] <= 0.5) {
                                        return 0.726102212409;
                                    } else {
                                        return 0.484467084164;
                                    }
                                } else {
                                    return 0.101945871567;
                                }
                            } else {
                                if (fs[4] <= 1.5) {
                                    return 0.0561253346038;
                                } else {
                                    if (fs[69] <= 9847.0) {
                                        return -0.0170989583543;
                                    } else {
                                        return 0.0504855459351;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.316318735937;
                                    } else {
                                        return 0.566235983513;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.572675609267;
                                    } else {
                                        return 0.69617592636;
                                    }
                                }
                            } else {
                                if (fs[73] <= 75.0) {
                                    if (fs[73] <= 25.0) {
                                        return 0.00645815654738;
                                    } else {
                                        return 0.194502790164;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.189921517621;
                                    } else {
                                        return 0.519898335568;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.601476200837;
                                    } else {
                                        return 0.313900515365;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.691771130228;
                                    } else {
                                        return 0.195421749169;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.463000839274;
                                    } else {
                                        return 0.260264647625;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.696264325962;
                                    } else {
                                        return 0.551995821293;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[82] <= -0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.59365342184;
                                    } else {
                                        return 0.161533687728;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return 0.717387592359;
                                    } else {
                                        return 0.672799219771;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.686731256532;
                                    } else {
                                        return 0.713124507959;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.340746948155;
                                    } else {
                                        return 0.174782807415;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[37] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[59] <= -0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.505382790867;
                                    } else {
                                        return 0.667542970014;
                                    }
                                } else {
                                    if (fs[69] <= 9987.0) {
                                        return 0.299268158742;
                                    } else {
                                        return 0.494078124102;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.671494827196;
                                    } else {
                                        return 0.578822934619;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0179140989924;
                                    } else {
                                        return 0.267591388795;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[82] <= -0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0956404962123;
                                    } else {
                                        return 0.0824700707141;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.201886837241;
                                    } else {
                                        return 0.526521661372;
                                    }
                                }
                            } else {
                                if (fs[50] <= -462.0) {
                                    if (fs[73] <= 75.0) {
                                        return -0.123913102939;
                                    } else {
                                        return 0.179163069247;
                                    }
                                } else {
                                    if (fs[69] <= 4273.5) {
                                        return 0.560323620009;
                                    } else {
                                        return 0.00661619321412;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 5.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.145333822567;
                                    } else {
                                        return 0.356890683653;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.598574154084;
                                    } else {
                                        return 0.741633582769;
                                    }
                                }
                            } else {
                                return -0.00154985192692;
                            }
                        } else {
                            return 0.733776229963;
                        }
                    }
                }
            } else {
                if (fs[73] <= 250.0) {
                    if (fs[2] <= 4.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[61] <= -996.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.804071638161;
                                    } else {
                                        return 0.584206643431;
                                    }
                                } else {
                                    if (fs[50] <= -1438.0) {
                                        return 0.501230792584;
                                    } else {
                                        return 0.304666775096;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.638213656646;
                                    } else {
                                        return 0.689132615002;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return 0.0293189390755;
                                    } else {
                                        return 0.337851594458;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[50] <= -1062.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.556545958042;
                                    } else {
                                        return 0.361534031531;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.191123766688;
                                    } else {
                                        return 0.328949552387;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.047396173265;
                                    } else {
                                        return 0.444421774028;
                                    }
                                } else {
                                    if (fs[67] <= -3.5) {
                                        return 0.572579657426;
                                    } else {
                                        return 0.271914807041;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 14.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[42] <= 0.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.609349332897;
                                    } else {
                                        return 0.178226307255;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.521502513924;
                                    } else {
                                        return 0.0710154993194;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.098709712033;
                                    } else {
                                        return -0.157484787526;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.302225739367;
                                    } else {
                                        return 0.578149758222;
                                    }
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[64] <= 0.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.405107660408;
                                    } else {
                                        return 0.175315030262;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.625458537302;
                                    } else {
                                        return 0.75982486371;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 37.0) {
                                        return 0.553207779094;
                                    } else {
                                        return 0.169209889562;
                                    }
                                } else {
                                    return -0.0431743915079;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[97] <= 1.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[50] <= -1007.0) {
                                        return 0.575771452954;
                                    } else {
                                        return 0.294066658953;
                                    }
                                } else {
                                    if (fs[4] <= 30.5) {
                                        return 0.373167373253;
                                    } else {
                                        return 0.628565471116;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[50] <= -1518.5) {
                                        return 0.663948049315;
                                    } else {
                                        return 0.176580697228;
                                    }
                                } else {
                                    if (fs[50] <= -1008.0) {
                                        return 0.457688683844;
                                    } else {
                                        return 0.140680095716;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[6] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return 0.0904524860831;
                                    } else {
                                        return 0.468751690118;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.598543930727;
                                    } else {
                                        return 0.520532181985;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return 0.449182860048;
                                    } else {
                                        return 0.639372653765;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.645116920225;
                                    } else {
                                        return -0.0163167928816;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 20.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.717242148819;
                                    } else {
                                        return 0.631997503091;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.222980621403;
                                    } else {
                                        return 0.316039630329;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    return 0.421604694474;
                                } else {
                                    return 0.3073470727;
                                }
                            }
                        } else {
                            if (fs[4] <= 31.5) {
                                if (fs[61] <= -995.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.67235402004;
                                    } else {
                                        return 0.765596945895;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.276515736828;
                                    } else {
                                        return 0.471284578482;
                                    }
                                }
                            } else {
                                return 0.00273741710343;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[84] <= 0.5) {
                if (fs[75] <= 0.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0536224647211;
                                    } else {
                                        return -0.0134804469681;
                                    }
                                } else {
                                    return 0.654256714449;
                                }
                            } else {
                                if (fs[50] <= -1058.0) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.383269832822;
                                    } else {
                                        return 0.867609852593;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0197867797656;
                                    } else {
                                        return -0.106489780961;
                                    }
                                }
                            }
                        } else {
                            if (fs[34] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0560122440625;
                                    } else {
                                        return 0.14781189324;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.0199673594001;
                                    } else {
                                        return -0.056190684624;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.583797557549;
                                    } else {
                                        return 0.651375809392;
                                    }
                                } else {
                                    return 0.742312750824;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 4847.0) {
                            if (fs[56] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[50] <= -466.5) {
                                        return -0.0619723813546;
                                    } else {
                                        return 0.0909925860627;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0556102968824;
                                    } else {
                                        return -0.00148934542226;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0482803891681;
                                    } else {
                                        return -0.024383469083;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return -0.0554408930784;
                                    } else {
                                        return -0.0410689830605;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1088.0) {
                                return 0.0997554703008;
                            } else {
                                return -0.0628188739481;
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[50] <= -1478.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.111260739367;
                                    } else {
                                        return 0.270240198817;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0169375553521;
                                    } else {
                                        return 0.345333648051;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.0100796610376;
                                    } else {
                                        return 0.141711821126;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.00922437085674;
                                    } else {
                                        return 0.377716581794;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[69] <= 9813.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0453531513147;
                                    } else {
                                        return -0.00151094911233;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.12373017288;
                                    } else {
                                        return 0.318071746998;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[69] <= 9843.5) {
                                        return -0.0309230995205;
                                    } else {
                                        return 0.0482002334412;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return -0.00877033028058;
                                    } else {
                                        return 0.490823691279;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9977.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[69] <= 9830.5) {
                                        return -0.0423120864353;
                                    } else {
                                        return -0.0153933358579;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.158333969275;
                                    } else {
                                        return -0.0195273699871;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.0124010797172;
                                    } else {
                                        return 0.033795778177;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return -0.0378702534939;
                                    } else {
                                        return 0.137967490967;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.118623918283;
                                    } else {
                                        return 0.0405753655585;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0102425574093;
                                    } else {
                                        return -0.0217909554862;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1418.0) {
                                    if (fs[82] <= 6.5) {
                                        return 0.168458032896;
                                    } else {
                                        return 0.597528595586;
                                    }
                                } else {
                                    if (fs[76] <= 0.5) {
                                        return 0.0218443339929;
                                    } else {
                                        return 0.367206009306;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1082.5) {
                    if (fs[33] <= 0.5) {
                        if (fs[4] <= 10.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.335462880115;
                                    } else {
                                        return 0.177912666403;
                                    }
                                } else {
                                    if (fs[0] <= 23.5) {
                                        return 0.0772727186399;
                                    } else {
                                        return 0.382372585784;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.255543249567;
                                    } else {
                                        return 0.00364784187979;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0154188134263;
                                    } else {
                                        return 0.322186867652;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[97] <= 1.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.0320642848021;
                                    } else {
                                        return 0.24814619908;
                                    }
                                } else {
                                    if (fs[0] <= 36.5) {
                                        return 0.133913624523;
                                    } else {
                                        return 0.676358384835;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1128.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0710318450036;
                                    } else {
                                        return 0.38688027606;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.34594334871;
                                    } else {
                                        return 0.767933268976;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[50] <= -1488.0) {
                                if (fs[50] <= -2938.0) {
                                    return 0.557015435418;
                                } else {
                                    if (fs[50] <= -1568.0) {
                                        return 0.113510602659;
                                    } else {
                                        return 0.278046403281;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.515193718087;
                                    } else {
                                        return 0.0222706288279;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.108618553813;
                                    } else {
                                        return 0.675217276645;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1478.0) {
                                if (fs[50] <= -1498.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0481857672714;
                                    } else {
                                        return -0.0245565665378;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0619826811252;
                                    } else {
                                        return 0.189391711985;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.00236957125535;
                                    } else {
                                        return -0.0310445237666;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.232244973314;
                                    } else {
                                        return 0.42100018444;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[97] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[54] <= 0.5) {
                                        return -0.0136049852506;
                                    } else {
                                        return 0.26281044627;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0593882703033;
                                    } else {
                                        return 0.137358484807;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0715166510892;
                                    } else {
                                        return 0.109034219437;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.026346403127;
                                    } else {
                                        return -0.0198636272153;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9997.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[50] <= -1027.0) {
                                        return 0.00160820154385;
                                    } else {
                                        return -0.0390480795722;
                                    }
                                } else {
                                    if (fs[50] <= -1031.5) {
                                        return -0.04150732013;
                                    } else {
                                        return -0.0452841771194;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1037.0) {
                                    if (fs[4] <= 21.5) {
                                        return -0.0492690168079;
                                    } else {
                                        return 0.287745058246;
                                    }
                                } else {
                                    if (fs[50] <= -1010.5) {
                                        return 0.000895407351659;
                                    } else {
                                        return -0.0383759592391;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= 3.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.126206646958;
                                    } else {
                                        return -0.0365431410773;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.00719731295259;
                                    } else {
                                        return -0.0482227412989;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.00292608214055;
                                    } else {
                                        return -0.0417605746188;
                                    }
                                } else {
                                    if (fs[59] <= -2.5) {
                                        return 0.0120165565738;
                                    } else {
                                        return -0.0444410211306;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[4] <= 2.5) {
                                        return -0.0382220316901;
                                    } else {
                                        return -0.0455786605074;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.0232371086529;
                                    } else {
                                        return -0.0456700029648;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0341335363135;
                                    } else {
                                        return -0.0453192772838;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0297328083275;
                                    } else {
                                        return 0.156238001846;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
