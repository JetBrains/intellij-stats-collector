/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree97 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[40] <= 0.5) {
                if (fs[68] <= 0.5) {
                    if (fs[2] <= 8.5) {
                        if (fs[50] <= 4.0) {
                            if (fs[82] <= 0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0113896274118;
                                    } else {
                                        return -0.112291701677;
                                    }
                                } else {
                                    if (fs[50] <= -1654.0) {
                                        return 0.0935162995025;
                                    } else {
                                        return -0.161389292678;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[69] <= 9448.0) {
                                        return 0.0534010525407;
                                    } else {
                                        return 0.0260618575958;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.0155178590711;
                                    } else {
                                        return 0.120375924535;
                                    }
                                }
                            }
                        } else {
                            return -0.253348311512;
                        }
                    } else {
                        if (fs[69] <= 9737.5) {
                            if (fs[73] <= 75.0) {
                                if (fs[4] <= 28.0) {
                                    if (fs[50] <= -1468.0) {
                                        return 0.13624683863;
                                    } else {
                                        return 0.00688799384806;
                                    }
                                } else {
                                    return -0.093786467392;
                                }
                            } else {
                                if (fs[4] <= 26.0) {
                                    if (fs[86] <= 0.5) {
                                        return 0.0499734784679;
                                    } else {
                                        return 0.176676224453;
                                    }
                                } else {
                                    return -0.170097118536;
                                }
                            }
                        } else {
                            if (fs[4] <= 16.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[50] <= -1458.0) {
                                        return 0.0233851081552;
                                    } else {
                                        return 0.19565142528;
                                    }
                                } else {
                                    if (fs[2] <= 9.5) {
                                        return -0.00898816174776;
                                    } else {
                                        return 0.0169801778996;
                                    }
                                }
                            } else {
                                if (fs[4] <= 23.5) {
                                    if (fs[4] <= 18.5) {
                                        return -0.0490593346764;
                                    } else {
                                        return -0.314601206416;
                                    }
                                } else {
                                    return 0.115211718257;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[77] <= 0.5) {
                        if (fs[69] <= 9793.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[73] <= 150.0) {
                                    if (fs[50] <= -880.5) {
                                        return 0.00462847063798;
                                    } else {
                                        return -0.0249788222576;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.10216894326;
                                    } else {
                                        return 0.0073195832294;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[2] <= 10.5) {
                                        return -0.0531061136367;
                                    } else {
                                        return 0.127438253218;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.101681728725;
                                    } else {
                                        return 0.0716333700058;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[4] <= 36.5) {
                                    if (fs[4] <= 20.5) {
                                        return 0.0156639581709;
                                    } else {
                                        return 0.0749770397432;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.19016791716;
                                    } else {
                                        return -0.32705748874;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.022497261801;
                                    } else {
                                        return -0.0532773677194;
                                    }
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return 0.126837726025;
                                    } else {
                                        return 0.0244410219529;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[50] <= -1473.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[69] <= 9998.5) {
                                        return -0.00778338570279;
                                    } else {
                                        return -0.365434773403;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0838939647044;
                                    } else {
                                        return -0.34606110471;
                                    }
                                }
                            } else {
                                return 0.0903152002739;
                            }
                        } else {
                            if (fs[4] <= 12.0) {
                                return 0.137414386128;
                            } else {
                                return 0.0810173031457;
                            }
                        }
                    }
                }
            } else {
                if (fs[68] <= 0.5) {
                    if (fs[4] <= 11.5) {
                        if (fs[93] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0470743655896;
                                    } else {
                                        return 0.173399461733;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0503619767436;
                                    } else {
                                        return -0.311554007609;
                                    }
                                }
                            } else {
                                if (fs[82] <= 2.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0409993917027;
                                    } else {
                                        return -0.0208342641212;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.163359875657;
                                    } else {
                                        return 0.0579074429327;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[69] <= 9987.5) {
                                        return -0.165498553144;
                                    } else {
                                        return 0.21234777419;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.124206348624;
                                    } else {
                                        return 0.283637520014;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.206135151836;
                                    } else {
                                        return 0.0879756410539;
                                    }
                                } else {
                                    return 0.370214465179;
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return -0.107970519126;
                                    } else {
                                        return 0.103327201446;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.219387734364;
                                    } else {
                                        return -0.103103751684;
                                    }
                                }
                            } else {
                                return 0.0988196767248;
                            }
                        } else {
                            return 0.135338088727;
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[97] <= 1.5) {
                            if (fs[69] <= 9996.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[82] <= 2.5) {
                                        return -0.113972445057;
                                    } else {
                                        return -0.290350425942;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.00603453789714;
                                    } else {
                                        return -0.104454790358;
                                    }
                                }
                            } else {
                                return -0.347174644674;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[11] <= 0.5) {
                                        return -0.207137490291;
                                    } else {
                                        return 0.00737778729068;
                                    }
                                } else {
                                    return -0.12430579703;
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0614964259433;
                                    } else {
                                        return -0.209973331351;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.152878784967;
                                    } else {
                                        return 0.0141037847713;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    return -0.212289726815;
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.00648075440255;
                                    } else {
                                        return -0.0879383719747;
                                    }
                                }
                            } else {
                                return 0.113218403082;
                            }
                        } else {
                            return 0.177148687497;
                        }
                    }
                }
            }
        } else {
            if (fs[84] <= 0.5) {
                if (fs[73] <= 300.0) {
                    if (fs[73] <= 75.0) {
                        if (fs[33] <= 0.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.00332640388608;
                                    } else {
                                        return -0.0057494494788;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.000447915253573;
                                    } else {
                                        return -0.00152613228811;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[50] <= -1128.0) {
                                        return -0.0315052651792;
                                    } else {
                                        return -0.0389073209063;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.00495733991213;
                                    } else {
                                        return -0.023789721969;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[50] <= -1318.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0433993972004;
                                    } else {
                                        return 0.22137168745;
                                    }
                                } else {
                                    if (fs[16] <= 0.5) {
                                        return 0.00921233561311;
                                    } else {
                                        return -0.070034619062;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.00132713646305;
                                    } else {
                                        return -0.00182389458528;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return -0.00138933180478;
                                    } else {
                                        return -0.005795746115;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[0] <= 11.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0310451057439;
                                    } else {
                                        return -0.00339692389255;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.023063301578;
                                    } else {
                                        return 0.0997449010084;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[69] <= 9768.5) {
                                        return -0.00235514477873;
                                    } else {
                                        return -0.0161278487121;
                                    }
                                } else {
                                    if (fs[0] <= 76.5) {
                                        return 0.0160026135695;
                                    } else {
                                        return 0.147080700807;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 5.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.0305166883355;
                                    } else {
                                        return -0.00127945498385;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.188662819075;
                                    } else {
                                        return 0.0423335237274;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0303375128895;
                                    } else {
                                        return -0.00637955072843;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.000670347408218;
                                    } else {
                                        return 0.096181563908;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -2018.5) {
                        return 0.181010225453;
                    } else {
                        if (fs[69] <= 9997.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[8] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0218779195273;
                                    } else {
                                        return -0.0380371545871;
                                    }
                                } else {
                                    return -0.100352294008;
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0222186881547;
                                    } else {
                                        return -0.00341801279955;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0357969258824;
                                    } else {
                                        return -0.0202620728477;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1062.0) {
                                return 0.255786457224;
                            } else {
                                return -0.0339577875633;
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1418.0) {
                    if (fs[79] <= 0.5) {
                        if (fs[4] <= 8.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.156920206298;
                                    } else {
                                        return -0.0300105228149;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0414102578256;
                                    } else {
                                        return 0.501044005494;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[50] <= -1593.5) {
                                        return 0.0841662853335;
                                    } else {
                                        return -0.06748678853;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.158198956515;
                                    } else {
                                        return 0.261756467759;
                                    }
                                }
                            }
                        } else {
                            if (fs[77] <= 0.5) {
                                if (fs[69] <= 9996.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.171725231005;
                                    } else {
                                        return 0.00662460902771;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.122585194264;
                                    } else {
                                        return -0.042862271455;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9979.5) {
                                    if (fs[50] <= -1948.0) {
                                        return 0.0974065581185;
                                    } else {
                                        return -0.0153710725564;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.0123592342655;
                                    } else {
                                        return -0.134864817264;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 5.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[91] <= 0.5) {
                                    return 0.156798403411;
                                } else {
                                    if (fs[73] <= 125.0) {
                                        return -0.0197884156742;
                                    } else {
                                        return 0.0651141961437;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.271107158588;
                                    } else {
                                        return 0.518940868863;
                                    }
                                } else {
                                    return 0.141208301587;
                                }
                            }
                        } else {
                            if (fs[0] <= 54.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[69] <= 4329.5) {
                                        return 0.149892039919;
                                    } else {
                                        return 0.00946909688858;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return 0.0307104004681;
                                    } else {
                                        return -0.0241661763446;
                                    }
                                }
                            } else {
                                return 0.437113690904;
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 14.5) {
                        if (fs[97] <= 0.5) {
                            if (fs[0] <= 10.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0191828999861;
                                    } else {
                                        return 0.0492298691267;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0222841125514;
                                    } else {
                                        return 0.00833046109482;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    return 0.0771324762971;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00390774016072;
                                    } else {
                                        return 0.000793444378098;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[59] <= -1.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.00109600389979;
                                    } else {
                                        return 0.051035365753;
                                    }
                                } else {
                                    if (fs[59] <= -0.5) {
                                        return -0.0226245298452;
                                    } else {
                                        return 0.00368058338322;
                                    }
                                }
                            } else {
                                if (fs[67] <= -4.0) {
                                    if (fs[0] <= 2.5) {
                                        return 0.108210919381;
                                    } else {
                                        return 0.00379773106171;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0210059047475;
                                    } else {
                                        return -0.00310277385119;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1092.5) {
                            return -0.14056016456;
                        } else {
                            return -0.0812402919385;
                        }
                    }
                }
            }
        }
    }
}
