/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree41 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[2] <= 1.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[50] <= -1138.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[57] <= 0.5) {
                                    return 0.198168797925;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0587570413251;
                                    } else {
                                        return 0.123044677798;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0716161931151;
                                    } else {
                                        return 0.0357269921663;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return -0.0889480512276;
                                    } else {
                                        return 0.126694537751;
                                    }
                                }
                            }
                        } else {
                            if (fs[34] <= 0.5) {
                                if (fs[50] <= -1038.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.148661983791;
                                    } else {
                                        return 0.140846884616;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.122341089766;
                                    } else {
                                        return -0.321640305677;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.121845920302;
                                    } else {
                                        return 0.118380520028;
                                    }
                                } else {
                                    return 0.107694150896;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 2.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[40] <= 0.5) {
                                    return 0.139582510205;
                                } else {
                                    return 0.0700807435075;
                                }
                            } else {
                                if (fs[50] <= -1068.0) {
                                    return 0.278734440547;
                                } else {
                                    return -0.0890754619461;
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0291451074418;
                                    } else {
                                        return 0.137689051134;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0117151497101;
                                    } else {
                                        return 0.0598762083791;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.00780367433359;
                                    } else {
                                        return 0.105856406667;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.159221082999;
                                    } else {
                                        return -0.0842590085226;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.165105405628;
                                    } else {
                                        return 0.136088775101;
                                    }
                                } else {
                                    return 0.0518094731362;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.121178162604;
                                    } else {
                                        return 0.130780645658;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.120097398116;
                                    } else {
                                        return 0.112151214591;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[67] <= -1.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.113798054185;
                                    } else {
                                        return 0.0999565361578;
                                    }
                                } else {
                                    return 0.0944212242284;
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0545628737556;
                                    } else {
                                        return 0.125410134428;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.0909933586311;
                                    } else {
                                        return -0.188083600584;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.417682314381;
                                    } else {
                                        return 0.0957195143159;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0238696732792;
                                    } else {
                                        return -0.0300573976053;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[0] <= 1.5) {
                                        return -0.105128517334;
                                    } else {
                                        return -0.0205344149496;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.000996044539474;
                                    } else {
                                        return -0.0340002605987;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return 0.0905293417856;
                                    } else {
                                        return -0.0929867212395;
                                    }
                                } else {
                                    return 0.30278785194;
                                }
                            } else {
                                return 0.363188827064;
                            }
                        }
                    }
                }
            } else {
                if (fs[95] <= 0.5) {
                    if (fs[34] <= 0.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[69] <= 9997.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.238482474242;
                                    } else {
                                        return 0.16165601982;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return -0.0324984308086;
                                    } else {
                                        return 0.0402250714796;
                                    }
                                }
                            } else {
                                return 0.165270550304;
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.162699043053;
                                    } else {
                                        return 0.13741274074;
                                    }
                                } else {
                                    return 0.258812194097;
                                }
                            } else {
                                return 0.0248504390642;
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[2] <= 1.5) {
                                return -0.133668861177;
                            } else {
                                return -0.154718743275;
                            }
                        } else {
                            return 0.139073922258;
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[50] <= -1263.0) {
                            if (fs[0] <= 0.5) {
                                if (fs[50] <= -1568.0) {
                                    return 0.0130770178441;
                                } else {
                                    return -0.171187779515;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[50] <= -1578.0) {
                                        return -0.0191265455243;
                                    } else {
                                        return -0.0297584211631;
                                    }
                                } else {
                                    return 0.00915486795121;
                                }
                            }
                        } else {
                            if (fs[4] <= 27.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.120521662198;
                                    } else {
                                        return 0.00120780144581;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0204101550486;
                                    } else {
                                        return -0.00245784810758;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0229641095207;
                                    } else {
                                        return -0.00946963250915;
                                    }
                                } else {
                                    if (fs[4] <= 72.0) {
                                        return -0.0104659938769;
                                    } else {
                                        return 0.0345083347999;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.176845412824;
                                    } else {
                                        return -0.0508814164757;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0307265834551;
                                    } else {
                                        return -0.0194951964926;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[4] <= 39.5) {
                                        return -0.015158072364;
                                    } else {
                                        return -0.00994241339259;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return -0.0113073594487;
                                    } else {
                                        return -0.00954598026084;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 44.5) {
                                        return -0.0665506486853;
                                    } else {
                                        return -0.039534553196;
                                    }
                                } else {
                                    return -0.0388772765135;
                                }
                            } else {
                                return -0.0187759200538;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[95] <= 0.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[50] <= -1504.0) {
                                    if (fs[67] <= -1.5) {
                                        return 0.138735746728;
                                    } else {
                                        return -0.207283551423;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0252512495231;
                                    } else {
                                        return -0.0416271643337;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.138859075938;
                                    } else {
                                        return -0.0240233893767;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.195858099812;
                                    } else {
                                        return -0.199962514913;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -546.5) {
                                if (fs[56] <= 0.5) {
                                    if (fs[69] <= 9989.5) {
                                        return 0.348136438806;
                                    } else {
                                        return 0.238617386817;
                                    }
                                } else {
                                    if (fs[69] <= 9617.0) {
                                        return 0.276646610907;
                                    } else {
                                        return 0.355431445466;
                                    }
                                }
                            } else {
                                return 0.0670754068072;
                            }
                        }
                    } else {
                        if (fs[50] <= -1498.5) {
                            if (fs[2] <= 0.5) {
                                return -0.178319842278;
                            } else {
                                if (fs[50] <= -1829.0) {
                                    if (fs[4] <= 3.5) {
                                        return 0.291027314229;
                                    } else {
                                        return 0.147549222211;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.217591298503;
                                    } else {
                                        return -0.124110573862;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.138530821536;
                                    } else {
                                        return 0.0943966138746;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.0501216801844;
                                    } else {
                                        return -0.053154317379;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[50] <= -1138.5) {
                                        return -0.0100194355123;
                                    } else {
                                        return 0.055170288548;
                                    }
                                } else {
                                    if (fs[50] <= -1138.5) {
                                        return 0.0504685099614;
                                    } else {
                                        return 0.111443303545;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 17.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[50] <= -1493.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.234613319715;
                                    } else {
                                        return 0.135563120932;
                                    }
                                } else {
                                    if (fs[82] <= -0.5) {
                                        return -0.140115083903;
                                    } else {
                                        return 0.091719939197;
                                    }
                                }
                            } else {
                                if (fs[2] <= 8.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.146181579374;
                                    } else {
                                        return 0.109322818277;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.153692439625;
                                    } else {
                                        return 0.238997144568;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[73] <= 150.0) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0853795538685;
                                    } else {
                                        return -0.00892776097366;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.261207908372;
                                    } else {
                                        return 0.0421864976961;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.042041075705;
                                    } else {
                                        return -0.169850438889;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.21159365195;
                                    } else {
                                        return 0.0463337580406;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 11.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[98] <= 0.5) {
                                    if (fs[69] <= 9816.5) {
                                        return -0.0397068344561;
                                    } else {
                                        return 0.0459841304814;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0391767673203;
                                    } else {
                                        return 0.28629695151;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[4] <= 29.5) {
                                        return 0.106805494913;
                                    } else {
                                        return -0.0637828920133;
                                    }
                                } else {
                                    if (fs[82] <= 5.0) {
                                        return 0.0448307990877;
                                    } else {
                                        return -0.128157872619;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[95] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.235123079061;
                                    } else {
                                        return 0.508332149911;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.327277253933;
                                    } else {
                                        return 0.12988115441;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.060521863507;
                                    } else {
                                        return 0.285635724792;
                                    }
                                } else {
                                    return 0.0470790350634;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[50] <= -1478.5) {
                        if (fs[4] <= 8.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.00528894684756;
                                    } else {
                                        return 0.286588393633;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.129828407229;
                                    } else {
                                        return 0.273200153972;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.0242623438282;
                                    } else {
                                        return -0.350900623525;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.00712483806121;
                                    } else {
                                        return 0.1818549839;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[4] <= 21.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0419940348134;
                                    } else {
                                        return 0.299799099344;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0187352217258;
                                    } else {
                                        return 0.0516945992437;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0389720952245;
                                    } else {
                                        return 0.188247749364;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0281122803413;
                                    } else {
                                        return 0.0536330782048;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[79] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.139490746726;
                                    } else {
                                        return 0.0274878716278;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0368621901116;
                                    } else {
                                        return -0.0109013858265;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0200222703195;
                                    } else {
                                        return -0.00465520827438;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0182809352944;
                                    } else {
                                        return 0.103154543685;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[73] <= 25.0) {
                                    if (fs[69] <= 9848.0) {
                                        return -0.0233067406759;
                                    } else {
                                        return 0.0544807819325;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0450118217852;
                                    } else {
                                        return 0.22043668286;
                                    }
                                }
                            } else {
                                if (fs[50] <= -402.0) {
                                    if (fs[69] <= 8695.5) {
                                        return -0.0437673288121;
                                    } else {
                                        return -0.0847153547849;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0258590142854;
                                    } else {
                                        return -0.0196953243759;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9977.5) {
                        if (fs[0] <= 5.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.00455436724164;
                                    } else {
                                        return 0.0106478625385;
                                    }
                                } else {
                                    if (fs[50] <= -1438.0) {
                                        return 0.0488970171243;
                                    } else {
                                        return 0.00406905252845;
                                    }
                                }
                            } else {
                                if (fs[42] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0133708757346;
                                    } else {
                                        return -0.00950328388609;
                                    }
                                } else {
                                    return 0.165156316666;
                                }
                            }
                        } else {
                            if (fs[54] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 21.5) {
                                        return -0.0065818862567;
                                    } else {
                                        return -0.00838932500146;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return -0.00824676625227;
                                    } else {
                                        return -0.013239105058;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return 0.24822988463;
                                    } else {
                                        return -0.038730629035;
                                    }
                                } else {
                                    if (fs[50] <= -976.0) {
                                        return -0.0503305606762;
                                    } else {
                                        return 0.0191027182607;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0307493607102;
                                    } else {
                                        return -0.00167862051284;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return 0.0744405291505;
                                    } else {
                                        return -0.00874863699085;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0265438895297;
                                    } else {
                                        return 0.0681843107751;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.000990177569123;
                                    } else {
                                        return 0.370819255493;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[0] <= 2.5) {
                                    if (fs[13] <= 0.5) {
                                        return -0.0531554195846;
                                    } else {
                                        return -0.0908972594794;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.0277477172613;
                                    } else {
                                        return 0.00174979869161;
                                    }
                                }
                            } else {
                                if (fs[2] <= 8.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.000484153454534;
                                    } else {
                                        return -0.01105731599;
                                    }
                                } else {
                                    return 0.0377006119726;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
