/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree96 {
    public double calcTree(double... fs) {
        if (fs[54] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[40] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[4] <= 13.5) {
                            if (fs[50] <= -987.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[50] <= -1483.5) {
                                        return -0.00615155487197;
                                    } else {
                                        return 0.0301547834548;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.00673370217683;
                                    } else {
                                        return -0.0242135786132;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.0959955563387;
                                    } else {
                                        return -0.0338771492243;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.0347364136295;
                                    } else {
                                        return -0.0926091533635;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[50] <= -1493.5) {
                                    if (fs[82] <= 2.5) {
                                        return 0.0203234622337;
                                    } else {
                                        return -0.137284024147;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0573622175235;
                                    } else {
                                        return 0.0762017458266;
                                    }
                                }
                            } else {
                                if (fs[2] <= 0.5) {
                                    return -0.211445542865;
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0110302565108;
                                    } else {
                                        return 0.0272315350298;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[67] <= -3.5) {
                            if (fs[67] <= -4.5) {
                                if (fs[82] <= 1.0) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0118776018904;
                                    } else {
                                        return 0.0435015669804;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0890315471876;
                                    } else {
                                        return 0.0414370232085;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.141171977499;
                                    } else {
                                        return -0.243638802344;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.139907069663;
                                    } else {
                                        return 0.266889448324;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[25] <= 0.5) {
                                    if (fs[61] <= -994.5) {
                                        return 0.0528015741493;
                                    } else {
                                        return 0.00608945602288;
                                    }
                                } else {
                                    if (fs[50] <= -1468.5) {
                                        return -0.00968764080837;
                                    } else {
                                        return -0.0978705505941;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0168094121553;
                                    } else {
                                        return -0.0102621152817;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return 0.0547818550636;
                                    } else {
                                        return 0.00765019699463;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[77] <= 0.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[82] <= 7.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.102560254063;
                                    } else {
                                        return -0.0148999229825;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0581784202963;
                                    } else {
                                        return -0.0201273027433;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return -0.0581979093875;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.11193231458;
                                    } else {
                                        return 0.0818987438814;
                                    }
                                }
                            }
                        } else {
                            return 0.118374609784;
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            return -0.34721133009;
                        } else {
                            if (fs[69] <= 4979.0) {
                                return -0.0174189360353;
                            } else {
                                return -0.287565070405;
                            }
                        }
                    }
                }
            } else {
                if (fs[63] <= 5.0) {
                    if (fs[52] <= 0.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.000600786996055;
                                    } else {
                                        return 0.000978105560285;
                                    }
                                } else {
                                    if (fs[4] <= 5.0) {
                                        return 0.125481691199;
                                    } else {
                                        return 0.0794499501326;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.00130394197086;
                                    } else {
                                        return -0.0118174882841;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.125418090854;
                                    } else {
                                        return 0.0293352684752;
                                    }
                                }
                            }
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[69] <= 9967.5) {
                                        return -0.00683958162203;
                                    } else {
                                        return -0.0980248306605;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.0622575081991;
                                    } else {
                                        return 0.0176629058361;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    return -0.100244094092;
                                } else {
                                    if (fs[50] <= -1483.0) {
                                        return -0.069751638683;
                                    } else {
                                        return -0.0223935930038;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1242.5) {
                            if (fs[52] <= 50.5) {
                                return 0.362302332762;
                            } else {
                                if (fs[52] <= 993.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.3823361598;
                                    } else {
                                        return -0.0135208267895;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0302389169463;
                                    } else {
                                        return 0.0842884303911;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[4] <= 11.5) {
                                    return 0.146059553805;
                                } else {
                                    return -0.0136403414451;
                                }
                            } else {
                                if (fs[82] <= 1.0) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0106370458757;
                                    } else {
                                        return -0.0240194669846;
                                    }
                                } else {
                                    return 0.0185029576624;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9937.5) {
                        if (fs[73] <= 25.0) {
                            if (fs[12] <= 0.5) {
                                if (fs[69] <= 9751.5) {
                                    if (fs[50] <= -491.5) {
                                        return -0.0318942655467;
                                    } else {
                                        return -0.0115943990163;
                                    }
                                } else {
                                    return -0.0505747935912;
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.00956632382846;
                                    } else {
                                        return -0.0174881195862;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.0015090722468;
                                    } else {
                                        return -0.0108542622016;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[50] <= -1488.0) {
                                    if (fs[4] <= 13.5) {
                                        return -0.136354106413;
                                    } else {
                                        return -0.0829573579158;
                                    }
                                } else {
                                    return 0.0177457752358;
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    return 0.00301115842072;
                                } else {
                                    return -0.106966361446;
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 75.0) {
                            return -0.08014906931;
                        } else {
                            if (fs[2] <= 2.5) {
                                return -0.103934179681;
                            } else {
                                return -0.272320857837;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[44] <= 0.5) {
                if (fs[40] <= 0.5) {
                    if (fs[69] <= 9999.5) {
                        if (fs[8] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.103450350731;
                                    } else {
                                        return -0.0538781690939;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0997800607623;
                                    } else {
                                        return -0.0458879608751;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9997.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.0636963112992;
                                    } else {
                                        return 0.10077870835;
                                    }
                                } else {
                                    return -0.150827567469;
                                }
                            }
                        } else {
                            return -0.140755626874;
                        }
                    } else {
                        if (fs[50] <= -1138.5) {
                            return 0.26376082102;
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.223641911849;
                                    } else {
                                        return 0.136505471393;
                                    }
                                } else {
                                    return 0.118071275908;
                                }
                            } else {
                                return 0.068821238014;
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -561.5) {
                        return -0.0312438527923;
                    } else {
                        return -0.143762270336;
                    }
                }
            } else {
                if (fs[69] <= 9975.5) {
                    if (fs[99] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[59] <= -0.5) {
                                return -0.0145894057244;
                            } else {
                                return -0.0235281401089;
                            }
                        } else {
                            if (fs[73] <= 250.0) {
                                return -0.0140822584166;
                            } else {
                                return -0.00260569817266;
                            }
                        }
                    } else {
                        return -0.0288230084333;
                    }
                } else {
                    return -0.0625611574884;
                }
            }
        }
    }
}
