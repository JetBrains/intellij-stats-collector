/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree49 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[2] <= 1.5) {
                    if (fs[4] <= 2.5) {
                        if (fs[0] <= 1.5) {
                            return 0.0993945494649;
                        } else {
                            if (fs[0] <= 10.5) {
                                if (fs[0] <= 2.5) {
                                    return 0.208947540833;
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.280546450019;
                                    } else {
                                        return 0.21096797439;
                                    }
                                }
                            } else {
                                return 0.0875676458728;
                            }
                        }
                    } else {
                        if (fs[50] <= -1138.0) {
                            if (fs[68] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.315378025965;
                                    } else {
                                        return -0.0196015625431;
                                    }
                                } else {
                                    return 0.0873348906249;
                                }
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return -0.0196910507055;
                                    } else {
                                        return 0.0181962409644;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.067941707005;
                                    } else {
                                        return 0.125845557532;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -988.0) {
                                if (fs[30] <= 0.5) {
                                    if (fs[50] <= -1123.5) {
                                        return 0.0852455538109;
                                    } else {
                                        return 0.120558141999;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0754111581355;
                                    } else {
                                        return -0.0511509333798;
                                    }
                                }
                            } else {
                                if (fs[15] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0956016385871;
                                    } else {
                                        return -0.023668660883;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0140987591973;
                                    } else {
                                        return -0.0965458499888;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[30] <= 0.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    return 0.149194216399;
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0832552506366;
                                    } else {
                                        return 0.157671144144;
                                    }
                                }
                            } else {
                                if (fs[50] <= -988.0) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0345714415511;
                                    } else {
                                        return 0.0759119820434;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0564544835523;
                                    } else {
                                        return 0.0393524350412;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.5) {
                                if (fs[2] <= 5.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0887520189136;
                                    } else {
                                        return 0.475004733998;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0636982788089;
                                    } else {
                                        return 0.0872808037801;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.0768629060101;
                                    } else {
                                        return 0.144316029275;
                                    }
                                } else {
                                    if (fs[50] <= -1128.0) {
                                        return 0.122798210985;
                                    } else {
                                        return -0.0412663608849;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[50] <= -1138.0) {
                                return -0.0626166493658;
                            } else {
                                return -0.0798191319586;
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                return -0.0352807637397;
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[50] <= -571.5) {
                                        return -0.022330645384;
                                    } else {
                                        return -0.0152575494818;
                                    }
                                } else {
                                    if (fs[0] <= 20.5) {
                                        return -0.00937061929152;
                                    } else {
                                        return -0.00639641486361;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[95] <= 0.5) {
                        if (fs[34] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 8.5) {
                                    return 0.274860778501;
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.219361796093;
                                    } else {
                                        return 0.169484004935;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0979140119117;
                                    } else {
                                        return 0.122255706384;
                                    }
                                } else {
                                    return 0.0853772475163;
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[2] <= 2.5) {
                                    return -0.152058430092;
                                } else {
                                    return 0.103520409307;
                                }
                            } else {
                                return 0.157818054504;
                            }
                        }
                    } else {
                        if (fs[4] <= 21.5) {
                            return 0.0822840689655;
                        } else {
                            if (fs[4] <= 29.5) {
                                if (fs[50] <= -1578.0) {
                                    return -0.209909790287;
                                } else {
                                    return -0.12745589257;
                                }
                            } else {
                                if (fs[4] <= 32.5) {
                                    return 0.189651741188;
                                } else {
                                    if (fs[4] <= 39.5) {
                                        return -0.18559085703;
                                    } else {
                                        return -0.00452314945921;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[67] <= -1.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[0] <= 7.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 76.5) {
                                        return -0.038161351277;
                                    } else {
                                        return 0.0684572785171;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0404316831283;
                                    } else {
                                        return -0.0353333373378;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return -0.0127252058912;
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0368338192813;
                                    } else {
                                        return -0.0243945702482;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0424107642104;
                                    } else {
                                        return -0.00116074860184;
                                    }
                                } else {
                                    return 0.0159076963419;
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    return -0.0460657896863;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0153947794772;
                                    } else {
                                        return -0.0262653304071;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[69] <= 9745.0) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0354738967158;
                                    } else {
                                        return -0.00299107960161;
                                    }
                                } else {
                                    if (fs[50] <= -1068.0) {
                                        return -0.0115443143208;
                                    } else {
                                        return -0.00843562438119;
                                    }
                                }
                            } else {
                                return -0.072253384912;
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[4] <= 39.5) {
                                    if (fs[50] <= -1012.0) {
                                        return -0.0298200428446;
                                    } else {
                                        return -0.0127049367274;
                                    }
                                } else {
                                    if (fs[4] <= 40.5) {
                                        return 0.0552677513272;
                                    } else {
                                        return -0.0262280296414;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[4] <= 33.5) {
                                        return -0.0138272655235;
                                    } else {
                                        return -0.0110615042159;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.00777825493181;
                                    } else {
                                        return -0.00472206172545;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[40] <= 0.5) {
                    if (fs[2] <= 3.5) {
                        if (fs[50] <= -1498.5) {
                            if (fs[67] <= -1.5) {
                                if (fs[2] <= 0.5) {
                                    return -0.11864323371;
                                } else {
                                    if (fs[50] <= -1838.5) {
                                        return 0.110107900983;
                                    } else {
                                        return 0.184252630925;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    return -0.180455986034;
                                } else {
                                    return -0.342676195317;
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.0453112091211;
                                    } else {
                                        return 0.0793837861986;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.011332678606;
                                    } else {
                                        return 0.0836769269008;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0654800769096;
                                    } else {
                                        return 0.136517972187;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0663617688768;
                                    } else {
                                        return 0.117954277297;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[8] <= 0.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.0810654898667;
                                    } else {
                                        return 0.124364291882;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0293003044039;
                                    } else {
                                        return -0.256173213763;
                                    }
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    if (fs[2] <= 11.5) {
                                        return 0.039868617368;
                                    } else {
                                        return 0.224956956038;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return -0.174284642741;
                                    } else {
                                        return 0.145470507108;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 4998.5) {
                                if (fs[93] <= 0.5) {
                                    return -0.382339341457;
                                } else {
                                    return -0.235406534978;
                                }
                            } else {
                                return 0.096325889123;
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 7.5) {
                        if (fs[68] <= 0.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0534762665296;
                                    } else {
                                        return 0.154947386076;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.452742133878;
                                    } else {
                                        return 0.297484856599;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.0578929681951;
                                    } else {
                                        return 0.0144263381102;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return 0.0815928745934;
                                    } else {
                                        return -0.100165224866;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.149490615627;
                                    } else {
                                        return -0.0451962479459;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0345543117899;
                                    } else {
                                        return -0.0597817426419;
                                    }
                                }
                            } else {
                                return 0.226224812183;
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            return -0.101299011628;
                        } else {
                            if (fs[49] <= 0.5) {
                                return -0.0402085068262;
                            } else {
                                if (fs[69] <= 4435.0) {
                                    if (fs[50] <= -1478.0) {
                                        return 0.144119103542;
                                    } else {
                                        return 0.0567395800615;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.162915885505;
                                    } else {
                                        return 0.274528798912;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[40] <= 0.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[4] <= 16.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0157675797101;
                                    } else {
                                        return 0.320245004367;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.0515420504256;
                                    } else {
                                        return 0.329228047848;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.0112207860465;
                                    } else {
                                        return 0.0270603596752;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return 0.0176579348164;
                                    } else {
                                        return -0.0864776373646;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 1.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[69] <= 9994.5) {
                                        return -0.0240535295659;
                                    } else {
                                        return 0.151005280785;
                                    }
                                } else {
                                    return 0.136308288389;
                                }
                            } else {
                                if (fs[18] <= -0.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.0634288281706;
                                    } else {
                                        return -0.274866308227;
                                    }
                                } else {
                                    if (fs[69] <= 9989.5) {
                                        return -0.0018082285531;
                                    } else {
                                        return 0.0464718863504;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[4] <= 26.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[76] <= 0.5) {
                                        return -0.0134349797091;
                                    } else {
                                        return 0.115470599419;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.00939219670628;
                                    } else {
                                        return 0.11017215286;
                                    }
                                }
                            } else {
                                return 0.393842418466;
                            }
                        } else {
                            if (fs[61] <= -996.5) {
                                if (fs[50] <= -1133.0) {
                                    return 0.487973896995;
                                } else {
                                    return 0.159249785337;
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0118559886351;
                                    } else {
                                        return 0.0665504386638;
                                    }
                                } else {
                                    if (fs[73] <= 350.0) {
                                        return 0.146889220525;
                                    } else {
                                        return 0.340833993787;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 7.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.00489752692252;
                                    } else {
                                        return 0.0823069977111;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.00309517418636;
                                    } else {
                                        return 0.00666892153356;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.157122595487;
                                    } else {
                                        return 0.00749942513136;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.213469083333;
                                    } else {
                                        return 0.403634810501;
                                    }
                                }
                            }
                        } else {
                            if (fs[42] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[69] <= 9867.0) {
                                        return -0.00885882170171;
                                    } else {
                                        return -0.0257525510484;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0065486374546;
                                    } else {
                                        return -0.0165555406057;
                                    }
                                }
                            } else {
                                return 0.107954261465;
                            }
                        }
                    } else {
                        if (fs[54] <= 0.5) {
                            if (fs[97] <= 1.5) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.001158390892;
                                    } else {
                                        return -0.00493227205953;
                                    }
                                } else {
                                    if (fs[50] <= -1428.0) {
                                        return 0.097345093063;
                                    } else {
                                        return 0.00210858350715;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[50] <= -1118.0) {
                                        return 0.0815036732185;
                                    } else {
                                        return -0.00536127890064;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.0208120329007;
                                    } else {
                                        return 0.16553055646;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 17.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.185160901247;
                                    } else {
                                        return -0.00741667984364;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.0503843853059;
                                    } else {
                                        return -0.0158278704619;
                                    }
                                }
                            } else {
                                if (fs[82] <= 3.0) {
                                    if (fs[4] <= 14.5) {
                                        return -0.0255268180404;
                                    } else {
                                        return 0.0449964939784;
                                    }
                                } else {
                                    return 0.204597606423;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
