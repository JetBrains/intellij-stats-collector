/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree26 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[50] <= -1438.5) {
                    if (fs[50] <= -1568.0) {
                        if (fs[4] <= 32.5) {
                            if (fs[4] <= 28.0) {
                                return 0.0432439636395;
                            } else {
                                return 0.146104587551;
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                return -0.108186262911;
                            } else {
                                return -0.168210548893;
                            }
                        }
                    } else {
                        if (fs[50] <= -1548.0) {
                            return -0.173046404448;
                        } else {
                            return -0.225771715485;
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[56] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[50] <= -1033.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.244332351714;
                                    } else {
                                        return 0.198915693482;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.102098411062;
                                    } else {
                                        return 0.434775509678;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.265227176868;
                                    } else {
                                        return 0.222472841369;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.333620206113;
                                    } else {
                                        return 0.286238360271;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9997.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.117495582469;
                                    } else {
                                        return 0.281964826779;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return 0.369684420878;
                                    } else {
                                        return 0.144862020426;
                                    }
                                }
                            } else {
                                return 0.332223772825;
                            }
                        }
                    } else {
                        if (fs[73] <= 100.0) {
                            if (fs[4] <= 9.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.266806683001;
                                    } else {
                                        return 0.248970588581;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.248324217054;
                                    } else {
                                        return 0.0317928406138;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    return 0.302093029631;
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return 0.28968817428;
                                    } else {
                                        return 0.303074453844;
                                    }
                                }
                            }
                        } else {
                            return 0.0943078610022;
                        }
                    }
                }
            } else {
                if (fs[0] <= 2.5) {
                    if (fs[34] <= 0.5) {
                        if (fs[33] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return -0.0856822505942;
                                    } else {
                                        return -0.113065784388;
                                    }
                                } else {
                                    return 0.00539000391435;
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0632070083454;
                                    } else {
                                        return -0.0547383235899;
                                    }
                                } else {
                                    return -0.108985078569;
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00572672146654;
                                    } else {
                                        return 0.0487279212677;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.00988254744528;
                                    } else {
                                        return 0.245911902291;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0235558521342;
                                    } else {
                                        return -0.0388132728028;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.0646019840623;
                                    } else {
                                        return -0.0298243231047;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[50] <= -1138.0) {
                                return 0.305994950781;
                            } else {
                                return 0.334063311243;
                            }
                        } else {
                            return 0.379005748872;
                        }
                    }
                } else {
                    if (fs[4] <= 2.5) {
                        return 0.308024003651;
                    } else {
                        if (fs[0] <= 25.5) {
                            if (fs[15] <= 0.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0159370845341;
                                    } else {
                                        return 0.0573096767238;
                                    }
                                } else {
                                    return 0.0875538091627;
                                }
                            } else {
                                if (fs[0] <= 24.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0935934386611;
                                    } else {
                                        return 0.0212382742634;
                                    }
                                } else {
                                    return 0.637202232532;
                                }
                            }
                        } else {
                            if (fs[15] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0432522241982;
                                    } else {
                                        return 0.032154487745;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0479465150689;
                                    } else {
                                        return -0.0187846648612;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return -0.0837451268113;
                                } else {
                                    return -0.0718063061676;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[73] <= 25.0) {
                    if (fs[79] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[13] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.275780424623;
                                    } else {
                                        return -0.200056076882;
                                    }
                                } else {
                                    if (fs[50] <= -1314.0) {
                                        return -0.035449260711;
                                    } else {
                                        return 0.225740949384;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.208712696177;
                                    } else {
                                        return 0.111084531623;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.243346517305;
                                    } else {
                                        return 0.289651935052;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -1128.5) {
                                        return 0.242012543302;
                                    } else {
                                        return 0.054025173392;
                                    }
                                } else {
                                    if (fs[82] <= -0.5) {
                                        return -0.298902259723;
                                    } else {
                                        return 0.252847104563;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[67] <= -3.5) {
                                        return 0.174798027643;
                                    } else {
                                        return 0.0584666428216;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.219008431896;
                                    } else {
                                        return 0.0375222903289;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.107306605628;
                                    } else {
                                        return -0.162388743966;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0919259496686;
                                    } else {
                                        return 0.0369186862418;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.286148639145;
                                    } else {
                                        return -0.0997395011601;
                                    }
                                } else {
                                    if (fs[18] <= -0.5) {
                                        return -0.15910578469;
                                    } else {
                                        return 0.0268597769251;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 16.5) {
                                if (fs[69] <= 9477.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.389226256689;
                                    } else {
                                        return 0.251938938977;
                                    }
                                } else {
                                    if (fs[69] <= 9970.0) {
                                        return -0.0934686493779;
                                    } else {
                                        return 0.324691876277;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1478.0) {
                                    if (fs[69] <= 9947.5) {
                                        return 0.418744072806;
                                    } else {
                                        return -0.232838328063;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.134249407689;
                                    } else {
                                        return 0.386628657381;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[97] <= 1.5) {
                            if (fs[50] <= -1543.5) {
                                if (fs[2] <= 0.5) {
                                    return -0.106668831813;
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.328143662068;
                                    } else {
                                        return 0.237767076664;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.139200262683;
                                    } else {
                                        return 0.214551531092;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.00826823060119;
                                    } else {
                                        return 0.172151432475;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    return 0.0275313518263;
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.228037295217;
                                    } else {
                                        return 0.075879937801;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.117583576294;
                                    } else {
                                        return 0.222519943119;
                                    }
                                } else {
                                    return 0.37600394035;
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.246556905635;
                                    } else {
                                        return 0.168757493075;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.310478377397;
                                    } else {
                                        return 0.0807789794616;
                                    }
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.281793609268;
                                    } else {
                                        return 0.0127305819711;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.283476114942;
                                    } else {
                                        return -0.0636297389898;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[73] <= 150.0) {
                                        return 0.0230124740283;
                                    } else {
                                        return 0.113016166842;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.239068594383;
                                    } else {
                                        return 0.0412251719289;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[69] <= 4667.5) {
                                        return 0.0670815076104;
                                    } else {
                                        return -0.0849809863288;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.362471314571;
                                    } else {
                                        return 0.342789592737;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[95] <= 0.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[82] <= 7.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0153340068795;
                                    } else {
                                        return -0.0232162698153;
                                    }
                                } else {
                                    if (fs[82] <= 4.5) {
                                        return 0.101346124256;
                                    } else {
                                        return 0.0149129102885;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.00306734906249;
                                    } else {
                                        return -0.0263638325378;
                                    }
                                } else {
                                    if (fs[50] <= -426.5) {
                                        return 0.0197446637659;
                                    } else {
                                        return 0.145439898753;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.00724699591439;
                                    } else {
                                        return 0.488276971204;
                                    }
                                } else {
                                    if (fs[50] <= -1247.5) {
                                        return 0.287697132116;
                                    } else {
                                        return -0.146899326868;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[14] <= 0.5) {
                                        return -0.00612124676972;
                                    } else {
                                        return 0.130729940242;
                                    }
                                } else {
                                    return 0.174596042172;
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9859.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[67] <= -3.5) {
                                        return -0.00290511845317;
                                    } else {
                                        return -0.0154802729875;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.000405525191195;
                                    } else {
                                        return -0.0125909365746;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0494974799121;
                                    } else {
                                        return 0.00269054376822;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return -0.0153272552159;
                                    } else {
                                        return 0.15340661669;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1067.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.00114323659613;
                                    } else {
                                        return 0.0807754957123;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.118962756154;
                                    } else {
                                        return 0.0166719966583;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0392638466991;
                                    } else {
                                        return 0.00294933706582;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.00650066334589;
                                    } else {
                                        return -0.0201193490617;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[88] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0389229702097;
                                    } else {
                                        return 0.0657118039386;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return 0.0145127747623;
                                    } else {
                                        return 0.387840646203;
                                    }
                                }
                            } else {
                                if (fs[50] <= 27.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.0244211170569;
                                    } else {
                                        return 0.0256903507184;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.203709279392;
                                    } else {
                                        return -0.0400761337607;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[69] <= 9548.0) {
                                    if (fs[4] <= 20.0) {
                                        return -0.0291486527999;
                                    } else {
                                        return 0.105539394064;
                                    }
                                } else {
                                    return 0.153315187213;
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return 0.635810655257;
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.299420153746;
                                    } else {
                                        return 0.18218517001;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[69] <= 9989.5) {
                                        return 0.0317632027858;
                                    } else {
                                        return 0.413146785214;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.00423147420534;
                                    } else {
                                        return -0.0170836056584;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1098.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.184599269782;
                                    } else {
                                        return 0.391251053693;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0147278096725;
                                    } else {
                                        return 0.147263589016;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.00388759616187;
                                    } else {
                                        return -0.0207656153507;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0159462784946;
                                    } else {
                                        return -0.017052769975;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0151022565688;
                                    } else {
                                        return -0.0116675831574;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.00408837743836;
                                    } else {
                                        return 0.123210052942;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
