/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree0 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[73] <= 100.0) {
                    if (fs[2] <= 1.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.817038240272;
                                    } else {
                                        return 0.908518687199;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.928914880692;
                                    } else {
                                        return 0.919481849294;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.81138497394;
                                    } else {
                                        return 0.670932413875;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.917647996369;
                                    } else {
                                        return 0.882328418843;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.843999024585;
                                    } else {
                                        return 0.775371573605;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.758038240272;
                                    } else {
                                        return 0.567571806434;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4984.0) {
                                    if (fs[39] <= 0.5) {
                                        return 0.897111246636;
                                    } else {
                                        return 0.686719091336;
                                    }
                                } else {
                                    return 0.671204906938;
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 12.5) {
                                if (fs[11] <= 0.5) {
                                    return 0.942038240272;
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.930744082663;
                                    } else {
                                        return 0.91149622708;
                                    }
                                }
                            } else {
                                return 0.382038240272;
                            }
                        } else {
                            if (fs[56] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.268568852517;
                                    } else {
                                        return 0.275371573605;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.631693412685;
                                    } else {
                                        return 0.451129149363;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return 0.902434279876;
                                } else {
                                    return 0.851129149363;
                                }
                            }
                        }
                    }
                } else {
                    return 0.20212792637;
                }
            } else {
                if (fs[95] <= 0.5) {
                    if (fs[4] <= 2.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[50] <= -1068.0) {
                                if (fs[0] <= 1.5) {
                                    return 0.417844691885;
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.620400813371;
                                    } else {
                                        return 0.44888755534;
                                    }
                                }
                            } else {
                                return 0.0329473311808;
                            }
                        } else {
                            return 0.12385642209;
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.114868793813;
                                    } else {
                                        return 0.246888124798;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return -0.00832204795889;
                                    } else {
                                        return 0.0846808829143;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0579617597283;
                                    } else {
                                        return 0.440368233592;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return 0.0475937958273;
                                    } else {
                                        return 0.811603457663;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[67] <= -1.5) {
                                        return -0.0244587911108;
                                    } else {
                                        return 0.246386066359;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0360799216539;
                                    } else {
                                        return -0.0579617597283;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0579617597283;
                                    } else {
                                        return -0.0439365142865;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0403988960094;
                                    } else {
                                        return -0.0406831420177;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 27.5) {
                        if (fs[50] <= -1138.0) {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 25.5) {
                                    if (fs[4] <= 23.5) {
                                        return -0.00377456761008;
                                    } else {
                                        return -0.0579617597283;
                                    }
                                } else {
                                    return 0.0395992158815;
                                }
                            } else {
                                if (fs[50] <= -1293.0) {
                                    return -0.0579617597283;
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.055908371638;
                                    } else {
                                        return -0.0434690061051;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 26.5) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0335715158259;
                                    } else {
                                        return -0.0551684636389;
                                    }
                                } else {
                                    return -0.0579617597283;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return -0.0114501318213;
                                } else {
                                    return -0.0579617597283;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1578.0) {
                            return 0.00586802750574;
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[57] <= 0.5) {
                                        return -0.053677794;
                                    } else {
                                        return -0.0329617597283;
                                    }
                                } else {
                                    return -0.0579617597283;
                                }
                            } else {
                                return -0.0579617597283;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[73] <= 75.0) {
                if (fs[0] <= 0.5) {
                    if (fs[74] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[46] <= -0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.520985608693;
                                    } else {
                                        return 0.753819849467;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.469268831233;
                                    } else {
                                        return 0.758749830568;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.741569468729;
                                    } else {
                                        return 0.232854566802;
                                    }
                                } else {
                                    if (fs[61] <= -995.5) {
                                        return 0.745578063281;
                                    } else {
                                        return 0.525079432209;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[69] <= 9843.0) {
                                        return 0.282605113611;
                                    } else {
                                        return 0.383459495073;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.604673016693;
                                    } else {
                                        return 0.469735798686;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[50] <= -1488.5) {
                                        return 0.237938418525;
                                    } else {
                                        return 0.0664622034053;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.616456844923;
                                    } else {
                                        return 0.327724124964;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[50] <= -1314.0) {
                                        return 0.0135899644096;
                                    } else {
                                        return 0.677038240272;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.873920545794;
                                    } else {
                                        return 0.575749747565;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.382038240272;
                                    } else {
                                        return 0.263877320731;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.626248766587;
                                    } else {
                                        return 0.249730547964;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.922701223697;
                                    } else {
                                        return 0.832663240272;
                                    }
                                } else {
                                    if (fs[69] <= 9902.0) {
                                        return 0.521850446844;
                                    } else {
                                        return 0.911269009502;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.863090871851;
                                    } else {
                                        return 0.608704906938;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.705196135009;
                                    } else {
                                        return 0.230698034086;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[69] <= 9893.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00120875604539;
                                    } else {
                                        return 0.137988823662;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.14269754943;
                                    } else {
                                        return 0.306417325239;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9992.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0249766288973;
                                    } else {
                                        return 0.0767003695862;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.183987042914;
                                    } else {
                                        return 0.325533385903;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9866.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.0168072020638;
                                    } else {
                                        return -0.0441741420695;
                                    }
                                } else {
                                    if (fs[50] <= -1438.0) {
                                        return 0.146082357919;
                                    } else {
                                        return 0.0347927686914;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.084449233401;
                                    } else {
                                        return 0.0495956911127;
                                    }
                                } else {
                                    if (fs[50] <= -1133.5) {
                                        return 0.407687095234;
                                    } else {
                                        return 0.100628548642;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 0.5) {
                            if (fs[69] <= 9982.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0534272635489;
                                    } else {
                                        return -0.05643536795;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0314374745061;
                                    } else {
                                        return -0.0479584142388;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[69] <= 9995.5) {
                                        return -0.00645042471571;
                                    } else {
                                        return 0.0328038282749;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.227056510674;
                                    } else {
                                        return 0.0277123975751;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[0] <= 6.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0194865422948;
                                    } else {
                                        return 0.016523325499;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0507487747067;
                                    } else {
                                        return -0.03446084604;
                                    }
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    if (fs[69] <= 9998.5) {
                                        return -0.0567527418775;
                                    } else {
                                        return -0.0263828123599;
                                    }
                                } else {
                                    return 0.0309271291606;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[39] <= 0.5) {
                    if (fs[69] <= 9774.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.681349404167;
                                    } else {
                                        return 0.393102070059;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.848146266521;
                                    } else {
                                        return 0.548247390598;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.522858039189;
                                    } else {
                                        return 0.741025948153;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.194785493019;
                                    } else {
                                        return 0.582663240272;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0680720632565;
                                    } else {
                                        return -0.035565099199;
                                    }
                                } else {
                                    if (fs[59] <= -2.5) {
                                        return -0.0341522359188;
                                    } else {
                                        return -0.0575449586098;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0487026742972;
                                    } else {
                                        return -0.0562517734082;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.630963321705;
                                    } else {
                                        return -0.0579617597283;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.647088745322;
                                    } else {
                                        return 0.0684072377443;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.4335393176;
                                    } else {
                                        return 0.0377474443624;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.671361548542;
                                    } else {
                                        return 0.873675760144;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.0793644434803;
                                    } else {
                                        return 0.489012762565;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -995.5) {
                                return 0.0329473311808;
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 35.5) {
                                        return -0.056519650128;
                                    } else {
                                        return -0.0103427121093;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0702433684768;
                                    } else {
                                        return -0.0579617597283;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[50] <= -1008.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.741330526188;
                                    } else {
                                        return 0.857667854277;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.924300944011;
                                    } else {
                                        return 0.855634898076;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.469401424351;
                                    } else {
                                        return 0.717038240272;
                                    }
                                } else {
                                    return 0.12385642209;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[91] <= 0.5) {
                                    return -0.0579617597283;
                                } else {
                                    if (fs[61] <= -496.5) {
                                        return 0.699932977114;
                                    } else {
                                        return 0.282778981012;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[59] <= -1.5) {
                                        return 0.942038240272;
                                    } else {
                                        return 0.840772417487;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return 0.252383067858;
                                    } else {
                                        return 0.736155887331;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[97] <= 1.5) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.0265928379728;
                                    } else {
                                        return 0.388192086426;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.114049902079;
                                    } else {
                                        return 0.237782921123;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -988.0) {
                                        return 0.212176279761;
                                    } else {
                                        return -0.0047702703666;
                                    }
                                } else {
                                    if (fs[46] <= -0.5) {
                                        return 0.542038240272;
                                    } else {
                                        return 0.110815702148;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[59] <= -0.5) {
                                        return -0.050767515124;
                                    } else {
                                        return 0.00810430633776;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0530153458783;
                                    } else {
                                        return -0.0402626446841;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.0551960544735;
                                    } else {
                                        return -0.0578033982418;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0409163051828;
                                    } else {
                                        return -0.0534440876581;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
