/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree33 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 17.5) {
                if (fs[40] <= 0.5) {
                    if (fs[75] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.162604744887;
                                    } else {
                                        return 0.0619688367481;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.188787305899;
                                    } else {
                                        return 0.356198886108;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    return 0.336962928463;
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.290107315523;
                                    } else {
                                        return 0.217266794205;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.155837388101;
                                    } else {
                                        return 0.200820762344;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.187497079936;
                                    } else {
                                        return 0.255333264276;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.153358207771;
                                    } else {
                                        return 0.190419151593;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return 0.186280935997;
                                    } else {
                                        return 0.205606285345;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[69] <= 9971.5) {
                                    if (fs[50] <= -1504.0) {
                                        return 0.211594897386;
                                    } else {
                                        return 0.0403212314784;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.187899352941;
                                    } else {
                                        return 0.101778011635;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[50] <= -1013.5) {
                                        return 0.155542717271;
                                    } else {
                                        return 0.0423777611078;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.170566592271;
                                    } else {
                                        return 0.0700562590104;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.119796868574;
                                    } else {
                                        return 0.179823058506;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.206708913782;
                                    } else {
                                        return -0.20244375328;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.192688728222;
                                    } else {
                                        return -0.147718762378;
                                    }
                                } else {
                                    if (fs[69] <= 4998.5) {
                                        return -0.34292197317;
                                    } else {
                                        return 0.0885223394714;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[68] <= 0.5) {
                        if (fs[82] <= 6.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[75] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.204872431416;
                                    } else {
                                        return 0.196741537633;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.113074223794;
                                    } else {
                                        return 0.0272055837067;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[77] <= 0.5) {
                                        return 0.238114334404;
                                    } else {
                                        return 0.0227559374744;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.28249875972;
                                    } else {
                                        return -0.0753245162457;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                return 0.158032310844;
                            } else {
                                return 0.292665537321;
                            }
                        }
                    } else {
                        if (fs[73] <= 75.0) {
                            if (fs[48] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[50] <= -456.5) {
                                        return -0.0891293204217;
                                    } else {
                                        return -0.365397523483;
                                    }
                                } else {
                                    if (fs[50] <= -1458.0) {
                                        return 0.24695107143;
                                    } else {
                                        return -0.0382218429814;
                                    }
                                }
                            } else {
                                return 0.238695710813;
                            }
                        } else {
                            if (fs[77] <= 0.5) {
                                if (fs[4] <= 15.5) {
                                    if (fs[73] <= 350.0) {
                                        return 0.0156364693319;
                                    } else {
                                        return 0.325502201539;
                                    }
                                } else {
                                    return -0.28548908607;
                                }
                            } else {
                                return -0.361003438017;
                            }
                        }
                    }
                }
            } else {
                if (fs[84] <= 0.5) {
                    if (fs[69] <= 9929.0) {
                        if (fs[11] <= 0.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[4] <= 42.5) {
                                    if (fs[50] <= -2003.0) {
                                        return 0.218881067845;
                                    } else {
                                        return 0.00899618710223;
                                    }
                                } else {
                                    return -0.330784403605;
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[82] <= 2.5) {
                                        return 0.306455993263;
                                    } else {
                                        return 0.174647593928;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.168536420058;
                                    } else {
                                        return -0.0769715352033;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1588.0) {
                                if (fs[18] <= 0.5) {
                                    if (fs[50] <= -2653.0) {
                                        return 0.456092977015;
                                    } else {
                                        return 0.0430709090054;
                                    }
                                } else {
                                    return 0.413342088791;
                                }
                            } else {
                                if (fs[2] <= 9.5) {
                                    if (fs[59] <= -0.5) {
                                        return 0.209453542891;
                                    } else {
                                        return -0.0965720073007;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return 0.100809901258;
                                    } else {
                                        return 0.339366016045;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 22.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[25] <= 0.5) {
                                        return 0.195805462338;
                                    } else {
                                        return 0.0656161631289;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.0150446151967;
                                    } else {
                                        return -0.0560140294762;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.30052838266;
                                    } else {
                                        return -0.283639375044;
                                    }
                                } else {
                                    return -0.00735924923408;
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[80] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.137732646887;
                                    } else {
                                        return -0.0168988760652;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.179529144808;
                                    } else {
                                        return 0.463572183728;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1438.0) {
                                    if (fs[4] <= 37.0) {
                                        return 0.346105313898;
                                    } else {
                                        return 0.0413135817855;
                                    }
                                } else {
                                    if (fs[69] <= 9997.0) {
                                        return 0.292105496525;
                                    } else {
                                        return 0.0916929147025;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[77] <= 0.5) {
                        if (fs[50] <= -2008.0) {
                            if (fs[68] <= 0.5) {
                                if (fs[67] <= -4.0) {
                                    return 0.25242834121;
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.355291119576;
                                    } else {
                                        return 0.378658722657;
                                    }
                                }
                            } else {
                                if (fs[4] <= 20.5) {
                                    if (fs[73] <= 50.0) {
                                        return 0.267776865174;
                                    } else {
                                        return -0.142042422509;
                                    }
                                } else {
                                    if (fs[50] <= -2978.0) {
                                        return 0.14176717326;
                                    } else {
                                        return 0.289941807745;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1478.0) {
                                if (fs[67] <= -1.5) {
                                    if (fs[4] <= 39.5) {
                                        return 0.0240310226463;
                                    } else {
                                        return 0.484339796943;
                                    }
                                } else {
                                    return -0.420203653753;
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return 0.203514029996;
                                    } else {
                                        return 0.377415108238;
                                    }
                                } else {
                                    if (fs[61] <= -995.5) {
                                        return 0.22688034585;
                                    } else {
                                        return 0.0852381130136;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0268644213945;
                                    } else {
                                        return -0.2485258453;
                                    }
                                } else {
                                    return 0.410723451049;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.23177304684;
                                } else {
                                    return -0.381275248076;
                                }
                            }
                        } else {
                            return 0.307276614117;
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[44] <= 0.5) {
                    if (fs[99] <= 0.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[4] <= 19.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0779784080258;
                                    } else {
                                        return 0.0460307484942;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.00318112497101;
                                    } else {
                                        return 0.0383764354348;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[52] <= 496.5) {
                                        return -0.00448808272661;
                                    } else {
                                        return 0.430763960266;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.140222467483;
                                    } else {
                                        return 0.225866266203;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.07089854527;
                                    } else {
                                        return 0.22895425452;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.120265905316;
                                    } else {
                                        return 0.519811191261;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0153302087177;
                                    } else {
                                        return -0.0627607547199;
                                    }
                                } else {
                                    if (fs[50] <= -1318.0) {
                                        return 0.370983898067;
                                    } else {
                                        return 0.106452318878;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 6.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[82] <= 1.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0265731734594;
                                    } else {
                                        return -0.0419215637541;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.0159423443017;
                                    } else {
                                        return -0.029271491441;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[69] <= 9988.5) {
                                        return 0.0212079104906;
                                    } else {
                                        return 0.135322336681;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return -0.00371470552261;
                                    } else {
                                        return 0.10923669059;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1363.0) {
                                if (fs[2] <= 1.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.0320391945397;
                                    } else {
                                        return -0.0735612749816;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.237965153312;
                                    } else {
                                        return 0.0413627616438;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0045129446169;
                                    } else {
                                        return -0.0843055347682;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.170688167283;
                                    } else {
                                        return -0.0300414340026;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[65] <= 1.5) {
                        if (fs[92] <= 0.5) {
                            if (fs[46] <= -2.5) {
                                if (fs[97] <= 1.5) {
                                    return -0.0117843596304;
                                } else {
                                    return 0.10886407634;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[67] <= -3.5) {
                                        return -0.0608855513409;
                                    } else {
                                        return -0.0129238319585;
                                    }
                                } else {
                                    if (fs[2] <= 11.5) {
                                        return -0.0259787621296;
                                    } else {
                                        return 0.105533449299;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9915.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[50] <= -941.5) {
                                        return -0.0285220496423;
                                    } else {
                                        return -0.0428188442427;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.0482090228732;
                                    } else {
                                        return -0.0432520220314;
                                    }
                                }
                            } else {
                                if (fs[50] <= -457.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0792573773198;
                                    } else {
                                        return -0.0900024940043;
                                    }
                                } else {
                                    return -0.0960005375292;
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            return 0.255797869522;
                        } else {
                            return 0.00252627855622;
                        }
                    }
                }
            } else {
                if (fs[0] <= 5.5) {
                    if (fs[54] <= 0.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0146749231754;
                                    } else {
                                        return -0.00451030430167;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0110864943457;
                                    } else {
                                        return -0.0207754773837;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.00240833298912;
                                    } else {
                                        return -0.00641373151773;
                                    }
                                } else {
                                    if (fs[69] <= 9983.5) {
                                        return 0.00189696497472;
                                    } else {
                                        return 0.056675065983;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[69] <= 9995.5) {
                                    if (fs[82] <= 5.5) {
                                        return -0.0108141165891;
                                    } else {
                                        return -0.0184961464801;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.0436381472333;
                                    } else {
                                        return -0.0273042566004;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.00918135728699;
                                    } else {
                                        return -0.00614755537729;
                                    }
                                } else {
                                    if (fs[50] <= -1428.0) {
                                        return 0.0542523206148;
                                    } else {
                                        return -0.0414742128882;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 7.5) {
                            if (fs[95] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    return -0.0494286984507;
                                } else {
                                    if (fs[82] <= 1.0) {
                                        return -0.0427569511396;
                                    } else {
                                        return 0.0913479237195;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.308774579939;
                                    } else {
                                        return 0.015790204337;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.126227340519;
                                    } else {
                                        return 0.392343450743;
                                    }
                                }
                            }
                        } else {
                            return 0.610582439517;
                        }
                    }
                } else {
                    if (fs[0] <= 20.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[0] <= 7.5) {
                                    if (fs[50] <= -1098.0) {
                                        return 0.00395395457697;
                                    } else {
                                        return -0.00521748729077;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return -0.00782852856245;
                                    } else {
                                        return -0.109405790925;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    return 0.249286204575;
                                } else {
                                    return -0.0310794418751;
                                }
                            }
                        } else {
                            if (fs[4] <= 14.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[50] <= 3.5) {
                                        return -0.00593333132139;
                                    } else {
                                        return -0.0124641546793;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0111234135484;
                                    } else {
                                        return -0.00777333412483;
                                    }
                                }
                            } else {
                                if (fs[82] <= 5.5) {
                                    if (fs[46] <= -2.5) {
                                        return 0.0927005742398;
                                    } else {
                                        return -0.0109487201448;
                                    }
                                } else {
                                    if (fs[69] <= 9983.5) {
                                        return -0.0136569906426;
                                    } else {
                                        return -0.0375667752441;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[54] <= 0.5) {
                            if (fs[97] <= 1.5) {
                                if (fs[0] <= 118.5) {
                                    if (fs[15] <= 0.5) {
                                        return -0.0115222533452;
                                    } else {
                                        return 0.06637911886;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.00886543441494;
                                    } else {
                                        return 0.0648619410882;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1078.0) {
                                    if (fs[39] <= 0.5) {
                                        return -0.000450016113214;
                                    } else {
                                        return 0.407429698604;
                                    }
                                } else {
                                    if (fs[50] <= 3.5) {
                                        return -0.0152594450056;
                                    } else {
                                        return -0.0105349377474;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                return 0.00950371321045;
                            } else {
                                return 0.130100082457;
                            }
                        }
                    }
                }
            }
        }
    }
}
