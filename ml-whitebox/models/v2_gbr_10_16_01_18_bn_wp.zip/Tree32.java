/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree32 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9985.5) {
            if (fs[75] <= 0.5) {
                if (fs[12] <= 0.5) {
                    if (fs[95] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[50] <= -983.0) {
                                        return 0.182562465142;
                                    } else {
                                        return -0.0241142545725;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.158179951345;
                                    } else {
                                        return 0.190615764009;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.334238945967;
                                    } else {
                                        return 0.327713256191;
                                    }
                                } else {
                                    if (fs[50] <= -1128.0) {
                                        return 0.225067402696;
                                    } else {
                                        return 0.294780932599;
                                    }
                                }
                            }
                        } else {
                            if (fs[15] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.282905247165;
                                    } else {
                                        return -0.0334578330328;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0101667927889;
                                    } else {
                                        return 0.0291445488909;
                                    }
                                }
                            } else {
                                if (fs[0] <= 25.5) {
                                    if (fs[0] <= 24.5) {
                                        return 0.0488162889857;
                                    } else {
                                        return 0.592600412275;
                                    }
                                } else {
                                    if (fs[0] <= 28.5) {
                                        return -0.0420150106492;
                                    } else {
                                        return -0.0703970941418;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[64] <= 0.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.31618204814;
                                    } else {
                                        return -0.0105105697188;
                                    }
                                } else {
                                    if (fs[50] <= -1568.0) {
                                        return -0.00439450920096;
                                    } else {
                                        return -0.0301459259233;
                                    }
                                }
                            } else {
                                return -0.128410433035;
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 9.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.000982144277277;
                                    } else {
                                        return -0.0151567207578;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return -0.0121547124578;
                                    } else {
                                        return -0.0147031903956;
                                    }
                                }
                            } else {
                                if (fs[73] <= 100.0) {
                                    return -0.0421548038125;
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0164619882588;
                                    } else {
                                        return -0.0130580659978;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1168.5) {
                        if (fs[4] <= 44.5) {
                            return -0.0588875199173;
                        } else {
                            if (fs[50] <= -1488.0) {
                                return -0.00550549544347;
                            } else {
                                return -0.0338136503226;
                            }
                        }
                    } else {
                        if (fs[4] <= 32.0) {
                            if (fs[0] <= 1.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.194375092599;
                                    } else {
                                        return 0.099041653927;
                                    }
                                } else {
                                    return 0.472618959272;
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0302218942812;
                                    } else {
                                        return -0.055857586328;
                                    }
                                } else {
                                    return 0.136151460883;
                                }
                            }
                        } else {
                            return -0.0174443769568;
                        }
                    }
                }
            } else {
                if (fs[73] <= 75.0) {
                    if (fs[0] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[86] <= 0.5) {
                                    if (fs[69] <= 9979.5) {
                                        return 0.232262697247;
                                    } else {
                                        return 0.14169345572;
                                    }
                                } else {
                                    if (fs[61] <= -496.5) {
                                        return 0.202887171205;
                                    } else {
                                        return 0.0983573905874;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1123.5) {
                                    if (fs[69] <= 9902.0) {
                                        return -0.0460320226135;
                                    } else {
                                        return 0.171606366043;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.235929059521;
                                    } else {
                                        return 0.369842900274;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0229355532107;
                                    } else {
                                        return 0.108185275525;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0751033183127;
                                    } else {
                                        return 0.104238178718;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.195963194038;
                                    } else {
                                        return 0.0991793615568;
                                    }
                                } else {
                                    if (fs[69] <= 4237.0) {
                                        return -0.0173511135225;
                                    } else {
                                        return -0.129564586429;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0292407416352;
                                    } else {
                                        return -0.033812854289;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0110389649678;
                                    } else {
                                        return 0.0778317174039;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0109860409795;
                                    } else {
                                        return -0.0130929890248;
                                    }
                                } else {
                                    if (fs[50] <= -1438.0) {
                                        return 0.0491393661958;
                                    } else {
                                        return -0.0107317970299;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.00373491650232;
                                    } else {
                                        return 0.125720782199;
                                    }
                                } else {
                                    if (fs[50] <= -1598.0) {
                                        return 0.170062211822;
                                    } else {
                                        return 0.0267027467872;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[50] <= -1062.0) {
                                        return 0.156296054379;
                                    } else {
                                        return 0.0276716291831;
                                    }
                                } else {
                                    if (fs[46] <= -2.5) {
                                        return 0.156199107262;
                                    } else {
                                        return -0.00929817348572;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[97] <= 1.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1493.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.182384047002;
                                    } else {
                                        return 0.329142747055;
                                    }
                                } else {
                                    if (fs[50] <= -1478.5) {
                                        return -0.0311108326391;
                                    } else {
                                        return 0.0937882780996;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.184345864447;
                                    } else {
                                        return 0.280310506648;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.129900133142;
                                    } else {
                                        return -0.0678156529948;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.018950986814;
                                    } else {
                                        return -0.0135896521373;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0145812495436;
                                    } else {
                                        return -0.005971797327;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0575892664775;
                                    } else {
                                        return 0.28135775711;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.00560814476408;
                                    } else {
                                        return 0.114037757308;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.178449835539;
                                    } else {
                                        return 0.146000551789;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.259890349435;
                                    } else {
                                        return 0.0468267976344;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0329720085124;
                                    } else {
                                        return 0.077844068966;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0323283084858;
                                    } else {
                                        return 0.00315168727434;
                                    }
                                }
                            }
                        } else {
                            if (fs[46] <= -2.5) {
                                if (fs[61] <= -995.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.15535501779;
                                    } else {
                                        return -0.0322025796559;
                                    }
                                } else {
                                    return -0.0448683331692;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return -0.0661872650409;
                                    } else {
                                        return 0.164143820579;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0132325389534;
                                    } else {
                                        return -0.0110857101585;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[33] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[18] <= -0.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[95] <= 0.5) {
                                    return -0.232887022459;
                                } else {
                                    return -0.407963287436;
                                }
                            } else {
                                return -0.134137521485;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.177588653099;
                                    } else {
                                        return 0.0397766833393;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.144826933584;
                                    } else {
                                        return 0.214156127374;
                                    }
                                }
                            } else {
                                if (fs[4] <= 30.5) {
                                    if (fs[42] <= 0.5) {
                                        return 0.183848245709;
                                    } else {
                                        return 0.00709760721898;
                                    }
                                } else {
                                    if (fs[50] <= -1733.0) {
                                        return 0.243511388972;
                                    } else {
                                        return -0.243458387912;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            return 0.121183222844;
                        } else {
                            if (fs[4] <= 9.0) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[69] <= 9992.5) {
                                        return 0.402608816742;
                                    } else {
                                        return 0.348101246419;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.239715223791;
                                    } else {
                                        return 0.26834228083;
                                    }
                                }
                            } else {
                                return 0.408963480068;
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1098.0) {
                        if (fs[52] <= 0.5) {
                            if (fs[50] <= -1128.0) {
                                if (fs[0] <= 16.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.081325236873;
                                    } else {
                                        return 0.00428497269473;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0203370177515;
                                    } else {
                                        return 0.0552595536692;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    return -0.0148764256735;
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.160986564864;
                                    } else {
                                        return 0.58254134355;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                return 0.52328986367;
                            } else {
                                return 0.144155426903;
                            }
                        }
                    } else {
                        if (fs[37] <= 0.5) {
                            if (fs[8] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0578460050543;
                                    } else {
                                        return -0.0180262253502;
                                    }
                                } else {
                                    if (fs[92] <= 0.5) {
                                        return -0.0132635733522;
                                    } else {
                                        return -0.0842756410328;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    return 0.302215815943;
                                } else {
                                    return -0.0227988053372;
                                }
                            }
                        } else {
                            if (fs[0] <= 8.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0530637881295;
                                    } else {
                                        return 0.252904832348;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.203775424058;
                                    } else {
                                        return 0.0326794574589;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0411828358825;
                                    } else {
                                        return -0.0358745699384;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.26137902011;
                                    } else {
                                        return -0.0405141452583;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 2.5) {
                    if (fs[69] <= 9999.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[50] <= -1108.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.19433707159;
                                    } else {
                                        return 0.0466886542943;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.121433889285;
                                    } else {
                                        return 0.0254855445623;
                                    }
                                }
                            } else {
                                if (fs[73] <= 100.0) {
                                    if (fs[50] <= 7.5) {
                                        return -0.0523545943983;
                                    } else {
                                        return -0.0475985117021;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0407119915831;
                                    } else {
                                        return -0.0212186751094;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.189490285402;
                                    } else {
                                        return 0.326333408177;
                                    }
                                } else {
                                    if (fs[50] <= -1428.0) {
                                        return 0.239737095651;
                                    } else {
                                        return 0.0429801525216;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return -0.00122225944466;
                                    } else {
                                        return 0.110305591079;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.042924846967;
                                    } else {
                                        return -0.0195029155833;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[82] <= 1.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.192548334226;
                                    } else {
                                        return 0.290814597671;
                                    }
                                } else {
                                    if (fs[73] <= 200.0) {
                                        return 0.119822771265;
                                    } else {
                                        return 0.317217283969;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    return 0.0465234868084;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.048966928546;
                                    } else {
                                        return -0.104798521008;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1608.0) {
                                if (fs[59] <= -0.5) {
                                    return -0.121890787181;
                                } else {
                                    if (fs[50] <= -1983.5) {
                                        return 0.210805894015;
                                    } else {
                                        return 0.31466501337;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0425345051809;
                                    } else {
                                        return 0.120604016051;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0938751288541;
                                    } else {
                                        return -0.0131987087287;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[82] <= 3.5) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.181449549115;
                                    } else {
                                        return 0.377460989975;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.234815433344;
                                    } else {
                                        return 0.119899698423;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.178891474672;
                                    } else {
                                        return 0.22591750431;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return 0.276239094545;
                                    } else {
                                        return 0.193285767712;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[61] <= -498.0) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.167902946042;
                                    } else {
                                        return 0.285381364414;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.100394988625;
                                    } else {
                                        return -0.000718999067731;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[73] <= 100.0) {
                                        return 0.202400335855;
                                    } else {
                                        return 0.322002777937;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0287544407613;
                                    } else {
                                        return 0.141872032276;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[91] <= 0.5) {
                            if (fs[2] <= 8.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[69] <= 9994.5) {
                                        return 0.0141515845597;
                                    } else {
                                        return 0.102485547491;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.118837087279;
                                    } else {
                                        return 0.0372066187906;
                                    }
                                }
                            } else {
                                return 0.528977008137;
                            }
                        } else {
                            if (fs[50] <= -1318.0) {
                                return 0.29767211182;
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0153750844561;
                                    } else {
                                        return -0.059908250833;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0595627629343;
                                    } else {
                                        return 0.00115929740917;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
