/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree76 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[50] <= -1498.5) {
                    if (fs[2] <= 0.5) {
                        return -0.163101960522;
                    } else {
                        if (fs[67] <= -1.5) {
                            if (fs[4] <= 12.5) {
                                if (fs[50] <= -2758.0) {
                                    if (fs[4] <= 9.5) {
                                        return -0.16097144069;
                                    } else {
                                        return -0.00113249100862;
                                    }
                                } else {
                                    if (fs[69] <= 4352.5) {
                                        return 0.0838510345919;
                                    } else {
                                        return 0.133574339687;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0766867621337;
                                    } else {
                                        return -0.0255195197644;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0586242011898;
                                    } else {
                                        return -0.00929163667247;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1548.0) {
                                return -0.0725400560614;
                            } else {
                                return -0.158704326316;
                            }
                        }
                    }
                } else {
                    if (fs[59] <= -0.5) {
                        if (fs[82] <= 7.5) {
                            if (fs[67] <= -4.0) {
                                if (fs[93] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return -0.0596336825829;
                                    } else {
                                        return -0.208963721792;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.00717701190976;
                                    } else {
                                        return 0.159737756592;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0280318617188;
                                    } else {
                                        return 0.102753029016;
                                    }
                                } else {
                                    if (fs[55] <= 0.5) {
                                        return 0.0302087811914;
                                    } else {
                                        return -0.0333830540413;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                return 0.0919403469805;
                            } else {
                                return 0.280050742132;
                            }
                        }
                    } else {
                        if (fs[50] <= -1488.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0895792455846;
                                    } else {
                                        return -0.042532723842;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0829254414014;
                                    } else {
                                        return -0.0492427369069;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.109531646583;
                                    } else {
                                        return -0.0922724664587;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return 0.117333721596;
                                    } else {
                                        return -0.000255769853992;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -987.5) {
                                if (fs[50] <= -1138.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.014477364696;
                                    } else {
                                        return 0.0684197214035;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0432019413043;
                                    } else {
                                        return -0.0802707689669;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.0478885318187;
                                    } else {
                                        return 0.0780297935366;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0132906590454;
                                    } else {
                                        return -0.027792381068;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[87] <= 0.5) {
                    if (fs[40] <= 0.5) {
                        if (fs[8] <= 0.5) {
                            if (fs[82] <= -0.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0945307862674;
                                    } else {
                                        return 0.071597015957;
                                    }
                                } else {
                                    return -0.280949570357;
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.025925226883;
                                    } else {
                                        return 0.0526293841861;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.0101878486057;
                                    } else {
                                        return 0.0378540516874;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 13.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.395757752916;
                                    } else {
                                        return -0.26107994136;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.111261311637;
                                    } else {
                                        return 0.0284106334551;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    return 0.157698523267;
                                } else {
                                    return -0.0696051236604;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[50] <= -1488.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[73] <= 150.0) {
                                        return -0.0499399496648;
                                    } else {
                                        return 0.203686687081;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0602277143912;
                                    } else {
                                        return 0.253996153787;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    if (fs[50] <= -491.5) {
                                        return -0.114328834618;
                                    } else {
                                        return -0.208492990933;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return -0.0245489045418;
                                    } else {
                                        return 0.158612984764;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9997.5) {
                                if (fs[50] <= -1948.0) {
                                    return 0.181365528817;
                                } else {
                                    if (fs[69] <= 9994.5) {
                                        return -0.0768406615934;
                                    } else {
                                        return -0.313210346722;
                                    }
                                }
                            } else {
                                return 0.177368947917;
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 0.5) {
                        if (fs[73] <= 150.0) {
                            if (fs[50] <= -1473.5) {
                                if (fs[69] <= 9905.0) {
                                    return -0.196207777897;
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.332389187863;
                                    } else {
                                        return -0.284984943112;
                                    }
                                }
                            } else {
                                return -0.0878074894228;
                            }
                        } else {
                            return -0.0846589156884;
                        }
                    } else {
                        return 0.0462045377048;
                    }
                }
            }
        } else {
            if (fs[52] <= 0.5) {
                if (fs[34] <= 0.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[82] <= 6.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[61] <= -998.5) {
                                    if (fs[50] <= -1128.0) {
                                        return 0.257115707251;
                                    } else {
                                        return 0.0300139162701;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.00838349714091;
                                    } else {
                                        return -0.0103138337926;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0109012298941;
                                    } else {
                                        return 0.00681273984233;
                                    }
                                } else {
                                    if (fs[35] <= 0.5) {
                                        return -0.0076613316926;
                                    } else {
                                        return 0.151348271644;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0235899732773;
                                    } else {
                                        return -0.00240456514861;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.129213073763;
                                    } else {
                                        return -0.0240904914977;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 15.0) {
                                        return -0.0188649483965;
                                    } else {
                                        return 0.36048355233;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.164136397502;
                                    } else {
                                        return 0.0747850633061;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 22.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return -0.00101875270314;
                                    } else {
                                        return -0.0106300064937;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.0205626876161;
                                    } else {
                                        return -0.00945011329767;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.00906298904985;
                                    } else {
                                        return 0.190406840233;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return 0.0207101996326;
                                    } else {
                                        return -0.00350506092662;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9753.5) {
                                if (fs[69] <= 9741.5) {
                                    if (fs[0] <= 6.5) {
                                        return -0.00429449090809;
                                    } else {
                                        return -0.00177985354932;
                                    }
                                } else {
                                    return 0.0865400716469;
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 37.5) {
                                        return -0.00695961030831;
                                    } else {
                                        return -0.0570955372549;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0121039788541;
                                    } else {
                                        return 0.0869111200603;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 4.5) {
                        return 0.157431138211;
                    } else {
                        if (fs[50] <= -1138.0) {
                            return -0.0446504595902;
                        } else {
                            return 0.185024162447;
                        }
                    }
                }
            } else {
                if (fs[73] <= 75.0) {
                    if (fs[52] <= 993.5) {
                        if (fs[50] <= -1237.5) {
                            if (fs[50] <= -1738.0) {
                                return 0.0396284554433;
                            } else {
                                return 0.34786672231;
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                return 0.234811103765;
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.0263145245656;
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0120610200252;
                                    } else {
                                        return -0.0350734012086;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 996.5) {
                            return -0.0645100656796;
                        } else {
                            return -0.114790936829;
                        }
                    }
                } else {
                    if (fs[50] <= -1478.0) {
                        return 0.261710365704;
                    } else {
                        return 0.0590901054569;
                    }
                }
            }
        }
    }
}
