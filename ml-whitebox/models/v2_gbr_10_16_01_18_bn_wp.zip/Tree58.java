/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree58 {
    public double calcTree(double... fs) {
        if (fs[97] <= 1.5) {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 8.5) {
                    if (fs[73] <= 75.0) {
                        if (fs[25] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0478462929241;
                                    } else {
                                        return 0.00881563897681;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0604260610378;
                                    } else {
                                        return -0.00200737213842;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1118.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0920867557065;
                                    } else {
                                        return -0.0291636560466;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.211884295669;
                                    } else {
                                        return -0.00940348997312;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[4] <= 3.5) {
                                    if (fs[82] <= 4.5) {
                                        return -0.128631782458;
                                    } else {
                                        return 0.198801309389;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0625415060953;
                                    } else {
                                        return 0.0947273758371;
                                    }
                                }
                            } else {
                                if (fs[82] <= 2.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.0314195951935;
                                    } else {
                                        return 0.102980388184;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0602979844019;
                                    } else {
                                        return 0.174325776915;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[50] <= -1488.0) {
                                if (fs[95] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0503328572508;
                                    } else {
                                        return 0.0671934390113;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0585218028096;
                                    } else {
                                        return 0.112875260452;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[50] <= -1284.0) {
                                        return 0.169025422045;
                                    } else {
                                        return 0.0337013872728;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.118961228479;
                                    } else {
                                        return 0.198472288645;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.103021861759;
                                    } else {
                                        return 0.0771937413358;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.0358753419521;
                                    } else {
                                        return 0.0971582115477;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[73] <= 150.0) {
                                        return -0.0162582785672;
                                    } else {
                                        return 0.0954826445781;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0092147260855;
                                    } else {
                                        return 0.1297197141;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[43] <= 0.5) {
                        if (fs[50] <= -1493.5) {
                            if (fs[67] <= -1.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 10.5) {
                                        return 0.130261485361;
                                    } else {
                                        return 0.275401398156;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0456549444778;
                                    } else {
                                        return 0.145840142737;
                                    }
                                }
                            } else {
                                if (fs[75] <= 0.5) {
                                    return -0.0545462969517;
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return -0.150343520543;
                                    } else {
                                        return -0.299889379195;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -995.5) {
                                if (fs[46] <= -1.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.147610092228;
                                    } else {
                                        return 0.106070357722;
                                    }
                                } else {
                                    if (fs[61] <= -997.5) {
                                        return 0.124263231292;
                                    } else {
                                        return 0.00962443381032;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.000860375203335;
                                    } else {
                                        return -0.0495296537474;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.0802556758563;
                                    } else {
                                        return 0.0192961571776;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 250.0) {
                            if (fs[18] <= -0.5) {
                                if (fs[69] <= 9976.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.008612480195;
                                    } else {
                                        return -0.172651493408;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.301381719199;
                                    } else {
                                        return -0.0703481622111;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0981823466867;
                                    } else {
                                        return -0.164296509748;
                                    }
                                } else {
                                    if (fs[50] <= -2178.0) {
                                        return 0.238685606268;
                                    } else {
                                        return -0.0687941103708;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    return 0.143221905011;
                                } else {
                                    return -0.119456391836;
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    return -0.13289033623;
                                } else {
                                    if (fs[69] <= 4997.5) {
                                        return -0.263632841176;
                                    } else {
                                        return -0.57873354147;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 2.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[82] <= -0.5) {
                                        return -0.017691993643;
                                    } else {
                                        return 0.00741618869646;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0913128684521;
                                    } else {
                                        return 0.154440432039;
                                    }
                                }
                            } else {
                                if (fs[50] <= -3443.0) {
                                    return 0.271118618192;
                                } else {
                                    if (fs[50] <= -341.5) {
                                        return -0.00720577694107;
                                    } else {
                                        return 0.00864280210713;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 17.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0699434116133;
                                    } else {
                                        return 0.00478531292574;
                                    }
                                } else {
                                    if (fs[50] <= -977.0) {
                                        return 0.154856608962;
                                    } else {
                                        return -0.043490280703;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0410494383465;
                                    } else {
                                        return -0.0938962098315;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.159826083417;
                                    } else {
                                        return -0.204711892397;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[67] <= -1.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0456998431183;
                                    } else {
                                        return -0.0328481988381;
                                    }
                                } else {
                                    if (fs[50] <= -17.5) {
                                        return -0.00636250256467;
                                    } else {
                                        return -0.0212687619513;
                                    }
                                }
                            } else {
                                return -0.0885869305517;
                            }
                        } else {
                            if (fs[86] <= 0.5) {
                                if (fs[50] <= -982.5) {
                                    if (fs[69] <= 9853.0) {
                                        return -0.0208899412583;
                                    } else {
                                        return -0.0579378392199;
                                    }
                                } else {
                                    if (fs[50] <= -17.5) {
                                        return -0.00207439884373;
                                    } else {
                                        return -0.0238288489112;
                                    }
                                }
                            } else {
                                if (fs[2] <= 11.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.0102022123374;
                                    } else {
                                        return 0.0787804289311;
                                    }
                                } else {
                                    return 0.0730582770959;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[14] <= 0.5) {
                        if (fs[0] <= 10.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[82] <= 3.5) {
                                        return 0.00152332993332;
                                    } else {
                                        return 0.0350352163071;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.00135267962935;
                                    } else {
                                        return -0.00463626887195;
                                    }
                                }
                            } else {
                                if (fs[69] <= 8714.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.00177204208187;
                                    } else {
                                        return 0.00507272530976;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.142925766357;
                                    } else {
                                        return 0.0103283962918;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 118.5) {
                                if (fs[0] <= 20.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.00334177056546;
                                    } else {
                                        return -0.00093648796541;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return -0.00352797593575;
                                    } else {
                                        return 0.0608733210925;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[95] <= 1.5) {
                                        return -0.0066022110874;
                                    } else {
                                        return 0.266915357016;
                                    }
                                } else {
                                    if (fs[0] <= 121.5) {
                                        return 0.0856056130394;
                                    } else {
                                        return -0.00349063353856;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 0.5) {
                            if (fs[0] <= 4.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0134868722417;
                                    } else {
                                        return 0.0517923098943;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.348298722563;
                                    } else {
                                        return -0.0237446990293;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9982.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0337254712966;
                                    } else {
                                        return -0.00452062576273;
                                    }
                                } else {
                                    if (fs[82] <= 3.0) {
                                        return 0.0892913288529;
                                    } else {
                                        return -0.0283997638278;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[0] <= 10.5) {
                                        return 0.0482562302111;
                                    } else {
                                        return -0.0116304213832;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.0103858479034;
                                    } else {
                                        return -0.0067030044916;
                                    }
                                }
                            } else {
                                return 0.203010713159;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[50] <= -1052.5) {
                if (fs[40] <= 0.5) {
                    if (fs[55] <= 0.5) {
                        if (fs[46] <= -0.5) {
                            if (fs[0] <= 4.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[59] <= -0.5) {
                                        return 0.0693079471286;
                                    } else {
                                        return -0.307887932406;
                                    }
                                } else {
                                    return -0.0538203025897;
                                }
                            } else {
                                return 0.503324444025;
                            }
                        } else {
                            if (fs[0] <= 21.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[59] <= -0.5) {
                                        return -0.0284469405004;
                                    } else {
                                        return 0.0433996403839;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.155606528369;
                                    } else {
                                        return -0.0389479053632;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    return 0.119548597664;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.51125948145;
                                    } else {
                                        return 0.306017982051;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1318.5) {
                            return -0.160399866704;
                        } else {
                            if (fs[2] <= 7.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.0344673172181;
                                    } else {
                                        return -0.0540201539887;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.00539285093558;
                                    } else {
                                        return 0.0893305643538;
                                    }
                                }
                            } else {
                                return 0.302516886691;
                            }
                        }
                    }
                } else {
                    if (fs[59] <= -1.5) {
                        return 0.280604698838;
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                return -0.302968444164;
                            } else {
                                return -0.0478764868881;
                            }
                        } else {
                            if (fs[59] <= -0.5) {
                                if (fs[4] <= 9.5) {
                                    return -0.197550548751;
                                } else {
                                    return -0.0357525987391;
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0389734687466;
                                    } else {
                                        return -0.015536517247;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.032776681269;
                                    } else {
                                        return -0.118961409361;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[59] <= -1.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[4] <= 16.0) {
                            return 0.0271790393165;
                        } else {
                            return 0.156570743805;
                        }
                    } else {
                        if (fs[61] <= -995.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[39] <= 0.5) {
                                    return 0.108494915554;
                                } else {
                                    return 0.00421052205852;
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.00825836054135;
                                    } else {
                                        return -0.00935765275254;
                                    }
                                } else {
                                    if (fs[59] <= -2.5) {
                                        return -0.0415081417211;
                                    } else {
                                        return -0.0145984173726;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -993.5) {
                                return -0.0438411041252;
                            } else {
                                return -0.0113576002865;
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[50] <= 7.5) {
                                if (fs[59] <= -0.5) {
                                    return 0.0470571791525;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.210914573188;
                                    } else {
                                        return -0.0769100686354;
                                    }
                                }
                            } else {
                                return 0.262270195605;
                            }
                        } else {
                            return 0.136961603442;
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0615733304569;
                                    } else {
                                        return -0.0294678121471;
                                    }
                                } else {
                                    return -0.0789793683108;
                                }
                            } else {
                                if (fs[4] <= 18.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.141648925195;
                                    } else {
                                        return -0.0239505126607;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0572249483325;
                                    } else {
                                        return -0.0181644900146;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0128374074615;
                                    } else {
                                        return -0.00366383725334;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.00765755729965;
                                    } else {
                                        return -0.0022518193324;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 25.5) {
                                        return -0.0262539654626;
                                    } else {
                                        return 0.000663970650079;
                                    }
                                } else {
                                    if (fs[0] <= 50.5) {
                                        return -0.00369419314014;
                                    } else {
                                        return 0.0183912892904;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
