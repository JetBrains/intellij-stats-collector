/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree30 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[50] <= -987.5) {
                if (fs[4] <= 18.5) {
                    if (fs[42] <= 0.5) {
                        if (fs[50] <= -1138.0) {
                            if (fs[71] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.179773617304;
                                    } else {
                                        return 0.241853741183;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0908384045518;
                                    } else {
                                        return 0.17205738444;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9902.0) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0535644624013;
                                    } else {
                                        return 0.117384533583;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.230717032001;
                                    } else {
                                        return 0.0130842964949;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1123.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.203531746951;
                                    } else {
                                        return 0.253950799718;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.240788754247;
                                    } else {
                                        return -0.0513670583627;
                                    }
                                }
                            } else {
                                if (fs[73] <= 350.0) {
                                    if (fs[82] <= 2.5) {
                                        return 0.227728906727;
                                    } else {
                                        return 0.297363961767;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.440478599119;
                                    } else {
                                        return 0.393296784471;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1468.0) {
                            if (fs[77] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[73] <= 150.0) {
                                        return -0.113918316171;
                                    } else {
                                        return 0.2008648919;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0408116520411;
                                    } else {
                                        return 0.249460980159;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    return -0.340632489113;
                                } else {
                                    return 0.0425575735961;
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                return 0.0239236577821;
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.110792785314;
                                    } else {
                                        return 0.00590087438155;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.218800457915;
                                    } else {
                                        return -0.295452971703;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[25] <= 0.5) {
                        if (fs[67] <= -1.5) {
                            if (fs[26] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[50] <= -1993.0) {
                                        return 0.255338360116;
                                    } else {
                                        return 0.0879195856489;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.172041697898;
                                    } else {
                                        return 0.056131434316;
                                    }
                                }
                            } else {
                                return -0.147313900756;
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    return 0.008626090373;
                                } else {
                                    return -0.178525348974;
                                }
                            } else {
                                if (fs[50] <= -1328.0) {
                                    if (fs[93] <= 0.5) {
                                        return -0.0186281862254;
                                    } else {
                                        return -0.340496231012;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.303499282126;
                                    } else {
                                        return -0.169057348954;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[50] <= -1653.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[4] <= 19.5) {
                                        return -0.254129394834;
                                    } else {
                                        return 0.114867171373;
                                    }
                                } else {
                                    if (fs[50] <= -2138.0) {
                                        return 0.366022833047;
                                    } else {
                                        return 0.180717960216;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.0276811393015;
                                    } else {
                                        return -0.12430414896;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.129074013543;
                                    } else {
                                        return 0.407343593593;
                                    }
                                }
                            }
                        } else {
                            if (fs[56] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.000792652137136;
                                    } else {
                                        return 0.142067192492;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.395937058558;
                                    } else {
                                        return 0.257557858054;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.365141177028;
                                    } else {
                                        return 0.337804287882;
                                    }
                                } else {
                                    return 0.23780450632;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 10.5) {
                    if (fs[50] <= -461.5) {
                        if (fs[78] <= 0.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    return -0.197246891556;
                                } else {
                                    return 0.256929642202;
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[69] <= 9853.0) {
                                        return -0.164693630261;
                                    } else {
                                        return 0.0317185675127;
                                    }
                                } else {
                                    return -0.304764221963;
                                }
                            }
                        } else {
                            return 0.22796302037;
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.141593383467;
                                    } else {
                                        return -0.00541564770362;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.218918934574;
                                    } else {
                                        return 6.45419410165e-06;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.203278717717;
                                    } else {
                                        return 0.270705346312;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.136677088675;
                                    } else {
                                        return -0.276698616842;
                                    }
                                }
                            }
                        } else {
                            if (fs[46] <= -0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0709424919705;
                                    } else {
                                        return 0.253466883545;
                                    }
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return 0.284747949779;
                                    } else {
                                        return 0.180379466476;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0279373380164;
                                    } else {
                                        return 0.15366857228;
                                    }
                                } else {
                                    return -0.200299238164;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 4.5) {
                        if (fs[54] <= 0.5) {
                            if (fs[46] <= -0.5) {
                                if (fs[4] <= 21.5) {
                                    if (fs[59] <= -2.5) {
                                        return 0.357974318573;
                                    } else {
                                        return 0.1800421454;
                                    }
                                } else {
                                    if (fs[46] <= -1.5) {
                                        return 0.179508351766;
                                    } else {
                                        return -0.184643381005;
                                    }
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.124822198088;
                                    } else {
                                        return -0.0215159615249;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.0560422081888;
                                    } else {
                                        return 0.290267039623;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -994.0) {
                                if (fs[2] <= 1.5) {
                                    return 0.211021914597;
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.379695399616;
                                    } else {
                                        return 0.350215946937;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    return 0.54887127748;
                                } else {
                                    return 0.402928275328;
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.197580602937;
                                    } else {
                                        return 0.317355604167;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.164886811199;
                                    } else {
                                        return -0.0641955332063;
                                    }
                                }
                            } else {
                                if (fs[73] <= 150.0) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.105127754038;
                                    } else {
                                        return -0.18828369744;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.265329300573;
                                    } else {
                                        return 0.398964908653;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    return -0.0885298181463;
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return -0.348294482122;
                                    } else {
                                        return -0.204584881552;
                                    }
                                }
                            } else {
                                return 0.226268441934;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[84] <= 0.5) {
                if (fs[4] <= 11.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[69] <= 9993.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[0] <= 25.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0375072954434;
                                    } else {
                                        return 0.141740347073;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.00805901170807;
                                    } else {
                                        return -0.0639143644862;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 9.5) {
                                        return 0.00168104747481;
                                    } else {
                                        return -0.0124042789961;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.000260037305745;
                                    } else {
                                        return 0.0837029082343;
                                    }
                                }
                            }
                        } else {
                            if (fs[29] <= 0.5) {
                                if (fs[0] <= 8.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.141214659638;
                                    } else {
                                        return 0.0258475896362;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0343104092991;
                                    } else {
                                        return -0.0378784992933;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    return -0.0540618176349;
                                } else {
                                    return -0.281693882758;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[25] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.148080000597;
                                    } else {
                                        return 0.00563130423707;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.0215083490274;
                                    } else {
                                        return 0.105148659903;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[50] <= -1118.5) {
                                        return 0.0341379206714;
                                    } else {
                                        return -0.000444076916606;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0719537635261;
                                    } else {
                                        return 0.224218310483;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 18.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[69] <= 9995.5) {
                                        return -0.0105610980753;
                                    } else {
                                        return 0.0112931800988;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0111489274891;
                                    } else {
                                        return -0.00436433167405;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.0130554680585;
                                    } else {
                                        return -0.017470703977;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0127437721937;
                                    } else {
                                        return 0.230250394596;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[2] <= 6.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return -0.0110604154432;
                                    } else {
                                        return 0.007024890777;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return -0.0129923158709;
                                    } else {
                                        return -0.018354726844;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1242.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.339498891748;
                                    } else {
                                        return 0.063653021393;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return -0.033422261953;
                                    } else {
                                        return 0.0117877861427;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 24.5) {
                                if (fs[69] <= 9996.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.034489163803;
                                    } else {
                                        return -0.00798639544666;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.182609386509;
                                    } else {
                                        return 0.525503177549;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1.0) {
                                    if (fs[2] <= 11.5) {
                                        return -0.016475988956;
                                    } else {
                                        return -0.0298438236374;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0316775546294;
                                    } else {
                                        return 0.0606236755349;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[59] <= -2.5) {
                            return 0.251213033006;
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.00678227523356;
                                    } else {
                                        return 0.0547062602785;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.00639748899229;
                                    } else {
                                        return 0.083188524301;
                                    }
                                }
                            } else {
                                if (fs[0] <= 120.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0380054564029;
                                    } else {
                                        return -0.011089543943;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.017435374146;
                                    } else {
                                        return 0.134537383458;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0279688484288;
                                    } else {
                                        return 0.0778266929912;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.0551042833319;
                                    } else {
                                        return -0.0237059916931;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.305041929759;
                                    } else {
                                        return 0.0394992405046;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0696144697536;
                                    } else {
                                        return 0.0773144452789;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 29.5) {
                                if (fs[50] <= -1068.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.336670352602;
                                    } else {
                                        return 0.149111459747;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return -0.0856642172255;
                                    } else {
                                        return 0.0854831320672;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.00885857597435;
                                    } else {
                                        return 0.12018769934;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.103134661061;
                                    } else {
                                        return -0.077009419073;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[59] <= -2.5) {
                            if (fs[4] <= 20.0) {
                                return -0.0369991077181;
                            } else {
                                return 0.232076225633;
                            }
                        } else {
                            if (fs[95] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    return -0.00975764662782;
                                } else {
                                    return -0.0668288458022;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0657452869832;
                                    } else {
                                        return -0.0171100294927;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0255188313101;
                                    } else {
                                        return -0.0813715692449;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[79] <= 0.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[50] <= -1453.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.138317291283;
                                    } else {
                                        return 0.00806779430941;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.010590231702;
                                    } else {
                                        return 0.00581157237456;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.166811782991;
                                    } else {
                                        return 0.505117889524;
                                    }
                                } else {
                                    if (fs[50] <= -566.5) {
                                        return 0.364567343484;
                                    } else {
                                        return 0.118923681031;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[59] <= -1.5) {
                                    if (fs[0] <= 6.5) {
                                        return -0.0243569281728;
                                    } else {
                                        return -0.0165478872737;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0198125508305;
                                    } else {
                                        return -0.0145749896153;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0124186184333;
                                    } else {
                                        return -0.0134953342937;
                                    }
                                } else {
                                    if (fs[46] <= -2.5) {
                                        return -0.0409071669919;
                                    } else {
                                        return -0.0145970512638;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1418.0) {
                            if (fs[69] <= 9998.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[50] <= -1478.0) {
                                        return 0.0555486056035;
                                    } else {
                                        return 0.107390507455;
                                    }
                                } else {
                                    if (fs[50] <= -1458.0) {
                                        return 0.0365521292335;
                                    } else {
                                        return 0.316618280445;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[50] <= -1913.0) {
                                        return 0.509873016052;
                                    } else {
                                        return 0.206922702196;
                                    }
                                } else {
                                    return -0.143130272108;
                                }
                            }
                        } else {
                            if (fs[43] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[69] <= 9998.5) {
                                        return -0.00945972215954;
                                    } else {
                                        return 0.350565033775;
                                    }
                                } else {
                                    if (fs[4] <= 28.5) {
                                        return -0.0179226746252;
                                    } else {
                                        return 0.0194014325024;
                                    }
                                }
                            } else {
                                if (fs[0] <= 18.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0261388706297;
                                    } else {
                                        return -0.0493935590576;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.0226094714885;
                                    } else {
                                        return -0.0135850611333;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
