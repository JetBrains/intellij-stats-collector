/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree36 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[2] <= 1.5) {
                    if (fs[50] <= -987.5) {
                        if (fs[50] <= -1138.5) {
                            if (fs[50] <= -1498.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.0295509541293;
                                    } else {
                                        return 0.21910753919;
                                    }
                                } else {
                                    return -0.0134688331241;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.122080751312;
                                    } else {
                                        return -0.0728921230932;
                                    }
                                } else {
                                    if (fs[69] <= 9996.5) {
                                        return 0.0344898192298;
                                    } else {
                                        return 0.112609809794;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[50] <= -1118.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.160296760858;
                                    } else {
                                        return 0.134517242424;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.199414158949;
                                    } else {
                                        return 0.127971618327;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return 0.139767399976;
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.150816838471;
                                    } else {
                                        return -0.0254205685937;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9999.5) {
                            if (fs[61] <= -996.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return -0.143167597275;
                                    } else {
                                        return 0.255219290394;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0420339032075;
                                    } else {
                                        return 0.206232659821;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0154856859522;
                                    } else {
                                        return -0.0842484196238;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.0587074916347;
                                    } else {
                                        return -0.0770709826666;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -997.5) {
                                return 0.22364155261;
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.100813236126;
                                    } else {
                                        return 0.23534936163;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0540881275658;
                                    } else {
                                        return 0.0470557309103;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[25] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.158235658624;
                                    } else {
                                        return -0.0909802400682;
                                    }
                                } else {
                                    if (fs[69] <= 9902.0) {
                                        return -0.0330777490834;
                                    } else {
                                        return 0.178490065249;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.1499515815;
                                    } else {
                                        return 0.0700055246604;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.170532632015;
                                    } else {
                                        return 0.338011240425;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return -0.103232857469;
                                    } else {
                                        return 0.0770794672688;
                                    }
                                } else {
                                    return 0.400496944201;
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.0427801802466;
                                    } else {
                                        return 0.166639209908;
                                    }
                                } else {
                                    return -0.296354607652;
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 6.5) {
                            if (fs[95] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.020152772705;
                                    } else {
                                        return 0.118950952955;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.0907913428911;
                                    } else {
                                        return 0.245256989567;
                                    }
                                }
                            } else {
                                if (fs[50] <= -978.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.130538437061;
                                    } else {
                                        return 0.209110978846;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.19470327003;
                                    } else {
                                        return -0.330809127864;
                                    }
                                }
                            }
                        } else {
                            if (fs[56] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[69] <= 9886.0) {
                                        return 0.128597185931;
                                    } else {
                                        return 0.215377479596;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return -0.232785264492;
                                    } else {
                                        return 0.270648772952;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.183200306367;
                                    } else {
                                        return 0.246437228517;
                                    }
                                } else {
                                    if (fs[69] <= 9921.0) {
                                        return 0.265460430977;
                                    } else {
                                        return 0.214479338686;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[11] <= 0.5) {
                    if (fs[83] <= 0.5) {
                        if (fs[73] <= 25.0) {
                            if (fs[4] <= 25.5) {
                                if (fs[59] <= -2.5) {
                                    return 0.327168064694;
                                } else {
                                    if (fs[67] <= -4.5) {
                                        return -0.196295989893;
                                    } else {
                                        return -0.0311355227706;
                                    }
                                }
                            } else {
                                if (fs[67] <= -4.0) {
                                    if (fs[69] <= 9990.0) {
                                        return 0.221881055483;
                                    } else {
                                        return 0.406571303279;
                                    }
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return 0.408581045864;
                                    } else {
                                        return -0.02835461744;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.141178118867;
                                    } else {
                                        return -0.254245005996;
                                    }
                                } else {
                                    if (fs[61] <= -994.5) {
                                        return 0.0966411120438;
                                    } else {
                                        return 0.292343957417;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[46] <= -3.5) {
                                        return -0.151798455828;
                                    } else {
                                        return 0.0841012423154;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.21037696919;
                                    } else {
                                        return 0.43300912292;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            return 0.289343866339;
                        } else {
                            if (fs[52] <= -0.5) {
                                return 0.0380392658015;
                            } else {
                                if (fs[4] <= 23.5) {
                                    if (fs[50] <= -1318.0) {
                                        return 0.285134351423;
                                    } else {
                                        return 0.231259191926;
                                    }
                                } else {
                                    if (fs[50] <= -490.5) {
                                        return 0.181077725557;
                                    } else {
                                        return -0.0610138076875;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[99] <= 0.5) {
                        if (fs[4] <= 26.5) {
                            if (fs[73] <= 25.0) {
                                if (fs[50] <= -1458.0) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0609952168598;
                                    } else {
                                        return 0.293817780682;
                                    }
                                } else {
                                    if (fs[69] <= 9088.5) {
                                        return -0.0861198299197;
                                    } else {
                                        return 0.0654857157448;
                                    }
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.0893061851835;
                                    } else {
                                        return 0.268160808615;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.131636990243;
                                    } else {
                                        return 0.0610823521219;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9998.5) {
                                if (fs[50] <= -2138.0) {
                                    if (fs[50] <= -2453.0) {
                                        return 0.408986018382;
                                    } else {
                                        return 0.296353864575;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.150076396199;
                                    } else {
                                        return -0.0410391419926;
                                    }
                                }
                            } else {
                                if (fs[4] <= 35.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.0183787192912;
                                    } else {
                                        return 0.22465542526;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.202484983864;
                                    } else {
                                        return 0.0218555353778;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 6.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.172483518121;
                                    } else {
                                        return -0.0392253497555;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.163241274483;
                                    } else {
                                        return 0.232190140234;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[50] <= -996.0) {
                                        return -0.188535519431;
                                    } else {
                                        return -0.0325633067365;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return -0.269612427569;
                                    } else {
                                        return -0.0697043664294;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 23.5) {
                                if (fs[33] <= 0.5) {
                                    return 0.0111797754862;
                                } else {
                                    if (fs[50] <= -1398.0) {
                                        return 0.420930703152;
                                    } else {
                                        return 0.18878193267;
                                    }
                                }
                            } else {
                                return -0.367834914632;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[44] <= 0.5) {
                    if (fs[84] <= 0.5) {
                        if (fs[82] <= 6.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0382560831516;
                                    } else {
                                        return 0.0124808905258;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.238302124916;
                                    } else {
                                        return 0.331923431942;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9989.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.0310345755226;
                                    } else {
                                        return -0.00782796767765;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0215064079312;
                                    } else {
                                        return 0.106861338032;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[50] <= -1448.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.00209957415076;
                                    } else {
                                        return 0.189735694771;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return 0.199488636857;
                                    } else {
                                        return 0.0274400705959;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.00966086848239;
                                    } else {
                                        return 0.128587195176;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.422331761455;
                                    } else {
                                        return 0.00282407449579;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[79] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 16.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.037763567806;
                                    } else {
                                        return 0.0861388452474;
                                    }
                                } else {
                                    if (fs[50] <= -2938.0) {
                                        return 0.434222322931;
                                    } else {
                                        return 0.0095779496774;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.337183931306;
                                    } else {
                                        return 0.0331223918079;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return -0.00954525084856;
                                    } else {
                                        return 0.16397775007;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 35.5) {
                                if (fs[50] <= -1068.0) {
                                    if (fs[69] <= 9995.5) {
                                        return 0.162644118613;
                                    } else {
                                        return 0.055034369789;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.113255407724;
                                    } else {
                                        return 0.370418719594;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4994.0) {
                                    return -0.0531150233984;
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.165282382997;
                                    } else {
                                        return -0.191034884994;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[86] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[22] <= 0.5) {
                                return -0.0393067934365;
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[52] <= -0.5) {
                                        return -0.0478941807928;
                                    } else {
                                        return -0.0425435101633;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.0372027755307;
                                    } else {
                                        return -0.0284408065796;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 4967.5) {
                                if (fs[4] <= 9.5) {
                                    return -0.0454631943411;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0355348724922;
                                    } else {
                                        return -0.0428400848976;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    return -0.0902411722279;
                                } else {
                                    return -0.0782697318211;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 11.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[46] <= -2.5) {
                                    if (fs[4] <= 20.0) {
                                        return -0.0409286945689;
                                    } else {
                                        return 0.207044038668;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.0354169782554;
                                    } else {
                                        return -0.0202603575235;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    return 0.272865518888;
                                } else {
                                    return -0.0228760507364;
                                }
                            }
                        } else {
                            return 0.157730320566;
                        }
                    }
                }
            } else {
                if (fs[0] <= 4.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[50] <= -341.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0613189658741;
                                    } else {
                                        return -0.00371619664482;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.000714849383271;
                                    } else {
                                        return 0.0181299967496;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.00758347231356;
                                    } else {
                                        return 0.154310939782;
                                    }
                                } else {
                                    if (fs[82] <= 4.0) {
                                        return 0.141093835757;
                                    } else {
                                        return 0.607581510634;
                                    }
                                }
                            }
                        } else {
                            if (fs[80] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[50] <= -1468.0) {
                                        return 0.142661804972;
                                    } else {
                                        return -0.00917491936171;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0588253314362;
                                    } else {
                                        return 0.227924550277;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.230783721274;
                                    } else {
                                        return 0.57718761651;
                                    }
                                } else {
                                    return 0.0154417970085;
                                }
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[4] <= 13.5) {
                                if (fs[69] <= 9884.0) {
                                    if (fs[2] <= 7.5) {
                                        return -0.0182107536884;
                                    } else {
                                        return 0.036846270398;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0545476201078;
                                    } else {
                                        return -0.019893392971;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0101185312395;
                                    } else {
                                        return -0.0181620884433;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.00536660182604;
                                    } else {
                                        return 0.192972487727;
                                    }
                                }
                            }
                        } else {
                            if (fs[39] <= 0.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.0186255715962;
                                    } else {
                                        return -0.0129045345687;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.0419606257579;
                                    } else {
                                        return -0.0190247752766;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[50] <= -992.5) {
                                        return 0.0224548079169;
                                    } else {
                                        return -0.0104761984681;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0496735659357;
                                    } else {
                                        return -0.0162142719123;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9999.5) {
                        if (fs[54] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[0] <= 18.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.00496081435186;
                                    } else {
                                        return -0.00917580788928;
                                    }
                                } else {
                                    if (fs[50] <= -1098.0) {
                                        return -0.00906042066483;
                                    } else {
                                        return -0.0100947214627;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1363.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00966345772479;
                                    } else {
                                        return 0.00859125970672;
                                    }
                                } else {
                                    if (fs[55] <= 0.5) {
                                        return -0.0105988523491;
                                    } else {
                                        return -0.00238340318143;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[82] <= 1.0) {
                                        return 0.110508790538;
                                    } else {
                                        return -0.00697204369578;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.37869377893;
                                    } else {
                                        return 0.0887325151455;
                                    }
                                }
                            } else {
                                if (fs[67] <= -4.0) {
                                    return -0.050807448488;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0239993094038;
                                    } else {
                                        return -0.0121785393741;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[50] <= -1268.0) {
                                if (fs[0] <= 27.5) {
                                    if (fs[0] <= 9.5) {
                                        return 0.0978763050641;
                                    } else {
                                        return 0.409846709229;
                                    }
                                } else {
                                    return -0.0868094698991;
                                }
                            } else {
                                if (fs[50] <= -1098.0) {
                                    if (fs[0] <= 7.5) {
                                        return 0.320448466507;
                                    } else {
                                        return 0.0158607485207;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.032849608336;
                                    } else {
                                        return -0.0398406848502;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[50] <= -1053.0) {
                                    if (fs[50] <= -1488.0) {
                                        return -0.0369414288738;
                                    } else {
                                        return 0.248299327114;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0484748756945;
                                    } else {
                                        return -0.0321982320439;
                                    }
                                }
                            } else {
                                if (fs[50] <= -991.5) {
                                    if (fs[50] <= -1047.0) {
                                        return -0.0406371226483;
                                    } else {
                                        return -0.0243207454285;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.0102271577267;
                                    } else {
                                        return -0.0295164426154;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
