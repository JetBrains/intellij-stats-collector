/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree22 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 11.5) {
                    if (fs[25] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[50] <= -987.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.287173159297;
                                    } else {
                                        return -0.0315147337469;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.0779132828425;
                                    } else {
                                        return 0.269538838462;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.302702548001;
                                    } else {
                                        return 0.220042059832;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.140114674865;
                                    } else {
                                        return 0.251267767563;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[50] <= -1493.5) {
                                        return 0.063401407744;
                                    } else {
                                        return -0.0618515996858;
                                    }
                                } else {
                                    if (fs[50] <= -1123.5) {
                                        return -0.0166776323424;
                                    } else {
                                        return 0.321051245254;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    return 0.176845838125;
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.313484228615;
                                    } else {
                                        return 0.409743190151;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0418033173337;
                                    } else {
                                        return 0.394940583905;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.176365861617;
                                    } else {
                                        return 0.285522034232;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.232806634571;
                                    } else {
                                        return 0.356256173531;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.217702945645;
                                    } else {
                                        return 0.465789319626;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[4] <= 10.5) {
                                    if (fs[50] <= -1488.5) {
                                        return 0.00757658513391;
                                    } else {
                                        return -0.0977329668935;
                                    }
                                } else {
                                    return 0.387882803767;
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.0454455078054;
                                    } else {
                                        return 0.423215495767;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.110399274592;
                                    } else {
                                        return 0.328670329654;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 4.5) {
                        if (fs[93] <= 0.5) {
                            if (fs[13] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.110834241144;
                                    } else {
                                        return 0.294867637093;
                                    }
                                } else {
                                    if (fs[50] <= -1693.0) {
                                        return 0.191817234152;
                                    } else {
                                        return -2.61304651664e-05;
                                    }
                                }
                            } else {
                                if (fs[86] <= 0.5) {
                                    if (fs[50] <= -490.5) {
                                        return 0.348010858135;
                                    } else {
                                        return 0.218071636463;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return 0.339027135446;
                                    } else {
                                        return -0.0336209610827;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.273093914672;
                                    } else {
                                        return 0.20540146675;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.485674841439;
                                    } else {
                                        return 0.298162748215;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1618.0) {
                                    if (fs[78] <= 0.5) {
                                        return 0.310701606565;
                                    } else {
                                        return 0.436692360607;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return 0.170998599984;
                                    } else {
                                        return -0.0293086749538;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.150660617495;
                                    } else {
                                        return -0.0271172575853;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.233643080816;
                                    } else {
                                        return -0.0906933281287;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9669.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.172418227859;
                                    } else {
                                        return 0.512555952081;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.52667072908;
                                    } else {
                                        return 0.223741426044;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[50] <= -1458.0) {
                                    if (fs[2] <= 5.5) {
                                        return -0.19576707692;
                                    } else {
                                        return 0.106579795066;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.127697697551;
                                    } else {
                                        return 0.203676883671;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.132521298104;
                                    } else {
                                        return 0.00809565611577;
                                    }
                                } else {
                                    return 0.229983050426;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[93] <= 0.5) {
                    if (fs[69] <= 8691.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0365223607461;
                                    } else {
                                        return -0.0244530041036;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0565218160772;
                                    } else {
                                        return 0.272838136492;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0122941259037;
                                    } else {
                                        return 0.0251874249263;
                                    }
                                } else {
                                    if (fs[75] <= 0.5) {
                                        return 0.536453797511;
                                    } else {
                                        return 0.0592281865852;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return -0.018144492487;
                                    } else {
                                        return 0.519319227782;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return -0.0143634035331;
                                    } else {
                                        return 0.156953488947;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.00798222357292;
                                    } else {
                                        return -0.0148178479216;
                                    }
                                } else {
                                    if (fs[50] <= -1292.5) {
                                        return 0.0798871996076;
                                    } else {
                                        return -0.0085429513218;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1408.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.0223371128259;
                                    } else {
                                        return 0.127611834051;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return 0.230370770937;
                                    } else {
                                        return 0.0683609146503;
                                    }
                                }
                            } else {
                                if (fs[69] <= 8730.5) {
                                    return 0.527606569104;
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.00155689207245;
                                    } else {
                                        return 0.229750644559;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9981.5) {
                                if (fs[67] <= -4.0) {
                                    if (fs[0] <= 2.5) {
                                        return 0.127950124841;
                                    } else {
                                        return -0.0101640634962;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.00840027457424;
                                    } else {
                                        return -0.0243205918299;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0793529824182;
                                    } else {
                                        return -0.0714836759373;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.00481582553424;
                                    } else {
                                        return 0.0516404870037;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return -0.0109522325659;
                                    } else {
                                        return 0.110968004356;
                                    }
                                } else {
                                    return 0.335805730361;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[67] <= -1.5) {
                                        return 0.0533285318963;
                                    } else {
                                        return -0.0707067005966;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0280815212118;
                                    } else {
                                        return -0.022000972425;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[46] <= -0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.199960021466;
                                    } else {
                                        return 0.0579400259717;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.0617422695318;
                                    } else {
                                        return 0.363620702425;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[50] <= -1037.0) {
                                        return 0.0290168497165;
                                    } else {
                                        return -0.0157419582642;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.00674373100268;
                                    } else {
                                        return -0.0303319242725;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 5.5) {
                            if (fs[73] <= 250.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.00507087891231;
                                    } else {
                                        return -0.0185432062056;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.0232726866013;
                                    } else {
                                        return 0.342579521943;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1458.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.104286140208;
                                    } else {
                                        return 0.036172195394;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0197311906676;
                                    } else {
                                        return -0.00772199723116;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0108172541428;
                                    } else {
                                        return 0.00753594605581;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return -0.0176867808233;
                                    } else {
                                        return 0.0432571852082;
                                    }
                                }
                            } else {
                                if (fs[61] <= -993.5) {
                                    if (fs[46] <= -2.5) {
                                        return -0.0321344769077;
                                    } else {
                                        return -0.0223206239782;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0200727782471;
                                    } else {
                                        return -0.0192001348492;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[44] <= 0.5) {
                if (fs[50] <= -992.0) {
                    if (fs[0] <= 0.5) {
                        if (fs[87] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.2918367599;
                                    } else {
                                        return 0.0833790310375;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.186150754046;
                                    } else {
                                        return -0.253800583606;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[59] <= -0.5) {
                                        return -0.0172654135318;
                                    } else {
                                        return 0.292582725363;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.0379045939229;
                                    } else {
                                        return 0.192989050162;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                return -0.0345595505517;
                            } else {
                                return -0.270865067082;
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[50] <= -1118.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0463275573347;
                                    } else {
                                        return -0.027633839434;
                                    }
                                } else {
                                    return 0.419166561513;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.112568494266;
                                    } else {
                                        return 0.0365968452353;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return 0.387831085875;
                                    } else {
                                        return 0.140176908167;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -2428.0) {
                                return 0.557139703784;
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.155921220775;
                                    } else {
                                        return 0.0445622586479;
                                    }
                                } else {
                                    return 0.523051259124;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[61] <= -498.0) {
                                        return 0.355304417972;
                                    } else {
                                        return 0.186584009826;
                                    }
                                } else {
                                    if (fs[46] <= -0.5) {
                                        return 0.416155963679;
                                    } else {
                                        return 0.287774166716;
                                    }
                                }
                            } else {
                                if (fs[96] <= 0.5) {
                                    if (fs[73] <= 100.0) {
                                        return -0.21025359133;
                                    } else {
                                        return -0.336127139558;
                                    }
                                } else {
                                    return 0.231550740519;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.193685008701;
                                    } else {
                                        return 0.324043779827;
                                    }
                                } else {
                                    if (fs[4] <= 12.0) {
                                        return -0.213489731233;
                                    } else {
                                        return 0.0440679942978;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.129709859462;
                                    } else {
                                        return 0.270821836352;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.172008554649;
                                    } else {
                                        return 0.081598356179;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[62] <= 0.5) {
                                        return 0.0729079831898;
                                    } else {
                                        return -0.0636000641234;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0191794370178;
                                    } else {
                                        return 0.059032953472;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[68] <= 0.5) {
                                        return -0.0850035373926;
                                    } else {
                                        return 0.219596317213;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return -0.0085431696768;
                                    } else {
                                        return 0.307725620711;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.0256724019899;
                                    } else {
                                        return 0.233901367051;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.285556121972;
                                    } else {
                                        return 0.0598964219847;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[37] <= 0.5) {
                                        return -0.00710888133834;
                                    } else {
                                        return 0.0916818987537;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0192553914024;
                                    } else {
                                        return -0.0607726886325;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 7.5) {
                    if (fs[65] <= 1.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[73] <= 25.0) {
                                return 0.450802281018;
                            } else {
                                return 0.222175596416;
                            }
                        } else {
                            if (fs[98] <= 0.5) {
                                if (fs[62] <= 0.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.021921807061;
                                    } else {
                                        return 0.0222093865391;
                                    }
                                } else {
                                    return 0.0643957195565;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return -0.0638820986085;
                                } else {
                                    return -0.076257333535;
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[4] <= 9.5) {
                                return -0.0361241728158;
                            } else {
                                if (fs[50] <= 12.5) {
                                    return -0.0298354385825;
                                } else {
                                    return -0.0234071056643;
                                }
                            }
                        } else {
                            return 0.333253211167;
                        }
                    }
                } else {
                    if (fs[4] <= 23.0) {
                        return 0.159942510073;
                    } else {
                        return -0.0438895185773;
                    }
                }
            }
        }
    }
}
