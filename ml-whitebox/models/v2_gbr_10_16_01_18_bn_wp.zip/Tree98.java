/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree98 {
    public double calcTree(double... fs) {
        if (fs[61] <= -997.5) {
            if (fs[67] <= -4.0) {
                if (fs[61] <= -998.5) {
                    if (fs[73] <= 100.0) {
                        if (fs[0] <= 0.5) {
                            return -0.164082230659;
                        } else {
                            return -0.0549092426417;
                        }
                    } else {
                        return 0.0906212269284;
                    }
                } else {
                    if (fs[50] <= -1067.0) {
                        return 0.216444944245;
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[4] <= 13.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.287022856796;
                                    } else {
                                        return -0.0865767465742;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0485643601188;
                                    } else {
                                        return -0.00374039120728;
                                    }
                                }
                            } else {
                                return 0.106906045611;
                            }
                        } else {
                            return 0.065295121599;
                        }
                    }
                }
            } else {
                if (fs[44] <= 0.5) {
                    if (fs[33] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[61] <= -998.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.15025172469;
                                    } else {
                                        return 0.108460381763;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.01634005208;
                                    } else {
                                        return 0.210925097848;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.0134033589847;
                                    } else {
                                        return -0.10182621159;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.123564782769;
                                    } else {
                                        return 0.0216949074114;
                                    }
                                }
                            }
                        } else {
                            return -0.197941413216;
                        }
                    } else {
                        if (fs[95] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[82] <= 1.0) {
                                    if (fs[0] <= 0.5) {
                                        return -0.186328662536;
                                    } else {
                                        return 0.00270840977658;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0291976563938;
                                    } else {
                                        return -0.0410414491293;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0807604530546;
                                    } else {
                                        return 0.00838795071485;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0275576688688;
                                    } else {
                                        return -0.0391545212548;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0315617488002;
                                    } else {
                                        return 0.0855839405667;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0120276459544;
                                    } else {
                                        return 0.249202247462;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.372360008073;
                                    } else {
                                        return -0.0347725742405;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0447022383931;
                                    } else {
                                        return 0.0272202449976;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 8.5) {
                                return 0.00297013506808;
                            } else {
                                if (fs[12] <= 0.5) {
                                    return -0.0052259907911;
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.0859335395475;
                                    } else {
                                        return -0.018831953119;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[50] <= -986.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0669813976176;
                                    } else {
                                        return 0.00217260641839;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00206168778718;
                                    } else {
                                        return -0.0104260361716;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.00093331008407;
                                    } else {
                                        return 0.00187156936121;
                                    }
                                } else {
                                    if (fs[61] <= -998.5) {
                                        return -0.0247678769446;
                                    } else {
                                        return -0.00745523607127;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[97] <= 0.5) {
                            if (fs[95] <= 0.5) {
                                return -0.0125321652971;
                            } else {
                                return -0.026007140797;
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[55] <= 0.5) {
                                        return -0.00847744348707;
                                    } else {
                                        return -0.00398311969605;
                                    }
                                } else {
                                    return -0.00209181953959;
                                }
                            } else {
                                if (fs[46] <= -1.5) {
                                    return -0.0274610558795;
                                } else {
                                    if (fs[50] <= -976.0) {
                                        return -0.014149823414;
                                    } else {
                                        return -0.0100965463062;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[50] <= -1983.5) {
                    if (fs[67] <= -1.5) {
                        if (fs[4] <= 52.0) {
                            if (fs[4] <= 30.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0799832987676;
                                    } else {
                                        return 0.00497562034446;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0440025858324;
                                    } else {
                                        return 0.103611706147;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    return -0.0586246796891;
                                } else {
                                    if (fs[4] <= 37.0) {
                                        return 0.151738699806;
                                    } else {
                                        return 0.238696573527;
                                    }
                                }
                            }
                        } else {
                            return -0.235695271595;
                        }
                    } else {
                        return -0.1060003723;
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[26] <= 0.5) {
                            if (fs[29] <= 0.5) {
                                if (fs[73] <= 350.0) {
                                    if (fs[82] <= 4.5) {
                                        return 0.00461235244284;
                                    } else {
                                        return 0.0247635621801;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.131201634388;
                                    } else {
                                        return 0.0714738305248;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[50] <= -1303.0) {
                                        return -0.130861441521;
                                    } else {
                                        return 0.267327329837;
                                    }
                                } else {
                                    return -0.263074803867;
                                }
                            }
                        } else {
                            return -0.271017069758;
                        }
                    } else {
                        if (fs[43] <= 0.5) {
                            if (fs[82] <= 4.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[59] <= -1.5) {
                                        return 0.0666723546312;
                                    } else {
                                        return -0.0144046261202;
                                    }
                                } else {
                                    if (fs[82] <= 1.5) {
                                        return 0.00253502246288;
                                    } else {
                                        return 0.114541519185;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return -0.0118192414593;
                                    } else {
                                        return 0.0381992518833;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.129954734534;
                                    } else {
                                        return -0.0950754331098;
                                    }
                                }
                            }
                        } else {
                            if (fs[77] <= 0.5) {
                                if (fs[18] <= -0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.120034312996;
                                    } else {
                                        return -0.0048810341331;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0362845367885;
                                    } else {
                                        return -0.0606127523953;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0661610122251;
                                    } else {
                                        return -0.098689037874;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.175751899714;
                                    } else {
                                        return -0.437485359756;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[63] <= 5.0) {
                    if (fs[34] <= 0.5) {
                        if (fs[73] <= 350.0) {
                            if (fs[54] <= 0.5) {
                                if (fs[4] <= 25.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.000226093119553;
                                    } else {
                                        return 0.00539912336635;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.00116293005982;
                                    } else {
                                        return -0.00358323530785;
                                    }
                                }
                            } else {
                                if (fs[82] <= 3.0) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0504691587574;
                                    } else {
                                        return 0.0330165620844;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.151763578887;
                                    } else {
                                        return -0.0242890466236;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9997.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.00589255167825;
                                    } else {
                                        return -0.0304734942651;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00416072579899;
                                    } else {
                                        return 0.0824045596756;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1057.0) {
                                    return 0.3179292498;
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0412234808737;
                                    } else {
                                        return -0.055961501731;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            return 0.14393215386;
                        } else {
                            if (fs[50] <= -1138.0) {
                                return -0.0489511109582;
                            } else {
                                return 0.1151642407;
                            }
                        }
                    }
                } else {
                    if (fs[73] <= 75.0) {
                        if (fs[4] <= 9.5) {
                            if (fs[69] <= 9751.5) {
                                if (fs[82] <= 1.5) {
                                    if (fs[50] <= -1483.0) {
                                        return -0.018326194497;
                                    } else {
                                        return -0.0123027802184;
                                    }
                                } else {
                                    return -0.0381556727196;
                                }
                            } else {
                                return -0.071695178392;
                            }
                        } else {
                            if (fs[50] <= -16.0) {
                                if (fs[69] <= 4997.0) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00368666582423;
                                    } else {
                                        return -0.135591315208;
                                    }
                                } else {
                                    return -0.150907494762;
                                }
                            } else {
                                return 0.093382495911;
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[82] <= 3.5) {
                                return -0.105736842589;
                            } else {
                                return -0.00364452311856;
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                return -0.220593853568;
                            } else {
                                return -0.0793389586211;
                            }
                        }
                    }
                }
            }
        }
    }
}
