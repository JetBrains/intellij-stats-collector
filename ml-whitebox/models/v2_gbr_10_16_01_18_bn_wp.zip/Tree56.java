/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree56 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[75] <= 0.5) {
                if (fs[4] <= 7.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[69] <= 9988.0) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0594441408278;
                                    } else {
                                        return 0.042069538949;
                                    }
                                } else {
                                    return -0.192869269393;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.0596756131829;
                                    } else {
                                        return -0.0390850578685;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.113330672163;
                                    } else {
                                        return 0.525411460024;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[67] <= -1.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.072605115869;
                                    } else {
                                        return 0.0845609909567;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0321333332853;
                                    } else {
                                        return -0.062549453845;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    return 0.309012448653;
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return 0.205213662561;
                                    } else {
                                        return -0.00759853658636;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            if (fs[50] <= -1053.5) {
                                return 0.120836640177;
                            } else {
                                if (fs[4] <= 3.5) {
                                    return -0.019515482451;
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0279743624836;
                                    } else {
                                        return -0.00806308921309;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return -0.348910656579;
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.065598914957;
                                    } else {
                                        return -0.121390722794;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0215990935625;
                                    } else {
                                        return -0.0556081109381;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[95] <= 1.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.213394406232;
                                    } else {
                                        return 0.133211325815;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.063303800925;
                                    } else {
                                        return 0.0998844185696;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.240618109816;
                                    } else {
                                        return 0.108789194083;
                                    }
                                } else {
                                    return 0.113086291404;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[50] <= -1328.0) {
                                        return -0.0515796993742;
                                    } else {
                                        return 0.306206445926;
                                    }
                                } else {
                                    return -0.230666639033;
                                }
                            } else {
                                return -0.138526019225;
                            }
                        }
                    } else {
                        if (fs[73] <= 100.0) {
                            if (fs[56] <= 0.5) {
                                if (fs[50] <= -466.0) {
                                    if (fs[0] <= 7.5) {
                                        return -0.0316042370133;
                                    } else {
                                        return 0.0109712410835;
                                    }
                                } else {
                                    return 0.00836333096722;
                                }
                            } else {
                                if (fs[67] <= -1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0359981084986;
                                    } else {
                                        return -0.0184901718685;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.153461457548;
                                    } else {
                                        return -0.0244461761953;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 4847.0) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 31.5) {
                                        return -0.000237723678836;
                                    } else {
                                        return -0.0096423041614;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0203490870136;
                                    } else {
                                        return -0.00797297343864;
                                    }
                                }
                            } else {
                                return 0.0985521714045;
                            }
                        }
                    }
                }
            } else {
                if (fs[95] <= 1.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[37] <= 0.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[69] <= 9633.5) {
                                        return 0.015004306418;
                                    } else {
                                        return 0.100654590092;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0442709219694;
                                    } else {
                                        return 0.0676328152699;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0731632839284;
                                    } else {
                                        return 0.12510375039;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0555955183719;
                                    } else {
                                        return -0.0186615874904;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0824697592849;
                                    } else {
                                        return -0.117464201652;
                                    }
                                } else {
                                    if (fs[69] <= 9982.5) {
                                        return 0.308303873833;
                                    } else {
                                        return 0.193529566919;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.334485276178;
                                    } else {
                                        return 0.172562120045;
                                    }
                                } else {
                                    return -0.0135893081146;
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[18] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[69] <= 9851.5) {
                                        return -0.0093826108768;
                                    } else {
                                        return 0.0231438263504;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.00373151028168;
                                    } else {
                                        return 0.00100858953379;
                                    }
                                }
                            } else {
                                if (fs[0] <= 20.5) {
                                    if (fs[50] <= -1142.5) {
                                        return 0.0069618383571;
                                    } else {
                                        return -0.00082713799319;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.00422529079558;
                                    } else {
                                        return -0.0112175599379;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1408.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.00810630160335;
                                    } else {
                                        return 0.0659047452178;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0103580018925;
                                    } else {
                                        return -0.00779508468397;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[69] <= 9658.5) {
                                        return -0.0051373376275;
                                    } else {
                                        return 0.0392426988911;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.0160316871367;
                                    } else {
                                        return -0.00486396941652;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[50] <= -1398.0) {
                                        return 0.0821629831052;
                                    } else {
                                        return 0.0497036135097;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.184031789103;
                                    } else {
                                        return 0.139052260785;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 19.5) {
                                        return 0.0184991923488;
                                    } else {
                                        return 0.2741478483;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0467673716296;
                                    } else {
                                        return -0.0136957189783;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[46] <= -2.5) {
                                        return 0.0879254988801;
                                    } else {
                                        return 0.00155228773086;
                                    }
                                } else {
                                    return 0.244077286486;
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[0] <= 3.5) {
                                        return 0.0901551769065;
                                    } else {
                                        return 0.0168139738857;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.157095001575;
                                    } else {
                                        return -0.00160345842378;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 11.5) {
                            if (fs[50] <= -1043.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0527884584777;
                                    } else {
                                        return 0.0168546930317;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.0339830380724;
                                    } else {
                                        return -0.0209129644777;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[67] <= -3.5) {
                                        return 0.0166650924345;
                                    } else {
                                        return -0.00389718870294;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0412048597221;
                                    } else {
                                        return 0.00954987451281;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 0.5) {
                                if (fs[50] <= -2968.0) {
                                    if (fs[73] <= 250.0) {
                                        return 0.284993285787;
                                    } else {
                                        return 0.0980374228054;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.00978520513181;
                                    } else {
                                        return -0.00420214494425;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[4] <= 13.5) {
                                        return 0.190242814418;
                                    } else {
                                        return 4.67422568381e-05;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.228778926771;
                                    } else {
                                        return 0.0258908780018;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[50] <= -1052.5) {
                if (fs[4] <= 18.5) {
                    if (fs[50] <= -1133.5) {
                        if (fs[25] <= 0.5) {
                            if (fs[91] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[0] <= 8.5) {
                                        return 0.0827331322721;
                                    } else {
                                        return -0.00427584955861;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0733144458296;
                                    } else {
                                        return 0.0952630291439;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.180311470953;
                                    } else {
                                        return 0.0207668155495;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0471835452367;
                                    } else {
                                        return -0.0335000678932;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1488.0) {
                                if (fs[91] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0387741962538;
                                    } else {
                                        return 0.284824715079;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.156213957198;
                                    } else {
                                        return 0.0700565495877;
                                    }
                                }
                            } else {
                                if (fs[87] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.131708601563;
                                    } else {
                                        return -0.143990482863;
                                    }
                                } else {
                                    return -0.257708783987;
                                }
                            }
                        }
                    } else {
                        if (fs[65] <= 1.5) {
                            if (fs[0] <= 10.0) {
                                if (fs[2] <= 2.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.0624503792083;
                                    } else {
                                        return 0.200427165161;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.121617245468;
                                    } else {
                                        return 0.202032385144;
                                    }
                                }
                            } else {
                                return 0.410063767564;
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return 0.0966371657176;
                            } else {
                                return 0.515651387443;
                            }
                        }
                    }
                } else {
                    if (fs[84] <= 0.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[0] <= 12.0) {
                                    if (fs[4] <= 31.0) {
                                        return 0.102745655777;
                                    } else {
                                        return -0.115223055352;
                                    }
                                } else {
                                    return -0.20185005172;
                                }
                            } else {
                                if (fs[82] <= 3.5) {
                                    if (fs[64] <= 0.5) {
                                        return -0.145788571967;
                                    } else {
                                        return 0.10251304069;
                                    }
                                } else {
                                    return 0.102969410111;
                                }
                            }
                        } else {
                            if (fs[4] <= 20.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.213884330254;
                                    } else {
                                        return -0.460647698323;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.103081411897;
                                    } else {
                                        return -0.0850052782255;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9997.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0143216305367;
                                    } else {
                                        return -0.234572247539;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.0951341991377;
                                    } else {
                                        return 0.262096102212;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[39] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -2008.0) {
                                        return 0.111550461515;
                                    } else {
                                        return -0.199417627532;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.188007388976;
                                    } else {
                                        return -0.0549668434423;
                                    }
                                }
                            } else {
                                if (fs[59] <= -0.5) {
                                    return -0.22680221944;
                                } else {
                                    return 0.0966142326379;
                                }
                            }
                        } else {
                            if (fs[50] <= -1758.0) {
                                if (fs[0] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0521667010535;
                                    } else {
                                        return 0.198789630724;
                                    }
                                } else {
                                    return 0.371337000503;
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 19.5) {
                                        return -0.191263820026;
                                    } else {
                                        return 0.0358657884476;
                                    }
                                } else {
                                    return -0.285393606314;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[99] <= 0.5) {
                    if (fs[4] <= 5.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0844159929464;
                                    } else {
                                        return 0.15552284981;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0560969523862;
                                    } else {
                                        return 0.0469453225663;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0319666719844;
                                    } else {
                                        return 0.11121916505;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0464326772821;
                                    } else {
                                        return 0.176236097784;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.13261414032;
                                    } else {
                                        return -0.0270269638107;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.190351071463;
                                    } else {
                                        return 0.128096234169;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.0219646632792;
                                    } else {
                                        return -0.159483614695;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00940560938819;
                                    } else {
                                        return 0.0735105940672;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 6.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.257381967872;
                                    } else {
                                        return 0.120891186792;
                                    }
                                } else {
                                    return 0.176670152575;
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.00127868323332;
                                    } else {
                                        return -0.383060151845;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.149945432491;
                                    } else {
                                        return -0.0451343043508;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 1.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0475455504868;
                                    } else {
                                        return 0.00406483982436;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0383485683495;
                                    } else {
                                        return 0.100163640151;
                                    }
                                }
                            } else {
                                if (fs[61] <= -995.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.172542468479;
                                    } else {
                                        return 0.00258805318534;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return -0.00911017703236;
                                    } else {
                                        return -0.190029495912;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[37] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0706326913308;
                                    } else {
                                        return 0.00399541394233;
                                    }
                                } else {
                                    return 0.413447784964;
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    return 0.226590586093;
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.061315352589;
                                    } else {
                                        return -0.00242574383827;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[4] <= 8.5) {
                                    return 0.0260858778419;
                                } else {
                                    return -0.241643234266;
                                }
                            } else {
                                return 0.21520607073;
                            }
                        }
                    } else {
                        if (fs[4] <= 14.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    return -0.00156764617589;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.129643612695;
                                    } else {
                                        return 0.163705600094;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0758558497285;
                                    } else {
                                        return -0.0457723702159;
                                    }
                                } else {
                                    if (fs[73] <= 50.0) {
                                        return 0.21851209923;
                                    } else {
                                        return 0.104876101445;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[69] <= 9998.5) {
                                    return -0.042462274167;
                                } else {
                                    return -0.337821966333;
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    return -0.128766422971;
                                } else {
                                    return 0.0346744305219;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
