/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree31 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 8.5) {
                if (fs[50] <= -987.5) {
                    if (fs[78] <= 0.5) {
                        if (fs[4] <= 3.5) {
                            if (fs[95] <= 1.5) {
                                if (fs[50] <= -1299.0) {
                                    if (fs[82] <= 1.5) {
                                        return -0.067650026468;
                                    } else {
                                        return 0.193077787307;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.285544099857;
                                    } else {
                                        return 0.0188882463671;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[2] <= 1.5) {
                                        return -0.210039578515;
                                    } else {
                                        return 0.126804643;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.277930844768;
                                    } else {
                                        return 0.105015635287;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.217372830855;
                                    } else {
                                        return 0.15008913306;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.0716530108268;
                                    } else {
                                        return 0.220084315228;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.0940110723688;
                                    } else {
                                        return 0.328002224893;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.222875598818;
                                    } else {
                                        return 0.246018753783;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[82] <= -0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.140347983746;
                                    } else {
                                        return 0.349719963025;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.435936198253;
                                    } else {
                                        return -0.228927913984;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.198304988073;
                                    } else {
                                        return 0.179648916505;
                                    }
                                } else {
                                    if (fs[82] <= 1.0) {
                                        return 0.0612539527531;
                                    } else {
                                        return -0.229820280016;
                                    }
                                }
                            }
                        } else {
                            if (fs[56] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.029575021193;
                                    } else {
                                        return 0.0392941573366;
                                    }
                                } else {
                                    return 0.345502565936;
                                }
                            } else {
                                return 0.195236722379;
                            }
                        }
                    }
                } else {
                    if (fs[68] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[75] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.268249616121;
                                    } else {
                                        return 0.0382581918108;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.106462314151;
                                    } else {
                                        return -0.00804898244898;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.186997399027;
                                    } else {
                                        return 0.0501413125353;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.396459265064;
                                    } else {
                                        return 0.298885750277;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.211076616555;
                                    } else {
                                        return 0.246264681251;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.196803686407;
                                    } else {
                                        return 0.0840816806075;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.267135383764;
                                    } else {
                                        return 0.341448844052;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.229419659262;
                                    } else {
                                        return 0.242762724091;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[46] <= -0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[61] <= -998.5) {
                                        return 0.227918527602;
                                    } else {
                                        return -0.100026462379;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.283510430175;
                                    } else {
                                        return 0.194109089267;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[54] <= 0.5) {
                                        return 0.0111707016056;
                                    } else {
                                        return 0.350720229848;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.172495338157;
                                    } else {
                                        return 0.37248847014;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[82] <= -0.5) {
                                        return -0.139875135315;
                                    } else {
                                        return 0.174518166668;
                                    }
                                } else {
                                    if (fs[82] <= 1.0) {
                                        return -0.113155755602;
                                    } else {
                                        return 0.0718427761905;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[50] <= -929.0) {
                                        return -0.212607248942;
                                    } else {
                                        return 0.0375107291449;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.129140076547;
                                    } else {
                                        return -0.0861408669945;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -977.0) {
                    if (fs[99] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 18.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[86] <= 0.5) {
                                        return 0.222234836915;
                                    } else {
                                        return 0.132760755687;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.210956676137;
                                    } else {
                                        return -0.0493834256947;
                                    }
                                }
                            } else {
                                if (fs[2] <= 10.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.122492811572;
                                    } else {
                                        return 0.0561315864754;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.316158053677;
                                    } else {
                                        return 0.0374113448644;
                                    }
                                }
                            }
                        } else {
                            if (fs[77] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[50] <= -1948.0) {
                                        return 0.321840513434;
                                    } else {
                                        return -0.0767361123166;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.0625941107032;
                                    } else {
                                        return 0.29231882008;
                                    }
                                }
                            } else {
                                return -0.30297779988;
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[82] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[67] <= -1.5) {
                                        return -0.269257380412;
                                    } else {
                                        return -0.133117101955;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.322908939587;
                                    } else {
                                        return -0.340822273106;
                                    }
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.244117986954;
                                    } else {
                                        return 0.101925330909;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.0397701046156;
                                    } else {
                                        return -0.196146057174;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[2] <= 5.5) {
                                    if (fs[4] <= 11.5) {
                                        return -0.00930158838807;
                                    } else {
                                        return -0.12381314977;
                                    }
                                } else {
                                    if (fs[2] <= 10.5) {
                                        return 0.0852440286351;
                                    } else {
                                        return 0.419923164033;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9995.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.329219644942;
                                    } else {
                                        return 0.147922677607;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.326172155445;
                                    } else {
                                        return 0.204720274971;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[25] <= 0.5) {
                        if (fs[61] <= -994.5) {
                            if (fs[59] <= -1.5) {
                                if (fs[59] <= -2.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.344404163738;
                                    } else {
                                        return 0.202848250292;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return 0.140782343846;
                                    } else {
                                        return 0.265240010879;
                                    }
                                }
                            } else {
                                if (fs[4] <= 22.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.175031830941;
                                    } else {
                                        return 0.306502699651;
                                    }
                                } else {
                                    return -0.434632411323;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[69] <= 9817.0) {
                                        return 0.0844247798163;
                                    } else {
                                        return 0.170391070798;
                                    }
                                } else {
                                    return 0.425477669173;
                                }
                            } else {
                                if (fs[73] <= 150.0) {
                                    if (fs[2] <= 4.5) {
                                        return -0.0103692748393;
                                    } else {
                                        return 0.153471019121;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.140535146256;
                                    } else {
                                        return 0.0630107004118;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[43] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[69] <= 4273.5) {
                                        return -0.151756781782;
                                    } else {
                                        return -0.219768291301;
                                    }
                                } else {
                                    return 0.163769244645;
                                }
                            } else {
                                return 0.145806529253;
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[73] <= 75.0) {
                                    return 0.0909510413067;
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.399041287816;
                                    } else {
                                        return 0.216411330846;
                                    }
                                }
                            } else {
                                return -0.017667788343;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[69] <= 9886.5) {
                if (fs[11] <= 0.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[73] <= 75.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.0733604851701;
                                    } else {
                                        return 0.0158664259437;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.11310393232;
                                    } else {
                                        return 0.0371606782518;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9845.0) {
                                    if (fs[50] <= -1468.5) {
                                        return 0.105240535356;
                                    } else {
                                        return 0.0522611587075;
                                    }
                                } else {
                                    if (fs[69] <= 9879.0) {
                                        return -0.102356003937;
                                    } else {
                                        return -0.255073480368;
                                    }
                                }
                            }
                        } else {
                            if (fs[86] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[50] <= -17.5) {
                                        return -0.0199047319106;
                                    } else {
                                        return -0.0413849754913;
                                    }
                                } else {
                                    if (fs[2] <= 7.5) {
                                        return -0.0443297098113;
                                    } else {
                                        return -0.0503587951737;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0277394677502;
                                    } else {
                                        return 0.027330475252;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.0193307145785;
                                    } else {
                                        return -0.00516365503457;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[95] <= 1.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[75] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.09477389301;
                                    } else {
                                        return 0.00823440913698;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0098602786389;
                                    } else {
                                        return -0.0150587737419;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[4] <= 25.5) {
                                        return -0.0308851052374;
                                    } else {
                                        return -0.0329106243261;
                                    }
                                } else {
                                    return 0.407731733445;
                                }
                            }
                        } else {
                            if (fs[50] <= -1098.0) {
                                if (fs[49] <= 0.5) {
                                    if (fs[0] <= 70.5) {
                                        return 0.0112896171481;
                                    } else {
                                        return 0.160819726454;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.153400559717;
                                    } else {
                                        return 0.0325561546948;
                                    }
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[4] <= 13.5) {
                                        return 0.00812030825325;
                                    } else {
                                        return -0.0118826663102;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0131051870467;
                                    } else {
                                        return -0.0203627982806;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[34] <= 0.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0177920180645;
                                    } else {
                                        return -0.000554584632804;
                                    }
                                } else {
                                    if (fs[69] <= 8672.5) {
                                        return 0.0179250999195;
                                    } else {
                                        return 0.115155069077;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[0] <= 9.5) {
                                        return -0.00730252826947;
                                    } else {
                                        return -0.0116843850221;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.00156567417389;
                                    } else {
                                        return -0.0124703231622;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.132051630784;
                                    } else {
                                        return -0.0101889843693;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0918563467813;
                                    } else {
                                        return 0.0272583872951;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[50] <= -1438.0) {
                                        return 0.0509123132764;
                                    } else {
                                        return -0.00696821110477;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0143787746907;
                                    } else {
                                        return -0.00513926991504;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1138.0) {
                            return 0.249278587251;
                        } else {
                            return 0.406138243325;
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[50] <= -1918.0) {
                                        return 0.165819197516;
                                    } else {
                                        return 0.00739977263302;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.127414261001;
                                    } else {
                                        return 0.334100291984;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.275745466532;
                                    } else {
                                        return 0.140878996853;
                                    }
                                } else {
                                    return -0.00924470708084;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                return 0.34228584736;
                            } else {
                                return 0.210238125678;
                            }
                        }
                    } else {
                        if (fs[37] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.076737429678;
                                    } else {
                                        return 0.0307944560798;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0620980465052;
                                    } else {
                                        return 0.242773798033;
                                    }
                                }
                            } else {
                                if (fs[50] <= -17.0) {
                                    if (fs[73] <= 75.0) {
                                        return -0.0775005309204;
                                    } else {
                                        return -0.0324395068168;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.022631434916;
                                    } else {
                                        return 0.0383501602138;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 16.5) {
                                    if (fs[69] <= 9986.5) {
                                        return 0.11778199335;
                                    } else {
                                        return -0.0251863380805;
                                    }
                                } else {
                                    return 0.292027892336;
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[73] <= 75.0) {
                                        return 0.195103830282;
                                    } else {
                                        return 0.321122760993;
                                    }
                                } else {
                                    return 0.444154692229;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1277.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0315111416169;
                                    } else {
                                        return 0.165309052088;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0457903051598;
                                    } else {
                                        return 0.491602240876;
                                    }
                                }
                            } else {
                                if (fs[73] <= 150.0) {
                                    if (fs[37] <= 0.5) {
                                        return 0.0126888497208;
                                    } else {
                                        return 0.346572917987;
                                    }
                                } else {
                                    if (fs[69] <= 9990.5) {
                                        return -0.0250999017496;
                                    } else {
                                        return -0.089278492223;
                                    }
                                }
                            }
                        } else {
                            if (fs[6] <= 0.5) {
                                return -0.190975867015;
                            } else {
                                if (fs[50] <= -1478.0) {
                                    if (fs[0] <= 18.0) {
                                        return 0.162073042405;
                                    } else {
                                        return -0.117752844454;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.204833780777;
                                    } else {
                                        return 0.358706390703;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[0] <= 8.5) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0484227089209;
                                    } else {
                                        return 0.179546788854;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0132364560045;
                                    } else {
                                        return 0.0166475546652;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[69] <= 9983.5) {
                                        return -0.0155891437879;
                                    } else {
                                        return -0.00223556965146;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0863032528666;
                                    } else {
                                        return 0.0158734288856;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[50] <= 3.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0714541105089;
                                    } else {
                                        return -0.0353106508089;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0179201213806;
                                    } else {
                                        return -0.0252033286796;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.00759000211516;
                                    } else {
                                        return -0.0279633234964;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0370179016137;
                                    } else {
                                        return -0.0155370519931;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
