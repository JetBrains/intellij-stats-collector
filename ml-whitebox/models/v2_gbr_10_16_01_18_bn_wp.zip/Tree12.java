/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree12 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[75] <= 0.5) {
                if (fs[4] <= 19.5) {
                    if (fs[50] <= -1138.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.493062262396;
                                    } else {
                                        return 0.344029767251;
                                    }
                                } else {
                                    return 0.172888338326;
                                }
                            } else {
                                if (fs[69] <= 9983.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.315694875659;
                                    } else {
                                        return 0.502347532227;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.592810337928;
                                    } else {
                                        return 0.525923839322;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.53845940864;
                                } else {
                                    return 0.471468024673;
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0702471182592;
                                    } else {
                                        return -0.111870129999;
                                    }
                                } else {
                                    return 0.237730757411;
                                }
                            }
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            if (fs[69] <= 4984.0) {
                                if (fs[50] <= -1028.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.531644401606;
                                    } else {
                                        return 0.518421339676;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.522711665482;
                                    } else {
                                        return 0.424628774224;
                                    }
                                }
                            } else {
                                return 0.392038815445;
                            }
                        } else {
                            if (fs[14] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[50] <= -983.0) {
                                        return 0.511318810747;
                                    } else {
                                        return 0.30836487998;
                                    }
                                } else {
                                    return 0.0707588681674;
                                }
                            } else {
                                return 0.581638351927;
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1578.0) {
                        if (fs[2] <= 3.5) {
                            if (fs[4] <= 31.0) {
                                return -0.0687855189892;
                            } else {
                                return 0.15404881919;
                            }
                        } else {
                            return -0.0829744612087;
                        }
                    } else {
                        if (fs[50] <= -1313.0) {
                            if (fs[4] <= 31.5) {
                                return -0.101476821553;
                            } else {
                                if (fs[4] <= 46.0) {
                                    return -0.164809230127;
                                } else {
                                    return -0.155230845311;
                                }
                            }
                        } else {
                            if (fs[4] <= 34.0) {
                                return -0.135933726619;
                            } else {
                                return 0.214112497955;
                            }
                        }
                    }
                }
            } else {
                if (fs[91] <= 0.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.362766775539;
                                    } else {
                                        return 0.27784266118;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.496270805492;
                                    } else {
                                        return 0.06303755248;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0162564146567;
                                    } else {
                                        return -0.0276747026306;
                                    }
                                } else {
                                    if (fs[50] <= -1123.5) {
                                        return 0.220539476072;
                                    } else {
                                        return 0.483735216947;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[69] <= 9940.5) {
                                    if (fs[82] <= -0.5) {
                                        return -0.156728073181;
                                    } else {
                                        return 0.207628456922;
                                    }
                                } else {
                                    if (fs[50] <= -1108.5) {
                                        return 0.381068648991;
                                    } else {
                                        return 0.224584282874;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[50] <= -1543.5) {
                                        return 0.313446802;
                                    } else {
                                        return 0.0652369556279;
                                    }
                                } else {
                                    if (fs[67] <= -3.5) {
                                        return 0.326043465825;
                                    } else {
                                        return 0.174837943467;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 11.5) {
                            if (fs[82] <= 5.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[100] <= 0.5) {
                                        return 0.384206027102;
                                    } else {
                                        return 0.489298265355;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.16563869788;
                                    } else {
                                        return 0.037627778316;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[62] <= 0.5) {
                                        return 0.534470941852;
                                    } else {
                                        return 0.0636128501787;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.44401882831;
                                    } else {
                                        return -0.0563430862764;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.253479208053;
                                    } else {
                                        return 0.0875227092596;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return 0.276728582199;
                                    } else {
                                        return 0.453002879474;
                                    }
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.345679501578;
                                    } else {
                                        return 0.414093597153;
                                    }
                                } else {
                                    return -0.043520053271;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[61] <= -997.5) {
                                    if (fs[55] <= 0.5) {
                                        return 0.519971488927;
                                    } else {
                                        return 0.423461020906;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.463493050304;
                                    } else {
                                        return 0.37650480707;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.371215463837;
                                    } else {
                                        return 0.461980249685;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.448457583516;
                                    } else {
                                        return 0.231709410083;
                                    }
                                }
                            }
                        } else {
                            if (fs[77] <= 0.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[4] <= 14.5) {
                                        return 0.277456977897;
                                    } else {
                                        return -0.0474096296607;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.111567961113;
                                    } else {
                                        return 0.132085041694;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return 0.179780962004;
                                } else {
                                    return -0.196315711404;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[59] <= -0.5) {
                                if (fs[59] <= -1.5) {
                                    if (fs[46] <= -2.5) {
                                        return 0.512108440982;
                                    } else {
                                        return 0.593996228704;
                                    }
                                } else {
                                    if (fs[50] <= -1042.0) {
                                        return 0.283993205995;
                                    } else {
                                        return 0.480951766161;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1298.5) {
                                    if (fs[69] <= 9989.0) {
                                        return 0.579967728118;
                                    } else {
                                        return 0.451536391249;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.115330559187;
                                    } else {
                                        return 0.242229658575;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[4] <= 21.5) {
                                        return 0.479672601817;
                                    } else {
                                        return 0.307409429828;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return 0.274989856782;
                                    } else {
                                        return 0.473342585828;
                                    }
                                }
                            } else {
                                if (fs[61] <= -997.5) {
                                    return 0.311971603901;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.543196744054;
                                    } else {
                                        return 0.614024294833;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[84] <= 0.5) {
                if (fs[69] <= 9868.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[73] <= 75.0) {
                                if (fs[75] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.258444776093;
                                    } else {
                                        return 0.0928541519963;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.017085027607;
                                    } else {
                                        return -0.0243870743927;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[69] <= 9760.0) {
                                        return 0.0562396329981;
                                    } else {
                                        return 0.288943526577;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.102032039541;
                                    } else {
                                        return 0.422135301592;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[73] <= 75.0) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0232699690673;
                                    } else {
                                        return -0.0134048600749;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.00911334917459;
                                    } else {
                                        return 0.146699217928;
                                    }
                                }
                            } else {
                                if (fs[82] <= 6.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0177477889761;
                                    } else {
                                        return -0.0288034360707;
                                    }
                                } else {
                                    if (fs[50] <= -1438.0) {
                                        return 0.039305466204;
                                    } else {
                                        return -0.0223079024569;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[50] <= -57.0) {
                                    if (fs[82] <= 6.5) {
                                        return -0.0192947030158;
                                    } else {
                                        return 0.0276518611183;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.0149948143704;
                                    } else {
                                        return 0.00723243901198;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0701907620489;
                                    } else {
                                        return 0.0257430156314;
                                    }
                                } else {
                                    if (fs[82] <= 1.5) {
                                        return -0.0331908812049;
                                    } else {
                                        return 0.00485450354329;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.0301778506368;
                                    } else {
                                        return -0.0250794857094;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.0320716178086;
                                    } else {
                                        return -0.0298427454715;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.0255099932581;
                                    } else {
                                        return 0.195870424276;
                                    }
                                } else {
                                    if (fs[73] <= 125.0) {
                                        return -0.025936753763;
                                    } else {
                                        return 0.00854129639061;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1418.0) {
                        if (fs[69] <= 9999.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0464609601542;
                                    } else {
                                        return 0.155170092238;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.174801472775;
                                    } else {
                                        return 0.46872187855;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.0620099781214;
                                    } else {
                                        return 0.443879864644;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.00902876809491;
                                    } else {
                                        return 0.202755804256;
                                    }
                                }
                            }
                        } else {
                            if (fs[63] <= 5.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.450659708612;
                                    } else {
                                        return -0.146351764153;
                                    }
                                } else {
                                    if (fs[0] <= 18.0) {
                                        return 0.288411483743;
                                    } else {
                                        return 0.00112501483965;
                                    }
                                }
                            } else {
                                return -0.146487065238;
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[69] <= 9993.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.0246700037266;
                                    } else {
                                        return 0.126226239128;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0645378241661;
                                    } else {
                                        return 0.159214276737;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9995.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.00266015593026;
                                    } else {
                                        return -0.0449470600988;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0528266722833;
                                    } else {
                                        return -0.00729801605266;
                                    }
                                }
                            }
                        } else {
                            if (fs[74] <= 0.5) {
                                if (fs[50] <= -1047.0) {
                                    return 0.0260394427798;
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return -0.0352585396095;
                                    } else {
                                        return -0.082436659191;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    return -0.0514623610671;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0842849894933;
                                    } else {
                                        return -0.0585188005035;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[25] <= 0.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.274341643397;
                                    } else {
                                        return 0.106485525392;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.0334465723653;
                                    } else {
                                        return -0.0208069693343;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.0630289426586;
                                    } else {
                                        return 0.363780693441;
                                    }
                                } else {
                                    return 0.048106462014;
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.432522549442;
                                    } else {
                                        return 0.104938233811;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0893053626376;
                                    } else {
                                        return -0.0315326675122;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[61] <= -996.5) {
                                        return 0.192102918396;
                                    } else {
                                        return -0.00959703681908;
                                    }
                                } else {
                                    if (fs[59] <= -2.5) {
                                        return 0.0895097634996;
                                    } else {
                                        return -0.0435863725606;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1082.5) {
                            if (fs[97] <= 1.5) {
                                if (fs[69] <= 9999.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0153532754549;
                                    } else {
                                        return -0.0183021899452;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.043953866935;
                                    } else {
                                        return 0.22228645442;
                                    }
                                }
                            } else {
                                if (fs[0] <= 31.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0714118518816;
                                    } else {
                                        return -0.0381139874909;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.574190329794;
                                    } else {
                                        return -0.0435564201261;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.0110248408217;
                                    } else {
                                        return -0.0285389648118;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return -0.00110648416707;
                                    } else {
                                        return 0.254872729473;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[59] <= -2.5) {
                                        return 0.0205225829335;
                                    } else {
                                        return -0.0311111205666;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return -0.0326139216154;
                                    } else {
                                        return -0.0257609895429;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[50] <= -1128.0) {
                                if (fs[4] <= 10.5) {
                                    if (fs[50] <= -1458.0) {
                                        return 0.170190808772;
                                    } else {
                                        return 0.685358418384;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return 0.0757557152904;
                                    } else {
                                        return 0.00263043539979;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0321354441563;
                                    } else {
                                        return 0.0878846543097;
                                    }
                                } else {
                                    if (fs[50] <= -446.5) {
                                        return -0.0581728790412;
                                    } else {
                                        return -0.0143957079333;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1458.0) {
                                if (fs[79] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.33566463368;
                                    } else {
                                        return -0.0199742981088;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.356895736734;
                                    } else {
                                        return 0.116231374912;
                                    }
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.603455580449;
                                    } else {
                                        return -0.00606678027963;
                                    }
                                } else {
                                    return -0.0927344220802;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1087.5) {
                            if (fs[91] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    return -0.0573408110691;
                                } else {
                                    return -0.0529182515359;
                                }
                            } else {
                                if (fs[73] <= 250.0) {
                                    if (fs[0] <= 19.5) {
                                        return -0.0394530301672;
                                    } else {
                                        return -0.0390528665237;
                                    }
                                } else {
                                    return -0.0381257283808;
                                }
                            }
                        } else {
                            if (fs[73] <= 75.0) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0127523708431;
                                    } else {
                                        return -0.0393936693948;
                                    }
                                } else {
                                    return 0.127988730475;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.0635338766306;
                                    } else {
                                        return -0.0373960790774;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0544413928744;
                                    } else {
                                        return -0.0342438647267;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
