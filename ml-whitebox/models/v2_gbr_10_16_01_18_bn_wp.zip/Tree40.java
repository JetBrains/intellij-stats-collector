/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree40 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[99] <= 0.5) {
                    if (fs[4] <= 19.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[50] <= -1143.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0806602320694;
                                    } else {
                                        return -0.0654657278091;
                                    }
                                } else {
                                    if (fs[50] <= -1483.5) {
                                        return 0.171504611341;
                                    } else {
                                        return 0.0583505942677;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1054.0) {
                                    if (fs[56] <= 0.5) {
                                        return 0.117072768437;
                                    } else {
                                        return 0.161543909522;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0863191525497;
                                    } else {
                                        return -0.190862161092;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -996.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.153071123849;
                                    } else {
                                        return 0.251046975807;
                                    }
                                } else {
                                    if (fs[50] <= -1938.0) {
                                        return -0.0199927720626;
                                    } else {
                                        return 0.149794493704;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0792761218518;
                                    } else {
                                        return -0.277489778153;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0675886705839;
                                    } else {
                                        return 0.0126094706198;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[43] <= 0.5) {
                            if (fs[95] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return -0.113476399658;
                                    } else {
                                        return -0.344030821637;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.0518480534634;
                                    } else {
                                        return -0.0946703268213;
                                    }
                                }
                            } else {
                                if (fs[46] <= -0.5) {
                                    if (fs[61] <= -995.5) {
                                        return 0.165643823598;
                                    } else {
                                        return 0.0140726581978;
                                    }
                                } else {
                                    if (fs[50] <= -1693.0) {
                                        return 0.143440709491;
                                    } else {
                                        return -0.0340681279492;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 26.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[69] <= 9994.5) {
                                        return 0.131959474486;
                                    } else {
                                        return 0.226954008189;
                                    }
                                } else {
                                    return -0.0823339441757;
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    return 0.0271435532557;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.29960528901;
                                    } else {
                                        return -0.0651616825942;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9988.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[82] <= 1.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.235287604359;
                                    } else {
                                        return -0.104783480573;
                                    }
                                } else {
                                    return -0.0821454832588;
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.208149220637;
                                    } else {
                                        return 0.0768315120788;
                                    }
                                } else {
                                    if (fs[50] <= -1589.0) {
                                        return 0.454991777285;
                                    } else {
                                        return -0.00514903429405;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.285301595713;
                                    } else {
                                        return -0.129051017481;
                                    }
                                } else {
                                    return 0.0252552688155;
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[50] <= -1548.5) {
                                        return 0.182271077181;
                                    } else {
                                        return -0.108448076301;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return 0.0322289076098;
                                    } else {
                                        return 0.432966649229;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[37] <= 0.5) {
                            if (fs[82] <= 2.5) {
                                if (fs[67] <= -4.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.124575888836;
                                    } else {
                                        return 0.210221147762;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0656414966373;
                                    } else {
                                        return 0.209743416625;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[50] <= -972.0) {
                                        return 0.124677987985;
                                    } else {
                                        return 0.0221430476698;
                                    }
                                } else {
                                    return 0.389728048793;
                                }
                            }
                        } else {
                            if (fs[82] <= 7.0) {
                                if (fs[4] <= 15.0) {
                                    if (fs[50] <= -736.5) {
                                        return 0.363585643463;
                                    } else {
                                        return 0.263619943128;
                                    }
                                } else {
                                    return 0.0136632326274;
                                }
                            } else {
                                return 0.334109431534;
                            }
                        }
                    }
                }
            } else {
                if (fs[40] <= 0.5) {
                    if (fs[29] <= 0.5) {
                        if (fs[82] <= -0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.153813494485;
                                    } else {
                                        return -0.501193857386;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return -0.179829536125;
                                    } else {
                                        return 0.130768167229;
                                    }
                                }
                            } else {
                                return 0.228733738079;
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[50] <= -1047.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.119931611526;
                                    } else {
                                        return 0.081285907003;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return 0.0682143391177;
                                    } else {
                                        return 0.163226422463;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.140300682772;
                                    } else {
                                        return 0.0548737699984;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.170242949681;
                                    } else {
                                        return 0.111976402076;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[50] <= -1303.0) {
                                if (fs[95] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.25821664351;
                                    } else {
                                        return -0.130986746108;
                                    }
                                } else {
                                    return 0.0665628005241;
                                }
                            } else {
                                return 0.252190629342;
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[82] <= 5.5) {
                                    return -0.416484269519;
                                } else {
                                    return -0.167936832632;
                                }
                            } else {
                                return -0.0526358497122;
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 7.5) {
                        if (fs[73] <= 150.0) {
                            if (fs[68] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0844535240345;
                                    } else {
                                        return 0.135439564391;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.0540362323758;
                                    } else {
                                        return 0.150863204848;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[89] <= 0.5) {
                                        return -0.0511248275639;
                                    } else {
                                        return 0.157487996966;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.188482077663;
                                    } else {
                                        return -0.126170637003;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 14.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.376699973192;
                                    } else {
                                        return 0.21327553252;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.024888841511;
                                    } else {
                                        return 0.248453858409;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    return 0.207832559433;
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.291035232442;
                                    } else {
                                        return 0.0354681749051;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9955.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[50] <= -1478.0) {
                                    if (fs[2] <= 5.5) {
                                        return 0.0407129949209;
                                    } else {
                                        return 0.233339053883;
                                    }
                                } else {
                                    return 0.251876390418;
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    return -0.116069818224;
                                } else {
                                    if (fs[50] <= -1468.0) {
                                        return 0.273720123585;
                                    } else {
                                        return 0.115752023107;
                                    }
                                }
                            }
                        } else {
                            return 0.0294427873713;
                        }
                    }
                }
            }
        } else {
            if (fs[11] <= 0.5) {
                if (fs[73] <= 75.0) {
                    if (fs[95] <= 1.5) {
                        if (fs[69] <= 9995.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.102100821077;
                                    } else {
                                        return 0.0373324259565;
                                    }
                                } else {
                                    if (fs[50] <= -1133.0) {
                                        return -0.06816792573;
                                    } else {
                                        return -0.0208996194767;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[50] <= 3.5) {
                                        return 0.00490869001021;
                                    } else {
                                        return -0.0261472047089;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return -0.00726487544606;
                                    } else {
                                        return 0.0955539517987;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 7.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.198856860049;
                                    } else {
                                        return 0.0662988817561;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.0423859469345;
                                    } else {
                                        return -0.0236475632478;
                                    }
                                }
                            } else {
                                if (fs[0] <= 39.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0349349058098;
                                    } else {
                                        return -0.0320757538475;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0693446794169;
                                    } else {
                                        return 0.0243730142037;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 6.5) {
                            if (fs[50] <= -1138.0) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 9.5) {
                                        return 0.122056005751;
                                    } else {
                                        return -0.137212915464;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.00926610073541;
                                    } else {
                                        return 0.0510946260874;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[50] <= -0.5) {
                                        return -0.0319004972845;
                                    } else {
                                        return 0.00615752883627;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0108270598323;
                                    } else {
                                        return 0.0431477241532;
                                    }
                                }
                            }
                        } else {
                            if (fs[7] <= 0.5) {
                                if (fs[69] <= 9997.5) {
                                    if (fs[4] <= 35.5) {
                                        return -0.0115626773622;
                                    } else {
                                        return 0.0202042757779;
                                    }
                                } else {
                                    if (fs[0] <= 13.5) {
                                        return 0.0126407584379;
                                    } else {
                                        return 0.193009140004;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.1134482061;
                                    } else {
                                        return -0.00957890347528;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0158300705826;
                                    } else {
                                        return 0.108896569381;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[61] <= -998.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[2] <= 1.5) {
                                return 0.121232923751;
                            } else {
                                return 0.438912021481;
                            }
                        } else {
                            return 0.0773986097219;
                        }
                    } else {
                        if (fs[50] <= -1093.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0455777055136;
                                    } else {
                                        return -0.0987226556822;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.206455246066;
                                    } else {
                                        return 0.0891988115998;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0744530010202;
                                    } else {
                                        return 0.282973995679;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.00950807992371;
                                    } else {
                                        return 0.157807707203;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[50] <= -21.0) {
                                        return -0.0261722585334;
                                    } else {
                                        return 0.0468663941652;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return 0.0374745371978;
                                    } else {
                                        return -0.00721860285284;
                                    }
                                }
                            } else {
                                if (fs[7] <= 0.5) {
                                    if (fs[67] <= -4.5) {
                                        return 0.0200796100641;
                                    } else {
                                        return -0.00973787443532;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.031813337064;
                                    } else {
                                        return -0.0108437447365;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[40] <= 0.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[75] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    return -0.105669083996;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0591341364744;
                                    } else {
                                        return -0.0942346782582;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.00758507220622;
                                    } else {
                                        return 0.214309965567;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return -0.0511141748675;
                                    } else {
                                        return -0.200211106326;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[4] <= 24.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0169781197246;
                                    } else {
                                        return 0.0438098396689;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0172206829477;
                                    } else {
                                        return -0.0474592046255;
                                    }
                                }
                            } else {
                                if (fs[82] <= 7.5) {
                                    if (fs[82] <= 6.5) {
                                        return -0.018917060633;
                                    } else {
                                        return 0.014054261402;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.0161643540784;
                                    } else {
                                        return 0.120625224706;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 6.5) {
                            if (fs[50] <= -1418.0) {
                                if (fs[73] <= 25.0) {
                                    if (fs[84] <= 0.5) {
                                        return -0.019057793995;
                                    } else {
                                        return 0.350258395519;
                                    }
                                } else {
                                    if (fs[82] <= 4.5) {
                                        return 0.0855220308457;
                                    } else {
                                        return -0.0363183014009;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[69] <= 9931.0) {
                                        return -0.0269244681481;
                                    } else {
                                        return 0.211712608384;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0193671691798;
                                    } else {
                                        return 0.107082577182;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.289949370032;
                                    } else {
                                        return 0.569292705561;
                                    }
                                } else {
                                    if (fs[69] <= 9583.0) {
                                        return 0.21013770208;
                                    } else {
                                        return 0.284647095803;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[69] <= 9982.5) {
                                        return 0.0508890326006;
                                    } else {
                                        return -0.27496840316;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.196986786475;
                                    } else {
                                        return -0.0810811445953;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[34] <= 0.5) {
                        if (fs[69] <= 9978.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.000327433352551;
                                    } else {
                                        return -0.00997299863676;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.00153057117652;
                                    } else {
                                        return 0.198147199652;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.00884553032843;
                                    } else {
                                        return -0.00543713189894;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.00668680678944;
                                    } else {
                                        return -0.00890250780055;
                                    }
                                }
                            }
                        } else {
                            if (fs[89] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0211738607104;
                                    } else {
                                        return 0.00490810044958;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.031080972794;
                                    } else {
                                        return 0.288209778907;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    return 0.510448145078;
                                } else {
                                    return 0.0287315327832;
                                }
                            }
                        }
                    } else {
                        return 0.383589586288;
                    }
                }
            }
        }
    }
}
