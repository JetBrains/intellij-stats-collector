/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree39 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9985.5) {
            if (fs[4] <= 7.5) {
                if (fs[75] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[50] <= -1138.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.149705344866;
                                    } else {
                                        return 0.343517108744;
                                    }
                                } else {
                                    return -0.0977745922963;
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0479986320144;
                                    } else {
                                        return 0.118103419085;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0364632594339;
                                    } else {
                                        return -0.00172171931139;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.181679487496;
                                    } else {
                                        return 0.144319313621;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return -0.0136565312413;
                                    } else {
                                        return 0.0452150099513;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.147908253433;
                                    } else {
                                        return 0.113008947341;
                                    }
                                } else {
                                    if (fs[50] <= -988.0) {
                                        return 0.135656534416;
                                    } else {
                                        return -0.0433973226953;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.20850026711;
                                    } else {
                                        return 0.136409718988;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.105829269514;
                                    } else {
                                        return -0.0759995596187;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return -0.00198337579691;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0659940735194;
                                    } else {
                                        return -0.0254480010824;
                                    }
                                }
                            }
                        } else {
                            if (fs[30] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.136873988351;
                                    } else {
                                        return 0.207081633127;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0216807212749;
                                    } else {
                                        return 0.138814603415;
                                    }
                                }
                            } else {
                                return -0.109610065386;
                            }
                        }
                    }
                } else {
                    if (fs[91] <= 0.5) {
                        if (fs[73] <= 75.0) {
                            if (fs[23] <= 0.5) {
                                if (fs[52] <= -0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.150096904839;
                                    } else {
                                        return 0.0567166572572;
                                    }
                                } else {
                                    if (fs[46] <= -0.5) {
                                        return 0.113494213153;
                                    } else {
                                        return -0.00472739986568;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[50] <= -546.5) {
                                        return 0.319364227569;
                                    } else {
                                        return 0.0594533884747;
                                    }
                                } else {
                                    if (fs[69] <= 9796.5) {
                                        return -0.0194645022335;
                                    } else {
                                        return -0.0596316036962;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1123.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0645775456486;
                                    } else {
                                        return 0.0108441552843;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0203926777807;
                                    } else {
                                        return -0.019900319035;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[50] <= -1448.0) {
                                        return 0.173602135759;
                                    } else {
                                        return 0.0371532493843;
                                    }
                                } else {
                                    if (fs[69] <= 9912.5) {
                                        return 0.0612109265155;
                                    } else {
                                        return 0.141976593834;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[50] <= -1293.5) {
                                    if (fs[50] <= -1488.0) {
                                        return 0.191241594907;
                                    } else {
                                        return 0.264031927373;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.125524214812;
                                    } else {
                                        return 0.101949042983;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[42] <= 0.5) {
                                        return 0.053168827652;
                                    } else {
                                        return 0.382473890746;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0541951589268;
                                    } else {
                                        return 0.00853641395903;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.00822763040778;
                                    } else {
                                        return -0.03900095468;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0120815799781;
                                    } else {
                                        return -0.00878164641187;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[39] <= 0.5) {
                                        return -0.0141757973221;
                                    } else {
                                        return -0.00137723542726;
                                    }
                                } else {
                                    return 0.0337171769528;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[84] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[60] <= 0.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.0227755354072;
                                    } else {
                                        return 0.147829103344;
                                    }
                                } else {
                                    if (fs[82] <= 1.5) {
                                        return -0.175403517848;
                                    } else {
                                        return -0.0031057448371;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    if (fs[2] <= 10.5) {
                                        return 0.123530088625;
                                    } else {
                                        return 0.292007845945;
                                    }
                                } else {
                                    if (fs[4] <= 28.5) {
                                        return -0.367273339238;
                                    } else {
                                        return -0.0897324348263;
                                    }
                                }
                            }
                        } else {
                            if (fs[74] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[4] <= 17.0) {
                                        return -0.0755685462474;
                                    } else {
                                        return -0.23428027231;
                                    }
                                } else {
                                    if (fs[50] <= -1453.0) {
                                        return 0.36353973335;
                                    } else {
                                        return -0.0975526419173;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9979.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.144517458648;
                                    } else {
                                        return 0.181379912037;
                                    }
                                } else {
                                    return 0.0140000048762;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 8.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[4] <= 15.5) {
                                    if (fs[75] <= 0.5) {
                                        return -0.036213681662;
                                    } else {
                                        return 0.00602163687977;
                                    }
                                } else {
                                    if (fs[59] <= -2.5) {
                                        return 0.184316635382;
                                    } else {
                                        return -0.00758266089276;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.0111233038767;
                                    } else {
                                        return 0.00867213831366;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0236152799632;
                                    } else {
                                        return 0.369825097103;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[54] <= 0.5) {
                                    if (fs[0] <= 118.5) {
                                        return -0.00866053323838;
                                    } else {
                                        return -0.00389615803024;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0344843567322;
                                    } else {
                                        return 0.102534488166;
                                    }
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.00791081659914;
                                    } else {
                                        return -0.00323566949166;
                                    }
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return -0.0137274092333;
                                    } else {
                                        return -0.0306280082871;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[12] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[54] <= 0.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0379922075514;
                                    } else {
                                        return 0.102868719119;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.112366491524;
                                    } else {
                                        return -0.101349780892;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.0) {
                                    return 0.427290004424;
                                } else {
                                    return 0.204354764691;
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.029501199515;
                                    } else {
                                        return -0.010938644597;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.00847855691912;
                                    } else {
                                        return -0.0100572267774;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1418.0) {
                                    if (fs[91] <= 0.5) {
                                        return 0.0733797216534;
                                    } else {
                                        return 0.0147671966275;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.198433254971;
                                    } else {
                                        return -0.0129406406279;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[46] <= -3.5) {
                                return -0.102262975192;
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[54] <= 0.5) {
                                        return 0.112306661477;
                                    } else {
                                        return 0.241739700944;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.162110445896;
                                    } else {
                                        return 0.265234631553;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 250.0) {
                                if (fs[25] <= 0.5) {
                                    if (fs[50] <= -1087.5) {
                                        return 0.0443415296005;
                                    } else {
                                        return 0.00536446166044;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return 0.153524558696;
                                    } else {
                                        return 0.0216752210433;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1468.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.513261717855;
                                    } else {
                                        return 0.0808736402251;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.00956761385474;
                                    } else {
                                        return -0.011471979696;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[68] <= 0.5) {
                        if (fs[69] <= 9999.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[50] <= -1002.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.331950923515;
                                    } else {
                                        return 0.0516490194255;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.186613621694;
                                    } else {
                                        return -0.0552770081689;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1488.0) {
                                    return 0.0572999263802;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.301354592847;
                                    } else {
                                        return 0.0227574524669;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.236823032069;
                                    } else {
                                        return 0.0489363655462;
                                    }
                                } else {
                                    if (fs[50] <= -732.0) {
                                        return 0.301669639218;
                                    } else {
                                        return 0.316093334816;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[50] <= -1108.0) {
                                        return 0.142995601841;
                                    } else {
                                        return 0.0554085102002;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.102026587606;
                                    } else {
                                        return 0.235870428492;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 21.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[75] <= 0.5) {
                                        return 0.302447213581;
                                    } else {
                                        return 0.117466951138;
                                    }
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return 0.0917333244591;
                                    } else {
                                        return -0.085597831561;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[94] <= 0.5) {
                                        return -0.175238745401;
                                    } else {
                                        return 0.17819053995;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return 0.150480896812;
                                    } else {
                                        return -0.0380574378009;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[82] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0157225671957;
                                    } else {
                                        return 0.190505978368;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return -0.00999238810533;
                                    } else {
                                        return 0.258243514712;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0468012360519;
                                    } else {
                                        return 0.0335451768942;
                                    }
                                } else {
                                    if (fs[50] <= -987.0) {
                                        return 0.0687547494919;
                                    } else {
                                        return -0.0173044571848;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 5.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[42] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0782903935942;
                                    } else {
                                        return 0.180197207116;
                                    }
                                } else {
                                    if (fs[82] <= 3.0) {
                                        return -0.0869005993536;
                                    } else {
                                        return 0.203768958271;
                                    }
                                }
                            } else {
                                return -0.0118662867115;
                            }
                        } else {
                            return -0.0701641027936;
                        }
                    } else {
                        if (fs[93] <= 0.5) {
                            if (fs[50] <= -987.0) {
                                if (fs[77] <= 0.5) {
                                    if (fs[67] <= -4.5) {
                                        return 0.269646484241;
                                    } else {
                                        return 0.134333678901;
                                    }
                                } else {
                                    return -0.181257731064;
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.059191960358;
                                    } else {
                                        return 0.136930671909;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.101531926908;
                                    } else {
                                        return 0.198960946989;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= 0.5) {
                                if (fs[73] <= 250.0) {
                                    if (fs[50] <= -1268.0) {
                                        return 0.117001248881;
                                    } else {
                                        return -0.0144359904822;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.104354551295;
                                    } else {
                                        return 0.152991714792;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return -0.505757405716;
                                    } else {
                                        return -0.290376367235;
                                    }
                                } else {
                                    return 0.00816965106372;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 3.5) {
                    if (fs[50] <= -1418.0) {
                        if (fs[69] <= 9999.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[50] <= -1488.0) {
                                        return -0.00521145118247;
                                    } else {
                                        return 0.0836598613051;
                                    }
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.0599407296087;
                                    } else {
                                        return 0.0136287972704;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0850650756308;
                                    } else {
                                        return 0.293898656935;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.157667967177;
                                    } else {
                                        return 0.00642772741023;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1968.0) {
                                if (fs[73] <= 25.0) {
                                    return 0.133579904068;
                                } else {
                                    return 0.385106333095;
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.108400036133;
                                    } else {
                                        return -0.193302977797;
                                    }
                                } else {
                                    return 0.451144279026;
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 7.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0354931504597;
                                    } else {
                                        return 0.157783072641;
                                    }
                                } else {
                                    if (fs[0] <= 39.5) {
                                        return 0.00252398070805;
                                    } else {
                                        return -0.0563235929917;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0730996657822;
                                    } else {
                                        return -0.0125775649698;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0149528586659;
                                    } else {
                                        return -0.0469720811342;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[50] <= 3.5) {
                                        return -0.03475353825;
                                    } else {
                                        return -0.0136520529865;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return -0.00957478354012;
                                    } else {
                                        return 0.203321135491;
                                    }
                                }
                            } else {
                                if (fs[0] <= 60.0) {
                                    if (fs[0] <= 8.5) {
                                        return 0.0626747813723;
                                    } else {
                                        return -0.0369603517689;
                                    }
                                } else {
                                    return 0.24401568458;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1418.0) {
                        if (fs[68] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.235177252216;
                                    } else {
                                        return 0.569897353835;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.324238795167;
                                    } else {
                                        return -0.0178869591592;
                                    }
                                }
                            } else {
                                return 0.51551148375;
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.108305466896;
                                    } else {
                                        return 0.0281258764308;
                                    }
                                } else {
                                    return -0.312151140008;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.012189562736;
                                    } else {
                                        return 0.171921474382;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.212623505862;
                                    } else {
                                        return 0.369998376995;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[4] <= 31.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.0488608540911;
                                    } else {
                                        return -0.00794287810124;
                                    }
                                } else {
                                    return 0.244250380672;
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.287935910375;
                                    } else {
                                        return -0.0206555109;
                                    }
                                } else {
                                    return -0.109847477757;
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 21.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0737154954202;
                                    } else {
                                        return -0.0257668975051;
                                    }
                                } else {
                                    if (fs[50] <= -1037.0) {
                                        return 0.0997361565692;
                                    } else {
                                        return -0.0153134434871;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[69] <= 9997.5) {
                                        return -0.0315143885765;
                                    } else {
                                        return -0.0718138348306;
                                    }
                                } else {
                                    if (fs[4] <= 18.0) {
                                        return 0.206364002501;
                                    } else {
                                        return 0.015044027726;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
