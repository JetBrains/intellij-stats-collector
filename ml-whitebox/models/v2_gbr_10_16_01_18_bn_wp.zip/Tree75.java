/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree75 {
    public double calcTree(double... fs) {
        if (fs[61] <= -997.5) {
            if (fs[2] <= 1.5) {
                if (fs[44] <= 0.5) {
                    if (fs[68] <= 0.5) {
                        if (fs[4] <= 13.5) {
                            if (fs[4] <= 10.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[61] <= -998.5) {
                                        return -0.0271990489391;
                                    } else {
                                        return -0.0931674876042;
                                    }
                                } else {
                                    return 0.0557424003808;
                                }
                            } else {
                                return -0.153218789934;
                            }
                        } else {
                            return 0.129999448317;
                        }
                    } else {
                        if (fs[6] <= 0.5) {
                            return -0.0685028227717;
                        } else {
                            if (fs[4] <= 18.5) {
                                if (fs[69] <= 9995.5) {
                                    if (fs[50] <= -1458.0) {
                                        return 0.120126324488;
                                    } else {
                                        return 0.0341105264404;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0280307135762;
                                    } else {
                                        return 0.108361709889;
                                    }
                                }
                            } else {
                                return -0.104473110916;
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[50] <= -961.5) {
                                return -0.0198747415788;
                            } else {
                                return -0.0315348908292;
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                return -0.0107970903345;
                            } else {
                                return -0.0138985675553;
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                return -0.0343870606315;
                            } else {
                                if (fs[73] <= 100.0) {
                                    if (fs[0] <= 7.5) {
                                        return -0.0223317978708;
                                    } else {
                                        return -0.0179399452817;
                                    }
                                } else {
                                    if (fs[50] <= -986.5) {
                                        return 0.0237808429785;
                                    } else {
                                        return -0.0101402599252;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 1.5) {
                                return -0.00405967680099;
                            } else {
                                if (fs[73] <= 250.0) {
                                    return -0.00492093722418;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.00383631530361;
                                    } else {
                                        return -0.000500587506075;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[57] <= 0.5) {
                    if (fs[95] <= 1.5) {
                        return -0.0996255457167;
                    } else {
                        if (fs[54] <= 0.5) {
                            if (fs[50] <= -957.0) {
                                if (fs[50] <= -1138.0) {
                                    return -0.0231704990327;
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0362402759214;
                                    } else {
                                        return -0.0101161491684;
                                    }
                                }
                            } else {
                                return -0.0572650821347;
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                return 0.0758985626108;
                            } else {
                                if (fs[18] <= 0.5) {
                                    return -0.112007714396;
                                } else {
                                    return 0.0575256828621;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[33] <= 0.5) {
                            if (fs[97] <= 1.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.259611477579;
                                    } else {
                                        return 0.0723509152026;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0654601165511;
                                    } else {
                                        return -0.0175073601512;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0296624560658;
                                    } else {
                                        return 0.072255546416;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.189552031796;
                                    } else {
                                        return 0.270985299118;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[67] <= -4.0) {
                                    if (fs[61] <= -998.5) {
                                        return -0.110413712118;
                                    } else {
                                        return 0.0676802561442;
                                    }
                                } else {
                                    if (fs[50] <= -1283.0) {
                                        return 0.268267374223;
                                    } else {
                                        return 0.0665263311092;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[73] <= 250.0) {
                                        return 0.0646669339951;
                                    } else {
                                        return -0.00662920393727;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.176084700105;
                                    } else {
                                        return 0.084591502255;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[4] <= 13.5) {
                                return -0.0215061531802;
                            } else {
                                return -0.0151579610844;
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0631634197799;
                                    } else {
                                        return -0.0256433247784;
                                    }
                                } else {
                                    return -0.000803845595071;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[50] <= -986.0) {
                                        return 0.0134820751689;
                                    } else {
                                        return -0.00941539933632;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0062466677534;
                                    } else {
                                        return -0.016096190847;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[69] <= 9981.5) {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 3.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[82] <= -0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.195621731246;
                                    } else {
                                        return -0.145933539427;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.0190856588018;
                                    } else {
                                        return -0.134978351465;
                                    }
                                }
                            } else {
                                if (fs[50] <= -880.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.00893972115033;
                                    } else {
                                        return 0.198927437985;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0762686716035;
                                    } else {
                                        return -0.00574051610402;
                                    }
                                }
                            }
                        } else {
                            if (fs[73] <= 25.0) {
                                if (fs[43] <= 0.5) {
                                    if (fs[82] <= 6.0) {
                                        return -0.0850834687392;
                                    } else {
                                        return 0.144251222686;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0353541528707;
                                    } else {
                                        return 0.16070282829;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1478.5) {
                                    if (fs[50] <= -1493.5) {
                                        return 0.0872935400897;
                                    } else {
                                        return -0.0201509702365;
                                    }
                                } else {
                                    if (fs[50] <= -1068.0) {
                                        return 0.101640665074;
                                    } else {
                                        return 0.0230338101711;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[79] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[50] <= -486.5) {
                                        return 0.0294113851062;
                                    } else {
                                        return -0.00884648932962;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.130141080783;
                                    } else {
                                        return 0.076540963202;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0574043079377;
                                    } else {
                                        return -0.0406054695013;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.138938544534;
                                    } else {
                                        return 0.207634037085;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 4.5) {
                                if (fs[42] <= 0.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.0535697824209;
                                    } else {
                                        return -0.060500429972;
                                    }
                                } else {
                                    if (fs[50] <= -1478.0) {
                                        return -0.0050538692806;
                                    } else {
                                        return -0.238932180956;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0535311220443;
                                    } else {
                                        return -0.00177938702172;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.190688113716;
                                    } else {
                                        return 0.00184402262485;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[34] <= 0.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[75] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return -0.0220843187567;
                                    } else {
                                        return 0.00772714585812;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.00250592162967;
                                    } else {
                                        return 0.00784387991989;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[67] <= -1.5) {
                                        return -0.000972159451629;
                                    } else {
                                        return -0.00541787373104;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.00243748367793;
                                    } else {
                                        return 0.0381888768868;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.00916514473719;
                                    } else {
                                        return -0.0264057532688;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.284649319744;
                                    } else {
                                        return -0.105637595126;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.00274600778785;
                                    } else {
                                        return -0.00236580939844;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.00472900516742;
                                    } else {
                                        return -0.00379404513857;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 5.5) {
                            return 0.0445526692715;
                        } else {
                            if (fs[0] <= 1.5) {
                                return 0.102349196953;
                            } else {
                                return 0.243174499573;
                            }
                        }
                    }
                }
            } else {
                if (fs[37] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[50] <= -1493.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.101328467371;
                                    } else {
                                        return 0.00229264601523;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0051262874036;
                                    } else {
                                        return 0.0160517293192;
                                    }
                                }
                            } else {
                                if (fs[50] <= -21.0) {
                                    if (fs[0] <= 0.5) {
                                        return -0.0488976338805;
                                    } else {
                                        return 0.0653304262868;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0378245904313;
                                    } else {
                                        return 0.142479952923;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                return 0.0168984049129;
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0687787053515;
                                    } else {
                                        return 0.196348473262;
                                    }
                                } else {
                                    if (fs[50] <= -1118.5) {
                                        return 0.159941192922;
                                    } else {
                                        return 0.02064763262;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 5.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[55] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.0358997725594;
                                    } else {
                                        return 0.0828641478097;
                                    }
                                } else {
                                    return -0.283849994949;
                                }
                            } else {
                                if (fs[69] <= 9993.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0448840862989;
                                    } else {
                                        return 0.298720572038;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0419476985137;
                                    } else {
                                        return 0.187216609806;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 30.5) {
                                if (fs[4] <= 29.5) {
                                    if (fs[50] <= -1413.5) {
                                        return 0.0248659858879;
                                    } else {
                                        return 0.00303015467838;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.0377076984481;
                                    } else {
                                        return 0.222673118801;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.0552448334424;
                                    } else {
                                        return -0.13688095067;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0456113589961;
                                    } else {
                                        return -0.146710729227;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 8.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -1232.5) {
                                        return 0.14615731942;
                                    } else {
                                        return 0.0105522620848;
                                    }
                                } else {
                                    if (fs[50] <= -1247.5) {
                                        return 0.12278743157;
                                    } else {
                                        return 0.0501208564315;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9998.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.14701757669;
                                    } else {
                                        return 0.0338614711735;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.09977020791;
                                    } else {
                                        return 0.0818019175198;
                                    }
                                }
                            }
                        } else {
                            return 0.205754453603;
                        }
                    } else {
                        if (fs[69] <= 9983.5) {
                            return 0.134550415833;
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[73] <= 75.0) {
                                    return -0.0730144602079;
                                } else {
                                    return -0.0958024165423;
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    return -0.0824418715599;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.03279305436;
                                    } else {
                                        return 0.074494464686;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
