/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree1 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[95] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[15] <= 0.5) {
                        if (fs[34] <= 0.5) {
                            if (fs[56] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0175340126877;
                                    } else {
                                        return 0.191565746286;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return 0.429077991615;
                                    } else {
                                        return 0.794519152415;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[50] <= -1138.5) {
                                        return 0.458062715893;
                                    } else {
                                        return 0.758848756603;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0373213684253;
                                    } else {
                                        return 0.230183532448;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[4] <= 5.5) {
                                        return 0.805279205994;
                                    } else {
                                        return 0.747214503876;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.853641661454;
                                    } else {
                                        return 0.71959379264;
                                    }
                                }
                            } else {
                                return 0.334639878214;
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[50] <= -1053.5) {
                                if (fs[4] <= 3.5) {
                                    return 0.762853605419;
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.85227328478;
                                    } else {
                                        return 0.896757157783;
                                    }
                                }
                            } else {
                                return -0.0719163214639;
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                return -0.062195803874;
                            } else {
                                if (fs[4] <= 3.5) {
                                    return 0.125381189923;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.249853940162;
                                    } else {
                                        return 0.0590979966651;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 7.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[50] <= -1133.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.84052452689;
                                    } else {
                                        return 0.87635221474;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.891926823444;
                                    } else {
                                        return 0.600943881888;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    return 0.731894694506;
                                } else {
                                    if (fs[50] <= -1053.0) {
                                        return 0.199583461624;
                                    } else {
                                        return 0.0164022333738;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[0] <= 0.5) {
                                    return 0.680961231385;
                                } else {
                                    if (fs[50] <= -477.0) {
                                        return -0.0619614880253;
                                    } else {
                                        return -0.0579026394195;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return -0.0569822785276;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.064005999267;
                                    } else {
                                        return -0.0590146328875;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                return 0.672789541339;
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.882945406211;
                                    } else {
                                        return 0.895582297781;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.768321203064;
                                    } else {
                                        return 0.896463428918;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0488242219404;
                                    } else {
                                        return 0.000329904875729;
                                    }
                                } else {
                                    return 0.00651788168078;
                                }
                            } else {
                                if (fs[50] <= -978.0) {
                                    return -0.0550970651834;
                                } else {
                                    return -0.055842963667;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[97] <= 0.5) {
                        if (fs[4] <= 21.5) {
                            return 0.465003592832;
                        } else {
                            if (fs[4] <= 29.5) {
                                if (fs[50] <= -1563.0) {
                                    return 0.0601369721583;
                                } else {
                                    return -0.0690225491269;
                                }
                            } else {
                                if (fs[4] <= 32.5) {
                                    return 0.339339251361;
                                } else {
                                    if (fs[50] <= -1348.0) {
                                        return -0.0382174097782;
                                    } else {
                                        return 0.264836819396;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.3485124067;
                    }
                } else {
                    if (fs[69] <= 4847.0) {
                        if (fs[50] <= -1578.0) {
                            if (fs[4] <= 39.5) {
                                if (fs[4] <= 22.5) {
                                    return -0.0229947062246;
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return -0.0559141417093;
                                    } else {
                                        return -0.0582551611036;
                                    }
                                }
                            } else {
                                return 0.156030553182;
                            }
                        } else {
                            if (fs[4] <= 31.5) {
                                if (fs[0] <= 5.5) {
                                    if (fs[50] <= -1138.0) {
                                        return -0.034219387578;
                                    } else {
                                        return -0.0522431447627;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return -0.0507039785284;
                                    } else {
                                        return -0.0541263166265;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[4] <= 47.5) {
                                        return -0.055166386383;
                                    } else {
                                        return -0.0513675235333;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.00762319555141;
                                    } else {
                                        return -0.0553414495197;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.052505400925;
                    }
                }
            }
        } else {
            if (fs[69] <= 9993.5) {
                if (fs[0] <= 0.5) {
                    if (fs[84] <= 0.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[50] <= -1309.0) {
                                    if (fs[73] <= 25.0) {
                                        return 0.0106798329669;
                                    } else {
                                        return 0.419406363344;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.628542007163;
                                    } else {
                                        return -0.0282267921683;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.460009300932;
                                    } else {
                                        return 0.268441931561;
                                    }
                                } else {
                                    if (fs[100] <= 0.5) {
                                        return 0.553143534803;
                                    } else {
                                        return 0.760079936601;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 12.5) {
                                if (fs[82] <= 5.5) {
                                    if (fs[80] <= 0.5) {
                                        return 0.55058898865;
                                    } else {
                                        return 0.799705441404;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.846914828702;
                                    } else {
                                        return 0.671841398473;
                                    }
                                }
                            } else {
                                if (fs[62] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.352736403166;
                                    } else {
                                        return 0.527581434371;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.647563908521;
                                    } else {
                                        return 0.826103604475;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[97] <= 1.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.764192981059;
                                    } else {
                                        return 0.226245618339;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.464015711183;
                                    } else {
                                        return 0.677101740777;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[50] <= -1588.0) {
                                        return 0.758501478898;
                                    } else {
                                        return 0.516835731999;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.635892917969;
                                    } else {
                                        return 0.730407903701;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.825874994211;
                                    } else {
                                        return 0.761465189934;
                                    }
                                } else {
                                    if (fs[4] <= 31.5) {
                                        return 0.370753197373;
                                    } else {
                                        return 0.0522589746759;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    return 0.034546240052;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.317070187686;
                                    } else {
                                        return 0.453922848369;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[73] <= 25.0) {
                            if (fs[95] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.034510991693;
                                    } else {
                                        return -0.00622597842159;
                                    }
                                } else {
                                    if (fs[82] <= 6.0) {
                                        return -0.0363756985238;
                                    } else {
                                        return 0.078433799684;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0226140044859;
                                    } else {
                                        return 0.0923682712463;
                                    }
                                } else {
                                    if (fs[50] <= -1283.0) {
                                        return 0.284470229895;
                                    } else {
                                        return 0.12458361084;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[82] <= 5.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0839079462762;
                                    } else {
                                        return 0.168394113187;
                                    }
                                } else {
                                    if (fs[50] <= -1413.5) {
                                        return 0.0093215243327;
                                    } else {
                                        return -0.0438702576484;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.278773669328;
                                    } else {
                                        return 0.732109571811;
                                    }
                                } else {
                                    if (fs[69] <= 9620.0) {
                                        return -0.00513496875617;
                                    } else {
                                        return 0.0701822019006;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[73] <= 25.0) {
                            if (fs[18] <= 0.5) {
                                if (fs[69] <= 9842.5) {
                                    if (fs[95] <= 0.5) {
                                        return -0.0531177872594;
                                    } else {
                                        return -0.0443855618592;
                                    }
                                } else {
                                    if (fs[50] <= -1398.0) {
                                        return 0.0284777409422;
                                    } else {
                                        return -0.0263023299731;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.00828141524529;
                                    } else {
                                        return -0.0212714950678;
                                    }
                                } else {
                                    if (fs[0] <= 20.5) {
                                        return -0.0425703573569;
                                    } else {
                                        return -0.0506271551848;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.00163464621114;
                                    } else {
                                        return 0.187900623453;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0431139649723;
                                    } else {
                                        return -0.0198023000604;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0506202316765;
                                    } else {
                                        return -0.0541551152434;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0548892985336;
                                    } else {
                                        return -0.0523800422161;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[50] <= -972.0) {
                        if (fs[98] <= 0.5) {
                            if (fs[87] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.715966579678;
                                    } else {
                                        return 0.818450584632;
                                    }
                                } else {
                                    if (fs[50] <= -1578.0) {
                                        return 0.772530264588;
                                    } else {
                                        return 0.603445157288;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.217315037081;
                                    } else {
                                        return -0.0874047808334;
                                    }
                                } else {
                                    return -0.0841135552565;
                                }
                            }
                        } else {
                            if (fs[50] <= -1458.0) {
                                if (fs[57] <= 0.5) {
                                    return 0.58782609703;
                                } else {
                                    return 0.826809617302;
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.894392774909;
                                    } else {
                                        return 0.816975801942;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return 0.749851841702;
                                    } else {
                                        return 0.867909440957;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[61] <= -498.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.811143785708;
                                    } else {
                                        return 0.891547284006;
                                    }
                                } else {
                                    return 0.694444645665;
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.425586789195;
                                    } else {
                                        return 0.703365948661;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.275331503498;
                                    } else {
                                        return 0.507677526358;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[61] <= -498.5) {
                                        return 0.908051428902;
                                    } else {
                                        return 0.527950662559;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.618278556973;
                                    } else {
                                        return 0.286908771596;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.843151558852;
                                    } else {
                                        return 0.659817752909;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.870464721918;
                                    } else {
                                        return 0.788231374211;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1408.0) {
                        if (fs[69] <= 9999.5) {
                            if (fs[82] <= 7.5) {
                                if (fs[69] <= 9998.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.167163466116;
                                    } else {
                                        return 0.085982982899;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.250490625394;
                                    } else {
                                        return -0.0505400815031;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.410601745145;
                                    } else {
                                        return 0.272916427435;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.554266070519;
                                    } else {
                                        return 0.747533510424;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 998.0) {
                                if (fs[40] <= 0.5) {
                                    if (fs[82] <= 6.5) {
                                        return 0.425449567304;
                                    } else {
                                        return 0.616633265591;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return -0.0232291974566;
                                    } else {
                                        return -0.0377510043513;
                                    }
                                }
                            } else {
                                return 0.938259186275;
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[65] <= 1.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.168805281866;
                                    } else {
                                        return 0.113183473679;
                                    }
                                } else {
                                    if (fs[61] <= -995.5) {
                                        return 0.039635675154;
                                    } else {
                                        return -0.0436872712151;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    return 0.304423358041;
                                } else {
                                    return 0.506416884422;
                                }
                            }
                        } else {
                            if (fs[50] <= -1072.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.502578124316;
                                    } else {
                                        return -0.0128063931939;
                                    }
                                } else {
                                    if (fs[50] <= -1128.0) {
                                        return 0.100038337725;
                                    } else {
                                        return 0.444392285924;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0236383091237;
                                    } else {
                                        return -0.049073740554;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return 0.12962214495;
                                    } else {
                                        return -0.0509896473819;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
