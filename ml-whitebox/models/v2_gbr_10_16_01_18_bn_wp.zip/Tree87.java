/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree87 {
    public double calcTree(double... fs) {
        if (fs[69] <= 9996.5) {
            if (fs[75] <= 0.5) {
                if (fs[4] <= 2.5) {
                    if (fs[50] <= -1138.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[40] <= 0.5) {
                                return 0.0509149237142;
                            } else {
                                return -0.0275000721107;
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                return 0.198142975747;
                            } else {
                                return 0.107626695943;
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            return 0.0215919115922;
                        } else {
                            return -0.113275061203;
                        }
                    }
                } else {
                    if (fs[73] <= 100.0) {
                        if (fs[4] <= 5.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0973091290177;
                                    } else {
                                        return 0.00261908446215;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return -0.0156950884594;
                                    } else {
                                        return 0.0690194820267;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0039750525838;
                                    } else {
                                        return 0.0283900230133;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.0649436835393;
                                    } else {
                                        return 0.264438852282;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.133326675611;
                                    } else {
                                        return -0.0126203063795;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0861191035333;
                                    } else {
                                        return 0.0124555401352;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0122330770817;
                                    } else {
                                        return 0.0195422484501;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0216838628106;
                                    } else {
                                        return -0.0966819345715;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 20.5) {
                            if (fs[69] <= 4847.0) {
                                if (fs[4] <= 19.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.006881318407;
                                    } else {
                                        return -0.00217176968125;
                                    }
                                } else {
                                    if (fs[50] <= -1343.0) {
                                        return -0.0790818327624;
                                    } else {
                                        return -0.0128258662219;
                                    }
                                }
                            } else {
                                return 0.0339724024606;
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 39.5) {
                                    if (fs[4] <= 32.5) {
                                        return -0.0400301848961;
                                    } else {
                                        return -0.163729526795;
                                    }
                                } else {
                                    if (fs[50] <= -1578.0) {
                                        return 0.106296434495;
                                    } else {
                                        return 0.0626923137813;
                                    }
                                }
                            } else {
                                return -0.000850400099418;
                            }
                        }
                    }
                }
            } else {
                if (fs[84] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[54] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[67] <= -3.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0375284338218;
                                    } else {
                                        return 0.00528518373201;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.00143687236737;
                                    } else {
                                        return 0.00698411235893;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[50] <= -1078.5) {
                                        return 0.00781652820507;
                                    } else {
                                        return -0.000527706842749;
                                    }
                                } else {
                                    if (fs[69] <= 9992.5) {
                                        return 0.0355037627147;
                                    } else {
                                        return -0.0587840195578;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0197052517459;
                                    } else {
                                        return -0.0665848004602;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0340402075912;
                                    } else {
                                        return 0.172987392689;
                                    }
                                }
                            } else {
                                return -0.124442860965;
                            }
                        }
                    } else {
                        if (fs[50] <= -1118.0) {
                            if (fs[4] <= 15.0) {
                                if (fs[69] <= 4733.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.151811119464;
                                    } else {
                                        return 0.343766946107;
                                    }
                                } else {
                                    if (fs[69] <= 9868.0) {
                                        return -1.91226526507e-05;
                                    } else {
                                        return 0.106997539861;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    return -0.195680086318;
                                } else {
                                    return -0.00862622221159;
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[0] <= 1.5) {
                                    return 0.338669609636;
                                } else {
                                    return 0.00877653721124;
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0450635198769;
                                    } else {
                                        return 0.00322651074676;
                                    }
                                } else {
                                    return -0.0151527421795;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[50] <= -1299.0) {
                                    if (fs[0] <= 12.5) {
                                        return 0.0854097083812;
                                    } else {
                                        return -0.0867934567182;
                                    }
                                } else {
                                    if (fs[4] <= 1.5) {
                                        return -0.0240450713189;
                                    } else {
                                        return 0.0178070842549;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[50] <= -1304.0) {
                                        return 0.194818516922;
                                    } else {
                                        return -0.0562342183206;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.066544252491;
                                    } else {
                                        return -0.00654058316462;
                                    }
                                }
                            }
                        } else {
                            if (fs[61] <= -996.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[46] <= -2.5) {
                                        return -0.119317250629;
                                    } else {
                                        return -0.011732706813;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0300049638226;
                                    } else {
                                        return -0.00142745513686;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1393.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0612306533689;
                                    } else {
                                        return 0.00764480219879;
                                    }
                                } else {
                                    if (fs[69] <= 8421.0) {
                                        return -0.00133799292682;
                                    } else {
                                        return -0.0165339973641;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 13.5) {
                            if (fs[50] <= -1292.5) {
                                if (fs[73] <= 250.0) {
                                    if (fs[95] <= 1.5) {
                                        return 0.0379774302878;
                                    } else {
                                        return 0.104591898229;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.0359309685333;
                                    } else {
                                        return -0.1083661466;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0154109617532;
                                    } else {
                                        return -0.00640299258779;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.140382166021;
                                    } else {
                                        return 0.00670756296342;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[69] <= 9960.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.00253430850846;
                                    } else {
                                        return -0.024170751965;
                                    }
                                } else {
                                    if (fs[69] <= 9973.5) {
                                        return -0.0762536161903;
                                    } else {
                                        return -0.0229827792465;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.108531389246;
                                    } else {
                                        return -0.00146744754244;
                                    }
                                } else {
                                    if (fs[69] <= 9360.5) {
                                        return 0.040779721704;
                                    } else {
                                        return -0.0607899512255;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[4] <= 5.5) {
                if (fs[93] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[82] <= 7.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.0577552371433;
                                    } else {
                                        return 0.423047416711;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0286495467479;
                                    } else {
                                        return 0.0200257774792;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.142853495623;
                                    } else {
                                        return 0.249371514063;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.052404748869;
                                    } else {
                                        return 0.0674320672561;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[82] <= 3.0) {
                                    if (fs[33] <= 0.5) {
                                        return -3.3105927166e-05;
                                    } else {
                                        return 0.127274909158;
                                    }
                                } else {
                                    if (fs[67] <= -4.0) {
                                        return -0.126010958502;
                                    } else {
                                        return -0.081634676162;
                                    }
                                }
                            } else {
                                if (fs[56] <= 0.5) {
                                    if (fs[82] <= 1.0) {
                                        return -0.062384444471;
                                    } else {
                                        return 0.105202659113;
                                    }
                                } else {
                                    if (fs[0] <= 11.5) {
                                        return -0.186204554151;
                                    } else {
                                        return -0.0464970931152;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0178413508004;
                                    } else {
                                        return -0.10845561064;
                                    }
                                } else {
                                    return -0.13294756522;
                                }
                            } else {
                                if (fs[67] <= -4.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.181594581465;
                                    } else {
                                        return 0.0648174223067;
                                    }
                                } else {
                                    if (fs[82] <= 5.5) {
                                        return 0.0595390681068;
                                    } else {
                                        return 0.00801788201632;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[73] <= 25.0) {
                                    return 0.0710801562231;
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.259546999558;
                                    } else {
                                        return -0.0612525123942;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1478.0) {
                                    if (fs[56] <= 0.5) {
                                        return 0.11389678117;
                                    } else {
                                        return -0.0535806897879;
                                    }
                                } else {
                                    return -0.0952264152171;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[55] <= 0.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[86] <= 0.5) {
                                        return -0.00611745358184;
                                    } else {
                                        return 0.0973544085713;
                                    }
                                } else {
                                    return 0.358243821125;
                                }
                            } else {
                                return 0.256261822064;
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.133555506948;
                                    } else {
                                        return 0.0336042728331;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.106161064663;
                                    } else {
                                        return 0.0240670608803;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1048.0) {
                                    if (fs[0] <= 3.5) {
                                        return 0.0641118855699;
                                    } else {
                                        return 0.452385999792;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0976767598129;
                                    } else {
                                        return -0.0438017945746;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9999.5) {
                            return -0.14659305264;
                        } else {
                            return -0.244038610625;
                        }
                    }
                }
            } else {
                if (fs[50] <= -1403.5) {
                    if (fs[40] <= 0.5) {
                        if (fs[82] <= 2.5) {
                            if (fs[50] <= -1478.0) {
                                if (fs[82] <= 1.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0592771269782;
                                    } else {
                                        return 0.0232010975313;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0309673307468;
                                    } else {
                                        return 0.16526228708;
                                    }
                                }
                            } else {
                                if (fs[73] <= 25.0) {
                                    if (fs[50] <= -1468.0) {
                                        return -0.102638037196;
                                    } else {
                                        return 0.0933124299226;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.123277151568;
                                    } else {
                                        return -0.0528113763571;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 6.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[69] <= 9997.5) {
                                        return -0.260123473217;
                                    } else {
                                        return -0.112500091317;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.265931010882;
                                    } else {
                                        return 0.203997813794;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0264047720999;
                                    } else {
                                        return -0.0907760839698;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.120804922881;
                                    } else {
                                        return -0.226640566284;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[56] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[82] <= 2.0) {
                                    return -0.00974508839462;
                                } else {
                                    return -0.278164423346;
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[4] <= 12.0) {
                                        return -0.226975313867;
                                    } else {
                                        return -0.270439599166;
                                    }
                                } else {
                                    return -0.235221710969;
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                return 0.174514067294;
                            } else {
                                if (fs[4] <= 15.5) {
                                    return -0.0583627470853;
                                } else {
                                    return -0.266877562792;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[99] <= 0.5) {
                        if (fs[39] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.102366506301;
                                    } else {
                                        return -0.00809719020058;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0151623966657;
                                    } else {
                                        return 0.0183060516146;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.0192657021512;
                                    } else {
                                        return 0.0570401809042;
                                    }
                                } else {
                                    if (fs[50] <= -1087.5) {
                                        return -0.214775804276;
                                    } else {
                                        return -0.152245364309;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 9.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.0345651746405;
                                    } else {
                                        return -0.180100347084;
                                    }
                                } else {
                                    return 0.230165904545;
                                }
                            } else {
                                if (fs[0] <= 40.5) {
                                    if (fs[50] <= -1137.5) {
                                        return -0.0524423461462;
                                    } else {
                                        return 0.00940110177887;
                                    }
                                } else {
                                    return 0.193939014763;
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 1.5) {
                            if (fs[82] <= -0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.176116162217;
                                    } else {
                                        return 0.347118452889;
                                    }
                                } else {
                                    if (fs[0] <= 10.0) {
                                        return -0.0553508380747;
                                    } else {
                                        return -0.0274392787636;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1118.5) {
                                    return 0.289882965547;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.125860378183;
                                    } else {
                                        return 0.225415561664;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 14.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0733364760932;
                                    } else {
                                        return 0.0317486145527;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0514938529611;
                                    } else {
                                        return -0.00702997154289;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1128.0) {
                                    return -0.198263842123;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return 0.0417635266335;
                                    } else {
                                        return -0.127570130324;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
