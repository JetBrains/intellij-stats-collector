/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree55 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[54] <= 0.5) {
                if (fs[61] <= -996.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[4] <= 22.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[97] <= 1.5) {
                                    return -0.0663266266341;
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.122351348657;
                                    } else {
                                        return -0.0169157689209;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[50] <= -1093.5) {
                                        return 0.0824014482487;
                                    } else {
                                        return 0.0239590596407;
                                    }
                                } else {
                                    return -0.0488602375106;
                                }
                            }
                        } else {
                            return -0.119754839009;
                        }
                    } else {
                        if (fs[69] <= 9999.5) {
                            if (fs[46] <= -1.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.25488449628;
                                    } else {
                                        return 0.0824111247618;
                                    }
                                } else {
                                    if (fs[95] <= 1.5) {
                                        return 0.0556668249559;
                                    } else {
                                        return 0.211742486835;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[82] <= 1.0) {
                                        return 0.217953057359;
                                    } else {
                                        return 0.110185690932;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0419362614601;
                                    } else {
                                        return 0.122505557951;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1052.0) {
                                if (fs[4] <= 7.5) {
                                    return -0.224993120373;
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0619693441074;
                                    } else {
                                        return 0.0892139956294;
                                    }
                                }
                            } else {
                                if (fs[46] <= -1.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0390693070161;
                                    } else {
                                        return 0.00650193478068;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.121086708873;
                                    } else {
                                        return 0.199096475943;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= -0.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[67] <= -4.0) {
                                        return -0.362698673815;
                                    } else {
                                        return -0.0684420517733;
                                    }
                                } else {
                                    return 0.330061764424;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.13899234421;
                                } else {
                                    if (fs[50] <= -1468.0) {
                                        return -0.285180297512;
                                    } else {
                                        return -0.181509105382;
                                    }
                                }
                            }
                        } else {
                            return 0.253721868433;
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            if (fs[87] <= 0.5) {
                                if (fs[50] <= -1598.0) {
                                    if (fs[4] <= 6.5) {
                                        return -0.00784686929612;
                                    } else {
                                        return 0.137173971498;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return 0.0476051590406;
                                    } else {
                                        return 0.0939747367239;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.273278737016;
                                    } else {
                                        return 0.0381374255129;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0192977756068;
                                    } else {
                                        return -0.218030617603;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -987.5) {
                                if (fs[50] <= -1133.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0393227920767;
                                    } else {
                                        return -0.0146390087792;
                                    }
                                } else {
                                    if (fs[97] <= 1.5) {
                                        return 0.0815467051144;
                                    } else {
                                        return 0.0547166507877;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0302695223736;
                                    } else {
                                        return 0.0834620061432;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0185699844544;
                                    } else {
                                        return 0.0710155771458;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[18] <= 0.5) {
                    if (fs[82] <= 1.0) {
                        if (fs[4] <= 7.5) {
                            return 0.190895987943;
                        } else {
                            return 0.0427562863782;
                        }
                    } else {
                        return -0.0847068797653;
                    }
                } else {
                    if (fs[61] <= -995.0) {
                        if (fs[4] <= 7.5) {
                            return -0.0120817795591;
                        } else {
                            if (fs[61] <= -996.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[50] <= -561.5) {
                                        return 0.253430869532;
                                    } else {
                                        return 0.220667025793;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.187695455396;
                                    } else {
                                        return 0.155675489105;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    return 0.143991308042;
                                } else {
                                    return 0.123668050011;
                                }
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[50] <= -1128.0) {
                                if (fs[4] <= 16.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.291098738491;
                                    } else {
                                        return 0.181791014347;
                                    }
                                } else {
                                    return 0.107579945281;
                                }
                            } else {
                                if (fs[69] <= 9997.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.268074745955;
                                    } else {
                                        return 0.331696747798;
                                    }
                                } else {
                                    if (fs[73] <= 100.0) {
                                        return 0.349906409943;
                                    } else {
                                        return 0.309306210782;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    return 0.105327036796;
                                } else {
                                    return 0.193341243976;
                                }
                            } else {
                                if (fs[69] <= 9997.5) {
                                    return 0.272315989851;
                                } else {
                                    return 0.213380902835;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[69] <= 9985.5) {
                if (fs[0] <= 3.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[50] <= -482.0) {
                                        return -0.0220252593227;
                                    } else {
                                        return 0.0400640690711;
                                    }
                                } else {
                                    if (fs[82] <= 4.5) {
                                        return 0.0384948903538;
                                    } else {
                                        return 0.120369794008;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[73] <= 75.0) {
                                        return -0.0137838574858;
                                    } else {
                                        return 0.0244814637399;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.0070676977858;
                                    } else {
                                        return 0.0319627218502;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[50] <= -2938.0) {
                                        return 0.323169534761;
                                    } else {
                                        return 0.0140761087918;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.0785543931041;
                                    } else {
                                        return -0.00111195840591;
                                    }
                                }
                            } else {
                                if (fs[69] <= 4329.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.108053989713;
                                    } else {
                                        return 0.28007985298;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0917175697659;
                                    } else {
                                        return 0.0381445178272;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[75] <= 0.5) {
                                        return -0.0453274313319;
                                    } else {
                                        return -0.00882211114178;
                                    }
                                } else {
                                    if (fs[67] <= -1.5) {
                                        return 0.00878486578543;
                                    } else {
                                        return -0.0158305536758;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[4] <= 5.0) {
                                        return 0.219379097061;
                                    } else {
                                        return 0.0181648596244;
                                    }
                                } else {
                                    return 0.254275762575;
                                }
                            }
                        } else {
                            if (fs[50] <= -1368.5) {
                                if (fs[82] <= 6.5) {
                                    if (fs[37] <= 0.5) {
                                        return -0.00845589007841;
                                    } else {
                                        return 0.0159162972294;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0123104953752;
                                    } else {
                                        return 0.0662746011815;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9181.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0133384753642;
                                    } else {
                                        return -0.00177708087683;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return -0.0323067188034;
                                    } else {
                                        return -0.0796752609483;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[59] <= -2.5) {
                            if (fs[4] <= 17.5) {
                                return 0.372055307911;
                            } else {
                                if (fs[0] <= 5.5) {
                                    return 0.132627512362;
                                } else {
                                    return -0.0502119255409;
                                }
                            }
                        } else {
                            if (fs[0] <= 20.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[93] <= 0.5) {
                                        return -0.00183811025722;
                                    } else {
                                        return 0.00628135150396;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.00406229116828;
                                    } else {
                                        return -0.011367082498;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[50] <= -331.5) {
                                        return -0.00360221616984;
                                    } else {
                                        return -0.00482071058672;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.165319443535;
                                    } else {
                                        return -0.0400226557886;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 6.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[47] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return -0.00491407050096;
                                    } else {
                                        return -0.0036038138568;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return -0.0146113706994;
                                    } else {
                                        return -0.00658687416681;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.00861314248242;
                                    } else {
                                        return -0.00516409533209;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0036666714141;
                                    } else {
                                        return -0.00516206337271;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[0] <= 6.5) {
                                        return -0.0157451266154;
                                    } else {
                                        return -0.0101696484209;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.0105921792114;
                                    } else {
                                        return -0.0323705449042;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.00519766994644;
                                    } else {
                                        return -0.0196603035604;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.0102896597178;
                                    } else {
                                        return -0.00734425435744;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 2.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[50] <= -1408.0) {
                            if (fs[18] <= -0.5) {
                                return -0.226168614436;
                            } else {
                                if (fs[50] <= -1443.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.00849613749572;
                                    } else {
                                        return 0.0559042086602;
                                    }
                                } else {
                                    return 0.372476635494;
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.172508626738;
                                    } else {
                                        return -0.0124842386467;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.0514783657054;
                                    } else {
                                        return 0.121472441394;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0173809022031;
                                    } else {
                                        return 0.0933321727737;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0199007487977;
                                    } else {
                                        return -0.0455901799674;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -2408.0) {
                            return 0.213230660555;
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.00900986274048;
                                    } else {
                                        return -0.0253939670907;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.0269361699606;
                                    } else {
                                        return -0.00684027091629;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[4] <= 2.5) {
                                        return -0.0569191847615;
                                    } else {
                                        return 0.0739242806288;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.00320947985099;
                                    } else {
                                        return 0.0382520383256;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[82] <= 5.5) {
                                if (fs[82] <= 1.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.101196061849;
                                    } else {
                                        return 0.278054678011;
                                    }
                                } else {
                                    return -0.236733617916;
                                }
                            } else {
                                if (fs[50] <= -1463.0) {
                                    if (fs[82] <= 7.5) {
                                        return 0.42873340687;
                                    } else {
                                        return 0.355665221533;
                                    }
                                } else {
                                    return 0.474568055564;
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[69] <= 9987.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0866397480656;
                                    } else {
                                        return 0.415109306984;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0468557348955;
                                    } else {
                                        return -0.00502231277495;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    return -0.0519540892196;
                                } else {
                                    return 0.28865315067;
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[50] <= -1418.0) {
                                if (fs[68] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.222489214663;
                                    } else {
                                        return -0.0174264308396;
                                    }
                                } else {
                                    if (fs[65] <= 1.5) {
                                        return 0.10071228046;
                                    } else {
                                        return -0.161690802615;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0325936328233;
                                    } else {
                                        return -0.0479901994824;
                                    }
                                } else {
                                    if (fs[4] <= 35.5) {
                                        return 0.00804034948591;
                                    } else {
                                        return 0.291726362759;
                                    }
                                }
                            }
                        } else {
                            return 0.359441549095;
                        }
                    }
                }
            }
        }
    }
}
