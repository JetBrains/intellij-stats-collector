/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree84 {
    public double calcTree(double... fs) {
        if (fs[61] <= -997.5) {
            if (fs[44] <= 0.5) {
                if (fs[14] <= 0.5) {
                    if (fs[50] <= -1488.0) {
                        if (fs[4] <= 12.5) {
                            if (fs[69] <= 9999.5) {
                                if (fs[82] <= 1.0) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0983582599126;
                                    } else {
                                        return 0.324386924406;
                                    }
                                } else {
                                    return -0.0435888623264;
                                }
                            } else {
                                return -0.0908568309284;
                            }
                        } else {
                            return -0.0423521949615;
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.113915722474;
                                    } else {
                                        return -0.041655074866;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0697681324364;
                                    } else {
                                        return -0.22034105027;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0149870574269;
                                    } else {
                                        return -0.158644443316;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0407108714117;
                                    } else {
                                        return 0.0235343628017;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 21.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[67] <= -4.0) {
                                        return -0.060632556924;
                                    } else {
                                        return 0.0429428349054;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.119478996841;
                                    } else {
                                        return 0.0256632427649;
                                    }
                                }
                            } else {
                                return -0.151437108558;
                            }
                        }
                    }
                } else {
                    return -0.228183401244;
                }
            } else {
                if (fs[61] <= -998.5) {
                    if (fs[0] <= 8.5) {
                        return -0.0235396530143;
                    } else {
                        return -0.030073916059;
                    }
                } else {
                    if (fs[69] <= 4998.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[33] <= 0.5) {
                                    return -0.0399378369968;
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0120218216941;
                                    } else {
                                        return 0.0126949399733;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00191736955503;
                                    } else {
                                        return -0.0180769103972;
                                    }
                                } else {
                                    if (fs[46] <= -1.5) {
                                        return -0.0100774187585;
                                    } else {
                                        return -0.00237906244936;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    return -0.00538229129433;
                                } else {
                                    if (fs[50] <= -966.0) {
                                        return -0.00624807284086;
                                    } else {
                                        return -0.0143243263247;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return -0.0227089686742;
                                    } else {
                                        return -0.0157935549857;
                                    }
                                } else {
                                    return -0.00936231309692;
                                }
                            }
                        }
                    } else {
                        return -0.0492120926952;
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[82] <= -0.5) {
                    if (fs[67] <= -4.0) {
                        return -0.334382230275;
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[50] <= -1463.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[50] <= -1718.0) {
                                        return -0.153111698983;
                                    } else {
                                        return -0.0351406386028;
                                    }
                                } else {
                                    return -0.22032573572;
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    return 0.197644799691;
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.0172513519309;
                                    } else {
                                        return 0.166957077211;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[65] <= 1.5) {
                                        return -0.117285671048;
                                    } else {
                                        return -0.24519113438;
                                    }
                                } else {
                                    return 0.0672160163209;
                                }
                            } else {
                                return 0.122452317651;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[73] <= 350.0) {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.00113060191356;
                                    } else {
                                        return 0.0290362613367;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.012776702929;
                                    } else {
                                        return 0.018405567908;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[82] <= 4.5) {
                                        return 0.0157245009465;
                                    } else {
                                        return 0.0389070471145;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return -0.00394839593309;
                                    } else {
                                        return -0.0654728228474;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9999.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.126953360891;
                                    } else {
                                        return 0.216232205429;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0313085738125;
                                    } else {
                                        return 0.143052890876;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.152493820565;
                                    } else {
                                        return 0.0777268128255;
                                    }
                                } else {
                                    return 0.0956021399936;
                                }
                            }
                        }
                    } else {
                        if (fs[82] <= 4.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[50] <= -1493.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.0834454562851;
                                    } else {
                                        return 0.0375560477157;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0032637487448;
                                    } else {
                                        return -0.0236511418785;
                                    }
                                }
                            } else {
                                if (fs[77] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.049979044645;
                                    } else {
                                        return 0.00600935499091;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return -0.277536416608;
                                    } else {
                                        return -0.00622692665391;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1488.0) {
                                if (fs[37] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0479592851973;
                                    } else {
                                        return -0.172865355964;
                                    }
                                } else {
                                    if (fs[4] <= 28.5) {
                                        return 0.061460905083;
                                    } else {
                                        return 0.264631663371;
                                    }
                                }
                            } else {
                                if (fs[4] <= 24.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.00807582380768;
                                    } else {
                                        return 0.297799974061;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.254997536058;
                                    } else {
                                        return -0.14541495014;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[34] <= 0.5) {
                    if (fs[14] <= 0.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.00387618881391;
                                    } else {
                                        return -0.00119434901477;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return 0.0117882618752;
                                    } else {
                                        return 0.151133678929;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[65] <= 1.5) {
                                        return 0.001666788835;
                                    } else {
                                        return 0.0268382929656;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.000824767460537;
                                    } else {
                                        return 0.0218081370379;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 9989.5) {
                                if (fs[0] <= 5.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.164672215136;
                                    } else {
                                        return -0.0568411667293;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.00785989446281;
                                    } else {
                                        return -0.0191560354799;
                                    }
                                }
                            } else {
                                if (fs[52] <= 995.0) {
                                    return 0.320399970574;
                                } else {
                                    return 0.0977184876046;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[39] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0194049244478;
                                    } else {
                                        return 0.196018807839;
                                    }
                                } else {
                                    if (fs[69] <= 9998.5) {
                                        return -0.00282955833151;
                                    } else {
                                        return 0.195948321344;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.256098649301;
                                    } else {
                                        return 0.173070175629;
                                    }
                                } else {
                                    return -0.148648656392;
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[0] <= 6.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0169042217085;
                                    } else {
                                        return 0.0389591253998;
                                    }
                                } else {
                                    if (fs[69] <= 9985.0) {
                                        return -0.00185816479512;
                                    } else {
                                        return 0.0518092708579;
                                    }
                                }
                            } else {
                                if (fs[2] <= 7.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0528102887463;
                                    } else {
                                        return -0.00287594579736;
                                    }
                                } else {
                                    if (fs[82] <= 1.5) {
                                        return -0.0172366801967;
                                    } else {
                                        return -0.0338952482604;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 5.5) {
                        return 0.045986265801;
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[50] <= -1138.0) {
                                return -0.0726846396226;
                            } else {
                                return 0.174891625216;
                            }
                        } else {
                            return 0.19970089818;
                        }
                    }
                }
            }
        }
    }
}
