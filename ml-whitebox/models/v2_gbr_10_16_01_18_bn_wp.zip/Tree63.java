/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree63 {
    public double calcTree(double... fs) {
        if (fs[97] <= 1.5) {
            if (fs[75] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 9.5) {
                        if (fs[50] <= -1138.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0552545770708;
                                    } else {
                                        return -0.226036815379;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.00114241449007;
                                    } else {
                                        return -0.0378346993427;
                                    }
                                }
                            } else {
                                if (fs[30] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.0506793656749;
                                    } else {
                                        return 0.037645118364;
                                    }
                                } else {
                                    return -0.167711673894;
                                }
                            }
                        } else {
                            if (fs[14] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[39] <= 0.5) {
                                        return 0.0495174466834;
                                    } else {
                                        return 0.108543476787;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0353455644246;
                                    } else {
                                        return 0.0850019502875;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return 0.0889653438944;
                                } else {
                                    return 0.128435884322;
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1443.5) {
                            if (fs[4] <= 40.5) {
                                if (fs[4] <= 31.5) {
                                    if (fs[4] <= 25.5) {
                                        return 0.0329667053686;
                                    } else {
                                        return -0.185776133354;
                                    }
                                } else {
                                    return 0.153019838856;
                                }
                            } else {
                                return -0.134377828737;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[57] <= 0.5) {
                                        return 0.183063905837;
                                    } else {
                                        return 0.180442114947;
                                    }
                                } else {
                                    return -0.01785918337;
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0888551415433;
                                    } else {
                                        return 0.0253859260391;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0468103305318;
                                    } else {
                                        return 0.0498374090949;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[34] <= 0.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0233322834425;
                                    } else {
                                        return -0.0172640347846;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0537422089588;
                                    } else {
                                        return -0.0128929801299;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.0123691481556;
                                    } else {
                                        return 0.107649605221;
                                    }
                                } else {
                                    return 0.263049090071;
                                }
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0550124857496;
                                    } else {
                                        return 0.143534305598;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.0305136979702;
                                    } else {
                                        return -0.00456180972064;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0399057532352;
                                    } else {
                                        return 0.162101292821;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0395954229998;
                                    } else {
                                        return 0.0106761598873;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[50] <= -1138.0) {
                                return 0.113930547245;
                            } else {
                                return 0.160850904186;
                            }
                        } else {
                            return 0.173414257694;
                        }
                    }
                }
            } else {
                if (fs[54] <= 0.5) {
                    if (fs[69] <= 9996.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[65] <= 1.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0283576454319;
                                    } else {
                                        return -0.0126353953541;
                                    }
                                } else {
                                    if (fs[69] <= 8623.0) {
                                        return -0.167804255899;
                                    } else {
                                        return -0.000398892953604;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.0620678692785;
                                    } else {
                                        return -0.143640573719;
                                    }
                                } else {
                                    if (fs[2] <= 10.5) {
                                        return 0.0214509877535;
                                    } else {
                                        return 0.147512472742;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -4913.0) {
                                return 0.236623704138;
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[28] <= 0.5) {
                                        return -0.00257860402382;
                                    } else {
                                        return 0.0128561237763;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.00150587552874;
                                    } else {
                                        return 0.00375453236718;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[4] <= 35.5) {
                                        return 0.0508283434743;
                                    } else {
                                        return -0.210990748736;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0343522083941;
                                    } else {
                                        return -0.22786941562;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[50] <= -1588.5) {
                                        return 0.140723591591;
                                    } else {
                                        return 0.0301472685156;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.0397332245963;
                                    } else {
                                        return 0.0351152576211;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[0] <= 39.5) {
                                        return 0.0230956006069;
                                    } else {
                                        return -0.0724725141797;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0569870917836;
                                    } else {
                                        return 0.2230871648;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1108.0) {
                                    if (fs[2] <= 6.5) {
                                        return 0.0152824485426;
                                    } else {
                                        return 0.141757414114;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return -0.0050469453165;
                                    } else {
                                        return 0.104759493184;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[69] <= 9989.5) {
                            if (fs[59] <= -2.5) {
                                return 0.0904131934931;
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.137415565253;
                                    } else {
                                        return -0.0205918358146;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.133318099393;
                                    } else {
                                        return -0.0404550880927;
                                    }
                                }
                            }
                        } else {
                            return -0.179760375128;
                        }
                    } else {
                        if (fs[50] <= 3.5) {
                            if (fs[6] <= 0.5) {
                                return -0.175368477691;
                            } else {
                                if (fs[67] <= -4.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.191373898586;
                                    } else {
                                        return -0.0551100222453;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return 0.173294136415;
                                    } else {
                                        return 0.0911920276671;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                return -0.0316133361877;
                            } else {
                                if (fs[0] <= 4.5) {
                                    return -0.0112122527933;
                                } else {
                                    if (fs[4] <= 7.0) {
                                        return -0.00283650747949;
                                    } else {
                                        return -0.00470370298719;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[44] <= 0.5) {
                if (fs[33] <= 0.5) {
                    if (fs[0] <= 31.5) {
                        if (fs[61] <= -996.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[61] <= -998.5) {
                                        return 0.00676221723453;
                                    } else {
                                        return -0.141658225969;
                                    }
                                } else {
                                    if (fs[46] <= -1.5) {
                                        return 0.125124624773;
                                    } else {
                                        return 0.112804633666;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[50] <= -1143.5) {
                                        return 0.0233009520582;
                                    } else {
                                        return 0.0504187667438;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.061107375434;
                                    } else {
                                        return 0.142264630686;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= -0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 24.5) {
                                        return 0.0150863196462;
                                    } else {
                                        return 0.145007119504;
                                    }
                                } else {
                                    if (fs[59] <= -1.5) {
                                        return 0.162881121037;
                                    } else {
                                        return -0.089757813095;
                                    }
                                }
                            } else {
                                if (fs[50] <= -988.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0332428805635;
                                    } else {
                                        return -0.0246560398759;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0086390923155;
                                    } else {
                                        return -0.06469038985;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1048.0) {
                            if (fs[50] <= -1138.0) {
                                return 0.16457655992;
                            } else {
                                if (fs[49] <= 0.5) {
                                    return 0.477315017682;
                                } else {
                                    return 0.377324143118;
                                }
                            }
                        } else {
                            return -0.0431525561058;
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[4] <= 18.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.270549558889;
                                    } else {
                                        return -0.114284818909;
                                    }
                                } else {
                                    return 0.00828684233672;
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.12010769047;
                                    } else {
                                        return -0.0655497112124;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0556621367018;
                                    } else {
                                        return 0.130265676742;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= -2.5) {
                                return -0.199778862053;
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[4] <= 21.5) {
                                        return 0.0375639688565;
                                    } else {
                                        return -0.0622898736686;
                                    }
                                } else {
                                    return 0.244194551013;
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[0] <= 3.5) {
                                return -0.0411549185709;
                            } else {
                                if (fs[4] <= 75.0) {
                                    if (fs[0] <= 5.5) {
                                        return -0.0136539129699;
                                    } else {
                                        return -0.0226962394136;
                                    }
                                } else {
                                    return -0.0371508128211;
                                }
                            }
                        } else {
                            if (fs[4] <= 24.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[46] <= -0.5) {
                                        return 0.00580549280139;
                                    } else {
                                        return -0.029816698015;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.031858179397;
                                    } else {
                                        return -0.00755640672111;
                                    }
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0126225276642;
                                    } else {
                                        return 0.00857917590938;
                                    }
                                } else {
                                    if (fs[0] <= 12.5) {
                                        return 0.201034948016;
                                    } else {
                                        return -0.0218209232389;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[46] <= -2.5) {
                    if (fs[61] <= -995.5) {
                        if (fs[50] <= -456.5) {
                            return 0.148364196289;
                        } else {
                            return -0.0378419464045;
                        }
                    } else {
                        return -0.0366298599081;
                    }
                } else {
                    if (fs[61] <= -998.5) {
                        if (fs[4] <= 5.5) {
                            return -0.044370611613;
                        } else {
                            return -0.0205115644237;
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 25.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0775438954614;
                                    } else {
                                        return -0.00748232842297;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0248466512648;
                                    } else {
                                        return 0.0362400656363;
                                    }
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0242174892359;
                                    } else {
                                        return -0.0119415182681;
                                    }
                                } else {
                                    if (fs[4] <= 33.5) {
                                        return 0.0540481483297;
                                    } else {
                                        return -0.0146150500024;
                                    }
                                }
                            }
                        } else {
                            if (fs[46] <= -1.5) {
                                if (fs[61] <= -997.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.012421670535;
                                    } else {
                                        return -0.0246753320163;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0049602240777;
                                    } else {
                                        return -0.00778516302517;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1027.0) {
                                    return -0.0262376718511;
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0105305469391;
                                    } else {
                                        return -0.00206393900031;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
