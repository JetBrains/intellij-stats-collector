/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree38 {
    public double calcTree(double... fs) {
        if (fs[39] <= 0.5) {
            if (fs[11] <= 0.5) {
                if (fs[15] <= 0.5) {
                    if (fs[75] <= 0.5) {
                        if (fs[4] <= 11.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.173860455182;
                                    } else {
                                        return 0.129949579471;
                                    }
                                } else {
                                    if (fs[68] <= 0.5) {
                                        return 0.159425589177;
                                    } else {
                                        return -0.0242341885005;
                                    }
                                }
                            } else {
                                return 0.382064769332;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[0] <= 6.5) {
                                        return -0.0651113328314;
                                    } else {
                                        return -0.0150539658241;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.0362319546535;
                                    } else {
                                        return -0.0248053634919;
                                    }
                                }
                            } else {
                                if (fs[4] <= 26.5) {
                                    return -0.0638579073513;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.142730225629;
                                    } else {
                                        return -0.0292923800035;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[46] <= -0.5) {
                                if (fs[46] <= -1.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.0788306474611;
                                    } else {
                                        return 0.244214927366;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.117233544715;
                                    } else {
                                        return 0.172349758489;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.155335954507;
                                    } else {
                                        return 0.031649628409;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.108732986462;
                                    } else {
                                        return 0.0510167407602;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0165072420456;
                                    } else {
                                        return 0.1149311557;
                                    }
                                } else {
                                    if (fs[89] <= 0.5) {
                                        return -0.0169828323499;
                                    } else {
                                        return -0.0288028883755;
                                    }
                                }
                            } else {
                                if (fs[54] <= 0.5) {
                                    if (fs[0] <= 10.5) {
                                        return -0.00171182140604;
                                    } else {
                                        return -0.00858058744609;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0366040406551;
                                    } else {
                                        return 0.184292599817;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -983.0) {
                        if (fs[0] <= 0.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.105808037585;
                                    } else {
                                        return 0.173795001949;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.158804237458;
                                    } else {
                                        return -0.0607810655562;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.17774249146;
                                    } else {
                                        return 0.146045210254;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.141193115705;
                                    } else {
                                        return 0.13634543341;
                                    }
                                }
                            }
                        } else {
                            return 0.053438302723;
                        }
                    } else {
                        if (fs[0] <= 24.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[0] <= 0.5) {
                                    return -0.342052529684;
                                } else {
                                    return -0.077353145204;
                                }
                            } else {
                                return 0.0414498974605;
                            }
                        } else {
                            if (fs[0] <= 25.5) {
                                return 0.600135373278;
                            } else {
                                return -0.0552703237964;
                            }
                        }
                    }
                }
            } else {
                if (fs[75] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[73] <= 100.0) {
                            if (fs[50] <= -1138.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.181611567809;
                                    } else {
                                        return 0.0417965217219;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.140810821558;
                                    } else {
                                        return 0.121966550563;
                                    }
                                }
                            } else {
                                if (fs[50] <= -983.0) {
                                    if (fs[33] <= 0.5) {
                                        return 0.131279049643;
                                    } else {
                                        return 0.153423904536;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return -0.0498720424432;
                                    } else {
                                        return 0.142440339881;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= -1138.0) {
                                if (fs[50] <= -1328.0) {
                                    if (fs[50] <= -1568.0) {
                                        return -0.000324297208359;
                                    } else {
                                        return -0.159219673837;
                                    }
                                } else {
                                    return 0.326796589162;
                                }
                            } else {
                                return -0.218166903428;
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[67] <= -1.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[30] <= 0.5) {
                                        return -0.081064570659;
                                    } else {
                                        return -0.0468934772122;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.0255878027932;
                                    } else {
                                        return -0.0470710267796;
                                    }
                                }
                            } else {
                                return 0.0295792296647;
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                if (fs[40] <= 0.5) {
                                    return 0.299040816415;
                                } else {
                                    return -0.0689158331446;
                                }
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return -0.00242091394248;
                                    } else {
                                        return 0.0181857905218;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.214612090928;
                                    } else {
                                        return 0.343892046843;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[69] <= 9868.5) {
                        if (fs[54] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0625200111142;
                                    } else {
                                        return -0.0278858620016;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.106883399095;
                                    } else {
                                        return -0.00623183498011;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[73] <= 25.0) {
                                        return -0.00691138804074;
                                    } else {
                                        return 0.00404055186564;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return -0.00776722853471;
                                    } else {
                                        return -0.00922124803666;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0526372117202;
                                    } else {
                                        return -0.0339595549389;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return 0.178574760788;
                                    } else {
                                        return 0.319791409861;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    return -0.0477784952412;
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.012709597304;
                                    } else {
                                        return -0.0140168856866;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0271905214295;
                                    } else {
                                        return 0.0536458794347;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return 0.0999299703218;
                                    } else {
                                        return 0.183696028127;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0106983368;
                                    } else {
                                        return -0.00985851153322;
                                    }
                                } else {
                                    if (fs[69] <= 9971.5) {
                                        return 0.022593243813;
                                    } else {
                                        return 0.0673786186191;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[50] <= -486.5) {
                                        return 0.152110015644;
                                    } else {
                                        return 0.188725935604;
                                    }
                                } else {
                                    if (fs[18] <= -0.5) {
                                        return -0.270780334245;
                                    } else {
                                        return 0.109026963767;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1418.0) {
                                    if (fs[82] <= 6.5) {
                                        return 0.049115133649;
                                    } else {
                                        return 0.243445040458;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0554157515485;
                                    } else {
                                        return -0.00653231282933;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[97] <= 0.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[49] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.144089138989;
                                    } else {
                                        return 0.2011732948;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.192176535489;
                                    } else {
                                        return 0.275780216909;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.0786362193088;
                                } else {
                                    return -0.107834831173;
                                }
                            }
                        } else {
                            if (fs[4] <= 1.5) {
                                return 0.306781975705;
                            } else {
                                if (fs[50] <= -547.0) {
                                    if (fs[95] <= 0.5) {
                                        return -0.109399647258;
                                    } else {
                                        return 0.120888989725;
                                    }
                                } else {
                                    return -0.162143927577;
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[69] <= 9943.0) {
                                if (fs[8] <= 0.5) {
                                    if (fs[50] <= -1138.0) {
                                        return -0.191476344276;
                                    } else {
                                        return -0.0655406184016;
                                    }
                                } else {
                                    return -0.331950764786;
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[50] <= -566.5) {
                                        return 0.179127897253;
                                    } else {
                                        return -0.04506386455;
                                    }
                                } else {
                                    return 0.465768464119;
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[4] <= 12.5) {
                                    return 0.165065278238;
                                } else {
                                    return 0.376964760314;
                                }
                            } else {
                                if (fs[59] <= -1.5) {
                                    return 0.195604750437;
                                } else {
                                    if (fs[50] <= -1108.0) {
                                        return 0.22653136192;
                                    } else {
                                        return -0.214952254624;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[61] <= -995.5) {
                            if (fs[55] <= 0.5) {
                                if (fs[50] <= -992.0) {
                                    if (fs[4] <= 1.5) {
                                        return 0.0926659563718;
                                    } else {
                                        return 0.158405688166;
                                    }
                                } else {
                                    return 0.103105664578;
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    return -0.194409637634;
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0996727300424;
                                    } else {
                                        return 0.179005660587;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[50] <= -1303.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.225849550338;
                                    } else {
                                        return 0.248395501571;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.118430915863;
                                    } else {
                                        return -0.0377680083886;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1493.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.205619691835;
                                    } else {
                                        return 0.273582174059;
                                    }
                                } else {
                                    if (fs[50] <= -1142.5) {
                                        return 0.0689327345441;
                                    } else {
                                        return 0.124179120099;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1132.5) {
                            if (fs[4] <= 22.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.222773588806;
                                    } else {
                                        return 0.140351412197;
                                    }
                                } else {
                                    if (fs[50] <= -1138.0) {
                                        return 0.102801190006;
                                    } else {
                                        return -0.146974887971;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    if (fs[4] <= 23.5) {
                                        return 0.0265524702261;
                                    } else {
                                        return -0.156619004619;
                                    }
                                } else {
                                    if (fs[4] <= 24.5) {
                                        return -0.159320540611;
                                    } else {
                                        return 0.24529641774;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[97] <= 1.5) {
                                        return 0.258006867277;
                                    } else {
                                        return 0.152676820488;
                                    }
                                } else {
                                    if (fs[50] <= -1098.0) {
                                        return 0.211553228697;
                                    } else {
                                        return 0.149014798374;
                                    }
                                }
                            } else {
                                return -0.0338067707736;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[4] <= 5.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[50] <= 7.5) {
                                if (fs[4] <= 1.5) {
                                    return 0.25433115193;
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0691387011294;
                                    } else {
                                        return 0.216573183434;
                                    }
                                }
                            } else {
                                if (fs[97] <= 1.5) {
                                    return -0.0482493916199;
                                } else {
                                    return -0.0325530280323;
                                }
                            }
                        } else {
                            if (fs[49] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    return 0.0558180574275;
                                } else {
                                    return 0.239837138377;
                                }
                            } else {
                                return 0.351030494403;
                            }
                        }
                    } else {
                        if (fs[6] <= 0.5) {
                            if (fs[73] <= 250.0) {
                                return -0.0323642966214;
                            } else {
                                return 0.41928500215;
                            }
                        } else {
                            if (fs[14] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return 0.00980654515109;
                                    } else {
                                        return 0.0481178248445;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.00466023171168;
                                    } else {
                                        return -0.0232639205355;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9996.5) {
                                    if (fs[97] <= 1.5) {
                                        return 0.174033893583;
                                    } else {
                                        return 0.278230690006;
                                    }
                                } else {
                                    return -0.113787471776;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 3.5) {
                        if (fs[65] <= 1.5) {
                            if (fs[59] <= -1.5) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.0861742635046;
                                    } else {
                                        return 0.370070407668;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return 0.0329604330933;
                                    } else {
                                        return -0.0337961290521;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1078.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0893554576223;
                                    } else {
                                        return -0.00163411241702;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.00489175539332;
                                    } else {
                                        return -0.00984658095931;
                                    }
                                }
                            }
                        } else {
                            if (fs[50] <= 3.5) {
                                if (fs[49] <= 0.5) {
                                    return 0.0353848130931;
                                } else {
                                    return 0.363428155428;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return -0.0176641856588;
                                } else {
                                    if (fs[0] <= 14.5) {
                                        return -0.0163196394469;
                                    } else {
                                        return -0.0128120324007;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= 0.5) {
                            if (fs[61] <= -995.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.0188455942501;
                                    } else {
                                        return 0.282847104281;
                                    }
                                } else {
                                    return 0.00177956012575;
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.085880689338;
                                    } else {
                                        return -0.021449402325;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return -0.0452822019143;
                                    } else {
                                        return -0.00217855312625;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 37.5) {
                                if (fs[50] <= -1078.0) {
                                    if (fs[0] <= 7.5) {
                                        return 0.0804405236217;
                                    } else {
                                        return 0.446739780325;
                                    }
                                } else {
                                    if (fs[73] <= 250.0) {
                                        return -0.0198748963673;
                                    } else {
                                        return 0.00199535277834;
                                    }
                                }
                            } else {
                                return 0.427301951429;
                            }
                        }
                    }
                }
            }
        }
    }
}
