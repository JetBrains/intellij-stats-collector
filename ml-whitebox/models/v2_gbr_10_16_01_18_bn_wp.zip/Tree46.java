/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree46 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[4] <= 4.5) {
                    if (fs[99] <= 0.5) {
                        if (fs[25] <= 0.5) {
                            if (fs[68] <= 0.5) {
                                if (fs[95] <= 1.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.12128306867;
                                    } else {
                                        return 0.252224561986;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.176641407044;
                                    } else {
                                        return 0.305137768605;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0610796656467;
                                    } else {
                                        return -0.0300834332836;
                                    }
                                } else {
                                    if (fs[50] <= -1054.0) {
                                        return 0.108193776074;
                                    } else {
                                        return 0.0345054210567;
                                    }
                                }
                            }
                        } else {
                            if (fs[93] <= 0.5) {
                                if (fs[49] <= 0.5) {
                                    if (fs[69] <= 4710.0) {
                                        return -0.112508781202;
                                    } else {
                                        return 0.255270416472;
                                    }
                                } else {
                                    if (fs[73] <= 25.0) {
                                        return -0.0977662907412;
                                    } else {
                                        return -0.238051302429;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.279075298148;
                                    } else {
                                        return 0.190120967636;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0372044505929;
                                    } else {
                                        return 0.176407289425;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[82] <= 6.5) {
                                if (fs[69] <= 9740.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0925100795791;
                                    } else {
                                        return 0.000524326942503;
                                    }
                                } else {
                                    return 0.195927038671;
                                }
                            } else {
                                if (fs[50] <= -1478.5) {
                                    if (fs[69] <= 4894.0) {
                                        return 0.162417472293;
                                    } else {
                                        return 0.244223035485;
                                    }
                                } else {
                                    return 0.350325674694;
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[73] <= 25.0) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0484603805491;
                                    } else {
                                        return 0.0428004564757;
                                    }
                                } else {
                                    if (fs[82] <= 6.5) {
                                        return -0.0663587874789;
                                    } else {
                                        return 0.194142675002;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.299950097798;
                                    } else {
                                        return -0.00155707584084;
                                    }
                                } else {
                                    return -0.144075921884;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[50] <= -1493.5) {
                        if (fs[4] <= 18.5) {
                            if (fs[2] <= 0.5) {
                                return -0.141461215301;
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.150069720436;
                                    } else {
                                        return 0.200237353335;
                                    }
                                } else {
                                    return 0.00166204212827;
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[50] <= -2458.0) {
                                    if (fs[69] <= 9989.0) {
                                        return 0.325144546955;
                                    } else {
                                        return 0.232467000216;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.0945257938798;
                                    } else {
                                        return -0.199907832512;
                                    }
                                }
                            } else {
                                if (fs[67] <= -1.5) {
                                    if (fs[50] <= -1598.0) {
                                        return 0.0461679351241;
                                    } else {
                                        return 0.281195536205;
                                    }
                                } else {
                                    if (fs[4] <= 32.5) {
                                        return -0.141686653705;
                                    } else {
                                        return -0.202871809564;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1488.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0925827174582;
                                    } else {
                                        return -0.0551550854596;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.123538427167;
                                    } else {
                                        return 0.0165846137031;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    return 0.0181170819305;
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.306532814125;
                                    } else {
                                        return 0.147478518081;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[82] <= 3.0) {
                                        return 0.0773983941625;
                                    } else {
                                        return 0.204760894322;
                                    }
                                } else {
                                    if (fs[50] <= -977.0) {
                                        return 0.0614364779433;
                                    } else {
                                        return -0.0664722171856;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1138.0) {
                                    if (fs[91] <= 0.5) {
                                        return -0.013694854712;
                                    } else {
                                        return -0.118770055318;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.122004839044;
                                    } else {
                                        return 0.0119960677768;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[40] <= 0.5) {
                    if (fs[4] <= 9.5) {
                        if (fs[82] <= -0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.172286940106;
                                    } else {
                                        return 0.125374877219;
                                    }
                                } else {
                                    if (fs[50] <= -1128.0) {
                                        return 0.0129313982907;
                                    } else {
                                        return 0.108023088689;
                                    }
                                }
                            } else {
                                return 0.282455756572;
                            }
                        } else {
                            if (fs[29] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.0966356996109;
                                    } else {
                                        return -0.403599579759;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0467457311594;
                                    } else {
                                        return 0.0766247608336;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0566227250752;
                                    } else {
                                        return -0.182978853466;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return -0.224227332448;
                                    } else {
                                        return -0.0274643391909;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[50] <= -987.0) {
                                if (fs[50] <= -1988.0) {
                                    if (fs[4] <= 46.5) {
                                        return 0.227401478369;
                                    } else {
                                        return -0.204479631379;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.0822406427266;
                                    } else {
                                        return -0.0455995060056;
                                    }
                                }
                            } else {
                                if (fs[46] <= -0.5) {
                                    if (fs[46] <= -2.5) {
                                        return 0.227242599644;
                                    } else {
                                        return 0.118494164919;
                                    }
                                } else {
                                    if (fs[54] <= 0.5) {
                                        return 0.00226763895115;
                                    } else {
                                        return 0.398539638899;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.270001437575;
                                    } else {
                                        return 0.120850425822;
                                    }
                                } else {
                                    if (fs[73] <= 75.0) {
                                        return -0.0506556936988;
                                    } else {
                                        return 0.130469431715;
                                    }
                                }
                            } else {
                                if (fs[82] <= 4.5) {
                                    if (fs[56] <= 0.5) {
                                        return -0.0509894479064;
                                    } else {
                                        return 0.117703140924;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.158207335879;
                                    } else {
                                        return 0.11274969274;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[82] <= 7.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[50] <= -1938.0) {
                                if (fs[42] <= 0.5) {
                                    return 0.00105895573825;
                                } else {
                                    return 0.332916758054;
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0545278343326;
                                    } else {
                                        return 0.0334265686302;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.00371854997458;
                                    } else {
                                        return -0.325896685033;
                                    }
                                }
                            }
                        } else {
                            return 0.221505001326;
                        }
                    } else {
                        if (fs[68] <= 0.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[2] <= 4.5) {
                                    return 0.23230716327;
                                } else {
                                    return -0.084456175067;
                                }
                            } else {
                                if (fs[69] <= 9848.0) {
                                    return 0.190520682778;
                                } else {
                                    return 0.165946149216;
                                }
                            }
                        } else {
                            if (fs[50] <= -1478.0) {
                                if (fs[49] <= 0.5) {
                                    return -0.0633674793823;
                                } else {
                                    return 0.227750655149;
                                }
                            } else {
                                return -0.122085103644;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[73] <= 25.0) {
                if (fs[69] <= 9995.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.0363985900783;
                                    } else {
                                        return 0.0326961178232;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0413011781308;
                                    } else {
                                        return 0.204678940985;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[46] <= -1.5) {
                                        return 0.138203087375;
                                    } else {
                                        return -0.000365754585585;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return 0.0427928535864;
                                    } else {
                                        return -0.024394754037;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[49] <= 0.5) {
                                        return -0.0325654932305;
                                    } else {
                                        return -0.0669669717817;
                                    }
                                } else {
                                    if (fs[69] <= 9883.0) {
                                        return -0.0193048969171;
                                    } else {
                                        return 0.0505134527078;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.189606792977;
                                    } else {
                                        return 0.540634655409;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.00397549148442;
                                    } else {
                                        return -0.0758329190331;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[2] <= 7.5) {
                                        return -0.0112974429078;
                                    } else {
                                        return -0.000816695876267;
                                    }
                                } else {
                                    if (fs[69] <= 9959.5) {
                                        return -0.00594800668358;
                                    } else {
                                        return 0.00580105509435;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9339.0) {
                                    if (fs[4] <= 10.5) {
                                        return 0.162147722404;
                                    } else {
                                        return 0.0294594979877;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0037006109232;
                                    } else {
                                        return -0.120062567934;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[7] <= 0.5) {
                                    if (fs[50] <= -1588.0) {
                                        return 0.0357453870829;
                                    } else {
                                        return -0.000232327838064;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.00622508418656;
                                    } else {
                                        return 0.0978132980616;
                                    }
                                }
                            } else {
                                if (fs[82] <= -0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00818343458266;
                                    } else {
                                        return -0.0108847913917;
                                    }
                                } else {
                                    if (fs[0] <= 20.5) {
                                        return -0.00334613617136;
                                    } else {
                                        return -0.00618316631875;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[61] <= -498.5) {
                        if (fs[4] <= 9.5) {
                            return 0.126892856946;
                        } else {
                            return 0.390460443735;
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[50] <= -1128.5) {
                                if (fs[82] <= 6.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0739606101649;
                                    } else {
                                        return 0.00517689209535;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0743315376298;
                                    } else {
                                        return 0.349825369894;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.00834948313963;
                                    } else {
                                        return 0.0701967167622;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.011544405707;
                                    } else {
                                        return 0.113051505287;
                                    }
                                }
                            }
                        } else {
                            if (fs[65] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.00569789316803;
                                    } else {
                                        return -0.15971313816;
                                    }
                                } else {
                                    if (fs[69] <= 9999.5) {
                                        return 0.0369306748219;
                                    } else {
                                        return 0.122497303285;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return 0.0995936168626;
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.413121275587;
                                    } else {
                                        return 0.235238241294;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[82] <= 6.5) {
                        if (fs[82] <= 5.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[50] <= -1408.0) {
                                        return 0.0760201135216;
                                    } else {
                                        return 0.0269663088514;
                                    }
                                } else {
                                    if (fs[69] <= 9997.5) {
                                        return 0.00414410125054;
                                    } else {
                                        return 0.0606684397998;
                                    }
                                }
                            } else {
                                if (fs[50] <= -2938.0) {
                                    return 0.363421938016;
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.00945209934067;
                                    } else {
                                        return 0.0705399991914;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 6.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0274916332605;
                                    } else {
                                        return -0.0423407644405;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.0409956564956;
                                    } else {
                                        return 0.124226450133;
                                    }
                                }
                            } else {
                                if (fs[68] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return 0.0643461005403;
                                    } else {
                                        return -0.00778284990185;
                                    }
                                } else {
                                    return 0.218451701624;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 6.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[50] <= -1448.5) {
                                        return 0.161527559016;
                                    } else {
                                        return -0.131248373978;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0171711495047;
                                    } else {
                                        return 0.125781498094;
                                    }
                                }
                            } else {
                                if (fs[86] <= 0.5) {
                                    return -0.353229176764;
                                } else {
                                    if (fs[50] <= -1488.0) {
                                        return -0.0521530499101;
                                    } else {
                                        return 0.0389340262812;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 7.5) {
                                if (fs[69] <= 9815.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.00846035061931;
                                    } else {
                                        return 0.125347462443;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.089138172869;
                                    } else {
                                        return 0.434268491208;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.108058499479;
                                    } else {
                                        return -0.171528057202;
                                    }
                                } else {
                                    return 0.101420619283;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[49] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[61] <= -996.5) {
                                    if (fs[55] <= 0.5) {
                                        return 0.146724858951;
                                    } else {
                                        return -0.0247027046993;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0267965596384;
                                    } else {
                                        return -0.0015263774242;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.00976235458382;
                                    } else {
                                        return -0.00656937305817;
                                    }
                                } else {
                                    if (fs[39] <= 0.5) {
                                        return -0.00740574440977;
                                    } else {
                                        return 0.0615423928504;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0129062413725;
                                    } else {
                                        return 0.00388435686304;
                                    }
                                } else {
                                    if (fs[82] <= 7.5) {
                                        return -0.00602823194376;
                                    } else {
                                        return -0.0131574920928;
                                    }
                                }
                            } else {
                                return 0.246882517744;
                            }
                        }
                    } else {
                        if (fs[44] <= 0.5) {
                            if (fs[82] <= 7.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[82] <= 5.5) {
                                        return 0.0045486325943;
                                    } else {
                                        return -0.00958727993505;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.131325465308;
                                    } else {
                                        return 0.0256932160763;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[0] <= 24.5) {
                                        return 0.0172272831207;
                                    } else {
                                        return -0.0464117359796;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.147215583901;
                                    } else {
                                        return 0.410925485678;
                                    }
                                }
                            }
                        } else {
                            if (fs[69] <= 8875.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0205291323758;
                                    } else {
                                        return -0.00971948463588;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0106931676746;
                                    } else {
                                        return -0.00655392897562;
                                    }
                                }
                            } else {
                                if (fs[2] <= 8.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0144138147898;
                                    } else {
                                        return -0.00926188412093;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.120565995743;
                                    } else {
                                        return -0.020978971267;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
