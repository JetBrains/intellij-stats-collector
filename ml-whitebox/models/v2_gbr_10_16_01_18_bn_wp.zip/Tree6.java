/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree6 {
    public double calcTree(double... fs) {
        if (fs[75] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.687077004203;
                                    } else {
                                        return 0.632321684998;
                                    }
                                } else {
                                    return 0.62423877322;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[50] <= -1053.5) {
                                        return 0.637195575476;
                                    } else {
                                        return 0.062796272087;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.511926122256;
                                    } else {
                                        return 0.700031885568;
                                    }
                                }
                            }
                        } else {
                            if (fs[56] <= 0.5) {
                                return 0.505393669258;
                            } else {
                                return 0.494615956192;
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[69] <= 5000.0) {
                                        return 0.695604196483;
                                    } else {
                                        return 0.712318419109;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.617742479385;
                                    } else {
                                        return 0.667717948111;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[56] <= 0.5) {
                                        return 0.643921296986;
                                    } else {
                                        return 0.686733041367;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.661465987352;
                                    } else {
                                        return 0.69487529912;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[50] <= -1138.0) {
                                    return 0.626910529066;
                                } else {
                                    return 0.670184357398;
                                }
                            } else {
                                if (fs[15] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.390813563141;
                                    } else {
                                        return 0.0653320501108;
                                    }
                                } else {
                                    return 0.182262401014;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0141497148858;
                                    } else {
                                        return 0.374919585446;
                                    }
                                } else {
                                    return -0.0926183793945;
                                }
                            } else {
                                return 0.804414476275;
                            }
                        } else {
                            if (fs[30] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.420415934127;
                                    } else {
                                        return 0.160501806122;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return 0.0742772069166;
                                    } else {
                                        return 0.593286871895;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[50] <= -1138.0) {
                                        return -0.0784794574941;
                                    } else {
                                        return -0.0590281592185;
                                    }
                                } else {
                                    if (fs[49] <= 0.5) {
                                        return -0.0606483028507;
                                    } else {
                                        return -0.0745729260829;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 2.5) {
                            if (fs[0] <= 5.5) {
                                return 0.560326309824;
                            } else {
                                if (fs[0] <= 7.5) {
                                    return 0.244101972374;
                                } else {
                                    return 0.375786295125;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[68] <= 0.5) {
                                    return 0.124329261521;
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.113866133214;
                                    } else {
                                        return 0.0056758009689;
                                    }
                                }
                            } else {
                                if (fs[50] <= -988.0) {
                                    if (fs[50] <= -1138.0) {
                                        return -0.014428830099;
                                    } else {
                                        return 0.167656745343;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0527703517747;
                                    } else {
                                        return -0.0607243176592;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 10.5) {
                    if (fs[4] <= 9.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[69] <= 9993.0) {
                                if (fs[50] <= -1128.0) {
                                    if (fs[33] <= 0.5) {
                                        return 0.196273861049;
                                    } else {
                                        return 0.0106247469686;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.646856319717;
                                    } else {
                                        return -0.0121622749796;
                                    }
                                }
                            } else {
                                return 0.621846477283;
                            }
                        } else {
                            if (fs[50] <= -1038.0) {
                                if (fs[68] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.682034554247;
                                    } else {
                                        return 0.00793854779528;
                                    }
                                } else {
                                    return 0.633104249211;
                                }
                            } else {
                                return 0.174240055729;
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[50] <= -1138.0) {
                                    if (fs[56] <= 0.5) {
                                        return 0.755198318125;
                                    } else {
                                        return 0.781775064328;
                                    }
                                } else {
                                    return 0.720908663884;
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.704101271376;
                                    } else {
                                        return 0.700993868104;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.68272682685;
                                    } else {
                                        return 0.703366145106;
                                    }
                                }
                            }
                        } else {
                            if (fs[67] <= -1.5) {
                                return -0.0593633404239;
                            } else {
                                return 0.00695312706889;
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[4] <= 19.5) {
                            if (fs[67] <= -1.5) {
                                return 0.645622449094;
                            } else {
                                return 0.569009907373;
                            }
                        } else {
                            if (fs[68] <= 0.5) {
                                return 0.0834335473416;
                            } else {
                                return -0.0519770627561;
                            }
                        }
                    } else {
                        if (fs[69] <= 4847.0) {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0410221740565;
                                    } else {
                                        return 0.00838496873051;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0391150514362;
                                    } else {
                                        return -0.0331658797835;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[50] <= -1578.0) {
                                        return -0.00296984783352;
                                    } else {
                                        return -0.0455757388523;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0437315664652;
                                    } else {
                                        return -0.0426576791243;
                                    }
                                }
                            }
                        } else {
                            return 0.0928762773464;
                        }
                    }
                }
            }
        } else {
            if (fs[97] <= 1.5) {
                if (fs[11] <= 0.5) {
                    if (fs[73] <= 25.0) {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[68] <= 0.5) {
                                    if (fs[69] <= 4995.0) {
                                        return 0.638765693785;
                                    } else {
                                        return 0.701217769402;
                                    }
                                } else {
                                    if (fs[50] <= -1308.5) {
                                        return 0.000878080268286;
                                    } else {
                                        return 0.459193242993;
                                    }
                                }
                            } else {
                                if (fs[98] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.362901898971;
                                    } else {
                                        return 0.479036982622;
                                    }
                                } else {
                                    if (fs[56] <= 0.5) {
                                        return 0.557281937753;
                                    } else {
                                        return 0.634852150407;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[67] <= -3.5) {
                                    if (fs[82] <= 7.5) {
                                        return -0.00415751884355;
                                    } else {
                                        return 0.150183411884;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0183351752014;
                                    } else {
                                        return -0.0369790175848;
                                    }
                                }
                            } else {
                                if (fs[95] <= 1.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.0403570518395;
                                    } else {
                                        return -0.0277134912991;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.0434764971389;
                                    } else {
                                        return -0.0207480302845;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= -1083.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.689298844719;
                                    } else {
                                        return 0.564838432851;
                                    }
                                } else {
                                    if (fs[46] <= -3.5) {
                                        return 0.159886289294;
                                    } else {
                                        return 0.494108834183;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.121714568902;
                                    } else {
                                        return 0.284405066721;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0106897906652;
                                    } else {
                                        return 0.0501601890395;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[68] <= 0.5) {
                                        return 0.162146944927;
                                    } else {
                                        return -0.0423506026729;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.46659567285;
                                    } else {
                                        return 0.0330579587604;
                                    }
                                }
                            } else {
                                if (fs[65] <= 1.5) {
                                    if (fs[69] <= 9999.5) {
                                        return -0.0406928649386;
                                    } else {
                                        return -0.022822882524;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.306880020495;
                                    } else {
                                        return -0.043381524535;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[82] <= 6.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[50] <= -987.5) {
                                        return 0.371879015383;
                                    } else {
                                        return 0.16221606454;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.503052927318;
                                    } else {
                                        return 0.376480510623;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[73] <= 25.0) {
                                        return 0.0603688651231;
                                    } else {
                                        return 0.314181971165;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.293169299258;
                                    } else {
                                        return 0.49016075243;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[82] <= 7.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.635264807106;
                                    } else {
                                        return -0.151661060603;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.485046018168;
                                    } else {
                                        return 0.668856627132;
                                    }
                                }
                            } else {
                                if (fs[50] <= -1078.0) {
                                    if (fs[49] <= 0.5) {
                                        return 0.457581746741;
                                    } else {
                                        return 0.549564517971;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.169441925526;
                                    } else {
                                        return 0.498046325625;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[69] <= 9868.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[82] <= 7.5) {
                                        return 0.0123831396121;
                                    } else {
                                        return 0.246961167363;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0241331958971;
                                    } else {
                                        return -0.0403589864813;
                                    }
                                }
                            } else {
                                if (fs[2] <= 13.5) {
                                    if (fs[50] <= -21.5) {
                                        return -0.042387134379;
                                    } else {
                                        return -0.0434624033373;
                                    }
                                } else {
                                    return 0.0531020555104;
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[50] <= -1418.0) {
                                    if (fs[82] <= 7.5) {
                                        return 0.146019226882;
                                    } else {
                                        return 0.45329019231;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0952030023529;
                                    } else {
                                        return -0.0474194903195;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[69] <= 9999.5) {
                                        return 0.00842443200564;
                                    } else {
                                        return 0.125067561524;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return -0.0431569624545;
                                    } else {
                                        return 0.020052338374;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[50] <= -1052.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[49] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 20.5) {
                                        return 0.64898162685;
                                    } else {
                                        return 0.487915885557;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.414294590409;
                                    } else {
                                        return 0.241927021038;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.528300168035;
                                    } else {
                                        return 0.623250132868;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.41949297899;
                                    } else {
                                        return 0.175130569476;
                                    }
                                }
                            }
                        } else {
                            if (fs[46] <= -0.5) {
                                if (fs[0] <= 9.5) {
                                    if (fs[50] <= -1138.0) {
                                        return 0.266025187263;
                                    } else {
                                        return 0.513050244404;
                                    }
                                } else {
                                    return 0.885809968814;
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0853165484052;
                                    } else {
                                        return 0.161275173053;
                                    }
                                } else {
                                    if (fs[50] <= -1088.5) {
                                        return 0.177043702946;
                                    } else {
                                        return 0.72035023449;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.287431564809;
                                    } else {
                                        return 0.058671011819;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.0601108691811;
                                    } else {
                                        return 0.0240570063771;
                                    }
                                }
                            } else {
                                if (fs[69] <= 9999.5) {
                                    if (fs[61] <= -997.5) {
                                        return 0.0471352710429;
                                    } else {
                                        return -0.0495169002816;
                                    }
                                } else {
                                    return 0.0927121819278;
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[59] <= -0.5) {
                                    return -0.0803186996827;
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.238290300403;
                                    } else {
                                        return -0.047732240561;
                                    }
                                }
                            } else {
                                return 0.39751370154;
                            }
                        }
                    }
                } else {
                    if (fs[61] <= -995.5) {
                        if (fs[61] <= -998.5) {
                            if (fs[50] <= 7.5) {
                                return 0.341757643484;
                            } else {
                                return -0.0455875497035;
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.183439674347;
                                    } else {
                                        return -0.054151823477;
                                    }
                                } else {
                                    return 0.557563639532;
                                }
                            } else {
                                if (fs[59] <= -2.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.22016862749;
                                    } else {
                                        return -0.0466116331897;
                                    }
                                } else {
                                    if (fs[50] <= -986.5) {
                                        return -0.0280986706357;
                                    } else {
                                        return -0.0462504138676;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    return 0.366165593326;
                                } else {
                                    return 0.6077439862;
                                }
                            } else {
                                if (fs[49] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0229159288788;
                                    } else {
                                        return 0.330317005004;
                                    }
                                } else {
                                    return 0.274274643476;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.101944794843;
                                    } else {
                                        return -0.0275311214273;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.00206182611542;
                                    } else {
                                        return -0.0402920837755;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[4] <= 2.5) {
                                        return -0.0317517308683;
                                    } else {
                                        return -0.0445560036042;
                                    }
                                } else {
                                    if (fs[50] <= -992.5) {
                                        return -0.0216723652198;
                                    } else {
                                        return -0.0421570661096;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
