/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree95 {
    public double calcTree(double... fs) {
        if (fs[0] <= 1.5) {
            if (fs[2] <= 1.5) {
                if (fs[4] <= 4.5) {
                    if (fs[97] <= 0.5) {
                        if (fs[25] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[98] <= 0.5) {
                                        return -0.00407905512676;
                                    } else {
                                        return 0.0244824678909;
                                    }
                                } else {
                                    return 0.246371390484;
                                }
                            } else {
                                if (fs[53] <= -1143.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.0625827595431;
                                    } else {
                                        return -0.081986450227;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0508476391571;
                                    } else {
                                        return 0.0151805564662;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 6.5) {
                                if (fs[100] <= 0.5) {
                                    if (fs[4] <= 1.5) {
                                        return -0.068290125309;
                                    } else {
                                        return -0.0276237926947;
                                    }
                                } else {
                                    if (fs[4] <= 1.5) {
                                        return 0.121606112561;
                                    } else {
                                        return -0.067247914773;
                                    }
                                }
                            } else {
                                if (fs[72] <= 8575.0) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00213916797484;
                                    } else {
                                        return 0.259155900173;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.130383069959;
                                    } else {
                                        return 0.0430539115965;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[13] <= 0.5) {
                            if (fs[53] <= -1123.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.257146006408;
                                    } else {
                                        return 0.0673758757975;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0467087822034;
                                    } else {
                                        return 0.0884380925823;
                                    }
                                }
                            } else {
                                return 0.0100504911305;
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[53] <= -1314.0) {
                                    if (fs[72] <= 4770.5) {
                                        return 0.0388733563418;
                                    } else {
                                        return -0.209772350945;
                                    }
                                } else {
                                    if (fs[53] <= -1138.5) {
                                        return 0.08582020716;
                                    } else {
                                        return 0.0445111824418;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return -0.0595533617474;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0789933594021;
                                    } else {
                                        return -0.0961156526343;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[64] <= -996.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[4] <= 15.5) {
                                    if (fs[0] <= 0.5) {
                                        return -0.12281854195;
                                    } else {
                                        return -0.0364577234223;
                                    }
                                } else {
                                    return 0.0158675980891;
                                }
                            } else {
                                return 0.00822247457306;
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[64] <= -998.5) {
                                    if (fs[58] <= 0.5) {
                                        return 0.0473325471515;
                                    } else {
                                        return -0.0925697437573;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.0489116618375;
                                    } else {
                                        return -0.0184994784656;
                                    }
                                }
                            } else {
                                if (fs[62] <= -2.5) {
                                    return 0.250151188759;
                                } else {
                                    if (fs[58] <= 0.5) {
                                        return 0.0635816081161;
                                    } else {
                                        return -0.0400457345154;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1493.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[2] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.00499871042933;
                                    } else {
                                        return -0.153114868426;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return 0.0439659055154;
                                    } else {
                                        return -0.00225826059589;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.0662431719901;
                                    } else {
                                        return 0.155069354003;
                                    }
                                } else {
                                    if (fs[76] <= 125.0) {
                                        return -0.0022099188032;
                                    } else {
                                        return 0.0833274638267;
                                    }
                                }
                            }
                        } else {
                            if (fs[55] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0606842723986;
                                    } else {
                                        return -0.00397396556501;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0173588534775;
                                    } else {
                                        return 0.000362719463602;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    return 0.0393334990916;
                                } else {
                                    if (fs[85] <= 3.0) {
                                        return 0.099751709254;
                                    } else {
                                        return 0.219657611982;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 18.5) {
                    if (fs[76] <= 75.0) {
                        if (fs[82] <= 0.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[85] <= 3.5) {
                                        return 0.00732065667816;
                                    } else {
                                        return 0.032507919145;
                                    }
                                } else {
                                    if (fs[72] <= 9938.5) {
                                        return -0.0254726263623;
                                    } else {
                                        return 0.0370353097618;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.142630374689;
                                    } else {
                                        return -0.242975707436;
                                    }
                                } else {
                                    if (fs[72] <= 4995.0) {
                                        return 0.149706253452;
                                    } else {
                                        return -0.125919018633;
                                    }
                                }
                            }
                        } else {
                            if (fs[87] <= 0.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return -0.0304985079874;
                                    } else {
                                        return -0.00466097214714;
                                    }
                                } else {
                                    if (fs[72] <= 9768.5) {
                                        return -0.0141913209572;
                                    } else {
                                        return 0.102029586728;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9982.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.0505020323497;
                                    } else {
                                        return 0.12864581904;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0700985942317;
                                    } else {
                                        return -0.0309342513981;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[37] <= 0.5) {
                            if (fs[85] <= 5.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[53] <= -1128.0) {
                                        return 0.0639561940584;
                                    } else {
                                        return -0.0613286317242;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.0148490700865;
                                    } else {
                                        return -0.130856816656;
                                    }
                                }
                            } else {
                                if (fs[53] <= -992.0) {
                                    if (fs[71] <= 0.5) {
                                        return 0.00893862492928;
                                    } else {
                                        return -0.0230328292716;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.123734716824;
                                    } else {
                                        return -0.0162209861459;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.191852416599;
                                    } else {
                                        return 0.0580181154028;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0742038440057;
                                    } else {
                                        return -0.0288407522789;
                                    }
                                }
                            } else {
                                if (fs[85] <= 3.0) {
                                    if (fs[72] <= 9975.5) {
                                        return 0.401879656639;
                                    } else {
                                        return 0.21406418085;
                                    }
                                } else {
                                    return 0.0153605409713;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[57] <= 0.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[87] <= 0.5) {
                                if (fs[64] <= -996.5) {
                                    return 0.318314668694;
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.0421108860391;
                                    } else {
                                        return -0.0119269256331;
                                    }
                                }
                            } else {
                                if (fs[100] <= 0.5) {
                                    if (fs[76] <= 300.0) {
                                        return 0.0584626237245;
                                    } else {
                                        return -0.0962177644731;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0512778665614;
                                    } else {
                                        return 0.0170138271297;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 45.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[2] <= 8.5) {
                                        return -0.0596350684616;
                                    } else {
                                        return 0.109884385515;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.064397268904;
                                    } else {
                                        return 0.0156576171199;
                                    }
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    return -0.308979169585;
                                } else {
                                    return -0.101181824706;
                                }
                            }
                        }
                    } else {
                        if (fs[64] <= -496.0) {
                            return 0.100865909613;
                        } else {
                            return 0.246048556647;
                        }
                    }
                }
            }
        } else {
            if (fs[76] <= 350.0) {
                if (fs[29] <= 0.5) {
                    if (fs[4] <= 26.5) {
                        if (fs[62] <= -1.5) {
                            if (fs[47] <= 0.5) {
                                if (fs[0] <= 30.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.113646774805;
                                    } else {
                                        return -0.0145786856046;
                                    }
                                } else {
                                    if (fs[100] <= 0.5) {
                                        return 0.171855451487;
                                    } else {
                                        return 0.227568441988;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[64] <= -996.5) {
                                        return -0.00980835380942;
                                    } else {
                                        return -0.000897532892211;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0485398534606;
                                    } else {
                                        return -0.0189573987096;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[72] <= 9997.5) {
                                    if (fs[40] <= 0.5) {
                                        return -0.000337123447976;
                                    } else {
                                        return -0.00186483527154;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return 0.0161763142915;
                                    } else {
                                        return -0.0232573538264;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1428.0) {
                                    if (fs[87] <= 0.5) {
                                        return 0.00300264290194;
                                    } else {
                                        return 0.0267550423049;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.00104837045216;
                                    } else {
                                        return -0.0104006863452;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9976.5) {
                            if (fs[36] <= 0.5) {
                                if (fs[72] <= 9975.5) {
                                    if (fs[72] <= 9956.5) {
                                        return -0.00156556710808;
                                    } else {
                                        return -0.0216710565528;
                                    }
                                } else {
                                    if (fs[4] <= 30.5) {
                                        return 0.0830718055303;
                                    } else {
                                        return 0.333029578238;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    return 0.280088662855;
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return 0.0351642214287;
                                    } else {
                                        return -0.00896942267671;
                                    }
                                }
                            }
                        } else {
                            if (fs[89] <= 0.5) {
                                if (fs[72] <= 9993.5) {
                                    if (fs[72] <= 9985.5) {
                                        return -0.0729754096109;
                                    } else {
                                        return 0.228758540496;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return -0.15519114268;
                                    } else {
                                        return 0.0231924456868;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return -0.156494830848;
                                    } else {
                                        return -0.0287071258612;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.000889205894924;
                                    } else {
                                        return 0.0357780359672;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 5.5) {
                        if (fs[87] <= 0.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[72] <= 9788.5) {
                                    if (fs[96] <= 0.5) {
                                        return -0.00757632342564;
                                    } else {
                                        return -0.0269900106193;
                                    }
                                } else {
                                    if (fs[98] <= 1.5) {
                                        return -0.0583577602652;
                                    } else {
                                        return 0.0971689901493;
                                    }
                                }
                            } else {
                                if (fs[85] <= 6.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0386524954301;
                                    } else {
                                        return -0.0267855051499;
                                    }
                                } else {
                                    if (fs[4] <= 7.0) {
                                        return -0.0535899452144;
                                    } else {
                                        return -0.0274440800063;
                                    }
                                }
                            }
                        } else {
                            if (fs[96] <= 0.5) {
                                return 0.045416556328;
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.094214570625;
                                    } else {
                                        return -0.0739064092167;
                                    }
                                } else {
                                    return -0.0943200943307;
                                }
                            }
                        }
                    } else {
                        if (fs[98] <= 1.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[0] <= 10.5) {
                                        return 0.031746815243;
                                    } else {
                                        return -0.00435615458515;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.00145636744558;
                                    } else {
                                        return -0.0100325747303;
                                    }
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    return -0.0265599463979;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.0149061439553;
                                    } else {
                                        return -0.00691641204603;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 100.0) {
                                if (fs[53] <= -1488.0) {
                                    if (fs[0] <= 15.5) {
                                        return -0.0312367870094;
                                    } else {
                                        return -0.014467739599;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0516596470241;
                                    } else {
                                        return -0.00760815045008;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0513135041951;
                                    } else {
                                        return -0.069028359405;
                                    }
                                } else {
                                    return 0.00231046495525;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[64] <= -995.5) {
                    if (fs[0] <= 3.5) {
                        return -0.0727073876589;
                    } else {
                        if (fs[47] <= 0.5) {
                            if (fs[98] <= 0.5) {
                                return -0.0270073740465;
                            } else {
                                return -0.047972525589;
                            }
                        } else {
                            return -0.0167162246542;
                        }
                    }
                } else {
                    if (fs[12] <= 0.5) {
                        if (fs[98] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[53] <= -1143.5) {
                                    if (fs[0] <= 62.5) {
                                        return -0.0177063155176;
                                    } else {
                                        return 0.0200972972568;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return -0.00304995395056;
                                    } else {
                                        return -0.130429592111;
                                    }
                                }
                            } else {
                                return -0.0211132239981;
                            }
                        } else {
                            if (fs[72] <= 9990.0) {
                                if (fs[53] <= -1103.0) {
                                    if (fs[4] <= 13.5) {
                                        return -0.0356040793888;
                                    } else {
                                        return -0.0131451475576;
                                    }
                                } else {
                                    if (fs[53] <= -1067.5) {
                                        return 0.0250194280164;
                                    } else {
                                        return -0.00270894707993;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[4] <= 21.0) {
                                        return -0.0870855171657;
                                    } else {
                                        return -0.0444903491584;
                                    }
                                } else {
                                    return -0.0113358613894;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1478.5) {
                            return 0.155111386839;
                        } else {
                            if (fs[53] <= -1133.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[53] <= -1143.5) {
                                        return -0.0429819957269;
                                    } else {
                                        return -0.0252191141218;
                                    }
                                } else {
                                    if (fs[0] <= 6.0) {
                                        return -0.120150368562;
                                    } else {
                                        return 0.155777818094;
                                    }
                                }
                            } else {
                                if (fs[0] <= 10.5) {
                                    if (fs[53] <= -1103.0) {
                                        return 0.0509477232013;
                                    } else {
                                        return -0.0102287230708;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0227121260948;
                                    } else {
                                        return -0.00610867342144;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
