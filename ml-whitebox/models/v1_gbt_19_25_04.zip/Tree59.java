/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree59 {
    public double calcTree(double... fs) {
        if (fs[11] <= 0.5) {
            if (fs[64] <= -997.5) {
                if (fs[47] <= 0.5) {
                    if (fs[98] <= 0.5) {
                        if (fs[64] <= -998.5) {
                            if (fs[102] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.138865804255;
                                    } else {
                                        return -0.056316251915;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0563223209673;
                                    } else {
                                        return -0.0261426672414;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    return -0.0755073326785;
                                } else {
                                    return 0.153028316607;
                                }
                            }
                        } else {
                            if (fs[72] <= 4999.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.00501500269929;
                                    } else {
                                        return 0.0573835287903;
                                    }
                                } else {
                                    return -0.156269108669;
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    return 0.16024691717;
                                } else {
                                    return 0.214521569954;
                                }
                            }
                        }
                    } else {
                        if (fs[31] <= 0.5) {
                            if (fs[100] <= 1.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0881815749757;
                                    } else {
                                        return -0.0838292371272;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.194517815368;
                                    } else {
                                        return 0.141596350159;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.126243446797;
                                } else {
                                    return -0.158333888776;
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[58] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0582176105659;
                                    } else {
                                        return 0.108001593174;
                                    }
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return 0.0640136162987;
                                    } else {
                                        return -0.0633155175881;
                                    }
                                }
                            } else {
                                return 0.388897446691;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 13.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[58] <= 0.5) {
                                return -0.0445100848786;
                            } else {
                                return -0.0160695656312;
                            }
                        } else {
                            if (fs[72] <= 5000.0) {
                                if (fs[60] <= 0.5) {
                                    if (fs[100] <= 1.5) {
                                        return -0.0154403407606;
                                    } else {
                                        return -0.00771335844187;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0142176929202;
                                    } else {
                                        return -0.0375102392346;
                                    }
                                }
                            } else {
                                return 0.00973557525604;
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            return 0.0570219690709;
                        } else {
                            return 0.0205586814953;
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[74] <= 0.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[102] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.261154600624;
                                    } else {
                                        return 0.105528779807;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0723553063536;
                                    } else {
                                        return 0.24844104565;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.244310592875;
                                    } else {
                                        return 0.026104345478;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.0132181515612;
                                    } else {
                                        return 0.0888059535193;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return 0.0394225532427;
                                    } else {
                                        return 0.189345947598;
                                    }
                                } else {
                                    if (fs[53] <= -1443.0) {
                                        return -0.167132763068;
                                    } else {
                                        return 0.245705118955;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0172743417679;
                                    } else {
                                        return -0.0508278122218;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.374380067811;
                                    } else {
                                        return -0.132518795612;
                                    }
                                }
                            }
                        }
                    } else {
                        return -0.0123779225621;
                    }
                } else {
                    if (fs[0] <= 6.5) {
                        if (fs[72] <= 9256.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[53] <= -1488.0) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0131267333186;
                                    } else {
                                        return 0.0657113472324;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.00306857494567;
                                    } else {
                                        return -0.0087975830282;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0220865662612;
                                    } else {
                                        return 0.315510607474;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.00258011063596;
                                    } else {
                                        return -0.0150828562559;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1128.0) {
                                if (fs[81] <= 0.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.0967427060085;
                                    } else {
                                        return -0.00469042997507;
                                    }
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return 0.506693557217;
                                    } else {
                                        return -0.00920200189663;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0248117587902;
                                    } else {
                                        return -0.0152804940876;
                                    }
                                } else {
                                    return 0.398604051022;
                                }
                            }
                        }
                    } else {
                        if (fs[64] <= -996.5) {
                            if (fs[53] <= 3.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.050961568338;
                                    } else {
                                        return 0.304909878528;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.158974116623;
                                    } else {
                                        return -0.00870982031946;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[49] <= -1.5) {
                                        return -0.0202890509355;
                                    } else {
                                        return -0.0140191117969;
                                    }
                                } else {
                                    return 0.00918339568643;
                                }
                            }
                        } else {
                            if (fs[62] <= -2.5) {
                                return 0.134204585532;
                            } else {
                                if (fs[4] <= 43.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.00296126246296;
                                    } else {
                                        return 0.016347519206;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return -0.00433453253947;
                                    } else {
                                        return -0.022489947731;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[23] <= 0.5) {
                    if (fs[53] <= -1498.5) {
                        if (fs[53] <= -1928.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[72] <= 8353.0) {
                                        return -0.0155716366437;
                                    } else {
                                        return 0.183839069759;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.253996719607;
                                    } else {
                                        return 0.0229152156285;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.304144632661;
                                    } else {
                                        return 0.175829848981;
                                    }
                                } else {
                                    if (fs[89] <= 0.5) {
                                        return 0.23101450971;
                                    } else {
                                        return 0.0853414565788;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 16.5) {
                                if (fs[53] <= -1913.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.488326251576;
                                    } else {
                                        return 0.293638075298;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.147530506384;
                                    } else {
                                        return 0.192722671849;
                                    }
                                }
                            } else {
                                if (fs[102] <= 0.5) {
                                    if (fs[53] <= -1843.5) {
                                        return 0.0216194180249;
                                    } else {
                                        return 0.156378815982;
                                    }
                                } else {
                                    return -0.206625468333;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 14.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[53] <= -987.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0380759468623;
                                    } else {
                                        return -0.304213783343;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.01351521525;
                                    } else {
                                        return -0.130263542644;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0610390554201;
                                    } else {
                                        return -0.00712300397485;
                                    }
                                } else {
                                    if (fs[85] <= 1.0) {
                                        return -0.291333848051;
                                    } else {
                                        return 0.0649912350258;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 9.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return -0.0303009891872;
                                    } else {
                                        return 0.156012235595;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0127675394958;
                                    } else {
                                        return 0.143191060603;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    if (fs[98] <= 1.5) {
                                        return 0.0656608950431;
                                    } else {
                                        return 0.197984386032;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return -0.233552957247;
                                    } else {
                                        return 0.0627952270887;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[98] <= 0.5) {
                        if (fs[72] <= 9967.0) {
                            if (fs[2] <= 1.5) {
                                if (fs[60] <= 0.5) {
                                    return 0.158254623356;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.245171641303;
                                    } else {
                                        return 0.315141565366;
                                    }
                                }
                            } else {
                                if (fs[70] <= -4.0) {
                                    return 0.272664098662;
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.252281710671;
                                    } else {
                                        return 0.324941176104;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1128.0) {
                                if (fs[4] <= 5.5) {
                                    return 0.0839113143098;
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.185126710646;
                                    } else {
                                        return 0.193286526739;
                                    }
                                }
                            } else {
                                return -0.0165701694473;
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -1138.0) {
                                return 0.0896412543629;
                            } else {
                                return 0.110997706707;
                            }
                        } else {
                            return 0.0923512936026;
                        }
                    }
                }
            } else {
                if (fs[34] <= 0.5) {
                    if (fs[55] <= 998.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[85] <= 7.5) {
                                        return -0.00600050928658;
                                    } else {
                                        return -0.0839070622937;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.00385757467448;
                                    } else {
                                        return 0.0296483116101;
                                    }
                                }
                            } else {
                                if (fs[80] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.0121610747512;
                                    } else {
                                        return 0.0109605578393;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.102154126629;
                                    } else {
                                        return -0.0357135950917;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 6548.5) {
                                if (fs[85] <= -0.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.00544092868506;
                                    } else {
                                        return -0.00348347079327;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0040535653313;
                                    } else {
                                        return -0.00177951927983;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1428.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.00515168748706;
                                    } else {
                                        return 0.0713650817915;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0111115643181;
                                    } else {
                                        return -0.00169239110482;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[94] <= 0.5) {
                            return 0.489660104101;
                        } else {
                            return 0.180359860368;
                        }
                    }
                } else {
                    if (fs[53] <= -1138.0) {
                        return 0.0570025041755;
                    } else {
                        return 0.223439935447;
                    }
                }
            }
        }
    }
}
