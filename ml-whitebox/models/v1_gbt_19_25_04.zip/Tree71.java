/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree71 {
    public double calcTree(double... fs) {
        if (fs[87] <= 0.5) {
            if (fs[55] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[51] <= 0.5) {
                        if (fs[80] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1553.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.143056113071;
                                    } else {
                                        return 0.108814999019;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0281788641339;
                                    } else {
                                        return -0.0153768631759;
                                    }
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0349289414204;
                                    } else {
                                        return 0.0166764204963;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.0936514564266;
                                    } else {
                                        return -0.00583636323289;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                return 0.226363259749;
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[72] <= 9986.5) {
                                        return -0.245562609712;
                                    } else {
                                        return -0.368544688126;
                                    }
                                } else {
                                    return -0.00763585901627;
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                return 0.174144891579;
                            } else {
                                return 0.161415578993;
                            }
                        } else {
                            if (fs[72] <= 9998.0) {
                                if (fs[4] <= 4.5) {
                                    return 0.269636258691;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.385913950477;
                                    } else {
                                        return 0.262614740995;
                                    }
                                }
                            } else {
                                return 0.147551509815;
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9997.5) {
                        if (fs[34] <= 0.5) {
                            if (fs[102] <= 0.5) {
                                if (fs[47] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.00406077938013;
                                    } else {
                                        return -0.000957424724047;
                                    }
                                } else {
                                    if (fs[50] <= 0.5) {
                                        return -0.00329361381522;
                                    } else {
                                        return -0.0132649177701;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[81] <= 0.5) {
                                        return -0.000750266841496;
                                    } else {
                                        return 0.0177851253568;
                                    }
                                } else {
                                    if (fs[51] <= 0.5) {
                                        return -0.00198087815759;
                                    } else {
                                        return 0.0187048890905;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[53] <= -1138.0) {
                                    return 0.0843307155152;
                                } else {
                                    return 0.172886054759;
                                }
                            } else {
                                return 0.275534926133;
                            }
                        }
                    } else {
                        if (fs[53] <= -1067.5) {
                            if (fs[53] <= -1137.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[64] <= -997.5) {
                                        return -0.162650868124;
                                    } else {
                                        return 0.0248274372322;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0216310063648;
                                    } else {
                                        return 0.236738527426;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    return 0.42293663163;
                                } else {
                                    if (fs[85] <= 1.5) {
                                        return 0.0580783405302;
                                    } else {
                                        return 0.479770497096;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[4] <= 17.5) {
                                        return -0.0265835018431;
                                    } else {
                                        return 0.00529587030647;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.0181007075431;
                                    } else {
                                        return -0.0392097984076;
                                    }
                                }
                            } else {
                                if (fs[53] <= 3.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.100281473757;
                                    } else {
                                        return -0.0103795750992;
                                    }
                                } else {
                                    return -0.0865273588898;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 17.5) {
                    if (fs[51] <= 0.5) {
                        if (fs[53] <= 3.5) {
                            if (fs[76] <= 75.0) {
                                if (fs[53] <= -986.0) {
                                    if (fs[85] <= 3.0) {
                                        return 0.199559475445;
                                    } else {
                                        return 0.326204196179;
                                    }
                                } else {
                                    return 0.439668275445;
                                }
                            } else {
                                if (fs[102] <= 0.5) {
                                    return 0.253148329743;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.151154138198;
                                    } else {
                                        return -0.0449204667652;
                                    }
                                }
                            }
                        } else {
                            return -0.0284480100452;
                        }
                    } else {
                        return -0.0146767208956;
                    }
                } else {
                    if (fs[53] <= -471.5) {
                        if (fs[0] <= 0.5) {
                            return -0.332023123616;
                        } else {
                            if (fs[0] <= 2.5) {
                                return -0.148302282789;
                            } else {
                                return -0.00822342165276;
                            }
                        }
                    } else {
                        return 0.257380422746;
                    }
                }
            }
        } else {
            if (fs[82] <= 0.5) {
                if (fs[4] <= 6.5) {
                    if (fs[53] <= -1093.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[58] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[53] <= -1128.5) {
                                        return 0.0285961485703;
                                    } else {
                                        return 0.0666322232463;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.098952035668;
                                    } else {
                                        return 0.0292917175077;
                                    }
                                }
                            } else {
                                if (fs[64] <= -998.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0940683839528;
                                    } else {
                                        return -0.0113363322308;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.152701534512;
                                    } else {
                                        return -0.0984580059981;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                return 0.293453058944;
                            } else {
                                if (fs[42] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.00419210694248;
                                    } else {
                                        return -0.047993012286;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.20427191658;
                                    } else {
                                        return -0.103384229899;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[62] <= -0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[47] <= 0.5) {
                                    if (fs[64] <= -998.5) {
                                        return 0.0351538770091;
                                    } else {
                                        return 0.141782760979;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.00829723803035;
                                    } else {
                                        return -0.0102010275768;
                                    }
                                }
                            } else {
                                if (fs[98] <= 1.5) {
                                    return 0.281586633345;
                                } else {
                                    if (fs[100] <= 0.5) {
                                        return 0.205752285205;
                                    } else {
                                        return 0.0642527254805;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0648308187169;
                                    } else {
                                        return 0.0334131347894;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.00642207189178;
                                    } else {
                                        return 0.00492251157875;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0229246232522;
                                    } else {
                                        return -0.109582697243;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0542812445232;
                                    } else {
                                        return 0.137434475984;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[64] <= -997.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[47] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.0481199039318;
                                    } else {
                                        return -0.0790283451658;
                                    }
                                } else {
                                    if (fs[100] <= 1.5) {
                                        return 0.106074220097;
                                    } else {
                                        return -0.109244804265;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0283389622256;
                                    } else {
                                        return -0.0130605123695;
                                    }
                                } else {
                                    return 0.0792095160754;
                                }
                            }
                        } else {
                            if (fs[51] <= 0.5) {
                                if (fs[98] <= 1.5) {
                                    return 0.177515619948;
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.095906316494;
                                    } else {
                                        return -0.0116215979979;
                                    }
                                }
                            } else {
                                return -0.209619602024;
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[76] <= 350.0) {
                                if (fs[58] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.00443505444015;
                                    } else {
                                        return 0.0322121189747;
                                    }
                                } else {
                                    if (fs[64] <= -995.5) {
                                        return -0.155229734396;
                                    } else {
                                        return -0.0416512166578;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[4] <= 22.5) {
                                        return -0.187067549946;
                                    } else {
                                        return 0.0163935750259;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0551549808936;
                                    } else {
                                        return -0.0889600908292;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 33.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[51] <= 0.5) {
                                        return -0.0040047800242;
                                    } else {
                                        return 0.0513232319632;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return 0.00550796342609;
                                    } else {
                                        return -0.00187818384936;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[47] <= 0.5) {
                                        return -0.0250084305636;
                                    } else {
                                        return 0.000765837610968;
                                    }
                                } else {
                                    if (fs[53] <= -1042.5) {
                                        return -0.0289658154923;
                                    } else {
                                        return -0.00292284649679;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1143.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[42] <= 0.5) {
                            if (fs[72] <= 9719.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[72] <= 4265.5) {
                                        return 0.0444171297804;
                                    } else {
                                        return 0.262050822131;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.118488778904;
                                    } else {
                                        return 0.520830086683;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9786.5) {
                                    return -0.423663483572;
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.00816745082402;
                                    } else {
                                        return 0.0718866010066;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 4799.0) {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.0333810467819;
                                    } else {
                                        return -0.200130775456;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return 0.190731972984;
                                    } else {
                                        return 0.0342256905878;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9989.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.00486848999287;
                                    } else {
                                        return -0.175793367342;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0159223974126;
                                    } else {
                                        return 0.11544367153;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[72] <= 4627.0) {
                                        return 0.0409139082681;
                                    } else {
                                        return -0.0730868236913;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.100375435153;
                                    } else {
                                        return 0.460243201088;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.00386906608563;
                                    } else {
                                        return 0.151498098262;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.443732245512;
                                    } else {
                                        return -0.114153718872;
                                    }
                                }
                            }
                        } else {
                            if (fs[66] <= 5.0) {
                                if (fs[4] <= 9.5) {
                                    if (fs[72] <= 9671.5) {
                                        return 0.171604311896;
                                    } else {
                                        return -0.184175289923;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return 0.318284922301;
                                    } else {
                                        return 0.109116767286;
                                    }
                                }
                            } else {
                                return -0.133485587932;
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -918.0) {
                        if (fs[53] <= -987.0) {
                            if (fs[4] <= 7.5) {
                                return 0.18177402131;
                            } else {
                                if (fs[4] <= 8.5) {
                                    return -0.111716196056;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.108669174842;
                                    } else {
                                        return -0.0114546060759;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[72] <= 9965.5) {
                                        return -0.114650876342;
                                    } else {
                                        return -0.0550119127521;
                                    }
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return -0.0303619268709;
                                    } else {
                                        return -0.00654942233638;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return -0.189978243593;
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0636481586579;
                                    } else {
                                        return -0.019337989709;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                return -0.0291134781807;
                            } else {
                                return 0.282382765587;
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.00857458967506;
                                    } else {
                                        return 0.0216278626107;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.114853370316;
                                    } else {
                                        return -0.0260596886024;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[0] <= 6.5) {
                                        return 0.161861176535;
                                    } else {
                                        return -0.0356995750591;
                                    }
                                } else {
                                    if (fs[72] <= 9950.0) {
                                        return -0.0143261713126;
                                    } else {
                                        return -0.00571404645595;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
