/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree52 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[40] <= 0.5) {
                if (fs[85] <= -0.5) {
                    if (fs[70] <= -3.5) {
                        return -0.285572290118;
                    } else {
                        if (fs[53] <= -6.0) {
                            if (fs[4] <= 21.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[53] <= -1118.5) {
                                        return -0.127305563522;
                                    } else {
                                        return -0.0245347218519;
                                    }
                                } else {
                                    if (fs[53] <= -1553.0) {
                                        return 0.0885020897761;
                                    } else {
                                        return -0.0664750309927;
                                    }
                                }
                            } else {
                                return -0.186785059718;
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                return -0.225406290842;
                            } else {
                                if (fs[49] <= -0.5) {
                                    return -0.277033813479;
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.158599773029;
                                    } else {
                                        return -0.0689992719805;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[72] <= 9986.0) {
                                        return 0.0595966021335;
                                    } else {
                                        return 0.1748863904;
                                    }
                                } else {
                                    if (fs[53] <= -1108.5) {
                                        return 0.0513845473711;
                                    } else {
                                        return -0.0408179962264;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.5) {
                                    if (fs[53] <= -1448.5) {
                                        return 0.118197077548;
                                    } else {
                                        return 0.0414905915569;
                                    }
                                } else {
                                    if (fs[53] <= -987.5) {
                                        return 0.136820774159;
                                    } else {
                                        return 0.0603933015651;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.00161773370539;
                                    } else {
                                        return 0.0570219142819;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.136787294346;
                                    } else {
                                        return 0.0582275323061;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[55] <= 0.5) {
                                        return -0.0154459790253;
                                    } else {
                                        return 0.358465708837;
                                    }
                                } else {
                                    if (fs[72] <= 9985.5) {
                                        return 0.296735199366;
                                    } else {
                                        return 0.1157414084;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 17.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[85] <= 6.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0675751114947;
                                    } else {
                                        return 0.0380012079907;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.129295577805;
                                    } else {
                                        return 0.0836849703792;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.0776132716552;
                                    } else {
                                        return -0.324500503676;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.11314630491;
                                    } else {
                                        return 0.172997151728;
                                    }
                                }
                            }
                        } else {
                            if (fs[98] <= 0.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.109257398104;
                                    } else {
                                        return -0.0456405822782;
                                    }
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return 0.400810985437;
                                    } else {
                                        return -0.0693415369245;
                                    }
                                }
                            } else {
                                if (fs[4] <= 48.5) {
                                    if (fs[51] <= 0.5) {
                                        return 0.0437530199065;
                                    } else {
                                        return -0.289440575718;
                                    }
                                } else {
                                    return -0.303598452328;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[76] <= 75.0) {
                    if (fs[102] <= 0.5) {
                        if (fs[33] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[100] <= 1.0) {
                                    if (fs[68] <= 1.5) {
                                        return -0.041919590092;
                                    } else {
                                        return -0.190979699964;
                                    }
                                } else {
                                    return 0.0709652242443;
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    return -0.180424726277;
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.28755909047;
                                    } else {
                                        return 0.053974320338;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[53] <= -1598.0) {
                                        return 0.229532523925;
                                    } else {
                                        return 0.000231719316757;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0723870970653;
                                    } else {
                                        return 0.108342324105;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1318.0) {
                                    return -0.271901194501;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.214604065001;
                                    } else {
                                        return 0.0688151930549;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.150596254646;
                                    } else {
                                        return 0.0208717384351;
                                    }
                                } else {
                                    return -0.0660838380086;
                                }
                            } else {
                                if (fs[72] <= 9715.0) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0450006272633;
                                    } else {
                                        return -0.113350408086;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.00342906962938;
                                    } else {
                                        return 0.0605194589758;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[52] <= 0.5) {
                                    return -0.231667030464;
                                } else {
                                    return 0.00570202847866;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.201161830276;
                                } else {
                                    return -0.328188770309;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1928.0) {
                        return 0.30767232368;
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[53] <= -1468.0) {
                                    if (fs[4] <= 5.5) {
                                        return -0.130610443869;
                                    } else {
                                        return -0.275772278503;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.175339501457;
                                    } else {
                                        return 0.0982647563637;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.0878889141523;
                                    } else {
                                        return 0.180898421693;
                                    }
                                } else {
                                    if (fs[72] <= 2989.5) {
                                        return 0.110647285668;
                                    } else {
                                        return -0.021236556004;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[80] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.127784759683;
                                    } else {
                                        return 0.0831214884359;
                                    }
                                } else {
                                    return 0.125817715755;
                                }
                            } else {
                                if (fs[42] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return 0.167960769607;
                                    } else {
                                        return 0.327809155353;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return -0.135377132661;
                                    } else {
                                        return 0.148586750562;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[47] <= 0.5) {
                    if (fs[12] <= 0.5) {
                        if (fs[4] <= 17.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[4] <= 4.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0432856194057;
                                    } else {
                                        return -0.0268036465065;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.000699728929838;
                                    } else {
                                        return 0.0691458984075;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.00540649866945;
                                    } else {
                                        return 0.0351512716737;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.112781121903;
                                    } else {
                                        return 0.0364914180772;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 11.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.0864022138432;
                                    } else {
                                        return -0.0155688465503;
                                    }
                                } else {
                                    if (fs[80] <= 0.5) {
                                        return -0.0104844321442;
                                    } else {
                                        return -0.0602414613385;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.0714939390408;
                                    } else {
                                        return 0.615351279291;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return -0.0312037756106;
                                    } else {
                                        return 0.109314616664;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1458.5) {
                            if (fs[66] <= 5.0) {
                                if (fs[81] <= 0.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.123601945846;
                                    } else {
                                        return 0.0388699504223;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.00181892088448;
                                    } else {
                                        return 0.0413683229044;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.0) {
                                    if (fs[96] <= 0.5) {
                                        return -0.173812464928;
                                    } else {
                                        return -0.286226891818;
                                    }
                                } else {
                                    return -0.0402653064398;
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.021736164384;
                                    } else {
                                        return -0.0554330560128;
                                    }
                                } else {
                                    return 0.66844885808;
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return 0.227952449284;
                                } else {
                                    return 0.447720338528;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -921.5) {
                        if (fs[68] <= 1.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[63] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.0854126463094;
                                    } else {
                                        return -0.0129690228549;
                                    }
                                } else {
                                    if (fs[72] <= 9721.5) {
                                        return -0.0225081608165;
                                    } else {
                                        return -0.0732488596664;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return 0.137185707199;
                                } else {
                                    return 0.0193918625623;
                                }
                            }
                        } else {
                            return 0.205958078217;
                        }
                    } else {
                        if (fs[70] <= -3.5) {
                            if (fs[72] <= 9989.5) {
                                if (fs[53] <= -3.0) {
                                    return -0.0731053642899;
                                } else {
                                    if (fs[102] <= 0.5) {
                                        return -0.0239661482188;
                                    } else {
                                        return -0.0485713501979;
                                    }
                                }
                            } else {
                                return -0.0905355718128;
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[85] <= 7.5) {
                                    if (fs[59] <= 0.5) {
                                        return -0.0201191106627;
                                    } else {
                                        return -0.0291364538281;
                                    }
                                } else {
                                    return -0.0700596003316;
                                }
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0195407542018;
                                    } else {
                                        return -0.0496177238781;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.0340375941171;
                                    } else {
                                        return 0.082679099263;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 7.5) {
                    if (fs[102] <= 0.5) {
                        if (fs[91] <= 0.5) {
                            if (fs[4] <= 18.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.00373825789528;
                                    } else {
                                        return 0.0200487747922;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00195982903638;
                                    } else {
                                        return 0.00723455245176;
                                    }
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return -0.00528993238716;
                                    } else {
                                        return 0.0499058594001;
                                    }
                                } else {
                                    if (fs[4] <= 55.0) {
                                        return 0.0461081803164;
                                    } else {
                                        return 0.211411721715;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9532.5) {
                                if (fs[4] <= 31.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.0248554957359;
                                    } else {
                                        return 0.279967187977;
                                    }
                                } else {
                                    if (fs[98] <= 1.5) {
                                        return -0.0183994039415;
                                    } else {
                                        return -0.0462995544512;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9897.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.341140639078;
                                    } else {
                                        return -0.0713445236949;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return 0.0989496489703;
                                    } else {
                                        return -0.025281238244;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[85] <= 6.5) {
                            if (fs[85] <= 5.5) {
                                if (fs[72] <= 9100.0) {
                                    if (fs[85] <= 1.5) {
                                        return -0.00751195850754;
                                    } else {
                                        return 0.00205024424378;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.00612699406696;
                                    } else {
                                        return 0.0449602497512;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return -0.0104420629295;
                                    } else {
                                        return -0.00111384985202;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.00039136239664;
                                    } else {
                                        return 0.054066778607;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0598141630978;
                                    } else {
                                        return 0.00218370774161;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0241208687909;
                                    } else {
                                        return 0.123183562945;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[53] <= -1118.0) {
                                        return 0.000995248895044;
                                    } else {
                                        return -0.0109531198873;
                                    }
                                } else {
                                    if (fs[72] <= 9502.0) {
                                        return 0.0134206892484;
                                    } else {
                                        return 0.435233902863;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[23] <= 0.5) {
                        if (fs[0] <= 16.5) {
                            if (fs[47] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return -0.00242671049643;
                                    } else {
                                        return -0.00467353496625;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return -0.000661628656651;
                                    } else {
                                        return 0.0469845267046;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1038.0) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00469612818405;
                                    } else {
                                        return 0.0210573056205;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.00738821704066;
                                    } else {
                                        return -0.0051032184217;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.0320511302002;
                                    } else {
                                        return -0.00503445940406;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return -0.00434231426093;
                                    } else {
                                        return -0.00571060799416;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return -0.0040902720364;
                                    } else {
                                        return -0.00259558469765;
                                    }
                                } else {
                                    if (fs[0] <= 100.5) {
                                        return -0.00966636052901;
                                    } else {
                                        return 0.0369065216362;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= 0.5) {
                            return 0.219543682674;
                        } else {
                            return -0.0110201404979;
                        }
                    }
                }
            }
        }
    }
}
