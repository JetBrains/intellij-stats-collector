/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree11 {
    public double calcTree(double... fs) {
        if (fs[78] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 6.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.523903527007;
                                    } else {
                                        return 0.378336682665;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.384919302222;
                                    } else {
                                        return 0.145874687962;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.506646708591;
                                    } else {
                                        return 0.579633281812;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.402867796741;
                                    } else {
                                        return 0.495814866866;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -1.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.552590765986;
                                    } else {
                                        return 0.416106134031;
                                    }
                                } else {
                                    if (fs[72] <= 4887.5) {
                                        return 0.517349144894;
                                    } else {
                                        return 0.424757928816;
                                    }
                                }
                            } else {
                                return 0.36035940719;
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[53] <= -1138.0) {
                                if (fs[4] <= 7.5) {
                                    if (fs[98] <= 1.0) {
                                        return 0.241719536223;
                                    } else {
                                        return 0.617303207577;
                                    }
                                } else {
                                    if (fs[76] <= 125.0) {
                                        return 0.538472448097;
                                    } else {
                                        return 0.230180223153;
                                    }
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[53] <= -1073.5) {
                                        return 0.532287359146;
                                    } else {
                                        return 0.164284763865;
                                    }
                                } else {
                                    return 0.137320560494;
                                }
                            }
                        } else {
                            return 0.0207171933245;
                        }
                    }
                } else {
                    if (fs[4] <= 6.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[53] <= -571.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.311102171145;
                                    } else {
                                        return 0.227764963713;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.0358724295759;
                                    } else {
                                        return -0.0633281720009;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0605475814778;
                                    } else {
                                        return -0.0255999537014;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.106001713287;
                                    } else {
                                        return 0.00282056429786;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    return 0.679171185545;
                                } else {
                                    if (fs[53] <= -556.5) {
                                        return 0.282225163407;
                                    } else {
                                        return -0.0766413933405;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.00473216365364;
                                    } else {
                                        return 0.309924945466;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.00490801996196;
                                    } else {
                                        return -0.0512999318526;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[72] <= 9998.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[31] <= 0.5) {
                                        return -0.0172061783888;
                                    } else {
                                        return 0.181202842051;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.0301194726409;
                                    } else {
                                        return -0.00152786325821;
                                    }
                                }
                            } else {
                                return 0.206152288254;
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[53] <= -1017.0) {
                                    return 0.172066790225;
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.15309294665;
                                    } else {
                                        return -0.0468296394137;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.0476555689196;
                                    } else {
                                        return -0.0406389197393;
                                    }
                                } else {
                                    return 0.0573029057301;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[98] <= 1.0) {
                                if (fs[72] <= 9997.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.525612548214;
                                    } else {
                                        return 0.543146007926;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.539768041306;
                                    } else {
                                        return -0.123895558209;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    return 0.142501134476;
                                } else {
                                    if (fs[64] <= -498.5) {
                                        return 0.55535817782;
                                    } else {
                                        return 0.496843403362;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[2] <= 2.5) {
                                        return 0.458340083448;
                                    } else {
                                        return 0.512617747275;
                                    }
                                } else {
                                    return 0.497224042127;
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.217881017925;
                                    } else {
                                        return 0.317039789845;
                                    }
                                } else {
                                    return -0.0515757878493;
                                }
                            }
                        }
                    } else {
                        return 0.130808766038;
                    }
                } else {
                    if (fs[98] <= 0.5) {
                        if (fs[34] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0110423620079;
                                    } else {
                                        return 0.374846172712;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.312824095346;
                                    } else {
                                        return 0.0523483325366;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0544687910363;
                                    } else {
                                        return -0.0242659367172;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0520155794091;
                                    } else {
                                        return 0.134186493203;
                                    }
                                }
                            }
                        } else {
                            return 0.711459196919;
                        }
                    } else {
                        if (fs[94] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    return -0.0623749386365;
                                } else {
                                    if (fs[53] <= -973.0) {
                                        return -0.0368469102788;
                                    } else {
                                        return -0.0385545173049;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[53] <= -1048.0) {
                                        return -0.0408974623165;
                                    } else {
                                        return -0.0253863774374;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.00761501008816;
                                    } else {
                                        return -0.0318330238646;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[11] <= 0.5) {
                                    return 0.104292628247;
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.17884713272;
                                    } else {
                                        return -0.0161614278387;
                                    }
                                }
                            } else {
                                return -0.0383401998691;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[100] <= 1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 12.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.500228568563;
                                    } else {
                                        return -0.00373515453061;
                                    }
                                } else {
                                    if (fs[53] <= -977.0) {
                                        return 0.463263750791;
                                    } else {
                                        return 0.315476635472;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.186902476215;
                                    } else {
                                        return 0.302388814782;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.577187818538;
                                    } else {
                                        return 0.602910017467;
                                    }
                                }
                            }
                        } else {
                            if (fs[42] <= 0.5) {
                                if (fs[85] <= 5.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.373224557267;
                                    } else {
                                        return 0.543034304766;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.526549000093;
                                    } else {
                                        return 0.364986273667;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[87] <= 0.5) {
                                        return -0.00222019518297;
                                    } else {
                                        return 0.19474017901;
                                    }
                                } else {
                                    if (fs[72] <= 9850.5) {
                                        return 0.281364308297;
                                    } else {
                                        return 0.0755208615616;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[59] <= 0.5) {
                                if (fs[96] <= 0.5) {
                                    if (fs[85] <= 6.5) {
                                        return 0.221892414056;
                                    } else {
                                        return 0.409256628286;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return 0.48941830661;
                                    } else {
                                        return 0.321239455325;
                                    }
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.342940901752;
                                    } else {
                                        return 0.50158845121;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0643007021156;
                                    } else {
                                        return 0.262578049819;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.16365848442;
                                    } else {
                                        return 0.0677140830938;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return 0.232216949161;
                                    } else {
                                        return 0.374485433249;
                                    }
                                }
                            } else {
                                if (fs[2] <= 7.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.255674977386;
                                    } else {
                                        return 0.370405917614;
                                    }
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return 0.42155000177;
                                    } else {
                                        return 0.167932456583;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[87] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[72] <= 8571.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[98] <= 0.5) {
                                        return -0.00081903243023;
                                    } else {
                                        return 0.0336725557427;
                                    }
                                } else {
                                    if (fs[53] <= -1488.5) {
                                        return 0.134643884707;
                                    } else {
                                        return 0.0141705845899;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.176393125716;
                                    } else {
                                        return 0.0634743776325;
                                    }
                                } else {
                                    if (fs[85] <= 7.5) {
                                        return 0.101332020702;
                                    } else {
                                        return 0.357446932457;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[72] <= 9962.5) {
                                        return -0.0267217546273;
                                    } else {
                                        return 0.0358901654475;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0293026769013;
                                    } else {
                                        return -0.0245744338842;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[0] <= 11.5) {
                                        return 0.0269725067262;
                                    } else {
                                        return -0.0242306985793;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.00970806462473;
                                    } else {
                                        return -0.019818582987;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[94] <= 0.5) {
                            if (fs[0] <= 5.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.230950003766;
                                    } else {
                                        return 0.0700172689174;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0946515638613;
                                    } else {
                                        return 0.0345977700637;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1418.0) {
                                    if (fs[81] <= 0.5) {
                                        return 0.0710137184656;
                                    } else {
                                        return -0.0228408790744;
                                    }
                                } else {
                                    if (fs[64] <= -997.5) {
                                        return 0.153257340657;
                                    } else {
                                        return -0.0216224103232;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[49] <= -2.5) {
                                        return 0.738851159219;
                                    } else {
                                        return 0.089956330359;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0440931607341;
                                    } else {
                                        return 0.00256524911004;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1077.0) {
                                    return 0.122660846226;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0343044668885;
                                    } else {
                                        return -0.0315629369505;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[47] <= 0.5) {
                    if (fs[33] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[53] <= -988.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.521925310638;
                                    } else {
                                        return 0.435819775876;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.152921178308;
                                    } else {
                                        return -0.0497778132924;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.089822248342;
                                    } else {
                                        return 0.1280965577;
                                    }
                                } else {
                                    return 0.32891505729;
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[53] <= -993.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.471486174022;
                                    } else {
                                        return 0.181445542896;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0534991790134;
                                    } else {
                                        return -0.00557432724716;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -988.0) {
                                        return 0.228913474355;
                                    } else {
                                        return -0.0409705825687;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.461082669821;
                                    } else {
                                        return 0.107712237369;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[53] <= -1138.5) {
                                if (fs[72] <= 9997.0) {
                                    if (fs[0] <= 0.5) {
                                        return 0.126432119373;
                                    } else {
                                        return -0.0370534124298;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.246831126209;
                                    } else {
                                        return -0.102405075455;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1093.5) {
                                    if (fs[0] <= 0.5) {
                                        return -0.241143058467;
                                    } else {
                                        return -0.069306023966;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return -0.145028725049;
                                    } else {
                                        return -0.0538787122526;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    return -0.162836316498;
                                } else {
                                    return 0.041114946132;
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.181554301467;
                                } else {
                                    return 0.274578230594;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[64] <= -996.5) {
                        if (fs[60] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 2.5) {
                                    return -0.0421776508748;
                                } else {
                                    return -0.039324666516;
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    return -0.0363178924924;
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return -0.032343885911;
                                    } else {
                                        return -0.0339425736119;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 18.5) {
                                if (fs[53] <= -976.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0197953386428;
                                    } else {
                                        return -0.0333908851265;
                                    }
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return -0.0370772702497;
                                    } else {
                                        return -0.0344642571943;
                                    }
                                }
                            } else {
                                return 0.173562684581;
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -976.0) {
                                        return -0.0145068939957;
                                    } else {
                                        return -0.0312887649992;
                                    }
                                } else {
                                    if (fs[53] <= 7.5) {
                                        return -0.0344486758957;
                                    } else {
                                        return 0.0176403337727;
                                    }
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0635366281877;
                                    } else {
                                        return -0.0310523718675;
                                    }
                                } else {
                                    if (fs[53] <= 17.5) {
                                        return -0.0298271823714;
                                    } else {
                                        return -0.0169929261118;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= 17.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0329213365749;
                                    } else {
                                        return -0.0316386590789;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0316818592034;
                                    } else {
                                        return -0.0205961462487;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0382882715782;
                                    } else {
                                        return -0.044925596744;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.032365969773;
                                    } else {
                                        return -0.0265119204567;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
