/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree22 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9988.5) {
            if (fs[31] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[78] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.196422046509;
                                    } else {
                                        return 0.306146290912;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.313770887777;
                                    } else {
                                        return 0.198017614914;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.070551616212;
                                } else {
                                    return 0.173079850432;
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.25763917879;
                                    } else {
                                        return 0.311059072733;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.113168613395;
                                    } else {
                                        return 0.253562018864;
                                    }
                                }
                            } else {
                                return -0.064506014882;
                            }
                        }
                    } else {
                        if (fs[85] <= 6.5) {
                            if (fs[102] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.199164436727;
                                    } else {
                                        return 0.026820926427;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.00368704945256;
                                    } else {
                                        return 0.0960914862655;
                                    }
                                }
                            } else {
                                if (fs[85] <= 1.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0896222460804;
                                    } else {
                                        return 0.111033366055;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0108560532978;
                                    } else {
                                        return 0.161802253765;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[53] <= -461.5) {
                                        return 0.259910364933;
                                    } else {
                                        return -0.0610782364844;
                                    }
                                } else {
                                    if (fs[53] <= -442.0) {
                                        return 0.0705138759706;
                                    } else {
                                        return -0.0881317372642;
                                    }
                                }
                            } else {
                                if (fs[70] <= -3.5) {
                                    if (fs[70] <= -4.5) {
                                        return 0.32704497303;
                                    } else {
                                        return 0.492813820785;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.344454476177;
                                    } else {
                                        return 0.236650526724;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[78] <= 0.5) {
                        if (fs[76] <= 25.0) {
                            if (fs[0] <= 2.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.0826868505493;
                                    } else {
                                        return -0.084307901878;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0264657422953;
                                    } else {
                                        return 0.049372625151;
                                    }
                                }
                            } else {
                                if (fs[30] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.00361812110177;
                                    } else {
                                        return 0.693595621836;
                                    }
                                } else {
                                    if (fs[53] <= -1053.0) {
                                        return -0.0369330219279;
                                    } else {
                                        return -0.0256780806693;
                                    }
                                }
                            }
                        } else {
                            if (fs[96] <= 0.5) {
                                if (fs[76] <= 125.0) {
                                    return -0.0417707841352;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0303581145964;
                                    } else {
                                        return -0.0202502047398;
                                    }
                                }
                            } else {
                                return 0.110298553052;
                            }
                        }
                    } else {
                        if (fs[87] <= 0.5) {
                            if (fs[72] <= 8423.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.00770083970344;
                                    } else {
                                        return 0.0155106779399;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.0145439280409;
                                    } else {
                                        return -0.017070182237;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0421925955412;
                                    } else {
                                        return 0.122036958905;
                                    }
                                } else {
                                    if (fs[53] <= -1428.0) {
                                        return 0.00771493850252;
                                    } else {
                                        return -0.01523066016;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.00976437577665;
                                    } else {
                                        return 0.106376071651;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.0088653944464;
                                    } else {
                                        return -0.0151973178797;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0302531074261;
                                    } else {
                                        return -0.000335968174844;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return 0.0878390481577;
                                    } else {
                                        return 0.0339489019209;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[47] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[53] <= -988.5) {
                                if (fs[58] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.275700273029;
                                    } else {
                                        return 0.29661174263;
                                    }
                                } else {
                                    if (fs[53] <= -1123.5) {
                                        return 0.197789248117;
                                    } else {
                                        return -0.113401894516;
                                    }
                                }
                            } else {
                                if (fs[64] <= -497.0) {
                                    return 0.283382549346;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0692343344161;
                                    } else {
                                        return 0.0145428919391;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.236789517271;
                                    } else {
                                        return 0.161900004045;
                                    }
                                } else {
                                    if (fs[53] <= -1098.0) {
                                        return 0.282964866735;
                                    } else {
                                        return 0.142984617124;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[53] <= -1128.0) {
                                        return 0.016823534704;
                                    } else {
                                        return 0.199394854464;
                                    }
                                } else {
                                    return 0.304132573285;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1118.0) {
                            if (fs[4] <= 8.5) {
                                if (fs[64] <= -997.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.249977205171;
                                    } else {
                                        return 0.146188300425;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.124434578643;
                                    } else {
                                        return 0.00940056076862;
                                    }
                                }
                            } else {
                                if (fs[100] <= 1.0) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0222611660306;
                                    } else {
                                        return 0.0203710418507;
                                    }
                                } else {
                                    if (fs[0] <= 20.5) {
                                        return 0.0434968353725;
                                    } else {
                                        return 0.270199296328;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[98] <= 1.5) {
                                    return 0.00302783112784;
                                } else {
                                    if (fs[53] <= -1068.0) {
                                        return 0.160785758567;
                                    } else {
                                        return -0.0478045143326;
                                    }
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0552478514888;
                                    } else {
                                        return -0.0141468053033;
                                    }
                                } else {
                                    if (fs[53] <= -988.0) {
                                        return 0.114367840143;
                                    } else {
                                        return -0.0318683751492;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        return 0.17938717831;
                    } else {
                        if (fs[62] <= -1.5) {
                            if (fs[53] <= -986.0) {
                                if (fs[12] <= 0.5) {
                                    return -0.0238131889871;
                                } else {
                                    return -0.0464276705964;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    return -0.0233732214302;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.020222513721;
                                    } else {
                                        return 0.0874687872181;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[53] <= -960.5) {
                                        return -0.00437099477306;
                                    } else {
                                        return -0.0169300921255;
                                    }
                                } else {
                                    if (fs[53] <= -1037.0) {
                                        return 0.0573623725409;
                                    } else {
                                        return -0.0174234276167;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[53] <= -986.0) {
                                        return -0.0231635244828;
                                    } else {
                                        return 0.0305803700077;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return -0.0207027848609;
                                    } else {
                                        return -0.00606762169071;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[53] <= -1047.0) {
                    if (fs[53] <= -1508.5) {
                        if (fs[70] <= -3.5) {
                            if (fs[53] <= -1978.0) {
                                return -0.0158532327529;
                            } else {
                                return 0.469729345289;
                            }
                        } else {
                            if (fs[98] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.443096839501;
                                    } else {
                                        return 0.333961962523;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.376504026649;
                                    } else {
                                        return 0.492372712837;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.392058565736;
                                    } else {
                                        return 0.0307485807036;
                                    }
                                } else {
                                    return 0.495208400129;
                                }
                            }
                        }
                    } else {
                        if (fs[98] <= 1.5) {
                            if (fs[4] <= 12.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[53] <= -1473.5) {
                                        return 0.259516468083;
                                    } else {
                                        return 0.328964084355;
                                    }
                                } else {
                                    return -0.266293045209;
                                }
                            } else {
                                if (fs[70] <= -3.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.190994772507;
                                    } else {
                                        return -0.171549796964;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.16707915039;
                                    } else {
                                        return -0.0945398035936;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 17.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.298595994636;
                                    } else {
                                        return 0.398175630537;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.209850021033;
                                    } else {
                                        return -0.194320309957;
                                    }
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[76] <= 150.0) {
                                        return 0.0774662300855;
                                    } else {
                                        return 0.265465139295;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.13754704351;
                                    } else {
                                        return -0.024601904096;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 6.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.212202716868;
                                    } else {
                                        return 0.35002906308;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.281921869531;
                                    } else {
                                        return -0.206170800784;
                                    }
                                }
                            } else {
                                if (fs[87] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.491700695463;
                                    } else {
                                        return 0.458682571936;
                                    }
                                } else {
                                    return 0.257411887925;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.154613949719;
                                    } else {
                                        return 0.0923264978091;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.296346136582;
                                    } else {
                                        return 0.141593865083;
                                    }
                                }
                            } else {
                                if (fs[87] <= 0.5) {
                                    if (fs[98] <= 1.5) {
                                        return 0.307090014414;
                                    } else {
                                        return 0.103184509012;
                                    }
                                } else {
                                    if (fs[62] <= -0.5) {
                                        return 0.444447887568;
                                    } else {
                                        return 0.093654917682;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[49] <= -0.5) {
                                if (fs[62] <= -1.5) {
                                    if (fs[98] <= 1.5) {
                                        return 0.467445492903;
                                    } else {
                                        return 0.442392538411;
                                    }
                                } else {
                                    if (fs[64] <= -997.5) {
                                        return 0.425261044918;
                                    } else {
                                        return 0.256130338131;
                                    }
                                }
                            } else {
                                if (fs[98] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.273920861126;
                                    } else {
                                        return 0.119594611512;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.263597644965;
                                    } else {
                                        return 0.0331765941831;
                                    }
                                }
                            }
                        } else {
                            if (fs[87] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.243890127493;
                                    } else {
                                        return -0.0153463877762;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.129093565228;
                                    } else {
                                        return 0.331086033215;
                                    }
                                }
                            } else {
                                if (fs[70] <= -4.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.0783078599288;
                                    } else {
                                        return 0.319794101263;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0433100866945;
                                    } else {
                                        return 0.213537964212;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[53] <= -1413.0) {
                        if (fs[33] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.0915482199639;
                                    } else {
                                        return 0.0110308281748;
                                    }
                                } else {
                                    if (fs[85] <= 5.5) {
                                        return 0.053977921849;
                                    } else {
                                        return 0.402642737156;
                                    }
                                }
                            } else {
                                if (fs[4] <= 24.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.121382731844;
                                    } else {
                                        return 0.19675575942;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.24305128772;
                                    } else {
                                        return -0.0211856061656;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[98] <= 0.5) {
                                    return -0.0898323940244;
                                } else {
                                    return 0.416853824006;
                                }
                            } else {
                                if (fs[100] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0871769058563;
                                    } else {
                                        return 0.0284179115808;
                                    }
                                } else {
                                    return 0.204821776943;
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= 0.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0635287029106;
                                    } else {
                                        return -0.0636875313581;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return 0.180955700435;
                                    } else {
                                        return 0.571723910579;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.299692100672;
                                    } else {
                                        return 0.028823830883;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.0165877659672;
                                    } else {
                                        return -0.0349279458101;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[4] <= 23.5) {
                                    if (fs[76] <= 250.0) {
                                        return -0.0456580517116;
                                    } else {
                                        return -0.0216832720001;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0233129759388;
                                    } else {
                                        return 0.0566776035011;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    return -0.0718410203376;
                                } else {
                                    return -0.0741448305044;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= 0.5) {
                        if (fs[53] <= -992.0) {
                            if (fs[98] <= 0.5) {
                                if (fs[0] <= 11.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.138283543036;
                                    } else {
                                        return 0.0332583130228;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.00755503632339;
                                    } else {
                                        return 0.14579579866;
                                    }
                                }
                            } else {
                                if (fs[76] <= 350.0) {
                                    if (fs[87] <= 0.5) {
                                        return 0.0158475890744;
                                    } else {
                                        return 0.0622458211584;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return -0.0772080825837;
                                    } else {
                                        return -0.115651111319;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.060760697055;
                                    } else {
                                        return 0.214339821179;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0502380792667;
                                    } else {
                                        return 0.0117727152256;
                                    }
                                }
                            } else {
                                if (fs[85] <= 7.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0653463786178;
                                    } else {
                                        return -0.0364993033121;
                                    }
                                } else {
                                    if (fs[0] <= 15.5) {
                                        return -0.0343658852881;
                                    } else {
                                        return 0.087272630746;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[96] <= 0.5) {
                            if (fs[76] <= 75.0) {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0365128759623;
                                    } else {
                                        return -0.0304221295957;
                                    }
                                } else {
                                    return -0.059688577534;
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return -0.022696368736;
                                    } else {
                                        return -0.00548914310319;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return -0.0305859271512;
                                    } else {
                                        return 0.106637758239;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 15.5) {
                                if (fs[53] <= -3.0) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0486854220537;
                                    } else {
                                        return -0.0218100815308;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.018556017368;
                                    } else {
                                        return -0.024524354536;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.0144620161762;
                                    } else {
                                        return -0.0184544158509;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0432435915498;
                                    } else {
                                        return -0.0132309968521;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
