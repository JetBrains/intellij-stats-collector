/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree57 {
    public double calcTree(double... fs) {
        if (fs[31] <= 0.5) {
            if (fs[72] <= 9994.5) {
                if (fs[78] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0128652094987;
                                    } else {
                                        return 0.0517226415591;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0593233880584;
                                    } else {
                                        return 0.0841786277728;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.192946120777;
                                    } else {
                                        return 0.192550704026;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.108430021953;
                                    } else {
                                        return 0.00291743998841;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                return -0.140812047404;
                            } else {
                                return -0.209691653038;
                            }
                        }
                    } else {
                        if (fs[4] <= 2.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[60] <= 0.5) {
                                    return 0.00617738542475;
                                } else {
                                    if (fs[53] <= -571.5) {
                                        return 0.139122886775;
                                    } else {
                                        return -0.163450699088;
                                    }
                                }
                            } else {
                                return -0.113037798977;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 60.0) {
                                        return 0.015431536625;
                                    } else {
                                        return 0.386232907536;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.023831442596;
                                    } else {
                                        return 0.00562537755979;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.0702937488238;
                                    } else {
                                        return 0.0126763189756;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0164158121905;
                                    } else {
                                        return -0.0043126525241;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[53] <= -1498.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[53] <= -1958.0) {
                                        return 0.00212695066779;
                                    } else {
                                        return 0.185543945154;
                                    }
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return -0.00574513096156;
                                    } else {
                                        return 0.192857216669;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -987.5) {
                                        return 0.0508995520721;
                                    } else {
                                        return -0.0152845855311;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0279950915889;
                                    } else {
                                        return 0.234623997751;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 27.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.061887013854;
                                    } else {
                                        return 0.0233583147299;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0762750553531;
                                    } else {
                                        return 0.142159993341;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[89] <= 0.5) {
                                        return 0.122059854797;
                                    } else {
                                        return -0.106557363388;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return -0.176013019265;
                                    } else {
                                        return 0.135442941388;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[55] <= 998.5) {
                            if (fs[0] <= 5.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.00358551236152;
                                    } else {
                                        return -0.00660501028188;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.000857706756496;
                                    } else {
                                        return 0.0110633447194;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[85] <= 6.5) {
                                        return -0.00164802224539;
                                    } else {
                                        return 0.0364757457791;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00329068951424;
                                    } else {
                                        return -0.00233675257331;
                                    }
                                }
                            }
                        } else {
                            return 0.34612851698;
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[100] <= 1.5) {
                        if (fs[98] <= 1.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0237156788154;
                                    } else {
                                        return 0.0662320867602;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.107846822061;
                                    } else {
                                        return 0.0150521180531;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[53] <= -1593.0) {
                                        return 0.130714427113;
                                    } else {
                                        return -0.0161031907823;
                                    }
                                } else {
                                    return -0.245457658274;
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -1468.0) {
                                        return -0.0799567384436;
                                    } else {
                                        return 0.013521366216;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.0811121896469;
                                    } else {
                                        return 0.0728751510366;
                                    }
                                }
                            } else {
                                if (fs[53] <= -977.0) {
                                    if (fs[4] <= 17.5) {
                                        return 0.0701404294597;
                                    } else {
                                        return -0.0118712876281;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return -0.00868862323855;
                                    } else {
                                        return -0.0959286272291;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 12.0) {
                            return -0.275945909318;
                        } else {
                            return -0.377741655279;
                        }
                    }
                } else {
                    if (fs[37] <= 0.5) {
                        if (fs[53] <= -1072.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.01392552765;
                                    } else {
                                        return 0.0310975395032;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.166899207331;
                                    } else {
                                        return -0.0227567291199;
                                    }
                                }
                            } else {
                                if (fs[4] <= 25.5) {
                                    if (fs[53] <= -1118.0) {
                                        return 0.0579160324825;
                                    } else {
                                        return 0.358061978456;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.0957461093298;
                                    } else {
                                        return 0.125012367319;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0561947042817;
                                    } else {
                                        return -0.0137310046222;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.299327308204;
                                    } else {
                                        return -0.00480009333499;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.0653821208858;
                                    } else {
                                        return -0.0289763294612;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0209668879992;
                                    } else {
                                        return -0.00563415248062;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 120.5) {
                                        return 0.0407328051694;
                                    } else {
                                        return 0.156597775517;
                                    }
                                } else {
                                    if (fs[0] <= 17.5) {
                                        return 0.361382674106;
                                    } else {
                                        return 0.0450305774439;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9996.5) {
                                    return 0.246593540024;
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.125627847996;
                                    } else {
                                        return -0.0939788456901;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0532350846427;
                                    } else {
                                        return -0.155307086898;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.224673186228;
                                    } else {
                                        return -0.132757289009;
                                    }
                                }
                            } else {
                                if (fs[0] <= 13.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.12842263875;
                                    } else {
                                        return -0.0119726596991;
                                    }
                                } else {
                                    if (fs[0] <= 24.0) {
                                        return 0.381621629309;
                                    } else {
                                        return 0.0565888624798;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[53] <= -1073.5) {
                if (fs[0] <= 1.5) {
                    if (fs[40] <= 0.5) {
                        if (fs[92] <= 0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[4] <= 1.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0534948548177;
                                    } else {
                                        return -0.0809303617586;
                                    }
                                } else {
                                    if (fs[53] <= -1128.5) {
                                        return 0.0496239522545;
                                    } else {
                                        return 0.099637512566;
                                    }
                                }
                            } else {
                                if (fs[64] <= -996.5) {
                                    if (fs[58] <= 0.5) {
                                        return 0.0784259971051;
                                    } else {
                                        return -0.0668562303691;
                                    }
                                } else {
                                    if (fs[100] <= 1.0) {
                                        return -0.0584055980519;
                                    } else {
                                        return 0.0286205719416;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.131167860425;
                                } else {
                                    return 0.113467708832;
                                }
                            } else {
                                return 0.362074562706;
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.111764059207;
                                    } else {
                                        return -0.110637178301;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.144958890227;
                                    } else {
                                        return 0.053498849805;
                                    }
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    return -0.00846513860204;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0700490776877;
                                    } else {
                                        return -0.143301016005;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.202327716859;
                                    } else {
                                        return -0.081895283627;
                                    }
                                } else {
                                    return 0.142467244941;
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return -0.286724858138;
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.00996895412092;
                                    } else {
                                        return 0.171274573778;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 46.5) {
                        if (fs[76] <= 250.0) {
                            if (fs[0] <= 2.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.089513708643;
                                    } else {
                                        return -0.0702872940339;
                                    }
                                } else {
                                    return 0.138355459646;
                                }
                            } else {
                                if (fs[96] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.00841861317179;
                                    } else {
                                        return 0.0196083094313;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0777813010453;
                                    } else {
                                        return -0.032365128117;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[53] <= -1137.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0560278408574;
                                    } else {
                                        return -0.0231094584721;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.00226279250956;
                                    } else {
                                        return 0.095777932851;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1137.5) {
                                    if (fs[62] <= -0.5) {
                                        return -0.0811625287449;
                                    } else {
                                        return 0.0949623029499;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.179361485949;
                                    } else {
                                        return 0.266341885511;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1138.0) {
                            return 0.133709222173;
                        } else {
                            return 0.337901600525;
                        }
                    }
                }
            } else {
                if (fs[2] <= 6.5) {
                    if (fs[72] <= 9895.5) {
                        if (fs[47] <= 0.5) {
                            if (fs[53] <= -988.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.128960834064;
                                    } else {
                                        return 0.0191338050544;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.074839030583;
                                    } else {
                                        return -0.0046745747209;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[53] <= -481.5) {
                                        return -0.12178330262;
                                    } else {
                                        return -0.0455948561008;
                                    }
                                } else {
                                    if (fs[53] <= -381.5) {
                                        return -0.0682677591982;
                                    } else {
                                        return -0.0141200085622;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -1.5) {
                                if (fs[64] <= -997.5) {
                                    if (fs[4] <= 11.5) {
                                        return -0.0181697339651;
                                    } else {
                                        return -0.0256949471733;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0705183852238;
                                    } else {
                                        return -0.021381147034;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0250734285151;
                                    } else {
                                        return -0.00702735978843;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0566795580184;
                                    } else {
                                        return -0.00395215446887;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.0920331501681;
                    }
                } else {
                    return 0.0956793257376;
                }
            }
        }
    }
}
