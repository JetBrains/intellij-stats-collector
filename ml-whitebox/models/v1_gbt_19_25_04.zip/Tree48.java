/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree48 {
    public double calcTree(double... fs) {
        if (fs[78] <= 0.5) {
            if (fs[98] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0779508041232;
                                    } else {
                                        return 0.0497855968164;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0576119462167;
                                    } else {
                                        return -0.151487282361;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.286432946725;
                                    } else {
                                        return 0.247429082376;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.144858888766;
                                    } else {
                                        return 0.104659251628;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1018.5) {
                                if (fs[53] <= -1128.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.104872106755;
                                    } else {
                                        return 0.0835187998341;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.102842391041;
                                    } else {
                                        return 0.141581023943;
                                    }
                                }
                            } else {
                                if (fs[15] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0393673277234;
                                    } else {
                                        return 0.109015200724;
                                    }
                                } else {
                                    return -0.14837955787;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 3.5) {
                            return 0.0469418508875;
                        } else {
                            return -0.222821438778;
                        }
                    }
                } else {
                    if (fs[52] <= 0.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0546832921942;
                                    } else {
                                        return 0.0119717861457;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0244578560343;
                                    } else {
                                        return 0.313961143101;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return -0.0268119957631;
                                    } else {
                                        return 0.107745428501;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0660063327336;
                                    } else {
                                        return 0.00709844561028;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.324383598025;
                                    } else {
                                        return 0.27612843609;
                                    }
                                } else {
                                    return 0.0593112929166;
                                }
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0362817451743;
                                    } else {
                                        return 0.0116605384063;
                                    }
                                } else {
                                    return 0.161431701208;
                                }
                            }
                        }
                    } else {
                        if (fs[34] <= 0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.181165994923;
                                    } else {
                                        return -0.122794933979;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.013412106795;
                                    } else {
                                        return 0.0670901872515;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1128.0) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0242268782071;
                                    } else {
                                        return -0.0343904442883;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.0129970659932;
                                    } else {
                                        return -0.0591220010598;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                return 0.149324473228;
                            } else {
                                return 0.289910777159;
                            }
                        }
                    }
                }
            } else {
                if (fs[62] <= -0.5) {
                    if (fs[47] <= 0.5) {
                        if (fs[53] <= -1142.5) {
                            if (fs[64] <= -997.5) {
                                return 0.0525171867168;
                            } else {
                                return 0.192081138402;
                            }
                        } else {
                            return 0.0854823779577;
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            return -0.0177764364794;
                        } else {
                            return 0.0480279772575;
                        }
                    }
                } else {
                    if (fs[82] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[53] <= -1143.5) {
                                return 0.204402088929;
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[96] <= 0.5) {
                                        return 0.159060447114;
                                    } else {
                                        return -7.49962672203e-06;
                                    }
                                } else {
                                    if (fs[4] <= 33.5) {
                                        return -0.153426001282;
                                    } else {
                                        return 0.0118049841118;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[53] <= -1048.0) {
                                    if (fs[76] <= 250.0) {
                                        return -0.0216845916686;
                                    } else {
                                        return -0.00545299751767;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0412659526255;
                                    } else {
                                        return -0.013696819277;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.078732352095;
                                    } else {
                                        return -0.00798972479112;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0124071369576;
                                    } else {
                                        return -0.00683252799521;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.186155493224;
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[53] <= -1498.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[53] <= -1938.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[53] <= -1998.5) {
                                        return 0.17100475371;
                                    } else {
                                        return -0.0405147562879;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.328575996968;
                                    } else {
                                        return 0.0391413649539;
                                    }
                                }
                            } else {
                                if (fs[53] <= -2023.5) {
                                    if (fs[53] <= -2388.0) {
                                        return 0.0217595601188;
                                    } else {
                                        return 0.336398692415;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0647138509012;
                                    } else {
                                        return 0.15478740767;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 15.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.205187994143;
                                    } else {
                                        return 0.28589484245;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.155264809665;
                                    } else {
                                        return 0.121389134358;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1598.0) {
                                    if (fs[72] <= 9991.5) {
                                        return -0.00751618466141;
                                    } else {
                                        return 0.251744179355;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.134290008523;
                                    } else {
                                        return 0.203293365057;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.0991326622634;
                                    } else {
                                        return -0.178966496601;
                                    }
                                } else {
                                    if (fs[31] <= 0.5) {
                                        return 0.164028868167;
                                    } else {
                                        return 0.079109074733;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1958.0) {
                                    return 0.163641310852;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.359814991099;
                                    } else {
                                        return 0.229522757478;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[4] <= 22.0) {
                                        return 0.191392239461;
                                    } else {
                                        return 0.283512001598;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.210815521751;
                                    } else {
                                        return -0.227631534487;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[85] <= 5.0) {
                                        return 0.269890010411;
                                    } else {
                                        return 0.20483809155;
                                    }
                                } else {
                                    if (fs[89] <= 0.5) {
                                        return 0.286422021647;
                                    } else {
                                        return 0.196269153352;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 75.0) {
                        if (fs[11] <= 0.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[89] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.125548876796;
                                    } else {
                                        return 0.0331675984624;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.082819352875;
                                    } else {
                                        return 0.0219108083829;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[53] <= -1118.5) {
                                        return -0.027182250122;
                                    } else {
                                        return 0.258889266783;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.105172149426;
                                    } else {
                                        return 0.181119909612;
                                    }
                                }
                            }
                        } else {
                            if (fs[102] <= 0.5) {
                                if (fs[89] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.137532715393;
                                    } else {
                                        return -0.0206453689904;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.016467424407;
                                    } else {
                                        return 0.176745985668;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[85] <= 2.5) {
                                        return -0.0489680706341;
                                    } else {
                                        return 0.113609376065;
                                    }
                                } else {
                                    if (fs[85] <= 3.5) {
                                        return -0.0805524974274;
                                    } else {
                                        return 0.0271356633063;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= -0.5) {
                            if (fs[102] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    return -0.5267968761;
                                } else {
                                    return -0.422652461334;
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    return -0.349385184437;
                                } else {
                                    return 0.114235366937;
                                }
                            }
                        } else {
                            if (fs[4] <= 15.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0766062573328;
                                    } else {
                                        return 0.0310523656598;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0871175523975;
                                    } else {
                                        return 0.162405850242;
                                    }
                                }
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0251991467069;
                                    } else {
                                        return 0.0546748254515;
                                    }
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return 0.133566657364;
                                    } else {
                                        return 0.0701800520991;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[76] <= 25.0) {
                    if (fs[18] <= 0.5) {
                        if (fs[55] <= 50.5) {
                            if (fs[55] <= -1.5) {
                                if (fs[72] <= 9579.5) {
                                    if (fs[53] <= -1118.0) {
                                        return 0.0787452699074;
                                    } else {
                                        return -0.0098678239073;
                                    }
                                } else {
                                    if (fs[53] <= -1057.0) {
                                        return 0.580708566013;
                                    } else {
                                        return 0.268608103382;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[72] <= 9978.5) {
                                        return -0.00503069262577;
                                    } else {
                                        return 0.00555127705099;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.264887594399;
                                    } else {
                                        return 0.0226129626468;
                                    }
                                }
                            }
                        } else {
                            return 0.4071697999;
                        }
                    } else {
                        if (fs[0] <= 4.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[96] <= 0.5) {
                                    if (fs[58] <= 0.5) {
                                        return 0.138380993403;
                                    } else {
                                        return -0.0571736794187;
                                    }
                                } else {
                                    return 0.522834381093;
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[98] <= 0.5) {
                                        return 0.00344089603188;
                                    } else {
                                        return 0.0165310367467;
                                    }
                                } else {
                                    if (fs[72] <= 9996.5) {
                                        return 0.0655048649823;
                                    } else {
                                        return 0.167601541945;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                if (fs[0] <= 5.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.117633082995;
                                    } else {
                                        return 0.0170749308819;
                                    }
                                } else {
                                    if (fs[0] <= 10.5) {
                                        return 0.0224699575425;
                                    } else {
                                        return -0.000820354172139;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.00546473014909;
                                    } else {
                                        return 0.0310418659602;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return -0.0020839711239;
                                    } else {
                                        return 0.0108320015811;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[53] <= -1284.0) {
                            if (fs[0] <= 4.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0199097009298;
                                    } else {
                                        return 0.32346376117;
                                    }
                                } else {
                                    if (fs[85] <= 7.5) {
                                        return 0.0810879226131;
                                    } else {
                                        return 0.192336229336;
                                    }
                                }
                            } else {
                                if (fs[0] <= 13.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0254455297349;
                                    } else {
                                        return 0.175977531592;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.0021531105319;
                                    } else {
                                        return 0.143270362682;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.0105788331631;
                                    } else {
                                        return -0.0090588683878;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.00414373794612;
                                    } else {
                                        return 0.0934960537602;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0845686258089;
                                    } else {
                                        return -0.0133975169779;
                                    }
                                } else {
                                    if (fs[53] <= -923.0) {
                                        return -0.0651540380029;
                                    } else {
                                        return -0.0166566542215;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[55] <= 0.5) {
                                if (fs[64] <= -993.5) {
                                    if (fs[53] <= -1083.0) {
                                        return 0.0902188553741;
                                    } else {
                                        return 0.000594447682004;
                                    }
                                } else {
                                    if (fs[85] <= 4.5) {
                                        return -0.00313077450226;
                                    } else {
                                        return -0.00754352590302;
                                    }
                                }
                            } else {
                                return 0.369274722817;
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.0789477524438;
                                    } else {
                                        return 0.349945775624;
                                    }
                                } else {
                                    if (fs[85] <= 5.5) {
                                        return 0.0355825675145;
                                    } else {
                                        return -0.0111237902062;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9539.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.013756248477;
                                    } else {
                                        return -0.00149123758558;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.0572996669107;
                                    } else {
                                        return 0.00109845434404;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
