/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree38 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9994.5) {
            if (fs[34] <= 0.5) {
                if (fs[76] <= 250.0) {
                    if (fs[0] <= 0.5) {
                        if (fs[60] <= 0.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.137104626284;
                                    } else {
                                        return 0.298596358219;
                                    }
                                } else {
                                    if (fs[85] <= 6.5) {
                                        return 0.0386101833499;
                                    } else {
                                        return 0.163113245843;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0541881927923;
                                    } else {
                                        return 0.0211138772902;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.112249856165;
                                    } else {
                                        return 0.283414526611;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[53] <= -1108.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.0897396276738;
                                    } else {
                                        return 0.14692831255;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0344022074651;
                                    } else {
                                        return 0.079071277863;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[96] <= 0.5) {
                                        return -0.0482787790375;
                                    } else {
                                        return 0.0866657117123;
                                    }
                                } else {
                                    if (fs[85] <= 2.5) {
                                        return 0.094167554309;
                                    } else {
                                        return 0.000648521384213;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[33] <= 0.5) {
                                    if (fs[55] <= -1.5) {
                                        return 0.0681343523744;
                                    } else {
                                        return -0.010458074521;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0356276718038;
                                    } else {
                                        return 0.00524503194845;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0518155344276;
                                    } else {
                                        return 0.000365526122161;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0286132152029;
                                    } else {
                                        return 0.114782735924;
                                    }
                                }
                            }
                        } else {
                            if (fs[102] <= 0.5) {
                                if (fs[0] <= 8.5) {
                                    if (fs[87] <= 0.5) {
                                        return -0.0020623925911;
                                    } else {
                                        return 0.012293735897;
                                    }
                                } else {
                                    if (fs[0] <= 19.5) {
                                        return -0.00601084493764;
                                    } else {
                                        return -0.00788548427922;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0032659088898;
                                    } else {
                                        return 0.0295170025501;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00830697359543;
                                    } else {
                                        return -0.00721508596234;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[82] <= 0.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.110590165885;
                                    } else {
                                        return -0.0295641987864;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.178909497029;
                                    } else {
                                        return -0.132633527859;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0727023900268;
                                    } else {
                                        return 0.243173178368;
                                    }
                                } else {
                                    return 0.0400542274823;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0881204295129;
                                    } else {
                                        return 0.0151246213397;
                                    }
                                } else {
                                    if (fs[53] <= -987.5) {
                                        return 0.1642460257;
                                    } else {
                                        return -0.0424579013572;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[51] <= 0.5) {
                                        return 0.139009401209;
                                    } else {
                                        return -0.149002444942;
                                    }
                                } else {
                                    if (fs[51] <= 0.5) {
                                        return 0.00359723141216;
                                    } else {
                                        return 0.284482430019;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[58] <= 0.5) {
                                        return 0.163082147614;
                                    } else {
                                        return -0.0638614427584;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.0290962268766;
                                    } else {
                                        return -0.070515233199;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[64] <= -995.5) {
                                        return 0.0700217186744;
                                    } else {
                                        return -0.00251984357155;
                                    }
                                } else {
                                    if (fs[4] <= 24.5) {
                                        return 0.0744151545271;
                                    } else {
                                        return 0.315309299215;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1077.0) {
                                return 0.163560220069;
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return -0.0123435862623;
                                    } else {
                                        return -0.00908996017323;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0114706108987;
                                    } else {
                                        return -0.0196307716754;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[83] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[15] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.152366763532;
                                    } else {
                                        return 0.128103730517;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.114200807173;
                                    } else {
                                        return 0.144826007361;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1118.5) {
                                        return 0.182782940204;
                                    } else {
                                        return 0.0825819114048;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.149400406933;
                                    } else {
                                        return 0.138657266141;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return -0.100885999677;
                            } else {
                                return 0.151745864367;
                            }
                        }
                    } else {
                        if (fs[53] <= -1138.0) {
                            if (fs[52] <= 0.5) {
                                return 0.169603247019;
                            } else {
                                return 0.278833326106;
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                return 0.414327755954;
                            } else {
                                return 0.440087775463;
                            }
                        }
                    }
                } else {
                    return 0.327063715457;
                }
            }
        } else {
            if (fs[53] <= -1062.5) {
                if (fs[0] <= 0.5) {
                    if (fs[53] <= -1493.5) {
                        if (fs[72] <= 9998.5) {
                            if (fs[53] <= -2018.0) {
                                return 0.289634485905;
                            } else {
                                if (fs[53] <= -1958.0) {
                                    if (fs[72] <= 9996.5) {
                                        return 0.0210002761913;
                                    } else {
                                        return -0.234347554496;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.270403235605;
                                    } else {
                                        return 0.0767845585323;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 24.5) {
                                if (fs[4] <= 23.5) {
                                    if (fs[53] <= -2423.0) {
                                        return 0.103967929045;
                                    } else {
                                        return 0.244753743514;
                                    }
                                } else {
                                    return -0.0552775213833;
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.243136414708;
                                    } else {
                                        return 0.326085374405;
                                    }
                                } else {
                                    return 0.378192334708;
                                }
                            }
                        }
                    } else {
                        if (fs[90] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[53] <= -1473.5) {
                                        return 0.12729909454;
                                    } else {
                                        return 0.185427617905;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.112084932833;
                                    } else {
                                        return -0.116236094528;
                                    }
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.00506035066435;
                                    } else {
                                        return 0.145541358464;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.00318812379803;
                                    } else {
                                        return -0.160625739899;
                                    }
                                }
                            }
                        } else {
                            return -0.46528967306;
                        }
                    }
                } else {
                    if (fs[81] <= 0.5) {
                        if (fs[72] <= 9997.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[0] <= 7.5) {
                                        return 0.0707267658863;
                                    } else {
                                        return -0.0354700574677;
                                    }
                                } else {
                                    return 0.390248460671;
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return -0.0256747943767;
                                    } else {
                                        return 0.238065355726;
                                    }
                                } else {
                                    if (fs[72] <= 9996.5) {
                                        return 0.106082536155;
                                    } else {
                                        return -0.0347240670613;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 14.5) {
                                if (fs[53] <= -1468.0) {
                                    if (fs[66] <= 5.0) {
                                        return 0.0739701979328;
                                    } else {
                                        return -0.165471568842;
                                    }
                                } else {
                                    if (fs[4] <= 26.0) {
                                        return 0.178215227522;
                                    } else {
                                        return -0.0391781324704;
                                    }
                                }
                            } else {
                                if (fs[80] <= 0.5) {
                                    if (fs[98] <= 1.5) {
                                        return -0.0311388984242;
                                    } else {
                                        return 0.0885254404735;
                                    }
                                } else {
                                    return -0.160758042438;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 13.5) {
                            if (fs[53] <= -1118.0) {
                                if (fs[100] <= 1.5) {
                                    if (fs[72] <= 9997.5) {
                                        return 0.0812256958917;
                                    } else {
                                        return 0.0284784114346;
                                    }
                                } else {
                                    return -0.145534103029;
                                }
                            } else {
                                return 0.324406328639;
                            }
                        } else {
                            if (fs[70] <= -3.5) {
                                if (fs[4] <= 29.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.197070574118;
                                    } else {
                                        return -0.122407793258;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.0156151808974;
                                    } else {
                                        return -0.146425507771;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[96] <= 0.5) {
                                        return -0.168806533494;
                                    } else {
                                        return -0.0517807706475;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return 0.0661443123591;
                                    } else {
                                        return -0.00626602896131;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[11] <= 0.5) {
                    if (fs[76] <= 75.0) {
                        if (fs[0] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.112374547435;
                                    } else {
                                        return 0.214624468304;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.228898688013;
                                    } else {
                                        return 0.0859389285957;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.144106352868;
                                    } else {
                                        return -0.312543967673;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.108931136803;
                                    } else {
                                        return -0.0985329952944;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -1.5) {
                                if (fs[72] <= 9997.5) {
                                    return 0.469671616613;
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0144295090291;
                                    } else {
                                        return 0.0891017112642;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.0781004182026;
                                    } else {
                                        return -0.0213244141956;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0236197102541;
                                    } else {
                                        return -0.0313593273209;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[37] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[72] <= 9998.5) {
                                    return -0.0996946327947;
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.228480915865;
                                    } else {
                                        return 0.0578484977363;
                                    }
                                }
                            } else {
                                if (fs[49] <= -0.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.224933975107;
                                    } else {
                                        return -0.0237645690205;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.00112438702489;
                                    } else {
                                        return -0.0563758577377;
                                    }
                                }
                            }
                        } else {
                            return 0.307141478448;
                        }
                    }
                } else {
                    if (fs[70] <= -3.5) {
                        if (fs[4] <= 3.5) {
                            if (fs[102] <= 0.5) {
                                return 0.175575617122;
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.405023787805;
                                } else {
                                    return 0.2460582753;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[85] <= 7.5) {
                                    if (fs[98] <= 0.5) {
                                        return 0.149209124442;
                                    } else {
                                        return 0.222116311995;
                                    }
                                } else {
                                    return -0.14120041872;
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[72] <= 9997.5) {
                                        return -0.0222436112167;
                                    } else {
                                        return 0.0556053708945;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0462630632092;
                                    } else {
                                        return -0.104898399479;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[37] <= 0.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[98] <= 0.5) {
                                        return 0.091140651445;
                                    } else {
                                        return -0.0852216749636;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0558896904446;
                                    } else {
                                        return -0.00370423546494;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.157982177728;
                                    } else {
                                        return -0.092212167045;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.00832877262105;
                                    } else {
                                        return -0.0160510908159;
                                    }
                                }
                            }
                        } else {
                            if (fs[87] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.126194733952;
                                    } else {
                                        return -0.00146759888653;
                                    }
                                } else {
                                    if (fs[53] <= -436.0) {
                                        return -0.0597339881669;
                                    } else {
                                        return 0.171272582357;
                                    }
                                }
                            } else {
                                return -0.062881218921;
                            }
                        }
                    }
                }
            }
        }
    }
}
