/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree65 {
    public double calcTree(double... fs) {
        if (fs[78] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[53] <= -1138.5) {
                    if (fs[4] <= 18.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[96] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[31] <= 0.5) {
                                        return 0.0100687452217;
                                    } else {
                                        return 0.157253458377;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.039178565617;
                                    } else {
                                        return 0.0332900262045;
                                    }
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    return 0.0769600706465;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0293663271203;
                                    } else {
                                        return -0.0573279091544;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                return -0.287390324006;
                            } else {
                                return 0.000764759437291;
                            }
                        }
                    } else {
                        return -0.252582853219;
                    }
                } else {
                    if (fs[30] <= 0.5) {
                        if (fs[33] <= 0.5) {
                            if (fs[53] <= -1058.5) {
                                if (fs[53] <= -1128.5) {
                                    if (fs[94] <= 0.5) {
                                        return 0.0307390417241;
                                    } else {
                                        return -0.0171586620527;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0597065765795;
                                    } else {
                                        return 0.035542426227;
                                    }
                                }
                            } else {
                                return -0.297538118892;
                            }
                        } else {
                            if (fs[76] <= 100.0) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0432215646077;
                                    } else {
                                        return 0.0661230116554;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0391295804415;
                                    } else {
                                        return 0.0675918539601;
                                    }
                                }
                            } else {
                                return 0.216112135183;
                            }
                        }
                    } else {
                        return -0.180017182774;
                    }
                }
            } else {
                if (fs[34] <= 0.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.181078683898;
                                    } else {
                                        return -0.0418333300549;
                                    }
                                } else {
                                    return 0.118238072866;
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 61.0) {
                                        return 0.00498373429978;
                                    } else {
                                        return 0.217114250294;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0352857283654;
                                    } else {
                                        return 0.0451331514291;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[31] <= 0.5) {
                                        return 0.109900024557;
                                    } else {
                                        return 7.15313509852e-05;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return -0.0387671073905;
                                    } else {
                                        return 0.0111277628804;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.0146597985147;
                                    } else {
                                        return -0.00406549301197;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0178440646391;
                                    } else {
                                        return 0.266818452613;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 3.5) {
                            if (fs[0] <= 2.5) {
                                return -0.0617561917463;
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 16.0) {
                                        return -0.0176569886097;
                                    } else {
                                        return -0.001494324508;
                                    }
                                } else {
                                    return -0.00518631704233;
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[53] <= -561.5) {
                                        return -0.0470910776837;
                                    } else {
                                        return -0.0360391124118;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0725397340144;
                                    } else {
                                        return -0.0408648784857;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -561.5) {
                                        return -0.00984057519756;
                                    } else {
                                        return 0.0008223627941;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.0417113359491;
                                    } else {
                                        return -0.0123797940198;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -1138.0) {
                            if (fs[4] <= 4.5) {
                                return 0.277888458196;
                            } else {
                                return -0.0599380316259;
                            }
                        } else {
                            return 0.148081690516;
                        }
                    } else {
                        return 0.215177183893;
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[53] <= -1498.5) {
                    if (fs[72] <= 9432.0) {
                        if (fs[76] <= 25.0) {
                            if (fs[53] <= -1928.5) {
                                if (fs[53] <= -2023.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.127559987895;
                                    } else {
                                        return -0.230442468939;
                                    }
                                } else {
                                    if (fs[85] <= 1.5) {
                                        return -0.105781596668;
                                    } else {
                                        return 0.126687559885;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1918.0) {
                                    return 0.407373392103;
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.130404290071;
                                    } else {
                                        return 0.00476038733371;
                                    }
                                }
                            }
                        } else {
                            if (fs[96] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[76] <= 300.0) {
                                        return 0.222325340489;
                                    } else {
                                        return 0.114491851228;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.0233352532278;
                                    } else {
                                        return 0.23204127054;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return -0.0547661212841;
                                    } else {
                                        return 0.0674837727279;
                                    }
                                } else {
                                    if (fs[53] <= -1958.0) {
                                        return 0.0640758088833;
                                    } else {
                                        return 0.137493589201;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9995.5) {
                            if (fs[42] <= 0.5) {
                                if (fs[4] <= 15.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.289063482076;
                                    } else {
                                        return 0.197580441628;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.0917586362962;
                                    } else {
                                        return 0.241379750529;
                                    }
                                }
                            } else {
                                return -0.104618805868;
                            }
                        } else {
                            if (fs[70] <= -3.5) {
                                if (fs[53] <= -2078.0) {
                                    return -0.352879241331;
                                } else {
                                    if (fs[53] <= -1978.0) {
                                        return -0.0751140092006;
                                    } else {
                                        return 0.177257038293;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9998.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0901760056336;
                                    } else {
                                        return -0.0292882665316;
                                    }
                                } else {
                                    if (fs[53] <= -2328.0) {
                                        return 0.083271732259;
                                    } else {
                                        return 0.147971119221;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[90] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[49] <= -1.5) {
                                if (fs[98] <= 1.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.215629086505;
                                    } else {
                                        return 0.156885388451;
                                    }
                                } else {
                                    if (fs[58] <= 0.5) {
                                        return 0.0979283240288;
                                    } else {
                                        return -0.0970748113167;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.0498370853756;
                                    } else {
                                        return -0.0129602744866;
                                    }
                                } else {
                                    if (fs[64] <= -997.5) {
                                        return 0.107066126339;
                                    } else {
                                        return 0.00953043726551;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[72] <= 9768.0) {
                                    if (fs[85] <= 3.5) {
                                        return -0.0327613329268;
                                    } else {
                                        return 0.0438342758535;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return 0.00967399213603;
                                    } else {
                                        return 0.116545901396;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0221597854267;
                                    } else {
                                        return 0.0577021946191;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0364246223565;
                                    } else {
                                        return 0.0239204899133;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9978.0) {
                            if (fs[85] <= 0.5) {
                                if (fs[96] <= 0.5) {
                                    if (fs[72] <= 7455.5) {
                                        return -0.153478774002;
                                    } else {
                                        return -0.213701211586;
                                    }
                                } else {
                                    return -0.301496389819;
                                }
                            } else {
                                if (fs[4] <= 14.0) {
                                    return -0.251394061296;
                                } else {
                                    return 0.141880432927;
                                }
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                return -0.411841976087;
                            } else {
                                return -0.307815479413;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[53] <= -1098.5) {
                        if (fs[85] <= 6.5) {
                            if (fs[102] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[55] <= 500.0) {
                                        return 0.0112353676675;
                                    } else {
                                        return 0.353889032494;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return 0.0218635458806;
                                    } else {
                                        return 0.0817977963337;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[40] <= 0.5) {
                                        return -0.0160919963564;
                                    } else {
                                        return 0.0117192281101;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0384894791259;
                                    } else {
                                        return 0.203317253928;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[85] <= 7.5) {
                                        return 0.0377867390791;
                                    } else {
                                        return -0.037912753453;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.327603998859;
                                    } else {
                                        return 0.0405162615113;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[25] <= 0.5) {
                                        return -0.0458766470368;
                                    } else {
                                        return 0.133419975564;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0415270352408;
                                    } else {
                                        return 0.051912607527;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0223111188325;
                                    } else {
                                        return 0.0429333102796;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.0113086268073;
                                    } else {
                                        return 0.0647668920666;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.0382971649153;
                                    } else {
                                        return -0.101278179321;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.0259568863117;
                                    } else {
                                        return -0.0769532750748;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return -0.000165324805934;
                                    } else {
                                        return 0.0474922404771;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0497124563268;
                                    } else {
                                        return 0.138705130644;
                                    }
                                }
                            } else {
                                if (fs[85] <= 1.5) {
                                    if (fs[94] <= 0.5) {
                                        return 0.0734897289192;
                                    } else {
                                        return -0.0260549838079;
                                    }
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return -0.0258391194389;
                                    } else {
                                        return 0.0506519927354;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[57] <= 0.5) {
                        if (fs[0] <= 8.5) {
                            if (fs[47] <= 0.5) {
                                if (fs[102] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.00245390564782;
                                    } else {
                                        return 0.0371873814092;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00302889446808;
                                    } else {
                                        return 0.00384736072918;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 38.5) {
                                        return -0.0101654152631;
                                    } else {
                                        return 0.0180034311176;
                                    }
                                } else {
                                    if (fs[85] <= 7.5) {
                                        return -0.00478054794756;
                                    } else {
                                        return -0.0170672025804;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[76] <= 150.0) {
                                    if (fs[2] <= 17.5) {
                                        return -0.001983099618;
                                    } else {
                                        return 0.0603405369824;
                                    }
                                } else {
                                    if (fs[31] <= 0.5) {
                                        return -0.00434310596224;
                                    } else {
                                        return 0.00440971701233;
                                    }
                                }
                            } else {
                                return 0.161037288788;
                            }
                        }
                    } else {
                        if (fs[47] <= 0.5) {
                            if (fs[85] <= 1.0) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.00799438198307;
                                    } else {
                                        return 0.306754033066;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.00727428231478;
                                    } else {
                                        return 0.495431815403;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return 0.037769891745;
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.101418455776;
                                    } else {
                                        return -0.0613730363686;
                                    }
                                }
                            }
                        } else {
                            if (fs[87] <= 0.5) {
                                return -0.0606429535133;
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.0233751325665;
                                    } else {
                                        return -0.00540278805595;
                                    }
                                } else {
                                    return -0.0311760029396;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
