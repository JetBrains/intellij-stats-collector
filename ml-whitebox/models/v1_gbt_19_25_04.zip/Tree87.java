/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree87 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[53] <= -1498.5) {
                if (fs[53] <= -1953.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[53] <= -2048.0) {
                            if (fs[11] <= 0.5) {
                                if (fs[53] <= -3408.0) {
                                    if (fs[98] <= 0.5) {
                                        return 0.135398407714;
                                    } else {
                                        return 0.219724499684;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0573504801359;
                                    } else {
                                        return -0.325253063189;
                                    }
                                }
                            } else {
                                if (fs[53] <= -2418.0) {
                                    if (fs[53] <= -2463.5) {
                                        return 0.0794676082793;
                                    } else {
                                        return -0.0570787894458;
                                    }
                                } else {
                                    if (fs[100] <= 0.5) {
                                        return 0.205655028101;
                                    } else {
                                        return -0.12292139106;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0216155010255;
                                    } else {
                                        return 0.149598577688;
                                    }
                                } else {
                                    if (fs[72] <= 4681.0) {
                                        return -0.0962148608421;
                                    } else {
                                        return 0.0793581206074;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    return 0.239147339136;
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.403007530307;
                                    } else {
                                        return -0.158263147647;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[100] <= 0.5) {
                                if (fs[53] <= -2048.0) {
                                    if (fs[4] <= 19.0) {
                                        return 0.27026240841;
                                    } else {
                                        return 0.0957280524157;
                                    }
                                } else {
                                    return 0.312446702082;
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    return 0.0583098680536;
                                } else {
                                    return 0.170668367587;
                                }
                            }
                        } else {
                            if (fs[70] <= -3.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[4] <= 17.0) {
                                        return -0.082574349092;
                                    } else {
                                        return -0.347933222428;
                                    }
                                } else {
                                    return 0.124597371903;
                                }
                            } else {
                                if (fs[76] <= 125.0) {
                                    if (fs[96] <= 0.5) {
                                        return 0.284227976075;
                                    } else {
                                        return 0.193165908169;
                                    }
                                } else {
                                    if (fs[64] <= -997.5) {
                                        return -0.196282957605;
                                    } else {
                                        return 0.016789835469;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 4.5) {
                        if (fs[87] <= 0.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[72] <= 9990.5) {
                                        return 0.158645543995;
                                    } else {
                                        return 0.0697448020031;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0178825280849;
                                    } else {
                                        return 0.015610371456;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0440533164182;
                                    } else {
                                        return 0.0444161609453;
                                    }
                                } else {
                                    if (fs[53] <= -1849.0) {
                                        return 0.0558464763401;
                                    } else {
                                        return 0.248047841461;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1928.0) {
                                if (fs[4] <= 15.0) {
                                    if (fs[76] <= 75.0) {
                                        return -0.00209773034481;
                                    } else {
                                        return 0.135909417542;
                                    }
                                } else {
                                    return -0.22920399586;
                                }
                            } else {
                                if (fs[53] <= -1878.5) {
                                    if (fs[4] <= 25.0) {
                                        return 0.113746759778;
                                    } else {
                                        return 0.226059717368;
                                    }
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return 0.0400358223454;
                                    } else {
                                        return -0.125600891058;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1618.0) {
                            if (fs[96] <= 0.5) {
                                if (fs[53] <= -1948.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.204709880865;
                                    } else {
                                        return 0.129795590704;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.0782418927992;
                                    } else {
                                        return 0.142523666146;
                                    }
                                }
                            } else {
                                if (fs[2] <= 7.5) {
                                    if (fs[87] <= 0.5) {
                                        return -0.0607299184537;
                                    } else {
                                        return 0.145088655702;
                                    }
                                } else {
                                    return -0.260226357549;
                                }
                            }
                        } else {
                            if (fs[6] <= 0.5) {
                                return 0.0771382428995;
                            } else {
                                if (fs[102] <= 0.5) {
                                    if (fs[87] <= 0.5) {
                                        return -0.000928484392744;
                                    } else {
                                        return -0.0998491387293;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0267037986964;
                                    } else {
                                        return -0.211057885804;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 1.5) {
                    if (fs[64] <= -996.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[53] <= -1143.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[64] <= -998.5) {
                                        return -0.080090742181;
                                    } else {
                                        return 0.0957564598929;
                                    }
                                } else {
                                    return -0.261545101268;
                                }
                            } else {
                                if (fs[64] <= -997.5) {
                                    if (fs[31] <= 0.5) {
                                        return 0.0602202938219;
                                    } else {
                                        return 0.0327071031449;
                                    }
                                } else {
                                    if (fs[53] <= -490.5) {
                                        return -0.0220123841056;
                                    } else {
                                        return -0.207309132126;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -4.0) {
                                if (fs[72] <= 4999.5) {
                                    if (fs[98] <= 1.5) {
                                        return -0.0057598373644;
                                    } else {
                                        return -0.10487280539;
                                    }
                                } else {
                                    return 0.0507930730498;
                                }
                            } else {
                                if (fs[49] <= -1.5) {
                                    if (fs[96] <= 0.5) {
                                        return 0.218629033722;
                                    } else {
                                        return 0.0931806551844;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0743460746623;
                                    } else {
                                        return 0.114951521095;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[55] <= 0.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[102] <= 0.5) {
                                    if (fs[58] <= 0.5) {
                                        return -0.00390285573385;
                                    } else {
                                        return -0.312357461839;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.0846354951702;
                                    } else {
                                        return -0.0170584650251;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.0441146384111;
                                    } else {
                                        return 0.0374837754243;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0443472460429;
                                    } else {
                                        return 0.0977260444419;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                return 0.115145987614;
                            } else {
                                if (fs[53] <= -471.5) {
                                    if (fs[55] <= 993.5) {
                                        return 0.0990629169439;
                                    } else {
                                        return 0.260960709489;
                                    }
                                } else {
                                    if (fs[72] <= 9931.5) {
                                        return 0.329237126254;
                                    } else {
                                        return 0.237743845504;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[40] <= 0.5) {
                        if (fs[37] <= 0.5) {
                            if (fs[2] <= 7.5) {
                                if (fs[85] <= 6.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.0123160932378;
                                    } else {
                                        return -0.0231632795147;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0481378616843;
                                    } else {
                                        return 0.0245801220951;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0624600699996;
                                    } else {
                                        return -0.255234564528;
                                    }
                                } else {
                                    if (fs[53] <= -1288.0) {
                                        return -0.0913581181353;
                                    } else {
                                        return 0.0315651569325;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9756.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.128589537139;
                                    } else {
                                        return -0.0112605761048;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.0836622178441;
                                    } else {
                                        return 0.184237186129;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9994.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.0975981568572;
                                    } else {
                                        return 0.216009087737;
                                    }
                                } else {
                                    if (fs[85] <= 4.0) {
                                        return 0.0438272381526;
                                    } else {
                                        return -0.0514698904392;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[58] <= 0.5) {
                            if (fs[68] <= 1.5) {
                                if (fs[103] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return -0.143918305977;
                                    } else {
                                        return -0.014419991957;
                                    }
                                } else {
                                    return 0.151903915953;
                                }
                            } else {
                                if (fs[102] <= 0.5) {
                                    if (fs[72] <= 8819.0) {
                                        return -0.177098789936;
                                    } else {
                                        return -0.359291016953;
                                    }
                                } else {
                                    return 0.0224388186854;
                                }
                            }
                        } else {
                            return -0.206458876447;
                        }
                    }
                }
            }
        } else {
            if (fs[55] <= 998.5) {
                if (fs[14] <= 0.5) {
                    if (fs[47] <= 0.5) {
                        if (fs[55] <= -1.5) {
                            if (fs[4] <= 13.5) {
                                if (fs[72] <= 9550.0) {
                                    if (fs[53] <= -1118.0) {
                                        return 0.125673788644;
                                    } else {
                                        return 0.036096284537;
                                    }
                                } else {
                                    return 0.418255388138;
                                }
                            } else {
                                if (fs[53] <= -541.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0554086700291;
                                    } else {
                                        return -0.032850421441;
                                    }
                                } else {
                                    return -0.0056775706529;
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.000179051659417;
                                    } else {
                                        return 0.00618229322812;
                                    }
                                } else {
                                    if (fs[2] <= 10.5) {
                                        return -0.00113848364123;
                                    } else {
                                        return 0.0127736192024;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.107910703725;
                                    } else {
                                        return 0.0867297513691;
                                    }
                                } else {
                                    if (fs[85] <= 1.0) {
                                        return 0.175630135281;
                                    } else {
                                        return -0.0271697401982;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[68] <= 1.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[72] <= 4383.0) {
                                        return -0.0117377228253;
                                    } else {
                                        return -0.0280839514803;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return -0.00958824225908;
                                    } else {
                                        return -0.00257685726901;
                                    }
                                }
                            } else {
                                if (fs[53] <= -986.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.179862990229;
                                    } else {
                                        return 0.105709996746;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0700699199954;
                                    } else {
                                        return 0.00301598752558;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                if (fs[0] <= 6.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.00440972921781;
                                    } else {
                                        return -0.0119990284066;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.00304093568204;
                                    } else {
                                        return -0.00147314760177;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.00413884766001;
                                    } else {
                                        return -0.00154725067983;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.000963421353311;
                                    } else {
                                        return -2.2810394161e-05;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 4.5) {
                        if (fs[25] <= 0.5) {
                            if (fs[4] <= 24.5) {
                                if (fs[47] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.0594522526668;
                                    } else {
                                        return -0.0460779891535;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return -0.0211434024314;
                                    } else {
                                        return 0.023173165483;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 32.5) {
                                        return 0.0296888359721;
                                    } else {
                                        return -0.10271346819;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0308016338205;
                                    } else {
                                        return 0.111195346006;
                                    }
                                }
                            }
                        } else {
                            return -0.188651344193;
                        }
                    } else {
                        if (fs[0] <= 112.5) {
                            if (fs[82] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.00716071566254;
                                    } else {
                                        return -0.00703514716423;
                                    }
                                } else {
                                    return 0.295305298361;
                                }
                            } else {
                                if (fs[96] <= 0.5) {
                                    if (fs[72] <= 9995.5) {
                                        return -0.00347983572138;
                                    } else {
                                        return 0.0795934776423;
                                    }
                                } else {
                                    return 0.0166956770435;
                                }
                            }
                        } else {
                            return 0.152379889031;
                        }
                    }
                }
            } else {
                return 0.170356472024;
            }
        }
    }
}
