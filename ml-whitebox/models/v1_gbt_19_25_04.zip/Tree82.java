/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree82 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9999.5) {
            if (fs[57] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[53] <= -1498.5) {
                        if (fs[4] <= 14.5) {
                            if (fs[53] <= -1953.5) {
                                if (fs[98] <= 1.5) {
                                    if (fs[72] <= 9594.0) {
                                        return -0.0270448670248;
                                    } else {
                                        return 0.172439720724;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.138916427702;
                                    } else {
                                        return 0.0039873034055;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.107667427519;
                                    } else {
                                        return 0.224640527602;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.00657807708351;
                                    } else {
                                        return 0.166773999658;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -2003.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -4563.5) {
                                        return 0.249941035253;
                                    } else {
                                        return -0.0315709380617;
                                    }
                                } else {
                                    if (fs[100] <= 0.5) {
                                        return 0.149951215979;
                                    } else {
                                        return -0.0146565970945;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1928.0) {
                                    if (fs[91] <= 0.5) {
                                        return -0.0815019973962;
                                    } else {
                                        return 0.210364729688;
                                    }
                                } else {
                                    if (fs[4] <= 35.5) {
                                        return 0.0509337947478;
                                    } else {
                                        return -0.207654925135;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[23] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -21.0) {
                                    if (fs[82] <= 0.5) {
                                        return 0.00492822132517;
                                    } else {
                                        return -0.0141104644986;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return -0.0793156940941;
                                    } else {
                                        return -0.0105295384164;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1463.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.0201329166285;
                                    } else {
                                        return 0.0170935233666;
                                    }
                                } else {
                                    if (fs[72] <= 5278.5) {
                                        return 0.0157908977669;
                                    } else {
                                        return 0.0426764059533;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.182290699726;
                                    } else {
                                        return 0.136781880739;
                                    }
                                } else {
                                    if (fs[72] <= 9984.5) {
                                        return 0.221315333398;
                                    } else {
                                        return 0.096979513448;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    return 0.178710736971;
                                } else {
                                    return 0.272267018754;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[51] <= 0.5) {
                                if (fs[72] <= 9939.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.00715702674542;
                                    } else {
                                        return -0.00159267145069;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0190288279262;
                                    } else {
                                        return 0.0057197049351;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0926762094155;
                                    } else {
                                        return 0.00799868554061;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return 0.0212700272353;
                                    } else {
                                        return -0.00405869048056;
                                    }
                                }
                            }
                        } else {
                            if (fs[34] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[85] <= 6.5) {
                                        return 0.00206407433386;
                                    } else {
                                        return 0.0501080206249;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.000875716425552;
                                    } else {
                                        return 0.00297303320696;
                                    }
                                }
                            } else {
                                return 0.123785922657;
                            }
                        }
                    } else {
                        if (fs[72] <= 9510.0) {
                            if (fs[76] <= 25.0) {
                                if (fs[25] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0101926971534;
                                    } else {
                                        return 0.0029201856558;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.00150636312112;
                                    } else {
                                        return 0.0211985698828;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1438.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.00480185821335;
                                    } else {
                                        return 0.084303621703;
                                    }
                                } else {
                                    if (fs[58] <= 0.5) {
                                        return -0.00173407177485;
                                    } else {
                                        return -0.0266891254319;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9996.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[53] <= -1428.0) {
                                        return 0.0383595047959;
                                    } else {
                                        return 0.0108682420216;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.00833103649136;
                                    } else {
                                        return 0.0187401321145;
                                    }
                                }
                            } else {
                                if (fs[96] <= 0.5) {
                                    if (fs[53] <= -1523.0) {
                                        return -0.145376171424;
                                    } else {
                                        return 0.0133372130319;
                                    }
                                } else {
                                    if (fs[64] <= -992.5) {
                                        return 0.249605529962;
                                    } else {
                                        return -0.032194101747;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[100] <= 1.5) {
                        if (fs[85] <= 3.0) {
                            if (fs[62] <= -0.5) {
                                if (fs[76] <= 100.0) {
                                    if (fs[98] <= 1.5) {
                                        return -0.0320164856707;
                                    } else {
                                        return 0.101065739114;
                                    }
                                } else {
                                    if (fs[53] <= -1113.0) {
                                        return 0.145714813527;
                                    } else {
                                        return 0.117157796739;
                                    }
                                }
                            } else {
                                if (fs[98] <= 1.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.311859012341;
                                    } else {
                                        return 0.176694632956;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return 0.29707292948;
                                    } else {
                                        return 0.122085494642;
                                    }
                                }
                            }
                        } else {
                            return -0.114880711782;
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            return -0.100310726782;
                        } else {
                            return -0.143418737258;
                        }
                    }
                } else {
                    if (fs[4] <= 9.5) {
                        if (fs[72] <= 9991.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[100] <= 0.5) {
                                        return -0.060350923593;
                                    } else {
                                        return -0.00432350569532;
                                    }
                                } else {
                                    return -0.101307196296;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0147111678199;
                                    } else {
                                        return 0.171654651123;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.0558245753459;
                                    } else {
                                        return 0.00170540635315;
                                    }
                                }
                            }
                        } else {
                            return 0.0772294923856;
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[102] <= 0.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.37685450617;
                                    } else {
                                        return -0.014192319424;
                                    }
                                } else {
                                    if (fs[85] <= 5.0) {
                                        return -0.0670744501868;
                                    } else {
                                        return -0.100755370628;
                                    }
                                }
                            } else {
                                if (fs[53] <= 3.5) {
                                    return -0.139152711639;
                                } else {
                                    return -0.01782236826;
                                }
                            }
                        } else {
                            if (fs[47] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    return 0.474474449334;
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.262357191722;
                                    } else {
                                        return 0.200384693054;
                                    }
                                }
                            } else {
                                if (fs[4] <= 18.0) {
                                    return -0.0234089102;
                                } else {
                                    return -0.0500840137145;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[18] <= 0.5) {
                if (fs[76] <= 250.0) {
                    if (fs[28] <= 0.5) {
                        if (fs[85] <= 0.5) {
                            if (fs[80] <= 0.5) {
                                if (fs[2] <= 12.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0207809329242;
                                    } else {
                                        return -0.192262216695;
                                    }
                                } else {
                                    return 0.186198432924;
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return -0.169521362827;
                                    } else {
                                        return -0.322137389329;
                                    }
                                } else {
                                    return -0.000490756306126;
                                }
                            }
                        } else {
                            if (fs[85] <= 7.5) {
                                if (fs[53] <= 3.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0982381248418;
                                    } else {
                                        return 0.0661074973465;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.037810032924;
                                    } else {
                                        return -0.0117538564723;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.045863832074;
                                    } else {
                                        return 0.330423481554;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.00555223819641;
                                    } else {
                                        return 0.150340024267;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1888.0) {
                            return 0.348023674212;
                        } else {
                            if (fs[102] <= 0.5) {
                                if (fs[53] <= -1303.0) {
                                    if (fs[87] <= 0.5) {
                                        return -0.124823016063;
                                    } else {
                                        return -0.225589841553;
                                    }
                                } else {
                                    return 0.252429560035;
                                }
                            } else {
                                return 0.0864317219661;
                            }
                        }
                    }
                } else {
                    if (fs[100] <= 0.5) {
                        if (fs[4] <= 14.0) {
                            if (fs[0] <= 1.5) {
                                if (fs[53] <= -1143.5) {
                                    return -0.145564641308;
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.14585639967;
                                    } else {
                                        return -0.0236258054404;
                                    }
                                }
                            } else {
                                return -0.0299493297425;
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    return -0.365830673688;
                                } else {
                                    return -0.235381386892;
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    return 0.00859981773311;
                                } else {
                                    return -0.162965598652;
                                }
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[13] <= 0.5) {
                                if (fs[80] <= 0.5) {
                                    return -0.126259832175;
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return 0.120359688826;
                                    } else {
                                        return -0.0113014222382;
                                    }
                                }
                            } else {
                                return -0.209339618817;
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                return 0.123847458735;
                            } else {
                                if (fs[53] <= -1027.0) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.465741681613;
                                    } else {
                                        return 0.265223381895;
                                    }
                                } else {
                                    return 0.0400052551636;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[82] <= 0.5) {
                    if (fs[98] <= 1.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[87] <= 0.5) {
                                if (fs[62] <= -0.5) {
                                    if (fs[53] <= -1113.0) {
                                        return 0.0217917062127;
                                    } else {
                                        return 0.12401983738;
                                    }
                                } else {
                                    if (fs[85] <= 2.5) {
                                        return 0.030171892393;
                                    } else {
                                        return 0.00154597071781;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.110244725476;
                                    } else {
                                        return -0.0710256611598;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0990694681433;
                                    } else {
                                        return -0.224599407965;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[70] <= -4.5) {
                                    return -0.00576221263525;
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0623571532705;
                                    } else {
                                        return -0.0875298589842;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[98] <= 0.5) {
                                        return -0.0605356511988;
                                    } else {
                                        return 0.0432672333046;
                                    }
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return 0.219806762007;
                                    } else {
                                        return -0.0281853005116;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[96] <= 0.5) {
                            if (fs[4] <= 23.5) {
                                if (fs[76] <= 100.0) {
                                    if (fs[70] <= -4.5) {
                                        return 0.0121807566687;
                                    } else {
                                        return -0.265473520556;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.114179571951;
                                    } else {
                                        return -0.0317099874983;
                                    }
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    return -0.0287886251092;
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.269296518663;
                                    } else {
                                        return 0.0517856873774;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 250.0) {
                                if (fs[62] <= -0.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.158550874256;
                                    } else {
                                        return 0.0105475472313;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00303097572561;
                                    } else {
                                        return -0.0658357515866;
                                    }
                                }
                            } else {
                                if (fs[4] <= 18.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.037411137335;
                                    } else {
                                        return -0.00518008279241;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.0272986920568;
                                    } else {
                                        return -0.331489610506;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    return 0.327065517536;
                }
            }
        }
    }
}
