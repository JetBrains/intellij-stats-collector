/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree56 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[40] <= 0.5) {
                if (fs[4] <= 14.5) {
                    if (fs[2] <= 3.5) {
                        if (fs[53] <= -1504.0) {
                            if (fs[85] <= 1.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.00432634993162;
                                    } else {
                                        return 0.161481350861;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.232675319996;
                                    } else {
                                        return 0.117385407785;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9897.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.327534765225;
                                    } else {
                                        return 0.220645459846;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.207929894993;
                                    } else {
                                        return 0.157601703626;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1473.5) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[87] <= 0.5) {
                                        return -0.0290528292955;
                                    } else {
                                        return 0.0706804993918;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return 0.0758720010148;
                                    } else {
                                        return -0.04127325942;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0531937020005;
                                    } else {
                                        return 0.0818756463664;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0549351786904;
                                    } else {
                                        return 0.00674162645923;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[29] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.065113840737;
                                    } else {
                                        return 0.114528618992;
                                    }
                                } else {
                                    return -0.336235036766;
                                }
                            } else {
                                if (fs[53] <= -1048.0) {
                                    if (fs[52] <= 0.5) {
                                        return 0.106196101649;
                                    } else {
                                        return 0.164544625363;
                                    }
                                } else {
                                    if (fs[85] <= 3.5) {
                                        return 0.0463885364984;
                                    } else {
                                        return 0.158395386171;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 4862.0) {
                                if (fs[2] <= 6.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.299865164459;
                                    } else {
                                        return -0.0779330195301;
                                    }
                                } else {
                                    return -0.34097133689;
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    return -0.102073006266;
                                } else {
                                    return -0.269429509824;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 7.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[53] <= -2003.5) {
                                    if (fs[76] <= 250.0) {
                                        return 0.200088415336;
                                    } else {
                                        return 0.0373361391326;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.0385740130495;
                                    } else {
                                        return 0.00792424394018;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[72] <= 9653.5) {
                                        return -0.224410672322;
                                    } else {
                                        return 0.129890316049;
                                    }
                                } else {
                                    if (fs[85] <= 5.0) {
                                        return 0.193035103672;
                                    } else {
                                        return 0.0535387192401;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -1.5) {
                                if (fs[58] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0994492477221;
                                    } else {
                                        return 0.175462161153;
                                    }
                                } else {
                                    return -0.144758547473;
                                }
                            } else {
                                if (fs[70] <= -3.5) {
                                    if (fs[53] <= -1318.0) {
                                        return -0.1847660141;
                                    } else {
                                        return -0.00851487172557;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.0273483625964;
                                    } else {
                                        return 0.100619847304;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[2] <= 11.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.0307360313465;
                                    } else {
                                        return 0.118832612992;
                                    }
                                } else {
                                    if (fs[53] <= -1278.0) {
                                        return 0.257738686384;
                                    } else {
                                        return 0.144216916635;
                                    }
                                }
                            } else {
                                if (fs[4] <= 29.5) {
                                    if (fs[53] <= -1458.0) {
                                        return 0.232424335377;
                                    } else {
                                        return 0.0942436168308;
                                    }
                                } else {
                                    return -0.193792250434;
                                }
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[4] <= 25.5) {
                                    if (fs[4] <= 20.5) {
                                        return 0.193741242686;
                                    } else {
                                        return 0.0503688861694;
                                    }
                                } else {
                                    return -0.2176808696;
                                }
                            } else {
                                return -0.320754150981;
                            }
                        }
                    }
                }
            } else {
                if (fs[72] <= 9904.5) {
                    if (fs[59] <= 0.5) {
                        if (fs[72] <= 9801.5) {
                            if (fs[70] <= -3.5) {
                                if (fs[4] <= 3.5) {
                                    return -0.358397519561;
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0581530728604;
                                    } else {
                                        return -0.221579414956;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    return -0.225649471952;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0410326058149;
                                    } else {
                                        return 0.0247819579954;
                                    }
                                }
                            }
                        } else {
                            if (fs[98] <= 1.5) {
                                if (fs[52] <= 0.5) {
                                    return -0.0762640104204;
                                } else {
                                    return 0.145090226542;
                                }
                            } else {
                                if (fs[72] <= 9805.5) {
                                    return 0.537439949842;
                                } else {
                                    if (fs[72] <= 9818.5) {
                                        return -0.154950104233;
                                    } else {
                                        return 0.202417502022;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[72] <= 2989.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0331808507732;
                                    } else {
                                        return 0.0702160672416;
                                    }
                                } else {
                                    if (fs[102] <= 0.5) {
                                        return -0.0906637683043;
                                    } else {
                                        return 0.205876768812;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0363240368729;
                                    } else {
                                        return 0.0717752027696;
                                    }
                                } else {
                                    return 0.108190132495;
                                }
                            }
                        } else {
                            if (fs[96] <= 0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[85] <= 4.0) {
                                        return 0.0570444999035;
                                    } else {
                                        return 0.154129877366;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.129282585656;
                                    } else {
                                        return 0.191271746063;
                                    }
                                }
                            } else {
                                return 0.318374207919;
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1478.0) {
                        if (fs[52] <= 0.5) {
                            if (fs[76] <= 75.0) {
                                if (fs[72] <= 9987.0) {
                                    return -0.086564668717;
                                } else {
                                    return 0.239728914031;
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[42] <= 0.5) {
                                        return -0.0654007423836;
                                    } else {
                                        return -0.232769723031;
                                    }
                                } else {
                                    return -0.014353394439;
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[102] <= 0.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.14096898997;
                                    } else {
                                        return -0.055650621933;
                                    }
                                } else {
                                    return 0.0364705088113;
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[96] <= 0.5) {
                                        return 0.0183726483877;
                                    } else {
                                        return 0.355214037508;
                                    }
                                } else {
                                    return -0.187302994448;
                                }
                            }
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[102] <= 0.5) {
                                return 0.0655565029947;
                            } else {
                                return -0.0939544553742;
                            }
                        } else {
                            if (fs[72] <= 9954.5) {
                                if (fs[59] <= 0.5) {
                                    return -0.19861474163;
                                } else {
                                    return -0.252344859397;
                                }
                            } else {
                                if (fs[72] <= 9970.5) {
                                    return -0.0120798292907;
                                } else {
                                    if (fs[98] <= 1.5) {
                                        return -0.183671793904;
                                    } else {
                                        return -0.102025312411;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[72] <= 6548.5) {
                if (fs[0] <= 1.5) {
                    if (fs[40] <= 0.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0504208487025;
                                    } else {
                                        return -0.0104618780917;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0216814121216;
                                    } else {
                                        return -0.00103153831827;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[58] <= 0.5) {
                                        return 0.0194136482345;
                                    } else {
                                        return -0.0452873047419;
                                    }
                                } else {
                                    return 0.410235049191;
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[53] <= -21.5) {
                                    return 0.138408181041;
                                } else {
                                    return 0.255133808521;
                                }
                            } else {
                                if (fs[85] <= 5.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.0791543488742;
                                    } else {
                                        return -0.0181249395035;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0972443082161;
                                    } else {
                                        return 0.320517722654;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[7] <= 0.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[4] <= 26.5) {
                                        return -0.00306703066134;
                                    } else {
                                        return 0.266145681851;
                                    }
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return 0.185930505154;
                                    } else {
                                        return 0.0631897783188;
                                    }
                                }
                            } else {
                                if (fs[51] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0695154109657;
                                    } else {
                                        return 0.000889218063477;
                                    }
                                } else {
                                    if (fs[53] <= -561.5) {
                                        return 0.208224434926;
                                    } else {
                                        return 0.0516978286333;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[77] <= 0.5) {
                                    return 0.436205396582;
                                } else {
                                    return 0.685846101995;
                                }
                            } else {
                                return 0.0193248850549;
                            }
                        }
                    }
                } else {
                    if (fs[34] <= 0.5) {
                        if (fs[0] <= 4.5) {
                            if (fs[47] <= 0.5) {
                                if (fs[102] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.00343974365045;
                                    } else {
                                        return 0.0643253766023;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.00578780928876;
                                    } else {
                                        return 0.000591344949505;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1077.0) {
                                    if (fs[4] <= 15.5) {
                                        return 0.0975016949785;
                                    } else {
                                        return 0.014495152071;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00803915974833;
                                    } else {
                                        return -0.0151644186232;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 19.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.00301904774942;
                                    } else {
                                        return -0.000853301690471;
                                    }
                                } else {
                                    if (fs[53] <= -1062.0) {
                                        return 0.37868210474;
                                    } else {
                                        return 0.0318720914124;
                                    }
                                }
                            } else {
                                if (fs[51] <= 0.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.00772723051458;
                                    } else {
                                        return -0.00354114292938;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0116621421976;
                                    } else {
                                        return -0.00504977228695;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.249538678413;
                    }
                }
            } else {
                if (fs[18] <= -0.5) {
                    if (fs[85] <= 7.5) {
                        if (fs[0] <= 5.5) {
                            if (fs[72] <= 9920.5) {
                                if (fs[72] <= 9802.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0339641808636;
                                    } else {
                                        return -0.0702778191509;
                                    }
                                } else {
                                    return 0.0649301258771;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 13.5) {
                                        return -0.188614305622;
                                    } else {
                                        return -0.131388870785;
                                    }
                                } else {
                                    if (fs[53] <= -1468.0) {
                                        return -0.104234425863;
                                    } else {
                                        return -0.0738591678033;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9952.5) {
                                if (fs[0] <= 6.5) {
                                    return 0.00824502406136;
                                } else {
                                    if (fs[72] <= 9803.5) {
                                        return -0.0112903048944;
                                    } else {
                                        return -0.0217945996404;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1468.0) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0694770121075;
                                    } else {
                                        return -0.0990618181156;
                                    }
                                } else {
                                    if (fs[0] <= 14.5) {
                                        return -0.0253230024733;
                                    } else {
                                        return -0.00929396670536;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -746.5) {
                            return -0.263175170776;
                        } else {
                            return -0.0210763328377;
                        }
                    }
                } else {
                    if (fs[91] <= 0.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[72] <= 8970.0) {
                                        return 0.211912567192;
                                    } else {
                                        return 0.0213096318698;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0480282766552;
                                    } else {
                                        return -0.00603171291699;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[0] <= 11.5) {
                                        return 0.0177658861853;
                                    } else {
                                        return -0.00998476694356;
                                    }
                                } else {
                                    if (fs[72] <= 9103.5) {
                                        return 0.202507577036;
                                    } else {
                                        return 0.0362444764254;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.00559167577564;
                                    } else {
                                        return 0.141456033246;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0200248051137;
                                    } else {
                                        return 0.121035065214;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[72] <= 9998.5) {
                                        return -0.00698466183938;
                                    } else {
                                        return 0.00806404459802;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.0172185725671;
                                    } else {
                                        return -0.0131601690254;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 12.5) {
                            if (fs[72] <= 9995.5) {
                                if (fs[85] <= 5.0) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0635145963136;
                                    } else {
                                        return 0.360813251855;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.104479831905;
                                    } else {
                                        return 0.0429190540389;
                                    }
                                }
                            } else {
                                return 0.43886171099;
                            }
                        } else {
                            if (fs[98] <= 1.5) {
                                if (fs[72] <= 9996.5) {
                                    if (fs[72] <= 9838.0) {
                                        return 0.0364437458958;
                                    } else {
                                        return -0.0807269071435;
                                    }
                                } else {
                                    return 0.169876702191;
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.254464742476;
                                    } else {
                                        return 0.0221852330769;
                                    }
                                } else {
                                    if (fs[72] <= 9992.5) {
                                        return 0.00240050767219;
                                    } else {
                                        return 0.165763585676;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
