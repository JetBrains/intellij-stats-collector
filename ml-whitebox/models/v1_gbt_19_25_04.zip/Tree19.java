/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree19 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[102] <= 0.5) {
                if (fs[78] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.34456322665;
                                    } else {
                                        return 0.0452942838702;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.337298235504;
                                    } else {
                                        return 0.24227015578;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.271135829503;
                                    } else {
                                        return 0.370417343445;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return 0.176664424296;
                                    } else {
                                        return 0.308302032279;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[53] <= -1018.5) {
                                    if (fs[94] <= 0.5) {
                                        return 0.373144234192;
                                    } else {
                                        return 0.276051444467;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.00932581762024;
                                    } else {
                                        return 0.339800457065;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    return 0.0896622928619;
                                } else {
                                    return -0.0947656434322;
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9998.5) {
                            if (fs[4] <= 18.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.359384729611;
                                    } else {
                                        return 0.0727661051141;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.303249512754;
                                    } else {
                                        return 0.0707523139578;
                                    }
                                }
                            } else {
                                return 0.0186496305071;
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    return 0.417753314774;
                                } else {
                                    return -0.225283879555;
                                }
                            } else {
                                return 0.309452791046;
                            }
                        }
                    }
                } else {
                    if (fs[31] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 13.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0973383258285;
                                    } else {
                                        return 0.239843018981;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.312599912747;
                                    } else {
                                        return 0.402554283124;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.179069638571;
                                    } else {
                                        return 0.324293806859;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.10438200113;
                                    } else {
                                        return 0.1774324218;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0435804525111;
                                    } else {
                                        return 0.104317716667;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.028296845659;
                                    } else {
                                        return 0.212637243043;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[80] <= 0.5) {
                                        return 0.10025586897;
                                    } else {
                                        return -0.0475027558921;
                                    }
                                } else {
                                    if (fs[72] <= 9877.5) {
                                        return 0.303433009815;
                                    } else {
                                        return 0.057416535438;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[64] <= -998.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0499373408713;
                                    } else {
                                        return 0.366674182047;
                                    }
                                } else {
                                    if (fs[53] <= -1138.5) {
                                        return 0.332334161743;
                                    } else {
                                        return 0.357615480729;
                                    }
                                }
                            } else {
                                if (fs[58] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.358139002644;
                                    } else {
                                        return 0.306356898284;
                                    }
                                } else {
                                    return 0.0851006755797;
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[89] <= 0.5) {
                                        return 0.428487477255;
                                    } else {
                                        return 0.272168700904;
                                    }
                                } else {
                                    if (fs[53] <= -1003.0) {
                                        return 0.328153176794;
                                    } else {
                                        return -0.0257997050597;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[76] <= 150.0) {
                                        return 0.28461247707;
                                    } else {
                                        return 0.166254314939;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return -0.00855384886063;
                                    } else {
                                        return 0.204606912399;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[85] <= 6.5) {
                    if (fs[85] <= 1.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[72] <= 9960.0) {
                                if (fs[76] <= 25.0) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0303568709665;
                                    } else {
                                        return -0.138536717312;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.409757200671;
                                    } else {
                                        return -0.098073095271;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.442974311681;
                                    } else {
                                        return 0.279669816726;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.296427393108;
                                    } else {
                                        return 0.0232946194874;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[53] <= -1478.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0027504723578;
                                    } else {
                                        return 0.277682567061;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.123947468765;
                                    } else {
                                        return 0.39766194396;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.39447217548;
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.412787266903;
                                    } else {
                                        return 0.0122891636473;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9966.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[85] <= 5.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.214562079136;
                                    } else {
                                        return 0.0481068190977;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return -0.128359974183;
                                    } else {
                                        return 0.147004938452;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.342802576685;
                                    } else {
                                        return 0.174017133065;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0681856904058;
                                    } else {
                                        return 0.309233513528;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.277009169102;
                                    } else {
                                        return 0.396813299718;
                                    }
                                } else {
                                    if (fs[72] <= 9986.5) {
                                        return -0.0212394158595;
                                    } else {
                                        return 0.0871986840208;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.444142974212;
                                    } else {
                                        return 0.297435211426;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.142539357758;
                                    } else {
                                        return 0.473406422206;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -442.0) {
                            if (fs[53] <= -1488.0) {
                                if (fs[59] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.0892135501931;
                                    } else {
                                        return 0.347645981718;
                                    }
                                } else {
                                    if (fs[72] <= 9996.5) {
                                        return 0.215334406322;
                                    } else {
                                        return 0.371138026474;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.377223717691;
                                    } else {
                                        return 0.0431244415412;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.408974319387;
                                    } else {
                                        return 0.564752811116;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[72] <= 4943.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0757057289786;
                                    } else {
                                        return -0.207529777359;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.033833348021;
                                    } else {
                                        return 0.0419319770994;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[40] <= 0.5) {
                                        return -0.0413798023053;
                                    } else {
                                        return -0.302553831735;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.250914505259;
                                    } else {
                                        return 0.402195782224;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[85] <= 7.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[89] <= 0.5) {
                                        return -0.259188923899;
                                    } else {
                                        return 0.397010544789;
                                    }
                                } else {
                                    return -0.245408732849;
                                }
                            } else {
                                if (fs[4] <= 10.0) {
                                    if (fs[4] <= 3.5) {
                                        return 0.521291587138;
                                    } else {
                                        return 0.40281164107;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.392055307668;
                                    } else {
                                        return -0.0855264645399;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.231287341431;
                                    } else {
                                        return 0.358633801269;
                                    }
                                } else {
                                    if (fs[85] <= 7.5) {
                                        return 0.215368897195;
                                    } else {
                                        return 0.0494452651197;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1448.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.312654324454;
                                    } else {
                                        return -0.0571917871012;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.324428206003;
                                    } else {
                                        return 0.437843695387;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 2.5) {
                if (fs[85] <= 7.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[102] <= 0.5) {
                            if (fs[53] <= -1082.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0434825130743;
                                    } else {
                                        return 0.110645031297;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.213158787329;
                                    } else {
                                        return 0.0922173565405;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0442379779364;
                                    } else {
                                        return -0.0517894177945;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0269480980137;
                                    } else {
                                        return 0.129618016772;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9981.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[53] <= -1358.0) {
                                        return -0.000632705979156;
                                    } else {
                                        return -0.0335769656497;
                                    }
                                } else {
                                    if (fs[51] <= 0.5) {
                                        return 0.0202172786954;
                                    } else {
                                        return 0.168746957204;
                                    }
                                }
                            } else {
                                if (fs[4] <= 20.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.064409267396;
                                    } else {
                                        return 0.170359209687;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.472908052954;
                                    } else {
                                        return -0.0313690754619;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= 0.5) {
                            if (fs[87] <= 0.5) {
                                if (fs[72] <= 9990.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0408335129435;
                                    } else {
                                        return -0.00444756666488;
                                    }
                                } else {
                                    if (fs[7] <= 0.5) {
                                        return 0.0503114126783;
                                    } else {
                                        return 0.447799632233;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1448.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0493068293492;
                                    } else {
                                        return 0.139772137317;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.00827729419422;
                                    } else {
                                        return 0.0402275375528;
                                    }
                                }
                            }
                        } else {
                            if (fs[100] <= 0.5) {
                                if (fs[72] <= 9906.5) {
                                    if (fs[4] <= 34.5) {
                                        return -0.0291866767414;
                                    } else {
                                        return -0.00532030876062;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.0212225201052;
                                    } else {
                                        return 0.00645904926205;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0209549386429;
                                    } else {
                                        return 0.00138609994663;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0181299323388;
                                    } else {
                                        return -0.0295345912535;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 6.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.0677559824858;
                                    } else {
                                        return -0.131600052006;
                                    }
                                } else {
                                    return 0.550077008229;
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0196987384109;
                                    } else {
                                        return 0.181147051757;
                                    }
                                } else {
                                    return 0.409312870841;
                                }
                            }
                        } else {
                            if (fs[53] <= -1458.0) {
                                if (fs[59] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0556165845165;
                                    } else {
                                        return 0.326050932216;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0304878889369;
                                    } else {
                                        return 0.51544261728;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0816752326666;
                                    } else {
                                        return -0.0660953893556;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.106128378412;
                                    } else {
                                        return 0.104126551005;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[76] <= 75.0) {
                                if (fs[4] <= 10.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0637012763033;
                                    } else {
                                        return 0.233580722972;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.035305382843;
                                    } else {
                                        return 0.0319506805385;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return -0.136790593671;
                                } else {
                                    return 0.0289413834454;
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[2] <= 1.5) {
                                    if (fs[72] <= 9998.5) {
                                        return -0.0494533274232;
                                    } else {
                                        return 0.0154534735465;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0115002698663;
                                    } else {
                                        return -0.0344966629941;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0888357521632;
                                    } else {
                                        return -0.0320849219231;
                                    }
                                } else {
                                    return -0.0395083091384;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 6.5) {
                    if (fs[102] <= 0.5) {
                        if (fs[72] <= 9874.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[53] <= 3.5) {
                                    if (fs[47] <= 0.5) {
                                        return -0.00345272430137;
                                    } else {
                                        return -0.0233292288365;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.022940668801;
                                    } else {
                                        return -0.0300277805483;
                                    }
                                }
                            } else {
                                if (fs[4] <= 18.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.0532166059874;
                                    } else {
                                        return -0.00849239371251;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return 0.0189720591026;
                                    } else {
                                        return 0.228173628342;
                                    }
                                }
                            }
                        } else {
                            if (fs[74] <= 0.5) {
                                if (fs[76] <= 250.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.00488816446589;
                                    } else {
                                        return 0.0415911653239;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return 0.109114027552;
                                    } else {
                                        return -0.0187589906424;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[72] <= 9987.5) {
                                        return 0.0868019465145;
                                    } else {
                                        return -0.0950656269785;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0533449375587;
                                    } else {
                                        return 0.350172004943;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[72] <= 9990.5) {
                                if (fs[53] <= 3.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.019044526022;
                                    } else {
                                        return -0.00928138523449;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0279556670451;
                                    } else {
                                        return -0.038283779893;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[72] <= 9997.5) {
                                        return 0.0773723411233;
                                    } else {
                                        return 0.290701778187;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.214684791796;
                                    } else {
                                        return 0.0471066055151;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[57] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return -0.00537677187793;
                                    } else {
                                        return -0.0195194143342;
                                    }
                                } else {
                                    return 0.379842280341;
                                }
                            } else {
                                if (fs[72] <= 8895.5) {
                                    if (fs[85] <= 7.5) {
                                        return -0.0169065414752;
                                    } else {
                                        return 0.0434966932271;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.00124967373855;
                                    } else {
                                        return 0.158058692891;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 12.5) {
                        if (fs[47] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[62] <= -1.5) {
                                    if (fs[98] <= 0.5) {
                                        return 0.070605262401;
                                    } else {
                                        return 0.45385955938;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.0168273538716;
                                    } else {
                                        return 0.00703399395901;
                                    }
                                }
                            } else {
                                if (fs[85] <= 5.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.00582560452493;
                                    } else {
                                        return -0.00952628836632;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0506367582943;
                                    } else {
                                        return -0.0209364560379;
                                    }
                                }
                            }
                        } else {
                            if (fs[31] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[98] <= 1.5) {
                                        return -0.0420138074524;
                                    } else {
                                        return -0.0215972222251;
                                    }
                                } else {
                                    if (fs[72] <= 9907.5) {
                                        return -0.0217010116019;
                                    } else {
                                        return -0.0232543358058;
                                    }
                                }
                            } else {
                                if (fs[102] <= 0.5) {
                                    if (fs[49] <= -1.5) {
                                        return 0.0220595729884;
                                    } else {
                                        return -0.0198310197953;
                                    }
                                } else {
                                    return 0.0299408580392;
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9993.5) {
                            if (fs[47] <= 0.5) {
                                if (fs[62] <= -0.5) {
                                    if (fs[0] <= 35.5) {
                                        return -0.0125386918916;
                                    } else {
                                        return 0.0632488468373;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.0189973031948;
                                    } else {
                                        return -0.0203642233929;
                                    }
                                }
                            } else {
                                if (fs[85] <= 7.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0227549662046;
                                    } else {
                                        return -0.0211673529134;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.029368308696;
                                    } else {
                                        return -0.025324001749;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[53] <= -1453.0) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.0249859302948;
                                    } else {
                                        return 0.292707365242;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.165490410778;
                                    } else {
                                        return -0.018033750852;
                                    }
                                }
                            } else {
                                if (fs[0] <= 23.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.00519554780202;
                                    } else {
                                        return 0.515823857231;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0065529471446;
                                    } else {
                                        return 0.0999705947686;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
