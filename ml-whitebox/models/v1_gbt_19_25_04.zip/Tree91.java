/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree91 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[23] <= 0.5) {
                if (fs[4] <= 14.5) {
                    if (fs[53] <= -1503.5) {
                        if (fs[85] <= 0.5) {
                            if (fs[53] <= -1958.0) {
                                if (fs[102] <= 0.5) {
                                    if (fs[53] <= -1983.5) {
                                        return 0.08465229645;
                                    } else {
                                        return -0.0416263326876;
                                    }
                                } else {
                                    if (fs[85] <= -0.5) {
                                        return -0.0426410251976;
                                    } else {
                                        return -0.138161778748;
                                    }
                                }
                            } else {
                                if (fs[100] <= 1.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.0750887963299;
                                    } else {
                                        return 0.162684686578;
                                    }
                                } else {
                                    if (fs[53] <= -1608.5) {
                                        return 0.0200931741118;
                                    } else {
                                        return -0.0305913320496;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[72] <= 9996.5) {
                                        return 0.21657731131;
                                    } else {
                                        return 0.0360555636787;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0738796761387;
                                    } else {
                                        return 0.191967507381;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    return 0.012607366655;
                                } else {
                                    return 0.00805558030221;
                                }
                            }
                        }
                    } else {
                        if (fs[28] <= 0.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0113612470941;
                                    } else {
                                        return 0.114277495517;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.00581860153292;
                                    } else {
                                        return 0.0339766644406;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.000858274355058;
                                    } else {
                                        return 0.0425453685205;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.116360380433;
                                    } else {
                                        return -0.00187185911312;
                                    }
                                }
                            }
                        } else {
                            return -0.190855608993;
                        }
                    }
                } else {
                    if (fs[98] <= 0.5) {
                        if (fs[72] <= 9024.0) {
                            if (fs[2] <= 8.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[4] <= 15.5) {
                                        return -0.136892477725;
                                    } else {
                                        return 0.272489343648;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0266088640166;
                                    } else {
                                        return -0.0708466680258;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1468.0) {
                                    if (fs[4] <= 25.5) {
                                        return 0.162382649423;
                                    } else {
                                        return -0.08017806882;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return -0.0671052786966;
                                    } else {
                                        return 0.132493912771;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[80] <= 0.5) {
                                    if (fs[72] <= 9973.5) {
                                        return 0.0827353843521;
                                    } else {
                                        return 0.00750431217578;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0163483455854;
                                    } else {
                                        return -0.358646649039;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    if (fs[70] <= -3.5) {
                                        return -0.397705528441;
                                    } else {
                                        return -0.0873920126756;
                                    }
                                } else {
                                    if (fs[53] <= -1318.0) {
                                        return -0.182217705799;
                                    } else {
                                        return -0.0145741733611;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[96] <= 0.5) {
                            if (fs[4] <= 40.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[42] <= 0.5) {
                                        return 0.0300735251273;
                                    } else {
                                        return -0.0394731597724;
                                    }
                                } else {
                                    return 0.358782929463;
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    return 0.0903521079148;
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.0896332350284;
                                    } else {
                                        return 0.270615535095;
                                    }
                                }
                            }
                        } else {
                            if (fs[51] <= 0.5) {
                                if (fs[58] <= 0.5) {
                                    if (fs[76] <= 350.0) {
                                        return -0.00376398041989;
                                    } else {
                                        return -0.18348376532;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0457530333029;
                                    } else {
                                        return -0.284235558891;
                                    }
                                }
                            } else {
                                return -0.263633796421;
                            }
                        }
                    }
                }
            } else {
                if (fs[72] <= 9985.5) {
                    if (fs[70] <= -4.0) {
                        if (fs[72] <= 4517.5) {
                            if (fs[2] <= 1.5) {
                                return 0.0011386099301;
                            } else {
                                return 0.191811910044;
                            }
                        } else {
                            return 0.214501441135;
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[72] <= 9943.0) {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.185742396851;
                                    } else {
                                        return 0.229870616231;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.107505817488;
                                    } else {
                                        return 0.170858797223;
                                    }
                                }
                            } else {
                                return 0.0837905565282;
                            }
                        } else {
                            return 0.265795926813;
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[53] <= -1128.0) {
                            if (fs[98] <= 0.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[72] <= 9998.5) {
                                        return 0.0596765637555;
                                    } else {
                                        return 0.0870000660471;
                                    }
                                } else {
                                    return 0.0890063976309;
                                }
                            } else {
                                return 0.0395428503746;
                            }
                        } else {
                            return -0.0878942301401;
                        }
                    } else {
                        return 0.165239030411;
                    }
                }
            }
        } else {
            if (fs[14] <= 0.5) {
                if (fs[29] <= 0.5) {
                    if (fs[12] <= 0.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[80] <= 0.5) {
                                if (fs[42] <= 0.5) {
                                    if (fs[85] <= 7.5) {
                                        return -0.00153721850365;
                                    } else {
                                        return -0.00863495996345;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0354186362368;
                                    } else {
                                        return -0.0120290034762;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[94] <= 0.5) {
                                        return -0.106892829958;
                                    } else {
                                        return -0.0524368605485;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00196136148277;
                                    } else {
                                        return -0.0156784953777;
                                    }
                                }
                            }
                        } else {
                            if (fs[87] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[72] <= 9978.5) {
                                        return -3.0172201408e-05;
                                    } else {
                                        return 0.010689633767;
                                    }
                                } else {
                                    if (fs[72] <= 9986.5) {
                                        return -0.00123366322585;
                                    } else {
                                        return -0.0348001336178;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0076872029033;
                                    } else {
                                        return 0.0502774661307;
                                    }
                                } else {
                                    if (fs[4] <= 1.5) {
                                        return 0.339495593664;
                                    } else {
                                        return 0.000461151170171;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[70] <= -1.5) {
                            if (fs[62] <= -0.5) {
                                if (fs[0] <= 33.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0345238181142;
                                    } else {
                                        return 0.0228980125696;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0222972252099;
                                    } else {
                                        return 0.29088962463;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.00643018151586;
                                    } else {
                                        return -0.000701410798748;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.0385241888539;
                                    } else {
                                        return 0.00208952774884;
                                    }
                                }
                            }
                        } else {
                            return 0.3385711601;
                        }
                    }
                } else {
                    if (fs[98] <= 1.5) {
                        if (fs[68] <= 1.5) {
                            if (fs[72] <= 8977.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.00490216428441;
                                    } else {
                                        return -0.00645666000928;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return -0.0496487807466;
                                    } else {
                                        return -0.0143600245548;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return 0.0240124409649;
                                } else {
                                    if (fs[72] <= 9875.5) {
                                        return -0.0486978550004;
                                    } else {
                                        return -0.0945857208504;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                return 0.0669173161488;
                            } else {
                                return 0.029587823091;
                            }
                        }
                    } else {
                        if (fs[87] <= 0.5) {
                            if (fs[53] <= -1478.0) {
                                if (fs[4] <= 6.5) {
                                    if (fs[0] <= 5.0) {
                                        return 0.22826217806;
                                    } else {
                                        return -0.0197159988467;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return -0.0374299899455;
                                    } else {
                                        return 0.0549866233506;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return -0.135133708719;
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0458580166782;
                                    } else {
                                        return -0.0112455691272;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                return -0.166212233994;
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[94] <= 0.5) {
                                        return -0.0582786355145;
                                    } else {
                                        return -0.0990238655484;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00147457447594;
                                    } else {
                                        return -0.0601047994048;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[33] <= 0.5) {
                    if (fs[87] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[85] <= 6.5) {
                                if (fs[98] <= 1.5) {
                                    if (fs[85] <= 5.5) {
                                        return 0.0721098252726;
                                    } else {
                                        return 0.153256920636;
                                    }
                                } else {
                                    return -0.121341038462;
                                }
                            } else {
                                return -0.202580574582;
                            }
                        } else {
                            if (fs[4] <= 42.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[28] <= 0.5) {
                                        return -0.0051676818739;
                                    } else {
                                        return 0.0617227817685;
                                    }
                                } else {
                                    if (fs[85] <= 1.0) {
                                        return 0.211366856649;
                                    } else {
                                        return 0.0102941009787;
                                    }
                                }
                            } else {
                                return 0.13254022371;
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[64] <= -499.0) {
                                return 0.0813030758525;
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return 0.25017790903;
                                } else {
                                    return -0.0252788365741;
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                return -0.0610171393777;
                            } else {
                                if (fs[4] <= 7.5) {
                                    return -0.0507152283726;
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return 0.0828337533977;
                                    } else {
                                        return -0.00486147145838;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 7.5) {
                        if (fs[53] <= -21.0) {
                            if (fs[4] <= 4.5) {
                                return 0.0712977434225;
                            } else {
                                if (fs[72] <= 9897.0) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0797391272091;
                                    } else {
                                        return 0.0608175792281;
                                    }
                                } else {
                                    return -0.195381395834;
                                }
                            }
                        } else {
                            if (fs[70] <= -4.0) {
                                if (fs[0] <= 2.5) {
                                    return -0.0385069429699;
                                } else {
                                    if (fs[85] <= 1.0) {
                                        return -0.0352519843967;
                                    } else {
                                        return -0.00180304517536;
                                    }
                                }
                            } else {
                                if (fs[98] <= 0.5) {
                                    if (fs[0] <= 16.5) {
                                        return 0.149864349344;
                                    } else {
                                        return 0.382279426012;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.0883080570811;
                                    } else {
                                        return -0.028940538695;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[98] <= 0.5) {
                            if (fs[86] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0199946553408;
                                    } else {
                                        return -0.00319755154437;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.00306099047276;
                                    } else {
                                        return 0.047419886528;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    return -0.0944299187229;
                                } else {
                                    return -0.0207916141818;
                                }
                            }
                        } else {
                            if (fs[53] <= -1608.0) {
                                return 0.288741509677;
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0498794863884;
                                    } else {
                                        return 0.0358653583517;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return -0.0365141039258;
                                    } else {
                                        return -0.0124491752059;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
