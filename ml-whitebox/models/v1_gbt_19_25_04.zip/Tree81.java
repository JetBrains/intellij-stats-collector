/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree81 {
    public double calcTree(double... fs) {
        if (fs[55] <= 0.5) {
            if (fs[78] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    return 0.222665780345;
                                } else {
                                    if (fs[53] <= -552.0) {
                                        return 0.126532568018;
                                    } else {
                                        return 0.206558576263;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    return 0.0482603238815;
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0378898629641;
                                    } else {
                                        return 0.0435749574661;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9998.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -552.0) {
                                        return 0.0208247859955;
                                    } else {
                                        return -0.158698778632;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.131892559584;
                                    } else {
                                        return -0.00291794324301;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    return -0.0930658304028;
                                } else {
                                    return 0.0985777706594;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1128.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.00759795878758;
                                    } else {
                                        return 0.0407630688095;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0132381799519;
                                    } else {
                                        return 0.014039737482;
                                    }
                                }
                            } else {
                                if (fs[76] <= 125.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.125732176346;
                                    } else {
                                        return 0.0500472877375;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0307131552584;
                                    } else {
                                        return -0.0622152681671;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -466.0) {
                                if (fs[4] <= 9.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0508057155436;
                                    } else {
                                        return 0.0166395625374;
                                    }
                                } else {
                                    return 0.170519747884;
                                }
                            } else {
                                if (fs[72] <= 9885.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0184163418565;
                                    } else {
                                        return -0.0682140397796;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.124895397306;
                                    } else {
                                        return 0.0317546084544;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 2.5) {
                        if (fs[53] <= -571.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    return -0.173888793198;
                                } else {
                                    return 0.123501595847;
                                }
                            } else {
                                return -0.152267771974;
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                return -0.107689013028;
                            } else {
                                return -0.000236844168027;
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[0] <= 56.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.324892652312;
                                    } else {
                                        return 0.0169073441101;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.000415673713226;
                                    } else {
                                        return 0.0904602859395;
                                    }
                                }
                            } else {
                                return 0.305020555184;
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.00162868510966;
                                    } else {
                                        return 0.171022016645;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.051849762648;
                                    } else {
                                        return 0.127241019526;
                                    }
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.00631910640117;
                                    } else {
                                        return -0.0202146389265;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.00865736947447;
                                    } else {
                                        return -0.00135028741311;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[53] <= -1498.5) {
                        if (fs[4] <= 33.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0160506370236;
                                    } else {
                                        return 0.0453335144317;
                                    }
                                } else {
                                    if (fs[53] <= -3743.0) {
                                        return -0.14387402335;
                                    } else {
                                        return 0.0822961168401;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1948.0) {
                                    if (fs[53] <= -2003.5) {
                                        return 0.102466168795;
                                    } else {
                                        return 0.00633711846669;
                                    }
                                } else {
                                    if (fs[2] <= 9.5) {
                                        return 0.117896372605;
                                    } else {
                                        return 0.0189451911954;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[82] <= 0.5) {
                                    return -0.263649471405;
                                } else {
                                    return -0.0720643124611;
                                }
                            } else {
                                if (fs[80] <= 0.5) {
                                    return 0.159499868617;
                                } else {
                                    return -0.163015654699;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[58] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.0155569038348;
                                    } else {
                                        return 0.047831584431;
                                    }
                                } else {
                                    if (fs[53] <= -1123.5) {
                                        return -0.0684530741251;
                                    } else {
                                        return -0.337844429521;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[94] <= 0.5) {
                                        return 0.00445960552196;
                                    } else {
                                        return 0.0258146010499;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0193595579842;
                                    } else {
                                        return 0.0877587848967;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 18.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.0642034167806;
                                    } else {
                                        return 0.0584161913524;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0271073949323;
                                    } else {
                                        return 0.0703070570648;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9992.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00882602240105;
                                    } else {
                                        return 0.0800658990147;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return -0.0258932126225;
                                    } else {
                                        return -0.130741542995;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[55] <= -1.5) {
                            if (fs[53] <= -1138.0) {
                                if (fs[4] <= 12.5) {
                                    return 0.243289702204;
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.0238644920689;
                                    } else {
                                        return -0.0482922600842;
                                    }
                                }
                            } else {
                                if (fs[53] <= 3.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.0375401970005;
                                    } else {
                                        return -0.0103702872872;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0192633199564;
                                    } else {
                                        return -0.00536146854106;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[31] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.00253792065584;
                                    } else {
                                        return 0.0139383601413;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0870790172784;
                                    } else {
                                        return -0.011743750968;
                                    }
                                }
                            } else {
                                if (fs[66] <= 10.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.00122488131758;
                                    } else {
                                        return 0.0249868496289;
                                    }
                                } else {
                                    return -0.164606256877;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[85] <= 5.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.000459359698946;
                                    } else {
                                        return 0.0261928415415;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0201723389621;
                                    } else {
                                        return -0.000110169587503;
                                    }
                                }
                            } else {
                                if (fs[85] <= 3.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0188448517669;
                                    } else {
                                        return 0.121323705568;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.105976146852;
                                    } else {
                                        return 0.505415082288;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 11.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return -0.000532526939533;
                                    } else {
                                        return 0.0129472486029;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.00617209606202;
                                    } else {
                                        return -0.0173218963783;
                                    }
                                }
                            } else {
                                if (fs[76] <= 350.0) {
                                    if (fs[18] <= 0.5) {
                                        return -0.000568137716053;
                                    } else {
                                        return -0.0037863271929;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.00819437908332;
                                    } else {
                                        return -0.0233697668786;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[4] <= 17.5) {
                if (fs[53] <= 3.5) {
                    if (fs[53] <= -982.0) {
                        if (fs[4] <= 12.5) {
                            if (fs[51] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[55] <= 998.0) {
                                        return 0.141497115729;
                                    } else {
                                        return 0.247974784021;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0909638275951;
                                    } else {
                                        return 0.0077326852432;
                                    }
                                }
                            } else {
                                return -0.294141650139;
                            }
                        } else {
                            return 0.290376038462;
                        }
                    } else {
                        return 0.378038648804;
                    }
                } else {
                    return -0.0736000130992;
                }
            } else {
                if (fs[52] <= 0.5) {
                    if (fs[47] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            return 0.18028832881;
                        } else {
                            return -0.11596948375;
                        }
                    } else {
                        return -0.0154251985979;
                    }
                } else {
                    return 0.106423545193;
                }
            }
        }
    }
}
