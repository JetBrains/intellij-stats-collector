/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree31 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[53] <= -1053.5) {
                if (fs[53] <= -1433.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[53] <= -1498.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[72] <= 9355.5) {
                                    if (fs[53] <= -1938.5) {
                                        return -0.0286037454907;
                                    } else {
                                        return 0.234891484534;
                                    }
                                } else {
                                    if (fs[53] <= -2453.5) {
                                        return 0.487929623098;
                                    } else {
                                        return 0.256377092029;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.33499422309;
                                    } else {
                                        return 0.215549577653;
                                    }
                                } else {
                                    if (fs[53] <= -1608.0) {
                                        return 0.118420978717;
                                    } else {
                                        return 0.376992553437;
                                    }
                                }
                            }
                        } else {
                            if (fs[98] <= 0.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[85] <= 6.5) {
                                        return -0.0310303815343;
                                    } else {
                                        return 0.190550267129;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.0175814515147;
                                    } else {
                                        return 0.229368418349;
                                    }
                                }
                            } else {
                                if (fs[42] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.125883266944;
                                    } else {
                                        return 0.423841975365;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.064111075528;
                                    } else {
                                        return -0.0311115770562;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[85] <= 6.5) {
                            if (fs[53] <= -1498.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[31] <= 0.5) {
                                        return 0.324587939038;
                                    } else {
                                        return 0.226015560335;
                                    }
                                } else {
                                    if (fs[72] <= 9810.0) {
                                        return 0.213807889615;
                                    } else {
                                        return 0.320454270342;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[85] <= 5.5) {
                                        return 0.106282185815;
                                    } else {
                                        return -0.048292172975;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return 0.19950649575;
                                    } else {
                                        return -0.105267240191;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.309131136786;
                                    } else {
                                        return 0.215252975404;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.339775451301;
                                    } else {
                                        return 0.151871799045;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0935716329963;
                                    } else {
                                        return 0.222780841872;
                                    }
                                } else {
                                    if (fs[72] <= 9987.5) {
                                        return -0.0963110224177;
                                    } else {
                                        return 0.190193108062;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[83] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.165635391851;
                                    } else {
                                        return 0.284509622337;
                                    }
                                } else {
                                    if (fs[85] <= 3.5) {
                                        return 0.207745089109;
                                    } else {
                                        return 0.348328801409;
                                    }
                                }
                            } else {
                                if (fs[98] <= 0.5) {
                                    if (fs[72] <= 4662.0) {
                                        return -0.0557908734686;
                                    } else {
                                        return 0.190706267139;
                                    }
                                } else {
                                    if (fs[76] <= 350.0) {
                                        return 0.123353076602;
                                    } else {
                                        return -0.153086937561;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                if (fs[58] <= 0.5) {
                                    if (fs[51] <= 0.5) {
                                        return 0.0384947092057;
                                    } else {
                                        return 0.374162777051;
                                    }
                                } else {
                                    return -0.172015300588;
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    return -0.00756800428686;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.181577519539;
                                    } else {
                                        return 0.201222815596;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[74] <= 0.5) {
                            if (fs[70] <= -1.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.237634645501;
                                    } else {
                                        return 0.372202808276;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.172143996066;
                                    } else {
                                        return 0.172480640664;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.256769861399;
                                    } else {
                                        return 0.406525790995;
                                    }
                                } else {
                                    return 0.291180658305;
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[72] <= 4685.0) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0587000042387;
                                    } else {
                                        return -0.115872756081;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.237936607397;
                                    } else {
                                        return 0.126941556733;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9855.5) {
                                    return 0.175738202898;
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.249161363708;
                                    } else {
                                        return 0.233740795346;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 1.5) {
                    if (fs[98] <= 0.5) {
                        if (fs[43] <= 0.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0666970764867;
                                    } else {
                                        return 0.0915119532449;
                                    }
                                } else {
                                    if (fs[55] <= 0.5) {
                                        return -0.108131790482;
                                    } else {
                                        return 0.539513557678;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.541326582893;
                                    } else {
                                        return 0.0503088117048;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.174679631844;
                                    } else {
                                        return -0.0608548327142;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 7.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.313313536409;
                                    } else {
                                        return 0.0896226260521;
                                    }
                                } else {
                                    if (fs[72] <= 4681.0) {
                                        return 0.0193546174761;
                                    } else {
                                        return 0.217485580801;
                                    }
                                }
                            } else {
                                return 0.291590342619;
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[72] <= 4820.5) {
                                        return 0.194719657235;
                                    } else {
                                        return 0.353916811084;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return 0.103986879237;
                                    } else {
                                        return -0.0223138456563;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9998.5) {
                                    if (fs[96] <= 0.5) {
                                        return -0.038557214807;
                                    } else {
                                        return 0.0812750349428;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.206328372727;
                                    } else {
                                        return -0.0111388490973;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -0.5) {
                                if (fs[64] <= -995.5) {
                                    if (fs[100] <= 0.5) {
                                        return 0.29752933775;
                                    } else {
                                        return 0.213011427792;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.354909653756;
                                    } else {
                                        return 0.134895618868;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return -0.0318561362098;
                                    } else {
                                        return 0.182232002971;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.0659098922349;
                                    } else {
                                        return 0.376937002725;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[25] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[4] <= 19.5) {
                                if (fs[72] <= 9736.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.202505268612;
                                    } else {
                                        return 0.067258215832;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.287014416269;
                                    } else {
                                        return 0.23719058118;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9791.0) {
                                    if (fs[81] <= 0.5) {
                                        return -0.321900941391;
                                    } else {
                                        return -0.0130533251795;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return 0.26925006605;
                                    } else {
                                        return -0.310384277797;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.373235689903;
                                    } else {
                                        return 0.241703354329;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.132603840788;
                                    } else {
                                        return -0.0394087828743;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[64] <= -992.5) {
                                        return 0.246486499029;
                                    } else {
                                        return 0.121779182703;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.055082578495;
                                    } else {
                                        return 0.416726299909;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[85] <= 7.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[53] <= -918.0) {
                                    if (fs[4] <= 10.5) {
                                        return -0.2144876337;
                                    } else {
                                        return -0.15602021397;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.18050293764;
                                    } else {
                                        return 0.0505445667786;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    return 0.0304397076362;
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.0342446302592;
                                    } else {
                                        return 0.343480991063;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                return 0.0141450542189;
                            } else {
                                return 0.250410755362;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[98] <= 0.5) {
                if (fs[0] <= 1.5) {
                    if (fs[72] <= 8566.5) {
                        if (fs[85] <= 6.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0635178284607;
                                    } else {
                                        return -0.01545686833;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0833851964547;
                                    } else {
                                        return -0.0588749124101;
                                    }
                                }
                            } else {
                                if (fs[102] <= 0.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.0119949441453;
                                    } else {
                                        return -0.0261463494712;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0170036690839;
                                    } else {
                                        return 0.018438306104;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1478.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.03376235274;
                                    } else {
                                        return 0.0774717378086;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.234689153584;
                                    } else {
                                        return -0.0183032167223;
                                    }
                                }
                            } else {
                                if (fs[70] <= -4.5) {
                                    if (fs[85] <= 7.5) {
                                        return 0.00961074631019;
                                    } else {
                                        return -0.0453560927946;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0381276385411;
                                    } else {
                                        return -0.00215448628007;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[82] <= 0.5) {
                                if (fs[53] <= -1118.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.131464925437;
                                    } else {
                                        return -0.0509043933197;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0253689337404;
                                    } else {
                                        return 0.177905667614;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0210212588992;
                                    } else {
                                        return -0.0354269335279;
                                    }
                                } else {
                                    if (fs[85] <= 7.5) {
                                        return 0.074466356149;
                                    } else {
                                        return 0.403338956217;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[53] <= -1053.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0920028282883;
                                    } else {
                                        return 0.223808678939;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.106466586927;
                                    } else {
                                        return -0.0575576460614;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.0537428098896;
                                    } else {
                                        return -0.0459854482592;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.163599309915;
                                    } else {
                                        return 0.325406423278;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 6.5) {
                        if (fs[102] <= 0.5) {
                            if (fs[72] <= 9998.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.149039273903;
                                    } else {
                                        return 0.0116250391849;
                                    }
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return -0.00191212693619;
                                    } else {
                                        return -0.0169315211629;
                                    }
                                }
                            } else {
                                if (fs[74] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0760800344477;
                                    } else {
                                        return 0.00356534610644;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.328070580535;
                                    } else {
                                        return 0.442699629521;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[72] <= 8927.5) {
                                    if (fs[85] <= 6.5) {
                                        return -0.0131760640523;
                                    } else {
                                        return 0.0114573875899;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.00383279171525;
                                    } else {
                                        return 0.0614810145964;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 8.5) {
                                        return -0.00604720704976;
                                    } else {
                                        return 0.138952042987;
                                    }
                                } else {
                                    if (fs[72] <= 9992.5) {
                                        return 0.0104915258691;
                                    } else {
                                        return 0.102585866518;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= -1.5) {
                            return 0.212583552702;
                        } else {
                            if (fs[72] <= 9988.5) {
                                if (fs[0] <= 19.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0102014450101;
                                    } else {
                                        return -0.00658447403541;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return -0.0112406817257;
                                    } else {
                                        return 0.0332680891546;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.00447401982238;
                                    } else {
                                        return 0.0805170760433;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0330057473168;
                                    } else {
                                        return -0.0148409292296;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 3.5) {
                    if (fs[4] <= 13.5) {
                        if (fs[47] <= 0.5) {
                            if (fs[53] <= -1488.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[72] <= 9997.5) {
                                        return 0.0756705282012;
                                    } else {
                                        return 0.189388349032;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.241730466474;
                                    } else {
                                        return 0.0426108795698;
                                    }
                                }
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0470084174026;
                                    } else {
                                        return 0.0178009177156;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.150544034248;
                                    } else {
                                        return 0.0503866446093;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1047.0) {
                                return 0.0639036409298;
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[53] <= -976.5) {
                                        return -0.0173168237501;
                                    } else {
                                        return -0.0282093232017;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return -0.022108451425;
                                    } else {
                                        return -0.0143735975249;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[98] <= 1.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[72] <= 9985.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0257987091653;
                                    } else {
                                        return -0.0159926696638;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return -0.00137960376911;
                                    } else {
                                        return -0.0924958145259;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9609.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.0145474887934;
                                    } else {
                                        return 0.255462015775;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return 0.147732550896;
                                    } else {
                                        return 0.0382489408248;
                                    }
                                }
                            }
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[2] <= 8.5) {
                                        return 0.0333639189684;
                                    } else {
                                        return 0.152642612046;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0207259162271;
                                    } else {
                                        return 0.00048644853518;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[53] <= -1848.5) {
                                        return -0.0449851822269;
                                    } else {
                                        return 0.24646003822;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return 0.0603846422927;
                                    } else {
                                        return -0.0169915507647;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 10.5) {
                        if (fs[47] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[72] <= 9995.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.0967456059593;
                                    } else {
                                        return 0.00987572879907;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.137766072047;
                                    } else {
                                        return -0.123995317017;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.00568284502539;
                                    } else {
                                        return -0.009913155514;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.221598801805;
                                    } else {
                                        return 0.0294746406782;
                                    }
                                }
                            }
                        } else {
                            if (fs[31] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 6.5) {
                                        return -0.0221198571876;
                                    } else {
                                        return -0.012885055342;
                                    }
                                } else {
                                    if (fs[80] <= 0.5) {
                                        return -0.0133134565105;
                                    } else {
                                        return -0.00417306440732;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[49] <= -1.5) {
                                        return 0.0154941994218;
                                    } else {
                                        return -0.0110187577464;
                                    }
                                } else {
                                    if (fs[53] <= -976.0) {
                                        return 0.00162481419647;
                                    } else {
                                        return -0.0118330989168;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 11.5) {
                            if (fs[62] <= -1.5) {
                                return 0.111414338288;
                            } else {
                                if (fs[53] <= -1072.0) {
                                    if (fs[72] <= 9787.5) {
                                        return -0.00188952121023;
                                    } else {
                                        return 0.128393724186;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.00816928852967;
                                    } else {
                                        return -0.0137757648051;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[4] <= 28.5) {
                                    if (fs[53] <= -1478.0) {
                                        return -0.00939679962635;
                                    } else {
                                        return -0.0128751627986;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return -0.0145153281881;
                                    } else {
                                        return -0.0260335644172;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1958.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.108451937901;
                                    } else {
                                        return -0.00149987664576;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.0116194105876;
                                    } else {
                                        return -0.00983322769382;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
