/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree39 {
    public double calcTree(double... fs) {
        if (fs[4] <= 7.5) {
            if (fs[78] <= 0.5) {
                if (fs[30] <= 0.5) {
                    if (fs[59] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[53] <= -1138.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.0671894273689;
                                    } else {
                                        return 0.101886479264;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.138511305889;
                                    } else {
                                        return 0.118459009402;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.133900372751;
                                    } else {
                                        return 0.160550534548;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.00140518870562;
                                    } else {
                                        return 0.016524030925;
                                    }
                                }
                            }
                        } else {
                            if (fs[34] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00181198895635;
                                    } else {
                                        return -0.0508449082484;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0133035118389;
                                    } else {
                                        return 0.0537155496449;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.135632301558;
                                    } else {
                                        return 0.340630643551;
                                    }
                                } else {
                                    return 0.476145946922;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 45.0) {
                            if (fs[2] <= 1.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.197217997924;
                                    } else {
                                        return 0.0772323557204;
                                    }
                                } else {
                                    if (fs[53] <= -561.5) {
                                        return 0.134602069043;
                                    } else {
                                        return -0.0390320485758;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.134777358328;
                                    } else {
                                        return 0.263602693252;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.131288687791;
                                    } else {
                                        return 0.238881556657;
                                    }
                                }
                            }
                        } else {
                            return 0.390979443099;
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[0] <= 0.5) {
                            return -0.112718527194;
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0757906642456;
                                    } else {
                                        return -0.044344102232;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.0700717004972;
                                    } else {
                                        return -0.0812323933158;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    return -0.0639040073883;
                                } else {
                                    return -0.0502512037687;
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0154741994227;
                                    } else {
                                        return -0.0214975251537;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.0239076388644;
                                    } else {
                                        return -0.0261809396575;
                                    }
                                }
                            } else {
                                if (fs[53] <= -566.5) {
                                    if (fs[0] <= 6.5) {
                                        return -0.0232248270466;
                                    } else {
                                        return -0.0197862374442;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.00984592778952;
                                    } else {
                                        return -0.00840748735325;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -571.5) {
                                return -0.0483946222353;
                            } else {
                                if (fs[4] <= 4.5) {
                                    return -0.030012718626;
                                } else {
                                    return -0.0166522950022;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[40] <= 0.5) {
                        if (fs[74] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[102] <= 0.5) {
                                    if (fs[98] <= 0.5) {
                                        return 0.0480584465159;
                                    } else {
                                        return 0.116901877299;
                                    }
                                } else {
                                    if (fs[85] <= 1.5) {
                                        return -0.0992973284376;
                                    } else {
                                        return 0.0502994773142;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.149993785651;
                                    } else {
                                        return 0.106904938288;
                                    }
                                } else {
                                    if (fs[53] <= -1303.0) {
                                        return -0.209225179997;
                                    } else {
                                        return 0.282701445979;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9938.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[53] <= -1118.5) {
                                        return -0.057420374382;
                                    } else {
                                        return 0.321366750094;
                                    }
                                } else {
                                    return 0.181568079061;
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    return -0.0569603938759;
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.171926673085;
                                    } else {
                                        return 0.118781329847;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 6.5) {
                            if (fs[80] <= 0.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0320129681523;
                                    } else {
                                        return 0.0903932928559;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.146320129664;
                                    } else {
                                        return 0.0871213183575;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return -0.0107732297358;
                                } else {
                                    return -0.251721291603;
                                }
                            }
                        } else {
                            if (fs[76] <= 150.0) {
                                if (fs[18] <= 0.5) {
                                    if (fs[53] <= -1448.0) {
                                        return -0.00749684712512;
                                    } else {
                                        return 0.407756086962;
                                    }
                                } else {
                                    if (fs[85] <= 5.5) {
                                        return -0.181266282171;
                                    } else {
                                        return -0.264962713371;
                                    }
                                }
                            } else {
                                if (fs[100] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.167453669937;
                                    } else {
                                        return -0.264493441906;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.131127568073;
                                    } else {
                                        return -0.0148667774691;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[55] <= -1.5) {
                            if (fs[4] <= 4.5) {
                                return 0.519092969088;
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.309007251269;
                                } else {
                                    return 0.208163586114;
                                }
                            }
                        } else {
                            if (fs[85] <= 7.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[72] <= 9881.5) {
                                        return -0.00294286300418;
                                    } else {
                                        return 0.034391998861;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.028981863937;
                                    } else {
                                        return 0.0852130064754;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0125139659003;
                                    } else {
                                        return 0.306319155775;
                                    }
                                } else {
                                    if (fs[53] <= -1468.0) {
                                        return 0.233703452679;
                                    } else {
                                        return -0.0126334121921;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9998.5) {
                            if (fs[0] <= 11.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[53] <= -1488.5) {
                                        return 0.0068992455187;
                                    } else {
                                        return -0.00567897152828;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0009571797792;
                                    } else {
                                        return 0.0199444516565;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[85] <= 6.5) {
                                        return -0.00801974069196;
                                    } else {
                                        return -0.0028691662022;
                                    }
                                } else {
                                    if (fs[0] <= 19.5) {
                                        return -0.000860252909351;
                                    } else {
                                        return -0.00687938805231;
                                    }
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[47] <= 0.5) {
                                    if (fs[85] <= 7.5) {
                                        return 0.0783678102287;
                                    } else {
                                        return -0.0643404782533;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return -0.0213336592401;
                                    } else {
                                        return -0.008228194078;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    return 0.454391797199;
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0873242412166;
                                    } else {
                                        return 0.431763916925;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 4.5) {
                    if (fs[102] <= 0.5) {
                        if (fs[31] <= 0.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[49] <= -1.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.094779834646;
                                    } else {
                                        return 0.242437742797;
                                    }
                                } else {
                                    if (fs[53] <= -1498.0) {
                                        return 0.19449284056;
                                    } else {
                                        return 0.0281438167509;
                                    }
                                }
                            } else {
                                if (fs[80] <= 0.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.237214767412;
                                    } else {
                                        return 0.1474594266;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.162774991235;
                                    } else {
                                        return 0.165247243789;
                                    }
                                }
                            }
                        } else {
                            if (fs[64] <= -996.5) {
                                if (fs[58] <= 0.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.165293359868;
                                    } else {
                                        return 0.140386848302;
                                    }
                                } else {
                                    return -0.0026954344065;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.0519886878966;
                                    } else {
                                        return 0.111955407258;
                                    }
                                } else {
                                    if (fs[100] <= 1.0) {
                                        return -0.0342084395672;
                                    } else {
                                        return 0.0897840344777;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9932.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[55] <= 0.5) {
                                    if (fs[85] <= 6.5) {
                                        return -0.101919715934;
                                    } else {
                                        return 0.0362301398516;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.477619139407;
                                    } else {
                                        return 0.203266442954;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 19.5) {
                                        return -0.0192427676079;
                                    } else {
                                        return -0.316902123528;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.196300825063;
                                    } else {
                                        return -0.0289380936821;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[72] <= 9995.5) {
                                    if (fs[85] <= 5.0) {
                                        return -0.185076326159;
                                    } else {
                                        return 0.173837126357;
                                    }
                                } else {
                                    if (fs[53] <= -1078.0) {
                                        return 0.166130882732;
                                    } else {
                                        return 0.242796891952;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[53] <= -1598.0) {
                                        return 0.335124050671;
                                    } else {
                                        return 0.00920544371392;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.385968070397;
                                    } else {
                                        return 0.240803231493;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 18.5) {
                        if (fs[2] <= 5.5) {
                            if (fs[53] <= -1448.0) {
                                if (fs[82] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.072899284587;
                                    } else {
                                        return -0.146430645968;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.179056208488;
                                    } else {
                                        return 0.071863895753;
                                    }
                                }
                            } else {
                                if (fs[37] <= 0.5) {
                                    if (fs[85] <= 1.5) {
                                        return 0.121577619476;
                                    } else {
                                        return 0.201938696199;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.194593289837;
                                    } else {
                                        return 0.31157460421;
                                    }
                                }
                            }
                        } else {
                            if (fs[28] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 10.5) {
                                        return 0.173877221231;
                                    } else {
                                        return 0.262049801472;
                                    }
                                } else {
                                    if (fs[100] <= 0.5) {
                                        return 0.0149962945891;
                                    } else {
                                        return 0.374122207818;
                                    }
                                }
                            } else {
                                return -0.299978485112;
                            }
                        }
                    } else {
                        if (fs[4] <= 29.5) {
                            if (fs[2] <= 12.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.172581974788;
                                    } else {
                                        return -0.0278918248505;
                                    }
                                } else {
                                    if (fs[102] <= 0.5) {
                                        return 0.038003420385;
                                    } else {
                                        return -0.117858630875;
                                    }
                                }
                            } else {
                                if (fs[72] <= 8686.0) {
                                    if (fs[98] <= 0.5) {
                                        return 0.257001475135;
                                    } else {
                                        return 0.340450456454;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return -0.0474934568015;
                                    } else {
                                        return 0.4706076075;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9612.5) {
                                if (fs[53] <= -1668.0) {
                                    return 0.077045803499;
                                } else {
                                    if (fs[4] <= 32.5) {
                                        return -0.266702062316;
                                    } else {
                                        return -0.107280671872;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    return -0.0295874688994;
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.365539729169;
                                    } else {
                                        return 0.000747039430085;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[85] <= 4.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[85] <= 1.5) {
                                        return -0.0036631722492;
                                    } else {
                                        return 0.0449122849614;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.0424967731908;
                                    } else {
                                        return 0.15932874544;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[66] <= 5.0) {
                                        return 0.0688402190539;
                                    } else {
                                        return -0.2166097451;
                                    }
                                } else {
                                    if (fs[53] <= -1458.0) {
                                        return 0.241761752112;
                                    } else {
                                        return -0.0867537340255;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.00875298694022;
                                    } else {
                                        return 0.0105566780911;
                                    }
                                } else {
                                    if (fs[80] <= 0.5) {
                                        return -0.014757001353;
                                    } else {
                                        return -0.0789407805433;
                                    }
                                }
                            } else {
                                if (fs[102] <= 0.5) {
                                    if (fs[72] <= 9369.5) {
                                        return 0.0191483999028;
                                    } else {
                                        return 0.0584476210662;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.00672066149283;
                                    } else {
                                        return 0.0481588019058;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[14] <= 0.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return -0.0385877457168;
                                    } else {
                                        return -0.000240378223596;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.00564424955847;
                                    } else {
                                        return 0.168186091149;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1458.0) {
                                    if (fs[60] <= 0.5) {
                                        return 0.0326456272674;
                                    } else {
                                        return 0.237533858349;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return -0.0818551595394;
                                    } else {
                                        return 0.0181320810604;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    return 0.204851661556;
                                } else {
                                    return -0.00566181233576;
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[2] <= 2.5) {
                                        return 0.152769664893;
                                    } else {
                                        return 0.417130026121;
                                    }
                                } else {
                                    return 0.0254565407757;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9511.5) {
                        if (fs[0] <= 5.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[102] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.00442768054176;
                                    } else {
                                        return 0.172108418679;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.0106338369205;
                                    } else {
                                        return 0.0225443734061;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0134323318739;
                                    } else {
                                        return 0.00939124592637;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.00491572870939;
                                    } else {
                                        return 0.0511607747444;
                                    }
                                }
                            }
                        } else {
                            if (fs[102] <= 0.5) {
                                if (fs[47] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return -0.00457024855764;
                                    } else {
                                        return -0.00735306446738;
                                    }
                                } else {
                                    if (fs[53] <= -1147.5) {
                                        return 0.0336496265348;
                                    } else {
                                        return -0.00856221984094;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.00778082674526;
                                    } else {
                                        return -0.00937051744715;
                                    }
                                } else {
                                    if (fs[0] <= 10.0) {
                                        return 0.223738949826;
                                    } else {
                                        return -0.0318231035744;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[91] <= 0.5) {
                                if (fs[53] <= -1108.0) {
                                    if (fs[37] <= 0.5) {
                                        return 0.00240383106082;
                                    } else {
                                        return 0.0767422539059;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.00369182262431;
                                    } else {
                                        return -0.0143415985791;
                                    }
                                }
                            } else {
                                if (fs[85] <= 3.0) {
                                    if (fs[72] <= 9855.0) {
                                        return 0.245229326249;
                                    } else {
                                        return 0.0760696386878;
                                    }
                                } else {
                                    if (fs[72] <= 9958.0) {
                                        return -0.0333369608364;
                                    } else {
                                        return 0.0327616745264;
                                    }
                                }
                            }
                        } else {
                            if (fs[98] <= 0.5) {
                                if (fs[85] <= 6.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0220226438739;
                                    } else {
                                        return 0.0684428204485;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0490878279073;
                                    } else {
                                        return 0.459034922617;
                                    }
                                }
                            } else {
                                if (fs[70] <= -4.5) {
                                    return 0.24709449834;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0786993124589;
                                    } else {
                                        return 0.00356015018127;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
