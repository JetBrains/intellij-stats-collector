/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree4 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[53] <= -1433.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[70] <= -4.5) {
                            if (fs[98] <= 1.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.759297744834;
                                    } else {
                                        return 0.743498006411;
                                    }
                                } else {
                                    if (fs[53] <= -1543.5) {
                                        return 0.814301911473;
                                    } else {
                                        return 0.561870389867;
                                    }
                                }
                            } else {
                                return 0.834355252931;
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.129314501819;
                                    } else {
                                        return -0.0151961809764;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.465650289142;
                                    } else {
                                        return 0.665507877903;
                                    }
                                }
                            } else {
                                if (fs[96] <= 0.5) {
                                    if (fs[72] <= 9997.5) {
                                        return 0.418369381092;
                                    } else {
                                        return 0.805811704235;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.654369406879;
                                    } else {
                                        return 0.826713294568;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[85] <= 6.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.510840701973;
                                    } else {
                                        return 0.713156992092;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.778048586907;
                                    } else {
                                        return 0.623478484217;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.0155925301798;
                                    } else {
                                        return 0.316944309948;
                                    }
                                } else {
                                    if (fs[72] <= 3034.0) {
                                        return 0.336894770217;
                                    } else {
                                        return 0.0145964213194;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[72] <= 8791.0) {
                                    if (fs[71] <= 0.5) {
                                        return 0.662074712017;
                                    } else {
                                        return 0.487672900165;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.373601361975;
                                    } else {
                                        return 0.770490786098;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.685805167792;
                                    } else {
                                        return 0.779581806498;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.554296750954;
                                    } else {
                                        return 0.665911130533;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9998.5) {
                        if (fs[53] <= -1052.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.631531031694;
                                    } else {
                                        return 0.755240121985;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return 0.446877079493;
                                    } else {
                                        return 0.314079579353;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9855.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.285605889197;
                                    } else {
                                        return 0.476338089216;
                                    }
                                } else {
                                    if (fs[53] <= -1138.5) {
                                        return 0.753424612014;
                                    } else {
                                        return 0.665394024841;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.263220791837;
                                    } else {
                                        return 0.605183849608;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0469106941024;
                                    } else {
                                        return 0.621953090584;
                                    }
                                }
                            } else {
                                if (fs[53] <= -471.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0925332587631;
                                    } else {
                                        return 0.109064790831;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.23209207261;
                                    } else {
                                        return 0.0333277507612;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -987.0) {
                            if (fs[96] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.653796997689;
                                    } else {
                                        return 0.781942641552;
                                    }
                                } else {
                                    if (fs[85] <= 1.0) {
                                        return 0.656934295821;
                                    } else {
                                        return 0.751381558886;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.700902936217;
                                    } else {
                                        return 0.789592870127;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.663563816719;
                                    } else {
                                        return 0.475127023958;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.579733359034;
                                    } else {
                                        return 0.472287292317;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.72705087535;
                                    } else {
                                        return 0.584093294405;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[37] <= 0.5) {
                                        return 0.234043895211;
                                    } else {
                                        return 0.659053345917;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.750110346291;
                                    } else {
                                        return 0.560595275994;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[76] <= 250.0) {
                    if (fs[43] <= 0.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.719869845448;
                                    } else {
                                        return 0.288323290374;
                                    }
                                } else {
                                    if (fs[53] <= -1498.0) {
                                        return 0.540863102069;
                                    } else {
                                        return 0.262393155243;
                                    }
                                }
                            } else {
                                if (fs[49] <= -1.5) {
                                    if (fs[72] <= 4997.0) {
                                        return 0.745014701075;
                                    } else {
                                        return 0.853284549795;
                                    }
                                } else {
                                    if (fs[53] <= -1498.0) {
                                        return 0.582585157356;
                                    } else {
                                        return 0.382627486024;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.608178669476;
                                    } else {
                                        return 0.401252482799;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.558944086565;
                                    } else {
                                        return 0.663528703453;
                                    }
                                }
                            } else {
                                if (fs[42] <= 0.5) {
                                    if (fs[4] <= 19.5) {
                                        return 0.359863487;
                                    } else {
                                        return -0.0903897316143;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return 0.0556424845981;
                                    } else {
                                        return 0.299159530914;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 16.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[76] <= 150.0) {
                                        return 0.73936203582;
                                    } else {
                                        return 0.558500971733;
                                    }
                                } else {
                                    return 0.370137125093;
                                }
                            } else {
                                if (fs[53] <= -1128.0) {
                                    if (fs[60] <= 0.5) {
                                        return 0.695925408994;
                                    } else {
                                        return 0.557532808358;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return 0.58966342859;
                                    } else {
                                        return 0.198550260781;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1628.0) {
                                if (fs[76] <= 25.0) {
                                    if (fs[53] <= -2403.0) {
                                        return 0.807040161067;
                                    } else {
                                        return 0.568332420856;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.744406815478;
                                    } else {
                                        return 0.814899131955;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[72] <= 3761.5) {
                                        return 0.599942154216;
                                    } else {
                                        return 0.781008757869;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return 0.261984099086;
                                    } else {
                                        return 0.424441997452;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[100] <= 1.5) {
                        if (fs[43] <= 0.5) {
                            if (fs[72] <= 8685.0) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.551242854356;
                                    } else {
                                        return 0.382589717114;
                                    }
                                } else {
                                    if (fs[53] <= -485.5) {
                                        return 0.637544112979;
                                    } else {
                                        return 0.39471367394;
                                    }
                                }
                            } else {
                                if (fs[4] <= 18.5) {
                                    if (fs[53] <= -490.5) {
                                        return 0.553277421383;
                                    } else {
                                        return 0.292653573357;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.709040779668;
                                    } else {
                                        return 0.210738794277;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.353955874329;
                                    } else {
                                        return 0.0821857256123;
                                    }
                                } else {
                                    if (fs[2] <= 7.5) {
                                        return -0.0980124153273;
                                    } else {
                                        return 0.00295755861465;
                                    }
                                }
                            } else {
                                if (fs[4] <= 26.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.66792843451;
                                    } else {
                                        return 0.777477646089;
                                    }
                                } else {
                                    return 0.501964408211;
                                }
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.646428792638;
                                    } else {
                                        return 0.408673198242;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.707141656108;
                                    } else {
                                        return 0.621369151692;
                                    }
                                }
                            } else {
                                if (fs[40] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.6301397527;
                                    } else {
                                        return 0.607536369158;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.288034845417;
                                    } else {
                                        return 0.419918454722;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 4999.0) {
                                if (fs[60] <= 0.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.00592789789438;
                                    } else {
                                        return 0.622538078469;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.07426412346;
                                    } else {
                                        return 0.170990406073;
                                    }
                                }
                            } else {
                                return -0.103900064967;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 2.5) {
                if (fs[85] <= 7.5) {
                    if (fs[47] <= 0.5) {
                        if (fs[87] <= 0.5) {
                            if (fs[72] <= 9916.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.117172531434;
                                    } else {
                                        return -0.0398504168197;
                                    }
                                } else {
                                    if (fs[102] <= 0.5) {
                                        return 0.0184709361136;
                                    } else {
                                        return -0.0197851114676;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[72] <= 9994.5) {
                                        return 0.0350199158756;
                                    } else {
                                        return 0.111659055374;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.120391737735;
                                    } else {
                                        return 0.198896710047;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1418.0) {
                                if (fs[80] <= 0.5) {
                                    if (fs[4] <= 33.5) {
                                        return 0.206368781934;
                                    } else {
                                        return 0.0468799629618;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0772845424026;
                                    } else {
                                        return 0.312309373234;
                                    }
                                }
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[58] <= 0.5) {
                                        return 0.0757582775289;
                                    } else {
                                        return -0.036828367069;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.226650301492;
                                    } else {
                                        return 0.164779062132;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[68] <= 1.5) {
                                if (fs[53] <= -942.5) {
                                    if (fs[16] <= 0.5) {
                                        return -0.0410558695352;
                                    } else {
                                        return 0.0506955016826;
                                    }
                                } else {
                                    if (fs[102] <= 0.5) {
                                        return -0.044207332733;
                                    } else {
                                        return -0.0474503364506;
                                    }
                                }
                            } else {
                                if (fs[53] <= -986.0) {
                                    return 0.0769552327042;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.05784577089;
                                    } else {
                                        return -0.0148180007844;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[4] <= 39.5) {
                                    if (fs[94] <= 0.5) {
                                        return -0.0219241127242;
                                    } else {
                                        return -0.0406628187296;
                                    }
                                } else {
                                    return 0.227413449767;
                                }
                            } else {
                                return 0.438289650118;
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1448.0) {
                        if (fs[2] <= 1.5) {
                            if (fs[68] <= 1.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[40] <= 0.5) {
                                        return 0.136054181903;
                                    } else {
                                        return 0.404988918268;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0110737956679;
                                    } else {
                                        return -0.0251457558665;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return -0.0624040055348;
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.647822894898;
                                    } else {
                                        return 0.813584161391;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.254729076565;
                                    } else {
                                        return 0.00513012381729;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.406061195014;
                                    } else {
                                        return 0.639917827976;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.610126164655;
                                    } else {
                                        return 0.800539853051;
                                    }
                                } else {
                                    if (fs[72] <= 9442.5) {
                                        return 0.037222930941;
                                    } else {
                                        return 0.44591510421;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9999.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0913066620671;
                                    } else {
                                        return -0.0551469349846;
                                    }
                                } else {
                                    if (fs[62] <= -0.5) {
                                        return 0.0406805759758;
                                    } else {
                                        return -0.00749493778657;
                                    }
                                }
                            } else {
                                if (fs[70] <= -4.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0550174239497;
                                    } else {
                                        return -0.041612506781;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0375787661338;
                                    } else {
                                        return -0.0106162224206;
                                    }
                                }
                            }
                        } else {
                            return 0.460143313104;
                        }
                    }
                }
            } else {
                if (fs[98] <= 0.5) {
                    if (fs[72] <= 9978.5) {
                        if (fs[33] <= 0.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[82] <= 0.5) {
                                    if (fs[72] <= 9851.5) {
                                        return -0.0391386291069;
                                    } else {
                                        return -0.0154742584031;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return -0.0399359623722;
                                    } else {
                                        return -0.0425960706908;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1428.0) {
                                    if (fs[72] <= 8814.0) {
                                        return -0.0320368805575;
                                    } else {
                                        return 0.0363735719886;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.0331857133571;
                                    } else {
                                        return -0.0435514636814;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 6.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0169761053494;
                                    } else {
                                        return 0.0410458826772;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0302832698155;
                                    } else {
                                        return -0.00573188436553;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[85] <= -0.5) {
                                        return -0.0430057408164;
                                    } else {
                                        return -0.0389481543044;
                                    }
                                } else {
                                    if (fs[0] <= 11.5) {
                                        return -0.0254373405023;
                                    } else {
                                        return -0.0370545707378;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[59] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[53] <= -1128.0) {
                                        return 0.0893514729206;
                                    } else {
                                        return 0.00494903517593;
                                    }
                                } else {
                                    if (fs[53] <= -1087.5) {
                                        return 0.0596593847182;
                                    } else {
                                        return -0.0431028724591;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.0629921959379;
                                    } else {
                                        return 0.227395784107;
                                    }
                                } else {
                                    if (fs[72] <= 9988.5) {
                                        return -0.0153690296918;
                                    } else {
                                        return -0.045251883727;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 10.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[53] <= -1103.0) {
                                        return 0.187615989057;
                                    } else {
                                        return 0.0277341214434;
                                    }
                                } else {
                                    if (fs[53] <= -1082.5) {
                                        return 0.451131138802;
                                    } else {
                                        return 0.133609315101;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1423.0) {
                                    if (fs[72] <= 9996.5) {
                                        return 0.184597325948;
                                    } else {
                                        return 0.368425514979;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0152963331736;
                                    } else {
                                        return 0.0684678330963;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 6.5) {
                        if (fs[72] <= 9938.5) {
                            if (fs[70] <= -1.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.00548811942314;
                                    } else {
                                        return -0.0425868552404;
                                    }
                                } else {
                                    if (fs[53] <= -1047.5) {
                                        return 0.138187819307;
                                    } else {
                                        return 0.0133488294512;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return -0.016270896639;
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return -0.0429493198498;
                                    } else {
                                        return -0.0419506886288;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 250.0) {
                                if (fs[72] <= 9992.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0510054756041;
                                    } else {
                                        return 0.000386575084619;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.107956454055;
                                    } else {
                                        return 0.0462598756805;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1428.0) {
                                    if (fs[0] <= 5.5) {
                                        return 0.0744422322711;
                                    } else {
                                        return 0.4208322927;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0350879620024;
                                    } else {
                                        return 0.0329407738097;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= 0.5) {
                            if (fs[31] <= 0.5) {
                                if (fs[72] <= 9997.5) {
                                    if (fs[87] <= 0.5) {
                                        return -0.0367283236101;
                                    } else {
                                        return -0.020687669222;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.195203352961;
                                    } else {
                                        return 0.0323382377655;
                                    }
                                }
                            } else {
                                if (fs[0] <= 46.5) {
                                    if (fs[76] <= 250.0) {
                                        return -0.0287321222241;
                                    } else {
                                        return 0.125426215924;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.339368468412;
                                    } else {
                                        return 0.489048371679;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1077.0) {
                                if (fs[25] <= 0.5) {
                                    return 0.0514486125467;
                                } else {
                                    return -0.0457630389573;
                                }
                            } else {
                                if (fs[64] <= -996.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0395020774388;
                                    } else {
                                        return -0.0101827112712;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return -0.0425692527922;
                                    } else {
                                        return -0.0436741343463;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
