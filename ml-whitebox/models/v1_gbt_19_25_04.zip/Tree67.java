/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree67 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9934.5) {
            if (fs[0] <= 0.5) {
                if (fs[102] <= 0.5) {
                    if (fs[2] <= 4.5) {
                        if (fs[25] <= 0.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[53] <= -21.0) {
                                        return 0.0310724517372;
                                    } else {
                                        return -0.00825978910732;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0408721806962;
                                    } else {
                                        return -0.115905597915;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.149992483587;
                                    } else {
                                        return 0.26224996696;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.290723359579;
                                    } else {
                                        return 0.230724722929;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[96] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0776036961307;
                                    } else {
                                        return 0.0293152457624;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.00931079733301;
                                    } else {
                                        return 0.11823193785;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1493.5) {
                                    if (fs[80] <= 0.5) {
                                        return 0.143615026821;
                                    } else {
                                        return -0.0485714522819;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0787907050621;
                                    } else {
                                        return -0.0163280197393;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[80] <= 0.5) {
                                if (fs[4] <= 29.5) {
                                    if (fs[98] <= 0.5) {
                                        return 0.0449620137979;
                                    } else {
                                        return 0.0725494966113;
                                    }
                                } else {
                                    if (fs[4] <= 46.0) {
                                        return -0.072408218819;
                                    } else {
                                        return -0.330512090007;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.186106722431;
                                    } else {
                                        return 0.0223697612448;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.172106338546;
                                    } else {
                                        return -0.336493024444;
                                    }
                                }
                            }
                        } else {
                            if (fs[81] <= 0.5) {
                                if (fs[53] <= -1478.0) {
                                    if (fs[42] <= 0.5) {
                                        return 0.145158029499;
                                    } else {
                                        return 0.00835642591833;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return -0.0610187275576;
                                    } else {
                                        return 0.0801032602405;
                                    }
                                }
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[53] <= -1288.0) {
                                        return -0.289779004425;
                                    } else {
                                        return -0.0923174903689;
                                    }
                                } else {
                                    return 0.0315870158552;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[85] <= 6.5) {
                        if (fs[2] <= 6.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[55] <= 0.5) {
                                        return -0.0947992252101;
                                    } else {
                                        return 0.252735636311;
                                    }
                                } else {
                                    if (fs[85] <= 1.5) {
                                        return -0.0711357999352;
                                    } else {
                                        return 0.00805853504021;
                                    }
                                }
                            } else {
                                if (fs[85] <= 3.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.0666517695261;
                                    } else {
                                        return -0.101881342483;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.126914667453;
                                    } else {
                                        return -0.103146557043;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0131804132265;
                                    } else {
                                        return -0.454880087959;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0149455271404;
                                    } else {
                                        return 0.167209221811;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return -0.0268175243528;
                                    } else {
                                        return -0.20739288123;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.00365996122956;
                                    } else {
                                        return 0.19081390224;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[60] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[53] <= -1303.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.206807320621;
                                    } else {
                                        return 0.169646197562;
                                    }
                                } else {
                                    return -0.0934011060754;
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -1478.0) {
                                        return -0.400364067508;
                                    } else {
                                        return 0.0651507955304;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.0587828018165;
                                    } else {
                                        return -0.275838180785;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.203367324009;
                                    } else {
                                        return 0.0386931036092;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0137163380529;
                                    } else {
                                        return 0.0869659766379;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[53] <= -1098.0) {
                                        return 0.117237557409;
                                    } else {
                                        return -0.0159885487509;
                                    }
                                } else {
                                    if (fs[53] <= -1423.0) {
                                        return -0.128875536914;
                                    } else {
                                        return 0.39305631315;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[34] <= 0.5) {
                    if (fs[55] <= 998.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[102] <= 0.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.00605257819741;
                                    } else {
                                        return -0.00881400303522;
                                    }
                                } else {
                                    if (fs[85] <= 6.5) {
                                        return -0.0067567776597;
                                    } else {
                                        return 0.0142153356625;
                                    }
                                }
                            } else {
                                if (fs[64] <= -996.5) {
                                    if (fs[0] <= 69.5) {
                                        return 0.0130247880999;
                                    } else {
                                        return 0.152107251538;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.00144547019394;
                                    } else {
                                        return -0.00228968167146;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 100.0) {
                                if (fs[98] <= 1.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0095742848357;
                                    } else {
                                        return 0.0315520293135;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0982101339142;
                                    } else {
                                        return -0.0337577722964;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0698008295251;
                                    } else {
                                        return -0.0108764383033;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.210449624701;
                                    } else {
                                        return -0.0799090930337;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.4733302107;
                    }
                } else {
                    if (fs[4] <= 4.5) {
                        return 0.231795726898;
                    } else {
                        if (fs[2] <= 1.5) {
                            return 0.0869987065636;
                        } else {
                            return 0.196361255629;
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[98] <= 1.5) {
                    if (fs[80] <= 0.5) {
                        if (fs[42] <= 0.5) {
                            if (fs[18] <= -0.5) {
                                if (fs[76] <= 25.0) {
                                    return -0.14182654832;
                                } else {
                                    return -0.320148998716;
                                }
                            } else {
                                if (fs[98] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0136015893248;
                                    } else {
                                        return 0.0455791343748;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.194159518522;
                                    } else {
                                        return 0.0570636145946;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                return -0.11706879894;
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.0246298509059;
                                    } else {
                                        return -0.130790649149;
                                    }
                                } else {
                                    if (fs[72] <= 9995.5) {
                                        return -0.0689068692789;
                                    } else {
                                        return -0.24928754817;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[98] <= 0.5) {
                            if (fs[76] <= 75.0) {
                                return 0.0778630315041;
                            } else {
                                if (fs[102] <= 0.5) {
                                    return -0.333652544044;
                                } else {
                                    return -0.0438012028317;
                                }
                            }
                        } else {
                            return -0.411199620351;
                        }
                    }
                } else {
                    if (fs[22] <= 0.5) {
                        if (fs[53] <= -977.0) {
                            if (fs[100] <= 1.5) {
                                if (fs[53] <= -1758.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.0686695015959;
                                    } else {
                                        return 0.171102454201;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0166702702626;
                                    } else {
                                        return -0.403696683599;
                                    }
                                }
                            } else {
                                return -0.336760234956;
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[70] <= -4.5) {
                                        return 0.0619761417854;
                                    } else {
                                        return 0.126021662933;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.103512942308;
                                    } else {
                                        return -0.2476500575;
                                    }
                                }
                            } else {
                                if (fs[4] <= 40.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.103540184335;
                                    } else {
                                        return -0.0621297227356;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.0341297881881;
                                    } else {
                                        return 0.270837253816;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 15.5) {
                            return -0.325628175139;
                        } else {
                            if (fs[53] <= -1488.0) {
                                return 0.136566558916;
                            } else {
                                return -0.354739759627;
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 1.5) {
                    if (fs[55] <= -1.5) {
                        return 0.165633516029;
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[53] <= -1098.0) {
                                        return 0.0612033942031;
                                    } else {
                                        return 0.00416075561467;
                                    }
                                } else {
                                    if (fs[37] <= 0.5) {
                                        return -0.0157079223172;
                                    } else {
                                        return 0.0161227332676;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    return -0.0731434302438;
                                } else {
                                    if (fs[53] <= -1252.5) {
                                        return -0.152181241602;
                                    } else {
                                        return -0.00811448242468;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                if (fs[72] <= 9935.5) {
                                    return 0.171576885291;
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0453599684084;
                                    } else {
                                        return -0.0113016116164;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 14.5) {
                                        return 0.0168432948996;
                                    } else {
                                        return -0.00784272368634;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.00357778167571;
                                    } else {
                                        return -0.0478981660306;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[37] <= 0.5) {
                        if (fs[53] <= -1428.0) {
                            if (fs[4] <= 26.5) {
                                if (fs[42] <= 0.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.0205157327545;
                                    } else {
                                        return 0.0356272498098;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.114311522328;
                                    } else {
                                        return -0.00390135141729;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9987.5) {
                                    if (fs[76] <= 150.0) {
                                        return -0.0136499812921;
                                    } else {
                                        return 0.0907086121775;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0633965472917;
                                    } else {
                                        return 0.00184066430196;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[25] <= 0.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.0016128512177;
                                    } else {
                                        return 0.423354297642;
                                    }
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return -0.0475992663404;
                                    } else {
                                        return -0.00920442455854;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.134379642232;
                                    } else {
                                        return -0.0734902989422;
                                    }
                                } else {
                                    if (fs[0] <= 11.5) {
                                        return -0.0182166608199;
                                    } else {
                                        return -0.00616593432108;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 23.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[4] <= 5.5) {
                                    return 0.402314867785;
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.0398513821755;
                                    } else {
                                        return 0.466774136513;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.383679814087;
                                    } else {
                                        return 0.152356377726;
                                    }
                                } else {
                                    if (fs[0] <= 20.5) {
                                        return 0.137844095813;
                                    } else {
                                        return 0.419319604659;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9994.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.0398618546097;
                                    } else {
                                        return 0.0746018021756;
                                    }
                                } else {
                                    if (fs[0] <= 32.5) {
                                        return -0.0494624840275;
                                    } else {
                                        return -0.0386285689443;
                                    }
                                }
                            } else {
                                if (fs[0] <= 32.5) {
                                    return -0.102809192592;
                                } else {
                                    if (fs[0] <= 39.5) {
                                        return 0.2294009888;
                                    } else {
                                        return 0.013088276025;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
