/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree94 {
    public double calcTree(double... fs) {
        if (fs[55] <= 0.5) {
            if (fs[23] <= 0.5) {
                if (fs[0] <= 1.5) {
                    if (fs[80] <= 0.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[102] <= 0.5) {
                                if (fs[53] <= -1042.5) {
                                    if (fs[42] <= 0.5) {
                                        return 0.0106571169169;
                                    } else {
                                        return -0.0264303445982;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.002321663961;
                                    } else {
                                        return -0.0618362531759;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.00160439775124;
                                    } else {
                                        return 0.0606488710865;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.00642433928268;
                                    } else {
                                        return -0.0164043812838;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[0] <= 0.5) {
                                    if (fs[72] <= 9709.5) {
                                        return -0.152699545836;
                                    } else {
                                        return -0.0312691389706;
                                    }
                                } else {
                                    if (fs[2] <= 7.5) {
                                        return -0.0326925238859;
                                    } else {
                                        return 0.0231312145429;
                                    }
                                }
                            } else {
                                if (fs[72] <= 8870.0) {
                                    if (fs[4] <= 7.5) {
                                        return -0.238434707197;
                                    } else {
                                        return -0.0573476721513;
                                    }
                                } else {
                                    if (fs[85] <= 7.5) {
                                        return -0.189982249316;
                                    } else {
                                        return -0.340584138362;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 250.0) {
                            if (fs[76] <= 25.0) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.318518344913;
                                    } else {
                                        return 0.079794259439;
                                    }
                                } else {
                                    return -0.222971409475;
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[72] <= 9625.5) {
                                        return -0.115277304862;
                                    } else {
                                        return -0.203817876263;
                                    }
                                } else {
                                    return 0.200531425524;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -1473.5) {
                                        return 0.131783258317;
                                    } else {
                                        return -0.0172188240289;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0211596560828;
                                    } else {
                                        return -0.256002668282;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[72] <= 9997.5) {
                                        return -0.00198033438185;
                                    } else {
                                        return 0.0900619391929;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0655459250735;
                                    } else {
                                        return -0.211024003502;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 350.0) {
                        if (fs[4] <= 26.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[33] <= 0.5) {
                                    if (fs[98] <= 1.5) {
                                        return -0.000874774895652;
                                    } else {
                                        return -0.00351121273444;
                                    }
                                } else {
                                    if (fs[53] <= -1398.0) {
                                        return 0.00838561972368;
                                    } else {
                                        return 0.000163828254545;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1428.0) {
                                    if (fs[0] <= 7.5) {
                                        return 0.00820665186803;
                                    } else {
                                        return 0.0011096529431;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.013027083516;
                                    } else {
                                        return -0.00145169037073;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9986.5) {
                                if (fs[80] <= 0.5) {
                                    if (fs[0] <= 8.5) {
                                        return -0.0037881351266;
                                    } else {
                                        return -0.000899546978855;
                                    }
                                } else {
                                    if (fs[4] <= 36.5) {
                                        return -0.00560959957221;
                                    } else {
                                        return -0.0354691204363;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[0] <= 11.5) {
                                        return -0.0469397371163;
                                    } else {
                                        return 0.00832110055158;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return -0.0103174085008;
                                    } else {
                                        return 0.163340937856;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 26.5) {
                            if (fs[62] <= -0.5) {
                                if (fs[53] <= -1042.0) {
                                    if (fs[4] <= 2.5) {
                                        return -0.0227523320722;
                                    } else {
                                        return -0.0530441923551;
                                    }
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return -0.0234403322081;
                                    } else {
                                        return -0.0045609692382;
                                    }
                                }
                            } else {
                                if (fs[2] <= 7.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00572086695809;
                                    } else {
                                        return 0.00297134111961;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.0411362079915;
                                    } else {
                                        return -0.0138544379455;
                                    }
                                }
                            }
                        } else {
                            if (fs[98] <= 0.5) {
                                return 0.461928617709;
                            } else {
                                if (fs[0] <= 4.5) {
                                    return -0.0516359416948;
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return 0.0472713298278;
                                    } else {
                                        return -0.000502917357994;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[98] <= 0.5) {
                    if (fs[53] <= -1042.0) {
                        if (fs[72] <= 9953.5) {
                            if (fs[59] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    return 0.229884851494;
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.198057056383;
                                    } else {
                                        return -0.0205158605538;
                                    }
                                }
                            } else {
                                if (fs[72] <= 4781.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0849952727051;
                                    } else {
                                        return 0.179094566965;
                                    }
                                } else {
                                    return 0.164860805962;
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                return 0.046988439581;
                            } else {
                                if (fs[72] <= 9993.5) {
                                    return 0.124710804812;
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.054025711134;
                                    } else {
                                        return 0.0882017900892;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9946.5) {
                            if (fs[47] <= 0.5) {
                                if (fs[72] <= 9322.0) {
                                    if (fs[71] <= 0.5) {
                                        return 0.110006993718;
                                    } else {
                                        return 0.0772368866914;
                                    }
                                } else {
                                    return 0.0662889458286;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 14.0) {
                                        return -0.00187801867459;
                                    } else {
                                        return 0.0533568938739;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.010577748486;
                                    } else {
                                        return 0.000646315412226;
                                    }
                                }
                            }
                        } else {
                            return -0.100165561024;
                        }
                    }
                } else {
                    if (fs[72] <= 4943.5) {
                        if (fs[96] <= 0.5) {
                            return -0.0622857170036;
                        } else {
                            return 0.0540939788776;
                        }
                    } else {
                        return 0.0447771028813;
                    }
                }
            }
        } else {
            if (fs[62] <= -0.5) {
                return -0.160979536945;
            } else {
                if (fs[4] <= 37.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[53] <= -1493.5) {
                                return 0.0238907289213;
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[55] <= 998.5) {
                                        return 0.109680299228;
                                    } else {
                                        return 0.172288496179;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.263630800754;
                                    } else {
                                        return 0.0964260769368;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 1.0) {
                                return 0.166394052579;
                            } else {
                                if (fs[76] <= 75.0) {
                                    return -0.0777905840047;
                                } else {
                                    return 0.0342369599719;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -491.5) {
                            return 0.0248527926462;
                        } else {
                            return -0.0662826464071;
                        }
                    }
                } else {
                    return -0.144406370808;
                }
            }
        }
    }
}
