/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree51 {
    public double calcTree(double... fs) {
        if (fs[4] <= 7.5) {
            if (fs[0] <= 0.5) {
                if (fs[74] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0740688781379;
                                    } else {
                                        return 0.0502218573957;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.124618519641;
                                    } else {
                                        return 0.206129976313;
                                    }
                                }
                            } else {
                                if (fs[87] <= 0.5) {
                                    if (fs[85] <= 6.5) {
                                        return -0.0538245730074;
                                    } else {
                                        return 0.122385753815;
                                    }
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return 0.161674446754;
                                    } else {
                                        return -0.0960910752975;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1038.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[87] <= 0.5) {
                                        return 0.113314394659;
                                    } else {
                                        return 0.069871601658;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.036388538213;
                                    } else {
                                        return -0.362305553219;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[72] <= 9826.5) {
                                        return -0.0334783639351;
                                    } else {
                                        return 0.103010663473;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.0705613863578;
                                    } else {
                                        return -0.0731661211524;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[85] <= -0.5) {
                                if (fs[53] <= -1459.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.11013235826;
                                    } else {
                                        return -8.79290704955e-05;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.246329646524;
                                    } else {
                                        return -0.206411073475;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.159759999707;
                                    } else {
                                        return 0.0755637087516;
                                    }
                                } else {
                                    if (fs[85] <= 3.0) {
                                        return -0.0294998636975;
                                    } else {
                                        return -0.218073743361;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[67] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return -0.122756330938;
                                    } else {
                                        return -0.0167881143429;
                                    }
                                } else {
                                    return 0.278411640061;
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[85] <= 1.5) {
                                        return -0.013928349133;
                                    } else {
                                        return 0.118295005393;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0206948600042;
                                    } else {
                                        return 0.125418726756;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9855.5) {
                        if (fs[53] <= -1118.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0357592407797;
                                    } else {
                                        return -0.0485291385349;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.109495957366;
                                    } else {
                                        return -0.25189031999;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    return -0.0195618467061;
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.262696069682;
                                    } else {
                                        return 0.206718033834;
                                    }
                                }
                            }
                        } else {
                            return 0.24446879372;
                        }
                    } else {
                        if (fs[4] <= 2.5) {
                            if (fs[72] <= 9997.5) {
                                if (fs[72] <= 9983.5) {
                                    if (fs[72] <= 9976.5) {
                                        return -0.0860407594718;
                                    } else {
                                        return -0.121746096377;
                                    }
                                } else {
                                    return -0.182811052964;
                                }
                            } else {
                                return 0.0399078735289;
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                if (fs[2] <= 1.5) {
                                    return 0.117156804517;
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.174472277733;
                                    } else {
                                        return 0.122049357748;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9986.0) {
                                    return 0.197836763013;
                                } else {
                                    if (fs[72] <= 9996.5) {
                                        return -0.0444242632963;
                                    } else {
                                        return 0.0475315174792;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[78] <= 0.5) {
                    if (fs[59] <= 0.5) {
                        if (fs[4] <= 2.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    return -0.197280336213;
                                } else {
                                    return -0.103614701029;
                                }
                            } else {
                                return 0.147370319972;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0377292294982;
                                    } else {
                                        return 0.0448514832664;
                                    }
                                } else {
                                    if (fs[53] <= -561.5) {
                                        return -0.0305293183755;
                                    } else {
                                        return -0.017904246034;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1118.0) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.012376556663;
                                    } else {
                                        return 0.177503755198;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0457049034327;
                                    } else {
                                        return -0.0267847883378;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[40] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[70] <= -1.5) {
                                        return -0.0990598578822;
                                    } else {
                                        return 0.166762049563;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.301334856526;
                                    } else {
                                        return 0.0102177975171;
                                    }
                                }
                            } else {
                                if (fs[53] <= -556.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.397345146882;
                                    } else {
                                        return 0.103009638094;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.102829525996;
                                    } else {
                                        return -0.0338214636058;
                                    }
                                }
                            }
                        } else {
                            return 0.397887851385;
                        }
                    }
                } else {
                    if (fs[85] <= 6.5) {
                        if (fs[76] <= 25.0) {
                            if (fs[33] <= 0.5) {
                                if (fs[72] <= 9983.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0113866127225;
                                    } else {
                                        return -0.00514542910389;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.013311966566;
                                    } else {
                                        return 0.126472692867;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.00510401589448;
                                    } else {
                                        return -0.00404708003625;
                                    }
                                } else {
                                    if (fs[0] <= 12.5) {
                                        return 0.0143255964423;
                                    } else {
                                        return -0.0022666083036;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0341090135006;
                                    } else {
                                        return 0.00897265784488;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0124352768322;
                                    } else {
                                        return 0.0182225150103;
                                    }
                                }
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.035679326786;
                                    } else {
                                        return -0.00897992533476;
                                    }
                                } else {
                                    if (fs[53] <= -991.5) {
                                        return -0.0223653663964;
                                    } else {
                                        return -0.00581660353195;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.00660580833183;
                                    } else {
                                        return -0.140534660607;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.191728873027;
                                    } else {
                                        return 0.355811314043;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[72] <= 9900.5) {
                                        return 0.204183133257;
                                    } else {
                                        return 0.0906039371104;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.00552686507011;
                                    } else {
                                        return 0.0959958366413;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1448.0) {
                                if (fs[4] <= 4.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0612666508331;
                                    } else {
                                        return 0.109922236522;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0159423245075;
                                    } else {
                                        return 0.123468741398;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 3.5) {
                                        return 0.042341926349;
                                    } else {
                                        return -0.00271383106701;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return -0.0250673473859;
                                    } else {
                                        return -0.0135982835055;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[72] <= 9934.5) {
                if (fs[31] <= 0.5) {
                    if (fs[27] <= 0.5) {
                        if (fs[53] <= -1983.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[53] <= -4893.0) {
                                    if (fs[98] <= 0.5) {
                                        return 0.214181081825;
                                    } else {
                                        return 0.31435410222;
                                    }
                                } else {
                                    if (fs[64] <= -497.0) {
                                        return -0.17032523244;
                                    } else {
                                        return 0.0109166665131;
                                    }
                                }
                            } else {
                                if (fs[87] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.0432826876908;
                                    } else {
                                        return 0.246725683353;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.232031992787;
                                    } else {
                                        return 0.072615096683;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[64] <= -996.5) {
                                        return 0.0199016675457;
                                    } else {
                                        return -0.00434351943531;
                                    }
                                } else {
                                    if (fs[100] <= 0.5) {
                                        return 0.196071812406;
                                    } else {
                                        return 0.0171899987031;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[98] <= 0.5) {
                                        return 0.0477435591047;
                                    } else {
                                        return 0.0926258948342;
                                    }
                                } else {
                                    if (fs[87] <= 0.5) {
                                        return -0.00211077748035;
                                    } else {
                                        return 0.0111916189754;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.544515098963;
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[64] <= -996.5) {
                            if (fs[58] <= 0.5) {
                                if (fs[53] <= -1049.0) {
                                    if (fs[62] <= -1.5) {
                                        return 0.112082794299;
                                    } else {
                                        return 0.0844886068678;
                                    }
                                } else {
                                    return 0.18538767235;
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    return -0.193316978513;
                                } else {
                                    return 0.149582685748;
                                }
                            }
                        } else {
                            if (fs[4] <= 32.5) {
                                if (fs[102] <= 0.5) {
                                    if (fs[62] <= -1.5) {
                                        return -0.011240690506;
                                    } else {
                                        return 0.0501148551064;
                                    }
                                } else {
                                    return -0.143773885644;
                                }
                            } else {
                                return -0.187673594937;
                            }
                        }
                    } else {
                        if (fs[49] <= -2.5) {
                            return -0.150296666643;
                        } else {
                            if (fs[64] <= -998.5) {
                                return 0.181045152073;
                            } else {
                                if (fs[0] <= 56.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00696756073223;
                                    } else {
                                        return 0.00987152165654;
                                    }
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return 0.186304718335;
                                    } else {
                                        return -0.00942809081674;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[37] <= 0.5) {
                        if (fs[53] <= -1558.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[70] <= -3.5) {
                                    return -0.0390391164567;
                                } else {
                                    if (fs[72] <= 9963.5) {
                                        return 0.356362957282;
                                    } else {
                                        return 0.163997612655;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.174333414399;
                                    } else {
                                        return -0.0270327022011;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.0175924670679;
                                    } else {
                                        return -0.191571038861;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.201960852664;
                                    } else {
                                        return 0.121332884412;
                                    }
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return 0.205983398868;
                                    } else {
                                        return -0.00831928414367;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.00968665120758;
                                    } else {
                                        return 0.0749684071556;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.0687383057452;
                                    } else {
                                        return -0.230459342906;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -476.5) {
                                if (fs[76] <= 25.0) {
                                    return 0.131048327684;
                                } else {
                                    if (fs[53] <= -1458.0) {
                                        return 0.240228007458;
                                    } else {
                                        return 0.406938167757;
                                    }
                                }
                            } else {
                                return -0.0759577471993;
                            }
                        } else {
                            if (fs[4] <= 26.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[72] <= 9997.5) {
                                        return 0.248364204718;
                                    } else {
                                        return 0.0570600202367;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.148322859313;
                                    } else {
                                        return 0.229666289259;
                                    }
                                }
                            } else {
                                return 0.385579585884;
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 3.5) {
                        if (fs[0] <= 6.5) {
                            if (fs[96] <= 0.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[85] <= 2.5) {
                                        return 0.0103077559403;
                                    } else {
                                        return -0.0158117092396;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.040934420833;
                                    } else {
                                        return -0.134058919316;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0156086135253;
                                    } else {
                                        return -0.102282214801;
                                    }
                                } else {
                                    if (fs[100] <= 0.5) {
                                        return -0.0300252861436;
                                    } else {
                                        return -0.0036116150476;
                                    }
                                }
                            }
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[89] <= 0.5) {
                                    if (fs[7] <= 0.5) {
                                        return -0.0280268057696;
                                    } else {
                                        return -0.0733325648045;
                                    }
                                } else {
                                    if (fs[0] <= 352.5) {
                                        return -0.00947728807579;
                                    } else {
                                        return 0.0367391077044;
                                    }
                                }
                            } else {
                                if (fs[47] <= 0.5) {
                                    return 0.319288913279;
                                } else {
                                    return -0.0285023993596;
                                }
                            }
                        }
                    } else {
                        if (fs[37] <= 0.5) {
                            if (fs[85] <= 6.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[76] <= 250.0) {
                                        return 0.0437547974921;
                                    } else {
                                        return -0.0168016812359;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return -0.0485190457818;
                                    } else {
                                        return -0.0167030709012;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0821943737163;
                                    } else {
                                        return 0.32137776325;
                                    }
                                } else {
                                    return 0.53812221484;
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[0] <= 6.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0815866821044;
                                    } else {
                                        return -0.0444113386212;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.245585304071;
                                    } else {
                                        return 0.141445388953;
                                    }
                                }
                            } else {
                                return 0.424649891183;
                            }
                        }
                    }
                }
            }
        }
    }
}
