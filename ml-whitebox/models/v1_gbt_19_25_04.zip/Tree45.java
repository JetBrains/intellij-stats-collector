/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree45 {
    public double calcTree(double... fs) {
        if (fs[78] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[33] <= 0.5) {
                            if (fs[94] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.109237276944;
                                    } else {
                                        return 0.258290243777;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.107692624293;
                                    } else {
                                        return 0.0814241032378;
                                    }
                                }
                            } else {
                                if (fs[64] <= -998.5) {
                                    return 0.188431603876;
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0244679173801;
                                    } else {
                                        return -0.0927607370722;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.257384363656;
                                    } else {
                                        return 0.00684299809394;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.161289782659;
                                    } else {
                                        return 0.0283768555676;
                                    }
                                }
                            } else {
                                if (fs[98] <= 1.5) {
                                    if (fs[53] <= -1018.5) {
                                        return 0.124004179096;
                                    } else {
                                        return 0.0249944006429;
                                    }
                                } else {
                                    return -0.0127911714196;
                                }
                            }
                        }
                    } else {
                        return -0.20518309945;
                    }
                } else {
                    if (fs[4] <= 18.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[53] <= -546.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.103335861074;
                                    } else {
                                        return 0.0971287821638;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return 0.128444316662;
                                    } else {
                                        return 0.0555706487032;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.100158177948;
                                    } else {
                                        return 0.142446102755;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.00202644699531;
                                    } else {
                                        return -0.154773898428;
                                    }
                                }
                            }
                        } else {
                            if (fs[31] <= 0.5) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.126341891718;
                                    } else {
                                        return 0.330957992406;
                                    }
                                } else {
                                    return -0.172076305615;
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.104171998573;
                                    } else {
                                        return 0.115212106813;
                                    }
                                } else {
                                    return 0.00709257333979;
                                }
                            }
                        }
                    } else {
                        return -0.0570716511313;
                    }
                }
            } else {
                if (fs[76] <= 25.0) {
                    if (fs[34] <= 0.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.084538549177;
                                    } else {
                                        return 0.183771162035;
                                    }
                                } else {
                                    return -0.0964327935548;
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00294097747069;
                                    } else {
                                        return 0.0241096239646;
                                    }
                                } else {
                                    if (fs[0] <= 64.5) {
                                        return -0.00273977455628;
                                    } else {
                                        return 0.121269093868;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[71] <= 0.5) {
                                    return -0.0072152768917;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0617279996186;
                                    } else {
                                        return -0.101024997922;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[40] <= 0.5) {
                                        return -0.0200474523302;
                                    } else {
                                        return -0.0264629700552;
                                    }
                                } else {
                                    if (fs[53] <= -571.5) {
                                        return -0.021709398194;
                                    } else {
                                        return -0.00918971191123;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[52] <= 0.5) {
                                return 0.0144561884061;
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.182499159782;
                                    } else {
                                        return 0.354404337027;
                                    }
                                } else {
                                    return 0.253722500155;
                                }
                            }
                        } else {
                            return 0.355115053269;
                        }
                    }
                } else {
                    if (fs[40] <= 0.5) {
                        if (fs[82] <= 0.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0305892606796;
                                    } else {
                                        return -0.13040179722;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0172009073276;
                                    } else {
                                        return 0.115601285512;
                                    }
                                }
                            } else {
                                if (fs[62] <= -1.5) {
                                    return 0.0533254803565;
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.0161908263117;
                                    } else {
                                        return -0.00727604393832;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 19.0) {
                                return 0.178757741027;
                            } else {
                                return -0.0263938537914;
                            }
                        }
                    } else {
                        if (fs[70] <= -1.5) {
                            return 0.203221103881;
                        } else {
                            if (fs[0] <= 5.5) {
                                return -0.0390507833972;
                            } else {
                                return -0.00768878951062;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 2.5) {
                    if (fs[31] <= 0.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00373032065372;
                                    } else {
                                        return 0.0520907633304;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.160950282719;
                                    } else {
                                        return 0.111373539243;
                                    }
                                }
                            } else {
                                if (fs[89] <= 0.5) {
                                    if (fs[72] <= 9874.0) {
                                        return 0.0470362404356;
                                    } else {
                                        return 0.131218761319;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.029949843378;
                                    } else {
                                        return 0.0339350747788;
                                    }
                                }
                            }
                        } else {
                            if (fs[43] <= 0.5) {
                                if (fs[49] <= -0.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.16713309542;
                                    } else {
                                        return 0.0976841434849;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.121417607598;
                                    } else {
                                        return 0.027068290961;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0354273185894;
                                    } else {
                                        return 0.18151893236;
                                    }
                                } else {
                                    if (fs[102] <= 0.5) {
                                        return 0.110841702757;
                                    } else {
                                        return 0.147913350597;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[64] <= -996.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[49] <= -1.5) {
                                        return 0.0920106509219;
                                    } else {
                                        return -0.0256825554645;
                                    }
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return 0.132170198262;
                                    } else {
                                        return 0.109699413791;
                                    }
                                }
                            } else {
                                return -0.198453489146;
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[89] <= 0.5) {
                                        return 0.149896766186;
                                    } else {
                                        return -0.180231503193;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.105256218076;
                                    } else {
                                        return 0.0797020202372;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.113458864583;
                                    } else {
                                        return 0.0937269882544;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0518655789772;
                                    } else {
                                        return 0.25167878568;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 19.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[37] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.0816549946646;
                                    } else {
                                        return 0.133922266456;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.142466451098;
                                    } else {
                                        return -0.306948201648;
                                    }
                                }
                            } else {
                                if (fs[72] <= 3558.0) {
                                    if (fs[4] <= 4.5) {
                                        return -0.142650325503;
                                    } else {
                                        return 0.0633339693312;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.213351809851;
                                    } else {
                                        return 0.157226206749;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[76] <= 150.0) {
                                    if (fs[72] <= 9832.0) {
                                        return -0.0759466289113;
                                    } else {
                                        return 0.0237258440064;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0196734504548;
                                    } else {
                                        return 0.091076044804;
                                    }
                                }
                            } else {
                                if (fs[72] <= 2989.5) {
                                    if (fs[70] <= -3.5) {
                                        return -0.201434353472;
                                    } else {
                                        return 0.0566366126507;
                                    }
                                } else {
                                    if (fs[42] <= 0.5) {
                                        return 0.0911798807205;
                                    } else {
                                        return -0.0721992163385;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[70] <= -1.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[2] <= 8.5) {
                                        return -0.0627265736002;
                                    } else {
                                        return 0.0652109660082;
                                    }
                                } else {
                                    if (fs[72] <= 9883.0) {
                                        return 0.0942888128415;
                                    } else {
                                        return 0.266036402082;
                                    }
                                }
                            } else {
                                if (fs[64] <= -997.5) {
                                    return -0.337502857272;
                                } else {
                                    if (fs[4] <= 48.5) {
                                        return 0.0501884630864;
                                    } else {
                                        return -0.321455788901;
                                    }
                                }
                            }
                        } else {
                            if (fs[96] <= 0.5) {
                                return 0.506296249378;
                            } else {
                                return 0.0953217483422;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[18] <= 0.5) {
                            if (fs[89] <= 0.5) {
                                if (fs[47] <= 0.5) {
                                    if (fs[72] <= 9778.5) {
                                        return 0.0175047672265;
                                    } else {
                                        return 0.120149702256;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0141834113218;
                                    } else {
                                        return -0.0294750607925;
                                    }
                                }
                            } else {
                                if (fs[87] <= 0.5) {
                                    if (fs[85] <= 3.5) {
                                        return -0.0127936672184;
                                    } else {
                                        return 0.023401882837;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.0164644682953;
                                    } else {
                                        return 0.140934399661;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[70] <= -4.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.06717102558;
                                    } else {
                                        return 0.00187427509647;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return 0.0127927791092;
                                    } else {
                                        return 0.0320089531076;
                                    }
                                }
                            } else {
                                if (fs[53] <= -495.5) {
                                    return 0.281655123292;
                                } else {
                                    return 0.132963732777;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[85] <= 3.0) {
                                    if (fs[47] <= 0.5) {
                                        return 0.0544322834597;
                                    } else {
                                        return -0.0208418861229;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0287530980054;
                                    } else {
                                        return -0.0583446231271;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0805261730224;
                                    } else {
                                        return -0.00148621088518;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return -0.0384487182494;
                                    } else {
                                        return 0.0498455831581;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 7.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[85] <= 5.5) {
                                        return 0.0381116286823;
                                    } else {
                                        return -0.0142388559918;
                                    }
                                } else {
                                    if (fs[72] <= 9765.5) {
                                        return 0.0925326604774;
                                    } else {
                                        return 0.359968176306;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.240453534712;
                                    } else {
                                        return -0.0826293984945;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0120861223405;
                                    } else {
                                        return 0.250226331799;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 6.5) {
                        if (fs[47] <= 0.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[85] <= 7.5) {
                                        return -0.00331116988644;
                                    } else {
                                        return 0.0184110071819;
                                    }
                                } else {
                                    if (fs[63] <= 0.5) {
                                        return 0.0463975234854;
                                    } else {
                                        return 0.241651547041;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0195256205242;
                                    } else {
                                        return -0.0123624991911;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.00743039681097;
                                    } else {
                                        return 0.0194594724517;
                                    }
                                }
                            }
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[36] <= 0.5) {
                                        return -0.0168000342411;
                                    } else {
                                        return 0.134636951725;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return -0.0113289696058;
                                    } else {
                                        return -0.00720319184476;
                                    }
                                }
                            } else {
                                if (fs[102] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0171307596765;
                                    } else {
                                        return 0.195140873014;
                                    }
                                } else {
                                    if (fs[53] <= -1026.5) {
                                        return -0.0203118481757;
                                    } else {
                                        return -0.0162196338199;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 11.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[49] <= -1.5) {
                                        return 0.0856459228342;
                                    } else {
                                        return -0.00358757517788;
                                    }
                                } else {
                                    if (fs[53] <= -0.5) {
                                        return 0.00150149111167;
                                    } else {
                                        return 0.0212297210426;
                                    }
                                }
                            } else {
                                if (fs[70] <= -3.5) {
                                    if (fs[72] <= 9996.5) {
                                        return 0.00684969540614;
                                    } else {
                                        return 0.164731469645;
                                    }
                                } else {
                                    if (fs[53] <= -2953.0) {
                                        return 0.0528125011338;
                                    } else {
                                        return -0.00614234151997;
                                    }
                                }
                            }
                        } else {
                            if (fs[51] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[2] <= 18.5) {
                                        return -0.00563566278933;
                                    } else {
                                        return 0.113740302087;
                                    }
                                } else {
                                    return 0.217091618709;
                                }
                            } else {
                                if (fs[0] <= 124.0) {
                                    if (fs[0] <= 13.5) {
                                        return 0.0381683586385;
                                    } else {
                                        return -0.0054228815828;
                                    }
                                } else {
                                    return 0.122281742601;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
