/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree89 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[53] <= -987.5) {
                    if (fs[37] <= 0.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[85] <= 6.5) {
                                    if (fs[102] <= 0.5) {
                                        return -0.00867212405125;
                                    } else {
                                        return -0.0552611046915;
                                    }
                                } else {
                                    if (fs[72] <= 8656.5) {
                                        return 0.0976125154514;
                                    } else {
                                        return -0.00582316658068;
                                    }
                                }
                            } else {
                                if (fs[18] <= -0.5) {
                                    if (fs[98] <= 0.5) {
                                        return -0.101492203296;
                                    } else {
                                        return -0.201756536021;
                                    }
                                } else {
                                    if (fs[4] <= 36.5) {
                                        return 0.0305049516398;
                                    } else {
                                        return -0.216627334272;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 3.5) {
                                if (fs[82] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0269131468647;
                                    } else {
                                        return 0.0756155832461;
                                    }
                                } else {
                                    return 0.315563408406;
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[85] <= 5.0) {
                                        return 0.0202101221701;
                                    } else {
                                        return 0.116313317575;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.18853801404;
                                    } else {
                                        return 0.222212262369;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            return -0.00264742889337;
                        } else {
                            if (fs[96] <= 0.5) {
                                if (fs[53] <= -1478.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0476646391394;
                                    } else {
                                        return 0.149744391837;
                                    }
                                } else {
                                    if (fs[53] <= -1448.5) {
                                        return 0.221424913131;
                                    } else {
                                        return 0.355060468542;
                                    }
                                }
                            } else {
                                return -0.0196795707399;
                            }
                        }
                    }
                } else {
                    if (fs[98] <= 0.5) {
                        if (fs[72] <= 9999.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[55] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return -0.0745388254373;
                                    } else {
                                        return -0.265865311983;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.072526228571;
                                    } else {
                                        return 0.396932308236;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[72] <= 4286.0) {
                                        return -0.0469457334366;
                                    } else {
                                        return 0.108503752664;
                                    }
                                } else {
                                    return 0.184012642006;
                                }
                            }
                        } else {
                            if (fs[37] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0421036273023;
                                    } else {
                                        return 0.0808936224689;
                                    }
                                } else {
                                    if (fs[85] <= 2.5) {
                                        return 0.0312222327032;
                                    } else {
                                        return -0.0471983109965;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    return -0.230076939761;
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.126581202547;
                                    } else {
                                        return -0.0413633216569;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[100] <= 0.5) {
                            if (fs[98] <= 1.5) {
                                if (fs[72] <= 9988.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.198005832557;
                                    } else {
                                        return -0.0175031940518;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0772540028599;
                                    } else {
                                        return 0.225393724861;
                                    }
                                }
                            } else {
                                if (fs[49] <= -0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0152038685662;
                                    } else {
                                        return 0.0890021315278;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return -0.112714975859;
                                    } else {
                                        return 0.00618603798172;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[70] <= -4.0) {
                                        return -0.0108667065577;
                                    } else {
                                        return -0.0797487750444;
                                    }
                                } else {
                                    return 0.168748008605;
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[72] <= 4936.5) {
                                        return -0.107904557093;
                                    } else {
                                        return -0.183255569925;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.0767032764961;
                                    } else {
                                        return -0.17844610529;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[85] <= -0.5) {
                    if (fs[37] <= 0.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[53] <= -1478.5) {
                                        return -0.0220835664;
                                    } else {
                                        return -0.0608102609695;
                                    }
                                } else {
                                    return 0.0751120459551;
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0532051078638;
                                    } else {
                                        return -0.0158931099767;
                                    }
                                } else {
                                    return -0.18777414666;
                                }
                            }
                        } else {
                            if (fs[70] <= -3.5) {
                                return -0.238784647186;
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0594496825575;
                                    } else {
                                        return -0.147073564412;
                                    }
                                } else {
                                    return -0.0755541429581;
                                }
                            }
                        }
                    } else {
                        return -0.234970813226;
                    }
                } else {
                    if (fs[40] <= 0.5) {
                        if (fs[4] <= 19.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[51] <= 0.5) {
                                    if (fs[85] <= 6.5) {
                                        return 0.00819091848782;
                                    } else {
                                        return 0.0377944146962;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0728835999242;
                                    } else {
                                        return 0.264507731055;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[53] <= -908.0) {
                                        return 0.0210667787134;
                                    } else {
                                        return 0.0611781133863;
                                    }
                                } else {
                                    if (fs[85] <= 3.0) {
                                        return -0.128938407142;
                                    } else {
                                        return -0.214399667176;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 16.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0556970547708;
                                    } else {
                                        return -0.162837477585;
                                    }
                                } else {
                                    if (fs[98] <= 0.5) {
                                        return -0.0294569703703;
                                    } else {
                                        return 0.0110741380099;
                                    }
                                }
                            } else {
                                if (fs[89] <= 0.5) {
                                    return -0.0524248975169;
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.214810185803;
                                    } else {
                                        return 0.0587342836795;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -2308.0) {
                            return -0.345243057773;
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[53] <= -1488.0) {
                                    if (fs[4] <= 11.5) {
                                        return -0.00345417064932;
                                    } else {
                                        return 0.0646999123599;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.00716959206813;
                                    } else {
                                        return -0.05312827717;
                                    }
                                }
                            } else {
                                if (fs[102] <= 0.5) {
                                    if (fs[72] <= 8819.0) {
                                        return -0.176823777909;
                                    } else {
                                        return -0.335058113199;
                                    }
                                } else {
                                    return 0.00324367459901;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[14] <= 0.5) {
                if (fs[2] <= 2.5) {
                    if (fs[28] <= 0.5) {
                        if (fs[55] <= -1.5) {
                            if (fs[0] <= 1.5) {
                                return 0.141266907721;
                            } else {
                                if (fs[55] <= -6.5) {
                                    return 0.0473770667896;
                                } else {
                                    if (fs[47] <= 0.5) {
                                        return 0.0392092615432;
                                    } else {
                                        return -0.00940456529791;
                                    }
                                }
                            }
                        } else {
                            if (fs[51] <= 0.5) {
                                if (fs[38] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00178089120309;
                                    } else {
                                        return -0.000363483212624;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0383819782015;
                                    } else {
                                        return 0.19178946674;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[0] <= 124.0) {
                                        return -0.000416270063923;
                                    } else {
                                        return 0.105572950411;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.126811057787;
                                    } else {
                                        return 0.0200155737747;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -16.0) {
                            if (fs[4] <= 15.5) {
                                if (fs[72] <= 9984.0) {
                                    if (fs[87] <= 0.5) {
                                        return -0.00719187673348;
                                    } else {
                                        return -0.0468867460545;
                                    }
                                } else {
                                    return -0.165076610836;
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[100] <= 0.5) {
                                        return 0.0522595697981;
                                    } else {
                                        return -0.0807579246312;
                                    }
                                } else {
                                    if (fs[0] <= 27.5) {
                                        return 0.00945852794513;
                                    } else {
                                        return -0.0115855818945;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= 0.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[4] <= 20.5) {
                                        return -0.00995382615603;
                                    } else {
                                        return 0.0963989221428;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return 0.235528194323;
                                    } else {
                                        return 0.0931329888133;
                                    }
                                }
                            } else {
                                if (fs[4] <= 28.5) {
                                    return -0.00718752630356;
                                } else {
                                    return -0.0147632173282;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[15] <= 0.5) {
                        if (fs[76] <= 25.0) {
                            if (fs[53] <= -12.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[72] <= 9994.5) {
                                        return 0.019135544712;
                                    } else {
                                        return -0.103268803013;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return -0.000773450641408;
                                    } else {
                                        return -0.00863261128196;
                                    }
                                }
                            } else {
                                if (fs[0] <= 12.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.00719716954445;
                                    } else {
                                        return 0.284543437509;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.000715593266836;
                                    } else {
                                        return -0.00496015160245;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0305156914015;
                                    } else {
                                        return 0.0766273828666;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0371378498449;
                                    } else {
                                        return 0.0973396254246;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[47] <= 0.5) {
                                        return 0.0170938788924;
                                    } else {
                                        return -0.0129073584316;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return -0.000609306173222;
                                    } else {
                                        return 0.0352996705942;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.219112219644;
                    }
                }
            } else {
                if (fs[0] <= 4.5) {
                    if (fs[4] <= 4.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                return -0.0908596700095;
                            } else {
                                if (fs[85] <= 3.0) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0686671751587;
                                    } else {
                                        return 0.240742614316;
                                    }
                                } else {
                                    return 0.433491963426;
                                }
                            }
                        } else {
                            return -0.123276114049;
                        }
                    } else {
                        if (fs[25] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[96] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.244915088811;
                                    } else {
                                        return 0.0181724030625;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0152052184235;
                                    } else {
                                        return -0.0184455319383;
                                    }
                                }
                            } else {
                                if (fs[4] <= 24.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.0452586012857;
                                    } else {
                                        return 0.131624756556;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0471645280805;
                                    } else {
                                        return -0.031231079575;
                                    }
                                }
                            }
                        } else {
                            return -0.22591902358;
                        }
                    }
                } else {
                    if (fs[33] <= 0.5) {
                        if (fs[72] <= 9997.5) {
                            if (fs[72] <= 4540.0) {
                                if (fs[100] <= 1.0) {
                                    if (fs[76] <= 75.0) {
                                        return -0.00427768374003;
                                    } else {
                                        return 0.0114113639746;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0427544390468;
                                    } else {
                                        return 0.0107721119506;
                                    }
                                }
                            } else {
                                return -0.0705739845391;
                            }
                        } else {
                            return 0.125459358842;
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[47] <= 0.5) {
                                    if (fs[100] <= 0.5) {
                                        return 0.00552970422471;
                                    } else {
                                        return 0.0722190428982;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return -0.00720713348136;
                                    } else {
                                        return -0.0127693250804;
                                    }
                                }
                            } else {
                                return 0.22130877441;
                            }
                        } else {
                            return -0.0937683656979;
                        }
                    }
                }
            }
        }
    }
}
