/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree76 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 17.5) {
                if (fs[2] <= 5.5) {
                    if (fs[51] <= 0.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0212968634069;
                                    } else {
                                        return -0.00679642729048;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0168770965204;
                                    } else {
                                        return 0.0529998397989;
                                    }
                                }
                            } else {
                                if (fs[53] <= -482.0) {
                                    if (fs[100] <= 1.5) {
                                        return 0.0923350971979;
                                    } else {
                                        return -0.25059668186;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0601584030677;
                                    } else {
                                        return -0.00459336845718;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1493.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[53] <= -1948.0) {
                                        return 0.0531241685919;
                                    } else {
                                        return 0.138046403246;
                                    }
                                } else {
                                    if (fs[53] <= -1928.5) {
                                        return -0.0128324654086;
                                    } else {
                                        return 0.0813919854565;
                                    }
                                }
                            } else {
                                if (fs[89] <= 0.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.234757219452;
                                    } else {
                                        return 0.0566993704425;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.00301153814165;
                                    } else {
                                        return 0.0938340435888;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[55] <= 0.5) {
                            if (fs[96] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.226080115916;
                                    } else {
                                        return 0.27531058685;
                                    }
                                } else {
                                    return 0.138961958535;
                                }
                            } else {
                                return 0.150356436664;
                            }
                        } else {
                            return -0.0287587706544;
                        }
                    }
                } else {
                    if (fs[29] <= 0.5) {
                        if (fs[40] <= 0.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[2] <= 10.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0874058099887;
                                    } else {
                                        return 0.0519358904491;
                                    }
                                } else {
                                    if (fs[89] <= 0.5) {
                                        return -0.013079881801;
                                    } else {
                                        return 0.139700450547;
                                    }
                                }
                            } else {
                                return -0.360216336599;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[2] <= 8.5) {
                                    if (fs[53] <= -1128.0) {
                                        return -0.0513224049194;
                                    } else {
                                        return 0.173574053586;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return -0.0541785147946;
                                    } else {
                                        return -0.216919872369;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1478.0) {
                                    if (fs[72] <= 3034.0) {
                                        return 0.111175863406;
                                    } else {
                                        return -0.029642851072;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return -0.0655639272162;
                                    } else {
                                        return 0.107012810932;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 7.5) {
                            return -0.199353368909;
                        } else {
                            return -0.322409310538;
                        }
                    }
                }
            } else {
                if (fs[87] <= 0.5) {
                    if (fs[62] <= -0.5) {
                        if (fs[53] <= -1138.0) {
                            if (fs[98] <= 1.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 24.5) {
                                        return 0.10114515301;
                                    } else {
                                        return 0.210506012196;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.380615632399;
                                    } else {
                                        return 0.374493331302;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1448.5) {
                                    return -0.265014519691;
                                } else {
                                    return 0.0577526926074;
                                }
                            }
                        } else {
                            if (fs[96] <= 0.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return -0.275987581434;
                                    } else {
                                        return -0.0124538571108;
                                    }
                                } else {
                                    if (fs[64] <= -995.5) {
                                        return -0.0289282340834;
                                    } else {
                                        return 0.0849869848814;
                                    }
                                }
                            } else {
                                if (fs[49] <= -1.5) {
                                    return 0.0955190022716;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.208278254707;
                                    } else {
                                        return 0.347182513003;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9882.0) {
                            if (fs[2] <= 8.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return -0.0642014750602;
                                    } else {
                                        return -0.0205816653397;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.232488926377;
                                    } else {
                                        return -0.224986986819;
                                    }
                                }
                            } else {
                                if (fs[4] <= 29.5) {
                                    if (fs[2] <= 17.5) {
                                        return 0.0668572566152;
                                    } else {
                                        return 0.194431367142;
                                    }
                                } else {
                                    if (fs[2] <= 10.5) {
                                        return -0.113834769963;
                                    } else {
                                        return -0.197938385275;
                                    }
                                }
                            }
                        } else {
                            if (fs[98] <= 1.5) {
                                if (fs[37] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return -0.0343184347358;
                                    } else {
                                        return -0.261463537967;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.110546921741;
                                    } else {
                                        return -0.0463545017785;
                                    }
                                }
                            } else {
                                if (fs[89] <= 0.5) {
                                    if (fs[76] <= 150.0) {
                                        return 0.160216834621;
                                    } else {
                                        return 0.446010363801;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0209038922789;
                                    } else {
                                        return 0.122988112495;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[96] <= 0.5) {
                        if (fs[4] <= 18.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[62] <= -0.5) {
                                    return -0.465595993378;
                                } else {
                                    return 0.0170448163036;
                                }
                            } else {
                                return 0.151488367097;
                            }
                        } else {
                            if (fs[6] <= 0.5) {
                                return -0.135216185707;
                            } else {
                                if (fs[100] <= 1.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.104034945889;
                                    } else {
                                        return 0.308028750507;
                                    }
                                } else {
                                    return -0.0984720184066;
                                }
                            }
                        }
                    } else {
                        if (fs[43] <= 0.5) {
                            if (fs[72] <= 9981.5) {
                                if (fs[51] <= 0.5) {
                                    if (fs[4] <= 48.5) {
                                        return 0.0296737829388;
                                    } else {
                                        return -0.325987750391;
                                    }
                                } else {
                                    return -0.254502753645;
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.0616901406311;
                                    } else {
                                        return -0.0520636481976;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.39845795036;
                                    } else {
                                        return -0.312739701361;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 250.0) {
                                if (fs[53] <= -1488.0) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0613171845219;
                                    } else {
                                        return 0.319826576913;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0118574623682;
                                    } else {
                                        return -0.230018824849;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 26.5) {
                                        return 0.172390030212;
                                    } else {
                                        return -0.131912494016;
                                    }
                                } else {
                                    if (fs[53] <= -1483.0) {
                                        return -0.208611702137;
                                    } else {
                                        return -0.27173179088;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[4] <= 30.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[55] <= -1.5) {
                            return 0.147428387651;
                        } else {
                            if (fs[51] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[85] <= 6.5) {
                                        return 0.00305261405615;
                                    } else {
                                        return 0.0416021806005;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.00686116609701;
                                    } else {
                                        return 0.0394759181222;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0183391116035;
                                    } else {
                                        return 0.329737780393;
                                    }
                                } else {
                                    if (fs[40] <= 0.5) {
                                        return 0.0471176264385;
                                    } else {
                                        return -0.0805290624739;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[42] <= 0.5) {
                            if (fs[53] <= -1478.5) {
                                if (fs[72] <= 9088.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.00238377431283;
                                    } else {
                                        return 0.0337626357442;
                                    }
                                } else {
                                    if (fs[72] <= 9809.0) {
                                        return 0.120654305766;
                                    } else {
                                        return 0.0404442800684;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.00987203319383;
                                    } else {
                                        return 0.0745573603426;
                                    }
                                } else {
                                    if (fs[4] <= 24.5) {
                                        return -0.0148487023127;
                                    } else {
                                        return 0.0589618056675;
                                    }
                                }
                            }
                        } else {
                            if (fs[87] <= 0.5) {
                                if (fs[72] <= 9949.5) {
                                    if (fs[76] <= 150.0) {
                                        return -0.0497822109656;
                                    } else {
                                        return 0.0591864382593;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.107714641885;
                                    } else {
                                        return -0.278598762329;
                                    }
                                }
                            } else {
                                if (fs[72] <= 4801.0) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.205697886128;
                                    } else {
                                        return -0.0168090721028;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.0145788125339;
                                    } else {
                                        return -0.199994589976;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[80] <= 0.5) {
                        if (fs[53] <= -1483.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[87] <= 0.5) {
                                    if (fs[72] <= 9993.5) {
                                        return -0.0390454164335;
                                    } else {
                                        return -0.150412953148;
                                    }
                                } else {
                                    if (fs[96] <= 0.5) {
                                        return -0.159620674167;
                                    } else {
                                        return 0.118828244679;
                                    }
                                }
                            } else {
                                if (fs[4] <= 41.5) {
                                    if (fs[72] <= 9998.5) {
                                        return -0.0676168045344;
                                    } else {
                                        return -0.180984018135;
                                    }
                                } else {
                                    if (fs[72] <= 9736.5) {
                                        return -0.130021007772;
                                    } else {
                                        return -0.230147859702;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1468.0) {
                                if (fs[71] <= 0.5) {
                                    if (fs[53] <= -1478.0) {
                                        return -0.10315991307;
                                    } else {
                                        return 0.104302994552;
                                    }
                                } else {
                                    if (fs[72] <= 9910.5) {
                                        return 0.122372974362;
                                    } else {
                                        return 0.560724858335;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[53] <= -1058.0) {
                                        return -0.0335224263546;
                                    } else {
                                        return -0.00686463549744;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return -0.0203076236195;
                                    } else {
                                        return 0.169567655246;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                return -0.0160518244412;
                            } else {
                                return -0.11603898031;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return -0.08673107467;
                            } else {
                                if (fs[76] <= 250.0) {
                                    return -0.156411652105;
                                } else {
                                    if (fs[4] <= 33.5) {
                                        return -0.0439979324372;
                                    } else {
                                        return -0.14980827766;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 11.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[18] <= 0.5) {
                            if (fs[72] <= 9935.5) {
                                if (fs[55] <= -1.5) {
                                    if (fs[53] <= -1057.0) {
                                        return 0.165144079916;
                                    } else {
                                        return 0.0175162228994;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return -0.00166027444628;
                                    } else {
                                        return -0.0109657007292;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.0202067018463;
                                    } else {
                                        return 0.0688550907689;
                                    }
                                } else {
                                    if (fs[85] <= 6.5) {
                                        return -0.0151906594878;
                                    } else {
                                        return 0.163063550401;
                                    }
                                }
                            }
                        } else {
                            if (fs[98] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[85] <= 2.5) {
                                        return -0.000325515997852;
                                    } else {
                                        return 0.0261526752428;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.00013827105918;
                                    } else {
                                        return -0.0267288373017;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9993.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0013280999701;
                                    } else {
                                        return 0.0142061436969;
                                    }
                                } else {
                                    if (fs[53] <= -1082.5) {
                                        return 0.206297792856;
                                    } else {
                                        return 0.0399490761928;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[53] <= -1273.5) {
                                if (fs[40] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0570687630598;
                                    } else {
                                        return 0.00457832439131;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.00217778979368;
                                    } else {
                                        return 0.0750461982777;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00538862096144;
                                    } else {
                                        return 0.00234915641851;
                                    }
                                } else {
                                    if (fs[72] <= 9899.5) {
                                        return -0.00549693994612;
                                    } else {
                                        return -0.0125123337488;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 150.0) {
                                if (fs[85] <= 6.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.010150065207;
                                    } else {
                                        return 0.0723445795138;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return 0.145368030589;
                                    } else {
                                        return 0.0541262763037;
                                    }
                                }
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[72] <= 9993.5) {
                                        return -0.000735767293175;
                                    } else {
                                        return -0.0591176086137;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.052993620891;
                                    } else {
                                        return 0.162314022436;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[85] <= 5.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[4] <= 26.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0237706810066;
                                    } else {
                                        return 0.00335158695543;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.00119069066058;
                                    } else {
                                        return 0.0030060816059;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9986.5) {
                                    if (fs[72] <= 9981.5) {
                                        return -0.00252255751309;
                                    } else {
                                        return 0.0499701616815;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.0126540502666;
                                    } else {
                                        return -0.0463998617531;
                                    }
                                }
                            }
                        } else {
                            if (fs[98] <= 1.5) {
                                return 0.299519161553;
                            } else {
                                if (fs[47] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0103673036176;
                                    } else {
                                        return 0.295071466555;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0181234348525;
                                    } else {
                                        return -0.0283993964928;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 5.5) {
                            if (fs[40] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 14.5) {
                                        return -0.0208337138033;
                                    } else {
                                        return -0.00788168803853;
                                    }
                                } else {
                                    if (fs[72] <= 9957.0) {
                                        return -0.00657017865716;
                                    } else {
                                        return -0.06087717703;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.408994053349;
                                    } else {
                                        return 0.121047738521;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0160893069156;
                                    } else {
                                        return -0.0169641436759;
                                    }
                                }
                            }
                        } else {
                            if (fs[40] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.00145029893679;
                                    } else {
                                        return 0.196739437591;
                                    }
                                } else {
                                    if (fs[72] <= 9993.5) {
                                        return -0.00700862677324;
                                    } else {
                                        return -0.0391217276933;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 15.5) {
                                        return -0.0156497364052;
                                    } else {
                                        return 0.0221975480429;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.272380231831;
                                    } else {
                                        return 0.0124510713254;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
