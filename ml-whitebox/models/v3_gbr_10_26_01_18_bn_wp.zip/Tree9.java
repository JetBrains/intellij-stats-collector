/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree9 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[101] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.536863495688;
                                    } else {
                                        return 0.600704254078;
                                    }
                                } else {
                                    return 0.437314932967;
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[27] <= 0.5) {
                                        return 0.49627322294;
                                    } else {
                                        return 0.608431130137;
                                    }
                                } else {
                                    return 0.300070913714;
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[4] <= 8.0) {
                                    if (fs[53] <= -988.0) {
                                        return -0.0534914966449;
                                    } else {
                                        return -0.0400415615379;
                                    }
                                } else {
                                    if (fs[4] <= 59.0) {
                                        return -0.0425810774081;
                                    } else {
                                        return -0.0376032829393;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.0264864606932;
                                    } else {
                                        return 0.106571412575;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.244236558432;
                                    } else {
                                        return -0.0361669328788;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.611135089767;
                                    } else {
                                        return 0.615815497718;
                                    }
                                } else {
                                    return 0.573831445514;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.386756779019;
                                    } else {
                                        return 0.582384814815;
                                    }
                                } else {
                                    return 0.592561830863;
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.55727820128;
                                    } else {
                                        return 0.583559435847;
                                    }
                                } else {
                                    return 0.53620703336;
                                }
                            } else {
                                return 0.0576922618518;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 7.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.595426104622;
                                    } else {
                                        return 0.564268831386;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.59371087343;
                                    } else {
                                        return 0.512933702105;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0378438408941;
                                    } else {
                                        return 0.339447010855;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.146044521067;
                                    } else {
                                        return 0.655735628666;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.414403848586;
                                    } else {
                                        return 0.157955206067;
                                    }
                                } else {
                                    return -0.0853660505815;
                                }
                            } else {
                                if (fs[4] <= 4.0) {
                                    return 0.527304380406;
                                } else {
                                    return 0.789608047126;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[0] <= 0.5) {
                                        return 0.567556154186;
                                    } else {
                                        return -0.0262658127294;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.601556061454;
                                    } else {
                                        return -0.0545821807817;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.2819433778;
                                    } else {
                                        return 0.552346342125;
                                    }
                                } else {
                                    return -0.0527821971621;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.564007206762;
                                    } else {
                                        return 0.602968720409;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return 0.598133535146;
                                    } else {
                                        return 0.608812459758;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return 0.0438137835436;
                                } else {
                                    return -0.0490201252463;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[79] <= 0.5) {
                    if (fs[4] <= 15.5) {
                        if (fs[0] <= 1.5) {
                            return 0.253352089522;
                        } else {
                            return -0.0404479430021;
                        }
                    } else {
                        if (fs[4] <= 39.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 27.0) {
                                        return -0.0254108584706;
                                    } else {
                                        return -0.0762309484958;
                                    }
                                } else {
                                    return 0.037356366063;
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0455119634263;
                                    } else {
                                        return -0.0409117516401;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.0394944683243;
                                    } else {
                                        return -0.0376650808074;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return 0.0717230955646;
                            } else {
                                if (fs[53] <= -1578.0) {
                                    return 0.103429928104;
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0307554875204;
                                    } else {
                                        return -0.0395404769802;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        return 0.284098169419;
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[0] <= 4.5) {
                                    return 0.0474294835459;
                                } else {
                                    if (fs[0] <= 11.5) {
                                        return -0.0127432900968;
                                    } else {
                                        return -0.0442255674001;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return 0.211334366044;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.00355939059227;
                                    } else {
                                        return -0.030363428145;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[4] <= 23.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0548630457278;
                                    } else {
                                        return -0.0507230714794;
                                    }
                                } else {
                                    if (fs[4] <= 31.5) {
                                        return -0.0498084992514;
                                    } else {
                                        return -0.0478502040852;
                                    }
                                }
                            } else {
                                if (fs[4] <= 31.5) {
                                    if (fs[0] <= 9.5) {
                                        return -0.042804554702;
                                    } else {
                                        return -0.0418045131068;
                                    }
                                } else {
                                    return -0.0398780107962;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[72] <= 9996.5) {
                if (fs[0] <= 0.5) {
                    if (fs[97] <= 0.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[89] <= 0.5) {
                                        return 0.403161687276;
                                    } else {
                                        return 0.624024389327;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.050591502655;
                                    } else {
                                        return 0.574192703758;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[67] <= 0.5) {
                                        return 0.299284117986;
                                    } else {
                                        return 0.588354804807;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.248552105824;
                                    } else {
                                        return 0.00248654897852;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[53] <= -1493.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.273680393372;
                                    } else {
                                        return 0.686141525051;
                                    }
                                } else {
                                    if (fs[88] <= 6.0) {
                                        return 0.0482794712604;
                                    } else {
                                        return 0.220313820772;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.323821043855;
                                    } else {
                                        return 0.165956097465;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.362850907918;
                                    } else {
                                        return 0.640710949652;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 13.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[53] <= -987.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.491217429998;
                                    } else {
                                        return 0.564246071052;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return 0.434760043233;
                                    } else {
                                        return 0.201742282065;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.172099839565;
                                    } else {
                                        return 0.520528107268;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0472353459026;
                                    } else {
                                        return 0.22539720035;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.553843993979;
                                    } else {
                                        return 0.151718422045;
                                    }
                                } else {
                                    if (fs[72] <= 9983.0) {
                                        return 0.627624423408;
                                    } else {
                                        return 0.178197356224;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 20.5) {
                                        return 0.510676530007;
                                    } else {
                                        return 0.402727261307;
                                    }
                                } else {
                                    if (fs[4] <= 28.5) {
                                        return 0.413567467291;
                                    } else {
                                        return 0.127716970071;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[88] <= 7.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0398322884317;
                                    } else {
                                        return 0.100085747959;
                                    }
                                } else {
                                    if (fs[2] <= 11.5) {
                                        return -0.036650327562;
                                    } else {
                                        return 0.173111153862;
                                    }
                                }
                            } else {
                                if (fs[88] <= 1.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.0426582747297;
                                    } else {
                                        return 0.156940754931;
                                    }
                                } else {
                                    if (fs[47] <= -12.5) {
                                        return 0.0994270978332;
                                    } else {
                                        return 0.0062288746876;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.114127744958;
                                    } else {
                                        return 0.027772363182;
                                    }
                                } else {
                                    if (fs[47] <= -3.5) {
                                        return 0.0546827715;
                                    } else {
                                        return -0.0253766600798;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0774059769035;
                                    } else {
                                        return 0.398610576257;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.392434066844;
                                    } else {
                                        return 0.609599624858;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 4.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.00957265574415;
                                    } else {
                                        return -0.024232711017;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0410173095939;
                                    } else {
                                        return 0.00320329258047;
                                    }
                                }
                            } else {
                                if (fs[47] <= -10.5) {
                                    if (fs[47] <= -11.5) {
                                        return -0.0322784108855;
                                    } else {
                                        return 0.06671331723;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0369014000702;
                                    } else {
                                        return -0.0401527680226;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[0] <= 8.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0282990351135;
                                    } else {
                                        return -0.00912980525808;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0356182237857;
                                    } else {
                                        return -0.0236111868748;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0397633937571;
                                    } else {
                                        return -0.0389256822195;
                                    }
                                } else {
                                    if (fs[72] <= 9774.5) {
                                        return -0.037782828467;
                                    } else {
                                        return -0.0436974769039;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -436.0) {
                                if (fs[53] <= -1473.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.414930315375;
                                    } else {
                                        return 0.225095274396;
                                    }
                                } else {
                                    if (fs[47] <= -5.5) {
                                        return 0.630832890791;
                                    } else {
                                        return 0.490396919584;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.11606543489;
                                    } else {
                                        return 0.430193976201;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.568039625809;
                                    } else {
                                        return 0.320163421255;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.592460588217;
                                    } else {
                                        return 0.542042239403;
                                    }
                                } else {
                                    return 0.210168779003;
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.487756502789;
                                    } else {
                                        return 0.117809097151;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.681955384838;
                                    } else {
                                        return -0.199199746236;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[92] <= 0.5) {
                                    return 0.691560865426;
                                } else {
                                    if (fs[88] <= 5.0) {
                                        return 0.435940387335;
                                    } else {
                                        return 0.616428931656;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 25.5) {
                                        return 0.270199825538;
                                    } else {
                                        return 0.551629008789;
                                    }
                                } else {
                                    return 0.642438567926;
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1118.5) {
                                        return 0.554041320104;
                                    } else {
                                        return 0.264469803787;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.573507608992;
                                    } else {
                                        return 0.450038759047;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.158326581658;
                                    } else {
                                        return 0.343205538404;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.423124311152;
                                    } else {
                                        return 0.284972935884;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1418.0) {
                        if (fs[47] <= -87.5) {
                            if (fs[47] <= -114.5) {
                                if (fs[4] <= 18.0) {
                                    if (fs[47] <= -138.0) {
                                        return 0.368789247206;
                                    } else {
                                        return -0.107714683571;
                                    }
                                } else {
                                    return -0.123172875979;
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.493944295436;
                                    } else {
                                        return 0.666969305582;
                                    }
                                } else {
                                    return 0.811923671867;
                                }
                            }
                        } else {
                            if (fs[55] <= 546.5) {
                                if (fs[4] <= 34.0) {
                                    if (fs[47] <= -1.5) {
                                        return 0.113931927053;
                                    } else {
                                        return 0.247251057857;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.0744247891028;
                                    } else {
                                        return -0.0680892991654;
                                    }
                                }
                            } else {
                                return 0.742992431225;
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0818586918022;
                                    } else {
                                        return 0.177053196748;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.100937318108;
                                    } else {
                                        return 0.0149802692903;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.192279622436;
                                    } else {
                                        return 0.0871436618101;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.599918012999;
                                    } else {
                                        return 0.404595708711;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1098.0) {
                                if (fs[53] <= -1128.0) {
                                    if (fs[4] <= 6.5) {
                                        return 0.248357550946;
                                    } else {
                                        return 0.0218494270075;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.189444614965;
                                    } else {
                                        return 0.595262236763;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.268304565571;
                                    } else {
                                        return -0.0550913718415;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return -0.0295370247351;
                                    } else {
                                        return 0.0930509861885;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
