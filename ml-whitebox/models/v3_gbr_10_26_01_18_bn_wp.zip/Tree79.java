/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree79 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[53] <= -1498.5) {
                    if (fs[53] <= -1923.5) {
                        if (fs[22] <= 0.5) {
                            if (fs[29] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[64] <= -996.5) {
                                        return -0.108216183253;
                                    } else {
                                        return 0.0666136123474;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.195442034864;
                                    } else {
                                        return 0.0893538645283;
                                    }
                                }
                            } else {
                                return 0.238913557604;
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[47] <= -25.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.240539372745;
                                    } else {
                                        return 0.2840716886;
                                    }
                                } else {
                                    if (fs[72] <= 9996.0) {
                                        return -0.103369409256;
                                    } else {
                                        return 0.1944204707;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.201470121798;
                                    } else {
                                        return 0.114725273816;
                                    }
                                } else {
                                    if (fs[53] <= -2329.0) {
                                        return 0.154292773428;
                                    } else {
                                        return -0.0460188799055;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1903.5) {
                            if (fs[72] <= 9902.0) {
                                if (fs[52] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.155761289484;
                                    } else {
                                        return 0.0575419267012;
                                    }
                                } else {
                                    if (fs[53] <= -1913.5) {
                                        return 0.147185102145;
                                    } else {
                                        return 0.335863987903;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    return 0.181550201942;
                                } else {
                                    if (fs[72] <= 9988.5) {
                                        return -0.115610553283;
                                    } else {
                                        return 0.156196135765;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[47] <= -5.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.00104972667391;
                                    } else {
                                        return 0.0896018781877;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.133286886042;
                                    } else {
                                        return -0.089558129244;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0338068748464;
                                    } else {
                                        return -0.0788123005929;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.117318384392;
                                    } else {
                                        return 0.0401451684684;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -1483.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[47] <= -1356.5) {
                                    if (fs[47] <= -3550.5) {
                                        return 0.160843056223;
                                    } else {
                                        return 0.0529817648604;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.00851392804392;
                                    } else {
                                        return -0.0855307963982;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[47] <= -27.5) {
                                        return 0.127056011275;
                                    } else {
                                        return -0.0255627547353;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.0217108936807;
                                    } else {
                                        return 0.120965416804;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -987.5) {
                                if (fs[88] <= 2.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0248610786116;
                                    } else {
                                        return -0.00876592814825;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.119164555168;
                                    } else {
                                        return -0.103755473237;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.0155653137529;
                                    } else {
                                        return -0.0916248524068;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return 0.00116485094178;
                                    } else {
                                        return 0.0904798337306;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[8] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[2] <= 5.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0256106458115;
                                    } else {
                                        return 0.00912802391574;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.0487432208382;
                                    } else {
                                        return 0.000306048969133;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[47] <= -365.0) {
                                        return 0.0749500775712;
                                    } else {
                                        return -0.0355325147473;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.226377372163;
                                    } else {
                                        return 0.00336075999694;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[76] <= 250.0) {
                                    if (fs[53] <= -456.5) {
                                        return -0.293487443432;
                                    } else {
                                        return -0.498145756775;
                                    }
                                } else {
                                    return -0.108365989918;
                                }
                            } else {
                                return 0.288316975142;
                            }
                        }
                    }
                }
            } else {
                if (fs[101] <= 0.5) {
                    if (fs[59] <= 0.5) {
                        if (fs[72] <= 9788.0) {
                            if (fs[64] <= -995.5) {
                                if (fs[4] <= 22.5) {
                                    return 0.343800127406;
                                } else {
                                    return -0.116740157342;
                                }
                            } else {
                                if (fs[2] <= 10.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.11641751704;
                                    } else {
                                        return 0.0246930755295;
                                    }
                                } else {
                                    return 0.300238530247;
                                }
                            }
                        } else {
                            if (fs[4] <= 20.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.141252178336;
                                    } else {
                                        return 0.0825060088701;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.395450765596;
                                    } else {
                                        return -0.240634543455;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9996.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.308793029465;
                                    } else {
                                        return 0.0396856575631;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.114944716951;
                                    } else {
                                        return -0.344695008456;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[70] <= -1.5) {
                            if (fs[4] <= 29.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.0798711162536;
                                    } else {
                                        return -0.0830980503778;
                                    }
                                } else {
                                    if (fs[4] <= 28.5) {
                                        return 0.0442611785287;
                                    } else {
                                        return 0.160345630324;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[53] <= -1488.0) {
                                        return -0.104889419353;
                                    } else {
                                        return -0.321688367979;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0980532113592;
                                    } else {
                                        return -0.150414262616;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9260.0) {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 22.5) {
                                        return -0.147478056895;
                                    } else {
                                        return -0.123964784677;
                                    }
                                } else {
                                    return -0.17808640887;
                                }
                            } else {
                                return 0.0184918800841;
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 0.5) {
                        if (fs[53] <= -1478.0) {
                            if (fs[47] <= -36.5) {
                                if (fs[53] <= -1978.0) {
                                    return 0.0641074619203;
                                } else {
                                    if (fs[47] <= -94.5) {
                                        return -0.111163138811;
                                    } else {
                                        return -0.39584967331;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1988.0) {
                                    if (fs[76] <= 75.0) {
                                        return 0.108013472726;
                                    } else {
                                        return 0.0301042221768;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.0488803017745;
                                    } else {
                                        return -0.0678066749224;
                                    }
                                }
                            }
                        } else {
                            if (fs[101] <= 1.5) {
                                if (fs[49] <= -2.5) {
                                    return 0.191920103997;
                                } else {
                                    if (fs[4] <= 36.5) {
                                        return -0.0512304876965;
                                    } else {
                                        return 0.304348672317;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0599119142256;
                                    } else {
                                        return 0.22435990232;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0917706064518;
                                    } else {
                                        return 0.00944972344738;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.384485589258;
                    }
                }
            }
        } else {
            if (fs[0] <= 3.5) {
                if (fs[18] <= -0.5) {
                    if (fs[88] <= 7.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[72] <= 9877.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[47] <= -89.5) {
                                        return -0.0309697102246;
                                    } else {
                                        return -0.0548112050362;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.0112746152466;
                                    } else {
                                        return -0.0436040597718;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.119801584487;
                                    } else {
                                        return -0.0930378040583;
                                    }
                                } else {
                                    return -0.192902010079;
                                }
                            }
                        } else {
                            if (fs[72] <= 9984.0) {
                                if (fs[2] <= 4.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.160672998169;
                                    } else {
                                        return -0.0831719521057;
                                    }
                                } else {
                                    return -0.00417288361849;
                                }
                            } else {
                                return -0.196571203967;
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            return -0.180861004535;
                        } else {
                            return -0.23729768343;
                        }
                    }
                } else {
                    if (fs[47] <= -12.5) {
                        if (fs[53] <= -1418.0) {
                            if (fs[4] <= 11.5) {
                                if (fs[88] <= 1.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0422243282359;
                                    } else {
                                        return -0.0144551116889;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0148705462219;
                                    } else {
                                        return 0.0828294915502;
                                    }
                                }
                            } else {
                                if (fs[88] <= 5.0) {
                                    if (fs[94] <= 0.5) {
                                        return 0.0137811803096;
                                    } else {
                                        return 0.191147214274;
                                    }
                                } else {
                                    if (fs[47] <= -586.5) {
                                        return -0.0672210248951;
                                    } else {
                                        return -0.0373480587585;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -1.5) {
                                return 0.375876856243;
                            } else {
                                if (fs[47] <= -17.5) {
                                    if (fs[24] <= 0.5) {
                                        return -0.0132927240529;
                                    } else {
                                        return 0.0590013917915;
                                    }
                                } else {
                                    if (fs[64] <= -498.0) {
                                        return -0.0712236662268;
                                    } else {
                                        return 0.0394136289494;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0208098920408;
                                    } else {
                                        return -0.0014314164314;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.00368902264356;
                                    } else {
                                        return 0.0110180694682;
                                    }
                                }
                            } else {
                                if (fs[53] <= -991.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.00240907883545;
                                    } else {
                                        return -0.00797669792044;
                                    }
                                } else {
                                    if (fs[72] <= 9357.0) {
                                        return -0.0174914605957;
                                    } else {
                                        return -0.0496494797295;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[2] <= 17.5) {
                                        return -0.122993566386;
                                    } else {
                                        return -0.144292233662;
                                    }
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return 0.0663060657385;
                                    } else {
                                        return -0.0689599347371;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[47] <= -5.5) {
                                        return 0.110566762019;
                                    } else {
                                        return 0.0114069328382;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0515626117277;
                                    } else {
                                        return 0.30544239569;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[28] <= 0.5) {
                    if (fs[47] <= -6607.5) {
                        if (fs[78] <= 0.5) {
                            return 0.190284163378;
                        } else {
                            if (fs[47] <= -14138.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[72] <= 9981.0) {
                                        return -0.0312754770885;
                                    } else {
                                        return -0.139695357688;
                                    }
                                } else {
                                    return -0.0834001582926;
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.197823649206;
                                    } else {
                                        return 0.0672441212319;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0443461924184;
                                    } else {
                                        return -0.0164982904528;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[94] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.00221912661376;
                                    } else {
                                        return -0.00404436887261;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.000698342274181;
                                    } else {
                                        return -0.0015406026691;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9998.5) {
                                    if (fs[53] <= -57.0) {
                                        return -0.000947180283649;
                                    } else {
                                        return 0.00131009764529;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0529428684244;
                                    } else {
                                        return 0.0560914101901;
                                    }
                                }
                            }
                        } else {
                            if (fs[90] <= 0.5) {
                                if (fs[47] <= -13.5) {
                                    if (fs[47] <= -31.5) {
                                        return 0.017789857109;
                                    } else {
                                        return 0.111197126356;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return -0.000254489944866;
                                    } else {
                                        return 0.0494429400437;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[4] <= 23.0) {
                                        return 0.650321897997;
                                    } else {
                                        return -0.0574892914508;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0387331885133;
                                    } else {
                                        return -0.049653853216;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[101] <= 0.5) {
                        if (fs[2] <= 5.5) {
                            if (fs[72] <= 9997.0) {
                                if (fs[0] <= 23.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.00677615154475;
                                    } else {
                                        return 0.0048268565484;
                                    }
                                } else {
                                    if (fs[0] <= 26.5) {
                                        return 0.00999939070533;
                                    } else {
                                        return -0.0050898290029;
                                    }
                                }
                            } else {
                                return -0.178303659676;
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[0] <= 7.5) {
                                    return -0.0662155048073;
                                } else {
                                    return -0.0321491354944;
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0324811968743;
                                    } else {
                                        return -0.0210721521201;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return -0.00895266484234;
                                    } else {
                                        return -0.0149657289475;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[90] <= 0.5) {
                            if (fs[47] <= -44.5) {
                                if (fs[0] <= 6.5) {
                                    return -0.0572518114382;
                                } else {
                                    if (fs[47] <= -120.0) {
                                        return -0.0329763261538;
                                    } else {
                                        return -0.0229551636802;
                                    }
                                }
                            } else {
                                if (fs[76] <= 100.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0485653428343;
                                    } else {
                                        return -0.0149318952382;
                                    }
                                } else {
                                    return -0.0473192389008;
                                }
                            }
                        } else {
                            if (fs[53] <= -1303.0) {
                                if (fs[97] <= 0.5) {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0756347914706;
                                    } else {
                                        return -0.0828282524846;
                                    }
                                } else {
                                    return -0.111005260696;
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    return -0.0344181699546;
                                } else {
                                    return -0.0163755996578;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
