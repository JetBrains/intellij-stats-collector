/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree65 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[0] <= 1.5) {
                    if (fs[53] <= -1138.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.00535590775404;
                                    } else {
                                        return 0.0632402528941;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.00511596242177;
                                    } else {
                                        return -0.102071754571;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0757069470539;
                                    } else {
                                        return 0.0182207728259;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.127791847067;
                                    } else {
                                        return 0.0436837293744;
                                    }
                                }
                            }
                        } else {
                            if (fs[6] <= 0.5) {
                                return 0.14550027976;
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0265473316213;
                                    } else {
                                        return 0.0404038820048;
                                    }
                                } else {
                                    return -0.0621297341986;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -988.0) {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0634007259051;
                                    } else {
                                        return 0.0442604770262;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0226263708252;
                                    } else {
                                        return 0.166221473665;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.0284236511189;
                                    } else {
                                        return 0.0354116258793;
                                    }
                                } else {
                                    return -0.0230388967443;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0695719559084;
                                    } else {
                                        return 0.0162876900294;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.163551702331;
                                    } else {
                                        return 0.0580092021549;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0555067598385;
                                    } else {
                                        return -0.15478390517;
                                    }
                                } else {
                                    if (fs[72] <= 5000.0) {
                                        return 0.0125085427539;
                                    } else {
                                        return 0.0640612843209;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 2.5) {
                        if (fs[53] <= -1068.0) {
                            return 0.18257253106;
                        } else {
                            return -0.149779049393;
                        }
                    } else {
                        if (fs[60] <= 0.5) {
                            if (fs[53] <= -1053.0) {
                                if (fs[25] <= 0.5) {
                                    return 0.0777439643166;
                                } else {
                                    return -0.0862688259751;
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0449045614376;
                                    } else {
                                        return -0.107644730608;
                                    }
                                } else {
                                    return -0.0285851040234;
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return -0.0757927264389;
                                    } else {
                                        return -0.00161956066279;
                                    }
                                } else {
                                    if (fs[0] <= 24.5) {
                                        return 0.0184973616207;
                                    } else {
                                        return 0.0938874096478;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0137894392218;
                                    } else {
                                        return 0.0399213929232;
                                    }
                                } else {
                                    return 0.143480168276;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[71] <= 0.5) {
                        if (fs[53] <= -1328.0) {
                            if (fs[4] <= 31.0) {
                                if (fs[53] <= -1578.0) {
                                    if (fs[4] <= 25.5) {
                                        return -0.0924853846563;
                                    } else {
                                        return -0.213328887013;
                                    }
                                } else {
                                    return -0.0687294643909;
                                }
                            } else {
                                if (fs[4] <= 40.5) {
                                    return 0.0931442996919;
                                } else {
                                    return -0.132142361164;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.114882191347;
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0407322910605;
                                    } else {
                                        return 0.0254921650856;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.0704041828104;
                                    } else {
                                        return 0.0157787219715;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[30] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                return -0.0757148495116;
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return 0.0819565985308;
                                } else {
                                    return 0.0441549635392;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                return -0.157240865171;
                            } else {
                                return 0.0619688487293;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[70] <= -1.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[0] <= 1.5) {
                                        return -0.034003202101;
                                    } else {
                                        return -0.0431115468287;
                                    }
                                } else {
                                    if (fs[53] <= -1053.0) {
                                        return -0.0277540536287;
                                    } else {
                                        return -0.0241404892694;
                                    }
                                }
                            } else {
                                return -0.0472853854723;
                            }
                        } else {
                            return 0.0515857040217;
                        }
                    } else {
                        if (fs[4] <= 12.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[53] <= -1128.0) {
                                    if (fs[78] <= 0.5) {
                                        return -0.00828298105152;
                                    } else {
                                        return -0.0160243311835;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.020039601296;
                                    } else {
                                        return 0.076349492657;
                                    }
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.0216360401463;
                                    } else {
                                        return -0.0298289035196;
                                    }
                                } else {
                                    return 0.0365279262663;
                                }
                            }
                        } else {
                            if (fs[4] <= 13.5) {
                                return 0.147444251309;
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[72] <= 4847.0) {
                                        return -0.0131113902737;
                                    } else {
                                        return 0.0399872360423;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.004214242572;
                                    } else {
                                        return 0.00583210467873;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[11] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[28] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[4] <= 16.5) {
                                    if (fs[72] <= 4853.0) {
                                        return 0.137379223933;
                                    } else {
                                        return 0.0743109242467;
                                    }
                                } else {
                                    if (fs[47] <= -4.5) {
                                        return 0.151199648182;
                                    } else {
                                        return 0.0109833647359;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.0472474690764;
                                    } else {
                                        return 0.229096498876;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.0357000610742;
                                    } else {
                                        return 0.100324575478;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -17.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0934508947238;
                                    } else {
                                        return -0.0982038569288;
                                    }
                                } else {
                                    return -0.183380489704;
                                }
                            } else {
                                if (fs[64] <= -995.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0881611108552;
                                    } else {
                                        return 0.0446852562907;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.0160669347098;
                                    } else {
                                        return 0.0405848986559;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 1.0) {
                            if (fs[47] <= -12.5) {
                                return -0.210967342624;
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.12706675691;
                                    } else {
                                        return -0.18984393756;
                                    }
                                } else {
                                    return -0.1730763174;
                                }
                            }
                        } else {
                            if (fs[47] <= -3.0) {
                                return -0.376933452144;
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.315661350893;
                                    } else {
                                        return -0.452753803288;
                                    }
                                } else {
                                    if (fs[4] <= 6.0) {
                                        return 0.155062284043;
                                    } else {
                                        return -0.341778452606;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[101] <= 0.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[72] <= 9993.5) {
                                        return -0.00308971188756;
                                    } else {
                                        return 0.0408015661049;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0165761914929;
                                    } else {
                                        return 0.049825090158;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.00942900702669;
                                    } else {
                                        return 0.0627681961911;
                                    }
                                } else {
                                    if (fs[0] <= 43.5) {
                                        return 0.0339021153572;
                                    } else {
                                        return 0.407915762422;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9989.5) {
                                if (fs[47] <= -2.5) {
                                    if (fs[53] <= -1093.0) {
                                        return 0.0614714382218;
                                    } else {
                                        return -0.000569506359584;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.00488878238721;
                                    } else {
                                        return -0.00118176288094;
                                    }
                                }
                            } else {
                                if (fs[47] <= -50.0) {
                                    if (fs[4] <= 12.5) {
                                        return 0.0485122477642;
                                    } else {
                                        return 0.223275525794;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.023941178822;
                                    } else {
                                        return -0.0349758584957;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 3.5) {
                            if (fs[53] <= -1398.0) {
                                if (fs[48] <= 0.5) {
                                    if (fs[47] <= -8.5) {
                                        return 0.0343070145531;
                                    } else {
                                        return -0.0274903238331;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return 0.109298382906;
                                    } else {
                                        return 0.0456319391568;
                                    }
                                }
                            } else {
                                if (fs[47] <= -5.5) {
                                    if (fs[47] <= -9.5) {
                                        return 0.0011726537752;
                                    } else {
                                        return -0.0508400875315;
                                    }
                                } else {
                                    if (fs[72] <= 9977.5) {
                                        return 0.0173167036237;
                                    } else {
                                        return -0.0339800855587;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[47] <= -5.5) {
                                    if (fs[29] <= 0.5) {
                                        return -0.0148037013264;
                                    } else {
                                        return 0.0373574272419;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return -0.00438222552758;
                                    } else {
                                        return -0.0351264406231;
                                    }
                                }
                            } else {
                                if (fs[0] <= 114.0) {
                                    if (fs[45] <= 0.5) {
                                        return 0.00853187336831;
                                    } else {
                                        return -0.0039670951089;
                                    }
                                } else {
                                    return 0.448681870661;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[34] <= 0.5) {
                    if (fs[47] <= -251.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[76] <= 250.0) {
                                if (fs[4] <= 19.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.0590430751773;
                                    } else {
                                        return 0.141648908443;
                                    }
                                } else {
                                    return 0.398983145842;
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[47] <= -3438.5) {
                                        return 0.268892269481;
                                    } else {
                                        return -0.218533401386;
                                    }
                                } else {
                                    return -0.445785879937;
                                }
                            }
                        } else {
                            if (fs[53] <= -1418.0) {
                                if (fs[101] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return 0.05978280895;
                                    } else {
                                        return 0.299871026991;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.013258939965;
                                    } else {
                                        return 0.018044435067;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.00467243671937;
                                    } else {
                                        return 0.263443118883;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0116452030354;
                                    } else {
                                        return -0.0272760863623;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[26] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.00671302637415;
                                    } else {
                                        return 0.042394887992;
                                    }
                                } else {
                                    if (fs[53] <= -1468.5) {
                                        return 0.116778584627;
                                    } else {
                                        return 0.00342002089742;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.00108593826438;
                                    } else {
                                        return -0.00279981189843;
                                    }
                                } else {
                                    if (fs[53] <= -2458.0) {
                                        return 0.0975801435075;
                                    } else {
                                        return -0.00662857058209;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0850544945001;
                                    } else {
                                        return -0.128839633334;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.108466476451;
                                    } else {
                                        return 0.0347315521234;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.00173538273336;
                                    } else {
                                        return 0.111929883366;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.115160768181;
                                    } else {
                                        return 0.0146149019072;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1042.0) {
                        if (fs[4] <= 15.0) {
                            if (fs[4] <= 8.5) {
                                if (fs[47] <= -0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.217901443847;
                                    } else {
                                        return 0.100830337113;
                                    }
                                } else {
                                    return -0.113060941992;
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[47] <= -9.5) {
                                        return 0.376668018224;
                                    } else {
                                        return 0.289975391774;
                                    }
                                } else {
                                    return 0.140648345951;
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                return 0.257117884909;
                            } else {
                                if (fs[0] <= 1.5) {
                                    return -0.15313112133;
                                } else {
                                    return -0.0227337466319;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[72] <= 4969.5) {
                                return 0.055760807294;
                            } else {
                                return 0.526781363732;
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.0973160008016;
                                    } else {
                                        return -0.0803451496423;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.046583790707;
                                    } else {
                                        return -0.0202245535361;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9870.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0135627385171;
                                    } else {
                                        return -0.00757397285218;
                                    }
                                } else {
                                    return -0.0486243944155;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
