/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree24 {
    public double calcTree(double... fs) {
        if (fs[4] <= 7.5) {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[53] <= -1039.0) {
                        if (fs[53] <= -1138.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[53] <= -1483.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0470755714965;
                                    } else {
                                        return 0.240678460635;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.228216527554;
                                    } else {
                                        return 0.132438962728;
                                    }
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.362410106754;
                                    } else {
                                        return 0.246121882423;
                                    }
                                } else {
                                    return -0.108577742351;
                                }
                            }
                        } else {
                            if (fs[53] <= -1123.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[47] <= -18.5) {
                                        return 0.396064847005;
                                    } else {
                                        return 0.258399376945;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.310815910708;
                                    } else {
                                        return 0.30059535521;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.3112891433;
                                    } else {
                                        return 0.133248994489;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.20534929206;
                                    } else {
                                        return -0.132435194856;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[47] <= -21752.5) {
                                return 0.568578122295;
                            } else {
                                if (fs[88] <= 7.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0331133193214;
                                    } else {
                                        return 0.118468661966;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.40358687237;
                                    } else {
                                        return 0.0543942242095;
                                    }
                                }
                            }
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[70] <= -4.0) {
                                        return 0.170857317447;
                                    } else {
                                        return 0.258361434477;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0930381359596;
                                    } else {
                                        return -0.0137206713735;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9995.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.141777967391;
                                    } else {
                                        return -0.0619237199367;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.268611733742;
                                    } else {
                                        return 0.147820422042;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[41] <= 0.5) {
                        if (fs[88] <= -0.5) {
                            if (fs[11] <= 0.5) {
                                return 0.327789611943;
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[53] <= -1473.5) {
                                        return -0.121837995233;
                                    } else {
                                        return 0.135094292974;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.165945515856;
                                    } else {
                                        return -0.303124487731;
                                    }
                                }
                            }
                        } else {
                            if (fs[74] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.292016430779;
                                    } else {
                                        return 0.261037129725;
                                    }
                                } else {
                                    if (fs[53] <= -1308.0) {
                                        return -0.0812556501735;
                                    } else {
                                        return 0.443202799024;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9902.0) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0330797646413;
                                    } else {
                                        return 0.249937469849;
                                    }
                                } else {
                                    if (fs[72] <= 9970.5) {
                                        return 0.360234625256;
                                    } else {
                                        return 0.297739260426;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -81.5) {
                            if (fs[88] <= 3.0) {
                                if (fs[4] <= 5.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.000650314993702;
                                    } else {
                                        return -0.0548598121001;
                                    }
                                } else {
                                    return 0.301788215793;
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0184784112731;
                                    } else {
                                        return 0.353202350312;
                                    }
                                } else {
                                    return 0.373630010587;
                                }
                            }
                        } else {
                            if (fs[76] <= 150.0) {
                                if (fs[85] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0676897173236;
                                    } else {
                                        return 0.239073668643;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0583991863907;
                                    } else {
                                        return 0.108272505191;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.265516708565;
                                    } else {
                                        return 0.456930017114;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.180889422836;
                                    } else {
                                        return 0.0107827779666;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[53] <= -1488.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.17389416808;
                                    } else {
                                        return 0.013932287177;
                                    }
                                } else {
                                    if (fs[47] <= -66.5) {
                                        return 0.303827099818;
                                    } else {
                                        return 0.12585445908;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.102963625049;
                                    } else {
                                        return -0.137280209226;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.303276515622;
                                    } else {
                                        return 0.389087712342;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 7.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[90] <= 0.5) {
                                        return 0.00387274074602;
                                    } else {
                                        return 0.371249270497;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.12922744474;
                                    } else {
                                        return 0.344195762696;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.355718750883;
                                    } else {
                                        return -0.29941977975;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.225917982301;
                                    } else {
                                        return -0.057812583776;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[81] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0618548689218;
                                    } else {
                                        return -0.0438966059271;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0944921449895;
                                    } else {
                                        return 0.437356262248;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0610749417748;
                                    } else {
                                        return 0.0216063826797;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return 0.672917604082;
                                    } else {
                                        return 0.00177838073395;
                                    }
                                }
                            }
                        } else {
                            if (fs[101] <= 1.5) {
                                if (fs[72] <= 9922.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.00481295650392;
                                    } else {
                                        return 0.0619363271542;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.169884875508;
                                    } else {
                                        return 0.0524270854896;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[53] <= -1132.5) {
                                        return 0.126269215557;
                                    } else {
                                        return 0.00542288682899;
                                    }
                                } else {
                                    if (fs[53] <= -21.0) {
                                        return 0.000882114114937;
                                    } else {
                                        return 0.0472682651512;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 25.0) {
                        if (fs[23] <= 0.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return -0.03857858215;
                                    } else {
                                        return -0.0177156947862;
                                    }
                                } else {
                                    return 0.599584327443;
                                }
                            } else {
                                if (fs[0] <= 10.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.338315022252;
                                    } else {
                                        return 0.0680506617241;
                                    }
                                } else {
                                    if (fs[0] <= 39.5) {
                                        return 0.02355913636;
                                    } else {
                                        return -0.100584689172;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[53] <= -1053.0) {
                                    if (fs[70] <= -4.0) {
                                        return -0.0172253089503;
                                    } else {
                                        return 0.223624408333;
                                    }
                                } else {
                                    if (fs[88] <= 3.0) {
                                        return -0.0199083546272;
                                    } else {
                                        return 0.157129162547;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.192306656301;
                                    } else {
                                        return 0.00265883653568;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return 0.00763102277283;
                                    } else {
                                        return -0.014240320061;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[47] <= -367.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.0900234082763;
                                    } else {
                                        return 0.212270955425;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0202948498289;
                                    } else {
                                        return 0.148134783166;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0631782860011;
                                    } else {
                                        return 0.00308714780584;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.0427837496062;
                                    } else {
                                        return 0.161417462334;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[72] <= 9587.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.0230925122936;
                                    } else {
                                        return -0.0287977083064;
                                    }
                                } else {
                                    if (fs[47] <= -1762.0) {
                                        return -0.0557943858251;
                                    } else {
                                        return -0.0283120961475;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[103] <= 1.5) {
                                        return -0.0282968402543;
                                    } else {
                                        return -0.0221266500343;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0199651238261;
                                    } else {
                                        return -0.0186499978348;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[101] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[25] <= 0.5) {
                        if (fs[24] <= 0.5) {
                            if (fs[72] <= 9985.5) {
                                if (fs[2] <= 5.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0858724486308;
                                    } else {
                                        return -0.0168328524938;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.248617807031;
                                    } else {
                                        return -0.129681128347;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.342160908017;
                                    } else {
                                        return 0.129874616203;
                                    }
                                } else {
                                    if (fs[47] <= -7.5) {
                                        return 0.265361150983;
                                    } else {
                                        return 0.138147894164;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 7.5) {
                                if (fs[72] <= 9817.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0128734259763;
                                    } else {
                                        return 0.250084162729;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.222904547907;
                                    } else {
                                        return 0.302291746573;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[47] <= -11.5) {
                                        return 0.422078799968;
                                    } else {
                                        return 0.448252770151;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.37329415873;
                                    } else {
                                        return 0.258074598009;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[53] <= -1503.5) {
                                if (fs[4] <= 27.5) {
                                    return 0.42549813351;
                                } else {
                                    return 0.462954238527;
                                }
                            } else {
                                if (fs[53] <= -490.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.312469134205;
                                    } else {
                                        return 0.4290085792;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.394102120868;
                                    } else {
                                        return 0.216620795948;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1123.0) {
                                if (fs[85] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.117592668255;
                                    } else {
                                        return 0.387488559056;
                                    }
                                } else {
                                    return -0.111679868003;
                                }
                            } else {
                                return -0.190710037916;
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9982.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[88] <= 4.5) {
                                        return 0.0384417946845;
                                    } else {
                                        return -0.019037233225;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0425273813804;
                                    } else {
                                        return 0.159419217843;
                                    }
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    if (fs[53] <= -1438.0) {
                                        return 0.00653857851845;
                                    } else {
                                        return -0.0111007404967;
                                    }
                                } else {
                                    if (fs[53] <= -1468.0) {
                                        return -0.00351581525103;
                                    } else {
                                        return -0.0178091900695;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0393623803599;
                                    } else {
                                        return -0.0213835750114;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.0162105271733;
                                    } else {
                                        return -0.0182530364574;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.00741578809717;
                                    } else {
                                        return 0.235882250299;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0137926284535;
                                    } else {
                                        return 0.00811671215524;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -966.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[47] <= -3146.5) {
                                        return 0.41833670303;
                                    } else {
                                        return 0.613210637706;
                                    }
                                } else {
                                    return 0.126379516613;
                                }
                            } else {
                                if (fs[47] <= -1006.0) {
                                    if (fs[53] <= -1293.0) {
                                        return 0.102065941725;
                                    } else {
                                        return -0.0147441660938;
                                    }
                                } else {
                                    return 0.624454469215;
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0613147749808;
                                    } else {
                                        return 0.0165337347103;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return -0.00639179917974;
                                    } else {
                                        return 0.176917609204;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1428.0) {
                                    if (fs[4] <= 11.5) {
                                        return 0.28077820011;
                                    } else {
                                        return 0.0699487929965;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0840332400445;
                                    } else {
                                        return -0.0161321133726;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[103] <= 1.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[53] <= -1598.0) {
                                    if (fs[83] <= 0.5) {
                                        return 0.328134952275;
                                    } else {
                                        return 0.172042185003;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.22892280572;
                                    } else {
                                        return 0.0986600865534;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.223354028168;
                                    } else {
                                        return 0.38414669927;
                                    }
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return 0.31291258681;
                                    } else {
                                        return 0.123939060846;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.250745540399;
                                    } else {
                                        return 0.086256327714;
                                    }
                                } else {
                                    if (fs[53] <= -1578.0) {
                                        return -0.223945156093;
                                    } else {
                                        return 0.0318608176094;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return -0.385271097021;
                                } else {
                                    return -0.0960607968259;
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9985.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0489098390997;
                                    } else {
                                        return 0.00609551322249;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0242041600045;
                                    } else {
                                        return 0.0424930055932;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[4] <= 17.5) {
                                        return -0.00963972862628;
                                    } else {
                                        return -0.0179556770884;
                                    }
                                } else {
                                    if (fs[72] <= 9862.5) {
                                        return -0.0191273916952;
                                    } else {
                                        return -0.0262549529343;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[53] <= -1058.0) {
                                        return 0.106290363814;
                                    } else {
                                        return -0.0230348595283;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0114356383906;
                                    } else {
                                        return 0.177572908136;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 19.5) {
                                        return -0.0228536652715;
                                    } else {
                                        return -0.015577694902;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.0216441295952;
                                    } else {
                                        return 0.15628520316;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1033.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.252757731599;
                                    } else {
                                        return -0.0551537114308;
                                    }
                                } else {
                                    if (fs[64] <= -995.5) {
                                        return 0.325851807116;
                                    } else {
                                        return 0.106912482555;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    return -0.271506063285;
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.112572988964;
                                    } else {
                                        return 0.000975154389295;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.452333394366;
                                    } else {
                                        return 0.204644388845;
                                    }
                                } else {
                                    if (fs[64] <= -994.5) {
                                        return 0.315263639173;
                                    } else {
                                        return 0.0736428601985;
                                    }
                                }
                            } else {
                                if (fs[2] <= 7.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.047427752442;
                                    } else {
                                        return 0.00783351475838;
                                    }
                                } else {
                                    return 0.222179830802;
                                }
                            }
                        }
                    } else {
                        if (fs[70] <= -4.0) {
                            return 0.133501966974;
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[49] <= -1.5) {
                                    return 0.386731896544;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.00290205706598;
                                    } else {
                                        return 0.168240040475;
                                    }
                                }
                            } else {
                                if (fs[62] <= -1.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0115952838168;
                                    } else {
                                        return 0.0103702604534;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0316626107914;
                                    } else {
                                        return -0.0184263656243;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
