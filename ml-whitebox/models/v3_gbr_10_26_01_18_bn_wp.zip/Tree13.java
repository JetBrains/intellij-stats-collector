/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree13 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[97] <= 0.5) {
                if (fs[30] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.377932561813;
                                    } else {
                                        return 0.404852240566;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.42143506697;
                                    } else {
                                        return 0.0894174367483;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.456614708421;
                                    } else {
                                        return 0.481254271866;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.280558752657;
                                    } else {
                                        return 0.00856995441827;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[53] <= -1504.0) {
                                    if (fs[48] <= 0.5) {
                                        return 0.481635561791;
                                    } else {
                                        return 0.332178924301;
                                    }
                                } else {
                                    if (fs[53] <= -1483.5) {
                                        return 0.118117179093;
                                    } else {
                                        return 0.235363132049;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.331228454576;
                                    } else {
                                        return 0.406933575943;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.104104179136;
                                    } else {
                                        return 0.434701039131;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.0644057881276;
                                    } else {
                                        return -0.00400735602673;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0581660820132;
                                    } else {
                                        return 0.0164896046959;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.148381399894;
                                    } else {
                                        return -0.000697058928929;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0753611015116;
                                    } else {
                                        return 0.515758260871;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 7.5) {
                                if (fs[47] <= -7.5) {
                                    if (fs[53] <= -1428.5) {
                                        return 0.018955620676;
                                    } else {
                                        return -0.0140323218273;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.015579010699;
                                    } else {
                                        return -0.0274623027647;
                                    }
                                }
                            } else {
                                if (fs[0] <= 20.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0279636561417;
                                    } else {
                                        return -0.0176072861482;
                                    }
                                } else {
                                    if (fs[47] <= -41427.0) {
                                        return 0.160157823934;
                                    } else {
                                        return -0.0300551596399;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[53] <= -1128.0) {
                                    if (fs[4] <= 5.5) {
                                        return 0.458576110122;
                                    } else {
                                        return 0.414363167027;
                                    }
                                } else {
                                    if (fs[53] <= -1098.5) {
                                        return 0.505133113989;
                                    } else {
                                        return 0.394973242131;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.0) {
                                    return 0.540861918277;
                                } else {
                                    return 0.569775269848;
                                }
                            }
                        } else {
                            return 0.0907775359802;
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[60] <= 0.5) {
                                    return 0.488868583282;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.489562255253;
                                    } else {
                                        return 0.480115410516;
                                    }
                                }
                            } else {
                                return 0.58038489335;
                            }
                        } else {
                            return 0.348372598788;
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[48] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[49] <= -1.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.612514132949;
                                    } else {
                                        return 0.578889812382;
                                    }
                                } else {
                                    return 0.567355285122;
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[47] <= -8.5) {
                                        return 0.519281106257;
                                    } else {
                                        return 0.283505082773;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return 0.416331762545;
                                    } else {
                                        return 0.601599041188;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[72] <= 9991.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.34602817313;
                                    } else {
                                        return 0.519782634211;
                                    }
                                } else {
                                    return 0.13687313205;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[53] <= -1493.5) {
                                        return 0.49178761991;
                                    } else {
                                        return 0.111568936336;
                                    }
                                } else {
                                    if (fs[47] <= -6.5) {
                                        return 0.334772164656;
                                    } else {
                                        return 0.215009670553;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 20.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.426382811884;
                                    } else {
                                        return 0.46453942286;
                                    }
                                } else {
                                    if (fs[53] <= -1493.5) {
                                        return 0.528404828266;
                                    } else {
                                        return 0.393039712247;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.216367494582;
                                    } else {
                                        return -0.107724739573;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.204518740992;
                                    } else {
                                        return -0.053115521663;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9995.5) {
                                if (fs[53] <= -1978.0) {
                                    if (fs[53] <= -2978.0) {
                                        return 0.479298071659;
                                    } else {
                                        return 0.577188887719;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.194351001446;
                                    } else {
                                        return 0.36291666779;
                                    }
                                }
                            } else {
                                return -0.333108927547;
                            }
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[53] <= -1948.0) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0553655289304;
                                    } else {
                                        return 0.376426835143;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.129498660137;
                                    } else {
                                        return 0.0671299803315;
                                    }
                                }
                            } else {
                                if (fs[0] <= 75.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.00745216112537;
                                    } else {
                                        return 0.35865145481;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0244258843599;
                                    } else {
                                        return 0.666370877612;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0271355046558;
                                    } else {
                                        return 0.0401338187507;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return -0.0368473464617;
                                    } else {
                                        return 0.0992935138698;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.0282759834308;
                                    } else {
                                        return 0.0127003920982;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0212908495392;
                                    } else {
                                        return 0.232043222218;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= -2.5) {
                            if (fs[53] <= -456.5) {
                                if (fs[64] <= -996.5) {
                                    return 0.14938613905;
                                } else {
                                    if (fs[58] <= 0.5) {
                                        return -0.0438163300359;
                                    } else {
                                        return 0.0775478832664;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    return -0.0489273964079;
                                } else {
                                    return -0.0351512455069;
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[103] <= 1.5) {
                                        return -0.0411463701745;
                                    } else {
                                        return -0.0323731769436;
                                    }
                                } else {
                                    return 0.173254209207;
                                }
                            } else {
                                if (fs[72] <= 9703.5) {
                                    if (fs[26] <= 0.5) {
                                        return -0.0322889925219;
                                    } else {
                                        return -0.0307393668337;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.034930892596;
                                    } else {
                                        return -0.0448133919852;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[2] <= 1.5) {
                if (fs[45] <= 0.5) {
                    if (fs[72] <= 9999.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[53] <= -1108.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.425047272742;
                                    } else {
                                        return 0.290750331834;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.267407818631;
                                    } else {
                                        return -0.0279901661449;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.277652936336;
                                    } else {
                                        return 0.475983594047;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.154426123544;
                                    } else {
                                        return -0.169917720604;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 3.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[47] <= -8.5) {
                                        return 0.0662280368044;
                                    } else {
                                        return 0.0203699658439;
                                    }
                                } else {
                                    return 0.25963271011;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.185772291052;
                                    } else {
                                        return 0.0497057795741;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.153932129363;
                                    } else {
                                        return 0.0257964491923;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[53] <= -988.0) {
                                if (fs[0] <= 0.5) {
                                    if (fs[47] <= -161.5) {
                                        return 0.49336527961;
                                    } else {
                                        return 0.348234033206;
                                    }
                                } else {
                                    if (fs[53] <= -1418.0) {
                                        return 0.263463455776;
                                    } else {
                                        return 0.0813899219922;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.224134362266;
                                    } else {
                                        return 0.413720021279;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.216611499699;
                                    } else {
                                        return 0.0947243373642;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[103] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.529656005985;
                                    } else {
                                        return 0.569211226666;
                                    }
                                } else {
                                    return 0.297740241969;
                                }
                            } else {
                                if (fs[64] <= -995.0) {
                                    if (fs[18] <= 0.5) {
                                        return 0.531813444279;
                                    } else {
                                        return 0.424035151899;
                                    }
                                } else {
                                    if (fs[47] <= -7.5) {
                                        return 0.407955848164;
                                    } else {
                                        return 0.247733235405;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[0] <= 1.5) {
                                    return -0.0760435973582;
                                } else {
                                    return -0.0561075079399;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.0395835499207;
                                    } else {
                                        return -0.0339060146391;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0436136541878;
                                    } else {
                                        return -0.0478310715552;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.0224742945321;
                                    } else {
                                        return -0.0385740631852;
                                    }
                                } else {
                                    if (fs[53] <= 7.5) {
                                        return 0.066935455124;
                                    } else {
                                        return 0.0277095882134;
                                    }
                                }
                            } else {
                                if (fs[4] <= 33.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.0177379364858;
                                    } else {
                                        return -0.0332480701201;
                                    }
                                } else {
                                    return -0.00271877251183;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[103] <= 0.5) {
                                return 0.331829195349;
                            } else {
                                if (fs[53] <= -986.0) {
                                    return -0.0395775167334;
                                } else {
                                    return -0.0420717450312;
                                }
                            }
                        } else {
                            if (fs[47] <= -0.5) {
                                if (fs[62] <= -0.5) {
                                    return 0.00600427220779;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.0387718121144;
                                    } else {
                                        return -0.0314162873377;
                                    }
                                }
                            } else {
                                return 0.0367194572095;
                            }
                        }
                    }
                }
            } else {
                if (fs[45] <= 0.5) {
                    if (fs[4] <= 8.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.506554634451;
                                    } else {
                                        return 0.461206775519;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return 0.347287025084;
                                    } else {
                                        return 0.457976377171;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[53] <= -561.5) {
                                        return 0.355142036502;
                                    } else {
                                        return 0.00746851427366;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0537539519858;
                                    } else {
                                        return 0.148904242386;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[88] <= 4.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.488788956301;
                                    } else {
                                        return 0.395867256597;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.473575148381;
                                    } else {
                                        return 0.514804482094;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.447825089475;
                                    } else {
                                        return 0.0181063561985;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.150071690007;
                                    } else {
                                        return 0.372710187771;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[53] <= -1023.0) {
                                if (fs[0] <= 0.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.0566718784407;
                                    } else {
                                        return 0.408061954932;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.160600236207;
                                    } else {
                                        return 0.581010673155;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.241595692237;
                                    } else {
                                        return 0.441108922564;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return 0.00808823823115;
                                    } else {
                                        return 0.401009348289;
                                    }
                                }
                            }
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[49] <= -0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.482763114965;
                                    } else {
                                        return 0.587135273974;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.207453150421;
                                    } else {
                                        return 0.0289982093494;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.335254800425;
                                    } else {
                                        return -0.0121112586107;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.48485084254;
                                    } else {
                                        return -0.00913820351825;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        return 0.495001767476;
                    } else {
                        if (fs[2] <= 7.5) {
                            if (fs[26] <= 0.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[86] <= 0.5) {
                                        return -0.0340557085747;
                                    } else {
                                        return -0.0696701582977;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0327151503945;
                                    } else {
                                        return 0.0597883633022;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.3513873728;
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return -0.0372547373386;
                                    } else {
                                        return 0.00290379213106;
                                    }
                                }
                            }
                        } else {
                            return 0.0319655690049;
                        }
                    }
                }
            }
        }
    }
}
