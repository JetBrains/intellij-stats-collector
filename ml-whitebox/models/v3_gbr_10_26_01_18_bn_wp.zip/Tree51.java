/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree51 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[41] <= 0.5) {
                    if (fs[53] <= -1498.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[47] <= -300.0) {
                                if (fs[23] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.206552922021;
                                    } else {
                                        return 0.297933898071;
                                    }
                                } else {
                                    return 0.166091436851;
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.104104550775;
                                    } else {
                                        return 0.142912201723;
                                    }
                                } else {
                                    if (fs[53] <= -1958.0) {
                                        return 0.168249999519;
                                    } else {
                                        return -0.0149729743022;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 1.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -1983.5) {
                                        return -0.0797624149635;
                                    } else {
                                        return -0.226992465203;
                                    }
                                } else {
                                    if (fs[53] <= -1958.0) {
                                        return -0.233801716731;
                                    } else {
                                        return -0.157261479787;
                                    }
                                }
                            } else {
                                if (fs[53] <= -2018.0) {
                                    if (fs[72] <= 9915.0) {
                                        return 0.3633640435;
                                    } else {
                                        return 0.198401163924;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.154582100805;
                                    } else {
                                        return -0.026531884029;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[88] <= -0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.143363677202;
                                    } else {
                                        return 0.19815361679;
                                    }
                                } else {
                                    return 0.371210871246;
                                }
                            } else {
                                if (fs[74] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0434893330422;
                                    } else {
                                        return 0.0759680027571;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0467530284561;
                                    } else {
                                        return 0.0435719718394;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -977.0) {
                                if (fs[44] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0523643767396;
                                    } else {
                                        return -0.034779846917;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.115022859824;
                                    } else {
                                        return -0.193320529295;
                                    }
                                }
                            } else {
                                if (fs[49] <= -0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0972761509181;
                                    } else {
                                        return 0.137398459547;
                                    }
                                } else {
                                    if (fs[47] <= -6.5) {
                                        return 0.0608595294785;
                                    } else {
                                        return -0.00919868926587;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -98.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[88] <= 4.0) {
                                if (fs[59] <= 0.5) {
                                    return -0.0916220950629;
                                } else {
                                    return -0.185538132555;
                                }
                            } else {
                                return 0.135556053741;
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.207185582398;
                                    } else {
                                        return -0.0712877914238;
                                    }
                                } else {
                                    return -0.236964698437;
                                }
                            } else {
                                if (fs[72] <= 9976.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.216580749029;
                                    } else {
                                        return 0.066357151054;
                                    }
                                } else {
                                    return 0.0842991932935;
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -94.5) {
                            if (fs[76] <= 25.0) {
                                return -0.202060749415;
                            } else {
                                return -0.306695911764;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[2] <= 9.5) {
                                    if (fs[26] <= 0.5) {
                                        return -0.0779302364275;
                                    } else {
                                        return 0.0400626954213;
                                    }
                                } else {
                                    return 0.245013186957;
                                }
                            } else {
                                if (fs[53] <= -1488.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0127223686901;
                                    } else {
                                        return 0.196691962731;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return -0.00833011092916;
                                    } else {
                                        return -0.235581849376;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -2008.0) {
                    if (fs[105] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 42.0) {
                                if (fs[23] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.17524348828;
                                    } else {
                                        return 0.267367648622;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return -0.1895569693;
                                    } else {
                                        return 0.139444356523;
                                    }
                                }
                            } else {
                                return -0.165969649757;
                            }
                        } else {
                            if (fs[53] <= -2653.0) {
                                if (fs[22] <= 0.5) {
                                    return 0.261715930565;
                                } else {
                                    if (fs[53] <= -2883.0) {
                                        return 0.307160723724;
                                    } else {
                                        return 0.39009046895;
                                    }
                                }
                            } else {
                                if (fs[4] <= 20.5) {
                                    return 0.00381916120024;
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.169702067321;
                                    } else {
                                        return 0.265077603487;
                                    }
                                }
                            }
                        }
                    } else {
                        return -0.235751562974;
                    }
                } else {
                    if (fs[2] <= 10.5) {
                        if (fs[4] <= 27.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[4] <= 25.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.0222874940096;
                                    } else {
                                        return -0.0479977908005;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.0346284916868;
                                    } else {
                                        return 0.10997522009;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0953864319153;
                                    } else {
                                        return 0.142603291347;
                                    }
                                } else {
                                    if (fs[53] <= -1973.5) {
                                        return -0.186862820297;
                                    } else {
                                        return 0.0599090306129;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -6.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0639262767405;
                                    } else {
                                        return 0.139998309601;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.0501519952015;
                                    } else {
                                        return 0.308685879888;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.11476963468;
                                    } else {
                                        return 0.0601453967306;
                                    }
                                } else {
                                    if (fs[72] <= 4999.5) {
                                        return 0.167347476313;
                                    } else {
                                        return 0.296104034077;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -6.0) {
                            return -0.0908796172192;
                        } else {
                            if (fs[53] <= -1478.0) {
                                if (fs[2] <= 13.5) {
                                    if (fs[72] <= 9988.5) {
                                        return 0.0163194326791;
                                    } else {
                                        return 0.156414205814;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.120061341465;
                                    } else {
                                        return 0.27066992553;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0985575113278;
                                    } else {
                                        return 0.420771819932;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.215369840729;
                                    } else {
                                        return 0.11220277517;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[4] <= 12.5) {
                    if (fs[47] <= -9.5) {
                        if (fs[53] <= -1453.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[47] <= -187.5) {
                                        return 0.0500812141176;
                                    } else {
                                        return -0.0120685152877;
                                    }
                                } else {
                                    if (fs[53] <= -1608.0) {
                                        return 0.0176630635998;
                                    } else {
                                        return 0.135760656101;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0628785165455;
                                    } else {
                                        return 0.138957198386;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.415725750739;
                                    } else {
                                        return 0.185812757338;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                if (fs[4] <= 6.5) {
                                    return 0.104948465016;
                                } else {
                                    return 0.412722217461;
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.0359710440827;
                                    } else {
                                        return -0.0684434056849;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return -0.0110665719677;
                                    } else {
                                        return -0.12854862933;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[22] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.0206291240622;
                                    } else {
                                        return 0.0914635834613;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.00382099730608;
                                    } else {
                                        return 0.141322005164;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.0) {
                                    if (fs[90] <= 0.5) {
                                        return -0.022438137516;
                                    } else {
                                        return 0.124245779427;
                                    }
                                } else {
                                    if (fs[72] <= 9018.5) {
                                        return 0.157608595829;
                                    } else {
                                        return 0.0690068398579;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[88] <= 4.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0347172896168;
                                    } else {
                                        return 0.0792835617828;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0548901586424;
                                    } else {
                                        return -0.0303172647224;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0907316406429;
                                    } else {
                                        return 0.216675448833;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.0469664539772;
                                    } else {
                                        return -0.0278064021763;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[55] <= 50.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0154980854776;
                                    } else {
                                        return -0.00404711763997;
                                    }
                                } else {
                                    if (fs[72] <= 9956.5) {
                                        return 0.0807127030486;
                                    } else {
                                        return 0.214882382197;
                                    }
                                }
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0233593242354;
                                    } else {
                                        return 0.158067689913;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0188732204135;
                                    } else {
                                        return 0.193280573974;
                                    }
                                }
                            }
                        } else {
                            if (fs[101] <= 0.5) {
                                if (fs[47] <= -2.5) {
                                    return 0.312385871975;
                                } else {
                                    if (fs[72] <= 9995.0) {
                                        return 0.0187083437878;
                                    } else {
                                        return -0.149985881879;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.371752273272;
                                    } else {
                                        return 0.0884787000861;
                                    }
                                } else {
                                    return 0.327022428954;
                                }
                            }
                        }
                    } else {
                        return 0.32187524361;
                    }
                }
            } else {
                if (fs[4] <= 11.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[99] <= 0.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[53] <= -1068.0) {
                                        return 0.234761359157;
                                    } else {
                                        return -0.171695731236;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.00745087118162;
                                    } else {
                                        return 0.0470170186726;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[55] <= 50.0) {
                                        return -0.00452771037558;
                                    } else {
                                        return 0.110268395388;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.00755877269496;
                                    } else {
                                        return -0.00403305656704;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 7.5) {
                                if (fs[0] <= 6.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.00249888349018;
                                    } else {
                                        return 0.0340415724928;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return -0.00143789888992;
                                    } else {
                                        return 0.168116298949;
                                    }
                                }
                            } else {
                                return 0.240573904044;
                            }
                        }
                    } else {
                        if (fs[53] <= -1418.0) {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.203797909237;
                                    } else {
                                        return 0.0273752130994;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00307190305504;
                                    } else {
                                        return 0.0173634061308;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.0740441541368;
                                    } else {
                                        return 0.227646794217;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return 0.0359756326589;
                                    } else {
                                        return 0.425968353681;
                                    }
                                }
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[64] <= -998.5) {
                                        return 0.345230629203;
                                    } else {
                                        return 0.0062989197775;
                                    }
                                } else {
                                    if (fs[47] <= -2000.0) {
                                        return 0.0951848755878;
                                    } else {
                                        return -0.00733263878792;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[76] <= 150.0) {
                                        return -0.0186330293099;
                                    } else {
                                        return 0.00541829321438;
                                    }
                                } else {
                                    if (fs[47] <= -2385.0) {
                                        return -0.0522627807327;
                                    } else {
                                        return -0.00815537614358;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[49] <= -2.5) {
                        if (fs[97] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                return 0.0779727744166;
                            } else {
                                return 0.232819558169;
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[53] <= -1103.0) {
                                    return 0.232592461498;
                                } else {
                                    return 0.0831796210168;
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    return 0.0233642531097;
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.039209174514;
                                    } else {
                                        return -0.0203066217489;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 24.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[88] <= 5.5) {
                                        return -0.00397583963878;
                                    } else {
                                        return -0.00776726529456;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.228652888414;
                                    } else {
                                        return 0.0190203166111;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.23687869581;
                                    } else {
                                        return 0.0184402634455;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.0754803320936;
                                    } else {
                                        return 0.00529880239225;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9921.5) {
                                if (fs[72] <= 9919.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.007139991728;
                                    } else {
                                        return -0.00558891114985;
                                    }
                                } else {
                                    return 0.400994882723;
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0694256213791;
                                    } else {
                                        return -0.0443209396168;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.0071382844849;
                                    } else {
                                        return -0.0271609330834;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
