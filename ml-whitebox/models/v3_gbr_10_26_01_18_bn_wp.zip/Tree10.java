/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree10 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[30] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[53] <= -1228.5) {
                        if (fs[74] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.271700964726;
                                    } else {
                                        return 0.473323849297;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.411368710138;
                                    } else {
                                        return 0.536840986847;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[53] <= -1928.0) {
                                        return 0.375643758941;
                                    } else {
                                        return 0.0310045785162;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.368309255454;
                                    } else {
                                        return 0.194323103525;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1493.5) {
                                return 0.0600443209067;
                            } else {
                                if (fs[53] <= -1488.5) {
                                    return -0.103490890157;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0170901717963;
                                    } else {
                                        return -0.0489719256765;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[53] <= -1043.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.393498804774;
                                    } else {
                                        return 0.53308826908;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.534584410168;
                                    } else {
                                        return 0.280265229026;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1.0) {
                                    if (fs[101] <= 1.5) {
                                        return -0.0293138084341;
                                    } else {
                                        return 0.272806877055;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.434512857154;
                                    } else {
                                        return 0.276756825167;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[62] <= -0.5) {
                                    if (fs[64] <= -996.5) {
                                        return 0.518306870746;
                                    } else {
                                        return 0.232023427454;
                                    }
                                } else {
                                    if (fs[53] <= -965.5) {
                                        return 0.283254785283;
                                    } else {
                                        return 0.13626928493;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.444809819236;
                                    } else {
                                        return 0.216557852883;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.22109828982;
                                    } else {
                                        return 0.391936498946;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[47] <= -1881.0) {
                            if (fs[4] <= 6.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.199625091275;
                                    } else {
                                        return -0.072112530778;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.103301837461;
                                    } else {
                                        return 0.556210057936;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[72] <= 9985.5) {
                                        return 0.088719691027;
                                    } else {
                                        return 0.447920628455;
                                    }
                                } else {
                                    return -0.00789571102742;
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0451444572951;
                                    } else {
                                        return -0.000791548111738;
                                    }
                                } else {
                                    if (fs[53] <= -1448.5) {
                                        return 0.327751551252;
                                    } else {
                                        return -0.00488514764653;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0378143427544;
                                    } else {
                                        return 0.00205963560414;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.0241359552411;
                                    } else {
                                        return 0.0418191725006;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 0.5) {
                            if (fs[72] <= 9867.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.00273649463511;
                                    } else {
                                        return -0.0340954466791;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.0179593385176;
                                    } else {
                                        return -0.0306483872847;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[72] <= 9968.5) {
                                        return -0.0175607825452;
                                    } else {
                                        return 0.021070433854;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return -0.000146945475423;
                                    } else {
                                        return -0.0269937895635;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[53] <= -1082.5) {
                                        return 0.0258764581845;
                                    } else {
                                        return -0.0147286730159;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.0108583891042;
                                    } else {
                                        return -0.0254661535098;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[103] <= 1.5) {
                                        return -0.0261867187654;
                                    } else {
                                        return 0.0345607498227;
                                    }
                                } else {
                                    if (fs[47] <= -2588.5) {
                                        return -0.0599127895438;
                                    } else {
                                        return -0.0366888659951;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 7.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[78] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.538284814856;
                                    } else {
                                        return 0.422024108954;
                                    }
                                } else {
                                    return 0.556399912847;
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return 0.609367166588;
                                } else {
                                    return 0.521301308421;
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    return 0.552082887644;
                                } else {
                                    return 0.507514112921;
                                }
                            } else {
                                return 0.525306230216;
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.5718198206;
                                    } else {
                                        return 0.567299231462;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.577949195872;
                                    } else {
                                        return 0.56840651629;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.578821481845;
                                    } else {
                                        return 0.568427841792;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.552454438047;
                                    } else {
                                        return 0.531735725876;
                                    }
                                }
                            }
                        } else {
                            return 0.652925168637;
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[2] <= 1.5) {
                            return 0.121462927672;
                        } else {
                            return 0.161112936529;
                        }
                    } else {
                        return 0.530651835916;
                    }
                }
            }
        } else {
            if (fs[53] <= -1052.5) {
                if (fs[18] <= 0.5) {
                    if (fs[4] <= 18.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[18] <= -0.5) {
                                if (fs[90] <= 0.5) {
                                    return 0.0657367114191;
                                } else {
                                    return -0.225559407611;
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[88] <= -0.5) {
                                        return -0.0338317167435;
                                    } else {
                                        return 0.488334010253;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.497267711316;
                                    } else {
                                        return 0.58489283528;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[104] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.280980794716;
                                    } else {
                                        return 0.145706716858;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.102182826533;
                                    } else {
                                        return -0.0366976430367;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.345259958614;
                                    } else {
                                        return 0.196679721295;
                                    }
                                } else {
                                    if (fs[47] <= -1082.5) {
                                        return 0.633659770418;
                                    } else {
                                        return 0.42643136046;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.366747027495;
                                    } else {
                                        return 0.18660392205;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.333556535988;
                                    } else {
                                        return 0.468907287856;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.417452390311;
                                    } else {
                                        return 0.174690564766;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.488083040742;
                                    } else {
                                        return 0.232782038419;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 250.0) {
                                if (fs[44] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0971646550796;
                                    } else {
                                        return 0.302698858764;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.0806366080702;
                                    } else {
                                        return 0.107216258345;
                                    }
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.034126430376;
                                    } else {
                                        return 0.125415132505;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.152136094175;
                                    } else {
                                        return -0.0933340292917;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[99] <= 0.5) {
                        if (fs[88] <= 2.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[47] <= -4.5) {
                                        return 0.440841451968;
                                    } else {
                                        return 0.276540459609;
                                    }
                                } else {
                                    if (fs[53] <= -1578.0) {
                                        return 0.66428915665;
                                    } else {
                                        return 0.460055398793;
                                    }
                                }
                            } else {
                                if (fs[47] <= -16.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.511930299544;
                                    } else {
                                        return 0.087377250422;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.126588302039;
                                    } else {
                                        return -0.0425094963164;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[47] <= -128.5) {
                                        return 0.672864486164;
                                    } else {
                                        return 0.529302973259;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return 0.70293525894;
                                    } else {
                                        return 0.637926388743;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9998.5) {
                                    return 0.114180710574;
                                } else {
                                    return 0.4235747662;
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 250.0) {
                            if (fs[2] <= 3.5) {
                                if (fs[71] <= 0.5) {
                                    return 0.467103986813;
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return 0.195655551274;
                                    } else {
                                        return -0.0306425924341;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.296527785995;
                                    } else {
                                        return 0.486263171929;
                                    }
                                } else {
                                    return -0.00670334809421;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0192895136914;
                                    } else {
                                        return 0.347564230315;
                                    }
                                } else {
                                    return 0.627748441426;
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0325263290698;
                                    } else {
                                        return 0.223612300827;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return 0.316968125475;
                                    } else {
                                        return 0.0398682271733;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[47] <= -6.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.617144914453;
                                    } else {
                                        return 0.538114939078;
                                    }
                                } else {
                                    if (fs[47] <= -40.0) {
                                        return 0.267882807229;
                                    } else {
                                        return 0.47093276765;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.591824860375;
                                    } else {
                                        return 0.351094918083;
                                    }
                                } else {
                                    if (fs[64] <= -498.0) {
                                        return 0.585656475531;
                                    } else {
                                        return 0.185105210046;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.437564316645;
                                    } else {
                                        return 0.122805913184;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.00491086080401;
                                    } else {
                                        return 0.318515827524;
                                    }
                                }
                            } else {
                                if (fs[70] <= -4.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.581951492517;
                                    } else {
                                        return 0.282019224609;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.164661909055;
                                    } else {
                                        return 0.706086214774;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[88] <= 4.5) {
                                if (fs[101] <= 1.5) {
                                    if (fs[47] <= -4.5) {
                                        return 0.519653264341;
                                    } else {
                                        return 0.456183243578;
                                    }
                                } else {
                                    if (fs[62] <= -0.5) {
                                        return 0.630773367105;
                                    } else {
                                        return 0.35361625597;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.635653022017;
                                    } else {
                                        return 0.606262970721;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.606535801229;
                                    } else {
                                        return 0.46810946019;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[88] <= 5.0) {
                                    if (fs[4] <= 9.5) {
                                        return 0.592388709012;
                                    } else {
                                        return 0.3603368285;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.679393903481;
                                    } else {
                                        return 0.534022518235;
                                    }
                                }
                            } else {
                                if (fs[64] <= -498.0) {
                                    if (fs[49] <= -1.5) {
                                        return 0.578121020025;
                                    } else {
                                        return 0.647731542219;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.407351663749;
                                    } else {
                                        return 0.231477629892;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[88] <= 3.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.188059680044;
                                    } else {
                                        return 0.0582361546528;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.115648371325;
                                    } else {
                                        return 0.30351698558;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0344776670887;
                                    } else {
                                        return 0.195010346856;
                                    }
                                } else {
                                    return 0.240710537794;
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0161309414995;
                                    } else {
                                        return 0.0429140223624;
                                    }
                                } else {
                                    if (fs[47] <= -13.5) {
                                        return 0.292904017223;
                                    } else {
                                        return 0.0701219830417;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0432686227885;
                                    } else {
                                        return 0.00497824674393;
                                    }
                                } else {
                                    if (fs[0] <= 58.0) {
                                        return -0.0339185730712;
                                    } else {
                                        return 0.0339071464703;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 7.5) {
                            if (fs[68] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[77] <= 0.5) {
                                        return -0.0367051423914;
                                    } else {
                                        return -0.0633276260942;
                                    }
                                } else {
                                    if (fs[27] <= 0.5) {
                                        return -0.0147866618765;
                                    } else {
                                        return -0.0425986538165;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    return 0.232273974834;
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0368250423495;
                                    } else {
                                        return -0.0432046342771;
                                    }
                                }
                            }
                        } else {
                            return 0.0512176078801;
                        }
                    }
                }
            }
        }
    }
}
