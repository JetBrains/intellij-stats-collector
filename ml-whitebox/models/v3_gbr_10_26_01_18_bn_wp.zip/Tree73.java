/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree73 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[53] <= -1498.5) {
                if (fs[18] <= 0.5) {
                    if (fs[43] <= 0.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[47] <= -967.5) {
                                        return 0.200768550164;
                                    } else {
                                        return 0.0846469294229;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.165876811001;
                                    } else {
                                        return 0.0456952269725;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[47] <= -5.5) {
                                        return 0.0761727279736;
                                    } else {
                                        return 0.273303865628;
                                    }
                                } else {
                                    if (fs[4] <= 42.0) {
                                        return 0.0993200209479;
                                    } else {
                                        return -0.387790359124;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -1.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[53] <= -1923.5) {
                                        return -0.00988005016498;
                                    } else {
                                        return 0.112530775753;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.129948983739;
                                    } else {
                                        return -0.147845474751;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0765619013315;
                                    } else {
                                        return -0.0742632112817;
                                    }
                                } else {
                                    return -0.287279665048;
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 1.5) {
                            if (fs[2] <= 1.5) {
                                return -0.20749223007;
                            } else {
                                return 0.121169477753;
                            }
                        } else {
                            if (fs[47] <= -20.0) {
                                return 0.348608917075;
                            } else {
                                return 0.161342693638;
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9999.5) {
                        if (fs[53] <= -1578.5) {
                            if (fs[53] <= -1618.0) {
                                if (fs[76] <= 250.0) {
                                    if (fs[88] <= 5.0) {
                                        return 0.170743311632;
                                    } else {
                                        return 0.0801631704261;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.140363968675;
                                    } else {
                                        return 0.0358615447594;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1608.5) {
                                    if (fs[2] <= 6.5) {
                                        return 0.0546525393858;
                                    } else {
                                        return -0.194149394025;
                                    }
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return -0.0625224852147;
                                    } else {
                                        return 0.178334848764;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 13.5) {
                                if (fs[71] <= 0.5) {
                                    return 0.29931381836;
                                } else {
                                    return 0.167557352133;
                                }
                            } else {
                                return 0.280267161221;
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[53] <= -1598.0) {
                                    return 0.202864423257;
                                } else {
                                    return -0.0380137174098;
                                }
                            } else {
                                return -0.0178759528723;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return -0.238301337681;
                            } else {
                                return 0.131570234227;
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 14.5) {
                    if (fs[34] <= 0.5) {
                        if (fs[8] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.0249895297821;
                                    } else {
                                        return 0.0612881673627;
                                    }
                                } else {
                                    if (fs[53] <= -1473.5) {
                                        return -0.291260447779;
                                    } else {
                                        return -0.00435401123462;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1473.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.075379421017;
                                    } else {
                                        return -0.000416607611609;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0187268242208;
                                    } else {
                                        return -0.0510667900096;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0754347733446;
                                    } else {
                                        return 0.257601886635;
                                    }
                                } else {
                                    if (fs[72] <= 4998.5) {
                                        return -0.437598656149;
                                    } else {
                                        return -0.172214769053;
                                    }
                                }
                            } else {
                                return -0.397682005191;
                            }
                        }
                    } else {
                        if (fs[72] <= 9706.5) {
                            if (fs[70] <= -4.0) {
                                if (fs[48] <= 0.5) {
                                    return 0.234389543767;
                                } else {
                                    return 0.204589816644;
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.341896475597;
                                    } else {
                                        return 0.232435460285;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.233531192932;
                                    } else {
                                        return 0.269371668216;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -0.5) {
                                if (fs[47] <= -1.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.103802835289;
                                    } else {
                                        return 0.193852763391;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.157486851081;
                                    } else {
                                        return 0.0882660396724;
                                    }
                                }
                            } else {
                                return -0.0236684832998;
                            }
                        }
                    }
                } else {
                    if (fs[99] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0153182310093;
                                    } else {
                                        return -0.174507544574;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.173313947253;
                                    } else {
                                        return -0.0779014629013;
                                    }
                                }
                            } else {
                                return 0.219632955507;
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0378792311378;
                                    } else {
                                        return 0.0280205664601;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.328396760791;
                                    } else {
                                        return -0.00039680769;
                                    }
                                }
                            } else {
                                if (fs[4] <= 29.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0203090201831;
                                    } else {
                                        return 0.094343170218;
                                    }
                                } else {
                                    return -0.404127822183;
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[83] <= 0.5) {
                                if (fs[47] <= -129.5) {
                                    if (fs[2] <= 6.5) {
                                        return 0.265582685641;
                                    } else {
                                        return 0.191160927145;
                                    }
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return 0.0731242363679;
                                    } else {
                                        return 0.00627208435771;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.102991699443;
                                    } else {
                                        return -0.22011714653;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return -0.0516546675452;
                                    } else {
                                        return 0.314373479497;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 16.5) {
                                if (fs[2] <= 2.5) {
                                    return -0.215918687643;
                                } else {
                                    return -0.378644283172;
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    return 0.177415370559;
                                } else {
                                    if (fs[72] <= 9994.5) {
                                        return -0.135236035693;
                                    } else {
                                        return -0.350693983037;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[14] <= 0.5) {
                if (fs[0] <= 2.5) {
                    if (fs[45] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[29] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[103] <= 1.5) {
                                        return -0.00428390578758;
                                    } else {
                                        return 0.0198480728275;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.205684386869;
                                    } else {
                                        return 0.0833200954766;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[4] <= 25.5) {
                                        return 0.131049963338;
                                    } else {
                                        return 0.289264948698;
                                    }
                                } else {
                                    return -0.0101201692718;
                                }
                            }
                        } else {
                            if (fs[88] <= 7.5) {
                                if (fs[53] <= -386.5) {
                                    if (fs[53] <= -992.0) {
                                        return 0.0044530248206;
                                    } else {
                                        return -0.0376193502512;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.00953328489199;
                                    } else {
                                        return 0.0329590369592;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00462136221374;
                                    } else {
                                        return 0.0483257802439;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.14896403977;
                                    } else {
                                        return -0.124447984824;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 11.5) {
                            if (fs[68] <= 1.5) {
                                if (fs[103] <= 1.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0121151077479;
                                    } else {
                                        return -0.00467877037429;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.0520872744945;
                                    } else {
                                        return -0.00339639425339;
                                    }
                                }
                            } else {
                                if (fs[53] <= -451.0) {
                                    if (fs[53] <= -976.0) {
                                        return 0.0731867932234;
                                    } else {
                                        return -0.0376916529465;
                                    }
                                } else {
                                    return 0.0732252421221;
                                }
                            }
                        } else {
                            if (fs[53] <= -961.5) {
                                return -0.00797954206162;
                            } else {
                                return 0.273546947439;
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[4] <= 3.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.0242634627218;
                                    } else {
                                        return 0.000137898605605;
                                    }
                                } else {
                                    if (fs[0] <= 15.5) {
                                        return 0.0396596325497;
                                    } else {
                                        return 0.0109191051135;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9719.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0157876085525;
                                    } else {
                                        return -0.00459963868713;
                                    }
                                } else {
                                    if (fs[0] <= 27.5) {
                                        return 0.0826340169933;
                                    } else {
                                        return -0.0476885477275;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[72] <= 9869.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.00469251738494;
                                    } else {
                                        return -0.00195913056097;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.0186378453314;
                                    } else {
                                        return -0.00619026839101;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[88] <= 5.5) {
                                        return -0.00135421489809;
                                    } else {
                                        return -0.00329104428077;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.00966405147414;
                                    } else {
                                        return -0.00118286824171;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -5.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[53] <= -1598.0) {
                                        return 0.0705497321095;
                                    } else {
                                        return -0.00558656470294;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.4194618879;
                                    } else {
                                        return -0.0239351792161;
                                    }
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[47] <= -479.0) {
                                        return 0.058663292774;
                                    } else {
                                        return 0.00592843073848;
                                    }
                                } else {
                                    if (fs[47] <= -13.5) {
                                        return 0.163523894056;
                                    } else {
                                        return 0.00853150017198;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -2.5) {
                                return 0.151770286009;
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[72] <= 9931.5) {
                                        return -0.00209546017934;
                                    } else {
                                        return -0.0349106128176;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.00146986028458;
                                    } else {
                                        return -0.000955082979075;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[99] <= 0.5) {
                        if (fs[88] <= 7.5) {
                            if (fs[53] <= -1488.0) {
                                if (fs[4] <= 20.5) {
                                    return -0.135275357159;
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.327677795616;
                                    } else {
                                        return 0.109978976811;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9989.0) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0803840877395;
                                    } else {
                                        return -0.0246303674232;
                                    }
                                } else {
                                    return 0.0879297674785;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.308152023176;
                            } else {
                                return 0.101033818402;
                            }
                        }
                    } else {
                        if (fs[53] <= -1488.0) {
                            return 0.243512916748;
                        } else {
                            if (fs[4] <= 4.5) {
                                return 0.290809288792;
                            } else {
                                if (fs[71] <= 0.5) {
                                    return 0.221892290068;
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.0348284490702;
                                    } else {
                                        return 0.30326023189;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 5.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[4] <= 2.5) {
                                return 0.0491138470487;
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[0] <= 9.5) {
                                        return -0.0446664962556;
                                    } else {
                                        return 0.0348170605639;
                                    }
                                } else {
                                    if (fs[0] <= 7.0) {
                                        return 0.0559486309634;
                                    } else {
                                        return -0.0262664582457;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                return 0.558787497273;
                            } else {
                                if (fs[0] <= 7.5) {
                                    return -0.039293953414;
                                } else {
                                    if (fs[0] <= 14.5) {
                                        return 0.0902903315615;
                                    } else {
                                        return 0.143154383232;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 6.5) {
                            if (fs[27] <= 0.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[4] <= 24.5) {
                                        return 0.024314306899;
                                    } else {
                                        return -0.017941826937;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0745648030933;
                                    } else {
                                        return -0.0563459140614;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 13.5) {
                                        return -0.0270914794531;
                                    } else {
                                        return 0.0601075011893;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.100370537148;
                                    } else {
                                        return -0.121428611395;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[70] <= -4.0) {
                                    if (fs[2] <= 1.5) {
                                        return -0.00671715627932;
                                    } else {
                                        return -0.0172359841054;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0193055849069;
                                    } else {
                                        return -0.00384915642456;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1128.0) {
                                    if (fs[103] <= 0.5) {
                                        return 0.000957481906799;
                                    } else {
                                        return 0.0694912561053;
                                    }
                                } else {
                                    if (fs[72] <= 9985.5) {
                                        return -0.00249403815055;
                                    } else {
                                        return 0.0495143272927;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
