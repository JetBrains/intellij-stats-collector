/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree85 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9999.5) {
            if (fs[0] <= 0.5) {
                if (fs[47] <= -134.5) {
                    if (fs[76] <= 250.0) {
                        if (fs[22] <= 0.5) {
                            if (fs[47] <= -400.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.0296275717494;
                                    } else {
                                        return -0.293221527662;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0909024921089;
                                    } else {
                                        return -0.034111436531;
                                    }
                                }
                            } else {
                                if (fs[53] <= -495.5) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.0448324060982;
                                    } else {
                                        return 0.207848508326;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0486096414871;
                                    } else {
                                        return 0.172534961267;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9865.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0749364960417;
                                    } else {
                                        return -0.0108924932823;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.256392248517;
                                    } else {
                                        return 0.154540155576;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9921.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.318455898469;
                                    } else {
                                        return -0.0225629190383;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.00822913274977;
                                    } else {
                                        return 0.13810334008;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -1685.0) {
                            return -0.0159402631666;
                        } else {
                            return -0.241117305801;
                        }
                    }
                } else {
                    if (fs[22] <= 0.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[53] <= -1143.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.116634174483;
                                    } else {
                                        return -0.0264353448669;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return 0.00983302439543;
                                    } else {
                                        return 0.0294567038896;
                                    }
                                }
                            } else {
                                if (fs[98] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.000138279184629;
                                    } else {
                                        return -0.0568351480759;
                                    }
                                } else {
                                    if (fs[72] <= 9987.5) {
                                        return 0.0449972390336;
                                    } else {
                                        return 0.0873381030601;
                                    }
                                }
                            }
                        } else {
                            if (fs[32] <= 0.5) {
                                if (fs[72] <= 9612.5) {
                                    if (fs[51] <= 0.5) {
                                        return 0.0192957136072;
                                    } else {
                                        return 0.176615481946;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.051435738945;
                                    } else {
                                        return 0.00496879818124;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    return -0.367173422307;
                                } else {
                                    return -0.207377034187;
                                }
                            }
                        }
                    } else {
                        if (fs[55] <= 0.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.0526343207672;
                                    } else {
                                        return 0.0388977666266;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.104956818482;
                                    } else {
                                        return 0.00338689460949;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[83] <= 0.5) {
                                        return 0.0879498907542;
                                    } else {
                                        return 0.0162987361983;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.123111876803;
                                    } else {
                                        return 0.00971637169482;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -1.5) {
                                return 0.267656391453;
                            } else {
                                if (fs[88] <= 1.0) {
                                    return 0.214154422318;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0927684171558;
                                    } else {
                                        return -0.0906157737736;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 13.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[101] <= 1.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.00743527883436;
                                    } else {
                                        return -0.00109925495916;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -9.6631383282e-05;
                                    } else {
                                        return 0.0272822384146;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 5.0) {
                                        return 0.17799849558;
                                    } else {
                                        return 0.00221135767902;
                                    }
                                } else {
                                    return 0.117315899971;
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[70] <= -1.5) {
                                        return -0.00148023623791;
                                    } else {
                                        return 0.205412153841;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.010919636903;
                                    } else {
                                        return 0.176093183233;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[53] <= -1062.0) {
                                        return 0.0875856900477;
                                    } else {
                                        return 0.0306911060201;
                                    }
                                } else {
                                    return 0.250971630893;
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 5.5) {
                            if (fs[53] <= -1408.0) {
                                if (fs[0] <= 6.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0235970812123;
                                    } else {
                                        return 0.0682495583482;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0320853076231;
                                    } else {
                                        return 0.00517852168021;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[72] <= 8516.0) {
                                        return 0.000525016380378;
                                    } else {
                                        return -0.0164774053218;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0066948373302;
                                    } else {
                                        return 0.0660541298475;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0048233897643;
                                    } else {
                                        return 0.0430756904723;
                                    }
                                } else {
                                    if (fs[47] <= -3126.0) {
                                        return -0.109082845342;
                                    } else {
                                        return -0.00659487122897;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[72] <= 9896.0) {
                                        return -0.0179359087578;
                                    } else {
                                        return -0.172949838442;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0514225111833;
                                    } else {
                                        return -0.00432126770685;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[103] <= 0.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[0] <= 6.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.00022688690473;
                                    } else {
                                        return -0.00695043577128;
                                    }
                                } else {
                                    if (fs[47] <= -12.5) {
                                        return 0.188638998696;
                                    } else {
                                        return 0.0253334618973;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[0] <= 120.5) {
                                        return -0.000844076933167;
                                    } else {
                                        return 0.00315224022358;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return -0.00260300407631;
                                    } else {
                                        return 0.0470686053437;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 10.5) {
                                if (fs[72] <= 9965.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.0138326997623;
                                    } else {
                                        return 0.0423856325093;
                                    }
                                } else {
                                    if (fs[4] <= 42.0) {
                                        return -0.0194271860011;
                                    } else {
                                        return 0.200130274014;
                                    }
                                }
                            } else {
                                if (fs[62] <= -2.5) {
                                    return 0.144471538068;
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.00471416660113;
                                    } else {
                                        return 0.12705120591;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1088.0) {
                            if (fs[62] <= -1.5) {
                                if (fs[4] <= 29.5) {
                                    if (fs[26] <= 0.5) {
                                        return -0.0175527726061;
                                    } else {
                                        return 0.185581307835;
                                    }
                                } else {
                                    return 0.226214124595;
                                }
                            } else {
                                if (fs[0] <= 62.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.0292108844805;
                                    } else {
                                        return -0.00983687014777;
                                    }
                                } else {
                                    if (fs[0] <= 113.0) {
                                        return 0.464955911586;
                                    } else {
                                        return 0.0633937778875;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[49] <= -1.5) {
                                        return 0.0275027473815;
                                    } else {
                                        return -0.00676554874458;
                                    }
                                } else {
                                    if (fs[53] <= -1082.5) {
                                        return 0.029919226053;
                                    } else {
                                        return -0.000373699522297;
                                    }
                                }
                            } else {
                                if (fs[2] <= 12.5) {
                                    if (fs[4] <= 16.5) {
                                        return -0.0123440910091;
                                    } else {
                                        return -0.00220394558803;
                                    }
                                } else {
                                    return -0.0615612625242;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[8] <= 0.5) {
                if (fs[84] <= 0.5) {
                    if (fs[0] <= 16.5) {
                        if (fs[4] <= 34.5) {
                            if (fs[66] <= 5.0) {
                                if (fs[53] <= -1488.0) {
                                    if (fs[4] <= 12.5) {
                                        return 0.00464787070325;
                                    } else {
                                        return 0.0621577574117;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.0478470476824;
                                    } else {
                                        return 0.149167992541;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    return -0.233377523913;
                                } else {
                                    return -0.15111514291;
                                }
                            }
                        } else {
                            if (fs[90] <= 0.5) {
                                return -0.142331885744;
                            } else {
                                return -0.356283344648;
                            }
                        }
                    } else {
                        if (fs[47] <= -373.0) {
                            return 0.103483341396;
                        } else {
                            if (fs[0] <= 39.5) {
                                if (fs[0] <= 38.5) {
                                    if (fs[74] <= 0.5) {
                                        return -0.0125489274115;
                                    } else {
                                        return -0.0603016019261;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0861718695651;
                                    } else {
                                        return -0.00685243244364;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return -0.0285261379429;
                                    } else {
                                        return -0.111402076704;
                                    }
                                } else {
                                    return 0.0280500998571;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[6] <= 0.5) {
                        if (fs[4] <= 8.5) {
                            return -0.430967260834;
                        } else {
                            if (fs[90] <= 0.5) {
                                if (fs[101] <= 1.0) {
                                    return 0.165315949632;
                                } else {
                                    return -0.240559392626;
                                }
                            } else {
                                return -0.179967961772;
                            }
                        }
                    } else {
                        if (fs[0] <= 32.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[76] <= 250.0) {
                                    if (fs[97] <= 0.5) {
                                        return -0.00327656879756;
                                    } else {
                                        return -0.0733916696345;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.109722997637;
                                    } else {
                                        return 0.0160224057957;
                                    }
                                }
                            } else {
                                if (fs[47] <= -86.5) {
                                    if (fs[47] <= -399.0) {
                                        return 0.00311929707666;
                                    } else {
                                        return -0.142496103636;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.032057074197;
                                    } else {
                                        return -0.14495095297;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 100.0) {
                                return 0.341872987756;
                            } else {
                                if (fs[53] <= -986.0) {
                                    return 0.291294536352;
                                } else {
                                    return -0.00558747448678;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 13.5) {
                    return -0.277324660039;
                } else {
                    return -0.130780914105;
                }
            }
        }
    }
}
