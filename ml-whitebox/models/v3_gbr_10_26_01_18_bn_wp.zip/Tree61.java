/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree61 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[53] <= -987.5) {
                    if (fs[53] <= -1138.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.040903256797;
                                    } else {
                                        return -0.0771305508246;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.00576101775664;
                                    } else {
                                        return -0.171473542454;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    return -0.110422861369;
                                } else {
                                    return -0.338532539497;
                                }
                            }
                        } else {
                            if (fs[72] <= 9998.5) {
                                if (fs[53] <= -1543.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.107454501214;
                                    } else {
                                        return -0.144824269237;
                                    }
                                } else {
                                    if (fs[53] <= -1483.5) {
                                        return -0.0805325606804;
                                    } else {
                                        return -0.00382545427133;
                                    }
                                }
                            } else {
                                if (fs[70] <= -3.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.182416144857;
                                    } else {
                                        return 0.28906195361;
                                    }
                                } else {
                                    if (fs[47] <= -506.5) {
                                        return 0.207134060476;
                                    } else {
                                        return 0.04130963084;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[58] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[88] <= 2.5) {
                                    if (fs[4] <= 21.5) {
                                        return 0.0652432826032;
                                    } else {
                                        return -0.0520669890595;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.100473689639;
                                    } else {
                                        return 0.218246716586;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0896806526908;
                                    } else {
                                        return -0.140106914129;
                                    }
                                } else {
                                    return 0.0210481213341;
                                }
                            }
                        } else {
                            return -0.143327924307;
                        }
                    }
                } else {
                    if (fs[72] <= 9999.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.34316511619;
                                    } else {
                                        return -0.0716340538683;
                                    }
                                } else {
                                    if (fs[4] <= 24.5) {
                                        return 0.0604900094676;
                                    } else {
                                        return -0.16639171704;
                                    }
                                }
                            } else {
                                if (fs[15] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.00243282022542;
                                    } else {
                                        return 0.217104701147;
                                    }
                                } else {
                                    return -0.350653049834;
                                }
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.281990597674;
                                    } else {
                                        return 0.143931912529;
                                    }
                                } else {
                                    return 0.144642429176;
                                }
                            } else {
                                if (fs[47] <= -6.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0373594716217;
                                    } else {
                                        return -0.135514295747;
                                    }
                                } else {
                                    if (fs[53] <= -948.5) {
                                        return 0.00830636368512;
                                    } else {
                                        return -0.127751549589;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[24] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0100655932458;
                                    } else {
                                        return 0.0265920230621;
                                    }
                                } else {
                                    return 0.27572287103;
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    return 0.0605644010428;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.328817112116;
                                    } else {
                                        return 0.158540767336;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 5.5) {
                                if (fs[78] <= 0.5) {
                                    return -0.262422976397;
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.00658509445912;
                                    } else {
                                        return 0.288972386996;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.0) {
                                    return 0.309624174692;
                                } else {
                                    return 0.117821552063;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 17.5) {
                    if (fs[71] <= 0.5) {
                        if (fs[18] <= -0.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[72] <= 9384.5) {
                                        return -0.29849103294;
                                    } else {
                                        return -0.358981588148;
                                    }
                                } else {
                                    return -0.0108198436815;
                                }
                            } else {
                                return 0.0937093942654;
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 8.5) {
                                        return 0.0410582236406;
                                    } else {
                                        return 0.137539972303;
                                    }
                                } else {
                                    if (fs[53] <= -1463.5) {
                                        return 0.152753682828;
                                    } else {
                                        return 0.0663679060748;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.112432296491;
                                    } else {
                                        return 0.0828108022846;
                                    }
                                } else {
                                    return 0.329961745637;
                                }
                            }
                        }
                    } else {
                        if (fs[28] <= 0.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[32] <= 0.5) {
                                    if (fs[47] <= -6.5) {
                                        return 0.0653358887687;
                                    } else {
                                        return 0.0332844277514;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.302608009866;
                                    } else {
                                        return -0.120680016865;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return -0.156493251303;
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.00758955602507;
                                    } else {
                                        return -0.164048323963;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 1.0) {
                                if (fs[90] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0710847382275;
                                    } else {
                                        return -0.300408922784;
                                    }
                                } else {
                                    return -0.203581792843;
                                }
                            } else {
                                if (fs[88] <= 5.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.309759391039;
                                    } else {
                                        return -0.414583262354;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.116277870976;
                                    } else {
                                        return -0.221586251574;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[26] <= 0.5) {
                        if (fs[53] <= -1993.0) {
                            if (fs[53] <= -2038.0) {
                                if (fs[2] <= 4.5) {
                                    if (fs[4] <= 22.5) {
                                        return -0.0172843165556;
                                    } else {
                                        return 0.164352722241;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.220320530631;
                                    } else {
                                        return 0.0625750628455;
                                    }
                                }
                            } else {
                                if (fs[4] <= 23.5) {
                                    return 0.271158436804;
                                } else {
                                    return 0.227234553517;
                                }
                            }
                        } else {
                            if (fs[2] <= 9.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[72] <= 9531.0) {
                                        return -0.0545038698813;
                                    } else {
                                        return 0.0251535934139;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.00648488171055;
                                    } else {
                                        return 0.0812850484286;
                                    }
                                }
                            } else {
                                if (fs[47] <= -6.5) {
                                    if (fs[47] <= -12.0) {
                                        return 0.023196449139;
                                    } else {
                                        return -0.255139008628;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0014536218092;
                                    } else {
                                        return 0.165116505038;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            return 0.249039146864;
                        } else {
                            if (fs[101] <= 1.0) {
                                return -0.141662943448;
                            } else {
                                if (fs[53] <= -1118.0) {
                                    if (fs[4] <= 26.5) {
                                        return 0.0640985695794;
                                    } else {
                                        return -0.188863329011;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.217081494;
                                    } else {
                                        return 0.000802861069201;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[4] <= 3.5) {
                if (fs[88] <= 6.5) {
                    if (fs[101] <= 0.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[15] <= 0.5) {
                                        return -0.0564838933608;
                                    } else {
                                        return -0.0230675615555;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0856160992255;
                                    } else {
                                        return -0.0220707222685;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0651162951594;
                                    } else {
                                        return 0.13316936889;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0774577083628;
                                    } else {
                                        return 0.0342398342409;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 3.5) {
                                if (fs[72] <= 9997.5) {
                                    if (fs[47] <= -1033.0) {
                                        return 0.0992217303799;
                                    } else {
                                        return -0.00368598095775;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0448082593768;
                                    } else {
                                        return -0.085052683639;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[88] <= 5.5) {
                                        return 0.037965717067;
                                    } else {
                                        return -0.0136260935542;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0436797326792;
                                    } else {
                                        return 0.00209497820158;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[27] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.047412776121;
                                    } else {
                                        return -0.0169629017816;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0367361092737;
                                    } else {
                                        return -0.00510270573003;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.00714554784798;
                                    } else {
                                        return 0.218277005889;
                                    }
                                } else {
                                    if (fs[53] <= -1468.0) {
                                        return -0.0900721177051;
                                    } else {
                                        return 0.0225090711905;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.107006115316;
                                    } else {
                                        return 0.051500222314;
                                    }
                                } else {
                                    return 0.208515285839;
                                }
                            } else {
                                return -0.0264721377339;
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 3.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[72] <= 9995.5) {
                                if (fs[53] <= -486.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0394592334165;
                                    } else {
                                        return 0.158209028269;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0249780944237;
                                    } else {
                                        return 0.0352004643319;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0842022769475;
                                    } else {
                                        return -0.115823246207;
                                    }
                                } else {
                                    return -0.132399194097;
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0350278059528;
                                    } else {
                                        return 0.107184497818;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.138848450293;
                                    } else {
                                        return 0.385800161883;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[47] <= -5.5) {
                                        return 0.426334260115;
                                    } else {
                                        return 0.0128312264979;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.219722026561;
                                    } else {
                                        return 0.0951200714016;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[23] <= 0.5) {
                            if (fs[53] <= -1488.0) {
                                if (fs[0] <= 2.5) {
                                    return -0.0673900107518;
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0398535922217;
                                    } else {
                                        return -0.0242266282093;
                                    }
                                }
                            } else {
                                return 0.117441794462;
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[72] <= 4981.0) {
                                    return -0.0646841156106;
                                } else {
                                    return -0.187246789248;
                                }
                            } else {
                                return -0.143139073842;
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 2.5) {
                    if (fs[14] <= 0.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[15] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00424506039258;
                                    } else {
                                        return -0.00214339814895;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0300327845405;
                                    } else {
                                        return 0.301945068252;
                                    }
                                }
                            } else {
                                if (fs[53] <= -983.0) {
                                    return 0.0603044449355;
                                } else {
                                    if (fs[0] <= 25.5) {
                                        return -0.118714906455;
                                    } else {
                                        return -0.0578416522455;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                return 0.132948432685;
                            } else {
                                return 0.160842965769;
                            }
                        }
                    } else {
                        if (fs[4] <= 5.5) {
                            if (fs[70] <= -4.0) {
                                if (fs[0] <= 18.0) {
                                    return -0.0308557491809;
                                } else {
                                    return -0.013449218305;
                                }
                            } else {
                                if (fs[53] <= -491.5) {
                                    return 0.0234145689783;
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0546153244825;
                                    } else {
                                        return 0.284249316686;
                                    }
                                }
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.00741469702425;
                                    } else {
                                        return 0.128273968194;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.00746580528349;
                                    } else {
                                        return -0.00656024725729;
                                    }
                                }
                            } else {
                                return 0.17741084259;
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 8690.0) {
                        if (fs[26] <= 0.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[4] <= 15.5) {
                                    if (fs[0] <= 6.5) {
                                        return 0.0119714998636;
                                    } else {
                                        return 0.000722797642157;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.00131898972163;
                                    } else {
                                        return -0.0115749034446;
                                    }
                                }
                            } else {
                                if (fs[47] <= -479.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.103117351397;
                                    } else {
                                        return 0.000826080905198;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.00356533915572;
                                    } else {
                                        return 0.00463855404393;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 43.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0943596326489;
                                    } else {
                                        return -0.0120082173623;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.076201722622;
                                    } else {
                                        return -0.00820235090367;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    return 0.279255030859;
                                } else {
                                    return 0.390072451319;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 10.5) {
                            if (fs[88] <= 5.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.0656122867009;
                                    } else {
                                        return 0.0162645145893;
                                    }
                                } else {
                                    if (fs[72] <= 9987.5) {
                                        return 0.0292431113624;
                                    } else {
                                        return 0.306604944486;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1468.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0731674153407;
                                    } else {
                                        return 0.293686808956;
                                    }
                                } else {
                                    if (fs[47] <= -1681.5) {
                                        return 0.312514309802;
                                    } else {
                                        return 0.0169780726231;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                if (fs[53] <= -1418.0) {
                                    if (fs[47] <= -1649.5) {
                                        return 0.368252737773;
                                    } else {
                                        return 0.0492003440183;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.0064081879517;
                                    } else {
                                        return 0.0654146322065;
                                    }
                                }
                            } else {
                                if (fs[55] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0137774425427;
                                    } else {
                                        return -0.0774522926716;
                                    }
                                } else {
                                    return 0.269715534546;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
