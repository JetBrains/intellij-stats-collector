/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree97 {
    public double calcTree(double... fs) {
        if (fs[57] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[71] <= 0.5) {
                    if (fs[88] <= 6.5) {
                        if (fs[59] <= 0.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.0230297125958;
                                    } else {
                                        return -0.0512172845743;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0376236778443;
                                    } else {
                                        return 0.142413297711;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9977.0) {
                                    if (fs[47] <= -6.0) {
                                        return -0.182699991086;
                                    } else {
                                        return 0.153816328443;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0246146286056;
                                    } else {
                                        return 0.0827856766422;
                                    }
                                }
                            }
                        } else {
                            if (fs[94] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.0103227762737;
                                    } else {
                                        return -0.0254595994279;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return 0.101076269028;
                                    } else {
                                        return -0.0927122723889;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 18.5) {
                                        return 0.0559297193807;
                                    } else {
                                        return -0.205114681213;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0149007975059;
                                    } else {
                                        return 0.129824009171;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[37] <= 0.5) {
                            if (fs[4] <= 16.5) {
                                if (fs[39] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0783745926423;
                                    } else {
                                        return 0.0336324758173;
                                    }
                                } else {
                                    return -0.15629321191;
                                }
                            } else {
                                if (fs[88] <= 7.5) {
                                    return -0.322706118221;
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.207492727193;
                                    } else {
                                        return 0.412481520561;
                                    }
                                }
                            }
                        } else {
                            return -0.152705364423;
                        }
                    }
                } else {
                    if (fs[76] <= 250.0) {
                        if (fs[49] <= -1.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.107966199367;
                                    } else {
                                        return 0.153428078875;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0375428847042;
                                    } else {
                                        return 0.149589715903;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    return 0.256229110521;
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.186470585603;
                                    } else {
                                        return 0.123419767019;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[53] <= -1453.5) {
                                        return -0.0258926211187;
                                    } else {
                                        return 0.0060186471299;
                                    }
                                } else {
                                    if (fs[72] <= 8673.0) {
                                        return -0.0415767761444;
                                    } else {
                                        return -0.00536310497634;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0145406305638;
                                    } else {
                                        return 0.0650507954448;
                                    }
                                } else {
                                    if (fs[4] <= 11.0) {
                                        return -0.161889576415;
                                    } else {
                                        return 0.0875868890446;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -528.5) {
                            if (fs[4] <= 11.5) {
                                return 0.0616724243668;
                            } else {
                                return -0.475750494205;
                            }
                        } else {
                            if (fs[76] <= 350.0) {
                                if (fs[83] <= 0.5) {
                                    if (fs[53] <= -1142.5) {
                                        return 0.00351522666774;
                                    } else {
                                        return 0.023798727679;
                                    }
                                } else {
                                    if (fs[67] <= 0.5) {
                                        return -0.0744832792326;
                                    } else {
                                        return -0.428835326423;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0318754436625;
                                    } else {
                                        return 0.200193425321;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.147479383104;
                                    } else {
                                        return -0.0265988181566;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[30] <= 0.5) {
                    if (fs[47] <= -0.5) {
                        if (fs[4] <= 3.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[72] <= 9889.0) {
                                        return -0.00352797462224;
                                    } else {
                                        return 0.0241315197719;
                                    }
                                } else {
                                    return 0.121978391033;
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.00193626137989;
                                    } else {
                                        return 0.0156365036903;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0343718410628;
                                    } else {
                                        return 0.121512090392;
                                    }
                                }
                            }
                        } else {
                            if (fs[15] <= 0.5) {
                                if (fs[88] <= 5.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.000487566448601;
                                    } else {
                                        return 0.00159848302279;
                                    }
                                } else {
                                    if (fs[31] <= 0.5) {
                                        return -0.00214988647472;
                                    } else {
                                        return 0.00822475475834;
                                    }
                                }
                            } else {
                                if (fs[53] <= -983.0) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0531498464173;
                                    } else {
                                        return 0.0648855300567;
                                    }
                                } else {
                                    if (fs[0] <= 25.5) {
                                        return -0.115798097355;
                                    } else {
                                        return -0.0531009001145;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9534.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[4] <= 20.5) {
                                        return -0.0108132115382;
                                    } else {
                                        return 0.00321928263105;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0975228747462;
                                    } else {
                                        return -0.00375512103751;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.00218336737922;
                                    } else {
                                        return -0.00778352769012;
                                    }
                                } else {
                                    if (fs[53] <= -1303.0) {
                                        return -0.0841879610741;
                                    } else {
                                        return 0.0453387861508;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -4.0) {
                                if (fs[72] <= 9997.5) {
                                    return 0.328380541365;
                                } else {
                                    return -0.0835749854791;
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.167287291225;
                                    } else {
                                        return -0.0201145189461;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.0134915788055;
                                    } else {
                                        return 0.0404496259832;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 5.5) {
                        return 0.0518397748735;
                    } else {
                        if (fs[53] <= -1138.0) {
                            return -0.0542388304494;
                        } else {
                            return 0.206843034847;
                        }
                    }
                }
            }
        } else {
            if (fs[18] <= 0.5) {
                if (fs[53] <= -1138.5) {
                    if (fs[0] <= 1.5) {
                        return -0.139366184463;
                    } else {
                        if (fs[4] <= 16.5) {
                            return -0.0212311103646;
                        } else {
                            if (fs[0] <= 17.5) {
                                return -0.0647749153651;
                            } else {
                                return -0.0318409795281;
                            }
                        }
                    }
                } else {
                    if (fs[52] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[103] <= 0.5) {
                                return 0.0191940903498;
                            } else {
                                return -0.0479799440303;
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                return 0.0387160147983;
                            } else {
                                return 0.149106964326;
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[45] <= 0.5) {
                                return -0.022437286671;
                            } else {
                                return -0.0103716127702;
                            }
                        } else {
                            return -0.0814000309901;
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[101] <= 0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[88] <= 7.5) {
                                    return -0.17548762872;
                                } else {
                                    return -0.11977729354;
                                }
                            } else {
                                return 0.0887202766676;
                            }
                        } else {
                            if (fs[62] <= -1.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.0451441316007;
                                    } else {
                                        return 0.111696238817;
                                    }
                                } else {
                                    return -0.000216243448715;
                                }
                            } else {
                                if (fs[47] <= -2.5) {
                                    return 0.0541944303455;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.184539349617;
                                    } else {
                                        return 0.103116663957;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[103] <= 0.5) {
                            if (fs[48] <= 0.5) {
                                return 0.0688646159794;
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.13982874115;
                                    } else {
                                        return 0.0648952734273;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.253034581971;
                                    } else {
                                        return 0.140913457601;
                                    }
                                }
                            }
                        } else {
                            return -0.0291476199066;
                        }
                    }
                } else {
                    if (fs[53] <= -1138.0) {
                        if (fs[47] <= -1.5) {
                            return -0.163123080806;
                        } else {
                            if (fs[12] <= 0.5) {
                                return 0.117295453229;
                            } else {
                                return 0.415738062971;
                            }
                        }
                    } else {
                        if (fs[72] <= 9995.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[76] <= 100.0) {
                                        return -0.0993974481132;
                                    } else {
                                        return -0.00932041412772;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0648669473688;
                                    } else {
                                        return -0.0151328025771;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return -0.0348811646264;
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0227719631782;
                                    } else {
                                        return 0.241222889453;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                return -0.0366754483823;
                            } else {
                                return 0.176975230896;
                            }
                        }
                    }
                }
            }
        }
    }
}
