/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree4 {
    public double calcTree(double... fs) {
        if (fs[27] <= 0.5) {
            if (fs[81] <= 0.5) {
                if (fs[101] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.715993864087;
                                    } else {
                                        return 0.66342564849;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.689394687661;
                                    } else {
                                        return 0.765647798744;
                                    }
                                }
                            } else {
                                if (fs[30] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.556799603285;
                                    } else {
                                        return 0.733666011479;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.642066755565;
                                    } else {
                                        return 0.722429845709;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.76562345535;
                                    } else {
                                        return 0.633709716304;
                                    }
                                } else {
                                    if (fs[53] <= -1138.5) {
                                        return 0.725266911943;
                                    } else {
                                        return 0.758267166033;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.764333326889;
                                    } else {
                                        return 0.304696789194;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.723735780296;
                                    } else {
                                        return 0.767488313199;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -988.0) {
                            if (fs[11] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.166958400864;
                                    } else {
                                        return 0.0470605410642;
                                    }
                                } else {
                                    return 0.418503967714;
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.0747753180012;
                                    } else {
                                        return 0.711949200995;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0572447933921;
                                    } else {
                                        return -0.0622087253326;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 25.5) {
                                if (fs[0] <= 24.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0180861544398;
                                    } else {
                                        return -0.0241699030659;
                                    }
                                } else {
                                    return 0.300828931632;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0475975491227;
                                    } else {
                                        return -0.0521819200326;
                                    }
                                } else {
                                    return -0.00715714811799;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1568.0) {
                        if (fs[79] <= 0.5) {
                            if (fs[4] <= 39.5) {
                                if (fs[4] <= 21.5) {
                                    return 0.0995438634391;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0704354736353;
                                    } else {
                                        return -0.0561091719562;
                                    }
                                }
                            } else {
                                if (fs[4] <= 42.0) {
                                    return 0.276125495526;
                                } else {
                                    return -0.0670922931106;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return 0.50967043317;
                            } else {
                                return -0.0509065274044;
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[53] <= -1328.0) {
                                    return -0.091337279503;
                                } else {
                                    return 0.209958058024;
                                }
                            } else {
                                return 0.303580647862;
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[72] <= 4847.0) {
                                    if (fs[4] <= 31.5) {
                                        return -1.1917095334e-05;
                                    } else {
                                        return -0.0440916451554;
                                    }
                                } else {
                                    return 0.112973351056;
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 45.5) {
                                        return -0.0482836529722;
                                    } else {
                                        return -0.0466828594383;
                                    }
                                } else {
                                    if (fs[53] <= -987.0) {
                                        return -0.0551507037243;
                                    } else {
                                        return -0.0489330453867;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[72] <= 9993.5) {
                    if (fs[26] <= 0.5) {
                        if (fs[47] <= -7.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0104241432276;
                                    } else {
                                        return 0.0655961573564;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.429217278931;
                                    } else {
                                        return 0.00230020968312;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.53212265219;
                                    } else {
                                        return 0.72015187462;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.141683643028;
                                    } else {
                                        return -0.0180830500706;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9774.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.512762907096;
                                    } else {
                                        return 0.352970862575;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.042721670261;
                                    } else {
                                        return -0.0276344301406;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.0227661132831;
                                    } else {
                                        return 0.397449549711;
                                    }
                                } else {
                                    if (fs[67] <= 0.5) {
                                        return 0.198568034735;
                                    } else {
                                        return 0.553307606163;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1093.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.404657241327;
                                    } else {
                                        return -0.023713883442;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.593371993493;
                                    } else {
                                        return 0.0135320464373;
                                    }
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.622322722051;
                                    } else {
                                        return 0.0187855525215;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.656852160949;
                                    } else {
                                        return 0.146936594715;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[53] <= -1008.5) {
                                        return 0.689799421634;
                                    } else {
                                        return 0.199989366761;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0417854356357;
                                    } else {
                                        return 0.0030105271927;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.348597734016;
                                    } else {
                                        return -0.0275408890095;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.324992245827;
                                    } else {
                                        return -0.038331992607;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1052.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[82] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.037946799646;
                                    } else {
                                        return 0.559514721159;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.644445923652;
                                    } else {
                                        return 0.733025560685;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.609748378452;
                                    } else {
                                        return 0.781753554085;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.774099329459;
                                    } else {
                                        return 0.63128159146;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.121798887153;
                                    } else {
                                        return 0.313167573619;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0498694518296;
                                    } else {
                                        return 0.192810521748;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[47] <= -2.5) {
                                        return 0.176164489465;
                                    } else {
                                        return 0.448475253189;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.297993468782;
                                    } else {
                                        return 0.641328509314;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.794894973355;
                                    } else {
                                        return 0.58939437579;
                                    }
                                } else {
                                    if (fs[88] <= 1.0) {
                                        return 0.367267243802;
                                    } else {
                                        return 0.592705326226;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[76] <= 250.0) {
                                        return 0.565457458777;
                                    } else {
                                        return 0.145136054029;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.207669131977;
                                    } else {
                                        return 0.499664204434;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.124019276592;
                                    } else {
                                        return 0.0282963652803;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0363145847543;
                                    } else {
                                        return 0.116650476901;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[88] <= 7.5) {
                                        return -0.0469251610374;
                                    } else {
                                        return -0.0069960534281;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return 0.13004222724;
                                    } else {
                                        return -0.0584868110946;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[103] <= 1.5) {
                if (fs[53] <= -1047.5) {
                    if (fs[4] <= 8.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[62] <= -0.5) {
                                return 0.609877947992;
                            } else {
                                if (fs[72] <= 9996.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.684010823858;
                                    } else {
                                        return 0.0732253283306;
                                    }
                                } else {
                                    return 0.708944096009;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[49] <= -0.5) {
                                    return 0.784569987259;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.73623472477;
                                    } else {
                                        return 0.784196326355;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    return 0.0956922906589;
                                } else {
                                    return 0.130263859551;
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9997.5) {
                            if (fs[64] <= -995.5) {
                                if (fs[60] <= 0.5) {
                                    return 0.342466613151;
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.715484552716;
                                    } else {
                                        return 0.305265784695;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[62] <= -1.5) {
                                        return 0.204787879811;
                                    } else {
                                        return 0.586654656339;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0838681304995;
                                    } else {
                                        return -0.0161606663734;
                                    }
                                }
                            }
                        } else {
                            if (fs[64] <= -498.0) {
                                if (fs[53] <= -1138.0) {
                                    return 0.645053797628;
                                } else {
                                    return 0.812348936459;
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    return 0.141177554155;
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.519896482636;
                                    } else {
                                        return 0.085559764621;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[81] <= 0.5) {
                        if (fs[12] <= 0.5) {
                            return 0.793973078415;
                        } else {
                            return 0.73553192131;
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.195103996787;
                                } else {
                                    return 0.483025963123;
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[64] <= -498.5) {
                                        return 0.366149830597;
                                    } else {
                                        return 0.352221382419;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.449079631252;
                                    } else {
                                        return 0.77243201145;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                return 0.249527665631;
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.111398628649;
                                    } else {
                                        return 0.00308135424315;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.00623963847688;
                                    } else {
                                        return -0.0462206257136;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[62] <= -0.5) {
                    if (fs[45] <= 0.5) {
                        if (fs[49] <= -0.5) {
                            if (fs[62] <= -3.5) {
                                return 0.326159479137;
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[58] <= 0.5) {
                                        return 0.756029352417;
                                    } else {
                                        return 0.682315080309;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.35757319108;
                                    } else {
                                        return 0.60713087297;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -1.5) {
                                if (fs[53] <= -1138.0) {
                                    return 0.623158312395;
                                } else {
                                    return 0.789189107284;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    return 0.658859533104;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0589092661134;
                                    } else {
                                        return -0.0634109356348;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[62] <= -2.5) {
                            return 0.109671361593;
                        } else {
                            if (fs[53] <= -986.0) {
                                if (fs[64] <= -997.5) {
                                    return 0.0120489047752;
                                } else {
                                    return -0.0493419169182;
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0552813949818;
                                    } else {
                                        return -0.0484072054582;
                                    }
                                } else {
                                    return -0.0545088432301;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[53] <= -986.0) {
                            if (fs[53] <= -1138.5) {
                                if (fs[97] <= 0.5) {
                                    return 0.795275674725;
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.705206891079;
                                    } else {
                                        return 0.27710733806;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.7364138927;
                                    } else {
                                        return 0.120799952715;
                                    }
                                } else {
                                    if (fs[53] <= -1128.5) {
                                        return 0.770816715335;
                                    } else {
                                        return 0.785919852427;
                                    }
                                }
                            }
                        } else {
                            return 0.402487375767;
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                return 0.193501074238;
                            } else {
                                if (fs[4] <= 7.5) {
                                    return 0.207962955677;
                                } else {
                                    return 0.460907543862;
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                return 0.028561352836;
                            } else {
                                if (fs[53] <= 17.5) {
                                    if (fs[53] <= -976.5) {
                                        return -0.0330684896273;
                                    } else {
                                        return -0.0449229828799;
                                    }
                                } else {
                                    return 0.0112893265622;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
