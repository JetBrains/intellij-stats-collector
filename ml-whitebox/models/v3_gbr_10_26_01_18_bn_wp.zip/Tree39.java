/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree39 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[70] <= -1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[53] <= -1138.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.142471063245;
                                    } else {
                                        return 0.0462547649349;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.203710384661;
                                    } else {
                                        return 0.143716373866;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.165323153384;
                                    } else {
                                        return -0.0920731079434;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.00292611037109;
                                    } else {
                                        return 0.0832697088495;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0885232409603;
                                    } else {
                                        return 0.136029703325;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.124608866897;
                                    } else {
                                        return 0.00140378822826;
                                    }
                                }
                            } else {
                                return -0.0531872630997;
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[72] <= 9997.5) {
                                if (fs[53] <= -988.0) {
                                    if (fs[53] <= -1118.5) {
                                        return 0.138807657876;
                                    } else {
                                        return 0.159275800945;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0132597738394;
                                    } else {
                                        return 0.156459195809;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.198227043454;
                                    } else {
                                        return 0.279875846104;
                                    }
                                } else {
                                    return 0.177910691949;
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.136591210145;
                                } else {
                                    return 0.13873402087;
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return -0.194848639417;
                                } else {
                                    return 0.0869890255635;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[52] <= 0.5) {
                        if (fs[15] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[103] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.00622748820137;
                                    } else {
                                        return 0.12990253287;
                                    }
                                } else {
                                    if (fs[4] <= 90.5) {
                                        return -0.0413909847454;
                                    } else {
                                        return 0.0414065603081;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0218431877265;
                                    } else {
                                        return -0.0436637532198;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0257556866916;
                                    } else {
                                        return -0.0493115028452;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 25.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.00200630044864;
                                    } else {
                                        return -0.0331153080246;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0538503262225;
                                    } else {
                                        return 0.0964336978102;
                                    }
                                }
                            } else {
                                if (fs[0] <= 28.5) {
                                    return -0.0517272396673;
                                } else {
                                    return -0.0848010973218;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0998809979778;
                                    } else {
                                        return -0.0189081307433;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.223328460394;
                                    } else {
                                        return 0.160478293479;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[53] <= -1053.0) {
                                        return 0.0374799622402;
                                    } else {
                                        return -0.0417809988465;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.286520812481;
                                    } else {
                                        return 0.177434623722;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.0417652322548;
                                    } else {
                                        return -0.0322740643452;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0483160219987;
                                    } else {
                                        return -0.0193589857052;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0210363643393;
                                    } else {
                                        return -0.0281673505872;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0420726792367;
                                    } else {
                                        return 0.0687898657549;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[101] <= 0.5) {
                    if (fs[45] <= 0.5) {
                        if (fs[4] <= 8.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[72] <= 9990.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.108166673154;
                                    } else {
                                        return 0.17857447633;
                                    }
                                } else {
                                    return 0.0555434208243;
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return -0.107054165397;
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0159263319779;
                                    } else {
                                        return -0.0220312969896;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.148636007006;
                                    } else {
                                        return 0.178580316249;
                                    }
                                } else {
                                    return 0.301794959814;
                                }
                            } else {
                                return 0.0457087472805;
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[72] <= 4984.0) {
                                return -0.057832331932;
                            } else {
                                return -0.110159207383;
                            }
                        } else {
                            return -0.0347532422454;
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 19.5) {
                                    return 0.0383822392348;
                                } else {
                                    if (fs[4] <= 39.5) {
                                        return -0.0455797282739;
                                    } else {
                                        return -0.0182218985874;
                                    }
                                }
                            } else {
                                if (fs[53] <= -992.0) {
                                    if (fs[4] <= 19.5) {
                                        return -0.0266913071625;
                                    } else {
                                        return -0.022570343266;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return -0.0113302008963;
                                    } else {
                                        return -0.00862345854092;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[0] <= 0.5) {
                                    return -0.0734926792343;
                                } else {
                                    return -0.0501007923012;
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.137633887697;
                                    } else {
                                        return -0.00523043968875;
                                    }
                                } else {
                                    if (fs[4] <= 34.5) {
                                        return -0.0787624133841;
                                    } else {
                                        return -0.0468285389635;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            return 0.00532609822715;
                        } else {
                            if (fs[53] <= -992.0) {
                                if (fs[0] <= 6.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.0152406028998;
                                    } else {
                                        return -0.0121368796395;
                                    }
                                } else {
                                    if (fs[53] <= -1558.0) {
                                        return -0.0137648115338;
                                    } else {
                                        return -0.00895462592318;
                                    }
                                }
                            } else {
                                return -0.00668584514696;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[99] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[88] <= 6.5) {
                        if (fs[22] <= 0.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.169996974987;
                                    } else {
                                        return 0.0881328799;
                                    }
                                } else {
                                    if (fs[72] <= 9902.0) {
                                        return -0.060364188709;
                                    } else {
                                        return 0.148631322067;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1504.0) {
                                    if (fs[88] <= 3.5) {
                                        return 0.220499979317;
                                    } else {
                                        return -0.00609666182938;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return 0.0539875359637;
                                    } else {
                                        return 0.224604950858;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.222256671582;
                                    } else {
                                        return 0.14424239124;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0310738594812;
                                    } else {
                                        return 0.0762763092529;
                                    }
                                }
                            } else {
                                if (fs[88] <= 5.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0833344907531;
                                    } else {
                                        return 0.0774160118397;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0254835859829;
                                    } else {
                                        return -0.174662085606;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -972.0) {
                                if (fs[72] <= 9996.5) {
                                    if (fs[72] <= 9295.0) {
                                        return 0.143352286202;
                                    } else {
                                        return 0.015486974327;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.241964778543;
                                    } else {
                                        return 0.164122684777;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[70] <= -4.0) {
                                        return 0.314460638606;
                                    } else {
                                        return -0.00646473173579;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.100196248564;
                                    } else {
                                        return -0.0220015931885;
                                    }
                                }
                            }
                        } else {
                            if (fs[28] <= 0.5) {
                                if (fs[4] <= 23.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.194165164034;
                                    } else {
                                        return 0.128938990713;
                                    }
                                } else {
                                    return -0.400830636781;
                                }
                            } else {
                                if (fs[47] <= -12.5) {
                                    return -0.470468246428;
                                } else {
                                    if (fs[4] <= 6.0) {
                                        return 0.1261520568;
                                    } else {
                                        return -0.396312044769;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[55] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[72] <= 9985.5) {
                                        return -0.00506553278456;
                                    } else {
                                        return 0.0345177780167;
                                    }
                                } else {
                                    if (fs[47] <= -107.5) {
                                        return 0.10030194955;
                                    } else {
                                        return 0.0252427713951;
                                    }
                                }
                            } else {
                                if (fs[55] <= 547.5) {
                                    return 0.367084538008;
                                } else {
                                    return 0.138423906826;
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[88] <= 5.5) {
                                    if (fs[64] <= -498.5) {
                                        return 0.511408603513;
                                    } else {
                                        return 0.000764955351226;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.334254694448;
                                    } else {
                                        return 0.127379741685;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0710585830515;
                                    } else {
                                        return 0.336049469666;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0734154524099;
                                    } else {
                                        return 0.20312362397;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[85] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00783161770432;
                                    } else {
                                        return -0.00360588708127;
                                    }
                                } else {
                                    if (fs[88] <= -0.5) {
                                        return -0.0135004372832;
                                    } else {
                                        return -0.00194482979388;
                                    }
                                }
                            } else {
                                if (fs[47] <= -345.0) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0272909404308;
                                    } else {
                                        return 0.356870703356;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.0148670774501;
                                    } else {
                                        return -0.00840399282321;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[0] <= 9.5) {
                                        return 0.012172526908;
                                    } else {
                                        return -0.00742759307346;
                                    }
                                } else {
                                    if (fs[72] <= 8756.5) {
                                        return 0.0370185456161;
                                    } else {
                                        return 0.159631708435;
                                    }
                                }
                            } else {
                                if (fs[88] <= 1.5) {
                                    if (fs[0] <= 6.5) {
                                        return 0.00972371301167;
                                    } else {
                                        return -0.00641584411906;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return -0.0118025889305;
                                    } else {
                                        return 0.000906742181135;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 8.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[53] <= -1458.5) {
                                    if (fs[47] <= -35.5) {
                                        return 0.0483650274132;
                                    } else {
                                        return 0.177187921972;
                                    }
                                } else {
                                    if (fs[4] <= 1.5) {
                                        return 0.0636862199703;
                                    } else {
                                        return 0.130829506233;
                                    }
                                }
                            } else {
                                if (fs[47] <= -60.5) {
                                    return -0.320360785292;
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.00243889955458;
                                    } else {
                                        return 0.162244235138;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[103] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.106296567264;
                                    } else {
                                        return 0.271844018333;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.215001614963;
                                    } else {
                                        return 0.0514459453488;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.140474277779;
                                    } else {
                                        return 0.00774403238824;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.0733316916559;
                                    } else {
                                        return -0.268170945453;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[53] <= -1468.5) {
                                if (fs[50] <= 0.5) {
                                    if (fs[72] <= 9896.5) {
                                        return 0.128402019268;
                                    } else {
                                        return 0.279896575586;
                                    }
                                } else {
                                    return -0.0175250852661;
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[53] <= -1132.5) {
                                        return 0.0668299250691;
                                    } else {
                                        return -0.00670257168496;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.0272756017904;
                                    } else {
                                        return -0.0212045342607;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[83] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0051101214997;
                                    } else {
                                        return -0.0114306647584;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.226853850569;
                                    } else {
                                        return 0.0483360270642;
                                    }
                                }
                            } else {
                                if (fs[0] <= 9.5) {
                                    if (fs[83] <= 0.5) {
                                        return 0.0185630116619;
                                    } else {
                                        return 0.292513422605;
                                    }
                                } else {
                                    if (fs[53] <= -1118.0) {
                                        return 0.109703271305;
                                    } else {
                                        return 0.0105851958744;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[49] <= -0.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.153260135117;
                                    } else {
                                        return 0.0486980161563;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.107560739292;
                                    } else {
                                        return -0.00590158732324;
                                    }
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    if (fs[53] <= -1398.0) {
                                        return 0.0542247826808;
                                    } else {
                                        return 0.0165239323335;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0837814540155;
                                    } else {
                                        return 0.250781518667;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[72] <= 9997.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.205240004038;
                                    } else {
                                        return -0.0102483318271;
                                    }
                                } else {
                                    if (fs[53] <= -992.0) {
                                        return 0.129992296326;
                                    } else {
                                        return 0.0169349208584;
                                    }
                                }
                            } else {
                                if (fs[47] <= -7.5) {
                                    if (fs[53] <= -1017.0) {
                                        return -0.090567578949;
                                    } else {
                                        return -0.0204920337685;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.231309648618;
                                    } else {
                                        return -0.0136600619581;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[53] <= -1588.0) {
                                if (fs[47] <= -27.5) {
                                    if (fs[47] <= -59.5) {
                                        return 0.170351309454;
                                    } else {
                                        return 0.410083994067;
                                    }
                                } else {
                                    if (fs[53] <= -2473.5) {
                                        return 0.35471069223;
                                    } else {
                                        return 0.193736854274;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return 0.028244121697;
                                    } else {
                                        return 0.208466978808;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.227853020336;
                                    } else {
                                        return 0.102806047198;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 19.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0102642073318;
                                    } else {
                                        return 0.00330356138245;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.185646441991;
                                    } else {
                                        return 0.0597636901499;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[72] <= 9997.5) {
                                        return -0.0117405501528;
                                    } else {
                                        return 0.022264217578;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.460541486299;
                                    } else {
                                        return 0.00949391371972;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
