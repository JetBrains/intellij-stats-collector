/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree47 {
    public double calcTree(double... fs) {
        if (fs[103] <= 1.5) {
            if (fs[81] <= 0.5) {
                if (fs[76] <= 100.0) {
                    if (fs[0] <= 0.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0304982235847;
                                    } else {
                                        return 0.086267161143;
                                    }
                                } else {
                                    return -0.0228148406501;
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.22767516034;
                                    } else {
                                        return 0.126008514894;
                                    }
                                } else {
                                    return 0.0587053777353;
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[27] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.101678571517;
                                    } else {
                                        return 0.0922431799515;
                                    }
                                } else {
                                    return 0.173838566117;
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    return 0.100962244668;
                                } else {
                                    return -0.0639116598922;
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.056992834569;
                                    } else {
                                        return -0.0116955218919;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0434301864884;
                                    } else {
                                        return -0.0342815986536;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.0430918932277;
                                    } else {
                                        return -0.0358951201694;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.132636008102;
                                    } else {
                                        return -0.100632441084;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.255767016098;
                                    } else {
                                        return -0.0356930581436;
                                    }
                                } else {
                                    return 0.0666210387793;
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0148487815088;
                                    } else {
                                        return 0.111060563767;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.00940565042892;
                                    } else {
                                        return -0.029417455563;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[79] <= 0.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 39.5) {
                                    if (fs[53] <= -1538.0) {
                                        return -0.174848727338;
                                    } else {
                                        return -0.0614311575585;
                                    }
                                } else {
                                    if (fs[53] <= -1578.0) {
                                        return 0.0441114609632;
                                    } else {
                                        return 0.0322518741292;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    return -0.0115496072402;
                                } else {
                                    return 0.0290967387276;
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                return -0.0262307235934;
                            } else {
                                if (fs[4] <= 37.5) {
                                    if (fs[0] <= 7.5) {
                                        return -0.0117139690411;
                                    } else {
                                        return -0.00516965913891;
                                    }
                                } else {
                                    return -0.00990033115233;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 32.5) {
                            if (fs[72] <= 4847.0) {
                                if (fs[53] <= -1558.0) {
                                    return 0.0954203795569;
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.0373569433772;
                                    } else {
                                        return 0.0176426966874;
                                    }
                                }
                            } else {
                                return 0.0798889089147;
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 35.0) {
                                    return -0.117244110554;
                                } else {
                                    return -0.0474114734649;
                                }
                            } else {
                                if (fs[4] <= 48.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0228293143976;
                                    } else {
                                        return -0.0162408958909;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return 0.0650869163128;
                                    } else {
                                        return -0.0176974114945;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[64] <= -996.5) {
                                        return 0.127585272319;
                                    } else {
                                        return 0.047476529537;
                                    }
                                } else {
                                    if (fs[72] <= 9995.5) {
                                        return 0.146512628399;
                                    } else {
                                        return 0.0891647708275;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0066599082783;
                                    } else {
                                        return -0.195276118347;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0334338560144;
                                    } else {
                                        return -0.0178048406706;
                                    }
                                }
                            }
                        } else {
                            if (fs[34] <= 0.5) {
                                if (fs[53] <= -1543.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.144833185101;
                                    } else {
                                        return -0.199940026252;
                                    }
                                } else {
                                    if (fs[72] <= 9969.5) {
                                        return -0.0216645931379;
                                    } else {
                                        return 0.0359139784521;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -546.5) {
                                        return 0.260344035793;
                                    } else {
                                        return 0.111090619614;
                                    }
                                } else {
                                    if (fs[72] <= 9954.5) {
                                        return 0.340238491519;
                                    } else {
                                        return 0.183662888903;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[47] <= -84.5) {
                                        return 0.134621679225;
                                    } else {
                                        return 0.0743893633126;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.143120678712;
                                    } else {
                                        return 0.102482810255;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[2] <= 9.5) {
                                        return -0.0281396015555;
                                    } else {
                                        return 0.202806594055;
                                    }
                                } else {
                                    if (fs[53] <= -1998.0) {
                                        return 0.189032200098;
                                    } else {
                                        return 0.0458469648661;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[53] <= -1538.0) {
                                    if (fs[43] <= 0.5) {
                                        return 0.0736158823501;
                                    } else {
                                        return 0.326789753753;
                                    }
                                } else {
                                    if (fs[51] <= 0.5) {
                                        return -0.0240989554872;
                                    } else {
                                        return 0.267415772545;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9902.0) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0536580965766;
                                    } else {
                                        return 0.219243080082;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.244078858404;
                                    } else {
                                        return 0.150608727855;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[4] <= 18.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[53] <= -1478.5) {
                                        return 0.0280816927689;
                                    } else {
                                        return 0.00584150585941;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0142538570354;
                                    } else {
                                        return 0.0209483583322;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[4] <= 11.5) {
                                        return 0.0183962326754;
                                    } else {
                                        return -0.018194166038;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0485660349261;
                                    } else {
                                        return 0.17954896097;
                                    }
                                }
                            }
                        } else {
                            if (fs[55] <= 50.5) {
                                if (fs[31] <= 0.5) {
                                    if (fs[53] <= -0.5) {
                                        return -0.0134050674101;
                                    } else {
                                        return 0.0077071191678;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.320662341144;
                                    } else {
                                        return 0.194042502621;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9327.0) {
                                    return 0.0451653202565;
                                } else {
                                    return 0.395784095691;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 7.5) {
                            if (fs[47] <= -7.5) {
                                if (fs[53] <= -1408.0) {
                                    if (fs[88] <= 6.5) {
                                        return 0.0148523664844;
                                    } else {
                                        return 0.0955669837465;
                                    }
                                } else {
                                    if (fs[47] <= -8.5) {
                                        return -0.00743886699515;
                                    } else {
                                        return 0.0280246528281;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.00377139750318;
                                    } else {
                                        return -0.00353624018629;
                                    }
                                } else {
                                    if (fs[53] <= -997.0) {
                                        return -0.00523361691122;
                                    } else {
                                        return -0.0132236017255;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -9750.0) {
                                if (fs[47] <= -10662.0) {
                                    if (fs[47] <= -12712.5) {
                                        return -0.0136459993008;
                                    } else {
                                        return 0.138452922669;
                                    }
                                } else {
                                    return 0.438274660603;
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.00530383991396;
                                    } else {
                                        return -0.00653846418303;
                                    }
                                } else {
                                    if (fs[53] <= -461.0) {
                                        return -0.0175430082588;
                                    } else {
                                        return 0.0677103932741;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[23] <= 0.5) {
                    if (fs[97] <= 0.5) {
                        if (fs[4] <= 12.5) {
                            if (fs[52] <= 0.5) {
                                return 0.277809044105;
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return 0.135476198758;
                                } else {
                                    if (fs[53] <= -1128.5) {
                                        return 0.204734582293;
                                    } else {
                                        return 0.243230826862;
                                    }
                                }
                            }
                        } else {
                            return 0.320989042631;
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[4] <= 20.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -1018.5) {
                                        return 0.0931103527632;
                                    } else {
                                        return -0.0103014685253;
                                    }
                                } else {
                                    if (fs[53] <= -1128.5) {
                                        return 0.0524000316739;
                                    } else {
                                        return 0.118918155389;
                                    }
                                }
                            } else {
                                if (fs[49] <= -0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.150622332601;
                                    } else {
                                        return 0.216468882578;
                                    }
                                } else {
                                    if (fs[62] <= -0.5) {
                                        return -0.21902331899;
                                    } else {
                                        return -0.00142564592603;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0353047531627;
                                    } else {
                                        return 0.14153005373;
                                    }
                                } else {
                                    return -0.233844308227;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0562942952275;
                                    } else {
                                        return -0.0881840556441;
                                    }
                                } else {
                                    return -0.242863051128;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[79] <= 0.5) {
                        if (fs[53] <= -970.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    return -0.0298501113674;
                                } else {
                                    if (fs[58] <= 0.5) {
                                        return -0.257699006185;
                                    } else {
                                        return -0.372275368959;
                                    }
                                }
                            } else {
                                return -0.0600294293714;
                            }
                        } else {
                            return 0.228514545723;
                        }
                    } else {
                        return 0.100688603133;
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[50] <= 0.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0055844226039;
                                    } else {
                                        return -0.120744868517;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.148748794787;
                                    } else {
                                        return 0.266310371436;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.128538035013;
                                    } else {
                                        return 0.0306627756823;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.299269616566;
                                    } else {
                                        return 0.188041036829;
                                    }
                                }
                            }
                        } else {
                            return 0.388761003049;
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[62] <= -1.5) {
                                return 0.0482137724506;
                            } else {
                                if (fs[72] <= 9992.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.0694981416138;
                                    } else {
                                        return 0.133844726976;
                                    }
                                } else {
                                    return -0.151501048003;
                                }
                            }
                        } else {
                            if (fs[4] <= 25.5) {
                                if (fs[49] <= -1.5) {
                                    return -0.038524873231;
                                } else {
                                    if (fs[72] <= 4992.0) {
                                        return -0.014904021481;
                                    } else {
                                        return -0.0261433974075;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    return 0.045606243534;
                                } else {
                                    if (fs[4] <= 32.5) {
                                        return -0.0163606636355;
                                    } else {
                                        return 0.0216748604687;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1078.0) {
                        if (fs[64] <= -995.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.241651427495;
                                } else {
                                    return 0.484125489754;
                                }
                            } else {
                                return -0.0289786071148;
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[53] <= -1137.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00675594510853;
                                    } else {
                                        return 0.0307444481466;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.073498768217;
                                    } else {
                                        return 0.3045339661;
                                    }
                                }
                            } else {
                                if (fs[4] <= 24.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0265952402228;
                                    } else {
                                        return -0.0516235861629;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.175441107466;
                                    } else {
                                        return -0.00565691582457;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[70] <= -4.0) {
                            return 0.054111376028;
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[27] <= 0.5) {
                                        return -0.0403221189512;
                                    } else {
                                        return -0.135296199492;
                                    }
                                } else {
                                    if (fs[0] <= 6.0) {
                                        return 0.0176826553653;
                                    } else {
                                        return -0.0319392212712;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.00162601131616;
                                    } else {
                                        return -0.00803399242522;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.0193354387637;
                                    } else {
                                        return -0.00451183065556;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
