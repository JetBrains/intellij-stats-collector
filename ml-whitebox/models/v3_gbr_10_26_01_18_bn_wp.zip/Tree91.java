/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree91 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[88] <= -0.5) {
                if (fs[68] <= 1.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[24] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0934504123348;
                                    } else {
                                        return 0.125686371497;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.118387338374;
                                    } else {
                                        return -0.362629939123;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    return 0.0638877387045;
                                } else {
                                    return 0.18058966037;
                                }
                            }
                        } else {
                            return 0.138239968261;
                        }
                    } else {
                        return 0.280590359824;
                    }
                } else {
                    return -0.289176460447;
                }
            } else {
                if (fs[53] <= -1498.5) {
                    if (fs[70] <= -1.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[2] <= 0.5) {
                                return -0.325984940906;
                            } else {
                                if (fs[53] <= -1888.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0042389521667;
                                    } else {
                                        return 0.0724290753134;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.135132387562;
                                    } else {
                                        return 0.0523148470004;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[53] <= -1928.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0407446452814;
                                    } else {
                                        return -0.108792775407;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0555048412759;
                                    } else {
                                        return 0.181027705606;
                                    }
                                }
                            } else {
                                if (fs[47] <= -39.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.129052160031;
                                    } else {
                                        return -0.0525955293513;
                                    }
                                } else {
                                    if (fs[53] <= -2208.0) {
                                        return 0.159310079372;
                                    } else {
                                        return 0.071651623662;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[81] <= 0.5) {
                            if (fs[53] <= -1568.0) {
                                if (fs[78] <= 0.5) {
                                    return 0.252349174829;
                                } else {
                                    if (fs[4] <= 39.5) {
                                        return -0.098664819931;
                                    } else {
                                        return -0.0110897322668;
                                    }
                                }
                            } else {
                                return -0.115930848378;
                            }
                        } else {
                            if (fs[4] <= 21.5) {
                                return -0.411153745427;
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.224730806746;
                                    } else {
                                        return -0.0868364067143;
                                    }
                                } else {
                                    return -0.288213746752;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 19.5) {
                        if (fs[47] <= -6.5) {
                            if (fs[18] <= -0.5) {
                                if (fs[72] <= 9996.5) {
                                    return -0.271179341974;
                                } else {
                                    return -0.0659688141457;
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[2] <= 9.5) {
                                        return 0.0225577750507;
                                    } else {
                                        return 0.118496870353;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.0235779355245;
                                    } else {
                                        return -0.295880388984;
                                    }
                                }
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -1143.5) {
                                        return -0.0270043023649;
                                    } else {
                                        return 0.0192746218082;
                                    }
                                } else {
                                    if (fs[53] <= -476.0) {
                                        return 0.00911636421085;
                                    } else {
                                        return -0.0134226625313;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.035511142304;
                                    } else {
                                        return 0.0370794524016;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.0424647631549;
                                    } else {
                                        return -0.00424803476567;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[62] <= -1.5) {
                            if (fs[27] <= 0.5) {
                                if (fs[2] <= 10.5) {
                                    if (fs[4] <= 23.5) {
                                        return 0.0523222660635;
                                    } else {
                                        return 0.226279054441;
                                    }
                                } else {
                                    return 0.0343892647975;
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    return -0.141623747443;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0948067273255;
                                    } else {
                                        return 0.124289583467;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9975.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[25] <= 0.5) {
                                        return -0.0852965852997;
                                    } else {
                                        return 0.0405875620715;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0361933797596;
                                    } else {
                                        return 0.0546618752218;
                                    }
                                }
                            } else {
                                if (fs[4] <= 30.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.0308647834261;
                                    } else {
                                        return -0.190983260333;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.106238673092;
                                    } else {
                                        return -0.214396568807;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[55] <= 0.5) {
                if (fs[62] <= -1.5) {
                    if (fs[41] <= 0.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.0479906791453;
                                    } else {
                                        return 0.154236055415;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.019458610542;
                                    } else {
                                        return -0.0261980138164;
                                    }
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    if (fs[53] <= -386.5) {
                                        return -0.106794050918;
                                    } else {
                                        return -0.0522023181869;
                                    }
                                } else {
                                    return 0.0548981411424;
                                }
                            }
                        } else {
                            if (fs[4] <= 23.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return -0.0152472131858;
                                    } else {
                                        return -0.0335122400454;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.0139652855036;
                                    } else {
                                        return -0.00399688059584;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return 0.0990241058196;
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return -0.0278733343971;
                                    } else {
                                        return -0.00192503177132;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[64] <= -996.5) {
                            return 0.22871793722;
                        } else {
                            if (fs[53] <= -1103.0) {
                                return 0.256053069895;
                            } else {
                                return -0.0862794000495;
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9999.5) {
                        if (fs[70] <= -1.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[72] <= 9547.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00162550003364;
                                    } else {
                                        return 0.00113351862495;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0463177300724;
                                    } else {
                                        return -0.0073916174406;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[88] <= 7.5) {
                                        return -0.000509285805585;
                                    } else {
                                        return 0.00843971095498;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.0036323854743;
                                    } else {
                                        return 0.280737645469;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9967.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[53] <= -4043.0) {
                                        return 0.0679439066159;
                                    } else {
                                        return -0.00334139559867;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.078232379562;
                                    } else {
                                        return -0.017719721549;
                                    }
                                }
                            } else {
                                if (fs[66] <= 5.0) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0506851138062;
                                    } else {
                                        return -0.0867798246183;
                                    }
                                } else {
                                    return -0.115442836251;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1968.0) {
                            if (fs[47] <= -37.5) {
                                return 0.467975808382;
                            } else {
                                if (fs[76] <= 25.0) {
                                    return -0.0838147081701;
                                } else {
                                    return 0.214045120069;
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[53] <= -1108.0) {
                                        return 0.0374521779105;
                                    } else {
                                        return -0.00363895485011;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.05780378311;
                                    } else {
                                        return -0.00380812240848;
                                    }
                                }
                            } else {
                                return 0.326201667804;
                            }
                        }
                    }
                }
            } else {
                if (fs[72] <= 9989.5) {
                    if (fs[4] <= 10.5) {
                        return 0.147020648973;
                    } else {
                        if (fs[88] <= 1.0) {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 12.5) {
                                    return -0.0672679525718;
                                } else {
                                    if (fs[53] <= -1738.0) {
                                        return 0.047941533273;
                                    } else {
                                        return -0.0367906470653;
                                    }
                                }
                            } else {
                                return 0.0218735855456;
                            }
                        } else {
                            return 0.102987818933;
                        }
                    }
                } else {
                    if (fs[72] <= 9999.5) {
                        return 0.255390091757;
                    } else {
                        return 0.0842588915538;
                    }
                }
            }
        }
    }
}
