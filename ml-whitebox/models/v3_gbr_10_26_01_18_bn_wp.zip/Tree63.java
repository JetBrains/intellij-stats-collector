/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree63 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 9.5) {
                    if (fs[74] <= 0.5) {
                        if (fs[88] <= -0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    return 0.188667026223;
                                } else {
                                    return 0.0773942967436;
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0222934858358;
                                    } else {
                                        return -0.24703597404;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0792384271481;
                                    } else {
                                        return 0.0787765559379;
                                    }
                                }
                            }
                        } else {
                            if (fs[102] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.0346895112747;
                                    } else {
                                        return -0.0566618998112;
                                    }
                                } else {
                                    if (fs[72] <= 9823.5) {
                                        return 0.260091757603;
                                    } else {
                                        return 0.159881026729;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1098.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.092635756715;
                                    } else {
                                        return 0.159926989993;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0654945291753;
                                    } else {
                                        return 0.0748860387826;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9902.0) {
                            if (fs[2] <= 3.5) {
                                if (fs[72] <= 4641.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0475314732013;
                                    } else {
                                        return -0.200857277268;
                                    }
                                } else {
                                    return -0.095224967647;
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    return -0.117529303221;
                                } else {
                                    return 0.11985452675;
                                }
                            }
                        } else {
                            if (fs[72] <= 9990.5) {
                                if (fs[4] <= 3.5) {
                                    return 0.216687566249;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.176794308676;
                                    } else {
                                        return 0.0904734478176;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    return 0.0161922534532;
                                } else {
                                    if (fs[72] <= 9992.5) {
                                        return 0.00414758006595;
                                    } else {
                                        return 0.146321362889;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 4.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[53] <= -1998.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0918880575306;
                                    } else {
                                        return 0.208081289683;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.011855392124;
                                    } else {
                                        return -0.0420687982463;
                                    }
                                }
                            } else {
                                if (fs[2] <= 7.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0257210777381;
                                    } else {
                                        return 0.0943672593657;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.102679412352;
                                    } else {
                                        return -0.0782190057609;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 250.0) {
                                if (fs[93] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.129965995095;
                                    } else {
                                        return 0.0646468777106;
                                    }
                                } else {
                                    if (fs[72] <= 9977.0) {
                                        return -0.0608059507054;
                                    } else {
                                        return -0.341553970226;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1453.0) {
                                    if (fs[12] <= 0.5) {
                                        return -0.285815530134;
                                    } else {
                                        return 0.0902478979937;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0963694256391;
                                    } else {
                                        return 0.0211912685491;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[22] <= 0.5) {
                            if (fs[48] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.00524060704923;
                                    } else {
                                        return 0.276121522278;
                                    }
                                } else {
                                    if (fs[76] <= 50.0) {
                                        return 0.276020827324;
                                    } else {
                                        return 0.155198343975;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[72] <= 9914.5) {
                                        return -0.129658638765;
                                    } else {
                                        return 0.0620344725778;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0464696608002;
                                    } else {
                                        return 0.0833410871163;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.123345801954;
                                    } else {
                                        return -0.228912191638;
                                    }
                                } else {
                                    if (fs[72] <= 9502.0) {
                                        return -0.0995837411885;
                                    } else {
                                        return 0.410024605223;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.133859414511;
                                    } else {
                                        return -0.0596315679014;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return -0.155213491373;
                                    } else {
                                        return 0.0213040683566;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 11.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[47] <= -390.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.0187116893285;
                                    } else {
                                        return 0.180155551045;
                                    }
                                } else {
                                    if (fs[47] <= -1258.5) {
                                        return -0.0240976541422;
                                    } else {
                                        return 0.0215508163612;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.00501006053726;
                                    } else {
                                        return 0.0443361592087;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.00231809704238;
                                    } else {
                                        return 0.00414382799597;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -2396.0) {
                                if (fs[85] <= 0.5) {
                                    if (fs[0] <= 25.5) {
                                        return -0.015877238838;
                                    } else {
                                        return -0.00638057069924;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0516184765516;
                                    } else {
                                        return -0.0339359831416;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[70] <= -3.5) {
                                        return -0.0481579279777;
                                    } else {
                                        return -0.0209499811679;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.00685283187865;
                                    } else {
                                        return -0.00415032590122;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 8866.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[85] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.0915338187809;
                                    } else {
                                        return 0.00559173735779;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.0164850482797;
                                    } else {
                                        return -0.00464683582593;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1428.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.032672568232;
                                    } else {
                                        return 0.0919909634469;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.0153120246848;
                                    } else {
                                        return -0.0270388513487;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1283.0) {
                                if (fs[76] <= 75.0) {
                                    if (fs[2] <= 5.5) {
                                        return 0.0194053387901;
                                    } else {
                                        return 0.118045391427;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.174307982424;
                                    } else {
                                        return 0.0580114608707;
                                    }
                                }
                            } else {
                                if (fs[53] <= -6.0) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0423972290064;
                                    } else {
                                        return 0.07277815807;
                                    }
                                } else {
                                    if (fs[72] <= 9995.5) {
                                        return 0.0130376882521;
                                    } else {
                                        return 0.0941334373843;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 5.5) {
                        if (fs[53] <= -4488.0) {
                            return 0.207361828767;
                        } else {
                            if (fs[47] <= -6645.0) {
                                return 0.302635252794;
                            } else {
                                if (fs[53] <= -57.0) {
                                    if (fs[103] <= 0.5) {
                                        return -0.0025265615615;
                                    } else {
                                        return -0.00665478634653;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.000416201392095;
                                    } else {
                                        return 0.084707000469;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -684.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[47] <= -1383.0) {
                                    return -0.113240272405;
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.072110066393;
                                    } else {
                                        return -0.0269188653465;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return -0.0987678509465;
                                } else {
                                    if (fs[53] <= -1453.0) {
                                        return -0.0552744100765;
                                    } else {
                                        return -0.0198725122228;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 16.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[72] <= 9989.5) {
                                        return -0.0245877567324;
                                    } else {
                                        return -0.114489315296;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0139053117275;
                                    } else {
                                        return -0.00594440764604;
                                    }
                                }
                            } else {
                                if (fs[47] <= -180.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.484159161549;
                                    } else {
                                        return -0.0110553534905;
                                    }
                                } else {
                                    if (fs[53] <= -1438.0) {
                                        return -0.00703632586022;
                                    } else {
                                        return -0.00263501034135;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[18] <= 0.5) {
                if (fs[53] <= -1108.5) {
                    if (fs[88] <= -0.5) {
                        return -0.294311504846;
                    } else {
                        if (fs[4] <= 30.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[18] <= -0.5) {
                                    if (fs[4] <= 15.5) {
                                        return -0.208605120115;
                                    } else {
                                        return -0.108572372227;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.0466184269623;
                                    } else {
                                        return 0.124703717582;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.306854023082;
                                    } else {
                                        return -0.034520626472;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.219154380591;
                                    } else {
                                        return 0.166647141014;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9998.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.250785800274;
                                    } else {
                                        return -0.0118879933626;
                                    }
                                } else {
                                    return -0.111707081045;
                                }
                            } else {
                                if (fs[53] <= -1858.5) {
                                    if (fs[4] <= 37.0) {
                                        return 0.189796669672;
                                    } else {
                                        return -0.0879419763139;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.281784954534;
                                    } else {
                                        return -0.0864381185096;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[22] <= 0.5) {
                        if (fs[88] <= 3.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.18230589291;
                                    } else {
                                        return 0.107772828688;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.016321510573;
                                    } else {
                                        return 0.201815298555;
                                    }
                                }
                            } else {
                                if (fs[7] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.00445896488454;
                                    } else {
                                        return 0.0578602658922;
                                    }
                                } else {
                                    return -0.21467926004;
                                }
                            }
                        } else {
                            if (fs[72] <= 9997.5) {
                                if (fs[47] <= -2.5) {
                                    return 0.219306768818;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.279445450648;
                                    } else {
                                        return -0.0497541113221;
                                    }
                                }
                            } else {
                                if (fs[88] <= 7.5) {
                                    if (fs[32] <= 0.5) {
                                        return 0.0695298826426;
                                    } else {
                                        return 0.480533668477;
                                    }
                                } else {
                                    if (fs[4] <= 7.0) {
                                        return 0.111180512558;
                                    } else {
                                        return 0.376534166411;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.177150672875;
                                    } else {
                                        return -0.0500556790226;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0410977276457;
                                    } else {
                                        return 0.06233136896;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[47] <= -42.5) {
                                        return 0.000696451270771;
                                    } else {
                                        return 0.132796737605;
                                    }
                                } else {
                                    return 0.369172459837;
                                }
                            }
                        } else {
                            if (fs[2] <= 6.5) {
                                if (fs[47] <= -86.0) {
                                    if (fs[0] <= 11.5) {
                                        return -0.0679182747847;
                                    } else {
                                        return -0.0215321656179;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.00889165974451;
                                    } else {
                                        return 0.00625948430854;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    return 0.228680185274;
                                } else {
                                    return -0.059570465756;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[13] <= 0.5) {
                    if (fs[4] <= 5.5) {
                        if (fs[51] <= 0.5) {
                            if (fs[103] <= 1.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[88] <= 3.5) {
                                        return 0.275411000599;
                                    } else {
                                        return 0.0861680772428;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.017767342369;
                                    } else {
                                        return 0.055398365021;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    return -0.1257148849;
                                } else {
                                    return -0.214887584923;
                                }
                            }
                        } else {
                            return 0.266106589699;
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[47] <= -2.5) {
                                        return 0.034630890346;
                                    } else {
                                        return -0.0173479014691;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.0993296781934;
                                    } else {
                                        return 0.0276473808026;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[47] <= -2.5) {
                                        return -0.212088743875;
                                    } else {
                                        return 0.14378602906;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.112699445712;
                                    } else {
                                        return -0.0224657183456;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 41.0) {
                                if (fs[2] <= 5.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.141445289632;
                                    } else {
                                        return -0.0256089585454;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0104407646145;
                                    } else {
                                        return 0.143657550598;
                                    }
                                }
                            } else {
                                return 0.458908100359;
                            }
                        }
                    }
                } else {
                    if (fs[101] <= 1.0) {
                        return 0.0177829259352;
                    } else {
                        if (fs[72] <= 9999.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 11.5) {
                                    return -0.209272190498;
                                } else {
                                    return -0.189277177672;
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return -0.113779723218;
                                } else {
                                    return -0.0814819683749;
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                return -0.509414934838;
                            } else {
                                if (fs[4] <= 13.5) {
                                    return -0.323618113511;
                                } else {
                                    return -0.29684918136;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
