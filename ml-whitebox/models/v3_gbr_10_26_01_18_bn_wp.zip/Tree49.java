/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree49 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[53] <= -987.5) {
                if (fs[22] <= 0.5) {
                    if (fs[53] <= -1138.0) {
                        if (fs[53] <= -1588.5) {
                            if (fs[4] <= 18.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.187686530507;
                                    } else {
                                        return 0.0152281726739;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.119491685952;
                                    } else {
                                        return 0.170047067946;
                                    }
                                }
                            } else {
                                if (fs[53] <= -2413.5) {
                                    if (fs[53] <= -9088.5) {
                                        return 0.253625150059;
                                    } else {
                                        return 0.12365852756;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.192733392372;
                                    } else {
                                        return 0.0173872300934;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return 0.0840824721028;
                                    } else {
                                        return 0.0225904929554;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0087593253557;
                                    } else {
                                        return -0.0936599056831;
                                    }
                                }
                            } else {
                                if (fs[74] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0785595457309;
                                    } else {
                                        return 0.0247703101474;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0350529651258;
                                    } else {
                                        return 0.114498716361;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[103] <= 1.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0861179938893;
                                    } else {
                                        return 0.093023730103;
                                    }
                                } else {
                                    return -0.0251438619014;
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.121951357087;
                                    } else {
                                        return -0.101446440024;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.140078992565;
                                    } else {
                                        return 0.149020584446;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[76] <= 150.0) {
                                    if (fs[53] <= -1128.5) {
                                        return 0.182414760916;
                                    } else {
                                        return 0.231921724067;
                                    }
                                } else {
                                    if (fs[53] <= -1128.5) {
                                        return 0.0652560044137;
                                    } else {
                                        return 0.103926070788;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return -0.241965353728;
                                } else {
                                    return -0.194493207382;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[4] <= 26.5) {
                                if (fs[72] <= 9996.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.185794397269;
                                    } else {
                                        return 0.110288927618;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.100391252266;
                                    } else {
                                        return 0.264351943586;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    return 0.289118514303;
                                } else {
                                    if (fs[4] <= 37.5) {
                                        return -0.157682060572;
                                    } else {
                                        return 0.141012778493;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[4] <= 6.5) {
                                    if (fs[53] <= -1478.5) {
                                        return -0.091015486667;
                                    } else {
                                        return -0.330653814127;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return -0.033777699124;
                                    } else {
                                        return 0.158933559057;
                                    }
                                }
                            } else {
                                if (fs[4] <= 42.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.108202575376;
                                    } else {
                                        return -0.127239049114;
                                    }
                                } else {
                                    return -0.508661954299;
                                }
                            }
                        }
                    } else {
                        if (fs[90] <= 0.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[2] <= 5.5) {
                                    if (fs[88] <= 5.5) {
                                        return -0.0135703282478;
                                    } else {
                                        return -0.111730221261;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.0870981684089;
                                    } else {
                                        return -0.329751841212;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[53] <= -1478.5) {
                                        return 0.101528916999;
                                    } else {
                                        return 0.194140497232;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.0786094852117;
                                    } else {
                                        return -0.0616938566956;
                                    }
                                }
                            }
                        } else {
                            if (fs[83] <= 0.5) {
                                if (fs[72] <= 9904.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.117225570903;
                                    } else {
                                        return 0.17699526997;
                                    }
                                } else {
                                    if (fs[72] <= 9964.5) {
                                        return -0.145462896965;
                                    } else {
                                        return 0.0655697763603;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0463912775688;
                                    } else {
                                        return 0.176177999095;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0774426725332;
                                    } else {
                                        return -0.273302751609;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 1.5) {
                    if (fs[72] <= 9999.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[106] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0410817258892;
                                    } else {
                                        return -0.154111428075;
                                    }
                                } else {
                                    if (fs[72] <= 9996.5) {
                                        return 0.0904786853925;
                                    } else {
                                        return 0.0400870094968;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[62] <= -1.5) {
                                        return 0.210912406013;
                                    } else {
                                        return -0.0148256439313;
                                    }
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return 0.197980092116;
                                    } else {
                                        return 0.0704596539088;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -6.5) {
                                if (fs[88] <= 5.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.370814754542;
                                    } else {
                                        return 0.0939207664632;
                                    }
                                } else {
                                    if (fs[47] <= -8.5) {
                                        return -0.0595042160728;
                                    } else {
                                        return 0.131606444459;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.044143569979;
                                    } else {
                                        return -0.228285571199;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.175507484225;
                                    } else {
                                        return -0.0969889771479;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0897011193182;
                                    } else {
                                        return -0.00872600416982;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.190788301938;
                                    } else {
                                        return -0.273302101465;
                                    }
                                }
                            } else {
                                if (fs[47] <= -6.0) {
                                    return 0.366151530936;
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.243680172442;
                                    } else {
                                        return 0.0965179731915;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[27] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0672561879275;
                                    } else {
                                        return 0.0939064270784;
                                    }
                                } else {
                                    return -0.122299534568;
                                }
                            } else {
                                if (fs[47] <= -6.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.20485025282;
                                    } else {
                                        return -0.0737927608114;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return -0.131465900957;
                                    } else {
                                        return 0.0224067954475;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[68] <= 1.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[53] <= -467.0) {
                                if (fs[71] <= 0.5) {
                                    return -0.275455113417;
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.173193717474;
                                    } else {
                                        return -0.060563991856;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.080152600906;
                                    } else {
                                        return 0.116265187971;
                                    }
                                } else {
                                    if (fs[88] <= 1.5) {
                                        return -0.106421752363;
                                    } else {
                                        return 0.0818526254844;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.111456927577;
                                    } else {
                                        return -0.172470371204;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.105921613217;
                                    } else {
                                        return 0.219349722521;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.110906397433;
                                    } else {
                                        return -0.0235778602664;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.00707615602438;
                                    } else {
                                        return 0.0994604773381;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    return -0.4092981694;
                                } else {
                                    return -0.283202738683;
                                }
                            } else {
                                return -0.357234671728;
                            }
                        } else {
                            return 0.0817182967529;
                        }
                    }
                }
            }
        } else {
            if (fs[101] <= 0.5) {
                if (fs[47] <= -320.5) {
                    if (fs[85] <= 0.5) {
                        if (fs[49] <= -0.5) {
                            return 0.229187389427;
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[47] <= -406.5) {
                                    if (fs[76] <= 50.0) {
                                        return -0.0205103246526;
                                    } else {
                                        return -0.025626613002;
                                    }
                                } else {
                                    if (fs[0] <= 10.5) {
                                        return 0.0371325919561;
                                    } else {
                                        return -0.013766981026;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[47] <= -406.0) {
                                        return -0.000667491589423;
                                    } else {
                                        return 0.278315277577;
                                    }
                                } else {
                                    return -0.0760929973674;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -1092.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.00574678362259;
                                    } else {
                                        return 0.159218447065;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.0859318108162;
                                    } else {
                                        return -0.0252336513931;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.141133825909;
                                    } else {
                                        return -0.029409683426;
                                    }
                                } else {
                                    if (fs[72] <= 9982.0) {
                                        return -0.000373065777687;
                                    } else {
                                        return 0.229581759427;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1468.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.2371102702;
                                    } else {
                                        return 0.0743785175912;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.140902327965;
                                    } else {
                                        return 0.258893487531;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[72] <= 9993.0) {
                                        return -0.0215132077379;
                                    } else {
                                        return 0.175621212304;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.316970810163;
                                    } else {
                                        return 0.035191671634;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[30] <= 0.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0389793120647;
                                    } else {
                                        return -0.0285490711598;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return 0.186534910788;
                                    } else {
                                        return 0.0118416600788;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.235142866693;
                                    } else {
                                        return 0.0351238773526;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0361168270233;
                                    } else {
                                        return -0.0344041455266;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9900.5) {
                                if (fs[47] <= -2.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.000121380652965;
                                    } else {
                                        return 0.0193157207486;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.00529027029042;
                                    } else {
                                        return -0.00297320491479;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[0] <= 8.5) {
                                        return 0.00947393629857;
                                    } else {
                                        return -0.00709932753698;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0134641142536;
                                    } else {
                                        return 0.110169617382;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -1138.0) {
                                return 0.183659647703;
                            } else {
                                return 0.285499448251;
                            }
                        } else {
                            return 0.22440514444;
                        }
                    }
                }
            } else {
                if (fs[4] <= 13.5) {
                    if (fs[53] <= -1488.0) {
                        if (fs[23] <= 0.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.00624278180365;
                                    } else {
                                        return 0.0133173265628;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0508922981311;
                                    } else {
                                        return 0.00351446792856;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[72] <= 9979.0) {
                                        return 0.146705578987;
                                    } else {
                                        return 0.495432535992;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.00431956925411;
                                    } else {
                                        return 0.0848645693108;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[76] <= 100.0) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0685489031953;
                                    } else {
                                        return 0.358976239459;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.241752284484;
                                    } else {
                                        return 0.0335553008797;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.0957337002848;
                                    } else {
                                        return 0.17949468793;
                                    }
                                } else {
                                    if (fs[51] <= 0.5) {
                                        return 0.0137275331691;
                                    } else {
                                        return 0.245486824818;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 6.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.0999141828388;
                                    } else {
                                        return 0.0135438567153;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.146815260417;
                                    } else {
                                        return 0.512452121864;
                                    }
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.0130256186381;
                                    } else {
                                        return 0.130299994088;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.00737784368154;
                                    } else {
                                        return 0.00571472024062;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[47] <= -1430.0) {
                                    if (fs[59] <= 0.5) {
                                        return -0.0467994180035;
                                    } else {
                                        return -0.0169583760713;
                                    }
                                } else {
                                    if (fs[0] <= 10.5) {
                                        return -0.00414591013232;
                                    } else {
                                        return -0.00949121235671;
                                    }
                                }
                            } else {
                                if (fs[0] <= 101.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.00633050910529;
                                    } else {
                                        return -0.000345965493408;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.00156154127118;
                                    } else {
                                        return 0.233403549897;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 3.5) {
                        if (fs[76] <= 150.0) {
                            if (fs[64] <= -996.5) {
                                if (fs[49] <= -1.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.40328055664;
                                    } else {
                                        return 0.220343440951;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.165879729437;
                                    } else {
                                        return -0.0514125839223;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[47] <= -2.5) {
                                        return -0.00185114041323;
                                    } else {
                                        return 0.0210923112847;
                                    }
                                } else {
                                    if (fs[72] <= 9956.5) {
                                        return 0.0984947423623;
                                    } else {
                                        return 0.460402431666;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -1.5) {
                                if (fs[53] <= -1093.0) {
                                    if (fs[26] <= 0.5) {
                                        return 0.0416208174536;
                                    } else {
                                        return 0.157712473493;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0422764359608;
                                    } else {
                                        return -0.00584192248957;
                                    }
                                }
                            } else {
                                if (fs[92] <= 0.5) {
                                    if (fs[72] <= 9977.0) {
                                        return 0.188007013882;
                                    } else {
                                        return -0.0923054154206;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0195980259342;
                                    } else {
                                        return -0.00460947763978;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[92] <= 0.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[47] <= -28.5) {
                                    if (fs[47] <= -31.5) {
                                        return -0.0165060199367;
                                    } else {
                                        return 0.279310715497;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.00848795363563;
                                    } else {
                                        return 0.0929078971707;
                                    }
                                }
                            } else {
                                if (fs[0] <= 10.5) {
                                    if (fs[4] <= 21.5) {
                                        return 0.16300014636;
                                    } else {
                                        return 0.0166795539077;
                                    }
                                } else {
                                    if (fs[0] <= 59.0) {
                                        return -0.00511608850881;
                                    } else {
                                        return 0.136992145516;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -3919.0) {
                                return 0.135474730253;
                            } else {
                                if (fs[62] <= -2.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.208146773398;
                                    } else {
                                        return -0.0129249082381;
                                    }
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return 0.0145773777158;
                                    } else {
                                        return -0.0063382596117;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
