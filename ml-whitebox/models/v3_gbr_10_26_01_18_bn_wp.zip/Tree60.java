/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree60 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[4] <= 5.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0353376607443;
                                    } else {
                                        return -0.00152998789426;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0494893297647;
                                    } else {
                                        return 0.0913218001193;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.0784324859471;
                                    } else {
                                        return 0.0596205715346;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.0397592306766;
                                    } else {
                                        return 0.0509185785524;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[53] <= -1053.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0587124271551;
                                    } else {
                                        return 0.0485060593741;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return -0.222672981067;
                                    } else {
                                        return 0.127514306322;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.103865465327;
                                    } else {
                                        return 0.0848256089239;
                                    }
                                } else {
                                    if (fs[53] <= -496.5) {
                                        return 0.0473096720389;
                                    } else {
                                        return 0.0355576520831;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.136373322936;
                                    } else {
                                        return -0.0397407305638;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0709467743044;
                                    } else {
                                        return 0.428462440405;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0163326397487;
                                    } else {
                                        return 0.11621705665;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0570612347442;
                                    } else {
                                        return -0.0377574636576;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0413486279379;
                                    } else {
                                        return -0.023027455579;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0762235312129;
                                    } else {
                                        return 0.210796423833;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    return 0.146323485808;
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0270494229701;
                                    } else {
                                        return -0.0013368518378;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[60] <= 0.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    return 0.0579645137;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0127043830344;
                                    } else {
                                        return 0.0453495784003;
                                    }
                                }
                            } else {
                                if (fs[53] <= -988.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.464153722082;
                                    } else {
                                        return 0.0896750385812;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.147862573578;
                                    } else {
                                        return -0.0803948433378;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0878598641513;
                                    } else {
                                        return 0.0094728716647;
                                    }
                                } else {
                                    return 0.0712342172075;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return -0.0876783267088;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.061602964166;
                                    } else {
                                        return 0.0461062779709;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1138.0) {
                            if (fs[0] <= 0.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0701464292302;
                                    } else {
                                        return -0.181767780923;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0679018158949;
                                    } else {
                                        return 0.0316289797895;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[30] <= 0.5) {
                                        return -0.0393338291355;
                                    } else {
                                        return -0.0524306830719;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.200912786572;
                                    } else {
                                        return -0.00670331309769;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.123769232553;
                                    } else {
                                        return 0.0413596009531;
                                    }
                                } else {
                                    if (fs[53] <= -988.0) {
                                        return 0.180287988518;
                                    } else {
                                        return -0.00464677021041;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1128.0) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0487074461405;
                                    } else {
                                        return -0.129795528957;
                                    }
                                } else {
                                    return -0.0944941593603;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[72] <= 9993.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[4] <= 19.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.055551728711;
                                    } else {
                                        return 0.0664998929491;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.145431939637;
                                    } else {
                                        return 0.077524210992;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.162588659068;
                                    } else {
                                        return 0.117956809802;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.0826289335594;
                                    } else {
                                        return 0.131025049752;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[4] <= 39.5) {
                                        return -0.0550431727582;
                                    } else {
                                        return 0.0767567942422;
                                    }
                                } else {
                                    return -0.119270144012;
                                }
                            } else {
                                return -0.250709610259;
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[4] <= 20.5) {
                                if (fs[70] <= -1.5) {
                                    return -0.0235185788433;
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.0618157020276;
                                    } else {
                                        return -0.0137561002505;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[53] <= -1188.0) {
                                        return -0.050751146767;
                                    } else {
                                        return 0.0632660177731;
                                    }
                                } else {
                                    return -0.00713343761795;
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0379012098544;
                                    } else {
                                        return -0.0450956547756;
                                    }
                                } else {
                                    if (fs[0] <= 10.5) {
                                        return -0.0314748124424;
                                    } else {
                                        return -0.0219115657298;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[101] <= 1.5) {
                                        return -0.0216460225954;
                                    } else {
                                        return -0.0120020749991;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.00302988726046;
                                    } else {
                                        return 0.0095880167614;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 9.5) {
                        if (fs[72] <= 9997.5) {
                            return 0.0629500135501;
                        } else {
                            return 0.115478359278;
                        }
                    } else {
                        return 0.0553943526833;
                    }
                }
            }
        } else {
            if (fs[72] <= 9980.5) {
                if (fs[0] <= 0.5) {
                    if (fs[103] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[101] <= 1.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0612895868399;
                                    } else {
                                        return -0.00340488330147;
                                    }
                                } else {
                                    if (fs[72] <= 9373.0) {
                                        return 0.0948619009251;
                                    } else {
                                        return -0.0705388137068;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0934507554927;
                                    } else {
                                        return -0.0382172153039;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0746272542799;
                                    } else {
                                        return 0.165473510448;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.0764177617563;
                                    } else {
                                        return 0.200601348655;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0666427821332;
                                    } else {
                                        return 0.0970951789266;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.0256103978936;
                                    } else {
                                        return -0.0320435157124;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.0567464006323;
                                    } else {
                                        return -0.126300254954;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[76] <= 250.0) {
                                if (fs[4] <= 3.5) {
                                    return 0.0536925511416;
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.155496686154;
                                    } else {
                                        return 0.267434457677;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[58] <= 0.5) {
                                        return 0.0553453616645;
                                    } else {
                                        return -0.0489940804325;
                                    }
                                } else {
                                    if (fs[53] <= -1142.5) {
                                        return 0.0161507046413;
                                    } else {
                                        return 0.0620703951435;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                return -0.252721110144;
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0753563247119;
                                    } else {
                                        return -0.0596111814372;
                                    }
                                } else {
                                    if (fs[27] <= 0.5) {
                                        return -0.0606070648513;
                                    } else {
                                        return -0.178438912989;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 3.5) {
                        if (fs[47] <= -259.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[47] <= -1095.5) {
                                        return 0.0352648688116;
                                    } else {
                                        return 0.129969803042;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.123052298125;
                                    } else {
                                        return 0.00780258837805;
                                    }
                                }
                            } else {
                                if (fs[47] <= -374.5) {
                                    if (fs[4] <= 20.5) {
                                        return -0.0478428513311;
                                    } else {
                                        return 0.119708621012;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.0125843663039;
                                    } else {
                                        return 0.307407351352;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.00200575588587;
                                    } else {
                                        return 0.0971286075527;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0167186525386;
                                    } else {
                                        return -0.0121262958534;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[24] <= 0.5) {
                                        return -0.00854724636761;
                                    } else {
                                        return 0.235919515647;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.000463901478742;
                                    } else {
                                        return 0.0435129172544;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 21.5) {
                            if (fs[62] <= -2.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0373314161199;
                                    } else {
                                        return -0.00629225325377;
                                    }
                                } else {
                                    return 0.242190398153;
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.00262846724761;
                                    } else {
                                        return 0.000793497294649;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.00595761931562;
                                    } else {
                                        return -0.00376446671012;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -104.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0122218111982;
                                    } else {
                                        return 0.193304856577;
                                    }
                                } else {
                                    if (fs[47] <= -580.5) {
                                        return 0.0649654042252;
                                    } else {
                                        return -0.014300644292;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.00744338575901;
                                    } else {
                                        return -0.00347692261614;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.00493496526951;
                                    } else {
                                        return -0.0031612421582;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[24] <= 0.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[6] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.113963292824;
                                    } else {
                                        return 0.172929561034;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.354643759079;
                                    } else {
                                        return -0.00362079155178;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[47] <= -7.5) {
                                        return 0.0646211949883;
                                    } else {
                                        return 0.0178564458619;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.262276267296;
                                    } else {
                                        return -0.340036870624;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[50] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.124518627788;
                                    } else {
                                        return -0.0318244271703;
                                    }
                                } else {
                                    if (fs[53] <= -1113.5) {
                                        return 0.0733909156194;
                                    } else {
                                        return 0.00606784446733;
                                    }
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[47] <= -21.5) {
                                        return 0.159556715888;
                                    } else {
                                        return -0.0465624726703;
                                    }
                                } else {
                                    if (fs[4] <= 9.0) {
                                        return 0.084015199456;
                                    } else {
                                        return 0.230391270958;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -721.5) {
                                    return 0.157345486722;
                                } else {
                                    if (fs[47] <= -17.0) {
                                        return -0.0238189263509;
                                    } else {
                                        return -0.17811662121;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.046021604935;
                                    } else {
                                        return 0.113760186624;
                                    }
                                } else {
                                    return -0.234391140572;
                                }
                            }
                        } else {
                            if (fs[72] <= 9983.5) {
                                if (fs[4] <= 6.5) {
                                    return 0.0489581323684;
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.259893700651;
                                    } else {
                                        return 0.431143317457;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[72] <= 9995.0) {
                                        return -0.170348949833;
                                    } else {
                                        return 0.0637761494529;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.0932424704533;
                                    } else {
                                        return 0.359613609498;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 150.0) {
                        if (fs[94] <= 0.5) {
                            if (fs[53] <= -1128.0) {
                                if (fs[66] <= 5.0) {
                                    if (fs[18] <= -0.5) {
                                        return -0.170409705314;
                                    } else {
                                        return 0.0300083026721;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.251322138384;
                                    } else {
                                        return -0.162381224637;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1.0) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0379758280882;
                                    } else {
                                        return -0.00961668358423;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0183967991247;
                                    } else {
                                        return 0.00289020468912;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -23.0) {
                                return 0.323710353005;
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[47] <= -2.5) {
                                        return -0.120892672568;
                                    } else {
                                        return 0.125834758965;
                                    }
                                } else {
                                    return 0.325656074369;
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.354476275492;
                                    } else {
                                        return 0.0256556877724;
                                    }
                                } else {
                                    if (fs[53] <= -17.5) {
                                        return -0.0170741021364;
                                    } else {
                                        return -0.00923228402877;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9995.5) {
                                    if (fs[47] <= -18.5) {
                                        return 0.332776595568;
                                    } else {
                                        return -0.0779872403938;
                                    }
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return -0.0986742705986;
                                    } else {
                                        return 0.0486280725948;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[53] <= -2443.0) {
                                    return 0.289348561952;
                                } else {
                                    if (fs[101] <= 1.0) {
                                        return 0.122741590356;
                                    } else {
                                        return -0.0117171698651;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    return 0.298250436633;
                                } else {
                                    return 0.146736601699;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
