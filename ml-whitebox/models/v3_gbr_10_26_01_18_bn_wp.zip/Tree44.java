/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree44 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9981.5) {
            if (fs[4] <= 7.5) {
                if (fs[0] <= 0.5) {
                    if (fs[74] <= 0.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[102] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[72] <= 9447.5) {
                                        return 0.0725420641545;
                                    } else {
                                        return -0.0291083058225;
                                    }
                                } else {
                                    if (fs[88] <= -0.5) {
                                        return -0.114053998373;
                                    } else {
                                        return 0.104601746032;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.104682516329;
                                    } else {
                                        return 0.175751237897;
                                    }
                                } else {
                                    return -0.195467134336;
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.127998158291;
                                    } else {
                                        return -0.00165169121255;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.319712167887;
                                    } else {
                                        return 0.136961062571;
                                    }
                                }
                            } else {
                                if (fs[51] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.130984840394;
                                    } else {
                                        return -0.0122579159187;
                                    }
                                } else {
                                    return 0.248484312455;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[53] <= -1123.5) {
                                if (fs[72] <= 9902.0) {
                                    if (fs[4] <= 2.5) {
                                        return -0.0595451836955;
                                    } else {
                                        return -0.206028585771;
                                    }
                                } else {
                                    return 0.216552511291;
                                }
                            } else {
                                return 0.241407183605;
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                return 0.102472733319;
                            } else {
                                return 0.255219492131;
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 6.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0294569709627;
                                    } else {
                                        return -0.00860327738023;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.00800834214397;
                                    } else {
                                        return -0.0479268049416;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.216706033588;
                                    } else {
                                        return 0.0169156062843;
                                    }
                                } else {
                                    if (fs[53] <= -1053.0) {
                                        return 0.138522487261;
                                    } else {
                                        return -0.0712745218008;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[64] <= -997.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.176792687935;
                                    } else {
                                        return 0.0253467520302;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.0072019060782;
                                    } else {
                                        return 0.00412597275046;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.00822346546897;
                                    } else {
                                        return -0.0105524700095;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0605482855254;
                                    } else {
                                        return 0.0447436177021;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1438.0) {
                            if (fs[2] <= 1.5) {
                                if (fs[47] <= -365.0) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00256344760125;
                                    } else {
                                        return 0.2166215862;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.00838533024115;
                                    } else {
                                        return 0.139964546602;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.114991012875;
                                    } else {
                                        return -0.0519057605749;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.164213027941;
                                    } else {
                                        return -0.0472641288224;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0261482949208;
                                    } else {
                                        return -0.0761505641051;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.105594349942;
                                    } else {
                                        return 0.0333694530893;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[72] <= 9598.5) {
                                        return -0.00570632797489;
                                    } else {
                                        return -0.0309143546484;
                                    }
                                } else {
                                    return 0.40306626813;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[101] <= 0.5) {
                        if (fs[2] <= 5.5) {
                            if (fs[89] <= 0.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0855301436815;
                                    } else {
                                        return 0.150804332153;
                                    }
                                } else {
                                    if (fs[53] <= -1548.5) {
                                        return 0.0955991728611;
                                    } else {
                                        return -0.0365897110715;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[55] <= -1.5) {
                                        return 0.0431901110669;
                                    } else {
                                        return 0.147968235327;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.171460633952;
                                    } else {
                                        return 0.23623843261;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 10.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[72] <= 9893.0) {
                                        return 0.0666679419517;
                                    } else {
                                        return 0.181305626357;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.174580106432;
                                    } else {
                                        return -0.163750566822;
                                    }
                                }
                            } else {
                                if (fs[88] <= 1.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.234110755155;
                                    } else {
                                        return 0.115819993176;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.35057316102;
                                    } else {
                                        return 0.381723811899;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1583.5) {
                            if (fs[4] <= 48.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[83] <= 0.5) {
                                        return 0.232064790324;
                                    } else {
                                        return -0.0184303198339;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.12966575895;
                                    } else {
                                        return 0.174303322244;
                                    }
                                }
                            } else {
                                return -0.218563721094;
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                if (fs[49] <= -3.5) {
                                    if (fs[4] <= 22.0) {
                                        return -0.385782308512;
                                    } else {
                                        return 0.149963711644;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.118105740877;
                                    } else {
                                        return 0.219852401955;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 20.5) {
                                        return 0.0592004211244;
                                    } else {
                                        return -0.0197639547901;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0609906806546;
                                    } else {
                                        return 0.118285092752;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 3.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[53] <= -4913.0) {
                                        return 0.416173397893;
                                    } else {
                                        return 0.01912930509;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0158176772421;
                                    } else {
                                        return 0.328500145082;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[72] <= 9759.0) {
                                        return -0.0141181098717;
                                    } else {
                                        return -0.0562751134305;
                                    }
                                } else {
                                    return 0.136108958138;
                                }
                            }
                        } else {
                            if (fs[62] <= -1.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0935451283185;
                                    } else {
                                        return 0.00858926225557;
                                    }
                                } else {
                                    if (fs[53] <= -1088.0) {
                                        return 0.520527549031;
                                    } else {
                                        return -0.0459155492063;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0103909346185;
                                    } else {
                                        return 0.00692075545198;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0132365609697;
                                    } else {
                                        return 0.0261555599067;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[0] <= 8.5) {
                                    if (fs[53] <= 3.5) {
                                        return -0.00241385636774;
                                    } else {
                                        return -0.00887349081459;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.251131378033;
                                    } else {
                                        return -0.00626024168536;
                                    }
                                }
                            } else {
                                if (fs[64] <= -996.5) {
                                    if (fs[4] <= 19.5) {
                                        return 0.055219516781;
                                    } else {
                                        return -0.00641165018585;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.00697811171614;
                                    } else {
                                        return -0.00795795165144;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[53] <= -1268.0) {
                                    return -0.0492887375558;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.298338507575;
                                    } else {
                                        return 0.109290553174;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return -0.0305490589502;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0103757828892;
                                    } else {
                                        return -0.0251035209481;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[53] <= -1052.5) {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 35.5) {
                        if (fs[93] <= 0.5) {
                            if (fs[24] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.13686678234;
                                    } else {
                                        return 0.0834674655665;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.00978651934935;
                                    } else {
                                        return -0.222802407459;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.198234307343;
                                    } else {
                                        return 0.292862656616;
                                    }
                                } else {
                                    if (fs[72] <= 9995.0) {
                                        return -0.0684162767896;
                                    } else {
                                        return 0.11646839633;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 15.5) {
                                if (fs[47] <= -35.0) {
                                    return -0.21993950928;
                                } else {
                                    return -0.403322905915;
                                }
                            } else {
                                return -0.177767624196;
                            }
                        }
                    } else {
                        if (fs[53] <= -1793.0) {
                            if (fs[76] <= 25.0) {
                                return 0.12690860705;
                            } else {
                                return 0.0593381207276;
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    return -0.263219423503;
                                } else {
                                    return -0.553146732628;
                                }
                            } else {
                                return 0.0681115128213;
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9999.5) {
                        if (fs[76] <= 150.0) {
                            if (fs[2] <= 6.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.00840101632605;
                                    } else {
                                        return 0.0392123168167;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0717116289345;
                                    } else {
                                        return 0.348648924827;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[72] <= 9984.5) {
                                        return 0.377370003104;
                                    } else {
                                        return 0.0861141069213;
                                    }
                                } else {
                                    return 0.563859389209;
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[84] <= 0.5) {
                                    return 0.397629150821;
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0630918258255;
                                    } else {
                                        return 0.153470500945;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0507549419618;
                                    } else {
                                        return -0.0119749538835;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.268902471869;
                                    } else {
                                        return 0.0088890846711;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1968.0) {
                            if (fs[59] <= 0.5) {
                                if (fs[76] <= 150.0) {
                                    return 0.156068510211;
                                } else {
                                    return 0.368293153162;
                                }
                            } else {
                                return 0.435568530139;
                            }
                        } else {
                            if (fs[66] <= 5.0) {
                                if (fs[0] <= 16.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.121688358567;
                                    } else {
                                        return 0.0317170788946;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0388464819543;
                                    } else {
                                        return 0.231819580938;
                                    }
                                }
                            } else {
                                return -0.203189744715;
                            }
                        }
                    }
                }
            } else {
                if (fs[45] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[103] <= 0.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.126940286074;
                                    } else {
                                        return 0.0888281397647;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.0808485712647;
                                    } else {
                                        return 0.22008350332;
                                    }
                                }
                            } else {
                                return -0.114474168663;
                            }
                        } else {
                            if (fs[88] <= 5.5) {
                                if (fs[62] <= -0.5) {
                                    if (fs[64] <= -498.0) {
                                        return 0.180145663784;
                                    } else {
                                        return 0.044836844625;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0152603227776;
                                    } else {
                                        return 0.0766435162761;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.189323890699;
                                    } else {
                                        return 0.0116107693051;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.104660623304;
                                    } else {
                                        return 0.191951171516;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -967.0) {
                            if (fs[72] <= 9991.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.127527265031;
                                    } else {
                                        return -0.157264148114;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0566516536494;
                                    } else {
                                        return -0.0330909000814;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[47] <= -155.5) {
                                        return 0.193307956475;
                                    } else {
                                        return -0.0387866054418;
                                    }
                                } else {
                                    return -0.116670497564;
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0942648121515;
                                    } else {
                                        return 0.0541866147282;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return 0.006617752855;
                                    } else {
                                        return 0.0893317893146;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9989.5) {
                                    if (fs[47] <= -5.5) {
                                        return 0.0944310218759;
                                    } else {
                                        return 0.0137201916414;
                                    }
                                } else {
                                    if (fs[64] <= -498.5) {
                                        return 0.171076175732;
                                    } else {
                                        return -0.00870691727953;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            return 0.349853311804;
                        } else {
                            return 0.158444604437;
                        }
                    } else {
                        if (fs[47] <= -2246.0) {
                            return 0.0993183149831;
                        } else {
                            if (fs[106] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.0873459468518;
                                    } else {
                                        return -0.0206575984468;
                                    }
                                } else {
                                    if (fs[2] <= 7.5) {
                                        return -0.0103818655944;
                                    } else {
                                        return 0.0942698608934;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.0689954413523;
                                    } else {
                                        return -0.0795560208287;
                                    }
                                } else {
                                    return -0.0451777230888;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
