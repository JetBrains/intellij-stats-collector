/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree34 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 19.5) {
                    if (fs[4] <= 9.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[53] <= -1053.5) {
                                        return 0.14792899053;
                                    } else {
                                        return -0.373430984033;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.20484549847;
                                    } else {
                                        return 0.223148720743;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 5.5) {
                                        return -0.031042097616;
                                    } else {
                                        return 0.0815227419157;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.203117517828;
                                    } else {
                                        return 0.151534155485;
                                    }
                                }
                            }
                        } else {
                            if (fs[33] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.180598356751;
                                    } else {
                                        return 0.0577332160239;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.16953777367;
                                    } else {
                                        return 0.155086072836;
                                    }
                                }
                            } else {
                                return -0.0408227972062;
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[60] <= 0.5) {
                                return 0.281269321124;
                            } else {
                                return 0.246109331595;
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 11.0) {
                                        return 0.218810601812;
                                    } else {
                                        return 0.19253870643;
                                    }
                                } else {
                                    return 0.252420280546;
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.196127713964;
                                    } else {
                                        return 0.215166891378;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return 0.17977974633;
                                    } else {
                                        return 0.195375616314;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[78] <= 0.5) {
                        return 0.0627683557297;
                    } else {
                        if (fs[4] <= 39.5) {
                            return -0.149074381622;
                        } else {
                            if (fs[53] <= -1523.0) {
                                return -0.0434297475146;
                            } else {
                                return 0.123689540015;
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 2.5) {
                    if (fs[78] <= 0.5) {
                        return 0.0613632699123;
                    } else {
                        if (fs[41] <= 0.5) {
                            return 0.299749857564;
                        } else {
                            return -0.0700551098177;
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0139932527512;
                                    } else {
                                        return 0.153642359852;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.051291551763;
                                    } else {
                                        return -0.0214376555155;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0531307996423;
                                    } else {
                                        return -0.0319651217243;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0353244787358;
                                    } else {
                                        return -0.0192506744849;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.0) {
                                return 0.239934956773;
                            } else {
                                return 0.273631662079;
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[53] <= -1053.0) {
                                        return 0.0702342806111;
                                    } else {
                                        return 0.00155681229824;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0824948435113;
                                    } else {
                                        return -0.0433325141656;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[53] <= -1133.0) {
                                        return -0.0377194660464;
                                    } else {
                                        return -0.0267918787326;
                                    }
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return -0.014681923325;
                                    } else {
                                        return -0.0134214695457;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0257919985169;
                                    } else {
                                        return 0.0577503202842;
                                    }
                                } else {
                                    return 0.0346674393008;
                                }
                            } else {
                                if (fs[0] <= 20.5) {
                                    if (fs[53] <= -1108.0) {
                                        return -0.00688256272619;
                                    } else {
                                        return -0.0200313399615;
                                    }
                                } else {
                                    if (fs[53] <= -987.0) {
                                        return -0.0118024873314;
                                    } else {
                                        return -0.0431250048884;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[72] <= 9996.5) {
                if (fs[103] <= 1.5) {
                    if (fs[72] <= 9825.5) {
                        if (fs[76] <= 25.0) {
                            if (fs[0] <= 0.5) {
                                if (fs[95] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.0716649098066;
                                    } else {
                                        return -0.0588343338653;
                                    }
                                } else {
                                    if (fs[55] <= -0.5) {
                                        return 0.219221954451;
                                    } else {
                                        return 0.111208292689;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[88] <= 6.0) {
                                        return -0.0112478954894;
                                    } else {
                                        return 0.00109362140684;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.00617890167486;
                                    } else {
                                        return -0.0129687479162;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.188238215281;
                                    } else {
                                        return 0.141073535248;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return 0.108892881364;
                                    } else {
                                        return -0.101682442408;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.00673992182832;
                                    } else {
                                        return 0.108576834486;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.00102517621288;
                                    } else {
                                        return -0.0106162966098;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.167616215744;
                                    } else {
                                        return 0.21623385909;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.213844226233;
                                    } else {
                                        return 0.0330879165057;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[53] <= -476.5) {
                                        return 0.108092251331;
                                    } else {
                                        return -0.140405569361;
                                    }
                                } else {
                                    if (fs[88] <= 3.0) {
                                        return 0.0375674136786;
                                    } else {
                                        return -0.21666249251;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[70] <= -4.5) {
                                        return 0.101227617611;
                                    } else {
                                        return -0.0035302446967;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.0302108239228;
                                    } else {
                                        return 0.147230597599;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1403.0) {
                                    if (fs[47] <= -384.5) {
                                        return 0.101021931145;
                                    } else {
                                        return 0.0125855734488;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0094709122331;
                                    } else {
                                        return 0.137616662257;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1043.0) {
                        if (fs[27] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.144330514618;
                                    } else {
                                        return -0.0746028870896;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0953564049369;
                                    } else {
                                        return -0.0715571711278;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0287417158126;
                                    } else {
                                        return 0.0939961089731;
                                    }
                                } else {
                                    if (fs[2] <= 7.5) {
                                        return -0.0393347685987;
                                    } else {
                                        return 0.304310536699;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -0.5) {
                                if (fs[12] <= 0.5) {
                                    return 0.0590363543571;
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return 0.186056578035;
                                    } else {
                                        return 0.0792595438307;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.167850096478;
                                    } else {
                                        return 0.0879753734262;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.0125858071776;
                                    } else {
                                        return -0.344851404757;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[62] <= -1.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 0.5) {
                                    return 0.310554026964;
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.022807727189;
                                    } else {
                                        return 0.000761127188579;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[53] <= -941.0) {
                                        return 0.0683712928448;
                                    } else {
                                        return 0.127379888454;
                                    }
                                } else {
                                    return -0.00275498632024;
                                }
                            }
                        } else {
                            if (fs[53] <= -993.5) {
                                return -0.104722994797;
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0404723866062;
                                    } else {
                                        return 0.0438298704338;
                                    }
                                } else {
                                    if (fs[53] <= 7.5) {
                                        return -0.0128448741124;
                                    } else {
                                        return -0.0103441578735;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[71] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[88] <= 1.5) {
                            if (fs[53] <= -1513.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.267745013175;
                                    } else {
                                        return 0.328112418261;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.0848643404448;
                                    } else {
                                        return 0.267994089157;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.122294928969;
                                    } else {
                                        return 0.167566183192;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.293202607254;
                                    } else {
                                        return -0.1291500411;
                                    }
                                }
                            }
                        } else {
                            if (fs[92] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.195764260137;
                                    } else {
                                        return 0.231189472601;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.30098157657;
                                    } else {
                                        return 0.458386884646;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.120224211114;
                                    } else {
                                        return 0.369317319202;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.193745310061;
                                    } else {
                                        return -0.161557931299;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[2] <= 10.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[53] <= -1468.0) {
                                        return -0.0988795650523;
                                    } else {
                                        return 0.0317371563673;
                                    }
                                } else {
                                    if (fs[47] <= -1156.0) {
                                        return 0.34305442258;
                                    } else {
                                        return 0.0652696099854;
                                    }
                                }
                            } else {
                                return 0.446445755691;
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[47] <= -2.5) {
                                        return -0.112770923335;
                                    } else {
                                        return -0.0771069708688;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return -0.0363716996493;
                                    } else {
                                        return -0.0463820935198;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0238990782689;
                                    } else {
                                        return 0.259433965287;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0603842595967;
                                    } else {
                                        return -0.0185137512014;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -1047.5) {
                            if (fs[72] <= 9998.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.000303389048324;
                                    } else {
                                        return 0.0663344150918;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.035484090153;
                                    } else {
                                        return 0.359411374514;
                                    }
                                }
                            } else {
                                if (fs[47] <= -7.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.126932693476;
                                    } else {
                                        return 0.195629851938;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return 0.0678668086783;
                                    } else {
                                        return 0.330895092831;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0434169129519;
                                    } else {
                                        return 0.00481045618983;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0335728648853;
                                    } else {
                                        return -0.0192187788741;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 14.5) {
                                        return 0.115439510584;
                                    } else {
                                        return -0.012067377106;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.0830863293699;
                                    } else {
                                        return -0.00201213892479;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[106] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.150590121588;
                                    } else {
                                        return 0.0281748475373;
                                    }
                                } else {
                                    if (fs[13] <= 0.5) {
                                        return 0.239258223263;
                                    } else {
                                        return 0.193919914309;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[53] <= -1268.0) {
                                        return 0.181760993792;
                                    } else {
                                        return -0.00871115907106;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.172238357623;
                                    } else {
                                        return 0.164022555199;
                                    }
                                }
                            }
                        } else {
                            if (fs[74] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0442160486974;
                                    } else {
                                        return 0.00749208469638;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return 0.155655538402;
                                    } else {
                                        return 0.0564878885142;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0648253640313;
                                    } else {
                                        return 0.417381739566;
                                    }
                                } else {
                                    return 0.139287952574;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
