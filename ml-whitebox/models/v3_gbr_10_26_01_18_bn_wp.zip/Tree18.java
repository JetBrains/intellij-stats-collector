/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree18 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 11.5) {
                    if (fs[41] <= 0.5) {
                        if (fs[74] <= 0.5) {
                            if (fs[53] <= -1043.0) {
                                if (fs[53] <= -1408.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.146427684368;
                                    } else {
                                        return 0.319630753643;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.343776008734;
                                    } else {
                                        return 0.444074463579;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.327143138269;
                                    } else {
                                        return 0.237734657154;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.133305984363;
                                    } else {
                                        return 0.299870077578;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[72] <= 9914.0) {
                                        return -0.0213004193881;
                                    } else {
                                        return 0.31305633828;
                                    }
                                } else {
                                    if (fs[72] <= 4907.0) {
                                        return -0.128242059484;
                                    } else {
                                        return 0.39908611671;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.187040991714;
                                    } else {
                                        return 0.365369196492;
                                    }
                                } else {
                                    return 0.48894958198;
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[47] <= -820.0) {
                                        return 0.47466185693;
                                    } else {
                                        return 0.0241870450073;
                                    }
                                } else {
                                    if (fs[47] <= -360.0) {
                                        return 0.474612908731;
                                    } else {
                                        return 0.267835866464;
                                    }
                                }
                            } else {
                                if (fs[70] <= -4.5) {
                                    return 0.280251636442;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.427361152189;
                                    } else {
                                        return 0.377540776122;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[76] <= 150.0) {
                                        return -0.0386037338903;
                                    } else {
                                        return 0.27346470568;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.254882910157;
                                    } else {
                                        return 0.15043047319;
                                    }
                                }
                            } else {
                                if (fs[65] <= 0.5) {
                                    if (fs[51] <= 0.5) {
                                        return 0.0954087889593;
                                    } else {
                                        return 0.457723836061;
                                    }
                                } else {
                                    return -0.316016960329;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[90] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 23.5) {
                                        return 0.492010683129;
                                    } else {
                                        return 0.580958369924;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.223682876021;
                                    } else {
                                        return 0.397219061755;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.147567619081;
                                    } else {
                                        return 0.0446887571349;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.313826635461;
                                    } else {
                                        return 0.179631466589;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 4.5) {
                                if (fs[72] <= 9834.0) {
                                    if (fs[4] <= 18.5) {
                                        return 0.128285721366;
                                    } else {
                                        return -0.00117843643718;
                                    }
                                } else {
                                    if (fs[53] <= -1528.0) {
                                        return 0.402692341255;
                                    } else {
                                        return 0.186265383243;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[53] <= -1398.0) {
                                        return 0.330160179366;
                                    } else {
                                        return 0.0487392270592;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.181984529402;
                                    } else {
                                        return -0.0524793400029;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[62] <= -0.5) {
                            if (fs[49] <= -3.5) {
                                return 0.0415346147674;
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[47] <= -10.5) {
                                        return -0.156292629318;
                                    } else {
                                        return 0.360276748224;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.291748089179;
                                    } else {
                                        return 0.522054699661;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[53] <= -21.0) {
                                        return 0.310701779617;
                                    } else {
                                        return 0.13134010063;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.274200137514;
                                    } else {
                                        return 0.375315542208;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1923.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.394404698601;
                                    } else {
                                        return 0.507072637865;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return 0.18659005283;
                                    } else {
                                        return 0.299692744798;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[90] <= 0.5) {
                    if (fs[81] <= 0.5) {
                        if (fs[76] <= 100.0) {
                            if (fs[52] <= 0.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0865163048771;
                                    } else {
                                        return -0.043406603086;
                                    }
                                } else {
                                    if (fs[0] <= 25.5) {
                                        return 0.103544879569;
                                    } else {
                                        return -0.044784764063;
                                    }
                                }
                            } else {
                                if (fs[30] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.400565887515;
                                    } else {
                                        return 0.0456324014773;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.471970197851;
                                    } else {
                                        return 0.527151052369;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 4847.0) {
                                if (fs[78] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0192984774131;
                                    } else {
                                        return -0.0383785406221;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.0501282521842;
                                    } else {
                                        return -0.0316343995652;
                                    }
                                }
                            } else {
                                return 0.105583650618;
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -1488.5) {
                                        return 0.0757496852584;
                                    } else {
                                        return 0.0312967506282;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0102477044902;
                                    } else {
                                        return 0.0327065257492;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.287817577569;
                                    } else {
                                        return 0.00685219022384;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0306352413215;
                                    } else {
                                        return 0.282476108315;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -3731.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[53] <= -1293.0) {
                                        return 0.085555229983;
                                    } else {
                                        return -0.028959461856;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.318195082126;
                                    } else {
                                        return -0.0691879371711;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9866.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.0143550341441;
                                    } else {
                                        return -0.0226359341901;
                                    }
                                } else {
                                    if (fs[53] <= -1403.0) {
                                        return 0.0334455978152;
                                    } else {
                                        return -0.0118362340199;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1082.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[83] <= 0.5) {
                                        return 0.0842946675578;
                                    } else {
                                        return 0.00344441512065;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.447892338817;
                                    } else {
                                        return 0.173243759792;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00809416046722;
                                    } else {
                                        return 0.0525460231158;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0964983426896;
                                    } else {
                                        return 0.0311704801684;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.485680460424;
                                    } else {
                                        return 0.0848168058526;
                                    }
                                } else {
                                    if (fs[0] <= 150.5) {
                                        return 0.00485057741349;
                                    } else {
                                        return 0.292061166006;
                                    }
                                }
                            } else {
                                if (fs[47] <= -0.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.00858363381291;
                                    } else {
                                        return -0.0272966645847;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.330783516533;
                                    } else {
                                        return 0.115189010567;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[103] <= 0.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[53] <= -472.0) {
                                        return -0.0662820781273;
                                    } else {
                                        return 0.0448696661566;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return 0.000172062104185;
                                    } else {
                                        return -0.0187619450203;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3.5) {
                                    if (fs[64] <= -996.5) {
                                        return 0.0133370640506;
                                    } else {
                                        return -0.0295056395552;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.0245315435581;
                                    } else {
                                        return -0.0282001749123;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[6] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.00936969789961;
                                    } else {
                                        return 0.348208130276;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0182662791161;
                                    } else {
                                        return -0.023614276128;
                                    }
                                }
                            } else {
                                if (fs[49] <= -1.5) {
                                    if (fs[53] <= -931.5) {
                                        return -0.035620742151;
                                    } else {
                                        return 0.0305811119955;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.00065736788838;
                                    } else {
                                        return -0.0258717924989;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[23] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[88] <= 1.5) {
                            if (fs[53] <= -436.0) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.216467076902;
                                    } else {
                                        return -0.189431134373;
                                    }
                                } else {
                                    if (fs[18] <= -0.5) {
                                        return -0.243112649314;
                                    } else {
                                        return 0.296625957489;
                                    }
                                }
                            } else {
                                if (fs[47] <= -938.0) {
                                    return 0.340478282715;
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.076237575726;
                                    } else {
                                        return 0.259944407847;
                                    }
                                }
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[47] <= -8.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.381325508584;
                                    } else {
                                        return 0.536252647475;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.216612913093;
                                    } else {
                                        return 0.38499331208;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    return 0.241949580033;
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.547480242979;
                                    } else {
                                        return 0.356281703879;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.372391371761;
                                    } else {
                                        return 0.406987104544;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.324580588801;
                                    } else {
                                        return -0.0189981832605;
                                    }
                                }
                            } else {
                                return -0.119991887022;
                            }
                        } else {
                            if (fs[47] <= -15.0) {
                                return 0.489232920862;
                            } else {
                                if (fs[2] <= 3.5) {
                                    return -0.187614617951;
                                } else {
                                    return 0.131100852317;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[47] <= -7.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[76] <= 100.0) {
                                    if (fs[53] <= -1123.5) {
                                        return 0.322922039737;
                                    } else {
                                        return 0.177828249352;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.536361094152;
                                    } else {
                                        return 0.327648779923;
                                    }
                                }
                            } else {
                                if (fs[88] <= 7.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.449720300554;
                                    } else {
                                        return 0.344855706604;
                                    }
                                } else {
                                    return 0.233009883138;
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[88] <= 3.0) {
                                        return 0.29988127585;
                                    } else {
                                        return 0.61795045371;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.215921966008;
                                    } else {
                                        return 0.406728520733;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1608.0) {
                                    if (fs[101] <= 1.5) {
                                        return 0.486957384214;
                                    } else {
                                        return 0.32181242232;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.212295085715;
                                    } else {
                                        return 0.0931505859744;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 0.5) {
                            if (fs[88] <= 5.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[47] <= -4.5) {
                                        return 0.452588154886;
                                    } else {
                                        return 0.376196192239;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return 0.239636588674;
                                    } else {
                                        return 0.40726654959;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.435024509542;
                                    } else {
                                        return 0.3229162814;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.46246966829;
                                    } else {
                                        return 0.401412242415;
                                    }
                                }
                            }
                        } else {
                            if (fs[64] <= -498.0) {
                                if (fs[103] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.310207117499;
                                    } else {
                                        return 0.431633634768;
                                    }
                                } else {
                                    return 0.330188311903;
                                }
                            } else {
                                if (fs[47] <= -0.5) {
                                    if (fs[53] <= -1288.0) {
                                        return 0.330538646639;
                                    } else {
                                        return 0.159360220305;
                                    }
                                } else {
                                    return 0.610774776477;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[45] <= 0.5) {
                    if (fs[85] <= 0.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.0666430589046;
                                    } else {
                                        return -0.0388094713571;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0929701824743;
                                    } else {
                                        return 0.196919506588;
                                    }
                                }
                            } else {
                                if (fs[4] <= 22.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.0128087325408;
                                    } else {
                                        return -0.151094079203;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.117735017687;
                                    } else {
                                        return 0.08309271312;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0423412702635;
                                    } else {
                                        return 0.10607501305;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.00843236463033;
                                    } else {
                                        return 0.0680958449896;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0670673534506;
                                    } else {
                                        return 0.00888334858217;
                                    }
                                } else {
                                    return 0.182760737319;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1068.0) {
                            if (fs[72] <= 9999.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.132216820121;
                                    } else {
                                        return 0.269896420666;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0481388689512;
                                    } else {
                                        return 0.30407283266;
                                    }
                                }
                            } else {
                                if (fs[0] <= 21.5) {
                                    if (fs[66] <= 5.0) {
                                        return 0.306843864392;
                                    } else {
                                        return -0.211492704006;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.179743648091;
                                    } else {
                                        return -0.0644231681221;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.352914409942;
                                    } else {
                                        return 0.0392386247518;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return -0.0520931898374;
                                    } else {
                                        return 0.0717408085874;
                                    }
                                }
                            } else {
                                return 0.566223673722;
                            }
                        }
                    }
                } else {
                    if (fs[68] <= 1.5) {
                        if (fs[2] <= 7.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[65] <= 0.5) {
                                    if (fs[88] <= 7.5) {
                                        return -0.026512050937;
                                    } else {
                                        return 0.020344701613;
                                    }
                                } else {
                                    return 0.0765896053526;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return -0.0774455475588;
                                } else {
                                    return -0.0446934589481;
                                }
                            }
                        } else {
                            return 0.0534224449286;
                        }
                    } else {
                        if (fs[0] <= 13.5) {
                            return 0.229060399566;
                        } else {
                            if (fs[0] <= 45.5) {
                                if (fs[0] <= 25.5) {
                                    return -0.0375794049443;
                                } else {
                                    return -0.0322931980027;
                                }
                            } else {
                                return -0.0254783780345;
                            }
                        }
                    }
                }
            }
        }
    }
}
