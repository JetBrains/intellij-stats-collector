/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree19 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[59] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.303002011886;
                                    } else {
                                        return 0.356161645265;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.16236562642;
                                    } else {
                                        return 0.246051046403;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0367651515022;
                                    } else {
                                        return -0.0489523931772;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0680322798636;
                                    } else {
                                        return 0.0168313184788;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[53] <= -1038.5) {
                                    if (fs[53] <= -1128.5) {
                                        return 0.339188687423;
                                    } else {
                                        return 0.38090677246;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.350403346233;
                                    } else {
                                        return 0.311230948639;
                                    }
                                }
                            } else {
                                if (fs[53] <= -988.0) {
                                    if (fs[33] <= 0.5) {
                                        return 0.166264376276;
                                    } else {
                                        return -0.0579534725589;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.028823640587;
                                    } else {
                                        return 0.131131040847;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[23] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return 0.405413501424;
                                    } else {
                                        return 0.429334080783;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.35823931109;
                                    } else {
                                        return 0.449669405556;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0702369258943;
                                    } else {
                                        return -0.0352967600051;
                                    }
                                } else {
                                    return -0.121642836829;
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.348454576418;
                                    } else {
                                        return 0.388194159274;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.330391027363;
                                    } else {
                                        return 0.0753433127981;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.20888790992;
                                    } else {
                                        return -0.0278099607167;
                                    }
                                } else {
                                    return 0.0129451410603;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[53] <= -1138.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.203665991382;
                                    } else {
                                        return 0.0370355548513;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.293742764012;
                                    } else {
                                        return 0.358545581321;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    return 0.357132092234;
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.376171262637;
                                    } else {
                                        return 0.371105753209;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0953352783382;
                                    } else {
                                        return -0.0318264104637;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0133706811737;
                                    } else {
                                        return -0.0867516953429;
                                    }
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.705609288704;
                                    } else {
                                        return 0.246939839328;
                                    }
                                } else {
                                    return 0.0533711205565;
                                }
                            }
                        }
                    } else {
                        return -0.0888645199333;
                    }
                }
            } else {
                if (fs[101] <= 0.5) {
                    if (fs[84] <= 0.5) {
                        if (fs[4] <= 85.0) {
                            return 0.0291051012667;
                        } else {
                            return -0.0237371635407;
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[72] <= 9997.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.400528770905;
                                    } else {
                                        return 0.364669656923;
                                    }
                                } else {
                                    return 0.406045752619;
                                }
                            } else {
                                if (fs[4] <= 9.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0386344135069;
                                    } else {
                                        return 0.321960085067;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.392716439122;
                                    } else {
                                        return 0.339624905141;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0605034231146;
                                    } else {
                                        return -0.0694514257237;
                                    }
                                } else {
                                    return 0.0450007082594;
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[70] <= -1.5) {
                                        return -0.0387432183638;
                                    } else {
                                        return 0.0345464694415;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0191523819635;
                                    } else {
                                        return 0.0741081001154;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[78] <= 0.5) {
                        if (fs[0] <= 3.5) {
                            return 0.0394809761905;
                        } else {
                            if (fs[4] <= 31.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[53] <= -1088.0) {
                                        return -0.040082550495;
                                    } else {
                                        return -0.0366170405028;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.0446217543791;
                                    } else {
                                        return -0.011348792316;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0383197382238;
                                    } else {
                                        return -0.0325830186009;
                                    }
                                } else {
                                    if (fs[4] <= 48.5) {
                                        return -0.0309637555523;
                                    } else {
                                        return -0.00755280381137;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[6] <= 0.5) {
                                return -0.169390855937;
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 72.5) {
                                        return -0.0949488824289;
                                    } else {
                                        return 0.0289587441267;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.0124234531527;
                                    } else {
                                        return -0.0439701157473;
                                    }
                                }
                            }
                        } else {
                            if (fs[103] <= 1.0) {
                                if (fs[45] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return -0.0381490153084;
                                    } else {
                                        return -0.0274601189404;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return -0.026394807136;
                                    } else {
                                        return -0.0227254023981;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 6.5) {
                                        return -0.0445322863758;
                                    } else {
                                        return -0.0364510356868;
                                    }
                                } else {
                                    return -0.0316984694231;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[103] <= 1.5) {
                if (fs[72] <= 9985.5) {
                    if (fs[47] <= -27.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[64] <= -997.5) {
                                        return 0.327449672624;
                                    } else {
                                        return 0.00678303093749;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0115344138505;
                                    } else {
                                        return 0.108503891713;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0516728419782;
                                    } else {
                                        return 0.169394974608;
                                    }
                                } else {
                                    if (fs[88] <= 4.5) {
                                        return 0.136019261063;
                                    } else {
                                        return 0.395300923958;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[62] <= -1.5) {
                                    if (fs[47] <= -151.0) {
                                        return 0.0810262169705;
                                    } else {
                                        return 0.512442535792;
                                    }
                                } else {
                                    if (fs[72] <= 9820.5) {
                                        return -0.00392349151371;
                                    } else {
                                        return 0.0506642745043;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[72] <= 4229.0) {
                                        return 0.380429531926;
                                    } else {
                                        return 0.21066307002;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.0090488119842;
                                    } else {
                                        return 0.22598503803;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[53] <= -1268.5) {
                                        return 0.18666742843;
                                    } else {
                                        return 0.268971930568;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0184776553732;
                                    } else {
                                        return -0.0182885843722;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[53] <= -1083.5) {
                                        return 0.341303676018;
                                    } else {
                                        return 0.233514686421;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.0461340048889;
                                    } else {
                                        return -0.00934241454548;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[85] <= 0.5) {
                                        return 0.145915739324;
                                    } else {
                                        return -0.00569003412062;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.283457633827;
                                    } else {
                                        return 0.134627888003;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 19.5) {
                                        return 0.000432271626096;
                                    } else {
                                        return -0.021983951789;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.0200741576629;
                                    } else {
                                        return -0.0224667010462;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[53] <= -972.0) {
                                if (fs[78] <= 0.5) {
                                    if (fs[53] <= -1478.5) {
                                        return 0.30428552334;
                                    } else {
                                        return 0.388643337315;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.106576631463;
                                    } else {
                                        return 0.320708302159;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[64] <= -499.0) {
                                        return 0.436847424522;
                                    } else {
                                        return 0.307683605542;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.296613600297;
                                    } else {
                                        return 0.185678290827;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.117048383326;
                                    } else {
                                        return 0.0429404467107;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.30668810608;
                                    } else {
                                        return 0.134579842444;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1443.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.127818429016;
                                    } else {
                                        return 0.474416987973;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.00902286271655;
                                    } else {
                                        return 0.061571992755;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1052.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.252801357728;
                                    } else {
                                        return 0.164184905171;
                                    }
                                } else {
                                    if (fs[47] <= -14.5) {
                                        return 0.370108180151;
                                    } else {
                                        return 0.246988660826;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0744312928988;
                                    } else {
                                        return 0.21350021301;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0363182151902;
                                    } else {
                                        return 0.0649917449295;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.239906556663;
                                    } else {
                                        return 0.480593027666;
                                    }
                                } else {
                                    if (fs[64] <= -498.0) {
                                        return 0.403854924646;
                                    } else {
                                        return 0.1330383694;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.00697229652344;
                                    } else {
                                        return -0.0232268353265;
                                    }
                                } else {
                                    if (fs[53] <= -21.0) {
                                        return 0.00918151629211;
                                    } else {
                                        return 0.0883017279324;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1052.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[64] <= -996.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.411485402239;
                                    } else {
                                        return 0.134492415183;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.314015558135;
                                    } else {
                                        return 0.453335454641;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.377105036118;
                                    } else {
                                        return 0.370253319922;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.3075951584;
                                    } else {
                                        return 0.388951618622;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.283344767156;
                                    } else {
                                        return 0.32283235359;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.332218405604;
                                    } else {
                                        return 0.271527648496;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.209165845492;
                                    } else {
                                        return 0.105558414541;
                                    }
                                } else {
                                    if (fs[0] <= 13.5) {
                                        return 0.0920808819765;
                                    } else {
                                        return 0.507027217881;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[79] <= 0.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[53] <= -1137.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0630650162644;
                                    } else {
                                        return -0.0241124237757;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0266634740448;
                                    } else {
                                        return -0.0710147799886;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.231510982544;
                                    } else {
                                        return -0.109675970237;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.073366483294;
                                    } else {
                                        return -0.0228818678373;
                                    }
                                }
                            }
                        } else {
                            if (fs[58] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    return 0.099445554611;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0871228321964;
                                    } else {
                                        return -0.0506531148724;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0421546204939;
                                    } else {
                                        return -0.00473388517724;
                                    }
                                } else {
                                    return 0.308062356351;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[49] <= -1.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                return 0.249798865044;
                            } else {
                                return 0.13296758327;
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 2.5) {
                                    return 0.0393009078359;
                                } else {
                                    return 0.184476737386;
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[62] <= -2.5) {
                                        return 0.0482806358279;
                                    } else {
                                        return -0.0265476858249;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return -0.0363450566141;
                                    } else {
                                        return -0.0284837278371;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[64] <= -498.5) {
                                return 0.366296699537;
                            } else {
                                if (fs[53] <= 7.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.128122514532;
                                    } else {
                                        return 0.0564344819525;
                                    }
                                } else {
                                    return 0.306209591518;
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[6] <= 0.5) {
                                    return 0.144899506864;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0450518428085;
                                    } else {
                                        return -0.000875820471647;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0172858841005;
                                    } else {
                                        return -0.0225969262136;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0283232077769;
                                    } else {
                                        return -0.0240007182817;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
