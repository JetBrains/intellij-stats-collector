/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree17 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 9.5) {
                if (fs[53] <= -987.5) {
                    if (fs[41] <= 0.5) {
                        if (fs[74] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.352063407646;
                                    } else {
                                        return 0.2293972575;
                                    }
                                } else {
                                    if (fs[53] <= -1123.5) {
                                        return 0.380659702184;
                                    } else {
                                        return 0.416123680129;
                                    }
                                }
                            } else {
                                if (fs[86] <= 0.5) {
                                    if (fs[88] <= -0.5) {
                                        return -0.0216009853318;
                                    } else {
                                        return 0.37656084995;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.474196572682;
                                    } else {
                                        return 0.434029181625;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[72] <= 9914.0) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0256698576813;
                                    } else {
                                        return 0.263349181574;
                                    }
                                } else {
                                    if (fs[53] <= -1138.5) {
                                        return 0.243886052275;
                                    } else {
                                        return 0.447265970862;
                                    }
                                }
                            } else {
                                if (fs[72] <= 4619.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.145385144226;
                                    } else {
                                        return 0.390770558105;
                                    }
                                } else {
                                    if (fs[72] <= 9992.5) {
                                        return 0.396501304312;
                                    } else {
                                        return 0.42723746229;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.403474707958;
                                    } else {
                                        return 0.491634154579;
                                    }
                                } else {
                                    return 0.281964902993;
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[53] <= -1718.5) {
                                        return 0.29194569676;
                                    } else {
                                        return 0.00627091721298;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0210718446368;
                                    } else {
                                        return 0.360918699894;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -106.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.226213669457;
                                    } else {
                                        return -0.0360446720053;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.446786113134;
                                    } else {
                                        return 0.274041719563;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1143.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0937454210261;
                                    } else {
                                        return 0.0548177687625;
                                    }
                                } else {
                                    if (fs[76] <= 350.0) {
                                        return 0.104182476179;
                                    } else {
                                        return 0.507330439174;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[62] <= -0.5) {
                                    if (fs[47] <= -8.5) {
                                        return 0.507272878103;
                                    } else {
                                        return 0.372962248319;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.31503374155;
                                    } else {
                                        return 0.198446465473;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9996.5) {
                                    if (fs[64] <= -499.0) {
                                        return 0.256781280749;
                                    } else {
                                        return 0.0309695260873;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.340549688442;
                                    } else {
                                        return 0.19433874987;
                                    }
                                }
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.092018684025;
                                    } else {
                                        return 0.49930940979;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.255516934436;
                                    } else {
                                        return 0.0850400194321;
                                    }
                                }
                            } else {
                                if (fs[88] <= 1.5) {
                                    if (fs[72] <= 9966.0) {
                                        return -0.0896876603496;
                                    } else {
                                        return -0.173240824809;
                                    }
                                } else {
                                    return 0.0754514119701;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -462.0) {
                            if (fs[45] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    return 0.145736794866;
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.12526656658;
                                    } else {
                                        return -0.0944854501223;
                                    }
                                }
                            } else {
                                return 0.457744420853;
                            }
                        } else {
                            if (fs[88] <= -0.5) {
                                if (fs[23] <= 0.5) {
                                    return 0.544784941179;
                                } else {
                                    if (fs[4] <= 7.0) {
                                        return -0.291575431446;
                                    } else {
                                        return -0.048076138409;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.281437615422;
                                    } else {
                                        return 0.368604773589;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.192880255925;
                                    } else {
                                        return 0.116406931527;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[105] <= 0.5) {
                    if (fs[53] <= -977.0) {
                        if (fs[53] <= -2003.5) {
                            if (fs[4] <= 48.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[64] <= -996.5) {
                                        return 0.225027983908;
                                    } else {
                                        return 0.479279073191;
                                    }
                                } else {
                                    return 0.0146591659015;
                                }
                            } else {
                                return -0.0775175502444;
                            }
                        } else {
                            if (fs[4] <= 18.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.302087253186;
                                    } else {
                                        return 0.209225569944;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.354201111789;
                                    } else {
                                        return 0.10702657554;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[13] <= 0.5) {
                                        return 0.118138848377;
                                    } else {
                                        return 0.39879434416;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return 0.130190551379;
                                    } else {
                                        return 0.26424648282;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[62] <= -0.5) {
                            if (fs[4] <= 28.5) {
                                if (fs[62] <= -1.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.364754011136;
                                    } else {
                                        return 0.454814593108;
                                    }
                                } else {
                                    if (fs[47] <= -3.5) {
                                        return 0.130604507016;
                                    } else {
                                        return 0.33233752584;
                                    }
                                }
                            } else {
                                return -0.0776509354253;
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[2] <= 4.5) {
                                    if (fs[82] <= 0.5) {
                                        return 0.058638404757;
                                    } else {
                                        return 0.299109483905;
                                    }
                                } else {
                                    if (fs[53] <= -887.0) {
                                        return -0.200916580862;
                                    } else {
                                        return 0.265838964881;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return -0.173120260364;
                                    } else {
                                        return 0.334113436975;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.105232667997;
                                    } else {
                                        return 0.276207650031;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 0.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[53] <= -1478.0) {
                                if (fs[4] <= 10.5) {
                                    return -0.12655344365;
                                } else {
                                    if (fs[72] <= 9166.5) {
                                        return -0.185748085865;
                                    } else {
                                        return -0.318898550848;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1468.0) {
                                    return -0.0390003476211;
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return -0.171540761684;
                                    } else {
                                        return -0.0789439392536;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                return -0.199000020378;
                            } else {
                                if (fs[4] <= 11.5) {
                                    return -0.256847769896;
                                } else {
                                    if (fs[88] <= -0.5) {
                                        return -0.229160026575;
                                    } else {
                                        return -0.246054574839;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0210557461075;
                                    } else {
                                        return 0.285563502258;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return 0.466664429705;
                                    } else {
                                        return 0.329765941667;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.269926884405;
                                    } else {
                                        return 0.124382944728;
                                    }
                                } else {
                                    if (fs[53] <= -1458.0) {
                                        return 0.326289864088;
                                    } else {
                                        return 0.47074991424;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                if (fs[4] <= 11.5) {
                                    if (fs[88] <= 3.5) {
                                        return 0.336192962626;
                                    } else {
                                        return 0.0451541764348;
                                    }
                                } else {
                                    if (fs[88] <= 4.5) {
                                        return 0.193927819481;
                                    } else {
                                        return -0.147900650197;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[92] <= 0.5) {
                                        return 0.442006249924;
                                    } else {
                                        return 0.100080909452;
                                    }
                                } else {
                                    if (fs[72] <= 9843.0) {
                                        return 0.227564601588;
                                    } else {
                                        return 0.433115203596;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[72] <= 9653.0) {
                    if (fs[45] <= 0.5) {
                        if (fs[101] <= 0.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.103793019646;
                                    } else {
                                        return -0.0354183543728;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.335052302564;
                                    } else {
                                        return 0.0914328186738;
                                    }
                                }
                            } else {
                                if (fs[47] <= -270.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.133788315521;
                                    } else {
                                        return 0.375968907415;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.00394335458669;
                                    } else {
                                        return 0.0425853109211;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[4] <= 16.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0297474829552;
                                    } else {
                                        return 0.0917331879884;
                                    }
                                } else {
                                    if (fs[53] <= -376.5) {
                                        return -0.0101920564756;
                                    } else {
                                        return 0.0548083787917;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.33683644631;
                                    } else {
                                        return 0.0368037000783;
                                    }
                                } else {
                                    if (fs[53] <= -1468.5) {
                                        return 0.186973618747;
                                    } else {
                                        return 0.0959928037368;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 11.5) {
                            if (fs[68] <= 1.5) {
                                if (fs[72] <= 4346.0) {
                                    if (fs[26] <= 0.5) {
                                        return -0.0367138019496;
                                    } else {
                                        return -0.0245550924897;
                                    }
                                } else {
                                    return 0.173284881457;
                                }
                            } else {
                                return 0.0692896035907;
                            }
                        } else {
                            return 0.183528711465;
                        }
                    }
                } else {
                    if (fs[88] <= 7.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[47] <= -12.5) {
                                    if (fs[47] <= -213.5) {
                                        return 0.00993892411459;
                                    } else {
                                        return 0.102406633399;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0146683813748;
                                    } else {
                                        return 0.0591197608565;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[53] <= -1458.0) {
                                        return 0.245792204233;
                                    } else {
                                        return 0.0797229865221;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.0434304292132;
                                    } else {
                                        return -0.0371836573737;
                                    }
                                }
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[72] <= 9985.5) {
                                    if (fs[47] <= -365.0) {
                                        return 0.271080523622;
                                    } else {
                                        return 0.0319429983662;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.110923265112;
                                    } else {
                                        return -0.0248905889717;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[47] <= -10.0) {
                                        return 0.408703442799;
                                    } else {
                                        return 0.102926333747;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.537066802765;
                                    } else {
                                        return 0.345421176791;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[72] <= 9888.5) {
                                if (fs[41] <= 0.5) {
                                    return 0.0948924601561;
                                } else {
                                    return -0.273421354859;
                                }
                            } else {
                                if (fs[53] <= -1303.0) {
                                    if (fs[47] <= -1.5) {
                                        return 0.266622371034;
                                    } else {
                                        return 0.133687453701;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0562102422902;
                                    } else {
                                        return -0.0738570400279;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.113393241787;
                                    } else {
                                        return 0.435476817147;
                                    }
                                } else {
                                    if (fs[72] <= 9939.5) {
                                        return 0.15246004834;
                                    } else {
                                        return -0.00363664758467;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[72] <= 9992.5) {
                                        return -0.106500551873;
                                    } else {
                                        return 0.435830316745;
                                    }
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return 0.414930515971;
                                    } else {
                                        return 0.325477390837;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 4.5) {
                    if (fs[88] <= 6.5) {
                        if (fs[22] <= 0.5) {
                            if (fs[53] <= 3.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.00784402451225;
                                    } else {
                                        return -0.0154996679482;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0243425224398;
                                    } else {
                                        return -0.0291392177618;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0322540250244;
                                    } else {
                                        return -0.0293535564607;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0304152302295;
                                    } else {
                                        return 0.078961468613;
                                    }
                                }
                            }
                        } else {
                            if (fs[90] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[47] <= -479.5) {
                                        return 0.0914365128924;
                                    } else {
                                        return -0.0144015500079;
                                    }
                                } else {
                                    if (fs[47] <= -19.5) {
                                        return -0.000868433948216;
                                    } else {
                                        return -0.0282358841704;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[72] <= 9976.5) {
                                        return 0.128755803187;
                                    } else {
                                        return 0.602358652634;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.0644145202946;
                                    } else {
                                        return 0.000883333441985;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 75.0) {
                            if (fs[57] <= 0.5) {
                                if (fs[47] <= -2.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.134534480954;
                                    } else {
                                        return 0.0161369048417;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.034445071768;
                                    } else {
                                        return -0.00866329592285;
                                    }
                                }
                            } else {
                                return 0.442155346431;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[47] <= -14.5) {
                                        return 0.367352299262;
                                    } else {
                                        return 0.000627844600419;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0157943026845;
                                    } else {
                                        return -0.0504329934379;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.156618228144;
                                    } else {
                                        return 0.484310723859;
                                    }
                                } else {
                                    if (fs[47] <= -1935.5) {
                                        return 0.224672234605;
                                    } else {
                                        return -0.0177051335982;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 8.5) {
                        if (fs[72] <= 9869.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.00558743587605;
                                    } else {
                                        return -0.0203415619384;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.0100756779445;
                                    } else {
                                        return 0.054771462461;
                                    }
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0250037378673;
                                    } else {
                                        return -0.0262628095285;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.0105890299451;
                                    } else {
                                        return 0.0161485588335;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[72] <= 9997.5) {
                                        return 0.00790285971587;
                                    } else {
                                        return 0.0751958081594;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.102317213955;
                                    } else {
                                        return -0.017452780112;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.204101253473;
                                    } else {
                                        return 0.0495218116532;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.0388774749103;
                                    } else {
                                        return 0.182602409625;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -7508.5) {
                            if (fs[53] <= -1478.0) {
                                if (fs[88] <= 7.5) {
                                    return 0.04017499859;
                                } else {
                                    return 0.57421241671;
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[0] <= 33.5) {
                                        return -0.0758479087036;
                                    } else {
                                        return -0.0466899143795;
                                    }
                                } else {
                                    if (fs[47] <= -20981.5) {
                                        return -0.0452844303897;
                                    } else {
                                        return -0.000928996398205;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[72] <= 9995.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0230418211365;
                                    } else {
                                        return -0.00465085987683;
                                    }
                                } else {
                                    if (fs[0] <= 21.5) {
                                        return 0.231307050621;
                                    } else {
                                        return -0.0271494346968;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[4] <= 17.5) {
                                        return -0.0234573724824;
                                    } else {
                                        return -0.0251829772558;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.00278002899994;
                                    } else {
                                        return 0.106177335427;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
