/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree2 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[76] <= 100.0) {
                if (fs[0] <= 0.5) {
                    if (fs[41] <= 0.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.800712173656;
                                    } else {
                                        return 0.66727332867;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.816793422463;
                                    } else {
                                        return 0.855414206358;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.701362950176;
                                    } else {
                                        return 0.661672595427;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.837744722309;
                                    } else {
                                        return 0.381115910558;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.81588996581;
                                    } else {
                                        return 0.826281103851;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.843662286031;
                                    } else {
                                        return 0.851552686054;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.749841420862;
                                    } else {
                                        return 0.822433061007;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.849470155193;
                                    } else {
                                        return 0.851852030674;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[59] <= 0.5) {
                            if (fs[53] <= -1138.0) {
                                if (fs[11] <= 0.5) {
                                    return 0.37775310863;
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.457758276375;
                                    } else {
                                        return 0.144581828224;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.397517793917;
                                } else {
                                    return 0.146748563148;
                                }
                            }
                        } else {
                            return 0.794282078119;
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0866076057135;
                                    } else {
                                        return 0.338571539968;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0322427202268;
                                    } else {
                                        return 0.0104660732645;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.0) {
                                    return 0.723541099777;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.722772695119;
                                    } else {
                                        return 0.774501022207;
                                    }
                                }
                            }
                        } else {
                            return -0.0640610732988;
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[15] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 14.0) {
                                        return 0.125262814368;
                                    } else {
                                        return -0.053330989143;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return -0.0476345961042;
                                    } else {
                                        return 0.164405083627;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return 0.104028333553;
                                } else {
                                    if (fs[53] <= -1053.0) {
                                        return 0.120991494855;
                                    } else {
                                        return -0.0600314894989;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.033841555219;
                                    } else {
                                        return -0.0538507435607;
                                    }
                                } else {
                                    if (fs[53] <= -1048.0) {
                                        return 0.0294485827837;
                                    } else {
                                        return -0.0412998950208;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.0704987974216;
                                    } else {
                                        return 0.0172452620498;
                                    }
                                } else {
                                    return 0.193654788311;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[23] <= 0.5) {
                    return 0.281047569559;
                } else {
                    if (fs[72] <= 4847.0) {
                        if (fs[0] <= 0.5) {
                            if (fs[4] <= 21.5) {
                                return 0.381032148904;
                            } else {
                                if (fs[78] <= 0.5) {
                                    return 0.207245407487;
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return -0.0782040287933;
                                    } else {
                                        return 0.0605061060579;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[53] <= -1578.0) {
                                    if (fs[4] <= 39.5) {
                                        return -0.0439039976204;
                                    } else {
                                        return 0.248015761355;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0527356609718;
                                    } else {
                                        return -0.0529786644109;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 31.5) {
                                        return 0.0102965112277;
                                    } else {
                                        return -0.0461678857447;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0557896735307;
                                    } else {
                                        return -0.0526753966671;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.115190596867;
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[97] <= 0.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[74] <= 0.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[53] <= -1488.5) {
                                        return 0.730382638356;
                                    } else {
                                        return 0.608333820168;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.467482701101;
                                    } else {
                                        return 0.647323800624;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.800802836877;
                                    } else {
                                        return 0.537440892461;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.851060595768;
                                    } else {
                                        return 0.759750978344;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1143.5) {
                                if (fs[53] <= -1493.5) {
                                    return 0.105767118079;
                                } else {
                                    if (fs[72] <= 9848.5) {
                                        return -0.0369654576758;
                                    } else {
                                        return 0.0481026739619;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[72] <= 4860.0) {
                                        return 0.107829299035;
                                    } else {
                                        return 0.835171051684;
                                    }
                                } else {
                                    if (fs[72] <= 9902.0) {
                                        return 0.443853368944;
                                    } else {
                                        return 0.7969504332;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 10.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1088.5) {
                                        return 0.427617809548;
                                    } else {
                                        return 0.236790639303;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.567623556742;
                                    } else {
                                        return 0.132700958525;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -988.5) {
                                        return 0.464921316349;
                                    } else {
                                        return 0.331866315636;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.706667840669;
                                    } else {
                                        return 0.245927899875;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[72] <= 9819.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.171505545219;
                                    } else {
                                        return 0.38983366996;
                                    }
                                } else {
                                    if (fs[88] <= 4.5) {
                                        return 0.437171185402;
                                    } else {
                                        return 0.284453920192;
                                    }
                                }
                            } else {
                                if (fs[47] <= -84.5) {
                                    if (fs[53] <= -1273.0) {
                                        return 0.805234656267;
                                    } else {
                                        return 0.497733938729;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.548913992743;
                                    } else {
                                        return 0.287975084997;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[4] <= 16.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.734165413477;
                                    } else {
                                        return 0.802243689177;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return 0.552551784271;
                                    } else {
                                        return 0.707117467857;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.608955019139;
                                    } else {
                                        return 0.00936777573915;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return 0.155066721675;
                                    } else {
                                        return 0.700523742542;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.39283406153;
                                    } else {
                                        return 0.762710192706;
                                    }
                                } else {
                                    return 0.0730808061854;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.000435081639326;
                                    } else {
                                        return 0.332432540971;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.258309643329;
                                    } else {
                                        return 0.428161532749;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[62] <= -1.5) {
                            if (fs[48] <= 0.5) {
                                if (fs[76] <= 250.0) {
                                    return 0.868745625255;
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.858579148581;
                                    } else {
                                        return 0.861982674662;
                                    }
                                }
                            } else {
                                if (fs[64] <= -996.5) {
                                    if (fs[53] <= -495.5) {
                                        return 0.861075372746;
                                    } else {
                                        return 0.82913935666;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.678415556097;
                                    } else {
                                        return 0.819223458215;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[53] <= -1298.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.7139634432;
                                    } else {
                                        return 0.803017431045;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.407944594819;
                                    } else {
                                        return 0.698679199642;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    return 0.881826457616;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.546746137611;
                                    } else {
                                        return 0.864175734037;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[72] <= 9653.0) {
                        if (fs[76] <= 25.0) {
                            if (fs[101] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[106] <= 0.5) {
                                        return -0.0265099729629;
                                    } else {
                                        return 0.0343377591607;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0175603033618;
                                    } else {
                                        return 0.0587376754636;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -1478.5) {
                                        return 0.199739951135;
                                    } else {
                                        return 0.11584890589;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0261192890533;
                                    } else {
                                        return 0.129866595978;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 7.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.170151516159;
                                    } else {
                                        return 0.0758246362024;
                                    }
                                } else {
                                    if (fs[47] <= -126.0) {
                                        return 0.143716338898;
                                    } else {
                                        return -0.0477971344594;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.422154554713;
                                    } else {
                                        return 0.568461395723;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0491124210408;
                                    } else {
                                        return 0.133859984822;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 7.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.186791585231;
                                    } else {
                                        return 0.120810706713;
                                    }
                                } else {
                                    if (fs[72] <= 9870.0) {
                                        return 0.0907357328052;
                                    } else {
                                        return -0.0373933287317;
                                    }
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[72] <= 9997.5) {
                                        return 0.243667727635;
                                    } else {
                                        return 0.453485160674;
                                    }
                                } else {
                                    return -0.075950128753;
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[53] <= -491.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.364905355662;
                                    } else {
                                        return 0.619778841979;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.153858192661;
                                    } else {
                                        return 0.258210846124;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.212457782316;
                                    } else {
                                        return 0.0219452594986;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0437327029332;
                                    } else {
                                        return -0.0710609461622;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9977.5) {
                        if (fs[0] <= 4.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0387253654663;
                                    } else {
                                        return -0.017599471619;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.00380792921871;
                                    } else {
                                        return 0.319986510409;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[53] <= 3.5) {
                                        return 0.0170344368568;
                                    } else {
                                        return -0.0534356933221;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0138068610805;
                                    } else {
                                        return -0.0231401325293;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -3848.5) {
                                if (fs[53] <= -1458.0) {
                                    if (fs[88] <= 7.5) {
                                        return 0.0661672132924;
                                    } else {
                                        return 0.574275844249;
                                    }
                                } else {
                                    if (fs[72] <= 9921.5) {
                                        return -0.0513834116692;
                                    } else {
                                        return 0.0259798470768;
                                    }
                                }
                            } else {
                                if (fs[0] <= 9.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0405007853618;
                                    } else {
                                        return -0.0515882939835;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.0489755879413;
                                    } else {
                                        return -0.0515136022581;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 150.0) {
                            if (fs[72] <= 9999.5) {
                                if (fs[53] <= -1403.0) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0755884856666;
                                    } else {
                                        return 0.176460145007;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.0168936213528;
                                    } else {
                                        return -0.0460796293143;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1418.0) {
                                    if (fs[47] <= -85.0) {
                                        return 0.576988651171;
                                    } else {
                                        return 0.381000804285;
                                    }
                                } else {
                                    if (fs[53] <= -1072.5) {
                                        return 0.194037481393;
                                    } else {
                                        return 0.00483616403361;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1093.0) {
                                if (fs[53] <= -1128.0) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.00316578697419;
                                    } else {
                                        return 0.176384954221;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.172527588116;
                                    } else {
                                        return 0.769084478175;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0121947309914;
                                    } else {
                                        return -0.0533637930426;
                                    }
                                } else {
                                    return 0.208270243175;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
