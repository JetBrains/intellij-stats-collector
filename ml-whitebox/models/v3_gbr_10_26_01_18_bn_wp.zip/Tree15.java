/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree15 {
    public double calcTree(double... fs) {
        if (fs[30] <= 0.5) {
            if (fs[72] <= 9993.5) {
                if (fs[0] <= 0.5) {
                    if (fs[53] <= -1228.5) {
                        if (fs[76] <= 25.0) {
                            if (fs[84] <= 0.5) {
                                if (fs[72] <= 9842.0) {
                                    if (fs[99] <= 0.5) {
                                        return 0.020866725687;
                                    } else {
                                        return 0.293732498423;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return 0.246318425083;
                                    } else {
                                        return 0.435461593429;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1548.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.43656337573;
                                    } else {
                                        return -0.11431335539;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.333006957182;
                                    } else {
                                        return 0.164933178477;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 42.0) {
                                    if (fs[4] <= 17.5) {
                                        return 0.425597039477;
                                    } else {
                                        return 0.323337910155;
                                    }
                                } else {
                                    return -0.235060522908;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.293809499518;
                                    } else {
                                        return 0.0890926387546;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.391628840424;
                                    } else {
                                        return 0.196819354814;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1073.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.377528100722;
                                    } else {
                                        return 0.235609769713;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.419388423352;
                                    } else {
                                        return 0.131049325147;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.397168637323;
                                    } else {
                                        return 0.141954010197;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.441285540216;
                                    } else {
                                        return 0.195311594806;
                                    }
                                }
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.200344467899;
                                    } else {
                                        return 0.292090957515;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0668971070712;
                                    } else {
                                        return 0.306475564816;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[72] <= 9992.5) {
                                        return 0.452021083375;
                                    } else {
                                        return 0.0946293357423;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.336320571189;
                                    } else {
                                        return 0.19324423654;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[88] <= 7.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.0455963980976;
                                    } else {
                                        return 0.0867199883697;
                                    }
                                } else {
                                    if (fs[88] <= 1.5) {
                                        return -0.0295145444307;
                                    } else {
                                        return 0.0355934268726;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0207202814502;
                                    } else {
                                        return -0.0127898583355;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0105224323229;
                                    } else {
                                        return 0.0697131973838;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0224103701004;
                                    } else {
                                        return 0.313930503663;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.441914669267;
                                    } else {
                                        return -0.0432869239594;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0174328550329;
                                    } else {
                                        return 0.188483522113;
                                    }
                                } else {
                                    if (fs[72] <= 9972.0) {
                                        return -0.0135546340167;
                                    } else {
                                        return -0.117233765418;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0165024206085;
                                    } else {
                                        return -0.0206991763405;
                                    }
                                } else {
                                    if (fs[72] <= 9926.5) {
                                        return -0.0269045267197;
                                    } else {
                                        return -0.00014901290468;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1418.0) {
                                    if (fs[4] <= 10.5) {
                                        return 0.13479898821;
                                    } else {
                                        return 0.0296602665665;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0163864208138;
                                    } else {
                                        return -0.0317693755728;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return -0.000474034748315;
                                    } else {
                                        return -0.0208547036746;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.0238054117169;
                                    } else {
                                        return -0.0149311907061;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9411.5) {
                                    if (fs[47] <= -204.0) {
                                        return -0.0356465038528;
                                    } else {
                                        return -0.0290683744153;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.0374999203223;
                                    } else {
                                        return -0.02553688114;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[53] <= -1108.5) {
                                    if (fs[53] <= -1478.5) {
                                        return 0.239351657249;
                                    } else {
                                        return 0.382572369391;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.208170845828;
                                    } else {
                                        return -0.123309886638;
                                    }
                                }
                            } else {
                                if (fs[4] <= 21.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.460784086077;
                                    } else {
                                        return 0.370538896222;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.114635305148;
                                    } else {
                                        return 0.385071686741;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -7.5) {
                                if (fs[76] <= 100.0) {
                                    if (fs[4] <= 5.5) {
                                        return 0.378352124504;
                                    } else {
                                        return 0.272833066367;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.513831705901;
                                    } else {
                                        return 0.420577523368;
                                    }
                                }
                            } else {
                                if (fs[53] <= -485.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.335650196457;
                                    } else {
                                        return 0.158813927655;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.230752754191;
                                    } else {
                                        return 0.103619156716;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[63] <= 0.5) {
                                        return 0.428146389772;
                                    } else {
                                        return -0.039859087309;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.456557290189;
                                    } else {
                                        return 0.473782570421;
                                    }
                                }
                            } else {
                                if (fs[88] <= 4.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.433416471763;
                                    } else {
                                        return 0.273261140782;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.386889621883;
                                    } else {
                                        return 0.494176237999;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[47] <= -14.5) {
                                    if (fs[72] <= 9994.5) {
                                        return 0.257240191243;
                                    } else {
                                        return 0.44449345235;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.369613230775;
                                    } else {
                                        return 0.293059182406;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.4178074161;
                                    } else {
                                        return 0.180400447275;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.319892641064;
                                    } else {
                                        return 0.199762658986;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[53] <= -1268.0) {
                            if (fs[47] <= -87.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.260912884833;
                                    } else {
                                        return 0.43495822924;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.0395655134843;
                                    } else {
                                        return 0.25535715098;
                                    }
                                }
                            } else {
                                if (fs[55] <= 546.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0707652348065;
                                    } else {
                                        return 0.160916376792;
                                    }
                                } else {
                                    return 0.665014999429;
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[86] <= 0.5) {
                                        return 0.095040511946;
                                    } else {
                                        return 0.314593814012;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.0473373131047;
                                    } else {
                                        return -0.0554863812415;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0704518801905;
                                    } else {
                                        return 0.0252112721184;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return -0.0109956966612;
                                    } else {
                                        return 0.050471353336;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 7.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0362513247537;
                                    } else {
                                        return -0.0282800849843;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0331020123329;
                                    } else {
                                        return 0.238514075363;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.00376476993847;
                                    } else {
                                        return -0.0381157235605;
                                    }
                                } else {
                                    return 0.122024831152;
                                }
                            }
                        } else {
                            if (fs[0] <= 4.0) {
                                return 0.189469218851;
                            } else {
                                return -0.0499303920216;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[2] <= 2.5) {
                if (fs[4] <= 7.5) {
                    if (fs[4] <= 5.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[53] <= -1113.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.370268506719;
                                    } else {
                                        return 0.449234103828;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.450173297468;
                                    } else {
                                        return 0.439935223263;
                                    }
                                }
                            } else {
                                return 0.13248202957;
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                return 0.406470477038;
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.470997695128;
                                    } else {
                                        return 0.454669956202;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.460046230475;
                                    } else {
                                        return 0.445653138399;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.403316614826;
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        return 0.0305662404386;
                    } else {
                        return 0.181532152342;
                    }
                }
            } else {
                if (fs[4] <= 7.5) {
                    if (fs[15] <= 0.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 4.5) {
                                        return 0.442084528392;
                                    } else {
                                        return 0.441299793907;
                                    }
                                } else {
                                    return 0.438857996055;
                                }
                            } else {
                                return 0.442010971039;
                            }
                        } else {
                            return 0.442081192723;
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            return 0.439166861422;
                        } else {
                            if (fs[53] <= -1138.0) {
                                return 0.440703896603;
                            } else {
                                return 0.43774254185;
                            }
                        }
                    }
                } else {
                    return 0.415244559718;
                }
            }
        }
    }
}
