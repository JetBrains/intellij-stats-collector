/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree28 {
    public double calcTree(double... fs) {
        if (fs[4] <= 7.5) {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 2.5) {
                    if (fs[53] <= -987.5) {
                        if (fs[4] <= 2.5) {
                            if (fs[59] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.137834458532;
                                    } else {
                                        return 0.206006844698;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.128387573989;
                                    } else {
                                        return 0.191457439265;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[53] <= -1309.0) {
                                        return -0.0549745805222;
                                    } else {
                                        return 0.197568001823;
                                    }
                                } else {
                                    return 0.311570386721;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[72] <= 9998.5) {
                                        return 0.325445640164;
                                    } else {
                                        return 0.271947423269;
                                    }
                                } else {
                                    if (fs[74] <= 0.5) {
                                        return 0.222380259462;
                                    } else {
                                        return 0.0925252461828;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.201403992577;
                                    } else {
                                        return 0.163320609584;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.133926133847;
                                    } else {
                                        return -0.00699635068755;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0264622621194;
                                    } else {
                                        return 0.0867872528043;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.184992759572;
                                    } else {
                                        return 0.0611859479257;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[4] <= 6.5) {
                                        return -0.121875408;
                                    } else {
                                        return 0.0550185098313;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.275287283821;
                                    } else {
                                        return -0.12877459351;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[72] <= 9969.0) {
                                    if (fs[18] <= 0.5) {
                                        return 0.252750459702;
                                    } else {
                                        return 0.130303895665;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.278794962901;
                                    } else {
                                        return 0.184945145849;
                                    }
                                }
                            } else {
                                if (fs[49] <= -0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.284311165662;
                                    } else {
                                        return 0.231983911412;
                                    }
                                } else {
                                    if (fs[72] <= 9987.5) {
                                        return 0.0507960592356;
                                    } else {
                                        return 0.174291731508;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 5.5) {
                        if (fs[53] <= -1278.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[88] <= 3.0) {
                                        return 0.256894077854;
                                    } else {
                                        return -0.353010375045;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.0303382060827;
                                    } else {
                                        return 0.0996349410523;
                                    }
                                }
                            } else {
                                if (fs[47] <= -61.5) {
                                    return -0.127151540246;
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.249365683792;
                                    } else {
                                        return 0.47337688664;
                                    }
                                }
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.230410722111;
                                    } else {
                                        return 0.286140585218;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.173579304536;
                                    } else {
                                        return 0.244643987477;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[53] <= -477.0) {
                                        return -0.0832857130284;
                                    } else {
                                        return 0.352600601286;
                                    }
                                } else {
                                    if (fs[72] <= 4612.5) {
                                        return -0.0648549294114;
                                    } else {
                                        return -0.430222705466;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[60] <= 0.5) {
                            if (fs[25] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[53] <= -1298.0) {
                                        return 0.426887162486;
                                    } else {
                                        return 0.253752961082;
                                    }
                                } else {
                                    if (fs[72] <= 9884.5) {
                                        return 0.305685620269;
                                    } else {
                                        return 0.265999171989;
                                    }
                                }
                            } else {
                                return -0.149123895222;
                            }
                        } else {
                            if (fs[28] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.262437833622;
                                    } else {
                                        return 0.0645071523416;
                                    }
                                } else {
                                    if (fs[53] <= -566.5) {
                                        return 0.0793287337619;
                                    } else {
                                        return 0.216446756303;
                                    }
                                }
                            } else {
                                return -0.142113389548;
                            }
                        }
                    }
                }
            } else {
                if (fs[76] <= 25.0) {
                    if (fs[72] <= 9993.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[89] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0265284268111;
                                    } else {
                                        return -0.0364022257845;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0943144436292;
                                    } else {
                                        return -0.00843756613723;
                                    }
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.00185903013616;
                                    } else {
                                        return 0.133168389305;
                                    }
                                } else {
                                    if (fs[62] <= -0.5) {
                                        return 0.144707701335;
                                    } else {
                                        return 0.00186753547772;
                                    }
                                }
                            }
                        } else {
                            if (fs[81] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.060543912783;
                                    } else {
                                        return -0.0390015701011;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.147917771149;
                                    } else {
                                        return 0.0241009533736;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.0759681651047;
                                    } else {
                                        return -0.0144695005309;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.00963316873584;
                                    } else {
                                        return 0.0156219225097;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[24] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 39.5) {
                                        return 0.0166005657201;
                                    } else {
                                        return -0.0796554441666;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.156662256014;
                                    } else {
                                        return 0.0754120593973;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return 0.189663490095;
                                } else {
                                    return 0.118095148373;
                                }
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[47] <= -45.5) {
                                        return -0.0408599999567;
                                    } else {
                                        return 0.0639046790983;
                                    }
                                } else {
                                    return 0.249256597773;
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.291884458135;
                                    } else {
                                        return 0.543822628608;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.106100957773;
                                    } else {
                                        return 0.25876931033;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 7.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[53] <= -992.0) {
                                    if (fs[88] <= 4.5) {
                                        return 0.116783303483;
                                    } else {
                                        return 0.0506619301846;
                                    }
                                } else {
                                    if (fs[53] <= -21.0) {
                                        return -0.0963268358308;
                                    } else {
                                        return 0.0278221649232;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    return 0.331191031922;
                                } else {
                                    if (fs[53] <= -485.5) {
                                        return -0.0309875078695;
                                    } else {
                                        return 0.0287363841507;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1093.5) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0880298310968;
                                    } else {
                                        return 0.0187992570544;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.489294222436;
                                    } else {
                                        return 0.0610280875516;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[76] <= 250.0) {
                                        return 0.0101871928213;
                                    } else {
                                        return -0.0138169051277;
                                    }
                                } else {
                                    if (fs[72] <= 9684.5) {
                                        return -0.0196951715572;
                                    } else {
                                        return -0.0343879805354;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[53] <= -1453.5) {
                                        return 0.0402990043161;
                                    } else {
                                        return -0.0214465705571;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0731817704257;
                                    } else {
                                        return -0.0184114398484;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1218.0) {
                                    if (fs[47] <= -0.5) {
                                        return 0.288477477635;
                                    } else {
                                        return -0.101159369543;
                                    }
                                } else {
                                    if (fs[0] <= 9.0) {
                                        return -0.0663965635554;
                                    } else {
                                        return -0.0360445930082;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.296658387933;
                                    } else {
                                        return -0.030330382744;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0609931087262;
                                    } else {
                                        return -0.117932118563;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.197866438852;
                                    } else {
                                        return 0.329598832075;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0378311330188;
                                    } else {
                                        return 0.0680998215154;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[11] <= 0.5) {
                if (fs[90] <= 0.5) {
                    if (fs[47] <= -91.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[53] <= -1423.0) {
                                if (fs[60] <= 0.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.206872909012;
                                    } else {
                                        return 0.375983222246;
                                    }
                                } else {
                                    if (fs[72] <= 9991.5) {
                                        return 0.0974363736028;
                                    } else {
                                        return 0.320999351674;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.261222362239;
                                    } else {
                                        return 0.00414266159574;
                                    }
                                } else {
                                    if (fs[47] <= -313.0) {
                                        return -0.0756025947169;
                                    } else {
                                        return 0.0110278517314;
                                    }
                                }
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[72] <= 9988.0) {
                                        return 0.216758953523;
                                    } else {
                                        return -0.109355004063;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.308092075523;
                                    } else {
                                        return -0.038811671865;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    return 0.429174017898;
                                } else {
                                    return 0.655672304918;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[88] <= 1.5) {
                                    if (fs[53] <= -1508.0) {
                                        return 0.215286517475;
                                    } else {
                                        return 0.0860450518086;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0778544716978;
                                    } else {
                                        return 0.217785453648;
                                    }
                                }
                            } else {
                                if (fs[53] <= -977.0) {
                                    if (fs[84] <= 0.5) {
                                        return 0.26996339445;
                                    } else {
                                        return -0.0166641569766;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.18307151333;
                                    } else {
                                        return -0.194989230275;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[55] <= 0.5) {
                                        return -0.0116829667994;
                                    } else {
                                        return 0.083470632828;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.00107152879342;
                                    } else {
                                        return 0.302493044058;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.0259579106412;
                                    } else {
                                        return 0.125555963532;
                                    }
                                } else {
                                    return 0.446110853603;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[67] <= 0.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[53] <= -1978.0) {
                                    if (fs[97] <= 0.5) {
                                        return 0.429702367438;
                                    } else {
                                        return 0.336463556402;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return 0.224461092886;
                                    } else {
                                        return 0.14210719086;
                                    }
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    if (fs[47] <= -4.5) {
                                        return 0.00114291677952;
                                    } else {
                                        return 0.264080446519;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.163722038878;
                                    } else {
                                        return 0.0354327137814;
                                    }
                                }
                            }
                        } else {
                            if (fs[83] <= 0.5) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.051735629211;
                                    } else {
                                        return 0.149974182636;
                                    }
                                } else {
                                    return -0.2657067647;
                                }
                            } else {
                                return -0.416350625386;
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[53] <= -1273.0) {
                                if (fs[72] <= 9996.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.082755129251;
                                    } else {
                                        return 0.261387684675;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0248320097802;
                                    } else {
                                        return -0.19922895875;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1068.0) {
                                    if (fs[52] <= 0.5) {
                                        return 0.041495462315;
                                    } else {
                                        return 0.244385378843;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.0423244440574;
                                    } else {
                                        return -0.00604342238706;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[49] <= -2.5) {
                                        return 0.243750648195;
                                    } else {
                                        return 0.00988298128768;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.0523322752543;
                                    } else {
                                        return 0.242590168421;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[49] <= -2.5) {
                                        return 0.00526288172813;
                                    } else {
                                        return -0.0166556094419;
                                    }
                                } else {
                                    if (fs[72] <= 9980.0) {
                                        return -0.00993443541064;
                                    } else {
                                        return 0.146799812189;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 4.5) {
                        if (fs[103] <= 0.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[76] <= 100.0) {
                                    if (fs[30] <= 0.5) {
                                        return 0.274420421928;
                                    } else {
                                        return 0.0106684967592;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0576788707619;
                                    } else {
                                        return 0.114468556904;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1543.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.232529202681;
                                    } else {
                                        return 0.242491924673;
                                    }
                                } else {
                                    if (fs[72] <= 9819.5) {
                                        return -0.0158173576554;
                                    } else {
                                        return 0.103910380487;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[4] <= 26.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.0922192601235;
                                    } else {
                                        return 0.187142046294;
                                    }
                                } else {
                                    if (fs[72] <= 9989.5) {
                                        return -0.027651393478;
                                    } else {
                                        return -0.213185372864;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1518.5) {
                                    if (fs[72] <= 9989.0) {
                                        return 0.408483697261;
                                    } else {
                                        return 0.32663017756;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0684444725729;
                                    } else {
                                        return 0.119938220655;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 8.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.244865431724;
                                    } else {
                                        return 0.0610729301024;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return 0.13328754396;
                                    } else {
                                        return -0.136336183722;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[72] <= 9869.0) {
                                        return -0.00346187404794;
                                    } else {
                                        return 0.207495981955;
                                    }
                                } else {
                                    if (fs[88] <= 5.0) {
                                        return 0.192707853216;
                                    } else {
                                        return 0.0372670139685;
                                    }
                                }
                            }
                        } else {
                            if (fs[43] <= 0.5) {
                                if (fs[4] <= 27.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0483704150727;
                                    } else {
                                        return 0.272014801944;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0767380762252;
                                    } else {
                                        return 0.127838785376;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    return 0.162957428266;
                                } else {
                                    return -0.236918597653;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9983.5) {
                        if (fs[0] <= 3.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[24] <= 0.5) {
                                        return -0.0165918188948;
                                    } else {
                                        return 0.00424875556917;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0118162299205;
                                    } else {
                                        return -0.0109048669575;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.00102948550376;
                                    } else {
                                        return 0.0514710898456;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0762919920785;
                                    } else {
                                        return 0.0142547332475;
                                    }
                                }
                            }
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[0] <= 8.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.00746248902122;
                                    } else {
                                        return -0.0163592487251;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.0986957684548;
                                    } else {
                                        return -0.0138992146964;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3620.0) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0920440962459;
                                    } else {
                                        return -0.0594109602661;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return -0.0144798164395;
                                    } else {
                                        return -0.0156685833126;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1067.0) {
                            if (fs[55] <= 496.5) {
                                if (fs[47] <= -959.5) {
                                    if (fs[72] <= 9985.5) {
                                        return -0.123130852075;
                                    } else {
                                        return 0.342426539391;
                                    }
                                } else {
                                    if (fs[88] <= 4.5) {
                                        return 0.0545883282415;
                                    } else {
                                        return -0.0620467698759;
                                    }
                                }
                            } else {
                                return 0.579627032053;
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[72] <= 9986.5) {
                                        return 0.209028293478;
                                    } else {
                                        return 0.022134335037;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0699312493458;
                                    } else {
                                        return 0.0475097461172;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[47] <= -2300.0) {
                                        return 0.235388727411;
                                    } else {
                                        return -0.0162421237636;
                                    }
                                } else {
                                    if (fs[53] <= -967.0) {
                                        return -0.0282187663398;
                                    } else {
                                        return 0.0203606043127;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
