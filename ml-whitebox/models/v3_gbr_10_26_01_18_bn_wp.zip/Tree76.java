/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree76 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[53] <= -1083.5) {
                if (fs[0] <= 1.5) {
                    if (fs[53] <= -1138.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0161843905258;
                                    } else {
                                        return 0.037474274533;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0268418767976;
                                    } else {
                                        return 0.0810093327208;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0947787438753;
                                    } else {
                                        return 0.0375469882971;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.0215061971159;
                                    } else {
                                        return -0.00210382963634;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 19.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0232129232469;
                                    } else {
                                        return 0.0373486082025;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.186714901965;
                                    } else {
                                        return -0.0215278853512;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 29.5) {
                                        return -0.0308927332938;
                                    } else {
                                        return 0.0105860387087;
                                    }
                                } else {
                                    return -0.165887556014;
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.0386134591089;
                                    } else {
                                        return 0.0235635137457;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0218535152402;
                                    } else {
                                        return 0.0140174588933;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return -0.0293291028767;
                                } else {
                                    return -0.117568756918;
                                }
                            }
                        } else {
                            if (fs[4] <= 19.5) {
                                return 0.000452478719291;
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0362339021527;
                                    } else {
                                        return -0.0273566913768;
                                    }
                                } else {
                                    return -0.0635337133854;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 2.5) {
                        return 0.136794144637;
                    } else {
                        if (fs[4] <= 3.5) {
                            if (fs[60] <= 0.5) {
                                return -0.143871382448;
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0129738166691;
                                    } else {
                                        return 0.0283773485771;
                                    }
                                } else {
                                    return 0.0855354251323;
                                }
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0182276024532;
                                    } else {
                                        return 0.00306090261328;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0168150747271;
                                    } else {
                                        return 0.0635961567726;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.0563860082047;
                                    } else {
                                        return 0.354627703321;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return -0.0280250183039;
                                    } else {
                                        return -0.00230016271713;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[52] <= 0.5) {
                    if (fs[26] <= 0.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0734600658509;
                                    } else {
                                        return 0.0542569741401;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.0175022327941;
                                    } else {
                                        return 0.0559310505147;
                                    }
                                }
                            } else {
                                if (fs[0] <= 21.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0103668107026;
                                    } else {
                                        return -0.0641938388265;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0369790990339;
                                    } else {
                                        return -0.00265662622788;
                                    }
                                }
                            }
                        } else {
                            if (fs[27] <= 0.5) {
                                return 0.145160743717;
                            } else {
                                return 0.131269928244;
                            }
                        }
                    } else {
                        if (fs[72] <= 5000.0) {
                            return 0.214022670492;
                        } else {
                            return 0.189857681991;
                        }
                    }
                } else {
                    if (fs[26] <= 0.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[4] <= 2.5) {
                                return -0.201194202789;
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0927224103299;
                                    } else {
                                        return -0.0413738176785;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0569847648668;
                                    } else {
                                        return -0.0225743809241;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 4847.0) {
                                if (fs[0] <= 8.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.00536482041868;
                                    } else {
                                        return -0.0412062373482;
                                    }
                                } else {
                                    if (fs[53] <= -16.5) {
                                        return -0.00216577063295;
                                    } else {
                                        return 0.0220325549795;
                                    }
                                }
                            } else {
                                return -0.0258269198053;
                            }
                        }
                    } else {
                        return -0.319495987117;
                    }
                }
            }
        } else {
            if (fs[64] <= -996.5) {
                if (fs[0] <= 2.5) {
                    if (fs[47] <= -27.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[4] <= 5.5) {
                                return 0.0945943455077;
                            } else {
                                return -0.121836282648;
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[12] <= 0.5) {
                                    return -0.0468400357168;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.219461415342;
                                    } else {
                                        return 0.25924595267;
                                    }
                                }
                            } else {
                                if (fs[47] <= -727.5) {
                                    return 0.157360980085;
                                } else {
                                    if (fs[47] <= -47.5) {
                                        return -0.0304268321606;
                                    } else {
                                        return 0.0910219021333;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -23.5) {
                            return -0.245634921064;
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.0326345079513;
                                    } else {
                                        return 0.11204720759;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.181511688684;
                                    } else {
                                        return 0.0693678007364;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[49] <= -1.5) {
                                        return 0.367933397864;
                                    } else {
                                        return 0.134176492222;
                                    }
                                } else {
                                    return -0.0799837294146;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[64] <= -998.5) {
                                if (fs[97] <= 0.5) {
                                    return -0.0351824563765;
                                } else {
                                    return 0.0734322827458;
                                }
                            } else {
                                return 0.212269460518;
                            }
                        } else {
                            if (fs[53] <= -1108.0) {
                                if (fs[27] <= 0.5) {
                                    if (fs[47] <= -2.5) {
                                        return 0.116167751498;
                                    } else {
                                        return 0.000615799372238;
                                    }
                                } else {
                                    return 0.319612954632;
                                }
                            } else {
                                if (fs[49] <= -2.5) {
                                    return 0.0891175635232;
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.0205394504369;
                                    } else {
                                        return -0.00665420487737;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 17.5) {
                            if (fs[0] <= 4.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[47] <= -8.5) {
                                        return -0.0838237097824;
                                    } else {
                                        return -0.0345739546761;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.039919944033;
                                    } else {
                                        return -0.0176604895173;
                                    }
                                }
                            } else {
                                if (fs[88] <= 1.0) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0129507408201;
                                    } else {
                                        return -0.00462867174685;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0533383479745;
                                    } else {
                                        return 0.0506806762225;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 19.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.0885339173765;
                                    } else {
                                        return 0.280944710621;
                                    }
                                } else {
                                    return -0.0081622165519;
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    return -0.0273749735731;
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0147645734736;
                                    } else {
                                        return -0.00457445390967;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[57] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[47] <= -6.5) {
                                if (fs[4] <= 15.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.271870789685;
                                    } else {
                                        return 0.0397276074193;
                                    }
                                } else {
                                    if (fs[47] <= -266.5) {
                                        return 0.123913094065;
                                    } else {
                                        return -0.0197515318356;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.0153542826664;
                                    } else {
                                        return 0.0107108083535;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0298405429837;
                                    } else {
                                        return -0.18306114782;
                                    }
                                }
                            }
                        } else {
                            if (fs[32] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0384789962265;
                                    } else {
                                        return 0.0676895915699;
                                    }
                                } else {
                                    if (fs[53] <= -1458.5) {
                                        return 0.0311184961546;
                                    } else {
                                        return -0.0650927924303;
                                    }
                                }
                            } else {
                                return -0.371200981242;
                            }
                        }
                    } else {
                        if (fs[55] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00187994763619;
                                    } else {
                                        return -0.00049476938298;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0297856890113;
                                    } else {
                                        return -0.00611907957116;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[72] <= 9902.0) {
                                        return 0.0315889455596;
                                    } else {
                                        return 0.139765745249;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return 0.0163513745558;
                                    } else {
                                        return -0.00171702764014;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 19.5) {
                                        return 0.140076587077;
                                    } else {
                                        return -0.0152261922406;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.0977078964988;
                                    } else {
                                        return -0.0148183776499;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[4] <= 12.0) {
                                        return 0.40420702135;
                                    } else {
                                        return 0.249772333931;
                                    }
                                } else {
                                    return -0.0235947397115;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[72] <= 4995.0) {
                                if (fs[31] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0205844607697;
                                    } else {
                                        return 0.0696769775863;
                                    }
                                } else {
                                    return -0.0731589126118;
                                }
                            } else {
                                return -0.267916127721;
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[47] <= -4.0) {
                                        return -0.1258501528;
                                    } else {
                                        return 0.122186123073;
                                    }
                                } else {
                                    if (fs[53] <= -561.5) {
                                        return 0.335661545987;
                                    } else {
                                        return 0.203659494476;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return -0.12298372214;
                                } else {
                                    return 0.126934197672;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.0) {
                            if (fs[0] <= 7.5) {
                                return -0.00600918497305;
                            } else {
                                if (fs[53] <= 7.5) {
                                    return -0.00581258708378;
                                } else {
                                    return -0.0098702420969;
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                return -0.0322190817938;
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0145290774649;
                                    } else {
                                        return -0.0206531475823;
                                    }
                                } else {
                                    return -0.0288081745765;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
