/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree41 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[41] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[4] <= 9.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[47] <= -17.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.209727313329;
                                    } else {
                                        return 0.0711949794916;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.0973056789291;
                                    } else {
                                        return 0.128021942138;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.265231770379;
                                    } else {
                                        return 0.129654130975;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.158374063242;
                                    } else {
                                        return 0.0449020978486;
                                    }
                                }
                            }
                        } else {
                            if (fs[34] <= 0.5) {
                                if (fs[53] <= -988.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.0724277378624;
                                    } else {
                                        return 0.268239880286;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.0486068002151;
                                    } else {
                                        return 0.0313517710193;
                                    }
                                }
                            } else {
                                if (fs[53] <= -546.5) {
                                    if (fs[72] <= 9993.5) {
                                        return 0.373836981859;
                                    } else {
                                        return 0.229424621152;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return 0.144484021261;
                                    } else {
                                        return 0.193906071261;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 4.5) {
                            if (fs[62] <= -0.5) {
                                if (fs[64] <= -995.5) {
                                    if (fs[53] <= -2253.0) {
                                        return -0.101461834809;
                                    } else {
                                        return 0.148010737278;
                                    }
                                } else {
                                    if (fs[53] <= -1298.0) {
                                        return 0.214547077834;
                                    } else {
                                        return 0.0132322530599;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1493.5) {
                                    if (fs[81] <= 0.5) {
                                        return -0.0949298883326;
                                    } else {
                                        return 0.159585659092;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.00420264571393;
                                    } else {
                                        return 0.0803415073226;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[53] <= -1543.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.312721889659;
                                    } else {
                                        return 0.0508281233761;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0549394982878;
                                    } else {
                                        return -0.144081353328;
                                    }
                                }
                            } else {
                                if (fs[47] <= -9.5) {
                                    return -0.139125401913;
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return 0.294097863483;
                                    } else {
                                        return 0.0546209563661;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 4.5) {
                        if (fs[88] <= -0.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[53] <= -938.0) {
                                    if (fs[44] <= 0.5) {
                                        return -0.144307713918;
                                    } else {
                                        return 0.0324694972321;
                                    }
                                } else {
                                    return 0.251704645689;
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.191414690882;
                                    } else {
                                        return 0.129304535973;
                                    }
                                } else {
                                    return -0.373848303079;
                                }
                            }
                        } else {
                            if (fs[74] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.134933107808;
                                    } else {
                                        return 0.107994975666;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.04114053409;
                                    } else {
                                        return 0.103870509852;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1143.5) {
                                    if (fs[72] <= 4639.5) {
                                        return -0.070706503967;
                                    } else {
                                        return -0.139067218827;
                                    }
                                } else {
                                    if (fs[72] <= 9902.0) {
                                        return -0.0807060271557;
                                    } else {
                                        return 0.143515498145;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 14.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[2] <= 5.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.139254880111;
                                    } else {
                                        return 0.094997491071;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.143318412913;
                                    } else {
                                        return 0.183164980654;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.303561260106;
                                    } else {
                                        return -0.223966441147;
                                    }
                                } else {
                                    return 0.0158798792479;
                                }
                            }
                        } else {
                            if (fs[4] <= 45.0) {
                                if (fs[83] <= 0.5) {
                                    if (fs[2] <= 10.5) {
                                        return 0.0644469223319;
                                    } else {
                                        return 0.2366962022;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.157750652426;
                                    } else {
                                        return 0.211229959107;
                                    }
                                }
                            } else {
                                return -0.328396168078;
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1138.0) {
                    if (fs[83] <= 0.5) {
                        if (fs[59] <= 0.5) {
                            if (fs[26] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.171254260623;
                                    } else {
                                        return 0.316087171673;
                                    }
                                } else {
                                    if (fs[47] <= -106.5) {
                                        return 0.0903656566002;
                                    } else {
                                        return -0.0468153981149;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.201759668141;
                                    } else {
                                        return 0.000585288934033;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.00515642589768;
                                    } else {
                                        return -0.0475790316703;
                                    }
                                }
                            }
                        } else {
                            if (fs[81] <= 0.5) {
                                return 0.169235942402;
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.070174182775;
                                    } else {
                                        return 0.14430504234;
                                    }
                                } else {
                                    if (fs[53] <= -1448.5) {
                                        return 0.101761983787;
                                    } else {
                                        return -0.238792948421;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            return -0.0644124341514;
                        } else {
                            if (fs[2] <= 1.5) {
                                return -0.285586617113;
                            } else {
                                return -0.373318317445;
                            }
                        }
                    }
                } else {
                    if (fs[70] <= -3.5) {
                        return 0.165449822563;
                    } else {
                        if (fs[81] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                return 0.0916490427592;
                            } else {
                                return 0.0462706332731;
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.338164778879;
                                    } else {
                                        return -0.10581613317;
                                    }
                                } else {
                                    return -0.0134120751807;
                                }
                            } else {
                                if (fs[72] <= 9987.5) {
                                    if (fs[51] <= 0.5) {
                                        return -0.0812327446096;
                                    } else {
                                        return 0.134242915969;
                                    }
                                } else {
                                    return 0.151828293153;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[72] <= 9981.5) {
                if (fs[0] <= 1.5) {
                    if (fs[47] <= -259.5) {
                        if (fs[59] <= 0.5) {
                            if (fs[4] <= 12.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.169459467538;
                                    } else {
                                        return 0.0175065646151;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.0989790901012;
                                    } else {
                                        return -0.214090908527;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[53] <= -1578.0) {
                                        return 0.131748919401;
                                    } else {
                                        return -0.0937879153235;
                                    }
                                } else {
                                    return -0.134348878523;
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[47] <= -6681.0) {
                                        return 0.191598767042;
                                    } else {
                                        return 0.0635474160386;
                                    }
                                } else {
                                    if (fs[47] <= -625.0) {
                                        return 0.226329954899;
                                    } else {
                                        return 0.415779682319;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 19.5) {
                                        return -0.0454666061396;
                                    } else {
                                        return 0.216944040032;
                                    }
                                } else {
                                    return 0.27945254997;
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0234470514878;
                                    } else {
                                        return 0.0964433024126;
                                    }
                                } else {
                                    if (fs[53] <= -1258.0) {
                                        return 0.0291388722798;
                                    } else {
                                        return -0.00600369133086;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[53] <= -988.5) {
                                        return -0.00040339786175;
                                    } else {
                                        return -0.0540776846852;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.00821104876585;
                                    } else {
                                        return 0.181705666213;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -37.0) {
                                if (fs[53] <= -942.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0307835548193;
                                    } else {
                                        return -0.0169587729917;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return 0.031773161384;
                                    } else {
                                        return 0.141923673873;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0394572699283;
                                    } else {
                                        return -0.029294204569;
                                    }
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return -0.0397955470355;
                                    } else {
                                        return -0.0203881829032;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 15.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return -0.00124777629188;
                                    } else {
                                        return 0.0566203682343;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return -0.00634855017492;
                                    } else {
                                        return -0.00062337007767;
                                    }
                                }
                            } else {
                                if (fs[64] <= -998.5) {
                                    return 0.587810213089;
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return 0.0163506936404;
                                    } else {
                                        return -0.00211057341079;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[47] <= -89.5) {
                                        return 0.0387211458895;
                                    } else {
                                        return -0.0171077882289;
                                    }
                                } else {
                                    if (fs[2] <= 7.5) {
                                        return -0.0122654869706;
                                    } else {
                                        return 0.0544066508883;
                                    }
                                }
                            } else {
                                if (fs[47] <= -2385.0) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0221938175406;
                                    } else {
                                        return -0.0537912417838;
                                    }
                                } else {
                                    if (fs[72] <= 9774.5) {
                                        return -0.00880137879138;
                                    } else {
                                        return -0.0158280568756;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= -2.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[62] <= -3.5) {
                                    return -0.0797141054127;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.103474235852;
                                    } else {
                                        return 0.267579964128;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.0899922033632;
                                    } else {
                                        return -0.0276373811983;
                                    }
                                } else {
                                    if (fs[64] <= -994.5) {
                                        return -0.0265877287159;
                                    } else {
                                        return -0.0316779425485;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -1.5) {
                                if (fs[0] <= 120.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0045417405925;
                                    } else {
                                        return -0.00814594927235;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.00126629198547;
                                    } else {
                                        return -0.00812477167557;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0218061191978;
                                    } else {
                                        return -0.0529100833322;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.023272777755;
                                    } else {
                                        return -0.0115298159931;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 2.5) {
                    if (fs[4] <= 4.5) {
                        if (fs[59] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.0701494495601;
                                    } else {
                                        return -0.00386773209966;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.331819522213;
                                    } else {
                                        return 0.00306374077269;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[48] <= 0.5) {
                                        return 0.023776411662;
                                    } else {
                                        return 0.0702637352987;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.016913846342;
                                    } else {
                                        return -0.124288414453;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[72] <= 9983.5) {
                                    return 0.21695875071;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0233982323356;
                                    } else {
                                        return 0.254271826778;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9995.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0437467413546;
                                    } else {
                                        return 0.0991908435826;
                                    }
                                } else {
                                    if (fs[53] <= -571.5) {
                                        return 0.538444302976;
                                    } else {
                                        return 0.181503030647;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[63] <= 0.5) {
                            if (fs[53] <= -1403.0) {
                                if (fs[53] <= -1448.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0217675226502;
                                    } else {
                                        return 0.104013899071;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.192089670925;
                                    } else {
                                        return 0.361175833204;
                                    }
                                }
                            } else {
                                if (fs[64] <= -995.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.283791060288;
                                    } else {
                                        return 0.100812029451;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.00541463948207;
                                    } else {
                                        return -0.0111230710277;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9998.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0252563020182;
                                    } else {
                                        return 0.0179226314682;
                                    }
                                } else {
                                    return -0.088684438575;
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0863054708928;
                                    } else {
                                        return 0.0455299691375;
                                    }
                                } else {
                                    return -0.149139864218;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[102] <= 0.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[55] <= 0.5) {
                                if (fs[53] <= -1418.0) {
                                    if (fs[0] <= 17.5) {
                                        return 0.0781151668815;
                                    } else {
                                        return -0.0898629101774;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.00216576649245;
                                    } else {
                                        return 0.040429111178;
                                    }
                                }
                            } else {
                                return 0.48527618605;
                            }
                        } else {
                            if (fs[53] <= 13.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 30.5) {
                                        return -0.0328678998293;
                                    } else {
                                        return -0.081811283123;
                                    }
                                } else {
                                    if (fs[47] <= -25.5) {
                                        return 0.0399371145545;
                                    } else {
                                        return -0.0213504886119;
                                    }
                                }
                            } else {
                                return 0.103804139514;
                            }
                        }
                    } else {
                        if (fs[53] <= -1072.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[72] <= 9999.5) {
                                    return 0.503268503775;
                                } else {
                                    return 0.353292628691;
                                }
                            } else {
                                if (fs[72] <= 9998.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.106904134913;
                                    } else {
                                        return 0.51011598479;
                                    }
                                } else {
                                    return 0.297378885862;
                                }
                            }
                        } else {
                            return -0.00773671165577;
                        }
                    }
                }
            }
        }
    }
}
