/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree83 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[11] <= 0.5) {
                if (fs[101] <= 1.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[72] <= 9989.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.0459353007164;
                                    } else {
                                        return -0.00698130974422;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0114153871192;
                                    } else {
                                        return -0.0200739669776;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1273.0) {
                                    if (fs[64] <= -997.5) {
                                        return 0.228496113391;
                                    } else {
                                        return -0.151650810362;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.128750479157;
                                    } else {
                                        return -0.056844117318;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 7.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return 0.0744466267701;
                                    } else {
                                        return 0.246591708077;
                                    }
                                } else {
                                    return 0.286165656879;
                                }
                            } else {
                                if (fs[72] <= 9993.5) {
                                    if (fs[47] <= -2.5) {
                                        return 0.0689758858458;
                                    } else {
                                        return -0.223028376703;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.122885524859;
                                    } else {
                                        return -0.0235264343024;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -3443.0) {
                            return 0.129349297486;
                        } else {
                            if (fs[0] <= 9.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[47] <= -140.0) {
                                        return 0.0407879371737;
                                    } else {
                                        return 0.00170588082634;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return -0.0192164002857;
                                    } else {
                                        return 0.226229653726;
                                    }
                                }
                            } else {
                                if (fs[47] <= -165.0) {
                                    if (fs[53] <= -1463.0) {
                                        return 0.155338738043;
                                    } else {
                                        return -0.0145338129413;
                                    }
                                } else {
                                    if (fs[27] <= 0.5) {
                                        return -0.00191254097623;
                                    } else {
                                        return 0.0734565155394;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[58] <= 0.5) {
                                if (fs[53] <= -1398.0) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0254131895968;
                                    } else {
                                        return 0.0614484138836;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.019916718659;
                                    } else {
                                        return -0.104852956643;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0652156551203;
                                    } else {
                                        return -0.140628231046;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0206163003592;
                                    } else {
                                        return 0.303722243459;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return 0.0763105964097;
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[4] <= 19.5) {
                                        return -0.00848107788511;
                                    } else {
                                        return -0.0215103689113;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00249094219092;
                                    } else {
                                        return 0.0621773410149;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -5.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[47] <= -8.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.00799236139951;
                                    } else {
                                        return -0.0532481865815;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.062222476909;
                                    } else {
                                        return -0.0829539086239;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.00393513158512;
                                    } else {
                                        return -0.016940278475;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0512442977972;
                                    } else {
                                        return -0.0111756801525;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1098.0) {
                                if (fs[52] <= 0.5) {
                                    if (fs[72] <= 9986.5) {
                                        return 0.0103965375017;
                                    } else {
                                        return -0.0324065651832;
                                    }
                                } else {
                                    if (fs[0] <= 32.5) {
                                        return 0.044132606907;
                                    } else {
                                        return 0.333965541261;
                                    }
                                }
                            } else {
                                if (fs[47] <= -4.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.142898368392;
                                    } else {
                                        return 0.0182439619636;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return 0.00725576221921;
                                    } else {
                                        return -0.0038243732286;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[34] <= 0.5) {
                    if (fs[81] <= 0.5) {
                        if (fs[4] <= 2.5) {
                            if (fs[53] <= -1063.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0436381480218;
                                    } else {
                                        return 0.119843887137;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.191750174324;
                                    } else {
                                        return -0.0526378784037;
                                    }
                                }
                            } else {
                                return -0.152757108213;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0155678799956;
                                    } else {
                                        return -0.052923686904;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00395941302447;
                                    } else {
                                        return -0.0466867195521;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.00256267842503;
                                    } else {
                                        return 0.0197097469464;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0650508519315;
                                    } else {
                                        return -0.00114406814515;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[103] <= 1.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.00149310612728;
                                    } else {
                                        return 0.00257012542247;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0114896466386;
                                    } else {
                                        return -0.00123168961604;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0711159828139;
                                    } else {
                                        return 0.1867035468;
                                    }
                                } else {
                                    if (fs[72] <= 9991.5) {
                                        return 0.0102916437955;
                                    } else {
                                        return 0.123674204752;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -649.0) {
                                if (fs[79] <= 0.5) {
                                    if (fs[47] <= -735.0) {
                                        return 0.0671221507858;
                                    } else {
                                        return 0.358929552736;
                                    }
                                } else {
                                    return 0.289943407212;
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.00506130739896;
                                    } else {
                                        return 0.0440671187509;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.000952165320832;
                                    } else {
                                        return -0.0437148452423;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1118.0) {
                        if (fs[4] <= 15.0) {
                            if (fs[4] <= 8.5) {
                                if (fs[72] <= 4733.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.147736595736;
                                    } else {
                                        return 0.217154377246;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0951749502789;
                                    } else {
                                        return -0.128312384678;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[72] <= 9981.5) {
                                        return 0.31129804814;
                                    } else {
                                        return 0.168185843503;
                                    }
                                } else {
                                    return 0.324014064869;
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                return 0.0208274854124;
                            } else {
                                return -0.0245800199241;
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                return 0.270266651744;
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.112849100483;
                                    } else {
                                        return 0.0502568920953;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return -0.0132192959245;
                                    } else {
                                        return 0.0405282057331;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9806.0) {
                                if (fs[4] <= 12.5) {
                                    if (fs[72] <= 9632.0) {
                                        return -0.0144938501058;
                                    } else {
                                        return -0.0229375263448;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0243200409569;
                                    } else {
                                        return -0.00789700985922;
                                    }
                                }
                            } else {
                                return -0.0592755479171;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[4] <= 4.5) {
                if (fs[52] <= 0.5) {
                    if (fs[28] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[23] <= 0.5) {
                                        return 0.205043128864;
                                    } else {
                                        return 0.111649933655;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0256270323174;
                                    } else {
                                        return -0.0346413963122;
                                    }
                                }
                            } else {
                                if (fs[47] <= -32.0) {
                                    return -0.0932707647909;
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return -0.175052433627;
                                    } else {
                                        return -0.0160270790276;
                                    }
                                }
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[47] <= -3.0) {
                                        return 0.0670106888992;
                                    } else {
                                        return -0.093076404439;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0461035953869;
                                    } else {
                                        return -0.197389614615;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1128.5) {
                                    return 0.320506107166;
                                } else {
                                    return -0.00306079701569;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1293.0) {
                            return -0.444731794947;
                        } else {
                            return 0.120627063622;
                        }
                    }
                } else {
                    if (fs[0] <= 16.5) {
                        if (fs[88] <= 6.5) {
                            if (fs[103] <= 0.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.0503777151657;
                                    } else {
                                        return 0.122183951171;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.41902480705;
                                    } else {
                                        return 0.0939780161409;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    return -0.108502125694;
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.00937577597256;
                                    } else {
                                        return -0.110234117777;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0356312793008;
                                    } else {
                                        return -0.135059423834;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.097533137843;
                                    } else {
                                        return 0.162374843168;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.208500477749;
                                    } else {
                                        return 0.0542905422472;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return 0.0735987635603;
                                    } else {
                                        return -0.131967700133;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 39.5) {
                            if (fs[0] <= 38.5) {
                                if (fs[4] <= 3.5) {
                                    return 0.0456293641263;
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0307143178667;
                                    } else {
                                        return -0.105807352648;
                                    }
                                }
                            } else {
                                return 0.10573202624;
                            }
                        } else {
                            if (fs[72] <= 9998.5) {
                                return -0.0701592695457;
                            } else {
                                return -0.128486580078;
                            }
                        }
                    }
                }
            } else {
                if (fs[13] <= 0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[18] <= -0.5) {
                            if (fs[53] <= -1307.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return -0.0230667203591;
                                    } else {
                                        return -0.224360278341;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.184406907469;
                                    } else {
                                        return -0.238036360659;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return -0.00578562923227;
                                } else {
                                    return -0.0223865421085;
                                }
                            }
                        } else {
                            if (fs[53] <= -1098.5) {
                                if (fs[88] <= -0.5) {
                                    return -0.329008715362;
                                } else {
                                    if (fs[4] <= 30.5) {
                                        return 0.0325287909403;
                                    } else {
                                        return -0.0696691550435;
                                    }
                                }
                            } else {
                                if (fs[32] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.00643390571286;
                                    } else {
                                        return -0.0234958710893;
                                    }
                                } else {
                                    return 0.324515593108;
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 1.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0349954783982;
                                    } else {
                                        return -0.0272537534999;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.00793942947705;
                                    } else {
                                        return 0.0926116293844;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[53] <= -1037.0) {
                                        return 0.169092323437;
                                    } else {
                                        return 0.0380641180945;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.0283635350332;
                                    } else {
                                        return -0.0432762843119;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[47] <= -1.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.298543734937;
                                    } else {
                                        return 0.0446703393884;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.1012577067;
                                    } else {
                                        return -0.0971759090221;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.0722542185251;
                                    } else {
                                        return -0.063667500184;
                                    }
                                } else {
                                    if (fs[0] <= 32.5) {
                                        return -0.00665783006292;
                                    } else {
                                        return 0.153274158122;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[99] <= 0.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.142610276089;
                                    } else {
                                        return -0.0400831689482;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return 0.104722646983;
                                    } else {
                                        return 0.0978539439818;
                                    }
                                }
                            } else {
                                if (fs[74] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.00685434198408;
                                    } else {
                                        return -0.140698627746;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.156890121683;
                                    } else {
                                        return -0.022054339069;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 0.5) {
                                if (fs[104] <= 0.5) {
                                    return -0.0802566177947;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0349382505896;
                                    } else {
                                        return -0.046127549209;
                                    }
                                }
                            } else {
                                return 0.147210880589;
                            }
                        }
                    } else {
                        if (fs[72] <= 9999.5) {
                            if (fs[53] <= -1318.0) {
                                return 0.0424771752764;
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.145863863547;
                                    } else {
                                        return -0.169120796395;
                                    }
                                } else {
                                    return -0.0611147517245;
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                return -0.266779146246;
                            } else {
                                return -0.368593354129;
                            }
                        }
                    }
                }
            }
        }
    }
}
