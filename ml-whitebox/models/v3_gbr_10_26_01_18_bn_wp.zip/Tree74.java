/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree74 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[53] <= -1498.5) {
                    if (fs[70] <= -1.5) {
                        if (fs[53] <= -1868.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.162788726418;
                                    } else {
                                        return 0.0891353874074;
                                    }
                                } else {
                                    if (fs[53] <= -1958.0) {
                                        return -0.0657735047511;
                                    } else {
                                        return 0.20707456907;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[53] <= -1978.0) {
                                        return 0.0184620026344;
                                    } else {
                                        return -0.091165219902;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.121562233108;
                                    } else {
                                        return 0.154240339212;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[53] <= -1553.5) {
                                        return 0.0966028005293;
                                    } else {
                                        return 0.209077290293;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.199646640441;
                                    } else {
                                        return 0.121221517499;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.0272074735858;
                                    } else {
                                        return 0.269210396332;
                                    }
                                } else {
                                    return -0.186730092375;
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            return -0.229582402115;
                        } else {
                            if (fs[101] <= 1.5) {
                                return -0.202806167201;
                            } else {
                                return -0.135009518444;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 9.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0445442114064;
                                    } else {
                                        return 0.184178148321;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.010322336633;
                                    } else {
                                        return -0.0826305718552;
                                    }
                                }
                            } else {
                                if (fs[74] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.036500489128;
                                    } else {
                                        return -0.132639483947;
                                    }
                                } else {
                                    return -0.0607796851911;
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[53] <= -987.5) {
                                        return 0.00905505041064;
                                    } else {
                                        return -0.0240618260965;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.087539159433;
                                    } else {
                                        return 0.22388275427;
                                    }
                                }
                            } else {
                                return 0.220293798556;
                            }
                        }
                    } else {
                        if (fs[64] <= -995.5) {
                            if (fs[70] <= -4.0) {
                                return -0.0903458588989;
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[62] <= -1.5) {
                                        return 0.117319742347;
                                    } else {
                                        return -0.167951402114;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0865460981651;
                                    } else {
                                        return 0.040875044892;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                if (fs[52] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return -0.0484043631321;
                                    } else {
                                        return 0.0984013633173;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return -0.0804026285848;
                                    } else {
                                        return -0.152133699769;
                                    }
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[4] <= 11.0) {
                                        return 0.122812368411;
                                    } else {
                                        return -0.0229110747667;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0183812067316;
                                    } else {
                                        return 0.21329188557;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[70] <= -3.5) {
                    if (fs[70] <= -4.5) {
                        if (fs[47] <= -33.0) {
                            if (fs[88] <= 1.0) {
                                if (fs[4] <= 10.5) {
                                    if (fs[53] <= -561.5) {
                                        return 0.15049769864;
                                    } else {
                                        return -0.0475396666672;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.208519305982;
                                    } else {
                                        return 0.326131576489;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.192003983551;
                                } else {
                                    return 0.247495041529;
                                }
                            }
                        } else {
                            if (fs[2] <= 6.5) {
                                if (fs[47] <= -14.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.08574489427;
                                    } else {
                                        return -0.147688650538;
                                    }
                                } else {
                                    if (fs[91] <= 0.5) {
                                        return 0.0499575419;
                                    } else {
                                        return -0.0739228492073;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3.5) {
                                    if (fs[2] <= 10.5) {
                                        return -0.132658979313;
                                    } else {
                                        return 0.146799108119;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.17668581847;
                                    } else {
                                        return 0.0600250233353;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[2] <= 2.5) {
                                    return 0.191479586538;
                                } else {
                                    return 0.106029246762;
                                }
                            } else {
                                return -0.15069031211;
                            }
                        } else {
                            if (fs[76] <= 100.0) {
                                if (fs[101] <= 1.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.246863485123;
                                    } else {
                                        return 0.142803398279;
                                    }
                                } else {
                                    return 0.294990585179;
                                }
                            } else {
                                return 0.102101679641;
                            }
                        }
                    }
                } else {
                    if (fs[24] <= 0.5) {
                        if (fs[4] <= 18.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[88] <= 2.5) {
                                        return 0.0189358138153;
                                    } else {
                                        return 0.0426169485908;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0109453021031;
                                    } else {
                                        return 0.0266515935827;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0408052486756;
                                    } else {
                                        return 0.0116712340717;
                                    }
                                } else {
                                    if (fs[88] <= 1.5) {
                                        return 0.0551455898082;
                                    } else {
                                        return 0.154541231901;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.0882494730335;
                                    } else {
                                        return -4.17153752197e-07;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.259387855378;
                                    } else {
                                        return 0.144000436802;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.359933657439;
                                    } else {
                                        return -0.0516509368235;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return 0.00672341331102;
                                    } else {
                                        return 0.118280601532;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[47] <= -248.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.174508097803;
                                    } else {
                                        return 0.114463328058;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.0666177521215;
                                    } else {
                                        return 0.0883659097366;
                                    }
                                }
                            } else {
                                if (fs[47] <= -143.5) {
                                    if (fs[47] <= -153.0) {
                                        return 0.0104390306032;
                                    } else {
                                        return -0.233807380754;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0187530671377;
                                    } else {
                                        return 0.0684006894266;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 0.5) {
                                if (fs[53] <= -1488.0) {
                                    return 0.0559942729558;
                                } else {
                                    return -0.0750652458852;
                                }
                            } else {
                                return -0.290408546501;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 2.5) {
                if (fs[4] <= 15.5) {
                    if (fs[45] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[103] <= 1.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.0223289966552;
                                    } else {
                                        return -0.00122251830204;
                                    }
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return 0.156452763707;
                                    } else {
                                        return -0.00699668947773;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[62] <= -0.5) {
                                        return -0.070505278938;
                                    } else {
                                        return 0.0399030833056;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0633357063453;
                                    } else {
                                        return -0.00606843271863;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 7.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0180565468237;
                                    } else {
                                        return 0.00199824556996;
                                    }
                                } else {
                                    if (fs[53] <= -1393.5) {
                                        return 0.00407151138472;
                                    } else {
                                        return -0.038627014272;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0601784948822;
                                    } else {
                                        return 0.124146583731;
                                    }
                                } else {
                                    if (fs[70] <= -4.5) {
                                        return -0.0439411674773;
                                    } else {
                                        return 0.027095682075;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[103] <= 1.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0111567463579;
                                    } else {
                                        return 0.255245313338;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.0120031397473;
                                    } else {
                                        return -0.0054644552244;
                                    }
                                }
                            } else {
                                return 0.121845288244;
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0269779859132;
                                    } else {
                                        return -0.0109204001395;
                                    }
                                } else {
                                    return -0.100473241841;
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[47] <= -45.5) {
                                        return 0.0315381078142;
                                    } else {
                                        return -0.0153802395967;
                                    }
                                } else {
                                    if (fs[47] <= -4.5) {
                                        return 0.0590038883576;
                                    } else {
                                        return -0.0060999379363;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[70] <= -1.5) {
                        if (fs[47] <= -3.5) {
                            if (fs[76] <= 150.0) {
                                if (fs[52] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return -0.0189378927466;
                                    } else {
                                        return -0.1057514433;
                                    }
                                } else {
                                    if (fs[2] <= 7.5) {
                                        return -0.00160509925603;
                                    } else {
                                        return 0.0877838511298;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9973.5) {
                                    if (fs[72] <= 9935.5) {
                                        return -0.0537484638859;
                                    } else {
                                        return 0.203108396551;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.139562096091;
                                    } else {
                                        return -0.060978346798;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -3443.0) {
                                return 0.360229143776;
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[4] <= 25.5) {
                                        return 0.000146026488948;
                                    } else {
                                        return -0.0134020208025;
                                    }
                                } else {
                                    if (fs[53] <= -1363.0) {
                                        return 0.213389519174;
                                    } else {
                                        return -0.0708992536883;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[97] <= 0.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[72] <= 9944.5) {
                                        return -0.0135607256924;
                                    } else {
                                        return -0.0995355639757;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0587174308332;
                                    } else {
                                        return -0.0179332727637;
                                    }
                                }
                            } else {
                                return -0.0859697908954;
                            }
                        } else {
                            if (fs[53] <= -1008.0) {
                                return -0.073106304633;
                            } else {
                                if (fs[79] <= 0.5) {
                                    return 0.00339158324599;
                                } else {
                                    return -0.0171378379101;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[47] <= -3848.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[53] <= -1298.0) {
                                    if (fs[4] <= 5.5) {
                                        return -0.155128933778;
                                    } else {
                                        return 0.244505400615;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.00817934211207;
                                    } else {
                                        return -0.0630808314354;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3942.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.0509362427074;
                                    } else {
                                        return -0.0214672331861;
                                    }
                                } else {
                                    return -0.156455565178;
                                }
                            }
                        } else {
                            if (fs[72] <= 9929.5) {
                                return 0.0449336011675;
                            } else {
                                return 0.211622060081;
                            }
                        }
                    } else {
                        if (fs[47] <= -3981.0) {
                            if (fs[22] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    return -0.10659583992;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0524861887985;
                                    } else {
                                        return -0.0153940180735;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.308535451952;
                                    } else {
                                        return 0.0827575927744;
                                    }
                                } else {
                                    return -0.0546397033738;
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                return 0.134094976639;
                            } else {
                                return 0.360872690946;
                            }
                        }
                    }
                } else {
                    if (fs[55] <= 0.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[47] <= -2557.5) {
                                if (fs[72] <= 9991.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0744084090175;
                                    } else {
                                        return -0.0282246172514;
                                    }
                                } else {
                                    return -0.138815617854;
                                }
                            } else {
                                if (fs[47] <= -2386.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.252536563716;
                                    } else {
                                        return -0.0246058797533;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.000911267262995;
                                    } else {
                                        return -0.00186945492527;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.112687105177;
                                    } else {
                                        return 0.459413377229;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0594566026172;
                                    } else {
                                        return -0.0166477847805;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[4] <= 24.5) {
                                        return 0.0307784520244;
                                    } else {
                                        return -0.0153589520864;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return -0.0027087629299;
                                    } else {
                                        return 0.0953119186953;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9989.5) {
                            if (fs[85] <= 0.5) {
                                return 0.0449857821984;
                            } else {
                                if (fs[0] <= 8.5) {
                                    return -0.0454576207006;
                                } else {
                                    if (fs[55] <= 492.5) {
                                        return -0.0116077539362;
                                    } else {
                                        return -0.00532270852781;
                                    }
                                }
                            }
                        } else {
                            return 0.21552714648;
                        }
                    }
                }
            }
        }
    }
}
