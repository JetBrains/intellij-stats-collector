/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree36 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[81] <= 0.5) {
                if (fs[70] <= -1.5) {
                    if (fs[53] <= -992.0) {
                        if (fs[0] <= 0.5) {
                            if (fs[101] <= 1.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0829790426902;
                                    } else {
                                        return 0.148441754488;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.156019573518;
                                    } else {
                                        return 0.166889696387;
                                    }
                                }
                            } else {
                                return -0.141145798992;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0403200829058;
                                    } else {
                                        return 0.267502183289;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0644560803445;
                                    } else {
                                        return -0.0232291862793;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0403452391277;
                                    } else {
                                        return 0.133872116432;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0314293113303;
                                    } else {
                                        return 0.030857972844;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.135020643759;
                                    } else {
                                        return -0.0195360206581;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0286314438367;
                                    } else {
                                        return -0.0731327240013;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -485.5) {
                                        return -0.0453344825337;
                                    } else {
                                        return 0.184564621096;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return -0.00433133381397;
                                    } else {
                                        return -0.0260420994976;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0767357481105;
                                    } else {
                                        return -0.00928960929881;
                                    }
                                } else {
                                    return -0.184226480962;
                                }
                            } else {
                                if (fs[0] <= 9.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0285723838715;
                                    } else {
                                        return -0.00967598296038;
                                    }
                                } else {
                                    if (fs[13] <= 0.5) {
                                        return -0.041561417613;
                                    } else {
                                        return -0.0120799814729;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 13.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[72] <= 4914.0) {
                                    if (fs[4] <= 5.5) {
                                        return 0.219237798761;
                                    } else {
                                        return 0.0853390316618;
                                    }
                                } else {
                                    return 0.0869826138666;
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[72] <= 4987.5) {
                                        return 0.134419599866;
                                    } else {
                                        return 0.184857845463;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.168987918597;
                                    } else {
                                        return 0.213752802557;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0264405392614;
                                    } else {
                                        return 0.119367798377;
                                    }
                                } else {
                                    return -0.0238660674854;
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    return -0.10803259678;
                                } else {
                                    return -0.0357656283864;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[53] <= -1188.0) {
                                if (fs[78] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0348473387459;
                                    } else {
                                        return -0.0582974028933;
                                    }
                                } else {
                                    return -0.0450153570353;
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.00302597766094;
                                    } else {
                                        return 0.0245372524238;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0259517121114;
                                    } else {
                                        return -0.0122752607311;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1578.0) {
                                return 0.0132264202098;
                            } else {
                                if (fs[4] <= 49.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.241788078986;
                                    } else {
                                        return -0.0179092494642;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.030492869469;
                                    } else {
                                        return -0.0270750008411;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[76] <= 25.0) {
                    if (fs[0] <= 0.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[53] <= -1504.0) {
                                    if (fs[4] <= 18.5) {
                                        return 0.260137013282;
                                    } else {
                                        return 0.137730490813;
                                    }
                                } else {
                                    if (fs[88] <= -0.5) {
                                        return -0.251810164927;
                                    } else {
                                        return 0.0632138432901;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[88] <= 6.0) {
                                        return -0.120968618371;
                                    } else {
                                        return 0.263543621789;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0305233046203;
                                    } else {
                                        return 0.270378210837;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[47] <= -121.5) {
                                        return 0.304809935916;
                                    } else {
                                        return 0.0230166011599;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return 0.140259132148;
                                    } else {
                                        return -0.0834450065396;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.199509687196;
                                    } else {
                                        return 0.148678238269;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.0446009353092;
                                    } else {
                                        return 0.110830758866;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 3.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.0361816329969;
                                    } else {
                                        return -0.0121532521083;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0235638445563;
                                    } else {
                                        return 0.114064567929;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0476452772097;
                                    } else {
                                        return 0.0070018207139;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return 0.0489005435842;
                                    } else {
                                        return -0.0425361369653;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return -0.00179784681363;
                                    } else {
                                        return -0.00979629125283;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0953591095105;
                                    } else {
                                        return -0.00467526259271;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.0596305052538;
                                    } else {
                                        return -0.00884377093734;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return -0.0068299510539;
                                    } else {
                                        return -0.0100197814128;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[47] <= -0.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.17140597052;
                                    } else {
                                        return 0.22473739399;
                                    }
                                } else {
                                    if (fs[72] <= 4775.5) {
                                        return 0.0772906010604;
                                    } else {
                                        return -0.359289065004;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.045569908829;
                                    } else {
                                        return 0.14444900633;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.153380107713;
                                    } else {
                                        return 0.124317488208;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.0484130103428;
                                    } else {
                                        return 0.130351379483;
                                    }
                                } else {
                                    if (fs[47] <= -6.5) {
                                        return 0.0586016002686;
                                    } else {
                                        return -0.0224193638694;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.00754789925315;
                                    } else {
                                        return 0.112189688103;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.015897186971;
                                    } else {
                                        return -0.0119704814;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[27] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0907693513577;
                                    } else {
                                        return 0.0273884081686;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.140232072001;
                                    } else {
                                        return 0.0287717960921;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[4] <= 13.5) {
                                        return -0.0158410860854;
                                    } else {
                                        return -0.0116529012021;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0117672108152;
                                    } else {
                                        return 0.0540935038472;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[88] <= 5.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.104698769047;
                                    } else {
                                        return -0.0972062726509;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.143871074477;
                                    } else {
                                        return -0.127083075013;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0103774260796;
                                    } else {
                                        return -0.00322992283586;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.113857605587;
                                    } else {
                                        return 0.00951318793321;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[53] <= -1052.5) {
                if (fs[47] <= -13.5) {
                    if (fs[18] <= -0.5) {
                        return -0.297372546417;
                    } else {
                        if (fs[66] <= 5.0) {
                            if (fs[4] <= 25.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.16505352235;
                                    } else {
                                        return -0.170114975726;
                                    }
                                } else {
                                    return -0.397006781525;
                                }
                            } else {
                                if (fs[4] <= 31.0) {
                                    if (fs[22] <= 0.5) {
                                        return 0.246760253803;
                                    } else {
                                        return 0.464442039301;
                                    }
                                } else {
                                    return 0.102497662554;
                                }
                            }
                        } else {
                            return -0.211643952354;
                        }
                    }
                } else {
                    if (fs[4] <= 10.5) {
                        if (fs[0] <= 13.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0917821086615;
                                    } else {
                                        return -0.253839867629;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.184229987941;
                                    } else {
                                        return 0.128565564924;
                                    }
                                }
                            } else {
                                return -0.411735551617;
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[0] <= 39.5) {
                                    if (fs[72] <= 9997.5) {
                                        return 0.110628184524;
                                    } else {
                                        return -0.0130747679121;
                                    }
                                } else {
                                    if (fs[92] <= 0.5) {
                                        return -0.0745665289325;
                                    } else {
                                        return -0.183070959102;
                                    }
                                }
                            } else {
                                return 0.354656661553;
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[53] <= -1132.5) {
                                if (fs[55] <= 546.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.10453211204;
                                    } else {
                                        return 0.0267077478165;
                                    }
                                } else {
                                    return 0.454904862222;
                                }
                            } else {
                                if (fs[76] <= 125.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.18444032682;
                                    } else {
                                        return 0.0225149733505;
                                    }
                                } else {
                                    if (fs[53] <= -1108.0) {
                                        return 0.404000285626;
                                    } else {
                                        return 0.0883965433075;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[53] <= -1608.0) {
                                    return 0.288969399529;
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return -0.149732777524;
                                    } else {
                                        return 0.025314803408;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[88] <= 2.5) {
                                        return 0.0867539710067;
                                    } else {
                                        return 0.382449012568;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.00792412922585;
                                    } else {
                                        return 0.135068110658;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[71] <= 0.5) {
                    if (fs[88] <= 5.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.238840927401;
                                    } else {
                                        return 0.0553612644255;
                                    }
                                } else {
                                    return 0.404273068209;
                                }
                            } else {
                                return 0.0406310517875;
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0622282012267;
                                    } else {
                                        return 0.14710535809;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.264403623675;
                                    } else {
                                        return -0.262926086964;
                                    }
                                }
                            } else {
                                if (fs[47] <= -432.0) {
                                    if (fs[24] <= 0.5) {
                                        return 0.0132361499988;
                                    } else {
                                        return 0.373435887317;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.0250048093229;
                                    } else {
                                        return -0.0236220456608;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[47] <= -83.0) {
                                return 0.0368220121807;
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.258865201477;
                                    } else {
                                        return 0.0877166769872;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.182635890897;
                                    } else {
                                        return 0.264927737638;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                return 0.0677052863002;
                            } else {
                                if (fs[59] <= 0.5) {
                                    return -0.0579279455306;
                                } else {
                                    if (fs[47] <= -84.0) {
                                        return 0.108365082572;
                                    } else {
                                        return -0.027809351392;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[49] <= -0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[47] <= -5.5) {
                                if (fs[49] <= -1.5) {
                                    return 0.0776098317204;
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.19443217076;
                                    } else {
                                        return 0.274121057861;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[64] <= -996.5) {
                                        return 0.233350175139;
                                    } else {
                                        return 0.298697055198;
                                    }
                                } else {
                                    return 0.320936118494;
                                }
                            }
                        } else {
                            if (fs[76] <= 150.0) {
                                return 0.157781388478;
                            } else {
                                return -0.00861241087721;
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0213314144285;
                                    } else {
                                        return 0.120274981517;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.050700973164;
                                    } else {
                                        return -0.00591775319889;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.10507888038;
                                    } else {
                                        return 0.0361055127621;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.0279407089959;
                                    } else {
                                        return -0.0288082549859;
                                    }
                                }
                            }
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.0601744196366;
                                    } else {
                                        return -0.00847553718677;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.16763541562;
                                    } else {
                                        return 0.0188209934162;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.184295095194;
                                    } else {
                                        return -0.0698889237604;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0931433083554;
                                    } else {
                                        return -0.0978152289793;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
