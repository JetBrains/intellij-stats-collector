/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree80 {
    public double calcTree(double... fs) {
        if (fs[64] <= -997.5) {
            if (fs[14] <= 0.5) {
                if (fs[47] <= -1468.5) {
                    return 0.223753429076;
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[4] <= 21.5) {
                            if (fs[58] <= 0.5) {
                                if (fs[8] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.00724761548329;
                                    } else {
                                        return 0.044097265978;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.249692423382;
                                    } else {
                                        return -0.0278027763095;
                                    }
                                }
                            } else {
                                if (fs[64] <= -998.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0442306317753;
                                    } else {
                                        return -0.0447156688062;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.16290652736;
                                    } else {
                                        return -0.0106720042179;
                                    }
                                }
                            }
                        } else {
                            return -0.21240375034;
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[27] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.00897837883689;
                                    } else {
                                        return -0.0190502782331;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.0309245421318;
                                    } else {
                                        return -0.0773341703951;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[47] <= -10.5) {
                                        return 0.0168630761834;
                                    } else {
                                        return -0.00491757329072;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0139664986075;
                                    } else {
                                        return -0.00989599998216;
                                    }
                                }
                            }
                        } else {
                            return -0.0348793942112;
                        }
                    }
                }
            } else {
                return -0.138893034575;
            }
        } else {
            if (fs[81] <= 0.5) {
                if (fs[0] <= 1.5) {
                    if (fs[4] <= 6.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[53] <= -988.0) {
                                        return 0.0229883267548;
                                    } else {
                                        return -0.118010897486;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0128007890883;
                                    } else {
                                        return 0.0325076453628;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    return 0.0873660233855;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0727752116167;
                                    } else {
                                        return -0.127131235711;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0332299889008;
                                    } else {
                                        return 0.235040209553;
                                    }
                                } else {
                                    if (fs[72] <= 5000.0) {
                                        return 0.0140941022782;
                                    } else {
                                        return 0.0615104509831;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.134453403447;
                                    } else {
                                        return -0.117936902099;
                                    }
                                } else {
                                    return -0.305669257863;
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.222478602522;
                                    } else {
                                        return -0.0250280213713;
                                    }
                                } else {
                                    if (fs[53] <= -1313.0) {
                                        return -0.02882088733;
                                    } else {
                                        return 0.0183756741279;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0381548584025;
                                    } else {
                                        return -0.0534287117379;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.0311276427453;
                                    } else {
                                        return -0.0133626495434;
                                    }
                                }
                            }
                        } else {
                            return 0.462585407552;
                        }
                    }
                } else {
                    if (fs[68] <= 1.5) {
                        if (fs[4] <= 2.5) {
                            if (fs[0] <= 4.5) {
                                if (fs[0] <= 3.5) {
                                    return 0.116102268583;
                                } else {
                                    return 0.200046506397;
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    return 0.00715921817349;
                                } else {
                                    if (fs[0] <= 14.5) {
                                        return 0.142842139055;
                                    } else {
                                        return 0.0902311757661;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -987.0) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[59] <= 0.5) {
                                        return -0.00871914547512;
                                    } else {
                                        return 0.00222688866439;
                                    }
                                } else {
                                    if (fs[4] <= 8.0) {
                                        return 0.117043909157;
                                    } else {
                                        return -0.00304433428397;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 25.5) {
                                        return 0.0427677368786;
                                    } else {
                                        return -0.052036269454;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0441308662186;
                                    } else {
                                        return -0.0128198609461;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1133.0) {
                            return 0.100935374331;
                        } else {
                            return -0.017303644621;
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[53] <= -1498.5) {
                        if (fs[70] <= -1.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[64] <= -996.5) {
                                    return -0.191741762987;
                                } else {
                                    if (fs[47] <= -330.5) {
                                        return 0.152272750145;
                                    } else {
                                        return 0.0424414557891;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[2] <= 8.5) {
                                        return 0.103279554273;
                                    } else {
                                        return -0.130118267112;
                                    }
                                } else {
                                    if (fs[53] <= -1578.0) {
                                        return 0.0715147299915;
                                    } else {
                                        return -0.304191616118;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.133337603013;
                                    } else {
                                        return -0.0582218246847;
                                    }
                                } else {
                                    return -0.271137230994;
                                }
                            } else {
                                return -0.322990178847;
                            }
                        }
                    } else {
                        if (fs[2] <= 5.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[53] <= -1483.5) {
                                        return -0.00927072326537;
                                    } else {
                                        return 0.0271722254274;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.0557706475247;
                                    } else {
                                        return 0.217084073114;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[72] <= 9829.5) {
                                        return -0.02460505917;
                                    } else {
                                        return 0.00647250643775;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0222514904916;
                                    } else {
                                        return -0.0335682417515;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 14.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0232900770146;
                                    } else {
                                        return 0.08708517091;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.0287185854639;
                                    } else {
                                        return 0.0914996663267;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0404653339899;
                                    } else {
                                        return 0.0350527378559;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0596307368153;
                                    } else {
                                        return -0.0723355575849;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9999.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[0] <= 7.5) {
                                        return 0.00923225563529;
                                    } else {
                                        return -0.00125648349975;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.00375347895021;
                                    } else {
                                        return -0.00150872482278;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[90] <= 0.5) {
                                        return -0.000974881365096;
                                    } else {
                                        return 0.0121657534351;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return 0.00384123873429;
                                    } else {
                                        return 0.0421372449915;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.00324216774009;
                                    } else {
                                        return 0.107825910646;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0879260856728;
                                    } else {
                                        return 0.38036185167;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.203200528013;
                                    } else {
                                        return 0.00517807154938;
                                    }
                                } else {
                                    return 0.142487857943;
                                }
                            }
                        }
                    } else {
                        if (fs[8] <= 0.5) {
                            if (fs[70] <= -3.5) {
                                if (fs[88] <= 4.0) {
                                    if (fs[45] <= 0.5) {
                                        return -0.151628216226;
                                    } else {
                                        return -0.0568545254682;
                                    }
                                } else {
                                    return 0.200491856479;
                                }
                            } else {
                                if (fs[53] <= -1968.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.015717258567;
                                    } else {
                                        return 0.293241613251;
                                    }
                                } else {
                                    if (fs[66] <= 5.0) {
                                        return 0.0150346991707;
                                    } else {
                                        return -0.160680003064;
                                    }
                                }
                            }
                        } else {
                            return -0.202752312755;
                        }
                    }
                }
            }
        }
    }
}
