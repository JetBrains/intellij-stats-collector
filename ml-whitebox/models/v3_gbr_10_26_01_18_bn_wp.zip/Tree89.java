/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree89 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[34] <= 0.5) {
                if (fs[47] <= -6.5) {
                    if (fs[18] <= -0.5) {
                        if (fs[4] <= 14.0) {
                            return -0.192529800844;
                        } else {
                            return -0.24971636305;
                        }
                    } else {
                        if (fs[53] <= -1478.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[72] <= 4229.0) {
                                        return 0.0621181981648;
                                    } else {
                                        return -0.0182606828925;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.0787404005677;
                                    } else {
                                        return -0.0185110848446;
                                    }
                                }
                            } else {
                                if (fs[53] <= -2253.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0193372280478;
                                    } else {
                                        return 0.141727369564;
                                    }
                                } else {
                                    if (fs[47] <= -524.0) {
                                        return 0.205617407918;
                                    } else {
                                        return -0.100014302993;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -987.0) {
                                if (fs[72] <= 9940.5) {
                                    if (fs[47] <= -847.0) {
                                        return 0.115396628792;
                                    } else {
                                        return 0.0241185447536;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0589772361082;
                                    } else {
                                        return 0.101759730226;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0419084105158;
                                    } else {
                                        return 0.0258217448667;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0145986700556;
                                    } else {
                                        return -0.109100803017;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[101] <= 1.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[53] <= -1043.5) {
                                        return 0.0117231902978;
                                    } else {
                                        return -0.00973889967648;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.0768352874191;
                                    } else {
                                        return 0.0172428826106;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.106639902652;
                                    } else {
                                        return -0.014453915578;
                                    }
                                } else {
                                    if (fs[4] <= 1.5) {
                                        return -0.0399107484921;
                                    } else {
                                        return 0.0228914845378;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[72] <= 9997.5) {
                                        return -0.0379487751618;
                                    } else {
                                        return 0.00896198165198;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return 0.00014521765212;
                                    } else {
                                        return 0.195950859644;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.0216986798782;
                                    } else {
                                        return 0.0938077166193;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0831759311012;
                                    } else {
                                        return -0.164027504977;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 6.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[76] <= 150.0) {
                                    if (fs[24] <= 0.5) {
                                        return 0.00158696402837;
                                    } else {
                                        return 0.0433199580674;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.111825338324;
                                    } else {
                                        return -0.0409545243286;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    if (fs[72] <= 9995.5) {
                                        return -0.0767635287151;
                                    } else {
                                        return 0.0433586772064;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0189278696575;
                                    } else {
                                        return 0.0877645917002;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[4] <= 24.0) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0805686290375;
                                    } else {
                                        return 0.0299920747309;
                                    }
                                } else {
                                    return -0.399660755148;
                                }
                            } else {
                                if (fs[53] <= -1273.0) {
                                    if (fs[53] <= -1593.0) {
                                        return 0.0808442786492;
                                    } else {
                                        return 0.258815658853;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0511085729832;
                                    } else {
                                        return 0.201462936105;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 14.5) {
                    if (fs[72] <= 9930.0) {
                        if (fs[4] <= 10.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[70] <= -4.0) {
                                    return 0.113551507468;
                                } else {
                                    if (fs[53] <= -546.5) {
                                        return 0.187529237225;
                                    } else {
                                        return 0.216658442137;
                                    }
                                }
                            } else {
                                return 0.0554778728221;
                            }
                        } else {
                            return 0.359315032569;
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            return -0.088365855609;
                        } else {
                            if (fs[53] <= -1138.0) {
                                if (fs[47] <= -38.0) {
                                    return 0.151064946118;
                                } else {
                                    if (fs[72] <= 9957.5) {
                                        return -0.0150646391205;
                                    } else {
                                        return 0.0863264853404;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[53] <= -1118.5) {
                                        return 0.0498233902199;
                                    } else {
                                        return 0.258250758287;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.0493879201956;
                                    } else {
                                        return -0.0903120615355;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    return -0.194231653688;
                }
            }
        } else {
            if (fs[30] <= 0.5) {
                if (fs[2] <= 6.5) {
                    if (fs[90] <= 0.5) {
                        if (fs[55] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.00379771803865;
                                    } else {
                                        return -0.000836216868773;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0262411013478;
                                    } else {
                                        return -0.00116526757699;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.000418144853276;
                                    } else {
                                        return 0.00326563625537;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.240309306925;
                                    } else {
                                        return 0.00923056467095;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 2.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[72] <= 9989.5) {
                                        return 0.0343469647421;
                                    } else {
                                        return 0.234629685521;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.055448342441;
                                    } else {
                                        return -0.014336125527;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return 0.41513709247;
                                } else {
                                    return 0.00741361752695;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1282.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[72] <= 9997.5) {
                                        return 0.0117751274129;
                                    } else {
                                        return -0.162930474711;
                                    }
                                } else {
                                    if (fs[47] <= -261.5) {
                                        return -0.0828611446862;
                                    } else {
                                        return 0.0697530757859;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0600011511451;
                                    } else {
                                        return 0.205741930202;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0362420620786;
                                    } else {
                                        return 0.00843729840533;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[49] <= -1.5) {
                                    if (fs[53] <= -1093.0) {
                                        return 0.0916276258178;
                                    } else {
                                        return -0.00199090080273;
                                    }
                                } else {
                                    if (fs[64] <= -998.5) {
                                        return 0.0857230283509;
                                    } else {
                                        return -0.00335677103316;
                                    }
                                }
                            } else {
                                if (fs[47] <= -0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.00831342942426;
                                    } else {
                                        return -0.00332097580411;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.205820435052;
                                    } else {
                                        return 0.0423463699103;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 3.5) {
                        if (fs[4] <= 25.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[4] <= 8.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0568221080155;
                                    } else {
                                        return -0.0222854732482;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0171576306255;
                                    } else {
                                        return -0.00542152987584;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0303324045562;
                                    } else {
                                        return 0.101247844756;
                                    }
                                } else {
                                    if (fs[101] <= 1.0) {
                                        return -0.0759460624417;
                                    } else {
                                        return 0.0126805529891;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -0.5) {
                                if (fs[64] <= -993.0) {
                                    return -0.0365277040616;
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return -0.126400247394;
                                    } else {
                                        return -0.113715236056;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return -0.0334165352998;
                                    } else {
                                        return 0.04849839763;
                                    }
                                } else {
                                    if (fs[4] <= 31.5) {
                                        return -0.0240839696234;
                                    } else {
                                        return 0.026187767433;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[4] <= 9.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[0] <= 11.5) {
                                        return -0.0189149345747;
                                    } else {
                                        return 0.0108729219871;
                                    }
                                } else {
                                    if (fs[2] <= 7.5) {
                                        return -0.00319301900084;
                                    } else {
                                        return -0.00739631894519;
                                    }
                                }
                            } else {
                                if (fs[88] <= 3.5) {
                                    if (fs[70] <= -4.0) {
                                        return -0.0125779712356;
                                    } else {
                                        return 1.82744214926e-05;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.273431689832;
                                    } else {
                                        return 0.0127590286479;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1438.0) {
                                if (fs[48] <= 0.5) {
                                    if (fs[47] <= -172.0) {
                                        return 0.385734084856;
                                    } else {
                                        return 0.0241694605003;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.00794056218842;
                                    } else {
                                        return 0.0651004290233;
                                    }
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    if (fs[43] <= 0.5) {
                                        return -0.0113380279093;
                                    } else {
                                        return 0.0473553446679;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.141005398351;
                                    } else {
                                        return 0.0037284893881;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1138.0) {
                    return 0.0951774225071;
                } else {
                    return 0.151602734845;
                }
            }
        }
    }
}
