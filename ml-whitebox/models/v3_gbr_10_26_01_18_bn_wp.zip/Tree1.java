/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree1 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[81] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[76] <= 100.0) {
                        if (fs[2] <= 1.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.559322720896;
                                    } else {
                                        return 0.844958796587;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.834684232855;
                                    } else {
                                        return 0.878990403381;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.831841023333;
                                    } else {
                                        return 0.277757009798;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.851061086401;
                                    } else {
                                        return 0.87513280222;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.889381471015;
                                    } else {
                                        return 0.828169980571;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.761467928136;
                                    } else {
                                        return 0.893992195337;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1133.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.834168493273;
                                    } else {
                                        return 0.875014528991;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.882961881791;
                                    } else {
                                        return 0.735700780144;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.174305876771;
                    }
                } else {
                    if (fs[76] <= 100.0) {
                        if (fs[0] <= 2.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.105303136506;
                                    } else {
                                        return -0.0644295184245;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.616988055652;
                                    } else {
                                        return 0.144998726384;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 5.0) {
                                        return 0.677650969973;
                                    } else {
                                        return 0.802737324367;
                                    }
                                } else {
                                    return 0.791204083526;
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 14.0) {
                                        return 0.0902403620764;
                                    } else {
                                        return -0.0561545155989;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return -0.0491759743633;
                                    } else {
                                        return 0.144359184149;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    if (fs[53] <= -1063.0) {
                                        return 0.572406096469;
                                    } else {
                                        return -0.00562294725128;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0191472096232;
                                    } else {
                                        return -0.0371760992445;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[0] <= 5.5) {
                                if (fs[53] <= -1188.0) {
                                    return -0.056205290638;
                                } else {
                                    if (fs[4] <= 31.5) {
                                        return 0.081096793148;
                                    } else {
                                        return -0.0561347063228;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[0] <= 9.5) {
                                        return -0.0169995967879;
                                    } else {
                                        return -0.0487375875558;
                                    }
                                } else {
                                    return -0.0554474408873;
                                }
                            }
                        } else {
                            if (fs[53] <= -1578.0) {
                                if (fs[0] <= 1.5) {
                                    return 0.0501359284811;
                                } else {
                                    return -0.0560567623492;
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 45.5) {
                                        return -0.0556075678748;
                                    } else {
                                        return -0.0533505083217;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0561129635973;
                                    } else {
                                        return -0.0554206680112;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[27] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[103] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[53] <= -1543.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.729466977463;
                                    } else {
                                        return 0.581553258313;
                                    }
                                } else {
                                    if (fs[74] <= 0.5) {
                                        return 0.433548609593;
                                    } else {
                                        return 0.0744707327727;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[13] <= 0.5) {
                                        return 0.606290951063;
                                    } else {
                                        return 0.808033303316;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.243271242022;
                                    } else {
                                        return 0.731950634567;
                                    }
                                }
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[53] <= -1493.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.873075173536;
                                    } else {
                                        return 0.77619303094;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.52101616422;
                                    } else {
                                        return 0.750434790645;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -436.0) {
                                        return 0.70397221076;
                                    } else {
                                        return 0.256825659004;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.808386908959;
                                    } else {
                                        return 0.45367415555;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[90] <= 0.5) {
                            if (fs[47] <= -2386.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.564887704878;
                                    } else {
                                        return 0.151893933285;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0490699905021;
                                    } else {
                                        return 0.0170110280232;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.025543371408;
                                    } else {
                                        return -0.0538068247705;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.018005854021;
                                    } else {
                                        return -0.050609828395;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[53] <= -1072.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.161308169618;
                                    } else {
                                        return 0.0440118367161;
                                    }
                                } else {
                                    if (fs[53] <= 3.5) {
                                        return -0.0288745729058;
                                    } else {
                                        return -0.0544732968362;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.138580739142;
                                    } else {
                                        return 0.000278621197898;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0422166801572;
                                    } else {
                                        return -0.0256422719022;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[103] <= 1.5) {
                                if (fs[62] <= -2.5) {
                                    return 0.364444727163;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.665683767243;
                                    } else {
                                        return 0.813476155224;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.871429551679;
                                    } else {
                                        return 0.840505394802;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.766245529154;
                                    } else {
                                        return 0.616967306378;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                if (fs[4] <= 5.5) {
                                    return 0.383667772253;
                                } else {
                                    return 0.495009609034;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return 0.320305319216;
                                } else {
                                    return 0.200703968926;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1057.5) {
                            if (fs[53] <= -1137.5) {
                                if (fs[49] <= -0.5) {
                                    if (fs[62] <= -1.5) {
                                        return 0.32392618569;
                                    } else {
                                        return 0.365583481336;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return 0.0646601813679;
                                    } else {
                                        return 0.170126393081;
                                    }
                                }
                            } else {
                                if (fs[64] <= -995.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.592119265751;
                                    } else {
                                        return 0.733245144592;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return 0.0515668347156;
                                    } else {
                                        return 0.292030366338;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.158322058193;
                                    } else {
                                        return 0.265497862023;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.0898745535689;
                                    } else {
                                        return -0.0263365102182;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0687856243748;
                                    } else {
                                        return -0.0434890782134;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.0484007054204;
                                    } else {
                                        return -0.0494182255796;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[53] <= -987.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -1468.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.402418911823;
                                    } else {
                                        return 0.754729235564;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.559481427622;
                                    } else {
                                        return -0.00671202550987;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[26] <= 0.5) {
                                        return 0.821632585441;
                                    } else {
                                        return 0.543094924407;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.682272592693;
                                    } else {
                                        return 0.81342666097;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= -0.5) {
                                return 0.0739521846735;
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.365379437946;
                                    } else {
                                        return 0.758783714311;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.736811004499;
                                    } else {
                                        return 0.900613470056;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 1.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[47] <= -2.5) {
                                    if (fs[47] <= -765.5) {
                                        return 0.862033378041;
                                    } else {
                                        return 0.901929544072;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.870226102252;
                                    } else {
                                        return 0.71351008874;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.784380914769;
                                    } else {
                                        return 0.691600068502;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.596721685454;
                                    } else {
                                        return 0.670611422206;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                if (fs[53] <= -1608.0) {
                                    if (fs[47] <= -3.5) {
                                        return 0.895342487806;
                                    } else {
                                        return 0.724225859785;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.774283514348;
                                    } else {
                                        return 0.532517922885;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[2] <= 3.5) {
                                        return 0.331595331743;
                                    } else {
                                        return 0.59806113559;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.516443822048;
                                    } else {
                                        return 0.743842130334;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.265482022794;
                                    } else {
                                        return 0.709281964333;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.389091780599;
                                    } else {
                                        return 0.752757795157;
                                    }
                                }
                            } else {
                                if (fs[49] <= -0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.853270818071;
                                    } else {
                                        return 0.909072649701;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.899666006054;
                                    } else {
                                        return 0.563915403086;
                                    }
                                }
                            }
                        } else {
                            if (fs[101] <= 1.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.797520005736;
                                    } else {
                                        return 0.666388375547;
                                    }
                                } else {
                                    if (fs[88] <= 4.5) {
                                        return 0.771354321599;
                                    } else {
                                        return 0.848486274733;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.666720284606;
                                    } else {
                                        return 0.834572414563;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.454898180188;
                                    } else {
                                        return 0.714858927917;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= -0.5) {
                            if (fs[49] <= -1.5) {
                                if (fs[101] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.696674424824;
                                    } else {
                                        return 0.685329981588;
                                    }
                                } else {
                                    return 0.898783848706;
                                }
                            } else {
                                if (fs[70] <= -4.0) {
                                    return 0.746655911939;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.905907068322;
                                    } else {
                                        return 0.856906189476;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 5.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.483050066343;
                                    } else {
                                        return 0.583041291071;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.508734170949;
                                    } else {
                                        return 0.339357579276;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[70] <= -4.0) {
                                        return 0.695544659227;
                                    } else {
                                        return 0.323283074335;
                                    }
                                } else {
                                    if (fs[4] <= 15.0) {
                                        return 0.809492199926;
                                    } else {
                                        return 0.496519424198;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1418.0) {
                    if (fs[41] <= 0.5) {
                        if (fs[88] <= 6.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.209827119822;
                                    } else {
                                        return 0.457255108271;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.21410896718;
                                    } else {
                                        return 0.0846888668793;
                                    }
                                }
                            } else {
                                if (fs[0] <= 21.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.447457816833;
                                    } else {
                                        return 0.933876933618;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.437526786233;
                                    } else {
                                        return 0.0760358999827;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[47] <= -79.0) {
                                        return 0.777902558114;
                                    } else {
                                        return 0.427060518954;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.787671566522;
                                    } else {
                                        return 0.623747887503;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.37983808824;
                                    } else {
                                        return 0.214926839588;
                                    }
                                } else {
                                    if (fs[4] <= 12.0) {
                                        return 0.531672872448;
                                    } else {
                                        return 0.82691678679;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[60] <= 0.5) {
                            if (fs[72] <= 9998.5) {
                                if (fs[76] <= 75.0) {
                                    return -0.0639105987999;
                                } else {
                                    return 0.150041045472;
                                }
                            } else {
                                return 0.630705266297;
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                if (fs[72] <= 9998.5) {
                                    return 0.120069855346;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.000516986778457;
                                    } else {
                                        return -0.0661853495972;
                                    }
                                }
                            } else {
                                return 0.0738247157229;
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[92] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.71586997677;
                                    } else {
                                        return 0.760847488015;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.339511281118;
                                    } else {
                                        return 0.183261281118;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[64] <= -498.5) {
                                        return 0.536222074712;
                                    } else {
                                        return 0.105734036272;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.225563080227;
                                    } else {
                                        return 0.119370375788;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[76] <= 50.0) {
                                    if (fs[4] <= 10.5) {
                                        return 0.110930951914;
                                    } else {
                                        return -0.0235598629423;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.00806560706028;
                                    } else {
                                        return -0.053370456039;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    return -0.058223470357;
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.116986342093;
                                    } else {
                                        return -0.0118764033748;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0818406994045;
                                    } else {
                                        return 0.197954894067;
                                    }
                                } else {
                                    if (fs[67] <= 0.5) {
                                        return 0.256692827718;
                                    } else {
                                        return 0.932771042626;
                                    }
                                }
                            } else {
                                if (fs[64] <= -995.5) {
                                    return 0.586734126541;
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.0197992098493;
                                    } else {
                                        return 0.0476342320129;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 16.5) {
                                        return -0.0463873204519;
                                    } else {
                                        return 0.0528519269527;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return -0.0458338962395;
                                    } else {
                                        return 0.0370557058725;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[53] <= -1037.0) {
                                        return 0.136167981607;
                                    } else {
                                        return -0.0432713914769;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0556151214966;
                                    } else {
                                        return -0.0585353544831;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
