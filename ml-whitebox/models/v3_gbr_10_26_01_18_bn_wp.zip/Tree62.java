/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree62 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[34] <= 0.5) {
                if (fs[41] <= 0.5) {
                    if (fs[57] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0587461420175;
                                    } else {
                                        return 0.11706829991;
                                    }
                                } else {
                                    if (fs[53] <= -967.0) {
                                        return 0.0369795752239;
                                    } else {
                                        return -0.003710419448;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.0348286049914;
                                    } else {
                                        return 0.200283317362;
                                    }
                                } else {
                                    if (fs[53] <= -1543.5) {
                                        return 0.0942332001506;
                                    } else {
                                        return -0.013428250369;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.0502279460997;
                                    } else {
                                        return -0.0109145822796;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return 0.0161643561797;
                                    } else {
                                        return 0.0863213805339;
                                    }
                                }
                            } else {
                                if (fs[47] <= -83.5) {
                                    if (fs[47] <= -1278.5) {
                                        return 0.0583022944315;
                                    } else {
                                        return 0.119341058742;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.0534813464745;
                                    } else {
                                        return -0.14225124274;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[64] <= -994.5) {
                            if (fs[49] <= -1.5) {
                                if (fs[103] <= 0.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.228143280248;
                                    } else {
                                        return 0.149738966704;
                                    }
                                } else {
                                    if (fs[53] <= -571.5) {
                                        return 0.149170214411;
                                    } else {
                                        return 0.0133151356114;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[101] <= 1.5) {
                                        return -0.139364837846;
                                    } else {
                                        return 0.111965514318;
                                    }
                                } else {
                                    return 0.210339144987;
                                }
                            }
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[53] <= -1128.0) {
                                    if (fs[47] <= -1.5) {
                                        return 0.292803477932;
                                    } else {
                                        return 0.149313597772;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.349835618117;
                                    } else {
                                        return 0.23871436013;
                                    }
                                }
                            } else {
                                if (fs[88] <= 3.0) {
                                    return -0.162511984198;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.204156504105;
                                    } else {
                                        return 0.134109495751;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 14.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[88] <= 5.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.280530245066;
                                    } else {
                                        return 0.000890314763678;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.100176251934;
                                    } else {
                                        return 0.100783101529;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    return 0.0853969553564;
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.183334474836;
                                    } else {
                                        return -0.357575626524;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0249289266224;
                                    } else {
                                        return 0.0831583008325;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.148780469262;
                                    } else {
                                        return 0.134026641696;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[53] <= -1488.5) {
                                        return 0.0607461402431;
                                    } else {
                                        return -0.0533500491836;
                                    }
                                } else {
                                    return -0.41789252001;
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[76] <= 25.0) {
                                return 0.23909729644;
                            } else {
                                return -0.0965605891868;
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.0207340529567;
                                    } else {
                                        return 0.185118681341;
                                    }
                                } else {
                                    return -0.201049071571;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[72] <= 9994.5) {
                                        return -0.0814065287644;
                                    } else {
                                        return -0.34952243378;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.399997228024;
                                    } else {
                                        return -0.212493307999;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -546.5) {
                    if (fs[4] <= 4.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[79] <= 0.5) {
                                return 0.0422850136093;
                            } else {
                                return 0.12451520261;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.148081055036;
                            } else {
                                if (fs[72] <= 9996.5) {
                                    return 0.17124184239;
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0972529355837;
                                    } else {
                                        return 0.097654324787;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 15.0) {
                            if (fs[72] <= 9930.0) {
                                if (fs[4] <= 7.5) {
                                    if (fs[70] <= -4.0) {
                                        return 0.191654255687;
                                    } else {
                                        return 0.292586359921;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.33040796895;
                                    } else {
                                        return 0.411264472184;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.248322601822;
                                    } else {
                                        return 0.127566991759;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.156572476053;
                                    } else {
                                        return 0.210139966021;
                                    }
                                }
                            }
                        } else {
                            return -0.0651871531111;
                        }
                    }
                } else {
                    if (fs[72] <= 9998.5) {
                        if (fs[72] <= 9986.0) {
                            if (fs[72] <= 9927.5) {
                                if (fs[72] <= 9536.0) {
                                    return 0.115573354372;
                                } else {
                                    return 0.150074785814;
                                }
                            } else {
                                return -0.114751261588;
                            }
                        } else {
                            return 0.357733196506;
                        }
                    } else {
                        return -0.17711911261;
                    }
                }
            }
        } else {
            if (fs[45] <= 0.5) {
                if (fs[103] <= 1.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[88] <= 6.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -2958.0) {
                                        return 0.172776732877;
                                    } else {
                                        return -0.00147794267805;
                                    }
                                } else {
                                    if (fs[72] <= 9886.5) {
                                        return 0.0096353508681;
                                    } else {
                                        return 0.0283389969106;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9989.5) {
                                    if (fs[72] <= 9881.5) {
                                        return -0.00776836712889;
                                    } else {
                                        return -0.0562856306231;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0676903839667;
                                    } else {
                                        return -0.0618754561982;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.00823324725414;
                                    } else {
                                        return 0.0192713646623;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.221575402957;
                                    } else {
                                        return 0.125216799719;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.219758139976;
                                    } else {
                                        return -0.321967838811;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.02832339527;
                                    } else {
                                        return 0.0680551769399;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[55] <= 0.5) {
                                    if (fs[72] <= 9998.5) {
                                        return -0.00232052188989;
                                    } else {
                                        return 0.0131909914781;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0452730276002;
                                    } else {
                                        return 0.232413123125;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.00299879102474;
                                    } else {
                                        return -0.00739016465716;
                                    }
                                } else {
                                    if (fs[53] <= -1418.0) {
                                        return 0.0473351556408;
                                    } else {
                                        return -0.0126840933385;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[0] <= 15.0) {
                                        return -0.0659374434278;
                                    } else {
                                        return -0.0462890062639;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0334442645959;
                                    } else {
                                        return 0.101261462229;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.245742470501;
                                    } else {
                                        return 0.00390510050382;
                                    }
                                } else {
                                    return 0.408584849988;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 41.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[62] <= -0.5) {
                                if (fs[62] <= -1.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.20001204684;
                                    } else {
                                        return 0.00746344030837;
                                    }
                                } else {
                                    if (fs[64] <= -994.5) {
                                        return 0.125111255562;
                                    } else {
                                        return -0.10843595532;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1133.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0180464808055;
                                    } else {
                                        return 0.301998019854;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.0600021453387;
                                    } else {
                                        return 0.316409358001;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 6.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 24.5) {
                                        return -0.0619291466531;
                                    } else {
                                        return 0.0896193462421;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0514720895814;
                                    } else {
                                        return -0.0164910392887;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.256812607208;
                                } else {
                                    return -0.0428013518005;
                                }
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            return -0.0262197741858;
                        } else {
                            if (fs[0] <= 57.0) {
                                if (fs[53] <= -1053.0) {
                                    return 0.505022679998;
                                } else {
                                    return -0.0646768746214;
                                }
                            } else {
                                return 0.342952618527;
                            }
                        }
                    }
                }
            } else {
                if (fs[47] <= -2396.0) {
                    if (fs[71] <= 0.5) {
                        if (fs[47] <= -6203.5) {
                            if (fs[4] <= 7.5) {
                                return -0.0915494318416;
                            } else {
                                return -0.0441876726683;
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                return -0.0231278506434;
                            } else {
                                return -0.0452633447571;
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[47] <= -7390.0) {
                                    return -0.0396977164698;
                                } else {
                                    if (fs[72] <= 9732.0) {
                                        return -0.0256092479573;
                                    } else {
                                        return -0.0168085810315;
                                    }
                                }
                            } else {
                                if (fs[53] <= -442.5) {
                                    return -0.0148417706744;
                                } else {
                                    if (fs[4] <= 6.0) {
                                        return -0.00817187909892;
                                    } else {
                                        return -0.0198730208246;
                                    }
                                }
                            }
                        } else {
                            return -0.0447774954078;
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[68] <= 1.5) {
                            if (fs[47] <= -29.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0625063130278;
                                    } else {
                                        return -0.0164140712518;
                                    }
                                } else {
                                    return 0.424811155826;
                                }
                            } else {
                                if (fs[47] <= -3.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.0432292189042;
                                    } else {
                                        return -0.0233244284613;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.00886672027097;
                                    } else {
                                        return -0.0154199289796;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    return -0.0555200524036;
                                } else {
                                    return -0.00322331016893;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.13872553031;
                                } else {
                                    return 0.219209281208;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 5.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[72] <= 9775.5) {
                                    if (fs[103] <= 1.5) {
                                        return -0.00817778773013;
                                    } else {
                                        return -0.00483172107305;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.0326588156136;
                                    } else {
                                        return -0.0114489781191;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.00351317276806;
                                    } else {
                                        return -0.00397432813741;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0113731271248;
                                    } else {
                                        return -0.00490392722995;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[49] <= -2.5) {
                                    if (fs[64] <= -995.5) {
                                        return -0.0436692042477;
                                    } else {
                                        return -0.0163520884635;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.00573649888574;
                                    } else {
                                        return -0.00352543742273;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[101] <= 1.5) {
                                        return -0.0055567809997;
                                    } else {
                                        return -0.00312648829693;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.00290014052317;
                                    } else {
                                        return -0.0018779370245;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
