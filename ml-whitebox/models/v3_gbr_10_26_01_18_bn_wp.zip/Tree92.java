/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree92 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 6.5) {
                if (fs[4] <= 9.5) {
                    if (fs[76] <= 350.0) {
                        if (fs[24] <= 0.5) {
                            if (fs[47] <= -0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0171155079906;
                                    } else {
                                        return 0.00419435934352;
                                    }
                                } else {
                                    if (fs[72] <= 9849.0) {
                                        return 0.146050522933;
                                    } else {
                                        return 0.0638067380254;
                                    }
                                }
                            } else {
                                if (fs[49] <= -0.5) {
                                    return 0.190070089293;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0870155016079;
                                    } else {
                                        return -0.0219747848777;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.14104103426;
                                    } else {
                                        return 0.0295044818299;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.0934581904538;
                                    } else {
                                        return 0.0779959365561;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0270691294233;
                                    } else {
                                        return 0.0717055027399;
                                    }
                                } else {
                                    return -0.107051723163;
                                }
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[53] <= -1133.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.210759757001;
                                    } else {
                                        return 0.134994419216;
                                    }
                                } else {
                                    return 0.0413292330775;
                                }
                            } else {
                                return -0.152443368539;
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -1133.5) {
                                        return 0.152670664109;
                                    } else {
                                        return 0.113864516073;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.205509452697;
                                    } else {
                                        return 0.124544767527;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return 0.26959858787;
                                } else {
                                    return 0.178937185048;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -854.5) {
                        if (fs[53] <= -1283.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[53] <= -1478.0) {
                                    if (fs[99] <= 0.5) {
                                        return 0.12658241438;
                                    } else {
                                        return 0.305275909401;
                                    }
                                } else {
                                    if (fs[72] <= 9912.0) {
                                        return 0.461506173966;
                                    } else {
                                        return 0.235038683877;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.0964807752419;
                                    } else {
                                        return 0.262617900895;
                                    }
                                } else {
                                    if (fs[47] <= -4311.5) {
                                        return 0.157574057406;
                                    } else {
                                        return -0.0867892164379;
                                    }
                                }
                            }
                        } else {
                            return -0.164058328022;
                        }
                    } else {
                        if (fs[53] <= -1493.5) {
                            if (fs[70] <= -1.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[64] <= -996.5) {
                                        return -0.213074340709;
                                    } else {
                                        return 0.0382778517568;
                                    }
                                } else {
                                    if (fs[64] <= -497.0) {
                                        return 0.215419313016;
                                    } else {
                                        return 0.0667400684541;
                                    }
                                }
                            } else {
                                if (fs[76] <= 100.0) {
                                    if (fs[78] <= 0.5) {
                                        return -0.214186951495;
                                    } else {
                                        return -0.130359108601;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.00709929787547;
                                    } else {
                                        return -0.305590927913;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -528.0) {
                                if (fs[70] <= -4.0) {
                                    return 0.170609419367;
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.437424195919;
                                    } else {
                                        return -0.232046469363;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0373902741287;
                                    } else {
                                        return 0.0710933570289;
                                    }
                                } else {
                                    if (fs[47] <= -6.5) {
                                        return 0.0376136584666;
                                    } else {
                                        return -0.00786906025119;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 10.5) {
                    if (fs[47] <= -119.5) {
                        if (fs[4] <= 15.5) {
                            if (fs[72] <= 9885.5) {
                                if (fs[53] <= -1448.0) {
                                    if (fs[88] <= 3.0) {
                                        return 0.139852355454;
                                    } else {
                                        return 0.0731882672791;
                                    }
                                } else {
                                    return 0.0461891195401;
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    return 0.00111113295038;
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.0371348495286;
                                    } else {
                                        return 0.114784848889;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -280.5) {
                                return 0.0937944417947;
                            } else {
                                return 0.255505784615;
                            }
                        }
                    } else {
                        if (fs[47] <= -5.5) {
                            if (fs[53] <= -987.5) {
                                if (fs[72] <= 4229.0) {
                                    if (fs[4] <= 16.5) {
                                        return 0.0822571810982;
                                    } else {
                                        return -0.0639014105592;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return -0.177779326506;
                                    } else {
                                        return -0.0152278179488;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[47] <= -18.5) {
                                        return -0.265321475828;
                                    } else {
                                        return -0.0157002671729;
                                    }
                                } else {
                                    return -0.346054793165;
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                if (fs[4] <= 36.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.00354663936089;
                                    } else {
                                        return 0.0443041313286;
                                    }
                                } else {
                                    return -0.183536689764;
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0992991696997;
                                    } else {
                                        return 0.0237754544106;
                                    }
                                } else {
                                    if (fs[53] <= -526.5) {
                                        return 0.0368998451071;
                                    } else {
                                        return -0.113954927734;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[105] <= 0.5) {
                        if (fs[47] <= -67.0) {
                            if (fs[99] <= 0.5) {
                                return 0.170011440815;
                            } else {
                                return 0.11477375897;
                            }
                        } else {
                            if (fs[94] <= 0.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0263328406367;
                                    } else {
                                        return 0.106942741853;
                                    }
                                } else {
                                    if (fs[47] <= -10.5) {
                                        return -0.122109803584;
                                    } else {
                                        return 0.084523069032;
                                    }
                                }
                            } else {
                                return 0.239565861861;
                            }
                        }
                    } else {
                        if (fs[22] <= 0.5) {
                            return 0.0907851395315;
                        } else {
                            if (fs[72] <= 9498.0) {
                                return 0.248524493424;
                            } else {
                                return 0.121410860332;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[30] <= 0.5) {
                if (fs[55] <= 0.5) {
                    if (fs[64] <= -997.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[47] <= -41.5) {
                                return 0.297122824679;
                            } else {
                                if (fs[53] <= -992.0) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0679830069464;
                                    } else {
                                        return 0.208628398505;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0335505428156;
                                    } else {
                                        return -0.0291480900823;
                                    }
                                }
                            }
                        } else {
                            if (fs[28] <= 0.5) {
                                if (fs[53] <= -1108.0) {
                                    if (fs[101] <= 0.5) {
                                        return 0.00545102370593;
                                    } else {
                                        return 0.212389989263;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0152747270492;
                                    } else {
                                        return -0.0075652976689;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0944468271636;
                                    } else {
                                        return -0.0426801739623;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.000915779626298;
                                    } else {
                                        return -0.0492766337397;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[14] <= 0.5) {
                            if (fs[76] <= 250.0) {
                                if (fs[18] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.000868551874757;
                                    } else {
                                        return 0.00555585854497;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.000233439192453;
                                    } else {
                                        return 0.00955449253009;
                                    }
                                }
                            } else {
                                if (fs[53] <= -2938.0) {
                                    if (fs[4] <= 21.5) {
                                        return 0.0727952708143;
                                    } else {
                                        return 0.370555778401;
                                    }
                                } else {
                                    if (fs[53] <= -1133.5) {
                                        return -0.00886155950599;
                                    } else {
                                        return -0.000769247522378;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[47] <= -86.5) {
                                    return 0.350746885289;
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.00806131923721;
                                    } else {
                                        return 0.0875119734256;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9994.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0736735131628;
                                    } else {
                                        return 0.00190607307133;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0164269202138;
                                    } else {
                                        return -0.0740742236598;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9989.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[0] <= 5.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.242545134692;
                                    } else {
                                        return 0.0505166786308;
                                    }
                                } else {
                                    return 0.293633951189;
                                }
                            } else {
                                if (fs[0] <= 15.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0279402602952;
                                    } else {
                                        return -0.0191300712366;
                                    }
                                } else {
                                    return 0.00622763152232;
                                }
                            }
                        } else {
                            if (fs[4] <= 19.5) {
                                return -0.0741811721523;
                            } else {
                                return -0.00926011045842;
                            }
                        }
                    } else {
                        if (fs[72] <= 9999.5) {
                            return 0.271575015651;
                        } else {
                            return 0.123259712923;
                        }
                    }
                }
            } else {
                if (fs[4] <= 5.5) {
                    return 0.055977283735;
                } else {
                    if (fs[2] <= 1.5) {
                        return 0.119694176444;
                    } else {
                        return 0.110622940337;
                    }
                }
            }
        }
    }
}
