/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree68 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[0] <= 1.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[33] <= 0.5) {
                            if (fs[27] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.0074572776591;
                                    } else {
                                        return 0.0426245354938;
                                    }
                                } else {
                                    return -0.15520960015;
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    return 0.126540261505;
                                } else {
                                    return 0.237025006432;
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                return -0.0789153716935;
                            } else {
                                return -0.00864322774843;
                            }
                        }
                    } else {
                        if (fs[33] <= 0.5) {
                            if (fs[4] <= 2.5) {
                                return 0.0640644301454;
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[72] <= 9989.5) {
                                        return 0.031720649969;
                                    } else {
                                        return 0.0767444645905;
                                    }
                                } else {
                                    return -0.0892116250363;
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.00534972244969;
                                    } else {
                                        return -0.0877853787626;
                                    }
                                } else {
                                    return 0.00025325548772;
                                }
                            } else {
                                return -0.16893322312;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 2.5) {
                        if (fs[0] <= 5.5) {
                            if (fs[0] <= 2.5) {
                                return 0.109799645297;
                            } else {
                                return 0.17982562733;
                            }
                        } else {
                            if (fs[0] <= 7.5) {
                                return -0.0770918724323;
                            } else {
                                if (fs[0] <= 13.5) {
                                    return 0.23644435933;
                                } else {
                                    return 0.0417869501622;
                                }
                            }
                        }
                    } else {
                        if (fs[60] <= 0.5) {
                            if (fs[53] <= -1053.0) {
                                if (fs[4] <= 4.5) {
                                    return -0.144041417233;
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.0658661650595;
                                    } else {
                                        return 0.303227837935;
                                    }
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0602383817492;
                                    } else {
                                        return -0.0990889510673;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0434334944825;
                                    } else {
                                        return 0.0371690090757;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0242944406809;
                                    } else {
                                        return 0.0469846701948;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00433820657112;
                                    } else {
                                        return 0.0175121522443;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -1058.0) {
                                        return 0.409833719716;
                                    } else {
                                        return -0.0544543587862;
                                    }
                                } else {
                                    return 0.171779928555;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[33] <= 0.5) {
                    if (fs[4] <= 10.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0104987824882;
                                    } else {
                                        return -0.012173591365;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.107738526272;
                                    } else {
                                        return -0.0276510311736;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1033.0) {
                                    if (fs[2] <= 5.5) {
                                        return 0.0385272505522;
                                    } else {
                                        return 0.022290787932;
                                    }
                                } else {
                                    return -0.0378076373984;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[2] <= 1.5) {
                                    return -0.112472320692;
                                } else {
                                    return -0.113695222998;
                                }
                            } else {
                                return 0.0610283980581;
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    return -0.131038283528;
                                } else {
                                    if (fs[103] <= 1.0) {
                                        return -0.0130294044408;
                                    } else {
                                        return -0.0312466979659;
                                    }
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.00421392732737;
                                    } else {
                                        return -0.00872715854167;
                                    }
                                } else {
                                    return 0.023389527118;
                                }
                            }
                        } else {
                            if (fs[72] <= 9745.0) {
                                if (fs[72] <= 4847.0) {
                                    if (fs[0] <= 6.5) {
                                        return -0.00743262203008;
                                    } else {
                                        return -0.00135661817317;
                                    }
                                } else {
                                    return 0.142961049419;
                                }
                            } else {
                                return -0.134360880747;
                            }
                        }
                    }
                } else {
                    return -0.0556882069086;
                }
            }
        } else {
            if (fs[72] <= 9996.5) {
                if (fs[0] <= 0.5) {
                    if (fs[90] <= 0.5) {
                        if (fs[47] <= -3.5) {
                            if (fs[24] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0515262011237;
                                    } else {
                                        return -0.0127864031163;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.0561487702807;
                                    } else {
                                        return 0.387381212949;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[72] <= 9979.5) {
                                        return 0.115908528786;
                                    } else {
                                        return 0.0705317819968;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.190296557993;
                                    } else {
                                        return 0.283164946385;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.0184913309786;
                                    } else {
                                        return -0.0495015156738;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return -0.061054513793;
                                    } else {
                                        return 0.15231806147;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[2] <= 8.5) {
                                        return 0.0110580085415;
                                    } else {
                                        return 0.0935676768088;
                                    }
                                } else {
                                    if (fs[101] <= 1.0) {
                                        return 0.222459730078;
                                    } else {
                                        return 0.0796033453705;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9994.5) {
                            if (fs[83] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[53] <= -1128.5) {
                                        return 0.0265729788098;
                                    } else {
                                        return 0.0536276975086;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0392960013265;
                                    } else {
                                        return 0.110524371473;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    return 0.134322729305;
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0952552536906;
                                    } else {
                                        return 0.0588597233189;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.0479333229677;
                                    } else {
                                        return -0.283296899733;
                                    }
                                } else {
                                    return 0.182929539644;
                                }
                            } else {
                                if (fs[47] <= -6.5) {
                                    if (fs[47] <= -11.0) {
                                        return -0.108687381448;
                                    } else {
                                        return 0.286482025408;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.194692778193;
                                    } else {
                                        return -0.368623485016;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[90] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.00426793808577;
                                    } else {
                                        return -0.015711038571;
                                    }
                                } else {
                                    if (fs[53] <= -1468.0) {
                                        return 0.0993605133937;
                                    } else {
                                        return 0.0211647765637;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.0220090764377;
                                    } else {
                                        return -0.00461104760743;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0942687394437;
                                    } else {
                                        return 0.0197392740324;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[18] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.00605135771152;
                                    } else {
                                        return -0.00222375278554;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.0392774597588;
                                    } else {
                                        return -0.000952087640955;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00574581757256;
                                    } else {
                                        return 0.000828006478309;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.00459877710811;
                                    } else {
                                        return 0.12254225389;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9703.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[72] <= 4346.0) {
                                    if (fs[2] <= 11.5) {
                                        return -0.0112147527024;
                                    } else {
                                        return 0.0700218304218;
                                    }
                                } else {
                                    return 0.161476892754;
                                }
                            } else {
                                if (fs[47] <= -11.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00639279266042;
                                    } else {
                                        return -0.0140897695971;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.00438941311005;
                                    } else {
                                        return -0.00218376516005;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[77] <= 0.5) {
                                        return -0.0728463325381;
                                    } else {
                                        return -0.0637745809351;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.0528363141968;
                                    } else {
                                        return -0.0365695062546;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0231337901209;
                                    } else {
                                        return -0.0149320576431;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.00604043595274;
                                    } else {
                                        return -0.0198683813201;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 4.5) {
                    if (fs[72] <= 9999.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[47] <= -3.0) {
                                    return 0.141318476328;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.014587590479;
                                    } else {
                                        return -0.112967056697;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1468.5) {
                                    return -0.10529499382;
                                } else {
                                    if (fs[53] <= -1048.5) {
                                        return 0.200456869839;
                                    } else {
                                        return 0.0305962145463;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 250.0) {
                                if (fs[0] <= 20.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.0529752805096;
                                    } else {
                                        return 0.15422470763;
                                    }
                                } else {
                                    if (fs[0] <= 41.0) {
                                        return -0.00532693346071;
                                    } else {
                                        return -0.111891445576;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    return -0.00336407287593;
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0940240883851;
                                    } else {
                                        return 0.0110508910391;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[28] <= 0.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.0237424060745;
                                    } else {
                                        return 0.218835092706;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.105365805036;
                                    } else {
                                        return 0.0694787391116;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    return 0.148311770688;
                                } else {
                                    if (fs[47] <= -6.0) {
                                        return 0.174358843485;
                                    } else {
                                        return -0.0628682523968;
                                    }
                                }
                            }
                        } else {
                            return -0.31114312526;
                        }
                    }
                } else {
                    if (fs[2] <= 4.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[53] <= -1052.5) {
                                    if (fs[4] <= 30.5) {
                                        return 0.0363818600534;
                                    } else {
                                        return -0.0934203165595;
                                    }
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return -0.034281799849;
                                    } else {
                                        return -0.0013617768023;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0243330784779;
                                    } else {
                                        return 0.121876367913;
                                    }
                                } else {
                                    if (fs[13] <= 0.5) {
                                        return -0.0209389397572;
                                    } else {
                                        return -0.17301081791;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0582679184122;
                                    } else {
                                        return -0.180832140795;
                                    }
                                } else {
                                    return 0.35025430736;
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0113365011997;
                                    } else {
                                        return 0.0539961383898;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.126681305567;
                                    } else {
                                        return -0.024343038418;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[90] <= 0.5) {
                            if (fs[76] <= 150.0) {
                                if (fs[29] <= 0.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.0495277392759;
                                    } else {
                                        return 0.127393575647;
                                    }
                                } else {
                                    return -0.236311486237;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.288942526965;
                                    } else {
                                        return 0.146232819891;
                                    }
                                } else {
                                    return -0.00572991012691;
                                }
                            }
                        } else {
                            if (fs[63] <= 0.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.0313151528988;
                                    } else {
                                        return -0.0622769477207;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.0365610457515;
                                    } else {
                                        return 0.170888193193;
                                    }
                                }
                            } else {
                                return -0.407774270571;
                            }
                        }
                    }
                }
            }
        }
    }
}
