/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree94 {
    public double calcTree(double... fs) {
        if (fs[64] <= -996.5) {
            if (fs[53] <= -1098.5) {
                if (fs[97] <= 0.5) {
                    if (fs[49] <= -1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                return -0.0295333477332;
                            } else {
                                if (fs[4] <= 11.5) {
                                    return 0.0300719318908;
                                } else {
                                    return 0.266423396744;
                                }
                            }
                        } else {
                            return 0.477822986241;
                        }
                    } else {
                        if (fs[4] <= 22.5) {
                            if (fs[8] <= 0.5) {
                                if (fs[53] <= -1953.0) {
                                    return -0.123278608513;
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return 0.0758079590274;
                                    } else {
                                        return -0.0733287506488;
                                    }
                                }
                            } else {
                                return -0.071468070343;
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                return -0.159764279773;
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[4] <= 30.5) {
                                        return -0.0128952374661;
                                    } else {
                                        return 0.0258262321842;
                                    }
                                } else {
                                    return -0.0313913133596;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9995.5) {
                        if (fs[58] <= 0.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    return -0.206051752188;
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.0159227679795;
                                    } else {
                                        return 0.040036382094;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[76] <= 250.0) {
                                        return -0.0194152457181;
                                    } else {
                                        return 0.07475781391;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.180455559268;
                                    } else {
                                        return 0.0492782338438;
                                    }
                                }
                            }
                        } else {
                            if (fs[103] <= 1.5) {
                                return -0.215312827569;
                            } else {
                                if (fs[78] <= 0.5) {
                                    return -0.154242192324;
                                } else {
                                    if (fs[62] <= -2.5) {
                                        return -0.148945160961;
                                    } else {
                                        return 0.0339299253029;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1318.0) {
                            return -0.286750872144;
                        } else {
                            if (fs[53] <= -1138.5) {
                                if (fs[64] <= -997.5) {
                                    return 0.0453204294586;
                                } else {
                                    return -0.157807947595;
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    return 0.145038269633;
                                } else {
                                    return 0.200645804622;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[78] <= 0.5) {
                        if (fs[76] <= 100.0) {
                            if (fs[47] <= -1.5) {
                                return -0.266795694746;
                            } else {
                                return -0.136829730479;
                            }
                        } else {
                            return -0.0681663759644;
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.106568457872;
                                    } else {
                                        return 0.0708310024627;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.37266337123;
                                    } else {
                                        return 0.0574750183466;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    return 0.172044747153;
                                } else {
                                    return 0.11769830613;
                                }
                            }
                        } else {
                            if (fs[47] <= -7.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.0351346044505;
                                    } else {
                                        return -0.0518812734822;
                                    }
                                } else {
                                    return -0.221278991241;
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    if (fs[49] <= -1.5) {
                                        return 0.0365332460631;
                                    } else {
                                        return 0.152991112882;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.0326015331929;
                                    } else {
                                        return 0.111408761763;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 7.5) {
                        if (fs[101] <= 1.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0790774209408;
                                    } else {
                                        return -0.0479466912924;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.242561174657;
                                    } else {
                                        return 0.00305712597469;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0846826817707;
                                    } else {
                                        return -0.0296638798282;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0375107759592;
                                    } else {
                                        return 0.227448440782;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -5.5) {
                                return 0.0459212572077;
                            } else {
                                if (fs[76] <= 100.0) {
                                    if (fs[47] <= -1.5) {
                                        return -0.026217223241;
                                    } else {
                                        return -0.0767292874216;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00064610800724;
                                    } else {
                                        return -0.0425079954227;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[72] <= 9995.5) {
                                if (fs[62] <= -1.5) {
                                    if (fs[49] <= -1.5) {
                                        return -0.00978399829458;
                                    } else {
                                        return 0.172053177477;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0529097303116;
                                    } else {
                                        return -0.0174773548796;
                                    }
                                }
                            } else {
                                return 0.147319986441;
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[47] <= -39.5) {
                                    return -0.0681037892593;
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0129704798657;
                                    } else {
                                        return -0.00439037360949;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.00342496272488;
                                    } else {
                                        return -0.0131565022117;
                                    }
                                } else {
                                    return 0.178340422502;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[72] <= 9985.5) {
                if (fs[57] <= 0.5) {
                    if (fs[2] <= 6.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0093343171766;
                                    } else {
                                        return -0.0555929632129;
                                    }
                                } else {
                                    if (fs[53] <= -1108.0) {
                                        return 0.00201075106451;
                                    } else {
                                        return -0.00723229925223;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.019362164413;
                                    } else {
                                        return 0.0205025951833;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.000932069110545;
                                    } else {
                                        return 0.000549404914602;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -1073.0) {
                                        return 0.0217288955517;
                                    } else {
                                        return -0.00257115463938;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.00116592298475;
                                    } else {
                                        return 0.00777383113207;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1393.0) {
                                    if (fs[48] <= 0.5) {
                                        return 0.00996103664449;
                                    } else {
                                        return 0.0766920272647;
                                    }
                                } else {
                                    if (fs[72] <= 9904.0) {
                                        return -0.00695930307545;
                                    } else {
                                        return -0.04311218819;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[8] <= 0.5) {
                                if (fs[2] <= 10.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0214708354875;
                                    } else {
                                        return 0.0458243668375;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.134379683221;
                                    } else {
                                        return 0.0371862646987;
                                    }
                                }
                            } else {
                                return -0.33698788281;
                            }
                        } else {
                            if (fs[72] <= 8689.0) {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 8.5) {
                                        return -0.01775443768;
                                    } else {
                                        return 0.000358232392082;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0557050938295;
                                    } else {
                                        return 0.010515109311;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[47] <= -59.0) {
                                        return 0.318787246886;
                                    } else {
                                        return 0.0631401141667;
                                    }
                                } else {
                                    if (fs[53] <= -486.5) {
                                        return -0.0301528243108;
                                    } else {
                                        return 0.143379053796;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[47] <= -5.0) {
                            return -0.0856376196481;
                        } else {
                            if (fs[64] <= -994.5) {
                                if (fs[4] <= 18.5) {
                                    return -0.112543491244;
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.0914497800192;
                                    } else {
                                        return -0.0470396687717;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.142204584982;
                                    } else {
                                        return 0.064626371303;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.00293377130597;
                                    } else {
                                        return 0.148398676259;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 7.5) {
                            if (fs[48] <= 0.5) {
                                if (fs[0] <= 5.5) {
                                    return 0.142654630948;
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.0343541319734;
                                    } else {
                                        return 0.0341305011279;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0993503979346;
                                    } else {
                                        return -0.038567165083;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0178601814519;
                                    } else {
                                        return 0.0508914127975;
                                    }
                                }
                            }
                        } else {
                            return 0.347263193461;
                        }
                    }
                }
            } else {
                if (fs[18] <= -0.5) {
                    if (fs[53] <= -1307.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[72] <= 9998.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 10.0) {
                                        return -0.246207787206;
                                    } else {
                                        return -0.178365026402;
                                    }
                                } else {
                                    return -0.0854096367994;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.144587695092;
                                } else {
                                    return -0.0780421907585;
                                }
                            }
                        } else {
                            return -0.224697128803;
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[0] <= 12.5) {
                                return -0.0104679516112;
                            } else {
                                return 0.000258572738355;
                            }
                        } else {
                            return -0.0217881183732;
                        }
                    }
                } else {
                    if (fs[4] <= 4.5) {
                        if (fs[28] <= 0.5) {
                            if (fs[55] <= 499.5) {
                                if (fs[0] <= 10.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.0276881835489;
                                    } else {
                                        return 0.0809700689283;
                                    }
                                } else {
                                    if (fs[0] <= 39.5) {
                                        return 0.00022469352305;
                                    } else {
                                        return -0.0734346854199;
                                    }
                                }
                            } else {
                                return -0.247293540851;
                            }
                        } else {
                            if (fs[53] <= -1453.0) {
                                return -0.40527015918;
                            } else {
                                return 0.107886183163;
                            }
                        }
                    } else {
                        if (fs[53] <= -1403.5) {
                            if (fs[53] <= -1488.0) {
                                if (fs[6] <= 0.5) {
                                    if (fs[76] <= 250.0) {
                                        return -0.0772934385519;
                                    } else {
                                        return -0.369575727267;
                                    }
                                } else {
                                    if (fs[4] <= 34.5) {
                                        return 0.00722187676808;
                                    } else {
                                        return -0.116828377465;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[47] <= -12947.5) {
                                        return -0.27119922464;
                                    } else {
                                        return 0.0671044664996;
                                    }
                                } else {
                                    if (fs[88] <= 2.0) {
                                        return -0.308966305199;
                                    } else {
                                        return 0.0866066867982;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1137.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.00497908093866;
                                    } else {
                                        return 0.150411383786;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0804461131453;
                                    } else {
                                        return 0.169518597723;
                                    }
                                }
                            } else {
                                if (fs[47] <= -2300.0) {
                                    if (fs[47] <= -2477.5) {
                                        return 0.0628853766081;
                                    } else {
                                        return 0.530358513731;
                                    }
                                } else {
                                    if (fs[53] <= -1052.5) {
                                        return 0.0514159041768;
                                    } else {
                                        return -0.00291813638569;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
