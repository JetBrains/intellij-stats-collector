/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree16 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[53] <= -1043.5) {
                if (fs[53] <= -1143.5) {
                    if (fs[88] <= 6.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.327004615092;
                                    } else {
                                        return 0.0882098309187;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.261811926751;
                                    } else {
                                        return 0.144456063026;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1493.5) {
                                    return 0.037980780291;
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0552204223197;
                                    } else {
                                        return -0.069134919489;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[47] <= -9.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.368582695873;
                                    } else {
                                        return 0.480523548903;
                                    }
                                } else {
                                    if (fs[88] <= 1.5) {
                                        return -0.141264229306;
                                    } else {
                                        return 0.0597859409779;
                                    }
                                }
                            } else {
                                if (fs[88] <= 5.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.474781846924;
                                    } else {
                                        return 0.332955240784;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.298766920563;
                                    } else {
                                        return -0.0686246646206;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[72] <= 9404.0) {
                                if (fs[47] <= -0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.361004051475;
                                    } else {
                                        return 0.47873552126;
                                    }
                                } else {
                                    return 0.212532617303;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[72] <= 9989.0) {
                                        return 0.521206187669;
                                    } else {
                                        return 0.443402298065;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.427916987964;
                                    } else {
                                        return 0.246938200625;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.178608683523;
                                    } else {
                                        return -0.0186819507737;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.274490804207;
                                    } else {
                                        return 0.388362298411;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.176535728644;
                                    } else {
                                        return -0.167289988936;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.49305385417;
                                    } else {
                                        return 0.106898175965;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -1138.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.361874042909;
                                    } else {
                                        return 0.265462782319;
                                    }
                                } else {
                                    return -0.102879245646;
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.401911828419;
                                    } else {
                                        return 0.436268031209;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.393401025407;
                                    } else {
                                        return 0.215673334788;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.409919638998;
                                    } else {
                                        return 0.314374970476;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.359575478539;
                                    } else {
                                        return 0.225151137598;
                                    }
                                }
                            } else {
                                if (fs[88] <= 1.0) {
                                    if (fs[4] <= 5.5) {
                                        return 0.268672926099;
                                    } else {
                                        return 0.0906657927752;
                                    }
                                } else {
                                    return -0.234442706499;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.397545811378;
                                    } else {
                                        return 0.179505309707;
                                    }
                                } else {
                                    if (fs[47] <= -6.5) {
                                        return 0.340116746061;
                                    } else {
                                        return 0.198391331321;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.045690510945;
                                    } else {
                                        return 0.204057664586;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.111492815807;
                                    } else {
                                        return 0.342196657065;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[88] <= 2.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.29880795148;
                                    } else {
                                        return 0.385247010518;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.55059962489;
                                    } else {
                                        return 0.391673056968;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.333561610662;
                                } else {
                                    return -0.0563077962724;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 1.5) {
                    if (fs[64] <= -995.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[62] <= -1.5) {
                                return 0.464310768778;
                            } else {
                                if (fs[64] <= -998.5) {
                                    return 0.306861787073;
                                } else {
                                    return 0.0241232992533;
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.555834572637;
                                    } else {
                                        return 0.452075461444;
                                    }
                                } else {
                                    return 0.123237657863;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    return 0.102791872663;
                                } else {
                                    if (fs[72] <= 5000.0) {
                                        return 0.318603622345;
                                    } else {
                                        return 0.445370871697;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0702157998667;
                                    } else {
                                        return 0.361334591516;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.525952226968;
                                    } else {
                                        return 0.452141275912;
                                    }
                                }
                            } else {
                                if (fs[47] <= -17.5) {
                                    if (fs[88] <= 3.0) {
                                        return 0.381211553887;
                                    } else {
                                        return 0.252419415725;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.266889501134;
                                    } else {
                                        return 0.105761458198;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9998.5) {
                                if (fs[47] <= -6156.5) {
                                    return 0.636652827635;
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.00312287495913;
                                    } else {
                                        return 0.0895162434088;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.256768761995;
                                    } else {
                                        return -0.146033104682;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.08562149103;
                                    } else {
                                        return 0.543869031047;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 10.5) {
                        if (fs[53] <= -461.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[47] <= -1.5) {
                                    return 0.50661123279;
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.374239284458;
                                    } else {
                                        return 0.150231709671;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[48] <= 0.5) {
                                        return -0.0318747671799;
                                    } else {
                                        return -0.138875002158;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.253001601584;
                                    } else {
                                        return 0.401418037625;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.386604808774;
                                    } else {
                                        return 0.105020770028;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.365354802517;
                                    } else {
                                        return 0.450856701157;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.40741696858;
                                    } else {
                                        return 0.351400424588;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.228842535213;
                                    } else {
                                        return 0.345354811595;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[4] <= 15.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.268904351821;
                                    } else {
                                        return 0.398351767907;
                                    }
                                } else {
                                    if (fs[72] <= 9907.0) {
                                        return 0.1104001656;
                                    } else {
                                        return 0.34291185035;
                                    }
                                }
                            } else {
                                if (fs[64] <= -994.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.363552912037;
                                    } else {
                                        return 0.556132960013;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.0752607347058;
                                    } else {
                                        return 0.240919877528;
                                    }
                                }
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[49] <= -0.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.490297375417;
                                    } else {
                                        return 0.364928048896;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.272909934549;
                                    } else {
                                        return 0.384689648795;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0504559610946;
                                    } else {
                                        return -0.227333748902;
                                    }
                                } else {
                                    return 0.318548678046;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 2.5) {
                if (fs[88] <= 7.5) {
                    if (fs[45] <= 0.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.0670350886067;
                                    } else {
                                        return 0.100953126143;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0315065244365;
                                    } else {
                                        return 0.239076816821;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[72] <= 9726.0) {
                                        return -0.0045028857228;
                                    } else {
                                        return 0.038251262025;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0262063359745;
                                    } else {
                                        return 0.0752293116208;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9985.5) {
                                if (fs[88] <= 1.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.036009410642;
                                    } else {
                                        return 0.102717627903;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0297404644131;
                                    } else {
                                        return -0.0161589140219;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0794092868004;
                                    } else {
                                        return -0.0115758603629;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.233842958643;
                                    } else {
                                        return 0.118324682573;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -356.5) {
                            return 0.136548040011;
                        } else {
                            if (fs[62] <= -2.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -986.0) {
                                        return 0.0368347158875;
                                    } else {
                                        return -0.0366278589814;
                                    }
                                } else {
                                    return 0.112353830151;
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[72] <= 9998.5) {
                                        return -0.0352777223688;
                                    } else {
                                        return -0.0233288842914;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0271638954153;
                                    } else {
                                        return 0.173880049888;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[41] <= 0.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.0339818476128;
                                    } else {
                                        return 0.464340334944;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.457433241045;
                                    } else {
                                        return 0.162104467372;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0114031461084;
                                    } else {
                                        return -0.0593165467604;
                                    }
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return 0.00577572606962;
                                    } else {
                                        return 0.146475361267;
                                    }
                                }
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.00145023630876;
                                    } else {
                                        return 0.0814935321745;
                                    }
                                } else {
                                    return 0.278435637471;
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.128448383144;
                                    } else {
                                        return -0.0877335067367;
                                    }
                                } else {
                                    if (fs[72] <= 9578.5) {
                                        return -0.0360675570769;
                                    } else {
                                        return 0.0280985868912;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1298.0) {
                            if (fs[59] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.039151391777;
                                    } else {
                                        return 0.253944442901;
                                    }
                                } else {
                                    if (fs[72] <= 9955.0) {
                                        return 0.414884454047;
                                    } else {
                                        return 0.212204552785;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    return 0.134275802452;
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return 0.590241914227;
                                    } else {
                                        return -0.296328754846;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[72] <= 9968.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0236568685933;
                                    } else {
                                        return -0.10658908994;
                                    }
                                } else {
                                    return 0.0467369315329;
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.276196847913;
                                    } else {
                                        return -0.106936575059;
                                    }
                                } else {
                                    return -0.0453881185194;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 6.5) {
                    if (fs[12] <= 0.5) {
                        if (fs[47] <= -5.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[72] <= 9977.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0118990327846;
                                    } else {
                                        return 0.0118364464531;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return 0.0400553658248;
                                    } else {
                                        return 0.140513004512;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.128319962827;
                                    } else {
                                        return -0.0210478847024;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.223622857782;
                                    } else {
                                        return 0.00533327021947;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                if (fs[81] <= 0.5) {
                                    return 0.516475887509;
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -3.9523766427e-05;
                                    } else {
                                        return -0.0325412209995;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9978.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0181644038565;
                                    } else {
                                        return -0.0278241571826;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -8.80047307213e-05;
                                    } else {
                                        return 0.166174033657;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[53] <= -431.5) {
                                        return 0.000984266738682;
                                    } else {
                                        return 0.0132132386346;
                                    }
                                } else {
                                    if (fs[72] <= 9991.5) {
                                        return -0.0129161249557;
                                    } else {
                                        return 0.0809022420811;
                                    }
                                }
                            } else {
                                if (fs[49] <= -2.5) {
                                    return 0.0436521366238;
                                } else {
                                    if (fs[47] <= -10.5) {
                                        return -0.0138796500281;
                                    } else {
                                        return -0.0278263953468;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1062.5) {
                                return 0.346337554593;
                            } else {
                                return 0.131773997615;
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9998.5) {
                        if (fs[0] <= 12.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0161198824227;
                                    } else {
                                        return 0.0111976933744;
                                    }
                                } else {
                                    if (fs[72] <= 8694.5) {
                                        return -0.0230660294546;
                                    } else {
                                        return -0.0115008989659;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1041.0) {
                                    if (fs[94] <= 0.5) {
                                        return -0.0253000003486;
                                    } else {
                                        return 0.0439012503381;
                                    }
                                } else {
                                    if (fs[47] <= -11.5) {
                                        return -0.0306503757188;
                                    } else {
                                        return -0.027062442443;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0261050346088;
                                    } else {
                                        return -0.0109718750818;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0118746772321;
                                    } else {
                                        return -0.0244263633587;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[31] <= 0.5) {
                                        return 0.246580929288;
                                    } else {
                                        return -0.0295487629804;
                                    }
                                } else {
                                    if (fs[53] <= -976.0) {
                                        return -0.0278283380758;
                                    } else {
                                        return -0.0285373119525;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 75.0) {
                            if (fs[53] <= -1428.0) {
                                if (fs[88] <= 0.5) {
                                    if (fs[0] <= 18.0) {
                                        return 0.387217693561;
                                    } else {
                                        return 0.181233851991;
                                    }
                                } else {
                                    return 0.0321490963972;
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0169018228837;
                                    } else {
                                        return 0.0817977962717;
                                    }
                                } else {
                                    if (fs[0] <= 12.5) {
                                        return -0.00658281458257;
                                    } else {
                                        return -0.0394202158975;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -94.5) {
                                if (fs[47] <= -97.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0410486127759;
                                    } else {
                                        return 0.212401797907;
                                    }
                                } else {
                                    return 0.514205205442;
                                }
                            } else {
                                if (fs[53] <= -1082.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0334605584482;
                                    } else {
                                        return 0.363943038031;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0579640979385;
                                    } else {
                                        return -0.0290010845745;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
