/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree6 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[81] <= 0.5) {
                if (fs[4] <= 19.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.553943777942;
                                    } else {
                                        return 0.620526217958;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.44429578384;
                                    } else {
                                        return 0.660615039517;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.28836713993;
                                    } else {
                                        return 0.460815002964;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.757570641195;
                                    } else {
                                        return 0.605860161716;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 4984.0) {
                                if (fs[60] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.718991648729;
                                    } else {
                                        return 0.587253501078;
                                    }
                                } else {
                                    if (fs[53] <= -1033.5) {
                                        return 0.681883648754;
                                    } else {
                                        return 0.457982178072;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    return 0.563183947175;
                                } else {
                                    return 0.128741529453;
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.672976824501;
                                    } else {
                                        return 0.686544085622;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.697257709122;
                                    } else {
                                        return 0.69777575012;
                                    }
                                }
                            } else {
                                return 0.446800091001;
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    return 0.687610485476;
                                } else {
                                    return 0.634184538931;
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.109474419003;
                                    } else {
                                        return 0.604609284416;
                                    }
                                } else {
                                    return 0.0488302823977;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[78] <= 0.5) {
                        return 0.232623172719;
                    } else {
                        if (fs[53] <= -1313.0) {
                            if (fs[4] <= 40.5) {
                                if (fs[4] <= 35.0) {
                                    if (fs[4] <= 22.5) {
                                        return 0.0445058590007;
                                    } else {
                                        return -0.0737957866247;
                                    }
                                } else {
                                    return 0.217534363838;
                                }
                            } else {
                                if (fs[53] <= -1568.0) {
                                    return -0.07597723464;
                                } else {
                                    return -0.14339773114;
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                return 0.235536409854;
                            } else {
                                return -0.0447221706028;
                            }
                        }
                    }
                }
            } else {
                if (fs[97] <= 0.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.619877853579;
                                    } else {
                                        return 0.269969982885;
                                    }
                                } else {
                                    if (fs[72] <= 9896.0) {
                                        return -0.042810913896;
                                    } else {
                                        return 0.182284560585;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[92] <= 0.5) {
                                        return 0.630526563027;
                                    } else {
                                        return 0.535957007652;
                                    }
                                } else {
                                    if (fs[64] <= -995.5) {
                                        return 0.591221889591;
                                    } else {
                                        return 0.387879022633;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9844.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.230122251688;
                                    } else {
                                        return 0.405061000182;
                                    }
                                } else {
                                    if (fs[53] <= -1548.0) {
                                        return 0.42788129807;
                                    } else {
                                        return 0.0633225502745;
                                    }
                                }
                            } else {
                                if (fs[47] <= -6.5) {
                                    if (fs[53] <= -988.0) {
                                        return 0.480822101847;
                                    } else {
                                        return 0.348327442586;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.263432663475;
                                    } else {
                                        return 0.469174243548;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[89] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[88] <= 5.5) {
                                        return 0.52135936456;
                                    } else {
                                        return 0.654716387878;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.341751826943;
                                    } else {
                                        return 0.446529483308;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.527804601277;
                                    } else {
                                        return 0.196192570615;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.455070769533;
                                    } else {
                                        return 0.673515766443;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[22] <= 0.5) {
                                        return 0.237171313119;
                                    } else {
                                        return 0.0222340489479;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return 0.246671660568;
                                    } else {
                                        return 0.58056365898;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.454273634124;
                                    } else {
                                        return 0.696250693186;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.172839720609;
                                    } else {
                                        return 0.49941098943;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 9.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.542251875732;
                                    } else {
                                        return 0.239283562627;
                                    }
                                } else {
                                    if (fs[53] <= -977.5) {
                                        return 0.643099611853;
                                    } else {
                                        return 0.422148510054;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[72] <= 4995.0) {
                                        return 0.511763716572;
                                    } else {
                                        return 0.211700694074;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.157429861867;
                                    } else {
                                        return 0.487173909305;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.67286085321;
                                    } else {
                                        return 0.644245739594;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.644261498962;
                                    } else {
                                        return 0.320601412671;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[72] <= 9990.5) {
                                        return 0.564931109376;
                                    } else {
                                        return 0.362791170308;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0680168857505;
                                    } else {
                                        return 0.280261498107;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[103] <= 1.5) {
                            if (fs[4] <= 27.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.29443744484;
                                    } else {
                                        return 0.491880436375;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.436757907619;
                                    } else {
                                        return 0.524416110764;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1958.0) {
                                    if (fs[4] <= 29.5) {
                                        return 0.683370539087;
                                    } else {
                                        return 0.771154651334;
                                    }
                                } else {
                                    if (fs[53] <= -1523.0) {
                                        return -0.0921487243878;
                                    } else {
                                        return 0.218234024279;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.626575267532;
                                    } else {
                                        return 0.205490746537;
                                    }
                                } else {
                                    if (fs[64] <= -497.5) {
                                        return 0.552554427119;
                                    } else {
                                        return 0.132436564917;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.547898125183;
                                    } else {
                                        return 0.607950134366;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.40002998961;
                                    } else {
                                        return 0.515305367022;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[45] <= 0.5) {
                    if (fs[88] <= 7.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[72] <= 9989.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.123154465707;
                                    } else {
                                        return 0.0539578865876;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.166120681558;
                                    } else {
                                        return 0.403947563196;
                                    }
                                }
                            } else {
                                if (fs[30] <= 0.5) {
                                    if (fs[88] <= -0.5) {
                                        return -0.046826819435;
                                    } else {
                                        return 0.0284454693337;
                                    }
                                } else {
                                    if (fs[4] <= 5.0) {
                                        return 0.684263760483;
                                    } else {
                                        return 0.630308272067;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.148920753786;
                                    } else {
                                        return 0.2993599021;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.163810305287;
                                    } else {
                                        return 0.0505113926099;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0995472605818;
                                    } else {
                                        return 0.192144341334;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.00316124140396;
                                    } else {
                                        return 0.085383747139;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[85] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[72] <= 9995.5) {
                                        return 0.0157608680308;
                                    } else {
                                        return 0.127865992601;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0401208751808;
                                    } else {
                                        return 0.0773816062204;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[4] <= 5.0) {
                                        return 0.108966338152;
                                    } else {
                                        return 0.22729856022;
                                    }
                                } else {
                                    return -0.0893870201351;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[47] <= -61.5) {
                                        return 0.332419487018;
                                    } else {
                                        return 0.0338234044608;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.665410096023;
                                    } else {
                                        return 0.273828438848;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.658509456435;
                                    } else {
                                        return -0.109732385328;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0297792798612;
                                    } else {
                                        return 0.278087121195;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[106] <= 0.5) {
                        if (fs[47] <= -356.5) {
                            return 0.335256996857;
                        } else {
                            if (fs[49] <= -2.5) {
                                if (fs[4] <= 18.0) {
                                    return -0.0617553129467;
                                } else {
                                    return 0.158542625097;
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[13] <= 0.5) {
                                        return -0.0425152306966;
                                    } else {
                                        return 0.0170593487307;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.344430499276;
                                    } else {
                                        return 0.0623194183046;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[50] <= 0.5) {
                            return -0.0606900023116;
                        } else {
                            if (fs[4] <= 15.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0494415112883;
                                    } else {
                                        return -0.060930270811;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0246125114235;
                                    } else {
                                        return -0.0590244421384;
                                    }
                                }
                            } else {
                                if (fs[53] <= -986.0) {
                                    if (fs[4] <= 19.5) {
                                        return -0.0606231750504;
                                    } else {
                                        return -0.0588215543911;
                                    }
                                } else {
                                    return -0.0590294167117;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 4.5) {
                    if (fs[45] <= 0.5) {
                        if (fs[72] <= 9877.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.0523826974063;
                                    } else {
                                        return -0.0375358947238;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.00666689968128;
                                    } else {
                                        return -0.0257104868712;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0278584962765;
                                    } else {
                                        return 0.0743212642525;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0108878738018;
                                    } else {
                                        return 0.0176126904107;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -3888.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0196398752287;
                                    } else {
                                        return 0.405543459035;
                                    }
                                } else {
                                    if (fs[72] <= 9995.5) {
                                        return 0.196628915201;
                                    } else {
                                        return 0.657056214086;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[53] <= -1048.5) {
                                        return 0.0543427781105;
                                    } else {
                                        return 0.0203405096321;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.046466219265;
                                    } else {
                                        return 0.208751888411;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[53] <= -991.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[47] <= -1.5) {
                                        return -0.0024869612213;
                                    } else {
                                        return -0.0397503991938;
                                    }
                                } else {
                                    if (fs[72] <= 9744.0) {
                                        return -0.0458724798629;
                                    } else {
                                        return -0.0577164466775;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1409.5) {
                                    return -0.0062190401271;
                                } else {
                                    if (fs[55] <= -1.5) {
                                        return -0.027668131109;
                                    } else {
                                        return -0.0448235608801;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -936.5) {
                                if (fs[47] <= -32.5) {
                                    return 0.0328568908804;
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.0372145858973;
                                    } else {
                                        return -0.0482332022668;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.0475428933822;
                                    } else {
                                        return 0.0388899759688;
                                    }
                                } else {
                                    return 0.110200955556;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9997.5) {
                        if (fs[72] <= 9830.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0426914148906;
                                    } else {
                                        return -0.0239142498462;
                                    }
                                } else {
                                    if (fs[47] <= -3848.5) {
                                        return 0.13574969758;
                                    } else {
                                        return -0.0374894677719;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 7.5) {
                                        return -0.0256608125556;
                                    } else {
                                        return -0.036972351718;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0430619594039;
                                    } else {
                                        return -0.0439619552632;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[53] <= -1418.0) {
                                    if (fs[47] <= -384.5) {
                                        return 0.17976903299;
                                    } else {
                                        return 0.0214080235114;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.00590696252646;
                                    } else {
                                        return -0.0298069270164;
                                    }
                                }
                            } else {
                                if (fs[2] <= 0.5) {
                                    return -0.015058143225;
                                } else {
                                    if (fs[53] <= -26.5) {
                                        return -0.0496240106077;
                                    } else {
                                        return -0.0465912765551;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.112981127996;
                                    } else {
                                        return 0.012914700537;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.483082676013;
                                    } else {
                                        return 0.117154503827;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1418.0) {
                                    if (fs[0] <= 18.0) {
                                        return 0.429041414575;
                                    } else {
                                        return 0.119812390746;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.00605260507149;
                                    } else {
                                        return 0.104192555139;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 16.5) {
                                if (fs[0] <= 69.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.00753409681446;
                                    } else {
                                        return -0.0461293097979;
                                    }
                                } else {
                                    return -0.0211792413786;
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0284020160621;
                                    } else {
                                        return 0.0621019251771;
                                    }
                                } else {
                                    if (fs[53] <= 13.5) {
                                        return -0.0456787476691;
                                    } else {
                                        return -0.0225645877035;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
