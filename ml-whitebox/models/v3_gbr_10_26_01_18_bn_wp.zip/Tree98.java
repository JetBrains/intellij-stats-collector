/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree98 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9999.5) {
            if (fs[11] <= 0.5) {
                if (fs[0] <= 1.5) {
                    if (fs[28] <= 0.5) {
                        if (fs[53] <= -1488.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[6] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0274960494381;
                                    } else {
                                        return -0.177874777977;
                                    }
                                } else {
                                    if (fs[53] <= -2718.5) {
                                        return -0.11556359026;
                                    } else {
                                        return 0.0846810717774;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0379687365882;
                                    } else {
                                        return -0.0486434240798;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.0241017787047;
                                    } else {
                                        return 0.0378573905932;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 22.5) {
                                if (fs[49] <= -3.5) {
                                    return -0.352933165553;
                                } else {
                                    if (fs[74] <= 0.5) {
                                        return 0.0125869800114;
                                    } else {
                                        return -0.0155741892399;
                                    }
                                }
                            } else {
                                if (fs[49] <= -1.5) {
                                    if (fs[4] <= 23.5) {
                                        return 0.260577692396;
                                    } else {
                                        return 0.0531022439771;
                                    }
                                } else {
                                    if (fs[47] <= -65.0) {
                                        return 0.316525637998;
                                    } else {
                                        return -0.0264932376395;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 1.5) {
                            if (fs[64] <= -998.5) {
                                return 0.271722228108;
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.142866070068;
                                    } else {
                                        return 0.064718535048;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.314705492416;
                                    } else {
                                        return -0.0772368191265;
                                    }
                                }
                            }
                        } else {
                            return 0.0485699870977;
                        }
                    }
                } else {
                    if (fs[47] <= -113.5) {
                        if (fs[4] <= 20.5) {
                            if (fs[72] <= 9994.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[72] <= 9945.5) {
                                        return -0.0222392238079;
                                    } else {
                                        return 0.0627993396891;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.039169044644;
                                    } else {
                                        return -0.0221883707293;
                                    }
                                }
                            } else {
                                if (fs[47] <= -192.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.162206677019;
                                    } else {
                                        return -0.0459969777195;
                                    }
                                } else {
                                    return 0.421354484166;
                                }
                            }
                        } else {
                            if (fs[53] <= -1458.0) {
                                if (fs[2] <= 3.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.27552965346;
                                    } else {
                                        return 0.0858661085681;
                                    }
                                } else {
                                    return 0.478489075927;
                                }
                            } else {
                                if (fs[47] <= -205.0) {
                                    return -0.0619299452718;
                                } else {
                                    return -0.0465991239112;
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[64] <= -998.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.232175983544;
                                    } else {
                                        return 0.0405514010676;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.000928670479369;
                                    } else {
                                        return 0.0172019096588;
                                    }
                                }
                            } else {
                                if (fs[67] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.00673804697965;
                                    } else {
                                        return -0.0026125899831;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return 0.0569485196334;
                                    } else {
                                        return -0.00407677851283;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 7.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0438762473586;
                                    } else {
                                        return -0.0716819770505;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0915300544413;
                                    } else {
                                        return -0.022129264636;
                                    }
                                }
                            } else {
                                return 0.315970541047;
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 6.5) {
                    if (fs[4] <= 3.5) {
                        if (fs[47] <= -561.5) {
                            if (fs[76] <= 200.0) {
                                if (fs[18] <= 0.5) {
                                    if (fs[53] <= -1048.5) {
                                        return 0.127772668567;
                                    } else {
                                        return -0.00938780762683;
                                    }
                                } else {
                                    if (fs[47] <= -746.5) {
                                        return 0.109980517811;
                                    } else {
                                        return 0.393786346206;
                                    }
                                }
                            } else {
                                return -0.0483150419405;
                            }
                        } else {
                            if (fs[85] <= 0.5) {
                                if (fs[88] <= 3.5) {
                                    if (fs[72] <= 9995.5) {
                                        return 0.00819205623342;
                                    } else {
                                        return -0.0625670073654;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.00613814476591;
                                    } else {
                                        return 0.0427699909095;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[0] <= 0.5) {
                                        return -0.0731955785302;
                                    } else {
                                        return -0.00648863739149;
                                    }
                                } else {
                                    if (fs[53] <= -1068.0) {
                                        return 0.0395957022347;
                                    } else {
                                        return -0.0137885058871;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[39] <= 0.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0138157912901;
                                    } else {
                                        return 0.00147957776249;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return -0.000411490304462;
                                    } else {
                                        return -0.00185508849468;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0492080468514;
                                    } else {
                                        return 0.085045686758;
                                    }
                                } else {
                                    if (fs[72] <= 9882.5) {
                                        return 0.000353867419522;
                                    } else {
                                        return -0.0434960595586;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                return 0.359484816514;
                            } else {
                                return -0.0357130692516;
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -356.0) {
                        if (fs[23] <= 0.5) {
                            if (fs[47] <= -654.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[47] <= -2524.0) {
                                        return -0.00107899088602;
                                    } else {
                                        return 0.0896768042112;
                                    }
                                } else {
                                    return 0.183761328497;
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[53] <= -1458.0) {
                                        return 0.322575058485;
                                    } else {
                                        return 0.0639638577124;
                                    }
                                } else {
                                    return 0.0581857155056;
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                return -0.036538602885;
                            } else {
                                if (fs[0] <= 3.5) {
                                    return 0.00963460319013;
                                } else {
                                    return -0.0137583013875;
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9997.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0537490960601;
                                    } else {
                                        return 0.0107617780765;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0491224196088;
                                    } else {
                                        return 4.44782145839e-05;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[72] <= 9954.0) {
                                        return 0.00557904690483;
                                    } else {
                                        return 0.290748063922;
                                    }
                                } else {
                                    if (fs[72] <= 9992.5) {
                                        return 0.000200791582812;
                                    } else {
                                        return -0.0461945494798;
                                    }
                                }
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[0] <= 0.5) {
                                        return -0.0140828437855;
                                    } else {
                                        return 0.110052219246;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.339516939653;
                                    } else {
                                        return 0.123179489688;
                                    }
                                }
                            } else {
                                return 0.367746352383;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[8] <= 0.5) {
                if (fs[84] <= 0.5) {
                    if (fs[41] <= 0.5) {
                        if (fs[4] <= 30.5) {
                            if (fs[66] <= 5.0) {
                                if (fs[4] <= 22.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.023010174707;
                                    } else {
                                        return 0.237265689249;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.124903443135;
                                    } else {
                                        return -0.029427234894;
                                    }
                                }
                            } else {
                                if (fs[88] <= 2.5) {
                                    return -0.187842837369;
                                } else {
                                    return -0.202249544856;
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    return -0.242857302657;
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.0654699330011;
                                    } else {
                                        return 0.121476612037;
                                    }
                                }
                            } else {
                                return -0.38131694177;
                            }
                        }
                    } else {
                        if (fs[53] <= -1473.5) {
                            if (fs[99] <= 0.5) {
                                return -0.270647042127;
                            } else {
                                return -0.24897098819;
                            }
                        } else {
                            return 0.0726002873356;
                        }
                    }
                } else {
                    if (fs[44] <= 0.5) {
                        if (fs[68] <= 1.5) {
                            if (fs[0] <= 32.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0232344322371;
                                    } else {
                                        return 0.00995915154669;
                                    }
                                } else {
                                    if (fs[88] <= 2.5) {
                                        return 0.0993831582702;
                                    } else {
                                        return 0.00727967065043;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    return -0.0492035936999;
                                } else {
                                    if (fs[53] <= 3.5) {
                                        return 0.315328813035;
                                    } else {
                                        return -0.0102289965137;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -511.5) {
                                return 0.406685518045;
                            } else {
                                if (fs[4] <= 8.5) {
                                    return 0.175755744546;
                                } else {
                                    return -0.0169418246355;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            return -0.391113164516;
                        } else {
                            if (fs[101] <= 1.0) {
                                return 0.159972809593;
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[4] <= 12.5) {
                                        return -0.28222695888;
                                    } else {
                                        return -0.206401958045;
                                    }
                                } else {
                                    return -0.132577104777;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 6.5) {
                    if (fs[53] <= -1138.0) {
                        return -0.0256373980406;
                    } else {
                        if (fs[2] <= 2.5) {
                            return -0.222820273818;
                        } else {
                            return -0.24668276269;
                        }
                    }
                } else {
                    return -0.302638640398;
                }
            }
        }
    }
}
