/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree45 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[53] <= -987.5) {
                if (fs[53] <= -1133.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[44] <= 0.5) {
                            if (fs[47] <= -263.0) {
                                if (fs[53] <= -1478.5) {
                                    if (fs[53] <= -1598.0) {
                                        return 0.262279364559;
                                    } else {
                                        return 0.0676867748248;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.156206983918;
                                    } else {
                                        return 0.271700265456;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[88] <= -0.5) {
                                        return -0.258574181224;
                                    } else {
                                        return 0.0588824940238;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.0260401344741;
                                    } else {
                                        return -0.0438569517321;
                                    }
                                }
                            }
                        } else {
                            if (fs[74] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[13] <= 0.5) {
                                        return 0.103394686768;
                                    } else {
                                        return -0.101483682024;
                                    }
                                } else {
                                    if (fs[72] <= 9490.0) {
                                        return 0.151982344759;
                                    } else {
                                        return 0.191905508754;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1294.0) {
                                    return -0.0179217152478;
                                } else {
                                    if (fs[72] <= 9991.5) {
                                        return -0.145247428029;
                                    } else {
                                        return -0.229458090016;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 18.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0771000842178;
                                    } else {
                                        return 0.0135154856857;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.10878792092;
                                    } else {
                                        return 0.0234161501998;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[47] <= -11.5) {
                                        return -0.418449649659;
                                    } else {
                                        return -0.0668805176267;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.280184443859;
                                    } else {
                                        return -0.178285538935;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1988.0) {
                                if (fs[4] <= 22.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.145219942984;
                                    } else {
                                        return -0.140753702673;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.247261088477;
                                    } else {
                                        return 0.105969930078;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1438.0) {
                                    if (fs[72] <= 9998.5) {
                                        return -0.0315746907351;
                                    } else {
                                        return 0.0909571112766;
                                    }
                                } else {
                                    if (fs[53] <= -1428.0) {
                                        return 0.311650990529;
                                    } else {
                                        return 0.0647802412622;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 21.5) {
                        if (fs[53] <= -1123.5) {
                            if (fs[72] <= 9970.0) {
                                if (fs[64] <= -996.5) {
                                    if (fs[27] <= 0.5) {
                                        return 0.22338032033;
                                    } else {
                                        return 0.118925500738;
                                    }
                                } else {
                                    if (fs[74] <= 0.5) {
                                        return 0.0987403276248;
                                    } else {
                                        return -0.0407664621532;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.142339020614;
                                    } else {
                                        return 0.186318901497;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.186922869547;
                                    } else {
                                        return -0.226319421738;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 0.5) {
                                if (fs[88] <= 2.5) {
                                    if (fs[76] <= 350.0) {
                                        return 0.12750717827;
                                    } else {
                                        return 0.307834592965;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.160502980079;
                                    } else {
                                        return 0.344193995544;
                                    }
                                }
                            } else {
                                return -0.0421907627164;
                            }
                        }
                    } else {
                        if (fs[47] <= -4.0) {
                            if (fs[23] <= 0.5) {
                                return 0.360328987444;
                            } else {
                                return 0.178203181955;
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                return 0.297528877475;
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0746072910224;
                                    } else {
                                        return 0.225845099355;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.221528215317;
                                    } else {
                                        return -0.0224479224131;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 9.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[47] <= -1.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.202177715384;
                                    } else {
                                        return -0.0523041469633;
                                    }
                                } else {
                                    if (fs[47] <= -6156.5) {
                                        return 0.25437067449;
                                    } else {
                                        return -0.0933755897594;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return -0.00151606086542;
                                    } else {
                                        return 0.139827342374;
                                    }
                                } else {
                                    if (fs[88] <= 3.0) {
                                        return 0.315249695231;
                                    } else {
                                        return 0.0153155337472;
                                    }
                                }
                            }
                        } else {
                            if (fs[101] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[88] <= 7.5) {
                                        return -0.00462963052982;
                                    } else {
                                        return 0.164620732861;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0486372121384;
                                    } else {
                                        return 0.0404133630995;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0578492390724;
                                    } else {
                                        return 0.224506862789;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.0775550965778;
                                    } else {
                                        return 0.35963862372;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -462.0) {
                            if (fs[85] <= 0.5) {
                                return 0.151388803074;
                            } else {
                                if (fs[71] <= 0.5) {
                                    return 0.110391478294;
                                } else {
                                    if (fs[47] <= -6.5) {
                                        return -0.336760400471;
                                    } else {
                                        return -0.118698006915;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[72] <= 4273.5) {
                                        return 0.226992169638;
                                    } else {
                                        return 0.151134202376;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.120513254853;
                                    } else {
                                        return -0.0468518392202;
                                    }
                                }
                            } else {
                                if (fs[88] <= -0.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0854406672401;
                                    } else {
                                        return -0.355820345931;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.0648484566296;
                                    } else {
                                        return 0.109135318008;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 4.5) {
                        if (fs[64] <= -994.5) {
                            if (fs[47] <= -4.5) {
                                if (fs[64] <= -997.5) {
                                    return 0.251865002054;
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return 0.115411974327;
                                    } else {
                                        return -0.194326582612;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.159041366517;
                                    } else {
                                        return 0.362111464619;
                                    }
                                } else {
                                    return -0.188531649482;
                                }
                            }
                        } else {
                            if (fs[70] <= -3.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0188797112451;
                                    } else {
                                        return 0.0839193918341;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.145877044098;
                                    } else {
                                        return 0.28430439957;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9817.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.0942184161368;
                                    } else {
                                        return 0.0527802411195;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.0278776159956;
                                    } else {
                                        return -0.045680499319;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -863.0) {
                            if (fs[53] <= -972.0) {
                                if (fs[90] <= 0.5) {
                                    return 0.0770661378223;
                                } else {
                                    return 0.177191473007;
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    return -0.177131052749;
                                } else {
                                    return -0.440622991573;
                                }
                            }
                        } else {
                            if (fs[47] <= -18.5) {
                                if (fs[72] <= 9996.5) {
                                    if (fs[47] <= -29.0) {
                                        return 0.169277535833;
                                    } else {
                                        return -0.394081209425;
                                    }
                                } else {
                                    return -0.245339816731;
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[88] <= 7.5) {
                                        return 0.0817873514424;
                                    } else {
                                        return 0.240397406496;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.103093226903;
                                    } else {
                                        return 0.2298542374;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[41] <= 0.5) {
                    if (fs[105] <= 0.5) {
                        if (fs[4] <= 23.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return 0.0191642948936;
                                    } else {
                                        return 0.153167563653;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0986000323488;
                                    } else {
                                        return 0.491104949948;
                                    }
                                }
                            } else {
                                if (fs[2] <= 8.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0202436536591;
                                    } else {
                                        return 0.142233994836;
                                    }
                                } else {
                                    return 0.139404221728;
                                }
                            }
                        } else {
                            if (fs[47] <= -49.0) {
                                if (fs[47] <= -69.5) {
                                    return -0.0212005588072;
                                } else {
                                    return 0.245441787242;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[47] <= -2.5) {
                                        return -0.067362867209;
                                    } else {
                                        return -0.0228545632551;
                                    }
                                } else {
                                    if (fs[53] <= -2363.0) {
                                        return 0.194779745662;
                                    } else {
                                        return -0.00694696822451;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 11.5) {
                            if (fs[48] <= 0.5) {
                                if (fs[47] <= -5.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.125852376657;
                                    } else {
                                        return 0.0396969896379;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0418327156101;
                                    } else {
                                        return 0.00315115381778;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9985.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0116833951468;
                                    } else {
                                        return 0.102945341414;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0225335360465;
                                    } else {
                                        return 0.130328448914;
                                    }
                                }
                            }
                        } else {
                            if (fs[55] <= 0.5) {
                                if (fs[31] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.028447779026;
                                    } else {
                                        return 0.0300559039108;
                                    }
                                } else {
                                    if (fs[53] <= -1363.0) {
                                        return 0.20872191644;
                                    } else {
                                        return 0.0429576423991;
                                    }
                                }
                            } else {
                                return 0.393080420091;
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 75.0) {
                        if (fs[23] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[47] <= -535.5) {
                                        return 0.184959155557;
                                    } else {
                                        return -0.0163650766885;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.031665147264;
                                    } else {
                                        return 0.489887205379;
                                    }
                                }
                            } else {
                                if (fs[47] <= -32.0) {
                                    return 0.370632751653;
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0334513128478;
                                    } else {
                                        return 0.230612142293;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[88] <= 5.0) {
                                        return 0.00104324087782;
                                    } else {
                                        return 0.0597137042603;
                                    }
                                } else {
                                    return -0.0969607680922;
                                }
                            } else {
                                if (fs[64] <= -498.5) {
                                    return 0.577544846798;
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.110214412036;
                                    } else {
                                        return 0.00710347585866;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[60] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.0610740897118;
                                    } else {
                                        return 0.216563265421;
                                    }
                                } else {
                                    return -0.140037745434;
                                }
                            } else {
                                if (fs[92] <= 0.5) {
                                    if (fs[76] <= 150.0) {
                                        return -0.0783784928581;
                                    } else {
                                        return -0.157836645533;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return 0.220713564335;
                                    } else {
                                        return -0.196140867222;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[76] <= 350.0) {
                                        return 0.0323359956135;
                                    } else {
                                        return 0.258023516411;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.143919238962;
                                    } else {
                                        return -0.0526623864405;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.00510041535063;
                                    } else {
                                        return 0.140509328382;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.617073620749;
                                    } else {
                                        return 0.127515482039;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 3.5) {
                    if (fs[88] <= 6.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0224774424183;
                                    } else {
                                        return -0.00950109817737;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.00743869996214;
                                    } else {
                                        return -0.0137203553818;
                                    }
                                }
                            } else {
                                if (fs[64] <= -997.5) {
                                    return 0.20059374019;
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.00315229764666;
                                    } else {
                                        return -0.0121457216375;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[64] <= -998.5) {
                                        return 0.296337450091;
                                    } else {
                                        return 0.012104589117;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.119195584118;
                                    } else {
                                        return -0.0797785503597;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0102865527493;
                                    } else {
                                        return -0.0326864441988;
                                    }
                                } else {
                                    if (fs[53] <= -947.0) {
                                        return -0.0126855681242;
                                    } else {
                                        return 0.0615529300189;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1383.0) {
                            if (fs[41] <= 0.5) {
                                if (fs[72] <= 9866.5) {
                                    if (fs[72] <= 4282.5) {
                                        return 0.0314696934924;
                                    } else {
                                        return -0.0373201523975;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0879754202973;
                                    } else {
                                        return 0.161273439261;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0138470223404;
                                    } else {
                                        return 0.396138248018;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.00504035489275;
                                    } else {
                                        return 0.16789334805;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.00766339825699;
                                    } else {
                                        return 0.150124324105;
                                    }
                                } else {
                                    return 0.483468481949;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0165698592933;
                                    } else {
                                        return -0.0264424392034;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return -0.00910310988091;
                                    } else {
                                        return -0.0278678060474;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9972.5) {
                        if (fs[4] <= 17.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[0] <= 18.5) {
                                    if (fs[53] <= 3.5) {
                                        return -0.00144938630246;
                                    } else {
                                        return -0.00809857293563;
                                    }
                                } else {
                                    if (fs[0] <= 118.5) {
                                        return -0.0064639654909;
                                    } else {
                                        return -0.000923228465277;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.00340927798814;
                                    } else {
                                        return 0.0315475060347;
                                    }
                                } else {
                                    if (fs[53] <= -1098.5) {
                                        return -0.00577473130312;
                                    } else {
                                        return -0.0072276707574;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9957.5) {
                                if (fs[47] <= -104.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.184381562653;
                                    } else {
                                        return -0.0112685632244;
                                    }
                                } else {
                                    if (fs[47] <= -33.5) {
                                        return -0.0139565784792;
                                    } else {
                                        return -0.00683757657199;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[76] <= 150.0) {
                                        return -0.0474769357275;
                                    } else {
                                        return -0.0635868162978;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.00752092488708;
                                    } else {
                                        return -0.0234522729414;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1418.0) {
                            if (fs[59] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0205238172218;
                                    } else {
                                        return -0.139987881177;
                                    }
                                } else {
                                    if (fs[0] <= 10.5) {
                                        return 0.156120795038;
                                    } else {
                                        return 0.250497037229;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[72] <= 9990.5) {
                                        return 0.0273729071227;
                                    } else {
                                        return 0.160311982587;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0571552778948;
                                    } else {
                                        return 0.025129458214;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[0] <= 10.5) {
                                    if (fs[13] <= 0.5) {
                                        return 0.017286481635;
                                    } else {
                                        return 0.151595441359;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.00627957355213;
                                    } else {
                                        return -0.026300362285;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0208004509096;
                                    } else {
                                        return -0.00565161879167;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0593201033401;
                                    } else {
                                        return -0.00298601982935;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
