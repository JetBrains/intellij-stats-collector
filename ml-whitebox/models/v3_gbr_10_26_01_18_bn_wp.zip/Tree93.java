/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree93 {
    public double calcTree(double... fs) {
        if (fs[0] <= 1.5) {
            if (fs[51] <= 0.5) {
                if (fs[94] <= 0.5) {
                    if (fs[47] <= -7.5) {
                        if (fs[93] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.0120250645862;
                                    } else {
                                        return 0.0614266841584;
                                    }
                                } else {
                                    if (fs[72] <= 5000.0) {
                                        return -0.0972994272655;
                                    } else {
                                        return -0.343050377134;
                                    }
                                }
                            } else {
                                if (fs[66] <= 5.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.215783430396;
                                    } else {
                                        return 0.0488910357009;
                                    }
                                } else {
                                    return -0.154852713802;
                                }
                            }
                        } else {
                            if (fs[47] <= -71.5) {
                                if (fs[47] <= -118.5) {
                                    return -0.185294995152;
                                } else {
                                    return -0.264173557923;
                                }
                            } else {
                                if (fs[47] <= -56.5) {
                                    return -0.038143678286;
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.215153391626;
                                    } else {
                                        return -0.168581033239;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[22] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -37.0) {
                                    if (fs[74] <= 0.5) {
                                        return 0.00482824958564;
                                    } else {
                                        return -0.0456838564732;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return -0.0153173672468;
                                    } else {
                                        return -0.276024970119;
                                    }
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.00664165549814;
                                    } else {
                                        return 0.0202655703281;
                                    }
                                } else {
                                    return -0.305847783063;
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[88] <= 5.5) {
                                        return -0.0125882931294;
                                    } else {
                                        return -0.0568853898243;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.051929925348;
                                    } else {
                                        return -0.0138364486779;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[72] <= 9295.0) {
                                        return 0.0480631492563;
                                    } else {
                                        return 0.0116321673352;
                                    }
                                } else {
                                    if (fs[53] <= -1703.0) {
                                        return 0.135308648223;
                                    } else {
                                        return -0.00838419478995;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1478.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[47] <= -3.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.108036350162;
                                    } else {
                                        return -0.0280610166451;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.125643394817;
                                    } else {
                                        return 0.439478204296;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    return 0.0755177493845;
                                } else {
                                    return -0.277219092899;
                                }
                            }
                        } else {
                            if (fs[4] <= 34.5) {
                                if (fs[101] <= 1.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0384300232491;
                                    } else {
                                        return 0.410167113888;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.278667784606;
                                    } else {
                                        return 0.136740588057;
                                    }
                                }
                            } else {
                                return -0.18723832155;
                            }
                        }
                    } else {
                        if (fs[90] <= 0.5) {
                            if (fs[76] <= 75.0) {
                                if (fs[2] <= 8.5) {
                                    if (fs[72] <= 9833.0) {
                                        return -0.0374451705613;
                                    } else {
                                        return 0.105543270155;
                                    }
                                } else {
                                    return -0.131669636624;
                                }
                            } else {
                                if (fs[53] <= -1228.0) {
                                    if (fs[4] <= 12.0) {
                                        return -0.0208293900348;
                                    } else {
                                        return 0.282757658327;
                                    }
                                } else {
                                    return 0.0238299842513;
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                return 0.304364835467;
                            } else {
                                return 0.0361247556386;
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 6.5) {
                    if (fs[70] <= -4.0) {
                        if (fs[2] <= 3.5) {
                            return 0.505405450419;
                        } else {
                            return 0.0882423775292;
                        }
                    } else {
                        if (fs[53] <= -1128.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    return 0.156450878656;
                                } else {
                                    return -0.0130217055357;
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.344514013565;
                                    } else {
                                        return 0.0862480712346;
                                    }
                                } else {
                                    return 0.332138245379;
                                }
                            }
                        } else {
                            if (fs[53] <= -557.0) {
                                return -0.0445371188953;
                            } else {
                                if (fs[72] <= 9998.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.117381795747;
                                    } else {
                                        return -0.0353404496354;
                                    }
                                } else {
                                    return 0.273850972632;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[53] <= -1288.0) {
                            return 0.101125890347;
                        } else {
                            if (fs[4] <= 13.5) {
                                if (fs[18] <= 0.5) {
                                    return -0.0955744056279;
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return -0.0794867083502;
                                    } else {
                                        return 0.0345928897984;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    return -0.0229122741753;
                                } else {
                                    return -0.138620584374;
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 100.0) {
                            if (fs[101] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    return 0.0753000747613;
                                } else {
                                    if (fs[53] <= -1133.0) {
                                        return 0.311182555822;
                                    } else {
                                        return 0.115129409093;
                                    }
                                }
                            } else {
                                return -0.0483097865262;
                            }
                        } else {
                            return -0.0157718956305;
                        }
                    }
                }
            }
        } else {
            if (fs[28] <= 0.5) {
                if (fs[103] <= 0.5) {
                    if (fs[49] <= -2.5) {
                        if (fs[18] <= 0.5) {
                            return -0.0734042022699;
                        } else {
                            return 0.244566490308;
                        }
                    } else {
                        if (fs[90] <= 0.5) {
                            if (fs[47] <= -0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.00738114089764;
                                    } else {
                                        return -0.000789235497713;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.00671768337348;
                                    } else {
                                        return -0.000159843914304;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.00559359288951;
                                    } else {
                                        return 0.00673903347783;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0186893798901;
                                    } else {
                                        return -0.00565407030777;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1418.0) {
                                if (fs[48] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.00147162960394;
                                    } else {
                                        return 0.218279733579;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0615596588853;
                                    } else {
                                        return -0.0109530415058;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[0] <= 18.5) {
                                        return 0.00498774480503;
                                    } else {
                                        return -0.00615826500587;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.148214184962;
                                    } else {
                                        return 0.246404485163;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 77.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[0] <= 5.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0266935712264;
                                    } else {
                                        return 0.158957748356;
                                    }
                                } else {
                                    if (fs[72] <= 9975.5) {
                                        return 0.0047345902864;
                                    } else {
                                        return 0.0936542455854;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0457393277244;
                                    } else {
                                        return -0.00749904970067;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.00853774684382;
                                    } else {
                                        return -0.0150490235731;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1142.5) {
                                if (fs[72] <= 9997.5) {
                                    if (fs[0] <= 55.0) {
                                        return -0.0102151787832;
                                    } else {
                                        return 0.233552795115;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.120098294226;
                                    } else {
                                        return -0.0875086861645;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1082.5) {
                                    if (fs[72] <= 9998.5) {
                                        return 0.00739758365072;
                                    } else {
                                        return 0.162587711957;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.00602620736333;
                                    } else {
                                        return -0.00110001684261;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1103.0) {
                            if (fs[23] <= 0.5) {
                                if (fs[4] <= 14.5) {
                                    return 0.175524660519;
                                } else {
                                    return 0.48724114185;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.166399221165;
                                } else {
                                    return 0.0528823819298;
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[53] <= 13.0) {
                                    return -0.00292011315937;
                                } else {
                                    if (fs[0] <= 100.5) {
                                        return -0.00032015616209;
                                    } else {
                                        return 0.0001624988758;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    return -0.0175342899072;
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.00570945298881;
                                    } else {
                                        return -0.0189788166153;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[72] <= 9997.0) {
                    if (fs[97] <= 0.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[47] <= -74.5) {
                                if (fs[49] <= -0.5) {
                                    return -0.0781626735792;
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.0702948714169;
                                    } else {
                                        return -0.0281948564045;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9827.0) {
                                    if (fs[47] <= -35.5) {
                                        return 0.0571790298181;
                                    } else {
                                        return -0.00640720449832;
                                    }
                                } else {
                                    return 0.0850761137121;
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0562727307785;
                                    } else {
                                        return -0.0241647895461;
                                    }
                                } else {
                                    return -0.00467173748863;
                                }
                            } else {
                                return -0.095634146132;
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            return -0.0536380826849;
                        } else {
                            return -0.108207171036;
                        }
                    }
                } else {
                    if (fs[48] <= 0.5) {
                        return -0.184130515537;
                    } else {
                        return -0.00981929087369;
                    }
                }
            }
        }
    }
}
