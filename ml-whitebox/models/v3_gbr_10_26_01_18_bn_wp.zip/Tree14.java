/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree14 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[53] <= -987.5) {
                if (fs[85] <= 0.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[53] <= -1142.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.390233709023;
                                    } else {
                                        return 0.268608713067;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.429557970162;
                                    } else {
                                        return 0.329710208847;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[72] <= 9890.0) {
                                        return -0.0398417011566;
                                    } else {
                                        return 0.153379555428;
                                    }
                                } else {
                                    if (fs[53] <= -1318.0) {
                                        return -0.0651894695807;
                                    } else {
                                        return 0.189205179722;
                                    }
                                }
                            }
                        } else {
                            if (fs[81] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.483967617769;
                                    } else {
                                        return 0.344528320608;
                                    }
                                } else {
                                    if (fs[53] <= -1128.5) {
                                        return 0.447306391577;
                                    } else {
                                        return 0.477429240008;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.432201190512;
                                    } else {
                                        return 0.342386709893;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.119004973607;
                                    } else {
                                        return 0.036785885744;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1258.0) {
                            if (fs[4] <= 17.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.156480666197;
                                    } else {
                                        return 0.396881093761;
                                    }
                                } else {
                                    if (fs[53] <= -1618.0) {
                                        return 0.547818923697;
                                    } else {
                                        return 0.482448027005;
                                    }
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.262619849726;
                                    } else {
                                        return -0.0622808778039;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.125022490511;
                                    } else {
                                        return 0.00150708009643;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 12.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.454272605511;
                                    } else {
                                        return 0.13169472056;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.192836157591;
                                    } else {
                                        return 0.35345516784;
                                    }
                                }
                            } else {
                                if (fs[47] <= -358.5) {
                                    return -0.0992316525599;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.397618814315;
                                    } else {
                                        return 0.328916701772;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -8.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[47] <= -3550.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.39808556775;
                                    } else {
                                        return 0.545417437438;
                                    }
                                } else {
                                    if (fs[53] <= -1478.5) {
                                        return 0.236957409571;
                                    } else {
                                        return 0.465238927838;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.550131908468;
                                    } else {
                                        return 0.46308550606;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.454309160223;
                                    } else {
                                        return 0.317696425329;
                                    }
                                }
                            }
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[72] <= 9987.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0124526771429;
                                    } else {
                                        return 0.252923457869;
                                    }
                                } else {
                                    if (fs[47] <= -36.5) {
                                        return 0.617691344271;
                                    } else {
                                        return 0.202181288968;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0780907576662;
                                    } else {
                                        return 0.223124863289;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.301306516403;
                                    } else {
                                        return 0.51079551783;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 6.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[88] <= 3.5) {
                                        return 0.336130006396;
                                    } else {
                                        return 0.201092838561;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.192820130033;
                                    } else {
                                        return 0.0450544383491;
                                    }
                                }
                            } else {
                                if (fs[43] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.350600791257;
                                    } else {
                                        return 0.467736607218;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.247541352113;
                                    } else {
                                        return -0.0403876279703;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.376717028307;
                                    } else {
                                        return 0.515456504424;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0865784212546;
                                    } else {
                                        return 0.536371105956;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.399109388932;
                                    } else {
                                        return 0.524396212015;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.376565615389;
                                    } else {
                                        return 0.0459008262518;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[71] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.489361304761;
                                    } else {
                                        return 0.534673683405;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.180444251713;
                                    } else {
                                        return 0.303088855928;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[105] <= 0.5) {
                                        return 0.458824214104;
                                    } else {
                                        return 0.226254427216;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.511801640815;
                                    } else {
                                        return 0.563244733748;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9997.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.123599070553;
                                    } else {
                                        return -0.0530701440837;
                                    }
                                } else {
                                    if (fs[72] <= 9957.5) {
                                        return 0.0116172469451;
                                    } else {
                                        return -0.194124571527;
                                    }
                                }
                            } else {
                                if (fs[88] <= 5.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.149984599965;
                                    } else {
                                        return 0.290921136016;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0811238138234;
                                    } else {
                                        return 0.483194288706;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 5.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[53] <= -948.0) {
                                    return -0.0101490884661;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.37766115482;
                                    } else {
                                        return 0.465423659897;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.352265899845;
                                    } else {
                                        return 0.244792237038;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.138687431826;
                                    } else {
                                        return 0.216708612076;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[31] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.486509919227;
                                    } else {
                                        return 0.340132638654;
                                    }
                                } else {
                                    return -0.217198840277;
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.621604830528;
                                    } else {
                                        return 0.612080414454;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.525543079334;
                                    } else {
                                        return 0.639516934468;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[47] <= -2.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.511970187886;
                                    } else {
                                        return 0.349650725956;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.403918506655;
                                    } else {
                                        return 0.263179283398;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.204858996071;
                                    } else {
                                        return 0.0931853666676;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0202972587633;
                                    } else {
                                        return 0.109454155301;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.362491003968;
                                    } else {
                                        return -0.10932852135;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.440188863138;
                                    } else {
                                        return 0.578072104859;
                                    }
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.302319310631;
                                    } else {
                                        return 0.406126722873;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0106086837306;
                                    } else {
                                        return 0.113999553651;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[53] <= -462.0) {
                                if (fs[53] <= -977.5) {
                                    return 0.130235292096;
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.163639453052;
                                    } else {
                                        return -0.0792820719292;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.476136017033;
                                    } else {
                                        return 0.358578307375;
                                    }
                                } else {
                                    if (fs[88] <= 1.0) {
                                        return -0.000319718582513;
                                    } else {
                                        return 0.226023740781;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[49] <= -0.5) {
                                    if (fs[49] <= -1.5) {
                                        return 0.52601283192;
                                    } else {
                                        return 0.37365179647;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.212328834693;
                                    } else {
                                        return 0.383711946987;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.153332395942;
                                    } else {
                                        return 0.283053973117;
                                    }
                                } else {
                                    if (fs[53] <= -971.5) {
                                        return -0.0555995758034;
                                    } else {
                                        return -0.167730628634;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[90] <= 0.5) {
                if (fs[0] <= 1.5) {
                    if (fs[72] <= 8674.0) {
                        if (fs[47] <= -1506.5) {
                            if (fs[53] <= -1458.0) {
                                if (fs[4] <= 12.5) {
                                    if (fs[47] <= -12741.0) {
                                        return 0.316684932142;
                                    } else {
                                        return 0.475882328355;
                                    }
                                } else {
                                    return 0.0453236388952;
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    return -0.118414937841;
                                } else {
                                    if (fs[47] <= -1544.0) {
                                        return -0.0105508334343;
                                    } else {
                                        return 0.180854319027;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.026348192665;
                                    } else {
                                        return 0.129548660726;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0121748200497;
                                    } else {
                                        return 0.0395307940427;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0831941013847;
                                    } else {
                                        return 0.0107478783979;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.171495608012;
                                    } else {
                                        return 0.492287142075;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 7.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[72] <= 9982.5) {
                                        return 0.031287448504;
                                    } else {
                                        return 0.0754983614976;
                                    }
                                } else {
                                    if (fs[53] <= -1128.5) {
                                        return 0.240897400822;
                                    } else {
                                        return 0.0879621471563;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9993.5) {
                                    if (fs[2] <= 7.5) {
                                        return 0.0923378981304;
                                    } else {
                                        return 0.237235819553;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return -0.0518963192642;
                                    } else {
                                        return 0.291013908038;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[72] <= 9995.5) {
                                    if (fs[47] <= -3.0) {
                                        return 0.173620135947;
                                    } else {
                                        return -0.0821901928246;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.203114102054;
                                    } else {
                                        return -0.00499068490199;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1458.0) {
                                    if (fs[47] <= -0.5) {
                                        return 0.317553278228;
                                    } else {
                                        return -0.0866040632401;
                                    }
                                } else {
                                    if (fs[72] <= 9992.0) {
                                        return -0.113273776112;
                                    } else {
                                        return 0.058040927872;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9983.5) {
                        if (fs[0] <= 3.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[53] <= -1488.5) {
                                    if (fs[72] <= 9868.5) {
                                        return 0.00769647283442;
                                    } else {
                                        return 0.100004525701;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.020091355679;
                                    } else {
                                        return 0.000575415457978;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.0168132191704;
                                    } else {
                                        return -0.0301561242421;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.00585912025547;
                                    } else {
                                        return 0.0378949107129;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 10.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0141511853548;
                                    } else {
                                        return -0.0317029761998;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0260896710627;
                                    } else {
                                        return -0.0173734845473;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0262522151089;
                                    } else {
                                        return -0.0299394073928;
                                    }
                                } else {
                                    if (fs[47] <= -9750.0) {
                                        return 0.130745904145;
                                    } else {
                                        return -0.0289728883532;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1418.0) {
                            if (fs[2] <= 2.5) {
                                if (fs[53] <= -1478.0) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0697425099745;
                                    } else {
                                        return 0.00367559377949;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return 0.110731479633;
                                    } else {
                                        return 0.276411684992;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.046212411692;
                                    } else {
                                        return 0.204276715968;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.570923612868;
                                    } else {
                                        return 0.245079975824;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0736105208628;
                                    } else {
                                        return 0.0978808088002;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.00042361116171;
                                    } else {
                                        return 0.040848224159;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.000407699846721;
                                    } else {
                                        return 0.0634487983198;
                                    }
                                } else {
                                    if (fs[53] <= -991.5) {
                                        return -0.0394859328198;
                                    } else {
                                        return -0.0339505378199;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[45] <= 0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[4] <= 17.5) {
                            if (fs[103] <= 1.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.162262074227;
                                    } else {
                                        return 0.0781941216119;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.00308989567224;
                                    } else {
                                        return 0.0645866996433;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 9.5) {
                                        return 0.168277156719;
                                    } else {
                                        return 0.590242508692;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0571361668779;
                                    } else {
                                        return 0.148715956252;
                                    }
                                }
                            }
                        } else {
                            if (fs[103] <= 1.5) {
                                if (fs[92] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return -0.0447172724354;
                                    } else {
                                        return 0.225041337156;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0369274350616;
                                    } else {
                                        return -0.0125271055245;
                                    }
                                }
                            } else {
                                if (fs[0] <= 36.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0664868825672;
                                    } else {
                                        return 0.122931885707;
                                    }
                                } else {
                                    return 0.699982181673;
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 250.0) {
                            if (fs[0] <= 3.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.0557818416244;
                                    } else {
                                        return 0.28117613382;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.432303818073;
                                    } else {
                                        return 0.0582279993802;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0210509850856;
                                    } else {
                                        return -0.0058254098606;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.361286387561;
                                    } else {
                                        return -0.0153749483731;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.00941791108196;
                                    } else {
                                        return 0.109684762991;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.0169120301461;
                                    } else {
                                        return -0.0299610375124;
                                    }
                                }
                            } else {
                                if (fs[47] <= -5.0) {
                                    return -0.0997030038474;
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return 0.251217055313;
                                    } else {
                                        return -0.0214831944367;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[49] <= -2.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[58] <= 0.5) {
                                return -0.0170962377811;
                            } else {
                                return 0.124660139487;
                            }
                        } else {
                            if (fs[53] <= -976.0) {
                                if (fs[4] <= 17.5) {
                                    return 0.0625320515194;
                                } else {
                                    return -0.0422533001042;
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    return -0.0450722865949;
                                } else {
                                    if (fs[53] <= -467.0) {
                                        return -0.0400202711668;
                                    } else {
                                        return -0.032934788025;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[23] <= 0.5) {
                            if (fs[72] <= 9997.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0370389411335;
                                    } else {
                                        return -0.0332001743673;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0265074402843;
                                    } else {
                                        return -0.0296237042498;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0136307699132;
                                    } else {
                                        return -0.0305663386342;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.286153159083;
                                    } else {
                                        return -0.0140316684459;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.00103356562913;
                                    } else {
                                        return -0.0356080114829;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0535584053976;
                                    } else {
                                        return -0.0386489663461;
                                    }
                                }
                            } else {
                                if (fs[53] <= 3.0) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0328956422671;
                                    } else {
                                        return -0.0311105367055;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0305208681098;
                                    } else {
                                        return -0.0241334402882;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
