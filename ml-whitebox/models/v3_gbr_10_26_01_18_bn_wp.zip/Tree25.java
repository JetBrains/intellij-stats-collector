/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree25 {
    public double calcTree(double... fs) {
        if (fs[103] <= 1.5) {
            if (fs[72] <= 9985.5) {
                if (fs[81] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[76] <= 100.0) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.238452443144;
                                    } else {
                                        return 0.13975750851;
                                    }
                                } else {
                                    if (fs[53] <= -1033.5) {
                                        return 0.274338591333;
                                    } else {
                                        return 0.170868900352;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.262541026957;
                                    } else {
                                        return 0.167701613142;
                                    }
                                } else {
                                    return -0.031128757519;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return -0.102159886738;
                            } else {
                                if (fs[53] <= -1328.0) {
                                    if (fs[53] <= -1568.0) {
                                        return 0.00839506173624;
                                    } else {
                                        return -0.179684041865;
                                    }
                                } else {
                                    return 0.0958598534108;
                                }
                            }
                        }
                    } else {
                        if (fs[30] <= 0.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[53] <= -1068.0) {
                                        return 0.406498913559;
                                    } else {
                                        return -0.0669509593058;
                                    }
                                } else {
                                    return 0.0476164806077;
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0330125697101;
                                    } else {
                                        return -0.0343140020695;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.00290339960605;
                                    } else {
                                        return -0.0252327751301;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                return 0.392576391292;
                            } else {
                                return 0.476363881851;
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.168125311945;
                                    } else {
                                        return 0.322632668052;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0160283405016;
                                    } else {
                                        return 0.0518015424439;
                                    }
                                }
                            } else {
                                if (fs[47] <= -11.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0732393313267;
                                    } else {
                                        return 0.00073914640361;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0134376760878;
                                    } else {
                                        return -0.00155976276355;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[53] <= -1083.0) {
                                    if (fs[64] <= -998.5) {
                                        return 0.334136022927;
                                    } else {
                                        return 0.178409422353;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.252619216308;
                                    } else {
                                        return 0.0153006178495;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.31196600787;
                                    } else {
                                        return 0.210422919811;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.0145926867508;
                                    } else {
                                        return -0.00870036840855;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[85] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.16279649829;
                                    } else {
                                        return 0.0606779623362;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0141576415717;
                                    } else {
                                        return -0.00338287607821;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9842.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.017688046816;
                                    } else {
                                        return 0.110379074728;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.160945074547;
                                    } else {
                                        return 0.00308512674824;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.151831646636;
                                    } else {
                                        return 0.256249993526;
                                    }
                                } else {
                                    if (fs[53] <= -1118.5) {
                                        return 0.0586367043799;
                                    } else {
                                        return -0.0135308546767;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0917875287962;
                                    } else {
                                        return 0.235814381268;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.00612403537972;
                                    } else {
                                        return -0.0142146072507;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -436.0) {
                            if (fs[53] <= -1608.0) {
                                if (fs[4] <= 12.5) {
                                    if (fs[53] <= -2758.5) {
                                        return 0.0878080999597;
                                    } else {
                                        return 0.377991248075;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.306838888353;
                                    } else {
                                        return 0.185724090625;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9998.5) {
                                    if (fs[53] <= -1488.5) {
                                        return 0.0239680919472;
                                    } else {
                                        return 0.226588381116;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.249150069576;
                                    } else {
                                        return 0.173525067505;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -6.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.300128705807;
                                    } else {
                                        return 0.134056266408;
                                    }
                                } else {
                                    if (fs[88] <= 3.0) {
                                        return 0.136802786481;
                                    } else {
                                        return -0.00177645975941;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.335452294936;
                                    } else {
                                        return 0.132148604517;
                                    }
                                } else {
                                    if (fs[70] <= -4.5) {
                                        return 0.185065443525;
                                    } else {
                                        return 0.0358707999632;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[23] <= 0.5) {
                            if (fs[4] <= 18.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[72] <= 9996.5) {
                                        return 0.202404743063;
                                    } else {
                                        return 0.251891812408;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.304532814514;
                                    } else {
                                        return 0.338001893866;
                                    }
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.0563610331589;
                                    } else {
                                        return -0.097763139298;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.182695351405;
                                    } else {
                                        return -0.0453386211233;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.280066572982;
                                    } else {
                                        return 0.353678255238;
                                    }
                                } else {
                                    if (fs[88] <= 4.5) {
                                        return 0.189188249002;
                                    } else {
                                        return 0.274457441993;
                                    }
                                }
                            } else {
                                if (fs[88] <= 5.5) {
                                    if (fs[47] <= -6.5) {
                                        return 0.215343380637;
                                    } else {
                                        return 0.11380694507;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return 0.146685918283;
                                    } else {
                                        return 0.320707580222;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1418.0) {
                        if (fs[18] <= -0.5) {
                            if (fs[72] <= 9996.0) {
                                if (fs[53] <= -1488.0) {
                                    return -0.144477641676;
                                } else {
                                    return -0.112397031363;
                                }
                            } else {
                                return -0.217774052765;
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.173819160225;
                                    } else {
                                        return 0.0485680305402;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.156637075682;
                                    } else {
                                        return 0.530549002295;
                                    }
                                }
                            } else {
                                if (fs[66] <= 5.0) {
                                    if (fs[0] <= 21.5) {
                                        return 0.232000182533;
                                    } else {
                                        return -0.0279287620699;
                                    }
                                } else {
                                    return -0.193037473048;
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[53] <= -1128.5) {
                                if (fs[47] <= -3.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0626288549512;
                                    } else {
                                        return 0.241383640345;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0971143714436;
                                    } else {
                                        return 0.0165544462761;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0800451824985;
                                    } else {
                                        return 0.0195641147482;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.305712294895;
                                    } else {
                                        return 0.000856351089744;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[53] <= -1108.0) {
                                    if (fs[0] <= 29.0) {
                                        return 0.00329384122391;
                                    } else {
                                        return 0.523064593178;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return -0.0101339063806;
                                    } else {
                                        return -0.0215606920352;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.569928272904;
                                    } else {
                                        return 0.244442716738;
                                    }
                                } else {
                                    return -0.121853255112;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[41] <= 0.5) {
                    if (fs[4] <= 20.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[53] <= -992.0) {
                                    if (fs[58] <= 0.5) {
                                        return 0.258789634001;
                                    } else {
                                        return 0.169729039408;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.274425507793;
                                    } else {
                                        return 0.2306360466;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.399063796728;
                                    } else {
                                        return 0.193230509357;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.185844321503;
                                    } else {
                                        return 0.23596499855;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                return 0.176495137561;
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.268487000298;
                                    } else {
                                        return 0.0147548334636;
                                    }
                                } else {
                                    return 0.126740926565;
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= -0.5) {
                            if (fs[4] <= 21.5) {
                                return 0.0770997451887;
                            } else {
                                if (fs[62] <= -2.5) {
                                    return 0.382177815014;
                                } else {
                                    return 0.361676128431;
                                }
                            }
                        } else {
                            if (fs[4] <= 27.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[27] <= 0.5) {
                                        return 0.18029515185;
                                    } else {
                                        return -0.0190687943757;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.000335649483988;
                                    } else {
                                        return 0.151434164793;
                                    }
                                }
                            } else {
                                if (fs[4] <= 31.5) {
                                    return -0.0507015759297;
                                } else {
                                    return -0.215866412669;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[26] <= 0.5) {
                        if (fs[60] <= 0.5) {
                            return -0.262810025491;
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[4] <= 3.5) {
                                    return 0.124672496243;
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0903356692003;
                                    } else {
                                        return 0.0501465985436;
                                    }
                                }
                            } else {
                                return -0.280689044713;
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            return -0.265880350582;
                        } else {
                            if (fs[53] <= -1138.0) {
                                if (fs[52] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.137024973213;
                                    } else {
                                        return 0.303258039474;
                                    }
                                } else {
                                    return 0.0876975168076;
                                }
                            } else {
                                if (fs[53] <= -1128.0) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0441859710971;
                                    } else {
                                        return -0.122738832358;
                                    }
                                } else {
                                    return 0.184500581692;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[58] <= 0.5) {
                    if (fs[53] <= -1068.0) {
                        if (fs[0] <= 21.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[49] <= -0.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.278330615562;
                                    } else {
                                        return 0.114499083977;
                                    }
                                } else {
                                    if (fs[53] <= -1088.5) {
                                        return 0.0704231261137;
                                    } else {
                                        return 0.725721780986;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0565225666225;
                                    } else {
                                        return -0.0910561733412;
                                    }
                                } else {
                                    return 0.0558402818035;
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[0] <= 41.5) {
                                    return 0.321173444826;
                                } else {
                                    return 0.576460615322;
                                }
                            } else {
                                return 0.707183716206;
                            }
                        }
                    } else {
                        if (fs[49] <= -2.5) {
                            return 0.0278076642942;
                        } else {
                            if (fs[13] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0370159210984;
                                    } else {
                                        return -0.0167381410176;
                                    }
                                } else {
                                    return -0.0632828875525;
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    return 0.149304254949;
                                } else {
                                    if (fs[53] <= -961.0) {
                                        return -0.0385607259563;
                                    } else {
                                        return -0.0250576789259;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[23] <= 0.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[53] <= -1128.0) {
                                return 0.159405078199;
                            } else {
                                if (fs[0] <= 3.5) {
                                    return -0.0641129571796;
                                } else {
                                    return -0.0234589863167;
                                }
                            }
                        } else {
                            return 0.0762009986302;
                        }
                    } else {
                        if (fs[0] <= 6.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0540907934549;
                                    } else {
                                        return -0.0222797037202;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0248759256959;
                                    } else {
                                        return 0.262828264235;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0231433342694;
                                    } else {
                                        return -0.056604892137;
                                    }
                                } else {
                                    return 0.121018464496;
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                if (fs[78] <= 0.5) {
                                    return 0.252319290645;
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return -0.0299280175288;
                                    } else {
                                        return 0.017827057221;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0438733449602;
                                    } else {
                                        return -0.0253834818357;
                                    }
                                } else {
                                    if (fs[0] <= 50.5) {
                                        return -0.0168209695509;
                                    } else {
                                        return 0.0148858045339;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
