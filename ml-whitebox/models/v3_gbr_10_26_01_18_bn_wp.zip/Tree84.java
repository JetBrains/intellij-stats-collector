/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree84 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[53] <= -987.5) {
                    if (fs[24] <= 0.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[76] <= 350.0) {
                                    if (fs[4] <= 1.5) {
                                        return -0.0246738324248;
                                    } else {
                                        return 0.0125850839111;
                                    }
                                } else {
                                    return 0.232740057244;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.0140973430043;
                                    } else {
                                        return 0.0376301139593;
                                    }
                                } else {
                                    if (fs[47] <= -1334.5) {
                                        return 0.113512863296;
                                    } else {
                                        return -0.0382520988147;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -1098.5) {
                                        return 0.0555399577372;
                                    } else {
                                        return -0.0203683263623;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.253892930401;
                                    } else {
                                        return 0.0741000400058;
                                    }
                                }
                            } else {
                                if (fs[4] <= 21.5) {
                                    if (fs[53] <= -1123.5) {
                                        return 0.0240211454277;
                                    } else {
                                        return 0.0523402854844;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.134718425546;
                                    } else {
                                        return 0.0242311550189;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1468.5) {
                            if (fs[88] <= 0.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0109088579691;
                                    } else {
                                        return -0.222449511091;
                                    }
                                } else {
                                    return 0.120940715904;
                                }
                            } else {
                                if (fs[4] <= 20.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0409038989282;
                                    } else {
                                        return 0.22654181383;
                                    }
                                } else {
                                    return -0.00478336841377;
                                }
                            }
                        } else {
                            if (fs[101] <= 0.5) {
                                return 0.345781128862;
                            } else {
                                return 0.16237694123;
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9997.5) {
                        if (fs[64] <= -996.5) {
                            if (fs[47] <= -0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[101] <= 1.5) {
                                        return -0.323372656409;
                                    } else {
                                        return 0.0757791597958;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0168142277614;
                                    } else {
                                        return 0.0801793805851;
                                    }
                                }
                            } else {
                                return 0.17913178844;
                            }
                        } else {
                            if (fs[101] <= 0.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0304496010625;
                                    } else {
                                        return -0.104520248994;
                                    }
                                } else {
                                    return -0.333827267722;
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0396548819704;
                                    } else {
                                        return -0.213089395121;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.0262460615443;
                                    } else {
                                        return -0.105447865191;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[14] <= 0.5) {
                            if (fs[70] <= -4.5) {
                                if (fs[101] <= 1.5) {
                                    if (fs[88] <= 5.0) {
                                        return -0.0249634989996;
                                    } else {
                                        return 0.157065362568;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0921016989981;
                                    } else {
                                        return 0.207289798174;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0301137393998;
                                    } else {
                                        return -0.0099973344292;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.00119737549191;
                                    } else {
                                        return -0.0675553811081;
                                    }
                                }
                            }
                        } else {
                            if (fs[101] <= 0.5) {
                                return 0.0630818218253;
                            } else {
                                if (fs[47] <= -3.0) {
                                    return 0.147813449389;
                                } else {
                                    return 0.288548973324;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1988.5) {
                    if (fs[4] <= 52.0) {
                        if (fs[47] <= -2.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[72] <= 9987.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.256645553323;
                                    } else {
                                        return 0.195766830146;
                                    }
                                } else {
                                    return 0.098687289938;
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.15129305755;
                                } else {
                                    return 0.0440934962314;
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                return -0.102123395154;
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.166493581287;
                                    } else {
                                        return 0.0483745534587;
                                    }
                                } else {
                                    if (fs[72] <= 9894.0) {
                                        return 0.195410291186;
                                    } else {
                                        return 0.0671913221763;
                                    }
                                }
                            }
                        }
                    } else {
                        return -0.278829412596;
                    }
                } else {
                    if (fs[32] <= 0.5) {
                        if (fs[8] <= 0.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[4] <= 25.5) {
                                        return 0.0454664116163;
                                    } else {
                                        return 0.157960657832;
                                    }
                                } else {
                                    if (fs[74] <= 0.5) {
                                        return 0.0174740087853;
                                    } else {
                                        return -0.0239227958959;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.0226673357152;
                                    } else {
                                        return 0.0286116444159;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.0464895533017;
                                    } else {
                                        return -0.00813891417766;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                return 0.219861331134;
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.321405868813;
                                    } else {
                                        return -0.143905290702;
                                    }
                                } else {
                                    return -0.0997309323092;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            return -0.0948981764046;
                        } else {
                            if (fs[2] <= 4.5) {
                                return -0.256677800194;
                            } else {
                                return -0.29822027977;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[55] <= 0.5) {
                if (fs[72] <= 9999.5) {
                    if (fs[53] <= -4913.0) {
                        return 0.184944062269;
                    } else {
                        if (fs[4] <= 25.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[62] <= -1.5) {
                                        return 0.038801483074;
                                    } else {
                                        return -0.000283468650065;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.00872873545649;
                                    } else {
                                        return -0.00170385637157;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.0966256636495;
                                    } else {
                                        return 0.0167725377911;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return -0.00197130814258;
                                    } else {
                                        return 0.115598134257;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 16.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[35] <= 0.5) {
                                        return -0.0110089608191;
                                    } else {
                                        return 0.178842339259;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.00214439033222;
                                    } else {
                                        return -0.000557821728182;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    return -0.0359409847853;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.107011185098;
                                    } else {
                                        return -0.137312614542;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1968.0) {
                        if (fs[11] <= 0.5) {
                            return 0.0719805340147;
                        } else {
                            if (fs[76] <= 75.0) {
                                return 0.105955953852;
                            } else {
                                return 0.360641944081;
                            }
                        }
                    } else {
                        if (fs[8] <= 0.5) {
                            if (fs[66] <= 5.0) {
                                if (fs[70] <= -3.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.112276129605;
                                    } else {
                                        return -0.0569309539995;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0541950433855;
                                    } else {
                                        return 0.00850730355897;
                                    }
                                }
                            } else {
                                if (fs[47] <= -20.5) {
                                    return -0.251714852571;
                                } else {
                                    return -0.0255089736227;
                                }
                            }
                        } else {
                            return -0.190810614918;
                        }
                    }
                }
            } else {
                if (fs[76] <= 75.0) {
                    if (fs[88] <= 2.5) {
                        if (fs[47] <= -23.5) {
                            return 0.185946284882;
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[0] <= 5.5) {
                                    return 0.0991154391259;
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return -0.0201700250024;
                                    } else {
                                        return -0.00647071279429;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    return -0.121685771515;
                                } else {
                                    return -0.0139280416532;
                                }
                            }
                        }
                    } else {
                        return 0.155140465807;
                    }
                } else {
                    if (fs[72] <= 9997.5) {
                        return 0.0918161762365;
                    } else {
                        return 0.251278879574;
                    }
                }
            }
        }
    }
}
