/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree88 {
    public double calcTree(double... fs) {
        if (fs[57] <= 0.5) {
            if (fs[34] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[47] <= -7.5) {
                        if (fs[18] <= -0.5) {
                            if (fs[47] <= -71.5) {
                                return -0.31765197505;
                            } else {
                                return -0.115748466177;
                            }
                        } else {
                            if (fs[53] <= -1478.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.011069539532;
                                    } else {
                                        return -0.248922434237;
                                    }
                                } else {
                                    if (fs[72] <= 9993.5) {
                                        return 0.121581497734;
                                    } else {
                                        return 0.00478343894608;
                                    }
                                }
                            } else {
                                if (fs[53] <= -987.0) {
                                    if (fs[43] <= 0.5) {
                                        return 0.0691702921411;
                                    } else {
                                        return -0.105681841529;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.0252126792136;
                                    } else {
                                        return -0.0894789267343;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 250.0) {
                            if (fs[59] <= 0.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.029343902436;
                                    } else {
                                        return 0.0687626615811;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.00812948421545;
                                    } else {
                                        return -0.0207156166233;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[92] <= 0.5) {
                                        return 0.0281107879857;
                                    } else {
                                        return 0.00145795547676;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return -0.0595778534585;
                                    } else {
                                        return 0.0851123273077;
                                    }
                                }
                            }
                        } else {
                            if (fs[103] <= 0.5) {
                                if (fs[47] <= -1.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0846456720035;
                                    } else {
                                        return -0.0863420302132;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return -0.0638864250544;
                                    } else {
                                        return 0.124145225262;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[49] <= -3.5) {
                                        return -0.205338753852;
                                    } else {
                                        return 0.016685519059;
                                    }
                                } else {
                                    if (fs[53] <= -1298.5) {
                                        return 0.0940408970439;
                                    } else {
                                        return -0.0317960048766;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[14] <= 0.5) {
                        if (fs[53] <= -3448.0) {
                            if (fs[0] <= 2.5) {
                                if (fs[99] <= 0.5) {
                                    return 0.0884048112509;
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.100099268337;
                                    } else {
                                        return 0.332565290806;
                                    }
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0359025107113;
                                    } else {
                                        return 0.0916022290127;
                                    }
                                } else {
                                    return -0.0140090873672;
                                }
                            }
                        } else {
                            if (fs[55] <= 0.5) {
                                if (fs[76] <= 250.0) {
                                    if (fs[76] <= 25.0) {
                                        return -0.000708064133621;
                                    } else {
                                        return 0.00157033298038;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.00893945756246;
                                    } else {
                                        return -0.00120239781148;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9989.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.0780024396597;
                                    } else {
                                        return -0.0133271134264;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return 0.239725031444;
                                    } else {
                                        return 0.0625932414483;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 5.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.0543175932776;
                                    } else {
                                        return -0.00736410997976;
                                    }
                                } else {
                                    if (fs[53] <= 3.5) {
                                        return 0.107066186438;
                                    } else {
                                        return -0.0437941247749;
                                    }
                                }
                            } else {
                                return 0.272901735875;
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[47] <= -34.0) {
                                    if (fs[70] <= -4.0) {
                                        return 0.0231909398045;
                                    } else {
                                        return 0.154256847437;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.00438656743829;
                                    } else {
                                        return 0.184189045057;
                                    }
                                }
                            } else {
                                return 0.137281081836;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[47] <= -24.0) {
                        if (fs[47] <= -36.0) {
                            if (fs[72] <= 4964.0) {
                                return 0.248881930628;
                            } else {
                                return 0.136374298238;
                            }
                        } else {
                            return 0.381098153102;
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[72] <= 4692.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.153364474387;
                                    } else {
                                        return 0.259149479127;
                                    }
                                } else {
                                    if (fs[72] <= 9886.0) {
                                        return 0.00181771560581;
                                    } else {
                                        return 0.0775641943108;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return 0.0880379494788;
                                } else {
                                    return -0.20647602019;
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                return -0.0542882268715;
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[72] <= 4780.5) {
                                        return -0.0326761089257;
                                    } else {
                                        return -0.0632305095322;
                                    }
                                } else {
                                    return -0.0270342742211;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9866.5) {
                        if (fs[53] <= -1123.0) {
                            if (fs[60] <= 0.5) {
                                return 0.0784365696121;
                            } else {
                                return 0.0887751890342;
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[72] <= 4751.0) {
                                        return 0.0139684065647;
                                    } else {
                                        return -0.0616865252126;
                                    }
                                } else {
                                    if (fs[53] <= 3.5) {
                                        return -0.0310424206482;
                                    } else {
                                        return -0.0101901953228;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[0] <= 35.5) {
                                        return -0.00662020219166;
                                    } else {
                                        return 0.0316562294103;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.186799336833;
                                    } else {
                                        return -0.00239518689286;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.0431586463639;
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[18] <= 0.5) {
                    if (fs[53] <= -537.0) {
                        return -0.104816130812;
                    } else {
                        if (fs[76] <= 250.0) {
                            return 0.0741703121847;
                        } else {
                            return -0.0141830797396;
                        }
                    }
                } else {
                    if (fs[78] <= 0.5) {
                        return -0.0598560928115;
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[72] <= 9993.0) {
                                if (fs[4] <= 25.5) {
                                    if (fs[64] <= -498.0) {
                                        return 0.0807881798688;
                                    } else {
                                        return 0.134960322512;
                                    }
                                } else {
                                    return -0.0346402288936;
                                }
                            } else {
                                return 0.00652975890321;
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                return 0.0354442317244;
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.233568402854;
                                    } else {
                                        return 0.0985080206053;
                                    }
                                } else {
                                    if (fs[72] <= 4998.0) {
                                        return 0.232559252153;
                                    } else {
                                        return 0.184931246099;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[12] <= 0.5) {
                    if (fs[52] <= 0.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[0] <= 9.5) {
                                return 0.00464227402105;
                            } else {
                                return -0.0582095815474;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -480.5) {
                                    return -0.0102285229306;
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0794349151317;
                                    } else {
                                        return -0.00894705982302;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    return -0.0610172135866;
                                } else {
                                    return -0.0824854098927;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[90] <= 0.5) {
                                return 0.0405982746328;
                            } else {
                                if (fs[76] <= 250.0) {
                                    return -0.080701607131;
                                } else {
                                    return -0.1341893527;
                                }
                            }
                        } else {
                            if (fs[88] <= 3.0) {
                                if (fs[90] <= 0.5) {
                                    if (fs[101] <= 1.5) {
                                        return -0.0462194572932;
                                    } else {
                                        return 0.0272253671065;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.329964901042;
                                    } else {
                                        return -0.00275732666139;
                                    }
                                }
                            } else {
                                return 0.208738279635;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 17.5) {
                        if (fs[47] <= -5.5) {
                            return -0.126816647016;
                        } else {
                            if (fs[4] <= 12.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0938063492412;
                                    } else {
                                        return 0.0780244278502;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.156663012134;
                                    } else {
                                        return 0.186342129761;
                                    }
                                }
                            } else {
                                return 0.319803182391;
                            }
                        }
                    } else {
                        if (fs[4] <= 27.5) {
                            if (fs[0] <= 2.5) {
                                return -0.106866006915;
                            } else {
                                return -0.0470762667462;
                            }
                        } else {
                            return 0.0254745663243;
                        }
                    }
                }
            }
        }
    }
}
