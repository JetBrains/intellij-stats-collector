/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree54 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[30] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[53] <= -1138.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.118504213306;
                                    } else {
                                        return -0.128283569369;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.00631719344991;
                                    } else {
                                        return 0.154994017788;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.0) {
                                    if (fs[70] <= -1.5) {
                                        return 0.180120607123;
                                    } else {
                                        return 0.0699078048788;
                                    }
                                } else {
                                    if (fs[53] <= -1563.0) {
                                        return -0.00181063776511;
                                    } else {
                                        return -0.106026918991;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 22.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.0615010214617;
                                    } else {
                                        return 0.273676445197;
                                    }
                                } else {
                                    return -0.16658402662;
                                }
                            } else {
                                return -0.0720426789395;
                            }
                        }
                    } else {
                        if (fs[27] <= 0.5) {
                            if (fs[4] <= 16.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0725249534511;
                                    } else {
                                        return 0.0195276216398;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.17180365051;
                                    } else {
                                        return 0.0819146741307;
                                    }
                                }
                            } else {
                                return -0.177595914516;
                            }
                        } else {
                            if (fs[14] <= 0.5) {
                                if (fs[72] <= 5000.0) {
                                    return 0.0918094828212;
                                } else {
                                    return 0.17903493609;
                                }
                            } else {
                                if (fs[72] <= 5000.0) {
                                    return 0.196363500611;
                                } else {
                                    return 0.155678451147;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 2.5) {
                        return 0.166579790554;
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[0] <= 25.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0737650550324;
                                    } else {
                                        return 0.0218042985072;
                                    }
                                } else {
                                    if (fs[0] <= 24.5) {
                                        return 0.0638814118576;
                                    } else {
                                        return 0.520576267355;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.0518564926089;
                                    } else {
                                        return -0.0726993986658;
                                    }
                                } else {
                                    return -0.0101637067312;
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0137119697634;
                                    } else {
                                        return 0.165926160928;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.0844393511786;
                                    } else {
                                        return -0.0277993047467;
                                    }
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[0] <= 7.5) {
                                        return -0.0298285062551;
                                    } else {
                                        return 0.0150968221162;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0084605871198;
                                    } else {
                                        return 0.0114565911373;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[78] <= 0.5) {
                            if (fs[53] <= -1138.0) {
                                if (fs[2] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0316975083854;
                                    } else {
                                        return 0.173167564613;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0924844507857;
                                    } else {
                                        return 0.066125453853;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[53] <= -1128.0) {
                                        return 0.0592483552694;
                                    } else {
                                        return 0.0743688108485;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0332372434142;
                                    } else {
                                        return 0.0714632493086;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0907186196967;
                                    } else {
                                        return 0.0696895992763;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0501612558264;
                                    } else {
                                        return 0.067621740517;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return 0.0398138221827;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0693879133585;
                                    } else {
                                        return 0.0644768428103;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[53] <= -1138.0) {
                                if (fs[2] <= 1.5) {
                                    return -0.156303333431;
                                } else {
                                    return -0.196242557985;
                                }
                            } else {
                                return 0.0853094361232;
                            }
                        } else {
                            return 0.0883618859981;
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[53] <= -1138.0) {
                            return 0.136044028616;
                        } else {
                            return 0.168984056098;
                        }
                    } else {
                        return 0.291076082966;
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[76] <= 25.0) {
                    if (fs[70] <= -3.5) {
                        if (fs[88] <= -0.5) {
                            return -0.406767663893;
                        } else {
                            if (fs[4] <= 15.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[53] <= -495.5) {
                                        return 0.142921045521;
                                    } else {
                                        return 0.0636129554616;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.178201103909;
                                    } else {
                                        return 0.0780249868742;
                                    }
                                }
                            } else {
                                if (fs[4] <= 25.5) {
                                    if (fs[88] <= 7.5) {
                                        return -0.08561786711;
                                    } else {
                                        return 0.346196791938;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.231243343076;
                                    } else {
                                        return 0.0565486219053;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[53] <= -1238.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[47] <= -97.0) {
                                        return 0.240199101794;
                                    } else {
                                        return -0.00311357311512;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.201991313147;
                                    } else {
                                        return 0.412206136812;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[47] <= -17.5) {
                                        return 0.146063273449;
                                    } else {
                                        return 0.0634882907515;
                                    }
                                } else {
                                    if (fs[64] <= -994.5) {
                                        return 0.129785000462;
                                    } else {
                                        return 0.0128387234839;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0177377894396;
                                    } else {
                                        return 0.0761683740045;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0859743608809;
                                    } else {
                                        return 0.00445970036743;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    if (fs[53] <= -977.0) {
                                        return 0.0715444996486;
                                    } else {
                                        return 0.0116195282964;
                                    }
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return 0.35900607987;
                                    } else {
                                        return -0.0393449185332;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -1493.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.124310990247;
                                    } else {
                                        return 0.232595479267;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.079620415912;
                                    } else {
                                        return -0.0608651090303;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9994.5) {
                                    if (fs[53] <= -1593.5) {
                                        return 0.187180708438;
                                    } else {
                                        return 0.12369315453;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.051740532858;
                                    } else {
                                        return 0.219129559771;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1488.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0223983246291;
                                    } else {
                                        return 0.114707176556;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0915492261942;
                                    } else {
                                        return 0.0402177240207;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0461898671502;
                                    } else {
                                        return -0.0289748986467;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.224209965383;
                                    } else {
                                        return 0.180534053208;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 27.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return 0.0631994940995;
                                    } else {
                                        return 0.132766101041;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0381109712347;
                                    } else {
                                        return 0.0294207420433;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    return -0.327480453375;
                                } else {
                                    return -0.0989813075764;
                                }
                            }
                        } else {
                            if (fs[47] <= -12.5) {
                                if (fs[2] <= 3.5) {
                                    return 0.126328809719;
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.146653439049;
                                    } else {
                                        return 0.276850300746;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1478.0) {
                                    if (fs[14] <= 0.5) {
                                        return -0.142550296493;
                                    } else {
                                        return 0.345605916106;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.109435992075;
                                    } else {
                                        return -0.0228888888364;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[47] <= -364.5) {
                    if (fs[84] <= 0.5) {
                        if (fs[101] <= 0.5) {
                            if (fs[53] <= -1092.5) {
                                if (fs[53] <= -1443.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.0590130777866;
                                    } else {
                                        return 0.125597327433;
                                    }
                                } else {
                                    if (fs[53] <= -1438.0) {
                                        return 0.261872715508;
                                    } else {
                                        return 0.455112201505;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[72] <= 9981.5) {
                                        return 0.0134101064647;
                                    } else {
                                        return 0.35761691676;
                                    }
                                } else {
                                    if (fs[53] <= 3.5) {
                                        return -0.0438394716365;
                                    } else {
                                        return -0.0239424746154;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9991.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.0227354867564;
                                    } else {
                                        return -0.0132753064943;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.0798140884142;
                                    } else {
                                        return 0.0616119594818;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.00787403168573;
                                    } else {
                                        return -0.146968115718;
                                    }
                                } else {
                                    return 0.134385744229;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 10.5) {
                            if (fs[64] <= -997.5) {
                                return 0.328124211608;
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[88] <= 5.0) {
                                        return -0.00585560259714;
                                    } else {
                                        return -0.0245698729595;
                                    }
                                } else {
                                    if (fs[53] <= -21.0) {
                                        return -0.0174950782893;
                                    } else {
                                        return 0.0985327411328;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= 3.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[47] <= -2900.0) {
                                        return 0.0433873049115;
                                    } else {
                                        return -0.109953171169;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0496297878657;
                                    } else {
                                        return -0.0236266865624;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[4] <= 12.5) {
                                        return -0.0123449658799;
                                    } else {
                                        return -0.010602304288;
                                    }
                                } else {
                                    return -0.0136068602156;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[55] <= 0.5) {
                                    if (fs[53] <= -1478.5) {
                                        return 0.0396975427671;
                                    } else {
                                        return 0.0110528830393;
                                    }
                                } else {
                                    return 0.355271005451;
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[47] <= -32.5) {
                                        return 0.290274556651;
                                    } else {
                                        return -0.00240701794503;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.160251573924;
                                    } else {
                                        return 0.0317643006391;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 21.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return -0.00706318127426;
                                    } else {
                                        return -0.0622022774451;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.00207626484216;
                                    } else {
                                        return 0.0278700243653;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[72] <= 9958.5) {
                                        return -0.0214850764709;
                                    } else {
                                        return -0.10027728481;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return 0.188469169606;
                                    } else {
                                        return 0.0268417040152;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 7.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0041888019967;
                                    } else {
                                        return 0.0682941551367;
                                    }
                                } else {
                                    if (fs[47] <= -92.5) {
                                        return 0.0448561763494;
                                    } else {
                                        return -0.00436334245561;
                                    }
                                }
                            } else {
                                if (fs[55] <= 998.0) {
                                    if (fs[2] <= 3.5) {
                                        return -0.00401674019614;
                                    } else {
                                        return -0.00216481889367;
                                    }
                                } else {
                                    return 0.148226457801;
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.101162933395;
                                    } else {
                                        return -0.0296481135146;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0724532073238;
                                    } else {
                                        return 0.28077858446;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    return -0.0383570239393;
                                } else {
                                    if (fs[88] <= 1.0) {
                                        return -0.0111983906775;
                                    } else {
                                        return -0.0250064505145;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
