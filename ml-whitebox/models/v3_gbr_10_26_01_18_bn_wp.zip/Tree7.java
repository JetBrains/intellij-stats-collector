/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree7 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[81] <= 0.5) {
                if (fs[101] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.583164436507;
                                    } else {
                                        return 0.415096487428;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.617005481974;
                                    } else {
                                        return 0.649855105751;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.364050749215;
                                    } else {
                                        return 0.684197932695;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.623509574448;
                                    } else {
                                        return 0.658917234497;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -983.0) {
                                if (fs[71] <= 0.5) {
                                    if (fs[53] <= -1118.5) {
                                        return 0.66657719443;
                                    } else {
                                        return 0.684246401964;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.660002639829;
                                    } else {
                                        return 0.643485198798;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0527791403144;
                                    } else {
                                        return 0.490541016301;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.460187368008;
                                    } else {
                                        return 0.659785236214;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.16517566192;
                                    } else {
                                        return 0.0645169619176;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.0544520118543;
                                    } else {
                                        return 0.00581285977417;
                                    }
                                }
                            } else {
                                if (fs[15] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0453387965307;
                                    } else {
                                        return 0.112474595494;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.015113814952;
                                    } else {
                                        return 0.0705745265783;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -1053.0) {
                                        return 0.0894202532996;
                                    } else {
                                        return -0.0379850633261;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.3757629203;
                                    } else {
                                        return 0.094038475625;
                                    }
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0560620264128;
                                    } else {
                                        return -0.0267056153686;
                                    }
                                } else {
                                    if (fs[53] <= -566.5) {
                                        return 0.21125632337;
                                    } else {
                                        return -0.0382154302376;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[78] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            return 0.228963991518;
                        } else {
                            return -0.00626207022544;
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[53] <= -1328.0) {
                                    if (fs[4] <= 40.5) {
                                        return 0.0117916003525;
                                    } else {
                                        return -0.0727934163809;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.428299637752;
                                    } else {
                                        return -0.104841141201;
                                    }
                                }
                            } else {
                                return 0.221276131041;
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[53] <= -1578.0) {
                                        return -0.0165018977562;
                                    } else {
                                        return -0.0427182857201;
                                    }
                                } else {
                                    return 0.00617515050239;
                                }
                            } else {
                                if (fs[4] <= 90.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0588651482994;
                                    } else {
                                        return -0.0445273844405;
                                    }
                                } else {
                                    return 0.0243842335421;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[64] <= -997.5) {
                    if (fs[64] <= -998.5) {
                        if (fs[53] <= -1098.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.361822612326;
                                    } else {
                                        return 0.614985760149;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.727426276827;
                                    } else {
                                        return 0.65885041756;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.127723146315;
                                    } else {
                                        return -0.0580597106652;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.106738858743;
                                    } else {
                                        return 0.544142341179;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.636516826703;
                                    } else {
                                        return 0.107297105279;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.330027031746;
                                    } else {
                                        return -0.0216202108865;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    return -0.051844856515;
                                } else {
                                    return -0.0417545244202;
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.217340624518;
                                    } else {
                                        return 0.537051966402;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.607107149683;
                                    } else {
                                        return 0.649409493061;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0957608031528;
                                    } else {
                                        return -0.00820983162388;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.013080864391;
                                    } else {
                                        return 0.265819823052;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[47] <= -10.5) {
                                    return 0.0536697334625;
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0267632387025;
                                    } else {
                                        return -0.0445058579121;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    return -0.0430700648028;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0537668263265;
                                    } else {
                                        return -0.0465464969034;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[103] <= 1.5) {
                        if (fs[72] <= 9774.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[47] <= -251.5) {
                                    if (fs[47] <= -3534.0) {
                                        return 0.320070948312;
                                    } else {
                                        return 0.0701584484442;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.0203355211221;
                                    } else {
                                        return -0.0345962538698;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1083.5) {
                                    if (fs[53] <= -1418.0) {
                                        return 0.192260514491;
                                    } else {
                                        return 0.0678805974677;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.421762375806;
                                    } else {
                                        return -0.0293675449435;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.345200044178;
                                    } else {
                                        return 0.549484342545;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.498710405065;
                                    } else {
                                        return 0.206875920876;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.0834418949806;
                                    } else {
                                        return 0.34783759665;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0163746295897;
                                    } else {
                                        return 0.011147622318;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[27] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.571485183492;
                                    } else {
                                        return 0.2971603494;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.125377124122;
                                    } else {
                                        return 0.576479840093;
                                    }
                                }
                            } else {
                                if (fs[49] <= -3.5) {
                                    return 0.285002388257;
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.604522248514;
                                    } else {
                                        return 0.632795528789;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1068.0) {
                                if (fs[58] <= 0.5) {
                                    if (fs[0] <= 21.5) {
                                        return 0.123386676444;
                                    } else {
                                        return 0.637240701015;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return -0.0371810822939;
                                    } else {
                                        return 0.0432782751041;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[64] <= -996.5) {
                                        return 0.0244362808087;
                                    } else {
                                        return -0.0356511284901;
                                    }
                                } else {
                                    if (fs[62] <= -2.5) {
                                        return 0.0952564993466;
                                    } else {
                                        return -0.040747261553;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[53] <= -1052.5) {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 8.5) {
                        if (fs[28] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1473.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.47880837698;
                                    } else {
                                        return 0.599455881329;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.608535004053;
                                    } else {
                                        return 0.497153987443;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.667216701028;
                                    } else {
                                        return 0.624434626276;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.616058416066;
                                    } else {
                                        return 0.457759942703;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                return 0.154715054985;
                            } else {
                                return 0.37863069015;
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[93] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 30.5) {
                                        return 0.616299600188;
                                    } else {
                                        return 0.193220452535;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.381888651035;
                                    } else {
                                        return 0.520758878472;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    return -0.154787124304;
                                } else {
                                    return 0.00532057505537;
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[29] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.157373881775;
                                    } else {
                                        return 0.558986573924;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.195106307378;
                                    } else {
                                        return 0.488366643957;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[53] <= -1578.0) {
                                        return 0.655373942627;
                                    } else {
                                        return 0.418598127461;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.229928554745;
                                    } else {
                                        return 0.402090325958;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1408.0) {
                        if (fs[72] <= 9999.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.115228502702;
                                    } else {
                                        return 0.354801500332;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.152824311413;
                                    } else {
                                        return 0.357705663493;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[47] <= -76.0) {
                                        return 0.29587065802;
                                    } else {
                                        return 0.099663310268;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0972537720205;
                                    } else {
                                        return -0.0648609876864;
                                    }
                                }
                            }
                        } else {
                            if (fs[66] <= 5.0) {
                                if (fs[47] <= -85.0) {
                                    if (fs[47] <= -97.0) {
                                        return 0.450935381669;
                                    } else {
                                        return 0.749297973435;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.364568571456;
                                    } else {
                                        return -0.0827202821282;
                                    }
                                }
                            } else {
                                return -0.0774660478202;
                            }
                        }
                    } else {
                        if (fs[53] <= -1138.0) {
                            if (fs[4] <= 4.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[0] <= 8.5) {
                                        return 0.264078471966;
                                    } else {
                                        return 0.0327422092542;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.496651482483;
                                    } else {
                                        return 0.0927522952302;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[47] <= -8.0) {
                                        return 0.434664271034;
                                    } else {
                                        return -0.0176231634562;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0707221569314;
                                    } else {
                                        return 0.148613799024;
                                    }
                                }
                            }
                        } else {
                            if (fs[74] <= 0.5) {
                                if (fs[53] <= -1123.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.104010535418;
                                    } else {
                                        return 0.286516458513;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.113266151889;
                                    } else {
                                        return 0.559737204953;
                                    }
                                }
                            } else {
                                return 0.765624066156;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.191902270161;
                                    } else {
                                        return 0.0759972555404;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.469120133484;
                                    } else {
                                        return 0.711169873316;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.333333101249;
                                    } else {
                                        return 0.496988993367;
                                    }
                                } else {
                                    if (fs[88] <= 1.0) {
                                        return 0.665501258724;
                                    } else {
                                        return 0.565625529587;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.656117532373;
                                    } else {
                                        return 0.716358967337;
                                    }
                                } else {
                                    return 0.552852642786;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[47] <= -7.5) {
                                        return 0.536141932241;
                                    } else {
                                        return 0.306544834585;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0734781464615;
                                    } else {
                                        return 0.196759271359;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[101] <= 1.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[47] <= -47.0) {
                                        return 0.56151435025;
                                    } else {
                                        return 0.646309534015;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.522964867107;
                                    } else {
                                        return 0.679495691455;
                                    }
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    if (fs[47] <= -4.5) {
                                        return 0.665879867456;
                                    } else {
                                        return 0.707314522326;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.689789164028;
                                    } else {
                                        return 0.377666961418;
                                    }
                                }
                            }
                        } else {
                            if (fs[64] <= -498.0) {
                                if (fs[101] <= 1.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.677795470351;
                                    } else {
                                        return 0.614825314362;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.716771707514;
                                    } else {
                                        return 0.709267540358;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.585236532253;
                                    } else {
                                        return 0.316976319718;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.401629257733;
                                    } else {
                                        return 0.237130523988;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[103] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[47] <= -3.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.314832732324;
                                    } else {
                                        return 0.159031805603;
                                    }
                                } else {
                                    if (fs[47] <= -20.0) {
                                        return -0.0287146587031;
                                    } else {
                                        return 0.149121486261;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0925135129245;
                                    } else {
                                        return 0.165002801542;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.110130752504;
                                    } else {
                                        return -0.0131046481165;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.0138072544011;
                                    } else {
                                        return 0.13768383877;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.116736751223;
                                    } else {
                                        return 0.0111800630106;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[53] <= -976.5) {
                                        return -0.0332411608496;
                                    } else {
                                        return -0.0447280325758;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0527522569653;
                                    } else {
                                        return 0.172618076031;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[8] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 5.5) {
                                    return 0.0955504657545;
                                } else {
                                    if (fs[53] <= 17.5) {
                                        return -0.0320000769856;
                                    } else {
                                        return 0.0876374173827;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[47] <= -0.5) {
                                        return -0.0421894616888;
                                    } else {
                                        return -0.00352308565115;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0277435665818;
                                    } else {
                                        return -0.0402410764622;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                return 0.144818864086;
                            } else {
                                return 0.315590870967;
                            }
                        }
                    }
                }
            }
        }
    }
}
