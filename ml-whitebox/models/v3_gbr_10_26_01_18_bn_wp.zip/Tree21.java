/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree21 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[0] <= 0.5) {
                if (fs[22] <= 0.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[74] <= 0.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[76] <= 100.0) {
                                        return 0.250297822734;
                                    } else {
                                        return 0.0102763700175;
                                    }
                                } else {
                                    if (fs[72] <= 4984.0) {
                                        return 0.325883415576;
                                    } else {
                                        return -0.124153441123;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[92] <= 0.5) {
                                        return 0.362251357818;
                                    } else {
                                        return 0.123139530021;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.27482554529;
                                    } else {
                                        return 0.203810654219;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9902.0) {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1118.5) {
                                        return -0.0439824239325;
                                    } else {
                                        return 0.361707769222;
                                    }
                                } else {
                                    return -0.0501954278739;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.271059436943;
                                    } else {
                                        return 0.499697920226;
                                    }
                                } else {
                                    return -0.0238053011865;
                                }
                            }
                        }
                    } else {
                        if (fs[28] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.318838992674;
                                    } else {
                                        return 0.384299612076;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.275976837102;
                                    } else {
                                        return 0.202620914215;
                                    }
                                }
                            } else {
                                if (fs[51] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.111868190678;
                                    } else {
                                        return 0.341485092791;
                                    }
                                } else {
                                    return 0.477586005183;
                                }
                            }
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    return 0.146537995617;
                                } else {
                                    return -0.10900293057;
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    return -0.406525525739;
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return -0.356129130328;
                                    } else {
                                        return -0.0583579419267;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 25.0) {
                        if (fs[48] <= 0.5) {
                            if (fs[47] <= -135.0) {
                                if (fs[60] <= 0.5) {
                                    if (fs[72] <= 9869.5) {
                                        return 0.432865257972;
                                    } else {
                                        return 0.0207523375246;
                                    }
                                } else {
                                    if (fs[47] <= -524.5) {
                                        return 0.271792547878;
                                    } else {
                                        return 0.494310496212;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.00929621192563;
                                    } else {
                                        return 0.227264874991;
                                    }
                                } else {
                                    if (fs[72] <= 9339.0) {
                                        return 0.518194004307;
                                    } else {
                                        return 0.119262075625;
                                    }
                                }
                            }
                        } else {
                            if (fs[101] <= 0.5) {
                                if (fs[88] <= 6.0) {
                                    if (fs[72] <= 9393.0) {
                                        return -0.09953161405;
                                    } else {
                                        return 0.0985305808337;
                                    }
                                } else {
                                    if (fs[72] <= 9986.5) {
                                        return 0.396663909658;
                                    } else {
                                        return 0.21562777887;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    return -0.207925261855;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.356525931371;
                                    } else {
                                        return 0.187537209684;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.426631480967;
                                    } else {
                                        return 0.229980001876;
                                    }
                                } else {
                                    if (fs[53] <= -1478.5) {
                                        return 0.370546104315;
                                    } else {
                                        return 0.237236758993;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1478.5) {
                                        return 0.0356490916267;
                                    } else {
                                        return 0.254583968191;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.250830161351;
                                    } else {
                                        return 0.0171566446026;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 5.5) {
                                if (fs[2] <= 5.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.324997263311;
                                    } else {
                                        return 0.114898564506;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.376509426333;
                                    } else {
                                        return 0.170540986989;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.182604498635;
                                    } else {
                                        return 0.136240561162;
                                    }
                                } else {
                                    if (fs[47] <= -364.5) {
                                        return 0.435733320857;
                                    } else {
                                        return 0.221566972101;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[88] <= 7.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[4] <= 19.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.0687567119807;
                                    } else {
                                        return 0.0249102708023;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0374512208808;
                                    } else {
                                        return -0.0309234402155;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0677463823561;
                                    } else {
                                        return -0.0407744818006;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return -0.0208948271523;
                                    } else {
                                        return 0.105377513723;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 1.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[47] <= -2.5) {
                                        return 0.131008761165;
                                    } else {
                                        return -0.0380081410785;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.0597447339401;
                                    } else {
                                        return 0.399381393404;
                                    }
                                }
                            } else {
                                if (fs[47] <= -68.5) {
                                    if (fs[88] <= 4.5) {
                                        return 0.275740602596;
                                    } else {
                                        return 0.0665101289478;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.00615471820207;
                                    } else {
                                        return 0.0721175686813;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 75.0) {
                            if (fs[68] <= 1.5) {
                                if (fs[53] <= -1088.0) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00636974089476;
                                    } else {
                                        return -0.0597554730661;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.000208205796569;
                                    } else {
                                        return 0.197208523065;
                                    }
                                }
                            } else {
                                return 0.228224205638;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[72] <= 9888.5) {
                                        return 0.161962879779;
                                    } else {
                                        return 0.343345088383;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0398757666271;
                                    } else {
                                        return -0.130922781452;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -1488.0) {
                                        return -0.239483385315;
                                    } else {
                                        return -0.153392304631;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0882506168547;
                                    } else {
                                        return 0.406519137155;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[12] <= 0.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    return 0.408020537971;
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.0092119021143;
                                    } else {
                                        return 0.110274582786;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[76] <= 100.0) {
                                        return -0.028615056925;
                                    } else {
                                        return -0.019980889159;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0319088373248;
                                    } else {
                                        return -0.0232056117891;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.0172792514152;
                                    } else {
                                        return -0.00376974944415;
                                    }
                                } else {
                                    if (fs[53] <= -1383.0) {
                                        return 0.0667318306507;
                                    } else {
                                        return -0.0121314270319;
                                    }
                                }
                            } else {
                                if (fs[47] <= -41427.0) {
                                    if (fs[47] <= -43344.5) {
                                        return -0.0772975886114;
                                    } else {
                                        return 0.58626185477;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0190784555689;
                                    } else {
                                        return -0.0214342287325;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[101] <= 1.5) {
                                        return -0.00817547451114;
                                    } else {
                                        return 0.00753782841223;
                                    }
                                } else {
                                    if (fs[47] <= -104.0) {
                                        return 0.0810654258444;
                                    } else {
                                        return -0.0199408158374;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[64] <= -996.5) {
                                        return 0.194156185441;
                                    } else {
                                        return 0.0478718811795;
                                    }
                                } else {
                                    if (fs[0] <= 101.5) {
                                        return 0.00676270922235;
                                    } else {
                                        return 0.247220809952;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[47] <= -2.5) {
                                    if (fs[47] <= -103.5) {
                                        return -0.0399538392508;
                                    } else {
                                        return -0.0276302321603;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return -0.00224626742001;
                                    } else {
                                        return -0.0206595465796;
                                    }
                                }
                            } else {
                                if (fs[47] <= -11.5) {
                                    if (fs[88] <= 5.5) {
                                        return -0.0309400810399;
                                    } else {
                                        return 4.33272463929e-05;
                                    }
                                } else {
                                    if (fs[72] <= 9637.0) {
                                        return -0.0231950134843;
                                    } else {
                                        return -0.0314833048922;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[71] <= 0.5) {
                    if (fs[88] <= 1.5) {
                        if (fs[53] <= -1513.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[72] <= 9998.5) {
                                    return 0.3117546566;
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.495291358236;
                                    } else {
                                        return 0.409323937477;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    return 0.302010856071;
                                } else {
                                    if (fs[4] <= 20.0) {
                                        return 0.254907601975;
                                    } else {
                                        return 0.488285834467;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= -0.5) {
                                if (fs[90] <= 0.5) {
                                    return -0.133554022708;
                                } else {
                                    return -0.271420741921;
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.135373985766;
                                    } else {
                                        return 0.264438175282;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.330877714675;
                                    } else {
                                        return 0.238404158927;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[88] <= 5.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.134785592634;
                                    } else {
                                        return -0.0386478026218;
                                    }
                                } else {
                                    if (fs[88] <= 2.5) {
                                        return 0.400511582589;
                                    } else {
                                        return 0.21494921319;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.0) {
                                    if (fs[4] <= 13.5) {
                                        return 0.333867897857;
                                    } else {
                                        return 0.557969909654;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0593147239885;
                                    } else {
                                        return 0.272969304659;
                                    }
                                }
                            }
                        } else {
                            if (fs[94] <= 0.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.33352652424;
                                    } else {
                                        return 0.380824348458;
                                    }
                                } else {
                                    return -0.0753948145106;
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    return 0.386327674253;
                                } else {
                                    return 0.563176571795;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[47] <= -7.5) {
                            if (fs[88] <= 3.0) {
                                if (fs[29] <= 0.5) {
                                    if (fs[72] <= 9998.5) {
                                        return 0.0880018677644;
                                    } else {
                                        return 0.297546215523;
                                    }
                                } else {
                                    return 0.0781502929108;
                                }
                            } else {
                                if (fs[53] <= -546.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.258681367095;
                                    } else {
                                        return 0.394830698006;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0251725737171;
                                    } else {
                                        return 0.204432087013;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.26480419008;
                                    } else {
                                        return 0.0624667167434;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return 0.140888321314;
                                    } else {
                                        return 0.406110411851;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.138063912507;
                                    } else {
                                        return 0.326919215277;
                                    }
                                } else {
                                    if (fs[88] <= 1.5) {
                                        return 0.0447469944835;
                                    } else {
                                        return 0.117228719835;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[47] <= -23.5) {
                                        return 0.383154815841;
                                    } else {
                                        return 0.308229233738;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.312501172779;
                                    } else {
                                        return -0.0419534426731;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.304337440775;
                                    } else {
                                        return 0.185677989778;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.180171800328;
                                    } else {
                                        return 0.374427220498;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[7] <= 0.5) {
                                    if (fs[72] <= 9998.5) {
                                        return 0.353755212183;
                                    } else {
                                        return 0.274763866824;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.144966662248;
                                    } else {
                                        return -0.342739795295;
                                    }
                                }
                            } else {
                                if (fs[49] <= -0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.351458637366;
                                    } else {
                                        return 0.399002946553;
                                    }
                                } else {
                                    if (fs[63] <= 0.5) {
                                        return 0.113843705617;
                                    } else {
                                        return -0.324487559672;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1277.5) {
                    if (fs[55] <= 546.5) {
                        if (fs[72] <= 9999.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[47] <= -94.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.147852992658;
                                    } else {
                                        return 0.328093154892;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0412493234749;
                                    } else {
                                        return 0.241619277852;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[72] <= 9998.5) {
                                        return 0.331906172535;
                                    } else {
                                        return 0.254831871269;
                                    }
                                } else {
                                    return 0.228311114013;
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[66] <= 5.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.346850618223;
                                    } else {
                                        return 0.203186976088;
                                    }
                                } else {
                                    if (fs[88] <= 2.5) {
                                        return -0.247055259287;
                                    } else {
                                        return -0.0397777650576;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    return -0.2297695111;
                                } else {
                                    return -0.191008238846;
                                }
                            }
                        }
                    } else {
                        return 0.602673382958;
                    }
                } else {
                    if (fs[53] <= -1082.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[4] <= 3.5) {
                                    return 0.0689143435636;
                                } else {
                                    if (fs[88] <= 1.0) {
                                        return 0.353998809869;
                                    } else {
                                        return 0.141452722824;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[70] <= -4.0) {
                                        return 0.26464169121;
                                    } else {
                                        return -0.0387551228287;
                                    }
                                } else {
                                    return 0.24203130246;
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0767126089303;
                                    } else {
                                        return 0.0106987241112;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return 0.0903682857931;
                                    } else {
                                        return 0.361798319771;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[48] <= 0.5) {
                                        return 0.722843188784;
                                    } else {
                                        return 0.23460425761;
                                    }
                                } else {
                                    return 0.719478816112;
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[0] <= 1.5) {
                                if (fs[47] <= -3.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.201021745817;
                                    } else {
                                        return 0.0726010761331;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.112441804298;
                                    } else {
                                        return 0.0395892463251;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[70] <= -4.5) {
                                        return 0.190585120586;
                                    } else {
                                        return 0.0467728268342;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.0019754790854;
                                    } else {
                                        return 0.177995059973;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -1188.0) {
                                if (fs[60] <= 0.5) {
                                    return 0.454781795931;
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.0594102493277;
                                    } else {
                                        return -0.0857080204615;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.0198511125719;
                                    } else {
                                        return -0.0477371400258;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0931166512391;
                                    } else {
                                        return 0.274786035108;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
