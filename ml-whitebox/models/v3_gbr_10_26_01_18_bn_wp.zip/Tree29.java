/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree29 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[103] <= 1.5) {
                if (fs[30] <= 0.5) {
                    if (fs[15] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[76] <= 100.0) {
                                        return 0.182243309289;
                                    } else {
                                        return -0.0653323490307;
                                    }
                                } else {
                                    if (fs[53] <= -1504.0) {
                                        return 0.231628308417;
                                    } else {
                                        return 0.0720962640224;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.223014394021;
                                    } else {
                                        return 0.134977456342;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.175989129736;
                                    } else {
                                        return 0.0980375029055;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9867.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.00852459680107;
                                    } else {
                                        return -0.0259222445048;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.00888811117484;
                                    } else {
                                        return -0.0132080154358;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0341379067957;
                                    } else {
                                        return 0.37337919353;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.00564657114107;
                                    } else {
                                        return 0.106435742811;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -983.0) {
                            if (fs[2] <= 1.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.169671097055;
                                    } else {
                                        return 0.240024928893;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.00315459871371;
                                    } else {
                                        return 0.0737823459096;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.217279919204;
                                    } else {
                                        return 0.224652034295;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0514465581507;
                                    } else {
                                        return -0.017142216413;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                return -0.0758775780394;
                            } else {
                                if (fs[2] <= 1.5) {
                                    return -0.00389765087671;
                                } else {
                                    return 0.174327639082;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1113.5) {
                                    return 0.20122644551;
                                } else {
                                    return 0.0342640024492;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return 0.230293778394;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.219377552092;
                                    } else {
                                        return 0.215764123914;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[53] <= -1128.0) {
                                    if (fs[2] <= 2.5) {
                                        return 0.20092709107;
                                    } else {
                                        return 0.221529418097;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.238435556665;
                                    } else {
                                        return 0.224098234916;
                                    }
                                }
                            } else {
                                return 0.0331030045553;
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -1138.0) {
                                return 0.359045624515;
                            } else {
                                return 0.424342928522;
                            }
                        } else {
                            return 0.372364631229;
                        }
                    }
                }
            } else {
                if (fs[53] <= -1033.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[64] <= -996.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[49] <= -1.5) {
                                    return 0.134649427265;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.214890918725;
                                    } else {
                                        return 0.156785159511;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[64] <= -998.5) {
                                        return 0.247665272661;
                                    } else {
                                        return 0.234302246757;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.225108909681;
                                    } else {
                                        return 0.263007806422;
                                    }
                                }
                            }
                        } else {
                            if (fs[58] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 20.5) {
                                        return 0.203320059301;
                                    } else {
                                        return 0.0976219902148;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.141672011102;
                                    } else {
                                        return 0.187046191238;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.134548148229;
                                    } else {
                                        return -0.125215413717;
                                    }
                                } else {
                                    return -0.00941871513519;
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[0] <= 21.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.285255370133;
                                    } else {
                                        return 0.0440331540353;
                                    }
                                } else {
                                    return 0.600099666508;
                                }
                            } else {
                                if (fs[0] <= 13.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0954234271213;
                                    } else {
                                        return 0.269481689826;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.275375732971;
                                    } else {
                                        return 0.605170175976;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[0] <= 8.5) {
                                    if (fs[2] <= 6.5) {
                                        return -0.0437677420771;
                                    } else {
                                        return 0.240499240147;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.139568410651;
                                    } else {
                                        return -0.0210446142855;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.046778417499;
                                    } else {
                                        return -0.0496170730966;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0568927508263;
                                    } else {
                                        return -0.0906151653762;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[27] <= 0.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 14.0) {
                                    if (fs[0] <= 2.5) {
                                        return 0.490164145803;
                                    } else {
                                        return -0.0672716218018;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.31791224658;
                                    } else {
                                        return 0.0610152172569;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[26] <= 0.5) {
                                        return -0.104334664986;
                                    } else {
                                        return -0.074295109186;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0456071800221;
                                    } else {
                                        return -0.0306972776817;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                return 0.165786248307;
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[62] <= -2.5) {
                                        return -0.040060061157;
                                    } else {
                                        return -0.0143473033671;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return -0.0181960822615;
                                    } else {
                                        return -0.00471773266726;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[49] <= -0.5) {
                                return 0.272113457796;
                            } else {
                                return 0.0640713458205;
                            }
                        } else {
                            if (fs[53] <= 17.5) {
                                if (fs[62] <= -2.5) {
                                    return 0.0618793943898;
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0119750373429;
                                    } else {
                                        return 0.0116863300023;
                                    }
                                }
                            } else {
                                return 0.0284764510073;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[23] <= 0.5) {
                    if (fs[18] <= -0.5) {
                        if (fs[2] <= 2.5) {
                            return -0.294828544646;
                        } else {
                            return -0.127344665188;
                        }
                    } else {
                        if (fs[53] <= -968.0) {
                            if (fs[4] <= 18.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return 0.213383107689;
                                    } else {
                                        return 0.335858734474;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.0428536290698;
                                    } else {
                                        return -0.0871337311827;
                                    }
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.204970147201;
                                    } else {
                                        return -0.0352815739128;
                                    }
                                } else {
                                    if (fs[4] <= 30.5) {
                                        return 0.178062914762;
                                    } else {
                                        return -0.0159421752448;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                if (fs[88] <= 5.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.1520940543;
                                    } else {
                                        return 0.269456417451;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return 0.100171437695;
                                    } else {
                                        return 0.299607502047;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0451466228016;
                                    } else {
                                        return 0.163019975959;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.0315810849849;
                                    } else {
                                        return -0.150846526981;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -6.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[4] <= 20.5) {
                                if (fs[76] <= 100.0) {
                                    if (fs[70] <= -3.5) {
                                        return 0.291421687584;
                                    } else {
                                        return 0.160404622138;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.372265425043;
                                    } else {
                                        return 0.189124445179;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[4] <= 22.0) {
                                        return -0.106965736215;
                                    } else {
                                        return -0.265010687898;
                                    }
                                } else {
                                    return 0.347295916834;
                                }
                            }
                        } else {
                            if (fs[47] <= -4674.0) {
                                return 0.405043175654;
                            } else {
                                if (fs[4] <= 24.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.237501161089;
                                    } else {
                                        return 0.145772767014;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.289515333741;
                                    } else {
                                        return 0.429566187232;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 5.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.244992031765;
                                    } else {
                                        return 0.17193094412;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0394693609415;
                                    } else {
                                        return 0.143987278803;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.271934795002;
                                    } else {
                                        return 0.112179105129;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.157746563135;
                                    } else {
                                        return 0.0561716595553;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.398403377352;
                                    } else {
                                        return 0.204513247578;
                                    }
                                } else {
                                    if (fs[70] <= -4.5) {
                                        return 0.267190718945;
                                    } else {
                                        return 0.0755996597809;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.0268495042554;
                                    } else {
                                        return 0.227074837353;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.303471936597;
                                    } else {
                                        return 0.255228737453;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[45] <= 0.5) {
                    if (fs[53] <= -1268.0) {
                        if (fs[4] <= 32.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[47] <= -80.5) {
                                        return 0.176419451754;
                                    } else {
                                        return 0.038625335218;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.351541899412;
                                    } else {
                                        return 0.0864794044674;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[66] <= 5.0) {
                                        return 0.201334161143;
                                    } else {
                                        return -0.179982835314;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.216026443524;
                                    } else {
                                        return -0.0682295986372;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                return -0.163910100586;
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.0223524372168;
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0749487165763;
                                    } else {
                                        return -0.0929487999853;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[77] <= 0.5) {
                                if (fs[64] <= -995.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.173168130469;
                                    } else {
                                        return 0.508666002246;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.00234861999221;
                                    } else {
                                        return 0.0315501176291;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.111974517802;
                                    } else {
                                        return 0.027000675572;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.347585698503;
                                    } else {
                                        return 0.151827586973;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -3.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.254733773442;
                                    } else {
                                        return -0.0945389892501;
                                    }
                                } else {
                                    return 0.468043759549;
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.084838885342;
                                    } else {
                                        return 0.312880320474;
                                    }
                                } else {
                                    if (fs[4] <= 31.5) {
                                        return 0.00459209293526;
                                    } else {
                                        return 0.508126072304;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1057.0) {
                        return -0.116637401993;
                    } else {
                        if (fs[82] <= 0.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[13] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return -0.0461464400804;
                                    } else {
                                        return -0.0166127422517;
                                    }
                                } else {
                                    return 0.065455107956;
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    return 0.124312166715;
                                } else {
                                    return -0.0478583204637;
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                return -0.0923622870436;
                            } else {
                                return -0.0485810449047;
                            }
                        }
                    }
                }
            }
        }
    }
}
