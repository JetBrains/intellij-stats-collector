/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree82 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[24] <= 0.5) {
                    if (fs[53] <= -1498.5) {
                        if (fs[53] <= -1938.5) {
                            if (fs[48] <= 0.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0842394600998;
                                    } else {
                                        return 0.0887715802064;
                                    }
                                } else {
                                    if (fs[72] <= 4870.5) {
                                        return -0.294164391674;
                                    } else {
                                        return 0.162586063754;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[88] <= 2.5) {
                                        return -0.0732237419381;
                                    } else {
                                        return 0.161711060055;
                                    }
                                } else {
                                    if (fs[64] <= -996.5) {
                                        return -0.110718031989;
                                    } else {
                                        return 0.0910137495229;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[72] <= 9986.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.222216525842;
                                    } else {
                                        return 0.12176386486;
                                    }
                                } else {
                                    if (fs[53] <= -1888.0) {
                                        return -0.0331755884459;
                                    } else {
                                        return 0.150174121658;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0425912608813;
                                    } else {
                                        return 0.115712139128;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.0960068762177;
                                    } else {
                                        return 0.0250479249534;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[84] <= 0.5) {
                                        return -5.11155543544e-05;
                                    } else {
                                        return 0.0175028044383;
                                    }
                                } else {
                                    if (fs[92] <= 0.5) {
                                        return 0.0562707113332;
                                    } else {
                                        return -0.00806542599914;
                                    }
                                }
                            } else {
                                if (fs[32] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0220475508774;
                                    } else {
                                        return -0.168713888701;
                                    }
                                } else {
                                    return -0.31213766559;
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0692792792006;
                                    } else {
                                        return 0.113977660152;
                                    }
                                } else {
                                    return -0.08916918187;
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[64] <= -498.0) {
                                        return 0.0892911852584;
                                    } else {
                                        return 0.25335303664;
                                    }
                                } else {
                                    if (fs[64] <= -498.5) {
                                        return 0.0347677040055;
                                    } else {
                                        return 0.0285911620367;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[101] <= 0.5) {
                        if (fs[88] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[47] <= -5.5) {
                                        return -0.0227619081319;
                                    } else {
                                        return -0.184167491958;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.055773779492;
                                    } else {
                                        return -0.0425598963098;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.110704486486;
                                    } else {
                                        return 0.0678356057884;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0671870103651;
                                    } else {
                                        return -0.016989700027;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 16.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.0892995960694;
                                    } else {
                                        return 0.0198398940162;
                                    }
                                } else {
                                    return -0.290394339722;
                                }
                            } else {
                                return -0.35911244939;
                            }
                        }
                    } else {
                        if (fs[4] <= 6.5) {
                            return -0.00824361986615;
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[47] <= -411478.0) {
                                    return 0.279508720438;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.19598337227;
                                    } else {
                                        return 0.123688028859;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    return 0.127861241673;
                                } else {
                                    return 0.0340287125257;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 9.5) {
                    if (fs[53] <= -2423.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[53] <= -2648.5) {
                                if (fs[53] <= -3373.0) {
                                    return 0.0691629311317;
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.310313279079;
                                    } else {
                                        return 0.171649751662;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    return -0.0290572313347;
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.0245256217635;
                                    } else {
                                        return 0.176927035238;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 24.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[76] <= 250.0) {
                                        return -0.140844970657;
                                    } else {
                                        return -0.364473167412;
                                    }
                                } else {
                                    return -0.121127166218;
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0806946469549;
                                    } else {
                                        return 0.18696907489;
                                    }
                                } else {
                                    return -0.0242094219863;
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[49] <= -1.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.153998204496;
                                    } else {
                                        return 0.295742993191;
                                    }
                                } else {
                                    return 0.133652824047;
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.0262572465977;
                                    } else {
                                        return -0.165975099057;
                                    }
                                } else {
                                    if (fs[72] <= 9927.5) {
                                        return -0.075430159635;
                                    } else {
                                        return -0.0231590602139;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0768257751293;
                                    } else {
                                        return 0.228177826256;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return -0.00767992311235;
                                    } else {
                                        return 0.087829261686;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0244301371872;
                                    } else {
                                        return -0.0844968004463;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.0398667359189;
                                    } else {
                                        return -0.0231215933134;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 25.0) {
                        if (fs[48] <= 0.5) {
                            if (fs[47] <= -16.5) {
                                return -0.13575262654;
                            } else {
                                if (fs[99] <= 0.5) {
                                    return 0.166276784265;
                                } else {
                                    return 0.122569231945;
                                }
                            }
                        } else {
                            if (fs[77] <= 0.5) {
                                if (fs[2] <= 11.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.00908557284367;
                                    } else {
                                        return 0.194132265461;
                                    }
                                } else {
                                    return 0.326798730286;
                                }
                            } else {
                                return 0.0379093973447;
                            }
                        }
                    } else {
                        if (fs[2] <= 16.5) {
                            if (fs[4] <= 27.5) {
                                if (fs[101] <= 1.5) {
                                    if (fs[72] <= 9984.5) {
                                        return 0.187580658221;
                                    } else {
                                        return -0.0328969669545;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.116446518393;
                                    } else {
                                        return 0.225017835522;
                                    }
                                }
                            } else {
                                return -0.191708702485;
                            }
                        } else {
                            if (fs[4] <= 25.5) {
                                return 0.157737603514;
                            } else {
                                return 0.0338959079466;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[55] <= 0.5) {
                if (fs[0] <= 1.5) {
                    if (fs[105] <= 0.5) {
                        if (fs[83] <= 0.5) {
                            if (fs[53] <= -1478.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.000482724472748;
                                    } else {
                                        return 0.0266142567772;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return 0.0771638380282;
                                    } else {
                                        return -0.0460826276898;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00360145917478;
                                    } else {
                                        return 0.0127555453601;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0333863200725;
                                    } else {
                                        return 0.0113300621261;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.0306526119993;
                                    } else {
                                        return 0.251485658728;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0584014373894;
                                    } else {
                                        return -0.0515296767539;
                                    }
                                }
                            } else {
                                return -0.253532104632;
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[53] <= -1573.0) {
                                    return 0.129878980236;
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0160066210068;
                                    } else {
                                        return -0.0653034423615;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0193633892537;
                                    } else {
                                        return 0.0774424415205;
                                    }
                                } else {
                                    if (fs[47] <= -3.5) {
                                        return 0.020456258765;
                                    } else {
                                        return -0.00504846387149;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[47] <= -27.0) {
                                    if (fs[47] <= -372.0) {
                                        return -0.029467586882;
                                    } else {
                                        return 0.325722247541;
                                    }
                                } else {
                                    if (fs[72] <= 9784.5) {
                                        return -0.0103029734804;
                                    } else {
                                        return -0.130881810222;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[72] <= 8779.0) {
                                        return 0.015093472745;
                                    } else {
                                        return -0.157179362129;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.110831392232;
                                    } else {
                                        return -0.0650642339986;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 18.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[0] <= 18.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.00148835154562;
                                    } else {
                                        return -0.00166327402691;
                                    }
                                } else {
                                    if (fs[47] <= -7.5) {
                                        return -0.00502246473443;
                                    } else {
                                        return -0.00112929362205;
                                    }
                                }
                            } else {
                                return 0.231740578303;
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.124789130986;
                                    } else {
                                        return 0.0129502645937;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0479132349516;
                                    } else {
                                        return 0.265302514714;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 7.0) {
                                        return -0.00476889793018;
                                    } else {
                                        return -0.018588967758;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0239543810087;
                                    } else {
                                        return -0.0178244153897;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9998.5) {
                            if (fs[64] <= -996.5) {
                                if (fs[49] <= -2.5) {
                                    return 0.175736985171;
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.0757795484523;
                                    } else {
                                        return 0.00145923810237;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[27] <= 0.5) {
                                        return -0.00162327954973;
                                    } else {
                                        return -0.0161222791409;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0946286723983;
                                    } else {
                                        return -0.0215918114123;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[47] <= -114.5) {
                                    return -0.281346412066;
                                } else {
                                    if (fs[88] <= 1.5) {
                                        return -0.00877594747617;
                                    } else {
                                        return 0.0957189994284;
                                    }
                                }
                            } else {
                                if (fs[4] <= 30.5) {
                                    return -0.0425108098509;
                                } else {
                                    return -0.236302195572;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 5.5) {
                    if (fs[4] <= 10.5) {
                        return 0.26389056277;
                    } else {
                        if (fs[53] <= -42.5) {
                            if (fs[11] <= 0.5) {
                                return 0.309545433369;
                            } else {
                                if (fs[72] <= 9324.0) {
                                    return -0.0428997372338;
                                } else {
                                    return 0.248979463311;
                                }
                            }
                        } else {
                            return -0.0440260272861;
                        }
                    }
                } else {
                    if (fs[85] <= 0.5) {
                        if (fs[0] <= 15.5) {
                            if (fs[4] <= 17.0) {
                                return -0.0324292123517;
                            } else {
                                return -0.0169974361513;
                            }
                        } else {
                            return 0.0144428782985;
                        }
                    } else {
                        if (fs[47] <= -11.0) {
                            return 0.143375866844;
                        } else {
                            if (fs[76] <= 75.0) {
                                return -0.00951098511945;
                            } else {
                                return 0.0479008845645;
                            }
                        }
                    }
                }
            }
        }
    }
}
