/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree95 {
    public double calcTree(double... fs) {
        if (fs[57] <= 0.5) {
            if (fs[64] <= -997.5) {
                if (fs[45] <= 0.5) {
                    if (fs[14] <= 0.5) {
                        if (fs[47] <= -1468.5) {
                            return 0.229894673632;
                        } else {
                            if (fs[53] <= -2198.0) {
                                return -0.185689504304;
                            } else {
                                if (fs[58] <= 0.5) {
                                    if (fs[4] <= 21.5) {
                                        return 0.0293919829998;
                                    } else {
                                        return -0.153391854038;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.134829427904;
                                    } else {
                                        return -0.0039230525658;
                                    }
                                }
                            }
                        }
                    } else {
                        return -0.23474693899;
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[103] <= 1.5) {
                                return -0.0290081006989;
                            } else {
                                return -0.0328434992787;
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                return 0.00470173146201;
                            } else {
                                if (fs[12] <= 0.5) {
                                    return -0.0129297516933;
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.018336591001;
                                    } else {
                                        return -0.0159309097078;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 100.0) {
                            if (fs[0] <= 2.5) {
                                return -0.0374732037283;
                            } else {
                                if (fs[4] <= 7.5) {
                                    return -0.0249311736401;
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0101097982063;
                                    } else {
                                        return -0.00450957809671;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -10.5) {
                                return 0.0358838952876;
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00254805414359;
                                    } else {
                                        return -0.0100325452397;
                                    }
                                } else {
                                    if (fs[53] <= -986.0) {
                                        return 0.0107474677639;
                                    } else {
                                        return -0.00886012633886;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[11] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[72] <= 9995.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[71] <= 0.5) {
                                        return 0.239769218236;
                                    } else {
                                        return 0.000385166070247;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0156137109211;
                                    } else {
                                        return 0.0511060363544;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[74] <= 0.5) {
                                        return 0.000283542275042;
                                    } else {
                                        return -0.00290820583771;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.0362455355471;
                                    } else {
                                        return 0.00306001295393;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0116828007095;
                                    } else {
                                        return -0.0500261556018;
                                    }
                                } else {
                                    if (fs[72] <= 9996.5) {
                                        return 0.265693059648;
                                    } else {
                                        return 0.0488522339018;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1123.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.104757577987;
                                    } else {
                                        return 0.231416564454;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0429271814233;
                                    } else {
                                        return -0.00167178670538;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -91.5) {
                            if (fs[59] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[47] <= -10714.0) {
                                        return -0.187362753063;
                                    } else {
                                        return -0.00766911559344;
                                    }
                                } else {
                                    if (fs[66] <= 5.0) {
                                        return 0.0643042013508;
                                    } else {
                                        return -0.223560217436;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    return 0.0717824397376;
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.0356463219058;
                                    } else {
                                        return 0.306156482978;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[76] <= 250.0) {
                                        return -0.0410777207378;
                                    } else {
                                        return 0.0442235867232;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0109792744504;
                                    } else {
                                        return -0.00621455328444;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1102.5) {
                                    if (fs[27] <= 0.5) {
                                        return 0.00142249616191;
                                    } else {
                                        return 0.226945523687;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.00325635970837;
                                    } else {
                                        return -0.0542482407464;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -364.5) {
                        if (fs[53] <= -1408.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[47] <= -375.5) {
                                        return 0.0280490489645;
                                    } else {
                                        return 0.189739574907;
                                    }
                                } else {
                                    if (fs[47] <= -15906.0) {
                                        return -0.324061983748;
                                    } else {
                                        return -0.0260989515944;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0596206993347;
                                    } else {
                                        return 0.343203861553;
                                    }
                                } else {
                                    return 0.403899500244;
                                }
                            }
                        } else {
                            if (fs[72] <= 9837.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.0567169769285;
                                    } else {
                                        return 0.0782201910441;
                                    }
                                } else {
                                    if (fs[47] <= -401.5) {
                                        return -0.0213724813635;
                                    } else {
                                        return 0.0276327079402;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0641554415706;
                                    } else {
                                        return -0.0240599162101;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return -0.0496051724573;
                                    } else {
                                        return 0.0936483475819;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[34] <= 0.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.0137498906906;
                                    } else {
                                        return 0.314159470316;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0137716766397;
                                    } else {
                                        return 0.0265676194214;
                                    }
                                }
                            } else {
                                if (fs[39] <= 0.5) {
                                    if (fs[94] <= 0.5) {
                                        return -0.000753782686506;
                                    } else {
                                        return 0.00787076928904;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.294999797758;
                                    } else {
                                        return 0.0761190739282;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[47] <= -24.0) {
                                        return 0.221757338202;
                                    } else {
                                        return 0.0927442663208;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0381527707645;
                                    } else {
                                        return 0.0549228526292;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9811.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0317191614303;
                                    } else {
                                        return -0.00915422047787;
                                    }
                                } else {
                                    return -0.0565443327737;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[45] <= 0.5) {
                if (fs[79] <= 0.5) {
                    if (fs[72] <= 9999.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[49] <= -2.5) {
                                    return 0.0896319415804;
                                } else {
                                    if (fs[53] <= -476.5) {
                                        return -0.0790172750859;
                                    } else {
                                        return 0.0610294384851;
                                    }
                                }
                            } else {
                                return -0.113677861857;
                            }
                        } else {
                            if (fs[72] <= 9997.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.00728970504319;
                                    } else {
                                        return 0.104093183197;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.182513063981;
                                    } else {
                                        return 0.0864426571746;
                                    }
                                }
                            } else {
                                return -0.133345794004;
                            }
                        }
                    } else {
                        if (fs[53] <= -561.5) {
                            return 0.237246930467;
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    return 0.195410850327;
                                } else {
                                    return 0.0852404835436;
                                }
                            } else {
                                return 0.0551398305122;
                            }
                        }
                    }
                } else {
                    if (fs[105] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            return 0.00183140080479;
                        } else {
                            return 0.0595997888993;
                        }
                    } else {
                        return -0.257207144442;
                    }
                }
            } else {
                if (fs[4] <= 7.0) {
                    if (fs[53] <= 7.5) {
                        return -0.000253707148675;
                    } else {
                        if (fs[0] <= 8.5) {
                            return -0.0109159610475;
                        } else {
                            return -0.00265023227167;
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[49] <= -0.5) {
                            return -0.0344235557147;
                        } else {
                            return -0.0314707510076;
                        }
                    } else {
                        if (fs[90] <= 0.5) {
                            return -0.0211562914083;
                        } else {
                            if (fs[0] <= 2.5) {
                                return -0.0219154652575;
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return -0.00416131049579;
                                    } else {
                                        return -0.007807514838;
                                    }
                                } else {
                                    return -0.0158488141903;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
