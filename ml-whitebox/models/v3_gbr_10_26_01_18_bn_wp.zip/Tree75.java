/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree75 {
    public double calcTree(double... fs) {
        if (fs[11] <= 0.5) {
            if (fs[64] <= -996.5) {
                if (fs[47] <= -27.5) {
                    if (fs[72] <= 9999.5) {
                        if (fs[47] <= -74.5) {
                            if (fs[23] <= 0.5) {
                                return -0.0421894928859;
                            } else {
                                if (fs[18] <= 0.5) {
                                    return 0.209199485903;
                                } else {
                                    if (fs[4] <= 8.0) {
                                        return 0.0267644579896;
                                    } else {
                                        return 0.155244235016;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                return 0.409436117509;
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.236947786715;
                                    } else {
                                        return 0.178327675236;
                                    }
                                } else {
                                    return 0.0490130218084;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            return -0.0704878147583;
                        } else {
                            if (fs[47] <= -33.0) {
                                if (fs[4] <= 10.5) {
                                    return 0.154347486862;
                                } else {
                                    return 0.0173501007906;
                                }
                            } else {
                                return -0.100835167909;
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[8] <= 0.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[58] <= 0.5) {
                                        return 0.04753426428;
                                    } else {
                                        return -0.02526516629;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.00913029983091;
                                    } else {
                                        return -0.151914139003;
                                    }
                                }
                            } else {
                                if (fs[64] <= -997.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0317123751773;
                                    } else {
                                        return -0.00396745002864;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0304156677846;
                                    } else {
                                        return 0.0431282824643;
                                    }
                                }
                            }
                        } else {
                            return -0.285276836591;
                        }
                    } else {
                        if (fs[58] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[64] <= -998.5) {
                                    return -0.00936867249483;
                                } else {
                                    return 0.380539952503;
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0101384813952;
                                    } else {
                                        return 0.0419158949167;
                                    }
                                } else {
                                    if (fs[64] <= -998.5) {
                                        return 0.135936939224;
                                    } else {
                                        return 0.0173553617295;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= 3.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0443329957637;
                                    } else {
                                        return -0.0192731690314;
                                    }
                                } else {
                                    return -0.0506406953667;
                                }
                            } else {
                                if (fs[64] <= -997.5) {
                                    if (fs[27] <= 0.5) {
                                        return -0.00184042319064;
                                    } else {
                                        return -0.00647542124088;
                                    }
                                } else {
                                    return -0.014285761399;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[28] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0762762197082;
                                    } else {
                                        return -0.108269921946;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0624100312717;
                                    } else {
                                        return -0.00669368176333;
                                    }
                                }
                            } else {
                                if (fs[4] <= 18.5) {
                                    if (fs[76] <= 150.0) {
                                        return 0.0246627692716;
                                    } else {
                                        return 0.132960756707;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.020772300025;
                                    } else {
                                        return -0.072088182038;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[4] <= 42.5) {
                                    if (fs[98] <= 0.5) {
                                        return 0.0142037395744;
                                    } else {
                                        return 0.0279994420551;
                                    }
                                } else {
                                    if (fs[47] <= -4.5) {
                                        return -0.331090573153;
                                    } else {
                                        return -0.101417220679;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.07457477598;
                                    } else {
                                        return 0.173595612154;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.0777940127553;
                                    } else {
                                        return -0.0508977589132;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1273.0) {
                            if (fs[47] <= -3.5) {
                                if (fs[105] <= 0.5) {
                                    return -0.304152216782;
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.224884996952;
                                    } else {
                                        return -0.427056043207;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 6.0) {
                                        return 0.18980806452;
                                    } else {
                                        return -0.0997257995938;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.176975683662;
                                    } else {
                                        return 0.160329249504;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[48] <= 0.5) {
                                    return 0.081647529931;
                                } else {
                                    return 0.291244615743;
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[53] <= -1118.0) {
                                        return -0.136054087246;
                                    } else {
                                        return -0.0235321116217;
                                    }
                                } else {
                                    return -0.0192562779467;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 10.5) {
                        if (fs[4] <= 13.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[47] <= -0.5) {
                                        return 0.00738184144324;
                                    } else {
                                        return -0.0150283462732;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.022158754567;
                                    } else {
                                        return 0.179045194858;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[47] <= -10.5) {
                                        return 0.0184517169426;
                                    } else {
                                        return -0.0117841236953;
                                    }
                                } else {
                                    if (fs[53] <= -980.5) {
                                        return -0.000448235983649;
                                    } else {
                                        return -0.00572832530658;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[47] <= -2.5) {
                                        return -0.0445552966198;
                                    } else {
                                        return -0.00674915545937;
                                    }
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return -0.0783953910176;
                                    } else {
                                        return -0.045926741463;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1418.0) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.00389555286355;
                                    } else {
                                        return 0.137962585188;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return -0.00212829958625;
                                    } else {
                                        return -0.00916891672652;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -93.5) {
                            if (fs[76] <= 75.0) {
                                if (fs[53] <= -1553.0) {
                                    return 0.115098768393;
                                } else {
                                    if (fs[88] <= 5.0) {
                                        return -0.0265613001728;
                                    } else {
                                        return 0.0158696230804;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1242.5) {
                                    if (fs[47] <= -235.0) {
                                        return 0.0603376634786;
                                    } else {
                                        return 0.32767798386;
                                    }
                                } else {
                                    if (fs[53] <= -982.5) {
                                        return 0.0729185006329;
                                    } else {
                                        return -0.0318464491145;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[72] <= 9970.5) {
                                        return -0.00770855746469;
                                    } else {
                                        return 0.0174058463882;
                                    }
                                } else {
                                    if (fs[0] <= 491.5) {
                                        return -0.00207518094348;
                                    } else {
                                        return 0.125036426098;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return 0.150666403397;
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0500517475821;
                                    } else {
                                        return 0.0511133797554;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[6] <= 0.5) {
                    if (fs[79] <= 0.5) {
                        if (fs[22] <= 0.5) {
                            if (fs[2] <= 7.5) {
                                if (fs[101] <= 0.5) {
                                    return -0.333437767437;
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.292096931906;
                                    } else {
                                        return -0.440062976818;
                                    }
                                }
                            } else {
                                return -0.164369310626;
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                return -0.113968624045;
                            } else {
                                return -0.0502527683377;
                            }
                        }
                    } else {
                        return 0.231486299389;
                    }
                } else {
                    if (fs[22] <= 0.5) {
                        if (fs[88] <= -0.5) {
                            if (fs[72] <= 9973.5) {
                                if (fs[78] <= 0.5) {
                                    return 0.0519354970402;
                                } else {
                                    if (fs[53] <= -436.5) {
                                        return -0.280683383071;
                                    } else {
                                        return -0.162308577607;
                                    }
                                }
                            } else {
                                return 0.162912332789;
                            }
                        } else {
                            if (fs[4] <= 25.5) {
                                if (fs[53] <= -1398.0) {
                                    if (fs[89] <= 0.5) {
                                        return 0.089319035683;
                                    } else {
                                        return -0.409520422094;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.00501799048867;
                                    } else {
                                        return 0.026052279197;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[100] <= 0.5) {
                                        return -0.232373277467;
                                    } else {
                                        return 0.106507853117;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.118711060877;
                                    } else {
                                        return -0.0571156927917;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1063.0) {
                            if (fs[88] <= 6.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[88] <= 5.5) {
                                        return -0.0129377998783;
                                    } else {
                                        return -0.0968279659231;
                                    }
                                } else {
                                    if (fs[53] <= -1493.5) {
                                        return 0.105161336606;
                                    } else {
                                        return 0.0169789604432;
                                    }
                                }
                            } else {
                                if (fs[88] <= 7.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0811820503454;
                                    } else {
                                        return -0.28162228444;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.0209544819752;
                                    } else {
                                        return 0.0533996755316;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 4273.5) {
                                if (fs[47] <= -56.0) {
                                    return -0.264815647481;
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0608675360501;
                                    } else {
                                        return 0.159140628727;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.12400870297;
                                    } else {
                                        return -0.26555735258;
                                    }
                                } else {
                                    if (fs[47] <= -7.0) {
                                        return 0.24594636123;
                                    } else {
                                        return -0.169409887101;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[70] <= -1.5) {
                    if (fs[52] <= 0.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[53] <= -1128.0) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0438327011798;
                                    } else {
                                        return -0.00592021009039;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.00920119649683;
                                    } else {
                                        return -0.0556566810026;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[62] <= -1.5) {
                                        return 0.0523383513881;
                                    } else {
                                        return -0.0116196496028;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0024366159098;
                                    } else {
                                        return -0.0519813438326;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.0167665120804;
                                    } else {
                                        return 0.0857282317381;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.000200134452238;
                                    } else {
                                        return -0.023404026043;
                                    }
                                }
                            } else {
                                if (fs[47] <= -368.0) {
                                    if (fs[53] <= -1468.0) {
                                        return 0.503865455509;
                                    } else {
                                        return 0.0462436347713;
                                    }
                                } else {
                                    if (fs[47] <= -20.5) {
                                        return 0.0211519485645;
                                    } else {
                                        return -0.000637453842915;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 7.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0280937325388;
                                    } else {
                                        return -0.0182621344277;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return -0.000911552140822;
                                    } else {
                                        return -0.00337399286874;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1418.0) {
                                    if (fs[97] <= 0.5) {
                                        return 0.063832330393;
                                    } else {
                                        return 0.0245550832215;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.00953266711532;
                                    } else {
                                        return -0.00374388766872;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1448.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0698836929353;
                                    } else {
                                        return 0.0381457064489;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.189175444053;
                                    } else {
                                        return 0.172455023262;
                                    }
                                }
                            } else {
                                if (fs[47] <= -4817.0) {
                                    if (fs[53] <= 7.5) {
                                        return -0.147535844808;
                                    } else {
                                        return -0.0585868302973;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.00334753603573;
                                    } else {
                                        return 0.136218652438;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[97] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[77] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.12719674234;
                                    } else {
                                        return -0.018001031664;
                                    }
                                } else {
                                    if (fs[53] <= -1118.0) {
                                        return 0.210697472181;
                                    } else {
                                        return -0.0366431411547;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    return -0.114686179112;
                                } else {
                                    return -0.0704842660402;
                                }
                            }
                        } else {
                            if (fs[72] <= 9715.0) {
                                if (fs[52] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0444905808009;
                                    } else {
                                        return -0.0101514077761;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.044471881133;
                                    } else {
                                        return -0.00481531898995;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[81] <= 0.5) {
                                        return -0.0596471992309;
                                    } else {
                                        return -0.0292228890683;
                                    }
                                } else {
                                    return -0.0615642845499;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[76] <= 250.0) {
                                    if (fs[53] <= -1483.0) {
                                        return -0.112456106674;
                                    } else {
                                        return -0.0938215927143;
                                    }
                                } else {
                                    return -0.0398001907852;
                                }
                            } else {
                                return 0.0446151559908;
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0246096329661;
                                    } else {
                                        return -0.0124755783718;
                                    }
                                } else {
                                    if (fs[4] <= 58.0) {
                                        return -0.0318026767018;
                                    } else {
                                        return -0.0561869692719;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.00316224953971;
                                    } else {
                                        return 0.0202820527277;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.00704801679671;
                                    } else {
                                        return -0.00664081993556;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
