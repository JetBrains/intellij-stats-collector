/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree12 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[53] <= -987.5) {
                if (fs[53] <= -1228.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[4] <= 3.5) {
                            if (fs[70] <= -3.5) {
                                return 0.640223027542;
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[47] <= -27.5) {
                                        return 0.51108351465;
                                    } else {
                                        return -0.0566287758532;
                                    }
                                } else {
                                    return 0.375468170482;
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[47] <= -136.0) {
                                    if (fs[4] <= 6.5) {
                                        return 0.30368169503;
                                    } else {
                                        return 0.532403211206;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.21115894855;
                                    } else {
                                        return 0.0169126861668;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.495742303057;
                                    } else {
                                        return 0.353949613252;
                                    }
                                } else {
                                    if (fs[4] <= 16.0) {
                                        return 0.411406796813;
                                    } else {
                                        return -0.0607075128576;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.250611133286;
                                    } else {
                                        return 0.392161924831;
                                    }
                                } else {
                                    if (fs[47] <= -62.5) {
                                        return 0.086553895599;
                                    } else {
                                        return 0.499676148893;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.519509205639;
                                    } else {
                                        return 0.357511058685;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.568861466271;
                                    } else {
                                        return 0.476572267096;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1588.0) {
                                if (fs[52] <= 0.5) {
                                    if (fs[83] <= 0.5) {
                                        return 0.433635274197;
                                    } else {
                                        return -0.0742778452216;
                                    }
                                } else {
                                    if (fs[53] <= -2193.0) {
                                        return 0.622334249026;
                                    } else {
                                        return 0.487285119638;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.15797575988;
                                    } else {
                                        return 0.464059730131;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return 0.297288230328;
                                    } else {
                                        return 0.0474423149355;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 12.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -1138.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.453379844051;
                                    } else {
                                        return -0.0353175621527;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.301368408101;
                                    } else {
                                        return 0.441529703945;
                                    }
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.500026401165;
                                    } else {
                                        return 0.526372500471;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.485243758476;
                                    } else {
                                        return 0.375486788923;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.502706495891;
                                    } else {
                                        return 0.391109739561;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.198686587561;
                                    } else {
                                        return 0.447392918963;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.483127616594;
                                    } else {
                                        return 0.413957046936;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0265429840564;
                                    } else {
                                        return 0.191695234532;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[62] <= -3.5) {
                                    return 0.0481002159706;
                                } else {
                                    if (fs[106] <= 0.5) {
                                        return 0.438981970167;
                                    } else {
                                        return 0.503372516848;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.163047787292;
                                    } else {
                                        return 0.391765227596;
                                    }
                                } else {
                                    if (fs[47] <= -542.5) {
                                        return -0.203702476254;
                                    } else {
                                        return 0.158304524108;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.173996127272;
                                    } else {
                                        return 0.297282546447;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.370861861586;
                                    } else {
                                        return 0.501074505829;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.709393116391;
                                    } else {
                                        return 0.563153941299;
                                    }
                                } else {
                                    return 0.510847958277;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[71] <= 0.5) {
                    if (fs[88] <= 5.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.156597390666;
                                    } else {
                                        return 0.298648398605;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0723935423085;
                                    } else {
                                        return -0.192769873048;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.505444543421;
                                    } else {
                                        return 0.64719390916;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.530394548338;
                                    } else {
                                        return 0.152154276026;
                                    }
                                }
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.496752456935;
                                    } else {
                                        return 0.383423886632;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0494738776267;
                                    } else {
                                        return 0.474072607685;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.430422681798;
                                    } else {
                                        return -0.139416138766;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.541417924726;
                                    } else {
                                        return 0.424671287873;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.234726497386;
                                    } else {
                                        return 0.562167733458;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.03977827183;
                                    } else {
                                        return 0.390103770555;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    return 0.106204462627;
                                } else {
                                    return 0.609586637512;
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.345564458677;
                                    } else {
                                        return 0.548203341643;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.478145441332;
                                    } else {
                                        return 0.574381384177;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[31] <= 0.5) {
                                        return 0.568092723803;
                                    } else {
                                        return 0.669186803288;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.653416249114;
                                    } else {
                                        return 0.693308572462;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[47] <= -6.5) {
                            if (fs[62] <= -0.5) {
                                if (fs[47] <= -29.5) {
                                    if (fs[47] <= -44.5) {
                                        return 0.522448086856;
                                    } else {
                                        return 0.663339511365;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.568473416223;
                                    } else {
                                        return 0.349361545034;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.184696660151;
                                    } else {
                                        return 0.294920085744;
                                    }
                                } else {
                                    return 0.569712614797;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[49] <= -0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.528908388157;
                                    } else {
                                        return 0.399500241138;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return 0.150874022408;
                                    } else {
                                        return 0.367567223921;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.573587236409;
                                    } else {
                                        return 0.486161469128;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0589313959216;
                                    } else {
                                        return 0.210989578927;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1.0) {
                            if (fs[22] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[92] <= 0.5) {
                                        return 0.622846821825;
                                    } else {
                                        return 0.438082923313;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.235778089753;
                                    } else {
                                        return 0.117017229016;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[4] <= 10.5) {
                                        return -0.117824045504;
                                    } else {
                                        return -0.164611261939;
                                    }
                                } else {
                                    return -0.0127741077366;
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.45665758188;
                                    } else {
                                        return 0.353828375669;
                                    }
                                } else {
                                    if (fs[64] <= -994.5) {
                                        return 0.472849024073;
                                    } else {
                                        return 0.179543405723;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[4] <= 19.5) {
                                        return 0.434081564905;
                                    } else {
                                        return 0.260715409696;
                                    }
                                } else {
                                    return 0.0549381695153;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[72] <= 9653.0) {
                    if (fs[76] <= 25.0) {
                        if (fs[85] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[47] <= -3.5) {
                                        return -0.00523006974082;
                                    } else {
                                        return 0.0790696851281;
                                    }
                                } else {
                                    return 0.526672328485;
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.00868272813104;
                                    } else {
                                        return 0.0796991679655;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.042047049111;
                                    } else {
                                        return 0.0778280290288;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[47] <= -27.5) {
                                    if (fs[88] <= 1.5) {
                                        return 0.0578600140853;
                                    } else {
                                        return 0.353413991545;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0355778264843;
                                    } else {
                                        return 0.169281719346;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[53] <= -1478.5) {
                                        return 0.0114667010088;
                                    } else {
                                        return -0.0481616144276;
                                    }
                                } else {
                                    if (fs[47] <= -8.5) {
                                        return 0.708143703915;
                                    } else {
                                        return 0.199421577485;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[53] <= -1478.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0939157401226;
                                    } else {
                                        return 0.370438093633;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.104136987322;
                                    } else {
                                        return -0.068687975973;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0630778775323;
                                    } else {
                                        return -0.0358393450508;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return 0.0542332217233;
                                    } else {
                                        return -0.0304088062543;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[51] <= 0.5) {
                                        return 0.078971132107;
                                    } else {
                                        return 0.458381102893;
                                    }
                                } else {
                                    if (fs[47] <= -97.5) {
                                        return 0.342598711324;
                                    } else {
                                        return 0.177062980285;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[88] <= 1.0) {
                                        return 0.127593849629;
                                    } else {
                                        return 0.00720256052057;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.215529900426;
                                    } else {
                                        return 0.462524572528;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -13.5) {
                        if (fs[88] <= 7.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.156870748228;
                                    } else {
                                        return 0.0677584358274;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.303967073317;
                                    } else {
                                        return -0.129509413549;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[47] <= -23.5) {
                                        return -0.000280757712827;
                                    } else {
                                        return 0.493114116183;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.451298090016;
                                    } else {
                                        return -0.104482457397;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[72] <= 9980.0) {
                                        return 0.524735835626;
                                    } else {
                                        return 0.30599365598;
                                    }
                                } else {
                                    return -0.258918880926;
                                }
                            } else {
                                if (fs[47] <= -84.5) {
                                    return 0.272866342116;
                                } else {
                                    if (fs[53] <= -978.0) {
                                        return -0.0640697531633;
                                    } else {
                                        return -0.0714254472365;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 7.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0406895436187;
                                    } else {
                                        return 0.132964587486;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return 0.117878387164;
                                    } else {
                                        return 0.650149915196;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1283.0) {
                                    if (fs[41] <= 0.5) {
                                        return 0.345283717688;
                                    } else {
                                        return -0.117868850529;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0797502334673;
                                    } else {
                                        return 0.266615361659;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[72] <= 9810.5) {
                                        return 0.425554387806;
                                    } else {
                                        return 0.157253444339;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.281299213061;
                                    } else {
                                        return 0.500949437358;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0316720766327;
                                    } else {
                                        return -0.0432028771421;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.0897493582382;
                                    } else {
                                        return 0.000572983386218;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[12] <= 0.5) {
                    if (fs[4] <= 11.5) {
                        if (fs[0] <= 5.5) {
                            if (fs[47] <= -488.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0346204649188;
                                    } else {
                                        return 0.109104403525;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0138905717661;
                                    } else {
                                        return 0.444193838844;
                                    }
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.538234222284;
                                    } else {
                                        return 0.0302853172985;
                                    }
                                } else {
                                    if (fs[72] <= 8867.5) {
                                        return -0.0170565728558;
                                    } else {
                                        return 0.0253927377355;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 18.5) {
                                if (fs[72] <= 9968.5) {
                                    if (fs[88] <= -0.5) {
                                        return -0.0337093799387;
                                    } else {
                                        return -0.0256814468343;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.0370134762041;
                                    } else {
                                        return -0.0121082538175;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9995.5) {
                                    if (fs[0] <= 34.5) {
                                        return -0.030416490356;
                                    } else {
                                        return -0.0320680420583;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0251117944186;
                                    } else {
                                        return -0.0361917727784;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[105] <= 0.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[0] <= 5.5) {
                                    if (fs[47] <= -5.5) {
                                        return -0.00216508402774;
                                    } else {
                                        return -0.0203580448934;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return -0.0264670363633;
                                    } else {
                                        return -0.0313193417724;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[53] <= 3.5) {
                                        return -0.0229841447316;
                                    } else {
                                        return -0.0332987490079;
                                    }
                                } else {
                                    if (fs[53] <= -1418.0) {
                                        return 0.0456413608498;
                                    } else {
                                        return -0.0288702574201;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -3.5) {
                                if (fs[72] <= 9985.5) {
                                    if (fs[47] <= -36.0) {
                                        return 0.0690060425881;
                                    } else {
                                        return -0.0287433759783;
                                    }
                                } else {
                                    return 0.273880051663;
                                }
                            } else {
                                if (fs[32] <= 0.5) {
                                    if (fs[47] <= -2154.0) {
                                        return -0.0637787185165;
                                    } else {
                                        return -0.0323737466228;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return 0.252080779787;
                                    } else {
                                        return -0.0367964921067;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[101] <= 0.5) {
                        if (fs[72] <= 9990.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0551393827366;
                                    } else {
                                        return 0.178639140997;
                                    }
                                } else {
                                    return -0.0302989782204;
                                }
                            } else {
                                if (fs[47] <= -2.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.22032956436;
                                    } else {
                                        return 0.00199630393018;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.00524772283137;
                                    } else {
                                        return -0.0276679395847;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -89.0) {
                                if (fs[4] <= 12.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.17424453743;
                                    } else {
                                        return -0.0494374898798;
                                    }
                                } else {
                                    if (fs[0] <= 27.0) {
                                        return 0.564535488156;
                                    } else {
                                        return 0.124787328225;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.080548432269;
                                    } else {
                                        return -0.000332062197914;
                                    }
                                } else {
                                    return 0.574018131911;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 10.5) {
                            if (fs[53] <= -1093.0) {
                                if (fs[4] <= 5.5) {
                                    if (fs[72] <= 4992.0) {
                                        return 0.117918168293;
                                    } else {
                                        return 0.634722743008;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.044946999298;
                                    } else {
                                        return -0.0421946436383;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0556723293964;
                                    } else {
                                        return -0.0380807046891;
                                    }
                                } else {
                                    if (fs[53] <= 3.5) {
                                        return -0.0123191054174;
                                    } else {
                                        return -0.0325527836727;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[49] <= -2.5) {
                                        return 0.240343597996;
                                    } else {
                                        return 0.0348311347387;
                                    }
                                } else {
                                    if (fs[72] <= 4669.5) {
                                        return -0.0332050381724;
                                    } else {
                                        return 0.00637740790937;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1092.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0100490521261;
                                    } else {
                                        return 0.355288119365;
                                    }
                                } else {
                                    if (fs[62] <= -2.5) {
                                        return 0.0477658011714;
                                    } else {
                                        return -0.0280726006374;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
