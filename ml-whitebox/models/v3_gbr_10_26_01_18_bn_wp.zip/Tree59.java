/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree59 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[101] <= 0.5) {
                    if (fs[6] <= 0.5) {
                        return 0.108276513842;
                    } else {
                        if (fs[53] <= -1138.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0479359513848;
                                    } else {
                                        return 0.0852023878142;
                                    }
                                } else {
                                    return -0.0386512693151;
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.00825548227593;
                                    } else {
                                        return 0.0453184795836;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0218182756563;
                                    } else {
                                        return 0.0695617021907;
                                    }
                                }
                            }
                        } else {
                            if (fs[27] <= 0.5) {
                                if (fs[53] <= -983.0) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0497107950521;
                                    } else {
                                        return 0.0603364849387;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.194114833112;
                                    } else {
                                        return 0.0406902140273;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[72] <= 5000.0) {
                                        return 0.0793066980881;
                                    } else {
                                        return 0.15921638251;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.182758670857;
                                    } else {
                                        return 0.0768193584347;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[79] <= 0.5) {
                        if (fs[4] <= 19.5) {
                            return 0.33122283753;
                        } else {
                            if (fs[11] <= 0.5) {
                                return -0.261022184303;
                            } else {
                                if (fs[53] <= -1318.0) {
                                    if (fs[4] <= 39.5) {
                                        return -0.147483754832;
                                    } else {
                                        return -0.0607006288242;
                                    }
                                } else {
                                    return -0.0228560160423;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1563.0) {
                            return 0.28249345302;
                        } else {
                            return -0.195400986487;
                        }
                    }
                }
            } else {
                if (fs[4] <= 2.5) {
                    if (fs[53] <= -571.5) {
                        if (fs[0] <= 1.5) {
                            return 0.0558493388592;
                        } else {
                            return 0.194550907529;
                        }
                    } else {
                        return -0.121321065261;
                    }
                } else {
                    if (fs[30] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0312355466441;
                                    } else {
                                        return 0.0346263353333;
                                    }
                                } else {
                                    if (fs[0] <= 25.5) {
                                        return 0.145653798733;
                                    } else {
                                        return -0.0565595014995;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    return -0.00968112709764;
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.00874173076762;
                                    } else {
                                        return -0.0353121499458;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0177833929224;
                                    } else {
                                        return 0.137964140645;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0111268512354;
                                    } else {
                                        return -0.0249046685938;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0286750865319;
                                    } else {
                                        return -0.00513703020894;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return 0.0396598198914;
                                    } else {
                                        return -0.00525515568154;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 5.5) {
                            return 0.0790260715228;
                        } else {
                            return 0.1691490986;
                        }
                    }
                }
            }
        } else {
            if (fs[103] <= 1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[47] <= -6.5) {
                        if (fs[28] <= 0.5) {
                            if (fs[18] <= -0.5) {
                                return -0.292632440984;
                            } else {
                                if (fs[53] <= -1898.0) {
                                    if (fs[53] <= -1968.0) {
                                        return 0.113569509157;
                                    } else {
                                        return 0.175111129622;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return 0.0523858931802;
                                    } else {
                                        return 0.104150716452;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                return -0.200600359148;
                            } else {
                                return -0.237293647655;
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[86] <= 0.5) {
                                    if (fs[65] <= 0.5) {
                                        return 0.0398104817907;
                                    } else {
                                        return -0.13371014224;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0942247186524;
                                    } else {
                                        return -0.00471777195792;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1143.5) {
                                    if (fs[72] <= 4641.5) {
                                        return -0.0471092754408;
                                    } else {
                                        return -0.0968127217983;
                                    }
                                } else {
                                    if (fs[72] <= 4619.5) {
                                        return -0.0884412345989;
                                    } else {
                                        return 0.0728416048898;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 150.0) {
                                if (fs[72] <= 9845.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0558673921549;
                                    } else {
                                        return 0.00949718409624;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0760732666822;
                                    } else {
                                        return 0.013978895493;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[47] <= -2.5) {
                                        return -0.0840256316326;
                                    } else {
                                        return 0.128828287578;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.0697106881609;
                                    } else {
                                        return 0.00580657238395;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.111944285316;
                                    } else {
                                        return 0.383630426128;
                                    }
                                } else {
                                    if (fs[47] <= -671.5) {
                                        return 0.265960485576;
                                    } else {
                                        return 0.00527779793418;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return -0.0161173449435;
                                    } else {
                                        return 0.0662291912202;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.0107826998516;
                                    } else {
                                        return 0.257569687237;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9368.0) {
                                if (fs[88] <= 7.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0194815167619;
                                    } else {
                                        return 0.00186555224318;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.158566092958;
                                    } else {
                                        return -0.005592790585;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.0500918197427;
                                    } else {
                                        return 0.0020729679566;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.103034351838;
                                    } else {
                                        return 0.238738327525;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[0] <= 7.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.00154025024965;
                                    } else {
                                        return 0.0072376645306;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00319240585538;
                                    } else {
                                        return -0.00157575706902;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[62] <= -2.5) {
                                        return 0.0996277755989;
                                    } else {
                                        return -0.003251205702;
                                    }
                                } else {
                                    if (fs[0] <= 77.5) {
                                        return -0.00612993838579;
                                    } else {
                                        return 0.0550078035138;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[101] <= 1.5) {
                                        return -0.00717801780792;
                                    } else {
                                        return 0.192530545501;
                                    }
                                } else {
                                    return 0.411158233086;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return -0.026972569962;
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.00873186893531;
                                    } else {
                                        return -0.0243733052373;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[45] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[0] <= 31.5) {
                            if (fs[53] <= -988.5) {
                                if (fs[32] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0440798459662;
                                    } else {
                                        return -0.0251304275869;
                                    }
                                } else {
                                    return -0.304663835383;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0916663520317;
                                    } else {
                                        return -0.225742404791;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.0756078067254;
                                    } else {
                                        return -0.0353707957161;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.0366086602332;
                                } else {
                                    return 0.443133005857;
                                }
                            } else {
                                return 0.312875469484;
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[72] <= 9988.5) {
                                if (fs[4] <= 25.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.0661422828858;
                                    } else {
                                        return -0.00571024886589;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.225738957575;
                                    } else {
                                        return -0.0759550116301;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    return -0.0696571548515;
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.147141832976;
                                    } else {
                                        return -0.297150638081;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 5.5) {
                                if (fs[0] <= 9.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.0290942230843;
                                    } else {
                                        return 0.0141537696982;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return -0.0178664668087;
                                    } else {
                                        return 0.0460505817697;
                                    }
                                }
                            } else {
                                return 0.0353598736144;
                            }
                        }
                    }
                } else {
                    if (fs[62] <= -2.5) {
                        if (fs[64] <= -995.5) {
                            if (fs[53] <= -456.5) {
                                return 0.171088902031;
                            } else {
                                return -0.0563524803216;
                            }
                        } else {
                            return -0.0499961009828;
                        }
                    } else {
                        if (fs[68] <= 1.5) {
                            if (fs[0] <= 4.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[59] <= 0.5) {
                                        return -0.00664561801604;
                                    } else {
                                        return -0.0171614933789;
                                    }
                                } else {
                                    if (fs[4] <= 30.5) {
                                        return -0.00602438122117;
                                    } else {
                                        return 0.0824577851034;
                                    }
                                }
                            } else {
                                if (fs[53] <= -981.5) {
                                    if (fs[53] <= -1027.0) {
                                        return -0.0136201563928;
                                    } else {
                                        return -0.00391983016029;
                                    }
                                } else {
                                    if (fs[53] <= -977.0) {
                                        return 0.00399523883546;
                                    } else {
                                        return -0.00239976417772;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                return 0.0749234573377;
                            } else {
                                return -0.00569175538845;
                            }
                        }
                    }
                }
            }
        }
    }
}
