/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree26 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[41] <= 0.5) {
                if (fs[4] <= 10.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[53] <= -987.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[65] <= 0.5) {
                                        return 0.218849782126;
                                    } else {
                                        return 0.319766247646;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0289035964818;
                                    } else {
                                        return 0.176865595897;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9885.5) {
                                    if (fs[53] <= -1123.5) {
                                        return -0.0568262956788;
                                    } else {
                                        return 0.316249342916;
                                    }
                                } else {
                                    if (fs[53] <= -1138.5) {
                                        return 0.154597711919;
                                    } else {
                                        return 0.306857672916;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[64] <= -498.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.323740185327;
                                    } else {
                                        return 0.185793135295;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.110266918787;
                                    } else {
                                        return 0.0496478594967;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -472.0) {
                                        return -0.196303350907;
                                    } else {
                                        return 0.239067707963;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.190728700391;
                                    } else {
                                        return 0.060486525723;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[18] <= -0.5) {
                                return -0.158041728947;
                            } else {
                                if (fs[88] <= 4.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.254921998625;
                                    } else {
                                        return 0.159685542207;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.321015326787;
                                    } else {
                                        return 0.376683765019;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.258417249857;
                                    } else {
                                        return 0.217675783029;
                                    }
                                } else {
                                    if (fs[88] <= 3.0) {
                                        return 0.073320619907;
                                    } else {
                                        return -0.265520945771;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 6.5) {
                                        return -0.148166732099;
                                    } else {
                                        return 0.111140203003;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.253781160398;
                                    } else {
                                        return 0.17495965459;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[76] <= 25.0) {
                            if (fs[98] <= 0.5) {
                                if (fs[53] <= -1508.0) {
                                    if (fs[4] <= 18.5) {
                                        return 0.33342912315;
                                    } else {
                                        return 0.210663784992;
                                    }
                                } else {
                                    if (fs[62] <= -0.5) {
                                        return 0.21989635284;
                                    } else {
                                        return 0.0573145964049;
                                    }
                                }
                            } else {
                                if (fs[55] <= -1.5) {
                                    if (fs[4] <= 12.0) {
                                        return 0.314544482404;
                                    } else {
                                        return 0.0703366836787;
                                    }
                                } else {
                                    if (fs[53] <= -1318.0) {
                                        return 0.387348338133;
                                    } else {
                                        return 0.272672345259;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.286472173416;
                                    } else {
                                        return 0.214141202618;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.239789656145;
                                    } else {
                                        return 0.36982009292;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    return -0.122752963019;
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.157226910212;
                                    } else {
                                        return -0.270021146543;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 0.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.159697054628;
                                    } else {
                                        return 0.00361136506724;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.0566133519483;
                                    } else {
                                        return -0.0842952015634;
                                    }
                                }
                            } else {
                                if (fs[82] <= 0.5) {
                                    if (fs[2] <= 9.5) {
                                        return 0.188471299029;
                                    } else {
                                        return 0.357524105369;
                                    }
                                } else {
                                    return -0.0228394825426;
                                }
                            }
                        } else {
                            if (fs[53] <= -1588.0) {
                                if (fs[76] <= 25.0) {
                                    if (fs[53] <= -1993.0) {
                                        return 0.377335176429;
                                    } else {
                                        return 0.189306135957;
                                    }
                                } else {
                                    if (fs[53] <= -2193.0) {
                                        return 0.401862019823;
                                    } else {
                                        return 0.294842343175;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0217216299224;
                                    } else {
                                        return 0.0939793393661;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return 0.163795784227;
                                    } else {
                                        return -0.237075528719;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[88] <= 6.5) {
                    if (fs[84] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[76] <= 75.0) {
                                    return 0.295956010266;
                                } else {
                                    return 0.416661714481;
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.000810110633277;
                                    } else {
                                        return 0.108878709004;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.12987135132;
                                    } else {
                                        return 0.485350311113;
                                    }
                                }
                            }
                        } else {
                            if (fs[77] <= 0.5) {
                                if (fs[47] <= -339.0) {
                                    return 0.145206327735;
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0894994480099;
                                    } else {
                                        return 0.0455466682613;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    return 0.0820829594081;
                                } else {
                                    return 0.38367164229;
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                return 0.198244746446;
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 4.0) {
                                        return 0.287701653226;
                                    } else {
                                        return 0.24839472051;
                                    }
                                } else {
                                    return 0.337756761484;
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    return -0.338374615451;
                                } else {
                                    return -0.207002535677;
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[52] <= 0.5) {
                                        return 0.145416468287;
                                    } else {
                                        return 0.0544735921712;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0262206174974;
                                    } else {
                                        return 0.434951481636;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[71] <= 0.5) {
                        if (fs[47] <= -0.5) {
                            if (fs[52] <= 0.5) {
                                return 0.143897164601;
                            } else {
                                if (fs[4] <= 5.5) {
                                    return 0.481357190307;
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.290734327028;
                                    } else {
                                        return 0.337500058517;
                                    }
                                }
                            }
                        } else {
                            return 0.114564046828;
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    return -0.158845989117;
                                } else {
                                    return -0.279520859919;
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    return 0.209139317143;
                                } else {
                                    return 0.110073416858;
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[53] <= -1458.0) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0247997396291;
                                    } else {
                                        return 0.25972568452;
                                    }
                                } else {
                                    return -0.154170624143;
                                }
                            } else {
                                return 0.368861381931;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[47] <= -3640.5) {
                if (fs[60] <= 0.5) {
                    if (fs[88] <= 7.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[78] <= 0.5) {
                                return 0.208946719094;
                            } else {
                                if (fs[53] <= -1458.0) {
                                    if (fs[47] <= -10589.0) {
                                        return -0.0956736686572;
                                    } else {
                                        return 0.0218935550263;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.0485329688888;
                                    } else {
                                        return -0.0661004677838;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[53] <= -1478.0) {
                                    if (fs[2] <= 3.5) {
                                        return 0.345372622711;
                                    } else {
                                        return 0.415229406674;
                                    }
                                } else {
                                    return 0.127335584718;
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[53] <= -1468.0) {
                                        return 0.281905586002;
                                    } else {
                                        return 0.0737968259489;
                                    }
                                } else {
                                    return -0.0888054526337;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1242.5) {
                            if (fs[47] <= -6869.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.409061885477;
                                    } else {
                                        return 0.530187887738;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.393847321785;
                                    } else {
                                        return 0.635448717587;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    return 0.0746822731241;
                                } else {
                                    if (fs[47] <= -3927.5) {
                                        return 0.275383747804;
                                    } else {
                                        return 0.473613686126;
                                    }
                                }
                            }
                        } else {
                            return -0.0850308967134;
                        }
                    }
                } else {
                    if (fs[23] <= 0.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[4] <= 10.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[47] <= -10840.5) {
                                        return -0.0824542893304;
                                    } else {
                                        return 0.0637841792414;
                                    }
                                } else {
                                    if (fs[47] <= -35018.5) {
                                        return -0.245039347349;
                                    } else {
                                        return -0.038757213029;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1293.0) {
                                    return 0.398256782699;
                                } else {
                                    return -0.0603739643422;
                                }
                            }
                        } else {
                            if (fs[0] <= 8.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.211920646126;
                                    } else {
                                        return 0.00817286394444;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.22608392955;
                                    } else {
                                        return 0.501144271986;
                                    }
                                }
                            } else {
                                if (fs[47] <= -12499.0) {
                                    return 0.0243596163592;
                                } else {
                                    return -0.0638109608391;
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[72] <= 9994.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[4] <= 5.0) {
                                        return -0.0156897867453;
                                    } else {
                                        return -0.0472131098593;
                                    }
                                } else {
                                    return -0.0220330205903;
                                }
                            } else {
                                return 0.0390171043474;
                            }
                        } else {
                            return 0.0364120631952;
                        }
                    }
                }
            } else {
                if (fs[72] <= 9867.5) {
                    if (fs[90] <= 0.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.372807421817;
                                    } else {
                                        return 0.0298527725666;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0347331337328;
                                    } else {
                                        return -0.0319615748357;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[53] <= -1188.0) {
                                        return -0.0525926597878;
                                    } else {
                                        return 0.0114627084523;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.0236855809831;
                                    } else {
                                        return -0.0351024289471;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0159670333044;
                                    } else {
                                        return -0.0104161292283;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.000671541749036;
                                    } else {
                                        return 0.23388239347;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.000491953272593;
                                    } else {
                                        return -0.0113658915547;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.00647990451999;
                                    } else {
                                        return 0.0387932231902;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.00686205961588;
                                    } else {
                                        return 0.0583315994028;
                                    }
                                } else {
                                    if (fs[72] <= 9360.5) {
                                        return 0.16105799617;
                                    } else {
                                        return -0.042785067287;
                                    }
                                }
                            } else {
                                if (fs[62] <= -2.5) {
                                    if (fs[4] <= 20.0) {
                                        return -0.0647557072897;
                                    } else {
                                        return 0.250087196608;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0179766682643;
                                    } else {
                                        return -0.0277440900278;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 0.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.0231220662437;
                                    } else {
                                        return -0.00603023571717;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.00744470246033;
                                    } else {
                                        return -0.0172277676938;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.124082220984;
                                    } else {
                                        return 0.0498378375208;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0113780915556;
                                    } else {
                                        return 0.0253520883141;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9999.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.0183632287385;
                                    } else {
                                        return 0.101410067129;
                                    }
                                } else {
                                    if (fs[47] <= -7.5) {
                                        return 0.276466229459;
                                    } else {
                                        return 0.124953803967;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1057.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.196996756579;
                                    } else {
                                        return -0.229944085148;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0856558980637;
                                    } else {
                                        return 0.0413649839297;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[72] <= 9996.5) {
                                        return 0.0105621484854;
                                    } else {
                                        return 0.0548896903865;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.000255192446307;
                                    } else {
                                        return -0.0137111418018;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.464470964243;
                                    } else {
                                        return 0.062750692791;
                                    }
                                } else {
                                    if (fs[53] <= -1418.0) {
                                        return 0.0502869400371;
                                    } else {
                                        return -0.00587020631455;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1108.0) {
                            if (fs[85] <= 0.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[53] <= -1123.5) {
                                        return 0.10411130249;
                                    } else {
                                        return 0.364394897098;
                                    }
                                } else {
                                    if (fs[47] <= -6.5) {
                                        return -0.146978822089;
                                    } else {
                                        return -0.037784488644;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.311577081841;
                                    } else {
                                        return 0.162487725279;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.24292511374;
                                    } else {
                                        return -0.0463868251386;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.104488718812;
                                    } else {
                                        return -0.0248411620706;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0382270372427;
                                    } else {
                                        return -0.0234516278319;
                                    }
                                }
                            } else {
                                if (fs[47] <= -0.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0197962006367;
                                    } else {
                                        return 0.0590536570858;
                                    }
                                } else {
                                    return 0.0640403518619;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
