/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree78 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[101] <= 0.5) {
                if (fs[0] <= 1.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[16] <= 0.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.00456628654866;
                                    } else {
                                        return 0.0504007117526;
                                    }
                                } else {
                                    if (fs[53] <= -1113.5) {
                                        return 0.0223239823978;
                                    } else {
                                        return -0.136351334547;
                                    }
                                }
                            } else {
                                return -0.0769249438021;
                            }
                        } else {
                            if (fs[72] <= 5000.0) {
                                if (fs[23] <= 0.5) {
                                    return 0.117657624236;
                                } else {
                                    return 0.121364722578;
                                }
                            } else {
                                return 0.090594652173;
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[53] <= -1123.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0201762307041;
                                    } else {
                                        return -0.0588915340686;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0123290533438;
                                    } else {
                                        return -0.107220062783;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0242665244013;
                                    } else {
                                        return -0.0344439215067;
                                    }
                                } else {
                                    return 0.167192956482;
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.0170854684504;
                                    } else {
                                        return 0.0411942897943;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0606809834516;
                                    } else {
                                        return -0.0678444373539;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0644653008489;
                                    } else {
                                        return 0.0363462496073;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0673730238778;
                                    } else {
                                        return 0.0280990088107;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 2.5) {
                        if (fs[0] <= 4.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[0] <= 2.5) {
                                    return 0.108477225347;
                                } else {
                                    return 0.160729300719;
                                }
                            } else {
                                return 0.348357256631;
                            }
                        } else {
                            return 0.0798773599939;
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.00170380288124;
                                    } else {
                                        return -0.0756858429919;
                                    }
                                } else {
                                    if (fs[0] <= 25.5) {
                                        return 0.0273562562999;
                                    } else {
                                        return -0.0563890989914;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0286067193435;
                                    } else {
                                        return -0.00558484716356;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0163422004801;
                                    } else {
                                        return -0.0733795472797;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1058.0) {
                                return 0.299709294069;
                            } else {
                                if (fs[52] <= 0.5) {
                                    return -0.0442428192242;
                                } else {
                                    return -0.114694088497;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[79] <= 0.5) {
                    if (fs[72] <= 4962.0) {
                        if (fs[11] <= 0.5) {
                            if (fs[101] <= 1.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 27.5) {
                                        return -0.011402991338;
                                    } else {
                                        return -0.00322926006912;
                                    }
                                } else {
                                    if (fs[4] <= 27.5) {
                                        return 0.0126521013732;
                                    } else {
                                        return -0.00413421484588;
                                    }
                                }
                            } else {
                                if (fs[53] <= -982.0) {
                                    return -0.0450570084938;
                                } else {
                                    return 0.0136884795473;
                                }
                            }
                        } else {
                            if (fs[4] <= 87.5) {
                                if (fs[0] <= 6.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.010902575152;
                                    } else {
                                        return -0.00727583397724;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.000320964389113;
                                    } else {
                                        return 0.00331541217693;
                                    }
                                }
                            } else {
                                return -0.0545653086462;
                            }
                        }
                    } else {
                        return -0.0811888086315;
                    }
                } else {
                    if (fs[72] <= 4847.0) {
                        if (fs[0] <= 4.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[4] <= 32.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0918523384403;
                                    } else {
                                        return -0.0246318339876;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0251536266165;
                                    } else {
                                        return -0.0376812155081;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return -0.0658518538864;
                                } else {
                                    if (fs[53] <= -1338.0) {
                                        return -0.0294552092613;
                                    } else {
                                        return -0.0303476377656;
                                    }
                                }
                            }
                        } else {
                            return -0.00313587627246;
                        }
                    } else {
                        return 0.075236957381;
                    }
                }
            }
        } else {
            if (fs[64] <= -996.5) {
                if (fs[45] <= 0.5) {
                    if (fs[49] <= -1.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[53] <= -1313.5) {
                                if (fs[28] <= 0.5) {
                                    return -0.0255327394399;
                                } else {
                                    return -0.205475916899;
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0412654387151;
                                    } else {
                                        return 0.0703419586438;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.0925760052958;
                                    } else {
                                        return 0.263934619542;
                                    }
                                }
                            }
                        } else {
                            return 0.278105981415;
                        }
                    } else {
                        if (fs[14] <= 0.5) {
                            if (fs[64] <= -997.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[47] <= -46.0) {
                                        return 0.298148816125;
                                    } else {
                                        return 0.00272072052558;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0712824266734;
                                    } else {
                                        return 0.0375497447999;
                                    }
                                }
                            } else {
                                if (fs[47] <= -15.5) {
                                    if (fs[47] <= -25.5) {
                                        return 0.0205466913797;
                                    } else {
                                        return -0.336871460365;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.0486222031027;
                                    } else {
                                        return -0.00163882432165;
                                    }
                                }
                            }
                        } else {
                            return -0.181791619544;
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        return 0.112460352536;
                    } else {
                        if (fs[26] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[47] <= -34.0) {
                                    return -0.0482223115027;
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return -0.0115378896027;
                                    } else {
                                        return -0.00275552415235;
                                    }
                                }
                            } else {
                                if (fs[4] <= 16.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0261387440857;
                                    } else {
                                        return -0.0151777874176;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.0205550633709;
                                    } else {
                                        return -0.0120977110013;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 11.5) {
                                        return -0.00462380309325;
                                    } else {
                                        return -0.00255870555259;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.00830319143892;
                                    } else {
                                        return 0.0426417894925;
                                    }
                                }
                            } else {
                                if (fs[4] <= 20.5) {
                                    return -0.0100298180953;
                                } else {
                                    return 0.14338889463;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[53] <= -1498.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[47] <= -411.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.163978160649;
                                    } else {
                                        return 0.239375166199;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return 0.0435535274035;
                                    } else {
                                        return 0.219434604803;
                                    }
                                }
                            } else {
                                if (fs[88] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.172380784768;
                                    } else {
                                        return -0.256985425149;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.111865538921;
                                    } else {
                                        return -0.0352494605185;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[53] <= -1578.0) {
                                        return 0.0980108888576;
                                    } else {
                                        return 0.237184440993;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.151103037716;
                                    } else {
                                        return -0.0166924244003;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1608.0) {
                                    if (fs[53] <= -2018.0) {
                                        return 0.201045851487;
                                    } else {
                                        return 0.0618527518624;
                                    }
                                } else {
                                    return -0.146895705345;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[47] <= -0.5) {
                                    if (fs[88] <= 5.5) {
                                        return 0.0151809298894;
                                    } else {
                                        return 0.0416062479215;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.027796794785;
                                    } else {
                                        return -0.079028806367;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.00630262965036;
                                    } else {
                                        return 0.202816773797;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0483135825167;
                                    } else {
                                        return 0.121059642192;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.0384381064975;
                                    } else {
                                        return -0.00302154914414;
                                    }
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.0311677000025;
                                    } else {
                                        return -0.0987712358411;
                                    }
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0391874681344;
                                    } else {
                                        return -0.016654396373;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.310806048227;
                                    } else {
                                        return 0.163614936545;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[4] <= 3.5) {
                            if (fs[88] <= 3.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.00254166715985;
                                    } else {
                                        return 0.0267009375298;
                                    }
                                } else {
                                    if (fs[53] <= -566.5) {
                                        return 0.0729738473004;
                                    } else {
                                        return 0.0131702477729;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.014363337692;
                                    } else {
                                        return -0.0492636324285;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0746895605671;
                                    } else {
                                        return 0.0326289921984;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -2958.0) {
                                if (fs[0] <= 2.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0661786928871;
                                    } else {
                                        return 0.235896342436;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return 0.0335889358366;
                                    } else {
                                        return -0.000555228592494;
                                    }
                                }
                            } else {
                                if (fs[55] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return -0.00156923529106;
                                    } else {
                                        return 0.0122490345175;
                                    }
                                } else {
                                    if (fs[88] <= 2.5) {
                                        return 0.0248256213195;
                                    } else {
                                        return 0.181150344665;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 11.5) {
                            if (fs[53] <= -1488.0) {
                                if (fs[76] <= 75.0) {
                                    if (fs[90] <= 0.5) {
                                        return 0.000749024211739;
                                    } else {
                                        return 0.0814480690542;
                                    }
                                } else {
                                    if (fs[88] <= 3.0) {
                                        return 0.0932272101379;
                                    } else {
                                        return 0.0239753998422;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9994.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.000292829778645;
                                    } else {
                                        return 0.0151972784644;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.023195370222;
                                    } else {
                                        return 0.22031665528;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -1.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.00310762689605;
                                    } else {
                                        return -0.00638002386822;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return -0.0016053737241;
                                    } else {
                                        return -0.0237719453448;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0323245135497;
                                    } else {
                                        return -0.0059210026896;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0620772144012;
                                    } else {
                                        return -0.0205282852789;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
