/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree31 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[101] <= 0.5) {
                if (fs[60] <= 0.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[53] <= -988.0) {
                            if (fs[79] <= 0.5) {
                                if (fs[6] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0304464082145;
                                    } else {
                                        return 0.270058627767;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.154423578059;
                                    } else {
                                        return 0.199881774853;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0520298377442;
                                    } else {
                                        return 0.211350558755;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.173875052453;
                                    } else {
                                        return 0.205249335958;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0830365530716;
                                    } else {
                                        return -0.151298715877;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0276149873892;
                                    } else {
                                        return 0.000340257960774;
                                    }
                                }
                            } else {
                                return 0.142505522411;
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.366677434784;
                                    } else {
                                        return 0.275400073636;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.27193474925;
                                    } else {
                                        return 0.236655920008;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.191043416296;
                                    } else {
                                        return 0.212038997742;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.240705173253;
                                    } else {
                                        return 0.207094034497;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[53] <= -1128.0) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0285595503826;
                                    } else {
                                        return 0.00631949316769;
                                    }
                                } else {
                                    return 0.0866470174029;
                                }
                            } else {
                                if (fs[53] <= -1128.0) {
                                    if (fs[70] <= -1.5) {
                                        return -0.0396728984834;
                                    } else {
                                        return 0.190220769848;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0286187627587;
                                    } else {
                                        return -0.0195285481299;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    return -0.0735661346801;
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return 0.236755272873;
                                    } else {
                                        return 0.072662074349;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0565877388593;
                                    } else {
                                        return 0.171968055938;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.192280659904;
                                    } else {
                                        return 0.250195573598;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                return 0.204570243793;
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.148820170103;
                                    } else {
                                        return 0.170150910681;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.208306462886;
                                    } else {
                                        return 0.197356327571;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[53] <= -983.0) {
                                    if (fs[33] <= 0.5) {
                                        return 0.178945952595;
                                    } else {
                                        return -0.152750576456;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.167383466141;
                                    } else {
                                        return -0.0421534924389;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return 0.0182517364222;
                                } else {
                                    return -0.0156643059563;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.227771274377;
                                    } else {
                                        return 0.344223813828;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return -0.0080483685629;
                                    } else {
                                        return 0.355405790159;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0179580877054;
                                    } else {
                                        return -0.107609987103;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.316240221872;
                                    } else {
                                        return 0.162660756085;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[78] <= 0.5) {
                    if (fs[0] <= 5.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[4] <= 32.5) {
                                if (fs[0] <= 0.5) {
                                    return 0.20956981582;
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.0107533735449;
                                    } else {
                                        return 0.0713441237862;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1348.0) {
                                    return -0.138299549152;
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0613875290804;
                                    } else {
                                        return -0.0166822900868;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                return -0.0749741817086;
                            } else {
                                if (fs[4] <= 29.5) {
                                    return -0.0411929581359;
                                } else {
                                    return -0.0325770982027;
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[4] <= 23.5) {
                                if (fs[0] <= 8.5) {
                                    if (fs[0] <= 6.5) {
                                        return -0.0370446117252;
                                    } else {
                                        return -0.0202996249698;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return 0.0918402977999;
                                    } else {
                                        return -0.0166709893346;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 7.5) {
                                        return 0.0159880702692;
                                    } else {
                                        return -0.0287371630528;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0224659745609;
                                    } else {
                                        return -0.0196743714461;
                                    }
                                }
                            }
                        } else {
                            return -0.0240930246039;
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[13] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[53] <= -1468.0) {
                                        return -0.0586720486629;
                                    } else {
                                        return -0.0347019513823;
                                    }
                                } else {
                                    if (fs[53] <= -410.5) {
                                        return -0.0221085395637;
                                    } else {
                                        return -0.0338810768753;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    return 0.0797294565388;
                                } else {
                                    return -0.0225803532006;
                                }
                            }
                        } else {
                            return -0.145119601513;
                        }
                    } else {
                        if (fs[0] <= 6.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[53] <= -1133.0) {
                                    return -0.0430961085606;
                                } else {
                                    return -0.0261392663308;
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0204559001328;
                                    } else {
                                        return -0.0214375292288;
                                    }
                                } else {
                                    if (fs[4] <= 39.5) {
                                        return -0.0191982621894;
                                    } else {
                                        return -0.0142212270137;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[0] <= 8.5) {
                                    return -0.0153959003069;
                                } else {
                                    if (fs[7] <= 0.5) {
                                        return -0.0130739021912;
                                    } else {
                                        return -0.0149520276294;
                                    }
                                }
                            } else {
                                if (fs[4] <= 81.5) {
                                    return -0.0352899786226;
                                } else {
                                    return -0.0409017822123;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[72] <= 9996.5) {
                if (fs[26] <= 0.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[53] <= -977.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.253203853845;
                                    } else {
                                        return 0.159909239356;
                                    }
                                } else {
                                    if (fs[88] <= 4.5) {
                                        return 0.0741779399268;
                                    } else {
                                        return 0.151323807937;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[47] <= -3.5) {
                                        return 0.17041229263;
                                    } else {
                                        return 0.0860873601873;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.0697763471712;
                                    } else {
                                        return -0.0235133120407;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.205880598648;
                                    } else {
                                        return -0.117620245165;
                                    }
                                } else {
                                    if (fs[2] <= 9.5) {
                                        return 0.101410984716;
                                    } else {
                                        return 0.276844616646;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[4] <= 3.5) {
                                        return 0.13858071599;
                                    } else {
                                        return -0.0185417094824;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.123625983465;
                                    } else {
                                        return -0.198740699166;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -2386.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[47] <= -2396.0) {
                                    if (fs[2] <= 6.5) {
                                        return 0.00270772952611;
                                    } else {
                                        return 0.431694959154;
                                    }
                                } else {
                                    return 0.497764710787;
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[53] <= -1468.0) {
                                        return 0.175983255862;
                                    } else {
                                        return -0.0813129569477;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.376677774051;
                                    } else {
                                        return 0.250495213511;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0461841107733;
                                    } else {
                                        return -0.02748341677;
                                    }
                                } else {
                                    if (fs[47] <= -11.5) {
                                        return 0.0456628677433;
                                    } else {
                                        return -0.00147070614507;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0111252180002;
                                    } else {
                                        return -0.00337829771153;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.012833570602;
                                    } else {
                                        return -0.010660321;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -1043.5) {
                            if (fs[103] <= 1.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0992119159242;
                                    } else {
                                        return -0.0210166490008;
                                    }
                                } else {
                                    return 0.379956526366;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[53] <= -1128.5) {
                                        return 0.133661063865;
                                    } else {
                                        return 0.216335412798;
                                    }
                                } else {
                                    if (fs[0] <= 40.5) {
                                        return 0.060553825285;
                                    } else {
                                        return 0.470943658043;
                                    }
                                }
                            }
                        } else {
                            if (fs[103] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.362918366863;
                                    } else {
                                        return -0.214524213419;
                                    }
                                } else {
                                    if (fs[4] <= 1.5) {
                                        return 0.111750231508;
                                    } else {
                                        return -0.015472675711;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.0443873421924;
                                    } else {
                                        return -0.00531020905633;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0129096978533;
                                    } else {
                                        return -0.00690187641161;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1078.0) {
                            if (fs[4] <= 10.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.192681009221;
                                    } else {
                                        return 0.155349035389;
                                    }
                                } else {
                                    if (fs[0] <= 21.5) {
                                        return 0.0466754920855;
                                    } else {
                                        return 0.76795916375;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.185606895883;
                                    } else {
                                        return -0.0135387661049;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.00109194390299;
                                    } else {
                                        return 0.112173344431;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0168849302602;
                                    } else {
                                        return -0.182680503546;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.307547405293;
                                    } else {
                                        return 0.192649530682;
                                    }
                                }
                            } else {
                                if (fs[53] <= -936.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0120162615127;
                                    } else {
                                        return -0.0157766419312;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.000922134003938;
                                    } else {
                                        return 0.136907157583;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1052.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[47] <= -8.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[47] <= -207.5) {
                                    if (fs[53] <= -1538.0) {
                                        return 0.363885986106;
                                    } else {
                                        return 0.242580767553;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.158335451688;
                                    } else {
                                        return 0.306970303206;
                                    }
                                }
                            } else {
                                if (fs[47] <= -13.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.00244229407535;
                                    } else {
                                        return 0.19873975933;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.0485998737618;
                                    } else {
                                        return -0.123345851301;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.177642843072;
                                    } else {
                                        return 0.101788606186;
                                    }
                                } else {
                                    return -0.290419570485;
                                }
                            } else {
                                if (fs[53] <= -1117.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.00411103006654;
                                    } else {
                                        return 0.0562524668848;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.545224635396;
                                    } else {
                                        return 0.087755002144;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 18.5) {
                            if (fs[98] <= 0.5) {
                                if (fs[47] <= -13.5) {
                                    if (fs[66] <= 5.0) {
                                        return 0.210746244864;
                                    } else {
                                        return -0.236546224981;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.163006643069;
                                    } else {
                                        return 0.0761502608212;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.233504669695;
                                    } else {
                                        return 0.348391011712;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.226329107814;
                                    } else {
                                        return 0.145806192216;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 20.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[47] <= -91.5) {
                                        return 0.342694870045;
                                    } else {
                                        return -0.00628375704791;
                                    }
                                } else {
                                    if (fs[53] <= -1443.0) {
                                        return -0.179161580952;
                                    } else {
                                        return -0.0663349618782;
                                    }
                                }
                            } else {
                                if (fs[55] <= 0.5) {
                                    if (fs[76] <= 150.0) {
                                        return 0.170609186493;
                                    } else {
                                        return 0.06030927889;
                                    }
                                } else {
                                    return 0.490011391809;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0195249957278;
                                    } else {
                                        return 0.0801434186455;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.100248153836;
                                    } else {
                                        return 0.183313951982;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.158133233363;
                                    } else {
                                        return 0.244569452491;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0421502953787;
                                    } else {
                                        return 0.245879251068;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.0998259059119;
                                    } else {
                                        return -0.0269811742971;
                                    }
                                } else {
                                    if (fs[32] <= 0.5) {
                                        return -0.0020528756226;
                                    } else {
                                        return 0.470923146213;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.200530138594;
                                    } else {
                                        return 0.0305201709577;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.144511181826;
                                    } else {
                                        return -0.0259732160703;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[88] <= 1.5) {
                                        return 0.167505754391;
                                    } else {
                                        return 0.228976079387;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.014707388443;
                                    } else {
                                        return 0.161215076811;
                                    }
                                }
                            } else {
                                if (fs[25] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.295376442759;
                                    } else {
                                        return 0.0699222752217;
                                    }
                                } else {
                                    return -0.320064357697;
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[103] <= 0.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.0882162551266;
                                    } else {
                                        return 0.0142347432725;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.0289935128013;
                                    } else {
                                        return -0.0359902663092;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.187293664132;
                                    } else {
                                        return -0.0795483353454;
                                    }
                                } else {
                                    if (fs[101] <= 1.0) {
                                        return 0.034990024907;
                                    } else {
                                        return -0.0532163484935;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
