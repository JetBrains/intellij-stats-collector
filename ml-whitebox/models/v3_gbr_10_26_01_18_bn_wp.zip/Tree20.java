/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree20 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[53] <= -987.5) {
                    if (fs[22] <= 0.5) {
                        if (fs[74] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[98] <= 0.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.253361990945;
                                    } else {
                                        return 0.339018588197;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.433729266037;
                                    } else {
                                        return 0.221384278247;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return 0.315523704658;
                                    } else {
                                        return 0.236036271566;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return 0.239797967601;
                                    } else {
                                        return 0.152741250292;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.5) {
                                if (fs[72] <= 9992.5) {
                                    if (fs[53] <= -1314.0) {
                                        return -0.00832190523559;
                                    } else {
                                        return -0.160644133611;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return -0.290469160129;
                                    } else {
                                        return -0.0179557499089;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    return 0.189918499447;
                                } else {
                                    if (fs[53] <= -1128.5) {
                                        return 0.203406023521;
                                    } else {
                                        return 0.350629307086;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[72] <= 9998.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0661222151276;
                                    } else {
                                        return -0.0622160193114;
                                    }
                                } else {
                                    if (fs[72] <= 9299.5) {
                                        return 0.323234198696;
                                    } else {
                                        return 0.117469158133;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.24311179071;
                                    } else {
                                        return 0.363517871033;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.196995752082;
                                    } else {
                                        return 0.014048683146;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.43847967988;
                                    } else {
                                        return 0.370392230949;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0695333876481;
                                    } else {
                                        return 0.40900163162;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.285770193996;
                                    } else {
                                        return 0.120341891659;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0878796406327;
                                    } else {
                                        return 0.291006655097;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[26] <= 0.5) {
                        if (fs[49] <= -0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[72] <= 5000.0) {
                                        return -0.0370120744073;
                                    } else {
                                        return 0.363469745462;
                                    }
                                } else {
                                    return 0.315924878899;
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[47] <= -2.5) {
                                        return 0.415523494996;
                                    } else {
                                        return 0.316139427077;
                                    }
                                } else {
                                    if (fs[47] <= -3.5) {
                                        return 0.123998370102;
                                    } else {
                                        return 0.283117818287;
                                    }
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[72] <= 9889.5) {
                                        return 0.0822624089904;
                                    } else {
                                        return 0.212678042027;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.074119016935;
                                    } else {
                                        return -0.131044265165;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.532901100575;
                                    } else {
                                        return 0.376775222527;
                                    }
                                } else {
                                    return 0.147709014097;
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 250.0) {
                            if (fs[4] <= 7.5) {
                                if (fs[47] <= -1.5) {
                                    return 0.240317838558;
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0663450780119;
                                    } else {
                                        return -0.0540584968283;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[101] <= 1.5) {
                                        return -0.149008226745;
                                    } else {
                                        return -0.270764104663;
                                    }
                                } else {
                                    return -0.225496334413;
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                return -0.0961768463846;
                            } else {
                                return 0.0892223712264;
                            }
                        }
                    }
                }
            } else {
                if (fs[41] <= 0.5) {
                    if (fs[22] <= 0.5) {
                        if (fs[4] <= 10.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[53] <= -987.0) {
                                    if (fs[92] <= 0.5) {
                                        return 0.407343484479;
                                    } else {
                                        return 0.328631637216;
                                    }
                                } else {
                                    if (fs[88] <= -0.5) {
                                        return -0.0567272830348;
                                    } else {
                                        return 0.289172146255;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1143.5) {
                                    if (fs[72] <= 4639.5) {
                                        return -0.0518009318614;
                                    } else {
                                        return -0.0865832274089;
                                    }
                                } else {
                                    if (fs[72] <= 9902.0) {
                                        return 0.0666762984284;
                                    } else {
                                        return 0.367088021441;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0279524351727;
                                    } else {
                                        return 0.282124834455;
                                    }
                                } else {
                                    if (fs[13] <= 0.5) {
                                        return 0.295624790256;
                                    } else {
                                        return 0.393780880488;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[53] <= -987.0) {
                                        return 0.22744682688;
                                    } else {
                                        return 0.139025554611;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.568579045874;
                                    } else {
                                        return 0.46736214525;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[72] <= 9838.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[72] <= 9356.5) {
                                        return 0.250819025467;
                                    } else {
                                        return -0.0582791705693;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.079023755953;
                                    } else {
                                        return 0.322919440645;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.0) {
                                    if (fs[18] <= -0.5) {
                                        return -0.247215891304;
                                    } else {
                                        return 0.209295630514;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.489941696732;
                                    } else {
                                        return 0.193032033931;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 9.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.3690667019;
                                    } else {
                                        return -0.318939148191;
                                    }
                                } else {
                                    if (fs[72] <= 9878.5) {
                                        return 0.237191709377;
                                    } else {
                                        return 0.324243140289;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9996.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.191044691881;
                                    } else {
                                        return -0.0759297985132;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.279185897755;
                                    } else {
                                        return 0.365179095742;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 7.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[47] <= -98.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.279054901928;
                                    } else {
                                        return -0.0275071633619;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return -0.0254654174048;
                                    } else {
                                        return 0.342391169062;
                                    }
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.286916877118;
                                    } else {
                                        return -0.158543854737;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.123678142081;
                                    } else {
                                        return -0.311613769664;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[53] <= -1043.0) {
                                    return 0.336913894697;
                                } else {
                                    return 0.169275695318;
                                }
                            } else {
                                if (fs[13] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.166002061757;
                                    } else {
                                        return 0.117893016238;
                                    }
                                } else {
                                    return -0.305471928666;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[60] <= 0.5) {
                                return 0.390830313278;
                            } else {
                                return 0.0102231202317;
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[2] <= 5.5) {
                                    return 0.262138246133;
                                } else {
                                    if (fs[72] <= 4440.0) {
                                        return 0.403383119181;
                                    } else {
                                        return 0.420432448919;
                                    }
                                }
                            } else {
                                if (fs[47] <= -2.5) {
                                    return 0.342505287673;
                                } else {
                                    return 0.141283384506;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[72] <= 9653.0) {
                    if (fs[45] <= 0.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[47] <= -83.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.137015910516;
                                    } else {
                                        return -0.0059924093791;
                                    }
                                } else {
                                    if (fs[88] <= -0.5) {
                                        return -0.0333107519658;
                                    } else {
                                        return 0.00847655150648;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.0375361242013;
                                    } else {
                                        return 0.336633300486;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0877374345862;
                                    } else {
                                        return 0.00784345968165;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -1273.0) {
                                        return 0.236892520141;
                                    } else {
                                        return 0.0921310944726;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.084529998024;
                                    } else {
                                        return -0.0152156388106;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[64] <= -996.5) {
                                        return 0.13310384432;
                                    } else {
                                        return 0.0217196270247;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.141836961507;
                                    } else {
                                        return 0.031265363839;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -311.0) {
                            return 0.237731324404;
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[62] <= -2.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.041512046021;
                                    } else {
                                        return 0.185816272006;
                                    }
                                } else {
                                    if (fs[92] <= 0.5) {
                                        return -0.0453261822584;
                                    } else {
                                        return -0.0318544630864;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.225305504552;
                                } else {
                                    return -0.079541333506;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 7.5) {
                        if (fs[24] <= 0.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[47] <= -5.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.123792083028;
                                    } else {
                                        return 0.0370750110527;
                                    }
                                } else {
                                    if (fs[2] <= 7.5) {
                                        return 0.0312806762622;
                                    } else {
                                        return 0.206640286002;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[4] <= 17.5) {
                                        return 0.160150853055;
                                    } else {
                                        return 0.027822287303;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0839323700402;
                                    } else {
                                        return -0.0168495244484;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[47] <= -318.0) {
                                    if (fs[4] <= 7.5) {
                                        return 0.588953330108;
                                    } else {
                                        return 0.2160761869;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.118822305444;
                                    } else {
                                        return 0.371615512837;
                                    }
                                }
                            } else {
                                return 0.619601002307;
                            }
                        }
                    } else {
                        if (fs[53] <= -1458.0) {
                            if (fs[93] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.297191101346;
                                    } else {
                                        return 0.483157194043;
                                    }
                                } else {
                                    if (fs[47] <= -3.5) {
                                        return 0.322960321883;
                                    } else {
                                        return 0.112038634869;
                                    }
                                }
                            } else {
                                return -0.32334143803;
                            }
                        } else {
                            if (fs[72] <= 9994.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.156555167807;
                                    } else {
                                        return -0.0433595356093;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.111261869585;
                                    } else {
                                        return 0.0412026721768;
                                    }
                                }
                            } else {
                                if (fs[47] <= -4.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0842319648475;
                                    } else {
                                        return -0.112313621433;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.198765424722;
                                    } else {
                                        return 0.0116296553181;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[72] <= 9977.5) {
                    if (fs[0] <= 3.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    return 0.478131014378;
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.0305713950607;
                                    } else {
                                        return -0.0273311356895;
                                    }
                                }
                            } else {
                                if (fs[53] <= 3.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00380357735101;
                                    } else {
                                        return 0.0220485793389;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0304671297298;
                                    } else {
                                        return -0.0231990639122;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.0105743683516;
                                    } else {
                                        return -0.0245140362375;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.00501951101812;
                                    } else {
                                        return 0.298972767592;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.00637691360632;
                                    } else {
                                        return -0.021434964032;
                                    }
                                } else {
                                    return 0.277043956161;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 14.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[101] <= 1.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.00372132884081;
                                    } else {
                                        return -0.0182160123163;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return 0.000785411828265;
                                    } else {
                                        return -0.015851233151;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[57] <= 0.5) {
                                        return -0.0209740784474;
                                    } else {
                                        return 0.184985831488;
                                    }
                                } else {
                                    if (fs[47] <= -1527.0) {
                                        return 0.110650309176;
                                    } else {
                                        return -0.0159016461215;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -2.5) {
                                if (fs[53] <= -1078.0) {
                                    return 0.32127146435;
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.141318975962;
                                    } else {
                                        return -0.000495856117914;
                                    }
                                }
                            } else {
                                if (fs[0] <= 120.5) {
                                    if (fs[29] <= 0.5) {
                                        return -0.0214450419901;
                                    } else {
                                        return -0.0117167164739;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0216969565228;
                                    } else {
                                        return 0.0111730355378;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1277.5) {
                        if (fs[100] <= 0.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0143663551089;
                                    } else {
                                        return 0.200162818754;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0300590344192;
                                    } else {
                                        return 0.200468110953;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.19892248178;
                                    } else {
                                        return 0.0130049393544;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.540440369344;
                                    } else {
                                        return 0.19803647476;
                                    }
                                }
                            }
                        } else {
                            return 0.662719993916;
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[64] <= -995.5) {
                                    return 0.367012176304;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0267419761276;
                                    } else {
                                        return 0.0048547683814;
                                    }
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.0222651318528;
                                    } else {
                                        return 0.205946988631;
                                    }
                                } else {
                                    if (fs[47] <= -833.0) {
                                        return 0.36208934988;
                                    } else {
                                        return -0.00115524815659;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -2246.0) {
                                return 0.0538219965607;
                            } else {
                                if (fs[53] <= -1132.0) {
                                    return -0.0750763304937;
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.0302102193592;
                                    } else {
                                        return -0.0244331217875;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
