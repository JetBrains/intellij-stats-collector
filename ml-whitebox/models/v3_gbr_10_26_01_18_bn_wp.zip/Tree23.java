/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree23 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 9.5) {
                if (fs[41] <= 0.5) {
                    if (fs[53] <= -1053.0) {
                        if (fs[53] <= -1133.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.176225222277;
                                    } else {
                                        return -0.0456302966274;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.343105928805;
                                    } else {
                                        return 0.25813745177;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0413202040359;
                                    } else {
                                        return 0.259576773954;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.296441995139;
                                    } else {
                                        return 0.266815097723;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1123.5) {
                                if (fs[72] <= 9970.0) {
                                    if (fs[74] <= 0.5) {
                                        return 0.290853281388;
                                    } else {
                                        return 0.0294583097314;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.321095179491;
                                    } else {
                                        return 0.39354327543;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[47] <= -18.0) {
                                        return 0.47151155631;
                                    } else {
                                        return 0.321077050738;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.16672345362;
                                    } else {
                                        return 0.361345256676;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0500666302468;
                                    } else {
                                        return 0.166788516537;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return 0.367796885202;
                                    } else {
                                        return 0.186259752909;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.288718813607;
                                    } else {
                                        return 0.346803473325;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.480852962443;
                                    } else {
                                        return -0.0729040544061;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[62] <= -0.5) {
                                        return 0.315493024225;
                                    } else {
                                        return 0.162161515049;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.0794269262451;
                                    } else {
                                        return 0.422919540111;
                                    }
                                }
                            } else {
                                if (fs[88] <= 3.5) {
                                    if (fs[84] <= 0.5) {
                                        return -0.0787654476005;
                                    } else {
                                        return 0.225851195775;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.343879536463;
                                    } else {
                                        return 0.261257824872;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 7.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[59] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0111809554535;
                                    } else {
                                        return 0.393398004476;
                                    }
                                } else {
                                    return -0.0622147091964;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.356759117916;
                                    } else {
                                        return 0.311354695371;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.297531229638;
                                    } else {
                                        return 0.316343084285;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[23] <= 0.5) {
                                    if (fs[53] <= -1488.5) {
                                        return 0.0524321801266;
                                    } else {
                                        return -0.0635701273888;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0790168070526;
                                    } else {
                                        return 0.0970544778538;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.216297064852;
                                    } else {
                                        return -0.122543140761;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0127261309768;
                                    } else {
                                        return 0.102422007975;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[72] <= 9005.0) {
                                return 0.125213523161;
                            } else {
                                return -0.219903583464;
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                return 0.0750251370362;
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[47] <= -163.0) {
                                        return 0.349785661679;
                                    } else {
                                        return 0.392324300758;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return 0.336546435057;
                                    } else {
                                        return 0.252792708322;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 5.5) {
                    if (fs[76] <= 250.0) {
                        if (fs[53] <= -1588.0) {
                            if (fs[76] <= 25.0) {
                                if (fs[105] <= 0.5) {
                                    if (fs[53] <= -1998.5) {
                                        return 0.368189283235;
                                    } else {
                                        return 0.234774085745;
                                    }
                                } else {
                                    if (fs[88] <= 1.5) {
                                        return -0.156598066606;
                                    } else {
                                        return 0.256934784926;
                                    }
                                }
                            } else {
                                if (fs[4] <= 37.0) {
                                    if (fs[2] <= 0.5) {
                                        return -0.130363915492;
                                    } else {
                                        return 0.361572293438;
                                    }
                                } else {
                                    return 0.0474292715536;
                                }
                            }
                        } else {
                            if (fs[102] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0825927730887;
                                    } else {
                                        return 0.169729684524;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.0946321592007;
                                    } else {
                                        return -0.0140688416396;
                                    }
                                }
                            } else {
                                if (fs[50] <= 0.5) {
                                    if (fs[72] <= 9976.5) {
                                        return -0.0163405189893;
                                    } else {
                                        return 0.315373816657;
                                    }
                                } else {
                                    if (fs[53] <= -490.5) {
                                        return 0.329931915892;
                                    } else {
                                        return 0.25228839269;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[63] <= 0.5) {
                                if (fs[49] <= -3.5) {
                                    return -0.0315145011635;
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.274953077295;
                                    } else {
                                        return 0.19836580119;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.216920936747;
                                    } else {
                                        return 0.0671548513555;
                                    }
                                } else {
                                    return -0.35766811812;
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[53] <= -1518.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.205249474634;
                                    } else {
                                        return 0.412395309033;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.0977311948335;
                                    } else {
                                        return 0.221335634253;
                                    }
                                }
                            } else {
                                return -0.159625046474;
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 14.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[2] <= 8.5) {
                                if (fs[53] <= -491.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.364678007309;
                                    } else {
                                        return 0.215744879112;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.108541288162;
                                    } else {
                                        return 0.287742517921;
                                    }
                                }
                            } else {
                                if (fs[2] <= 11.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.369015336279;
                                    } else {
                                        return 0.453700197054;
                                    }
                                } else {
                                    return 0.51679201188;
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[47] <= -2.5) {
                                    if (fs[47] <= -73.5) {
                                        return 0.413756950425;
                                    } else {
                                        return 0.312965359928;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.14931682514;
                                    } else {
                                        return 0.298654866461;
                                    }
                                }
                            } else {
                                if (fs[76] <= 100.0) {
                                    if (fs[62] <= -0.5) {
                                        return 0.487931460527;
                                    } else {
                                        return 0.308915538105;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.330574722928;
                                    } else {
                                        return 0.422641167266;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 9.5) {
                            if (fs[47] <= -89.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[53] <= -1468.0) {
                                        return 0.425020118103;
                                    } else {
                                        return 0.227924017726;
                                    }
                                } else {
                                    return 0.510799066248;
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[25] <= 0.5) {
                                        return 0.084616944605;
                                    } else {
                                        return 0.268134796094;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.177475312861;
                                    } else {
                                        return 0.258111293655;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 16.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[2] <= 11.5) {
                                        return 0.297411024748;
                                    } else {
                                        return 0.431158204582;
                                    }
                                } else {
                                    if (fs[72] <= 9968.0) {
                                        return 0.305053450081;
                                    } else {
                                        return 0.110986674009;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[47] <= -3.5) {
                                        return 0.449737723206;
                                    } else {
                                        return 0.503458288945;
                                    }
                                } else {
                                    return 0.402718092329;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[47] <= -3640.5) {
                if (fs[88] <= 7.5) {
                    if (fs[72] <= 9994.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[4] <= 16.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0209771341484;
                                    } else {
                                        return 0.0589256856624;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0556239226008;
                                    } else {
                                        return 0.134395998644;
                                    }
                                }
                            } else {
                                return 0.19626595428;
                            }
                        } else {
                            if (fs[72] <= 9979.0) {
                                if (fs[2] <= 4.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.257421687964;
                                    } else {
                                        return 0.0289787470828;
                                    }
                                } else {
                                    return 0.541544798652;
                                }
                            } else {
                                return -0.0832508440782;
                            }
                        }
                    } else {
                        if (fs[53] <= -1458.0) {
                            if (fs[4] <= 9.0) {
                                return 0.36199386408;
                            } else {
                                return 0.605560408306;
                            }
                        } else {
                            return 0.112326813304;
                        }
                    }
                } else {
                    if (fs[52] <= 0.5) {
                        if (fs[53] <= -1478.0) {
                            if (fs[72] <= 4834.0) {
                                return 0.133898703184;
                            } else {
                                return -0.0590585848907;
                            }
                        } else {
                            if (fs[53] <= -476.5) {
                                return -0.235025642244;
                            } else {
                                return -0.0805062509726;
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[53] <= -1458.0) {
                                    if (fs[47] <= -3920.0) {
                                        return 0.432201748971;
                                    } else {
                                        return 0.133308790747;
                                    }
                                } else {
                                    return -0.103159251631;
                                }
                            } else {
                                return -0.048126849416;
                            }
                        } else {
                            if (fs[53] <= -1468.0) {
                                if (fs[72] <= 9785.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.417796250069;
                                    } else {
                                        return 0.693286667722;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.220010264086;
                                    } else {
                                        return 0.382324932584;
                                    }
                                }
                            } else {
                                return 0.0257985222877;
                            }
                        }
                    }
                }
            } else {
                if (fs[90] <= 0.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[88] <= 6.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[72] <= 9657.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.015838330595;
                                    } else {
                                        return -0.0137806682896;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0203452994227;
                                    } else {
                                        return 0.0826457752928;
                                    }
                                }
                            } else {
                                if (fs[47] <= -22.5) {
                                    if (fs[66] <= 5.0) {
                                        return 0.0358724070087;
                                    } else {
                                        return -0.215305742789;
                                    }
                                } else {
                                    if (fs[53] <= -1408.5) {
                                        return -0.00957464191284;
                                    } else {
                                        return -0.0408166230456;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.0316248526526;
                                    } else {
                                        return 0.327427804978;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0431216624766;
                                    } else {
                                        return 0.293804170664;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9981.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.0167890079549;
                                    } else {
                                        return -0.0118863977645;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.131439787187;
                                    } else {
                                        return 0.0440444458894;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[0] <= 8.5) {
                                if (fs[47] <= -12.5) {
                                    if (fs[53] <= -1438.0) {
                                        return 0.0165902166937;
                                    } else {
                                        return -0.011753282146;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.0115865741288;
                                    } else {
                                        return -0.0186910337085;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9939.5) {
                                    if (fs[15] <= 0.5) {
                                        return -0.018315944159;
                                    } else {
                                        return 0.0386477533584;
                                    }
                                } else {
                                    if (fs[47] <= -878.0) {
                                        return 0.148509094008;
                                    } else {
                                        return -0.0101335572222;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0168653274231;
                                    } else {
                                        return 0.0968052241276;
                                    }
                                } else {
                                    if (fs[76] <= 125.0) {
                                        return -0.00710700199631;
                                    } else {
                                        return 0.036732204158;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[0] <= 20.5) {
                                        return -0.0118448960647;
                                    } else {
                                        return -0.017258222819;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.0700428082368;
                                    } else {
                                        return 0.619162646746;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0316818330608;
                                    } else {
                                        return 0.0840768767806;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.0487710359283;
                                    } else {
                                        return -0.0121914218431;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1068.0) {
                                    if (fs[4] <= 10.5) {
                                        return 0.24077602265;
                                    } else {
                                        return 0.106342827716;
                                    }
                                } else {
                                    if (fs[53] <= -472.0) {
                                        return -0.0870136822815;
                                    } else {
                                        return 0.137045927886;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[103] <= 1.5) {
                                        return 0.0104046455433;
                                    } else {
                                        return 0.0787820997448;
                                    }
                                } else {
                                    if (fs[53] <= -1052.0) {
                                        return 0.253390231659;
                                    } else {
                                        return -0.00574209661175;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.00318702391855;
                                    } else {
                                        return 0.194673877223;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0175309261479;
                                    } else {
                                        return -0.00378042047042;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 4.5) {
                            if (fs[53] <= -1011.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0149597387516;
                                    } else {
                                        return 0.168808630567;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.0499138131078;
                                    } else {
                                        return -0.0341006351224;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0162415314465;
                                    } else {
                                        return -0.0242589757501;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.0372683668559;
                                    } else {
                                        return -0.0261897770119;
                                    }
                                }
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[49] <= -2.5) {
                                    if (fs[0] <= 6.5) {
                                        return 0.0432159745112;
                                    } else {
                                        return -0.0314263784936;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.0200408305998;
                                    } else {
                                        return -0.0252389739082;
                                    }
                                }
                            } else {
                                if (fs[53] <= 7.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.020221400893;
                                    } else {
                                        return -0.0178903349966;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.0189560628406;
                                    } else {
                                        return -0.0172431647828;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
