/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree50 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[33] <= 0.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0301268695059;
                                    } else {
                                        return 0.0781380826867;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0503591040576;
                                    } else {
                                        return 0.0244985917132;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.105602028319;
                                    } else {
                                        return 0.0719728381093;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.066182521677;
                                    } else {
                                        return 0.0540020738928;
                                    }
                                }
                            }
                        } else {
                            if (fs[27] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[53] <= -988.0) {
                                        return 0.0875057258035;
                                    } else {
                                        return 0.03372903693;
                                    }
                                } else {
                                    return 0.194415808737;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.222817101912;
                                } else {
                                    return 0.1254949433;
                                }
                            }
                        }
                    } else {
                        if (fs[60] <= 0.5) {
                            if (fs[50] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[53] <= -1063.0) {
                                        return 0.0980036105311;
                                    } else {
                                        return -0.0763526634513;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0282528930615;
                                    } else {
                                        return 0.139090696569;
                                    }
                                }
                            } else {
                                return -0.076456363208;
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                if (fs[0] <= 4.5) {
                                    return 0.26381262569;
                                } else {
                                    return 0.174319750302;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0100209224258;
                                    } else {
                                        return 0.169115488402;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0541629805765;
                                    } else {
                                        return 0.235318381968;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[60] <= 0.5) {
                            return 0.144244154572;
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0894789365455;
                                    } else {
                                        return -0.043627668769;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0778086645962;
                                    } else {
                                        return -0.105859922739;
                                    }
                                }
                            } else {
                                return -0.116308769032;
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[79] <= 0.5) {
                                    return -0.00712408552904;
                                } else {
                                    if (fs[0] <= 48.5) {
                                        return -0.00471440188717;
                                    } else {
                                        return -0.00577743484374;
                                    }
                                }
                            } else {
                                return -0.0107777924426;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[0] <= 5.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0153433115383;
                                    } else {
                                        return -0.011724232124;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.00595972363319;
                                    } else {
                                        return -0.0010047798757;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    return -0.061286888673;
                                } else {
                                    return -0.0355944002493;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[76] <= 100.0) {
                        if (fs[23] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                return -0.129273858256;
                            } else {
                                return 0.143322795588;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.273566431564;
                                    } else {
                                        return 0.150170772409;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return 0.113417387042;
                                    } else {
                                        return 0.151743646982;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0889645212689;
                                    } else {
                                        return 0.111832770841;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0834101106896;
                                    } else {
                                        return 0.073542710609;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[79] <= 0.5) {
                            if (fs[53] <= -1328.0) {
                                if (fs[4] <= 39.5) {
                                    return -0.136747802401;
                                } else {
                                    return -0.02708874797;
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return 0.197659714567;
                                } else {
                                    return -0.21349660165;
                                }
                            }
                        } else {
                            if (fs[53] <= -1563.0) {
                                return 0.184517512642;
                            } else {
                                return -0.183979890126;
                            }
                        }
                    }
                } else {
                    if (fs[70] <= -1.5) {
                        if (fs[59] <= 0.5) {
                            if (fs[0] <= 7.5) {
                                if (fs[4] <= 90.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.069386701212;
                                    } else {
                                        return -0.0372693512031;
                                    }
                                } else {
                                    return -0.0171052162294;
                                }
                            } else {
                                if (fs[0] <= 9.5) {
                                    if (fs[53] <= -1313.0) {
                                        return -0.0369852438006;
                                    } else {
                                        return 0.198823250192;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0223691112474;
                                    } else {
                                        return -0.00222790043515;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[78] <= 0.5) {
                                    return -0.0552693792912;
                                } else {
                                    if (fs[0] <= 4.0) {
                                        return -0.0469087202442;
                                    } else {
                                        return -0.0183380198415;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0272094086148;
                                    } else {
                                        return -0.0112879200192;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0129541825542;
                                    } else {
                                        return 0.0268599962313;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            return 0.091381165966;
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[0] <= 1.5) {
                                        return -0.00704165904906;
                                    } else {
                                        return -0.0154239629563;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0402893288068;
                                    } else {
                                        return -0.0223407237092;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.00917415701505;
                                    } else {
                                        return -0.0173577366682;
                                    }
                                } else {
                                    if (fs[76] <= 100.0) {
                                        return -0.0285521012099;
                                    } else {
                                        return -0.00769965601414;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[76] <= 25.0) {
                    if (fs[22] <= 0.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[88] <= 3.0) {
                                        return 0.168247812975;
                                    } else {
                                        return 0.0627810827993;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0166249137366;
                                    } else {
                                        return 0.089556591809;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1503.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.138407900417;
                                    } else {
                                        return -0.122022140342;
                                    }
                                } else {
                                    if (fs[47] <= -7.5) {
                                        return 0.0856694374188;
                                    } else {
                                        return -0.00621551681802;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9474.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[88] <= 1.0) {
                                        return -0.018676696127;
                                    } else {
                                        return 0.137260684753;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return 0.122543526864;
                                    } else {
                                        return -0.00111125758532;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[47] <= -388.5) {
                                        return -0.246403302249;
                                    } else {
                                        return 0.10227258788;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.167043197972;
                                    } else {
                                        return -0.143189491368;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -60.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[2] <= 7.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.270614845382;
                                    } else {
                                        return 0.0696123327213;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return 0.19798234976;
                                    } else {
                                        return 0.293895724635;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.211635545351;
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.212653722142;
                                    } else {
                                        return -0.105167559873;
                                    }
                                }
                            }
                        } else {
                            if (fs[101] <= 1.5) {
                                if (fs[72] <= 9848.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0910336606811;
                                    } else {
                                        return 0.248008864525;
                                    }
                                } else {
                                    if (fs[72] <= 9864.5) {
                                        return 0.368901043199;
                                    } else {
                                        return 0.0162260126803;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[47] <= -34.5) {
                                        return -0.140541628329;
                                    } else {
                                        return 0.0435596632866;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.238842357667;
                                    } else {
                                        return 0.125865519189;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1493.5) {
                        if (fs[4] <= 37.0) {
                            if (fs[52] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.134509440568;
                                    } else {
                                        return 0.230222891966;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.0907050410953;
                                    } else {
                                        return 0.012001181953;
                                    }
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[72] <= 9992.5) {
                                        return 0.189590412644;
                                    } else {
                                        return 0.130487632923;
                                    }
                                } else {
                                    return -0.21857666519;
                                }
                            }
                        } else {
                            if (fs[4] <= 42.0) {
                                if (fs[22] <= 0.5) {
                                    return -0.367635734342;
                                } else {
                                    return 0.0986478044547;
                                }
                            } else {
                                return -0.485587391916;
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -1488.5) {
                                if (fs[72] <= 9994.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.0222198268544;
                                    } else {
                                        return -0.153697247267;
                                    }
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return 0.0401626235848;
                                    } else {
                                        return -0.372229400684;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.0793565954521;
                                    } else {
                                        return -0.0364913400424;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0494018566301;
                                    } else {
                                        return -0.0808759396311;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 7.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.0596009789375;
                                    } else {
                                        return 0.0994029343543;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return 0.124340443159;
                                    } else {
                                        return -0.217085645967;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.143540479181;
                                    } else {
                                        return 0.0868288191495;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.260599856896;
                                    } else {
                                        return -0.0170386188826;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[41] <= 0.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[29] <= 0.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[101] <= 0.5) {
                                        return 4.38319901827e-05;
                                    } else {
                                        return 0.0182022314304;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return -0.0152371262883;
                                    } else {
                                        return 0.0394560593948;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return -0.0247524088906;
                                    } else {
                                        return 0.186057921917;
                                    }
                                } else {
                                    return 0.372892256695;
                                }
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                if (fs[88] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.464624705664;
                                    } else {
                                        return 0.155568294279;
                                    }
                                } else {
                                    if (fs[4] <= 23.0) {
                                        return -0.034219412166;
                                    } else {
                                        return 0.275238276611;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[72] <= 9998.5) {
                                        return 4.59912798833e-05;
                                    } else {
                                        return 0.182851676909;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.169864006797;
                                    } else {
                                        return -0.00126133160313;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[88] <= 5.5) {
                                if (fs[64] <= -498.5) {
                                    return 0.366653335134;
                                } else {
                                    if (fs[47] <= -34.5) {
                                        return 0.132478751994;
                                    } else {
                                        return -0.00608912464065;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[31] <= 0.5) {
                                        return 0.0679726475897;
                                    } else {
                                        return -0.0790684325906;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.192597692134;
                                    } else {
                                        return 0.035406146307;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[47] <= -15.5) {
                                        return 0.130160094231;
                                    } else {
                                        return -0.0574306044954;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.122607687846;
                                    } else {
                                        return 0.294198670471;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0388192656477;
                                    } else {
                                        return 0.244139766835;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return -0.152508729965;
                                    } else {
                                        return 0.00139189891148;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -3731.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[53] <= -1242.5) {
                                    return 0.205255218063;
                                } else {
                                    return 0.00858061951523;
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0519183099908;
                                    } else {
                                        return 0.0702086415636;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return -0.079521571252;
                                    } else {
                                        return -0.0248471730729;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1293.0) {
                                if (fs[41] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0536655315413;
                                    } else {
                                        return 0.135828007245;
                                    }
                                } else {
                                    if (fs[47] <= -4067.5) {
                                        return 0.179565511145;
                                    } else {
                                        return 0.440022899228;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0387448068507;
                                    } else {
                                        return -0.0708338717397;
                                    }
                                } else {
                                    return 0.0822370521032;
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0049288646202;
                                    } else {
                                        return -0.00185232245835;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.00228856835796;
                                    } else {
                                        return 0.0131129697676;
                                    }
                                }
                            } else {
                                if (fs[64] <= -996.5) {
                                    if (fs[53] <= -1098.0) {
                                        return 0.0709229653716;
                                    } else {
                                        return -0.00202633196785;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return -0.00531365228604;
                                    } else {
                                        return -0.0113022479365;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 7.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0357029121632;
                                    } else {
                                        return 0.242381385655;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0575163686389;
                                    } else {
                                        return -0.014051328558;
                                    }
                                }
                            } else {
                                return 0.471606631649;
                            }
                        }
                    }
                }
            }
        }
    }
}
