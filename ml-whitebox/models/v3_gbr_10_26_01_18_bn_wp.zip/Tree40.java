/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree40 {
    public double calcTree(double... fs) {
        if (fs[103] <= 1.5) {
            if (fs[72] <= 9985.5) {
                if (fs[0] <= 0.5) {
                    if (fs[88] <= -0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[85] <= 0.5) {
                                return 0.154330418573;
                            } else {
                                return -0.102870863641;
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.290728898215;
                                    } else {
                                        return 0.191034005726;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.133027711715;
                                    } else {
                                        return -0.084270126501;
                                    }
                                }
                            } else {
                                return 0.233104248011;
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.107452815349;
                                    } else {
                                        return 0.212687202197;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.124117566399;
                                    } else {
                                        return -0.0492934034696;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1504.0) {
                                    if (fs[18] <= 0.5) {
                                        return 0.144637410655;
                                    } else {
                                        return 0.23350390265;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.00968574804323;
                                    } else {
                                        return 0.0815766001743;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.117449359202;
                                    } else {
                                        return 0.162436123525;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return 0.0498747886896;
                                    } else {
                                        return 0.19743359308;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[53] <= -1553.0) {
                                        return 0.192219819957;
                                    } else {
                                        return -0.0264079950143;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.0647877762995;
                                    } else {
                                        return -0.169131488274;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.103958998005;
                                    } else {
                                        return 0.0281860024399;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.00098800470046;
                                    } else {
                                        return 0.0696519156288;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0850965564505;
                                    } else {
                                        return 0.154707797657;
                                    }
                                } else {
                                    if (fs[47] <= -1228.5) {
                                        return 0.287717444608;
                                    } else {
                                        return 0.0223917945727;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 10.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.00180642752883;
                                    } else {
                                        return 0.256688187728;
                                    }
                                } else {
                                    if (fs[92] <= 0.5) {
                                        return -0.00453584722395;
                                    } else {
                                        return -0.0117357557889;
                                    }
                                }
                            } else {
                                if (fs[47] <= -165.0) {
                                    if (fs[47] <= -187.5) {
                                        return -0.0124372791104;
                                    } else {
                                        return 0.231855050736;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.00853189180442;
                                    } else {
                                        return 0.111154236469;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[30] <= 0.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return -0.0503533126409;
                                    } else {
                                        return -0.0110838598225;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.00172652778244;
                                    } else {
                                        return 0.0228690652545;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.00841853540283;
                                    } else {
                                        return -0.0111453933844;
                                    }
                                } else {
                                    if (fs[47] <= -3848.5) {
                                        return 0.043288837017;
                                    } else {
                                        return -0.00706280421447;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[53] <= -1138.0) {
                                    return 0.134040591959;
                                } else {
                                    return 0.352907416078;
                                }
                            } else {
                                return 0.444359404677;
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1052.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[93] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.125022830003;
                                    } else {
                                        return 0.0762135610954;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.222493612264;
                                    } else {
                                        return 0.0485625741226;
                                    }
                                }
                            } else {
                                if (fs[4] <= 30.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.161582396833;
                                    } else {
                                        return -0.455930347302;
                                    }
                                } else {
                                    return -0.471107030936;
                                }
                            }
                        } else {
                            if (fs[76] <= 150.0) {
                                if (fs[76] <= 25.0) {
                                    return -0.251866210523;
                                } else {
                                    if (fs[47] <= -69.5) {
                                        return -0.277953554979;
                                    } else {
                                        return -0.440759601751;
                                    }
                                }
                            } else {
                                return -0.208585629652;
                            }
                        }
                    } else {
                        if (fs[85] <= 0.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0287641629617;
                                    } else {
                                        return -0.00507662567752;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.165294562594;
                                    } else {
                                        return -0.0487243977995;
                                    }
                                }
                            } else {
                                if (fs[4] <= 18.5) {
                                    if (fs[53] <= -1123.5) {
                                        return 0.0692187238201;
                                    } else {
                                        return 0.300939909381;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return -0.0749727685755;
                                    } else {
                                        return -0.260959236613;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.0452988786339;
                                    } else {
                                        return -0.158218712669;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.00810420741124;
                                    } else {
                                        return 0.327868935654;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0771747632724;
                                    } else {
                                        return 0.210402128513;
                                    }
                                } else {
                                    return -0.238849473975;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[49] <= -0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.0956783482013;
                                    } else {
                                        return 0.206233042336;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.185990672877;
                                    } else {
                                        return 0.253699250462;
                                    }
                                }
                            } else {
                                if (fs[47] <= -5.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.22082491395;
                                    } else {
                                        return 0.073541402468;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.137513354807;
                                    } else {
                                        return 0.0234918167497;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.191108240025;
                                    } else {
                                        return 0.0476236375282;
                                    }
                                } else {
                                    if (fs[70] <= -4.5) {
                                        return 0.171621841352;
                                    } else {
                                        return 0.13562340176;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.140307851271;
                                    } else {
                                        return 0.26355092763;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.205457892999;
                                    } else {
                                        return 0.0768444113989;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[88] <= 7.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[2] <= 8.5) {
                                        return 0.0125191267921;
                                    } else {
                                        return 0.299020941019;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0478457232803;
                                    } else {
                                        return 0.26819213712;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0367794515588;
                                    } else {
                                        return -0.00215203947526;
                                    }
                                } else {
                                    return 0.216386297173;
                                }
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[6] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0706344641115;
                                    } else {
                                        return 0.149570949126;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.013379844936;
                                    } else {
                                        return -0.0421415965264;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[72] <= 9995.5) {
                                        return 0.0567286788294;
                                    } else {
                                        return 0.172376358062;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0137314570492;
                                    } else {
                                        return -0.0480919122085;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[45] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[53] <= -1138.0) {
                                if (fs[52] <= 0.5) {
                                    return 0.314936711505;
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.252456093117;
                                    } else {
                                        return 0.151925700841;
                                    }
                                }
                            } else {
                                return 0.271321928265;
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[26] <= 0.5) {
                                        return 0.13221391389;
                                    } else {
                                        return 0.103563696658;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.208914159857;
                                    } else {
                                        return 0.00301600174303;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.199053930357;
                                    } else {
                                        return -0.0904997123791;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0803466274373;
                                    } else {
                                        return -0.0256812552954;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[11] <= 0.5) {
                                    return -0.285584633626;
                                } else {
                                    if (fs[58] <= 0.5) {
                                        return -0.171025145101;
                                    } else {
                                        return -0.264442581284;
                                    }
                                }
                            } else {
                                if (fs[58] <= 0.5) {
                                    return -0.242050957326;
                                } else {
                                    return 0.0401778062183;
                                }
                            }
                        } else {
                            return 0.0331976520579;
                        }
                    }
                } else {
                    if (fs[0] <= 39.5) {
                        if (fs[60] <= 0.5) {
                            if (fs[50] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[27] <= 0.5) {
                                        return 0.0139047758246;
                                    } else {
                                        return 0.175498290745;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0369692018172;
                                    } else {
                                        return 0.182584225296;
                                    }
                                }
                            } else {
                                return 0.338065933385;
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.163606626584;
                                    } else {
                                        return 0.47544977708;
                                    }
                                } else {
                                    return -0.0479846817685;
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0212377486787;
                                    } else {
                                        return 0.0730773181742;
                                    }
                                } else {
                                    if (fs[53] <= -987.0) {
                                        return -0.0502669404451;
                                    } else {
                                        return -0.0154428285355;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[23] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[53] <= -556.5) {
                                    return 0.555535304785;
                                } else {
                                    return -0.0743535568212;
                                }
                            } else {
                                return 0.434835383185;
                            }
                        } else {
                            return -0.0308900050915;
                        }
                    }
                }
            } else {
                if (fs[62] <= -2.5) {
                    if (fs[2] <= 2.5) {
                        if (fs[53] <= -456.5) {
                            return 0.0154136346468;
                        } else {
                            return -0.041637755621;
                        }
                    } else {
                        return 0.101916429768;
                    }
                } else {
                    if (fs[0] <= 5.5) {
                        if (fs[4] <= 75.5) {
                            if (fs[4] <= 25.5) {
                                if (fs[72] <= 9983.0) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0261609680631;
                                    } else {
                                        return -0.0108028436991;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.0190661255899;
                                    } else {
                                        return -0.0339619609723;
                                    }
                                }
                            } else {
                                if (fs[53] <= -960.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0138255694035;
                                    } else {
                                        return 0.0048696787289;
                                    }
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return 0.0583851215345;
                                    } else {
                                        return 0.000570100325708;
                                    }
                                }
                            }
                        } else {
                            return -0.0637380558228;
                        }
                    } else {
                        if (fs[2] <= 0.5) {
                            return 0.0115926031879;
                        } else {
                            if (fs[53] <= -981.5) {
                                if (fs[0] <= 30.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.008935564665;
                                    } else {
                                        return -0.0135406454399;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0101369154285;
                                    } else {
                                        return 0.0226176422393;
                                    }
                                }
                            } else {
                                if (fs[0] <= 50.5) {
                                    if (fs[0] <= 15.5) {
                                        return -0.00746057714243;
                                    } else {
                                        return -0.00605301210583;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.00847744897936;
                                    } else {
                                        return 0.0115847839993;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
