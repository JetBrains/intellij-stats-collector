/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree38 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[22] <= 0.5) {
                if (fs[53] <= -977.0) {
                    if (fs[74] <= 0.5) {
                        if (fs[95] <= 0.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[88] <= -0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.210967280584;
                                    } else {
                                        return 0.1838652688;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.10080231737;
                                    } else {
                                        return 0.131013423752;
                                    }
                                }
                            } else {
                                if (fs[47] <= -0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.330681172941;
                                    } else {
                                        return 0.00633357243959;
                                    }
                                } else {
                                    return 0.0721812953046;
                                }
                            }
                        } else {
                            if (fs[67] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.171270165172;
                                    } else {
                                        return -0.393286493091;
                                    }
                                } else {
                                    if (fs[4] <= 17.0) {
                                        return 0.228267299066;
                                    } else {
                                        return -0.138167961568;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1143.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.228941351844;
                                    } else {
                                        return 0.289252616399;
                                    }
                                } else {
                                    if (fs[72] <= 9996.5) {
                                        return 0.194363124437;
                                    } else {
                                        return 0.174091519833;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1143.5) {
                            if (fs[72] <= 4639.5) {
                                if (fs[53] <= -1493.5) {
                                    return 0.0378589301691;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.11355870273;
                                    } else {
                                        return -0.0728072579806;
                                    }
                                }
                            } else {
                                return -0.132951807907;
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[72] <= 4965.0) {
                                        return -0.00635280525277;
                                    } else {
                                        return 0.196065461113;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.13778928194;
                                    } else {
                                        return 0.113856028058;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.000674567498915;
                                    } else {
                                        return 0.157351961593;
                                    }
                                } else {
                                    return 0.0576058504428;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 5.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.047479318121;
                                    } else {
                                        return 0.190130629061;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.188035079786;
                                    } else {
                                        return -0.0789238301647;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.248485360336;
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.355909197342;
                                    } else {
                                        return 0.245894659047;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.414087431884;
                                    } else {
                                        return -0.0777708561145;
                                    }
                                } else {
                                    if (fs[64] <= -499.0) {
                                        return 0.198843892837;
                                    } else {
                                        return 0.0441808569906;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.119064729129;
                                    } else {
                                        return -0.172426165418;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.163775500277;
                                    } else {
                                        return -0.15521301083;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[64] <= -496.5) {
                                if (fs[49] <= -1.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.126225205427;
                                    } else {
                                        return 0.238928290575;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return -0.00921639066248;
                                    } else {
                                        return 0.156299905541;
                                    }
                                }
                            } else {
                                if (fs[47] <= -13.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.175579374259;
                                    } else {
                                        return 0.0639775057511;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0179128637007;
                                    } else {
                                        return 0.0606486706998;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 5.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return 0.0661149119546;
                                    } else {
                                        return 0.280768440278;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.185197094169;
                                    } else {
                                        return 0.00368774889513;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.214664321989;
                                    } else {
                                        return 0.302275562772;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.253146507165;
                                    } else {
                                        return 0.108876867717;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[76] <= 25.0) {
                    if (fs[90] <= 0.5) {
                        if (fs[47] <= -61.5) {
                            if (fs[43] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.365462263587;
                                    } else {
                                        return 0.0316171561233;
                                    }
                                } else {
                                    if (fs[72] <= 9970.5) {
                                        return 0.299636739281;
                                    } else {
                                        return 0.128353558434;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    return -0.216886992443;
                                } else {
                                    return -0.14779212551;
                                }
                            }
                        } else {
                            if (fs[53] <= -1468.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[88] <= 6.0) {
                                        return -0.0602252198043;
                                    } else {
                                        return 0.251461121639;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.00942775070826;
                                    } else {
                                        return 0.189842899647;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.140124113807;
                                    } else {
                                        return 0.486849733531;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0218906070255;
                                    } else {
                                        return -0.317624662303;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -382.5) {
                            return -0.161546465982;
                        } else {
                            if (fs[4] <= 16.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.272923035284;
                                    } else {
                                        return 0.053831773207;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.472971922447;
                                    } else {
                                        return 0.381894244592;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9891.5) {
                                    if (fs[53] <= -1468.0) {
                                        return 0.447432379509;
                                    } else {
                                        return 0.306522257468;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.14111578833;
                                    } else {
                                        return -0.26594862345;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 6.5) {
                        if (fs[2] <= 5.5) {
                            if (fs[88] <= 5.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.209507985761;
                                    } else {
                                        return 0.136579116474;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0418233491186;
                                    } else {
                                        return 0.11118292097;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.149242573757;
                                    } else {
                                        return 0.00138656858024;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.239174437569;
                                    } else {
                                        return -0.0617161133136;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 27.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[53] <= -968.0) {
                                        return 0.178603948196;
                                    } else {
                                        return -0.256277813201;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.105836281322;
                                    } else {
                                        return -0.121714928029;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 29.5) {
                                        return -0.411212983065;
                                    } else {
                                        return -0.231320944742;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.327200160293;
                                    } else {
                                        return 0.227212451496;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[47] <= -0.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[72] <= 9296.5) {
                                        return 0.200447052148;
                                    } else {
                                        return 0.138693893759;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.254122849438;
                                    } else {
                                        return 0.0872580523837;
                                    }
                                }
                            } else {
                                return -0.20140878185;
                            }
                        } else {
                            if (fs[53] <= -1403.5) {
                                if (fs[72] <= 9821.0) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0731743006151;
                                    } else {
                                        return 0.190709947422;
                                    }
                                } else {
                                    if (fs[72] <= 9912.5) {
                                        return 0.264454459178;
                                    } else {
                                        return 0.0978281539441;
                                    }
                                }
                            } else {
                                return 0.386179627207;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[4] <= 16.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[85] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[101] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0298385653733;
                                    } else {
                                        return 0.00287032406773;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.049197311311;
                                    } else {
                                        return 0.341646942439;
                                    }
                                }
                            } else {
                                if (fs[64] <= -498.5) {
                                    return 0.579550984624;
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.00764165119444;
                                    } else {
                                        return 0.0759816061819;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -7.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0245642325747;
                                    } else {
                                        return 0.126888338134;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.127093500827;
                                    } else {
                                        return 0.624481610929;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.0) {
                                    if (fs[94] <= 0.5) {
                                        return -0.0262767317277;
                                    } else {
                                        return 0.0183586733495;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0455768329254;
                                    } else {
                                        return 0.145474995259;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[53] <= -988.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0386306065885;
                                    } else {
                                        return 0.148205293046;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.0092761788532;
                                    } else {
                                        return -0.0871339122897;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[88] <= 5.5) {
                                        return 0.0385286190868;
                                    } else {
                                        return -0.0333859991182;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.167647321268;
                                    } else {
                                        return 0.0650517119294;
                                    }
                                }
                            }
                        } else {
                            if (fs[27] <= 0.5) {
                                if (fs[47] <= -32.0) {
                                    return 0.0455566001805;
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return -0.0252830075589;
                                    } else {
                                        return 0.0243319968143;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[62] <= -0.5) {
                                        return -0.040927047156;
                                    } else {
                                        return 0.0825508981497;
                                    }
                                } else {
                                    if (fs[62] <= -0.5) {
                                        return -0.0588658796805;
                                    } else {
                                        return -0.0432903810547;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[14] <= 0.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[53] <= -921.5) {
                                if (fs[72] <= 9997.5) {
                                    if (fs[4] <= 21.5) {
                                        return -0.0102031581263;
                                    } else {
                                        return -0.0334507833909;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return 0.135053010053;
                                    } else {
                                        return -0.00106544319024;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[86] <= 0.5) {
                                        return 0.0237377700728;
                                    } else {
                                        return 0.246771701534;
                                    }
                                } else {
                                    if (fs[47] <= -9.5) {
                                        return 0.213081094688;
                                    } else {
                                        return -0.0182559442918;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -3428.0) {
                                return 0.533232565709;
                            } else {
                                if (fs[47] <= -2.5) {
                                    if (fs[4] <= 26.5) {
                                        return -0.0641989317082;
                                    } else {
                                        return 0.0939849485234;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.000116373027458;
                                    } else {
                                        return 0.0526457123908;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[53] <= -1488.0) {
                                return 0.0792504688524;
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.0346063821488;
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.103221224484;
                                    } else {
                                        return -0.0481144700498;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 20.5) {
                                return -0.0673306021556;
                            } else {
                                if (fs[4] <= 21.5) {
                                    return 0.46664276116;
                                } else {
                                    if (fs[4] <= 23.0) {
                                        return -0.0667080796203;
                                    } else {
                                        return 0.281931747049;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 4.5) {
                    if (fs[47] <= -372.5) {
                        if (fs[85] <= 0.5) {
                            if (fs[78] <= 0.5) {
                                return 0.147761969063;
                            } else {
                                if (fs[72] <= 9994.5) {
                                    if (fs[47] <= -402.0) {
                                        return -0.0324516784009;
                                    } else {
                                        return 0.0616747482506;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.000434080385591;
                                    } else {
                                        return 0.178444932628;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1092.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[88] <= 5.5) {
                                        return 0.0879802513864;
                                    } else {
                                        return -0.0314525777617;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.269164590631;
                                    } else {
                                        return 0.137529867174;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9819.5) {
                                    if (fs[47] <= -462.0) {
                                        return -0.0579138004912;
                                    } else {
                                        return 0.0862037756569;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return -0.0781517119328;
                                    } else {
                                        return 0.218727611632;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.00488848236278;
                                    } else {
                                        return 0.0112684628344;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return 0.153577509827;
                                    } else {
                                        return -0.185067753983;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[62] <= -2.5) {
                                        return 0.173635666404;
                                    } else {
                                        return 0.0180759780252;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.0254135522264;
                                    } else {
                                        return -0.0152140279627;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.014239377787;
                                    } else {
                                        return 0.00331238591422;
                                    }
                                } else {
                                    return 0.22024917564;
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.00634824490919;
                                    } else {
                                        return -0.00810722721335;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return -0.0148307598366;
                                    } else {
                                        return -0.00170076088313;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 11.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[62] <= -2.5) {
                                    return 0.165830092505;
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.00257848924953;
                                    } else {
                                        return 0.174432244637;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1098.0) {
                                    if (fs[4] <= 13.5) {
                                        return 0.149629329131;
                                    } else {
                                        return 0.323023424414;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0339943447212;
                                    } else {
                                        return 0.0434794173744;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[76] <= 250.0) {
                                    if (fs[47] <= -370.5) {
                                        return 0.0242216648393;
                                    } else {
                                        return -0.00927298551719;
                                    }
                                } else {
                                    if (fs[53] <= -1052.5) {
                                        return -0.0245235189113;
                                    } else {
                                        return -0.0106382138039;
                                    }
                                }
                            } else {
                                if (fs[72] <= 8693.5) {
                                    if (fs[47] <= -3534.0) {
                                        return 0.0687253781721;
                                    } else {
                                        return -0.00675986942143;
                                    }
                                } else {
                                    if (fs[47] <= -5.5) {
                                        return 0.0249721030529;
                                    } else {
                                        return -0.00132535522062;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 3.5) {
                            if (fs[15] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.00756401985971;
                                    } else {
                                        return 0.0131917894064;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.00208450803894;
                                    } else {
                                        return 0.0308053168507;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    return -0.071279044651;
                                } else {
                                    return 0.179703800885;
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 118.5) {
                                        return -0.00968575344298;
                                    } else {
                                        return -0.00392049579288;
                                    }
                                } else {
                                    if (fs[47] <= -41427.0) {
                                        return 0.201842781329;
                                    } else {
                                        return -0.0084294218566;
                                    }
                                }
                            } else {
                                if (fs[4] <= 18.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.216198286299;
                                    } else {
                                        return -0.0202170445454;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return -0.0292038053325;
                                    } else {
                                        return -0.0362310549971;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
