/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree66 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[81] <= 0.5) {
                if (fs[30] <= 0.5) {
                    if (fs[4] <= 7.5) {
                        if (fs[60] <= 0.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.00976997941117;
                                    } else {
                                        return 0.111265269826;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.075347828335;
                                    } else {
                                        return 0.0363508081586;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    return -0.0112539434573;
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0728744392758;
                                    } else {
                                        return -0.0629327481409;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0182498794749;
                                    } else {
                                        return -0.0456717386738;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.018636158941;
                                    } else {
                                        return 0.0574780222528;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0512911200702;
                                    } else {
                                        return 0.00600600338781;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0074756383869;
                                    } else {
                                        return 0.0494936576376;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 11.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0740598408992;
                                    } else {
                                        return 0.0189215644803;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0890377125365;
                                    } else {
                                        return 0.0756527815816;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.111445555681;
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0207730846841;
                                    } else {
                                        return 0.026286335097;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1903.5) {
                                return -0.205710099883;
                            } else {
                                if (fs[72] <= 9745.0) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0079052925511;
                                    } else {
                                        return -0.0060480189368;
                                    }
                                } else {
                                    return -0.117250344893;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[53] <= -1138.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.0267394087367;
                                    } else {
                                        return 0.046881208535;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.065837175283;
                                    } else {
                                        return 0.0310368946909;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0397283829576;
                                    } else {
                                        return 0.0366320323099;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.0270517208337;
                                    } else {
                                        return 0.0548381480296;
                                    }
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                return 0.17657212715;
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.211721650455;
                                    } else {
                                        return 0.0363321225612;
                                    }
                                } else {
                                    return 0.0641663764273;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1138.0) {
                            if (fs[4] <= 5.0) {
                                return 0.279418296295;
                            } else {
                                return -0.0838661647429;
                            }
                        } else {
                            return 0.181496525497;
                        }
                    }
                }
            } else {
                if (fs[76] <= 25.0) {
                    if (fs[57] <= 0.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[49] <= -2.5) {
                                if (fs[48] <= 0.5) {
                                    return 0.0127913150106;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.216842703206;
                                    } else {
                                        return 0.31097990898;
                                    }
                                }
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.00115455993865;
                                    } else {
                                        return -0.00328800881757;
                                    }
                                } else {
                                    if (fs[72] <= 9866.5) {
                                        return 0.0309253077122;
                                    } else {
                                        return 0.127204437893;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0231192998654;
                                    } else {
                                        return 0.175908721637;
                                    }
                                } else {
                                    if (fs[53] <= -1012.5) {
                                        return 0.120011007549;
                                    } else {
                                        return 0.0465879336681;
                                    }
                                }
                            } else {
                                if (fs[63] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00461731334144;
                                    } else {
                                        return 0.00720510156626;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.183080374355;
                                    } else {
                                        return 0.0376938308184;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 7.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.136628213482;
                                    } else {
                                        return -0.0256583111338;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.108743091596;
                                    } else {
                                        return 0.232674933052;
                                    }
                                }
                            } else {
                                if (fs[88] <= 3.0) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0580089729301;
                                    } else {
                                        return 0.0779321644743;
                                    }
                                } else {
                                    if (fs[53] <= -490.5) {
                                        return -0.0455458805066;
                                    } else {
                                        return 0.264961392774;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 7.5) {
                                    return 0.318549386361;
                                } else {
                                    return 0.256984765977;
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    return 0.179882860284;
                                } else {
                                    return 0.21742279929;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 8.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[64] <= -998.5) {
                                if (fs[53] <= 3.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0684134467734;
                                    } else {
                                        return 0.192711962007;
                                    }
                                } else {
                                    return -0.00857041486121;
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.0178305850861;
                                    } else {
                                        return 0.0749684360045;
                                    }
                                } else {
                                    if (fs[47] <= -227089.0) {
                                        return 0.371622802244;
                                    } else {
                                        return 0.00290944007468;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0728440165897;
                                    } else {
                                        return 0.0317025157418;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.00792318886924;
                                    } else {
                                        return 0.0419946576171;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1468.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.0853255726269;
                                    } else {
                                        return -0.129513194688;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0834329700491;
                                    } else {
                                        return -0.00275855893231;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[105] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[103] <= 1.5) {
                                        return -0.00169696675048;
                                    } else {
                                        return 0.00908766885288;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.055410431997;
                                    } else {
                                        return 0.147520889983;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0658590245101;
                                    } else {
                                        return 0.00524440099103;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0110227941981;
                                    } else {
                                        return -0.00595978968701;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 6.5) {
                                if (fs[88] <= 5.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0994580216179;
                                    } else {
                                        return -0.00152717584014;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0138542366802;
                                    } else {
                                        return -0.00360836446524;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9477.0) {
                                    if (fs[47] <= -1.5) {
                                        return 0.109638277294;
                                    } else {
                                        return 0.0241341913287;
                                    }
                                } else {
                                    if (fs[53] <= -1468.0) {
                                        return 0.208592103428;
                                    } else {
                                        return -0.041292429029;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[84] <= 0.5) {
                    if (fs[18] <= -0.5) {
                        if (fs[90] <= 0.5) {
                            return 0.0300042651377;
                        } else {
                            return -0.23519046531;
                        }
                    } else {
                        if (fs[53] <= -1898.0) {
                            if (fs[53] <= -1928.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.152400133233;
                                    } else {
                                        return 0.0123313294387;
                                    }
                                } else {
                                    if (fs[47] <= -27.0) {
                                        return 0.0654892927477;
                                    } else {
                                        return 0.155359491309;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    return 0.238545511359;
                                } else {
                                    return 0.161121046918;
                                }
                            }
                        } else {
                            if (fs[4] <= 35.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.0248295361141;
                                    } else {
                                        return -0.107337846881;
                                    }
                                } else {
                                    if (fs[47] <= -4042.5) {
                                        return 0.22218287879;
                                    } else {
                                        return 0.0563871824934;
                                    }
                                }
                            } else {
                                return -0.319761115118;
                            }
                        }
                    }
                } else {
                    if (fs[65] <= 0.5) {
                        if (fs[88] <= 5.5) {
                            if (fs[88] <= 2.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0126808577918;
                                    } else {
                                        return 0.0318314126391;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.173569220794;
                                    } else {
                                        return 0.0420642819952;
                                    }
                                }
                            } else {
                                if (fs[88] <= 3.5) {
                                    return -0.337274181182;
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0358648256354;
                                    } else {
                                        return -0.0650284239197;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[31] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.00588596663687;
                                    } else {
                                        return 0.0945195079334;
                                    }
                                } else {
                                    return 0.207225744682;
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.157962733549;
                                    } else {
                                        return 0.0260024867006;
                                    }
                                } else {
                                    if (fs[53] <= -1027.0) {
                                        return 0.103014461872;
                                    } else {
                                        return 0.0122800154189;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 1.0) {
                            return 0.0251804476868;
                        } else {
                            if (fs[4] <= 11.5) {
                                return -0.459351894183;
                            } else {
                                if (fs[2] <= 2.5) {
                                    return -0.252097229911;
                                } else {
                                    return -0.2971916266;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[55] <= 546.5) {
                    if (fs[2] <= 4.5) {
                        if (fs[53] <= -2423.0) {
                            if (fs[85] <= 0.5) {
                                return -0.0139420948971;
                            } else {
                                return 0.422400855974;
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[0] <= 11.5) {
                                        return 0.0239800537791;
                                    } else {
                                        return -0.0354889040554;
                                    }
                                } else {
                                    if (fs[0] <= 12.5) {
                                        return 0.0714236536735;
                                    } else {
                                        return 0.218443615013;
                                    }
                                }
                            } else {
                                if (fs[67] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.00795842786239;
                                    } else {
                                        return -0.00622627380317;
                                    }
                                } else {
                                    if (fs[86] <= 0.5) {
                                        return -0.0965858147951;
                                    } else {
                                        return -0.0351803932819;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 24.5) {
                            if (fs[4] <= 22.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0723904811181;
                                    } else {
                                        return 0.13832062789;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.114212397563;
                                    } else {
                                        return 0.0293966068723;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    return 0.098114263637;
                                } else {
                                    return 0.344850400371;
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[4] <= 32.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.024753487295;
                                    } else {
                                        return -0.0542644264091;
                                    }
                                } else {
                                    return -0.203108517921;
                                }
                            } else {
                                return 0.0515116819698;
                            }
                        }
                    }
                } else {
                    return 0.257945887374;
                }
            }
        }
    }
}
