/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree0 {
    public double calcTree(double... fs) {
        if (fs[103] <= 1.5) {
            if (fs[0] <= 0.5) {
                if (fs[18] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[53] <= -992.0) {
                            if (fs[4] <= 10.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.848252411333;
                                    } else {
                                        return 0.736605001635;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.707289436444;
                                    } else {
                                        return 0.531603457663;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.547684468767;
                                    } else {
                                        return 0.274536151717;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.625816474358;
                                    } else {
                                        return 0.846293559421;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.332267787064;
                                    } else {
                                        return -0.0079617597283;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return 0.664260462494;
                                    } else {
                                        return 0.321680606159;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.695124660025;
                                    } else {
                                        return 0.873335950195;
                                    }
                                } else {
                                    return 0.0220382402717;
                                }
                            }
                        }
                    } else {
                        if (fs[81] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.926749202556;
                                    } else {
                                        return 0.61945759511;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.87385642209;
                                    } else {
                                        return 0.407447045303;
                                    }
                                }
                            } else {
                                if (fs[4] <= 21.5) {
                                    return 0.578401876635;
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.423519721753;
                                    } else {
                                        return 0.040252525986;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[85] <= 0.5) {
                                    if (fs[53] <= -1468.0) {
                                        return 0.382621199913;
                                    } else {
                                        return 0.696340756919;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.280485028383;
                                    } else {
                                        return 0.521434565731;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.802322342237;
                                    } else {
                                        return 0.693834253628;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.37813374589;
                                    } else {
                                        return 0.776413240272;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[64] <= -995.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[4] <= 10.5) {
                                    return 0.508704906938;
                                } else {
                                    return 0.662038240272;
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[72] <= 5000.0) {
                                        return 0.860957159191;
                                    } else {
                                        return 0.942038240272;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.843677584534;
                                    } else {
                                        return 0.732319570195;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -4.0) {
                                if (fs[72] <= 4978.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.415242345175;
                                    } else {
                                        return 0.165567652036;
                                    }
                                } else {
                                    if (fs[53] <= -1133.5) {
                                        return 0.853149351383;
                                    } else {
                                        return 0.573394172475;
                                    }
                                }
                            } else {
                                if (fs[53] <= -965.5) {
                                    if (fs[53] <= -1283.5) {
                                        return 0.783027639565;
                                    } else {
                                        return 0.491014197529;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.261957757374;
                                    } else {
                                        return 0.402666369539;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[62] <= -0.5) {
                            if (fs[49] <= -0.5) {
                                if (fs[62] <= -1.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.80528610352;
                                    } else {
                                        return 0.924307743818;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.799021480495;
                                    } else {
                                        return 0.177332357919;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[70] <= -4.0) {
                                        return 0.769624447168;
                                    } else {
                                        return 0.35942954462;
                                    }
                                } else {
                                    if (fs[47] <= -5.5) {
                                        return 0.370609668843;
                                    } else {
                                        return 0.796204906938;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[102] <= 0.5) {
                                        return 0.780565744978;
                                    } else {
                                        return 0.192038240272;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.627268264485;
                                    } else {
                                        return 0.742873313341;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.794310967544;
                                    } else {
                                        return 0.591188162992;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.428174763847;
                                    } else {
                                        return 0.664520178223;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[47] <= -2386.5) {
                    if (fs[88] <= 7.5) {
                        if (fs[53] <= -1438.0) {
                            if (fs[0] <= 5.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.360642891434;
                                    } else {
                                        return 0.153008704407;
                                    }
                                } else {
                                    return 0.73273591469;
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[0] <= 13.5) {
                                        return 0.0702433684768;
                                    } else {
                                        return -0.00587842639497;
                                    }
                                } else {
                                    return 0.292038240272;
                                }
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    return 0.0372763355098;
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0541594783595;
                                    } else {
                                        return 0.0118056821322;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9981.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.167844691885;
                                    } else {
                                        return -0.0312950930616;
                                    }
                                } else {
                                    return 0.673745557345;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1458.0) {
                            if (fs[4] <= 6.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.713968064833;
                                    } else {
                                        return 0.899257491609;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.389097063801;
                                    } else {
                                        return 0.677522111239;
                                    }
                                }
                            } else {
                                return 0.0231193213528;
                            }
                        } else {
                            return -0.0579617597283;
                        }
                    }
                } else {
                    if (fs[72] <= 9866.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.159540277761;
                                    } else {
                                        return -0.0342941897193;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.0221497285295;
                                    } else {
                                        return -0.0263842533779;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.195609668843;
                                    } else {
                                        return 0.00195726861178;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.216628404206;
                                    } else {
                                        return 0.74635257001;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.0310045090996;
                                    } else {
                                        return 0.00792164300816;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0372637615844;
                                    } else {
                                        return -0.0559479703912;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.049947078859;
                                    } else {
                                        return -0.0576001328596;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0565594291088;
                                    } else {
                                        return -0.00124534181786;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.175539183075;
                                    } else {
                                        return 0.510834309068;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.116323311202;
                                    } else {
                                        return 0.170979924937;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0445208995132;
                                    } else {
                                        return -0.000407802893771;
                                    }
                                } else {
                                    return 0.0574228556563;
                                }
                            }
                        } else {
                            if (fs[0] <= 6.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[53] <= -1418.0) {
                                        return 0.0958455391731;
                                    } else {
                                        return 0.00594848860146;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.099371573605;
                                    } else {
                                        return 0.26034062754;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9999.5) {
                                    if (fs[53] <= -1403.0) {
                                        return 0.0357370946089;
                                    } else {
                                        return -0.0369538522575;
                                    }
                                } else {
                                    if (fs[47] <= -94.5) {
                                        return 0.410569708803;
                                    } else {
                                        return 0.0319853302188;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[64] <= -996.5) {
                    if (fs[60] <= 0.5) {
                        if (fs[78] <= 0.5) {
                            return 0.492038240272;
                        } else {
                            if (fs[4] <= 7.5) {
                                if (fs[53] <= -1138.0) {
                                    return 0.942038240272;
                                } else {
                                    return 0.900371573605;
                                }
                            } else {
                                return 0.829135014465;
                            }
                        }
                    } else {
                        if (fs[4] <= 13.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.916462792701;
                                    } else {
                                        return 0.92235804347;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.933109668843;
                                    } else {
                                        return 0.942038240272;
                                    }
                                }
                            } else {
                                return 0.742038240272;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[64] <= -997.5) {
                                    return 0.942038240272;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.863090871851;
                                    } else {
                                        return 0.924494380623;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[62] <= -1.5) {
                                        return 0.769624447168;
                                    } else {
                                        return 0.858704906938;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.942038240272;
                                    } else {
                                        return 0.870609668843;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[41] <= 0.5) {
                        if (fs[72] <= 9987.5) {
                            if (fs[26] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[53] <= -987.5) {
                                        return 0.874584037224;
                                    } else {
                                        return 0.405001203235;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.275371573605;
                                    } else {
                                        return 0.463777370706;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1014.0) {
                                        return 0.760881271395;
                                    } else {
                                        return 0.175371573605;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.90576881022;
                                    } else {
                                        return 0.852602006008;
                                    }
                                }
                            }
                        } else {
                            return 0.12385642209;
                        }
                    } else {
                        if (fs[58] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.398178591149;
                                    } else {
                                        return 0.637690414185;
                                    }
                                } else {
                                    return 0.0771733754068;
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.550976787758;
                                    } else {
                                        return 0.379075277309;
                                    }
                                } else {
                                    return 0.12385642209;
                                }
                            }
                        } else {
                            return 0.11595128375;
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[53] <= -1068.0) {
                        if (fs[23] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[60] <= 0.5) {
                                    return 0.727752525986;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.225543394911;
                                    } else {
                                        return 0.420299109837;
                                    }
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.043625541859;
                                    } else {
                                        return 0.349445647679;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.181302043953;
                                    } else {
                                        return 0.23727633551;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.0372763355098;
                                    } else {
                                        return -0.0481095429795;
                                    }
                                } else {
                                    return 0.275371573605;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 7.0) {
                                        return 0.0716678699013;
                                    } else {
                                        return -0.0579617597283;
                                    }
                                } else {
                                    return 0.288192086426;
                                }
                            }
                        }
                    } else {
                        if (fs[7] <= 0.5) {
                            if (fs[49] <= -1.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 18.0) {
                                        return -0.0579617597283;
                                    } else {
                                        return 0.267619635621;
                                    }
                                } else {
                                    return -0.0579617597283;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0138441126695;
                                    } else {
                                        return -0.0498822072112;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0144364303169;
                                    } else {
                                        return -0.0579617597283;
                                    }
                                }
                            }
                        } else {
                            return 0.0848953831288;
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[0] <= 31.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 9.5) {
                                        return 0.17514634838;
                                    } else {
                                        return 0.714765512999;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.0723927454416;
                                    } else {
                                        return 0.222180084243;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    return 0.626248766587;
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.367038240272;
                                    } else {
                                        return 0.559685299095;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[0] <= 24.5) {
                                    if (fs[64] <= -995.5) {
                                        return -0.0195002212668;
                                    } else {
                                        return -0.0563706698317;
                                    }
                                } else {
                                    if (fs[58] <= 0.5) {
                                        return -0.0579617597283;
                                    } else {
                                        return -0.0135173152839;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[76] <= 150.0) {
                                        return -0.0579617597283;
                                    } else {
                                        return -0.0262716188832;
                                    }
                                } else {
                                    return 0.0784018766353;
                                }
                            }
                        }
                    } else {
                        if (fs[62] <= -2.5) {
                            if (fs[4] <= 17.5) {
                                return 0.12385642209;
                            } else {
                                return -0.0579617597283;
                            }
                        } else {
                            if (fs[27] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.053836347187;
                                    } else {
                                        return -0.0577148766274;
                                    }
                                } else {
                                    if (fs[0] <= 50.5) {
                                        return -0.0563270096115;
                                    } else {
                                        return -0.0329617597283;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0428102445768;
                                    } else {
                                        return -0.0545441247317;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.0189613171948;
                                    } else {
                                        return -0.0579617597283;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
