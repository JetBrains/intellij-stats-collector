/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree99 {
    public double calcTree(double... fs) {
        if (fs[64] <= -996.5) {
            if (fs[53] <= -1098.5) {
                if (fs[23] <= 0.5) {
                    if (fs[41] <= 0.5) {
                        if (fs[58] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    return -0.0532204543132;
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return -0.0708620064192;
                                    } else {
                                        return 0.0180531967367;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1137.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0439990718795;
                                    } else {
                                        return -0.0507675191386;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.168288705783;
                                    } else {
                                        return -0.0786874091279;
                                    }
                                }
                            }
                        } else {
                            if (fs[64] <= -997.5) {
                                if (fs[103] <= 1.5) {
                                    return -0.127987022566;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0220298826981;
                                    } else {
                                        return 0.0449408786199;
                                    }
                                }
                            } else {
                                return -0.268729956594;
                            }
                        }
                    } else {
                        return -0.206624521841;
                    }
                } else {
                    if (fs[62] <= -1.5) {
                        if (fs[101] <= 1.5) {
                            if (fs[48] <= 0.5) {
                                return 0.176670346317;
                            } else {
                                return 0.41546902271;
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                return -0.0698041978852;
                            } else {
                                if (fs[47] <= -4.5) {
                                    return -0.050576939473;
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.239861323031;
                                    } else {
                                        return 0.152359031357;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 4995.5) {
                            if (fs[4] <= 22.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.0720471119893;
                                    } else {
                                        return -0.008935964767;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0182449462034;
                                    } else {
                                        return 0.206943873448;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1373.0) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0386580242715;
                                    } else {
                                        return -0.00632968931929;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0860330164912;
                                    } else {
                                        return -0.0358296783222;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 250.0) {
                                if (fs[18] <= 0.5) {
                                    return 0.1804339011;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.179502943923;
                                    } else {
                                        return 0.0681318729768;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    return -0.119080171334;
                                } else {
                                    return -0.334210240842;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1073.5) {
                    return -0.146198470786;
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[101] <= 1.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.302917723422;
                                    } else {
                                        return -0.0976317925827;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.100560768954;
                                    } else {
                                        return 0.0180365039629;
                                    }
                                }
                            } else {
                                if (fs[70] <= -4.0) {
                                    return -0.19211586364;
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.046875009172;
                                    } else {
                                        return 0.143896211823;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[47] <= -7.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.0400150372979;
                                    } else {
                                        return -0.148441614795;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0756397120349;
                                    } else {
                                        return 0.0790765843094;
                                    }
                                }
                            } else {
                                if (fs[76] <= 100.0) {
                                    return 0.297039615241;
                                } else {
                                    return 0.180577354844;
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -6.5) {
                            if (fs[47] <= -9.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[64] <= -997.5) {
                                        return -0.0964019207188;
                                    } else {
                                        return 0.0861666198908;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.0413404069325;
                                    } else {
                                        return 0.00611901773828;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    return -0.0302392250512;
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return -0.0883666644933;
                                    } else {
                                        return -0.154355336654;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.00634289224723;
                                    } else {
                                        return 0.0859324868019;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0146886039684;
                                    } else {
                                        return 0.100190534192;
                                    }
                                }
                            } else {
                                if (fs[47] <= -4.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.19348547508;
                                    } else {
                                        return -0.0282403971035;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return -0.0275979364643;
                                    } else {
                                        return -0.00366118427076;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[34] <= 0.5) {
                if (fs[55] <= 0.5) {
                    if (fs[57] <= 0.5) {
                        if (fs[14] <= 0.5) {
                            if (fs[83] <= 0.5) {
                                if (fs[47] <= -184.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.00789542319618;
                                    } else {
                                        return 0.017096468963;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.000468028925159;
                                    } else {
                                        return 0.00216539778919;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[53] <= -1453.5) {
                                        return 0.111633947296;
                                    } else {
                                        return -0.00439629251257;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0418666071199;
                                    } else {
                                        return -0.00969845736393;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 21.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0411869800273;
                                    } else {
                                        return 0.0229268371982;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0618542980031;
                                    } else {
                                        return -0.0358958518784;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9998.5) {
                                    if (fs[47] <= -92.5) {
                                        return 0.253799680018;
                                    } else {
                                        return -0.00247009597456;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0600220160484;
                                    } else {
                                        return -0.223985926593;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[88] <= 1.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0112162887881;
                                    } else {
                                        return -0.0226784679013;
                                    }
                                } else {
                                    return -0.0919024318441;
                                }
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.11643558427;
                                    } else {
                                        return -0.0588178349413;
                                    }
                                } else {
                                    if (fs[0] <= 18.5) {
                                        return -0.0947983508699;
                                    } else {
                                        return -0.0314306889921;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -3.5) {
                                if (fs[52] <= 0.5) {
                                    return -0.00142085922475;
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return -0.151982430258;
                                    } else {
                                        return -0.0263927234873;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0462375946365;
                                    } else {
                                        return 0.155667155014;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.00514419520956;
                                    } else {
                                        return 0.0893123946247;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1063.0) {
                        if (fs[72] <= 9989.0) {
                            if (fs[55] <= 992.0) {
                                if (fs[4] <= 17.0) {
                                    if (fs[88] <= 1.0) {
                                        return 0.162268507724;
                                    } else {
                                        return 0.355168220064;
                                    }
                                } else {
                                    return 0.010222145283;
                                }
                            } else {
                                if (fs[88] <= 5.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.065699558447;
                                    } else {
                                        return -0.139428575285;
                                    }
                                } else {
                                    return 0.178333251874;
                                }
                            }
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[76] <= 75.0) {
                                    return 0.319473227603;
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.251879924919;
                                    } else {
                                        return 0.160967469204;
                                    }
                                }
                            } else {
                                return 0.0408765366619;
                            }
                        }
                    } else {
                        if (fs[0] <= 4.5) {
                            if (fs[88] <= 1.5) {
                                return -0.123119040081;
                            } else {
                                return -0.0185706064957;
                            }
                        } else {
                            if (fs[7] <= 0.5) {
                                if (fs[72] <= 4777.0) {
                                    return -0.00666911067966;
                                } else {
                                    return -0.0520405539266;
                                }
                            } else {
                                return 0.0334811034866;
                            }
                        }
                    }
                }
            } else {
                if (fs[45] <= 0.5) {
                    if (fs[47] <= -1.5) {
                        if (fs[4] <= 12.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0305848261478;
                                    } else {
                                        return 0.0990734729877;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.145102968352;
                                    } else {
                                        return 0.1127528724;
                                    }
                                }
                            } else {
                                return 0.259888096914;
                            }
                        } else {
                            return -0.0332278029682;
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[72] <= 4756.0) {
                                        return 0.0969390374074;
                                    } else {
                                        return 0.00182340100436;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.0180206938435;
                                    } else {
                                        return 0.0270732107642;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9901.0) {
                                    if (fs[4] <= 13.5) {
                                        return 0.157170588353;
                                    } else {
                                        return 0.0110549804374;
                                    }
                                } else {
                                    if (fs[72] <= 9963.0) {
                                        return -0.0510829764934;
                                    } else {
                                        return 0.0403112109084;
                                    }
                                }
                            }
                        } else {
                            return 0.197146890866;
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[4] <= 6.5) {
                            return -0.0535373562101;
                        } else {
                            if (fs[72] <= 4796.0) {
                                if (fs[4] <= 12.5) {
                                    return -0.0333543962082;
                                } else {
                                    return -0.0239607302786;
                                }
                            } else {
                                return -0.0615601915974;
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            if (fs[72] <= 9249.0) {
                                return -0.0101729042686;
                            } else {
                                return -0.023728392243;
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[72] <= 9774.0) {
                                    if (fs[53] <= 7.5) {
                                        return -0.0141377598421;
                                    } else {
                                        return -0.00747630726023;
                                    }
                                } else {
                                    return -0.032775216628;
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[4] <= 14.5) {
                                        return -0.00639116477836;
                                    } else {
                                        return -0.00909743854937;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.00505812179477;
                                    } else {
                                        return -0.00728274091125;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
