/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree8 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 10.5) {
                if (fs[81] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[59] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.514969876019;
                                    } else {
                                        return 0.631920116295;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.582539035738;
                                    } else {
                                        return 0.616962098984;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[30] <= 0.5) {
                                        return 0.477956256346;
                                    } else {
                                        return 0.162399538539;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.592922952476;
                                    } else {
                                        return 0.643157492204;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[78] <= 0.5) {
                                    return 0.605805666148;
                                } else {
                                    if (fs[53] <= -1138.5) {
                                        return 0.552749367946;
                                    } else {
                                        return 0.633825407066;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[70] <= -1.5) {
                                        return 0.350721117218;
                                    } else {
                                        return 0.5682231665;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.649415676636;
                                    } else {
                                        return 0.600341807615;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[15] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.63138738108;
                                    } else {
                                        return 0.590482796523;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.632818452972;
                                    } else {
                                        return 0.628897539571;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.577825905477;
                                    } else {
                                        return 0.622954455194;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.618928682052;
                                    } else {
                                        return 0.627800570946;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.141699941865;
                                    } else {
                                        return 0.6419136652;
                                    }
                                } else {
                                    return 0.573191456151;
                                }
                            } else {
                                return 0.0217656889661;
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1047.5) {
                        if (fs[76] <= 75.0) {
                            if (fs[4] <= 2.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[53] <= -1308.5) {
                                        return -0.0332000427951;
                                    } else {
                                        return 0.530549109231;
                                    }
                                } else {
                                    if (fs[53] <= -1493.5) {
                                        return 0.0569456184053;
                                    } else {
                                        return -0.0442078991171;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.538821135771;
                                    } else {
                                        return 0.382964378863;
                                    }
                                } else {
                                    if (fs[88] <= 6.0) {
                                        return 0.0483469819625;
                                    } else {
                                        return 0.2786107104;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.357482994189;
                                    } else {
                                        return 0.529937897818;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.593225084091;
                                    } else {
                                        return 0.340027663135;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1303.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.58493007492;
                                    } else {
                                        return 0.699412430626;
                                    }
                                } else {
                                    if (fs[72] <= 9994.5) {
                                        return 0.39912400687;
                                    } else {
                                        return 0.203914856069;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[62] <= -0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.205969589455;
                                    } else {
                                        return 0.530686048924;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.674740595484;
                                    } else {
                                        return 0.597010790064;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.267626716996;
                                    } else {
                                        return 0.156841927673;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return 0.323238295719;
                                    } else {
                                        return 0.170919801949;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= -0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.352937488682;
                                    } else {
                                        return -0.0718934276206;
                                    }
                                } else {
                                    return 0.630076344052;
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.475663538786;
                                    } else {
                                        return 0.0555316396869;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.532424925948;
                                    } else {
                                        return 0.644005172696;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[103] <= 0.5) {
                    if (fs[2] <= 5.5) {
                        if (fs[77] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[53] <= -1503.0) {
                                        return 0.561871891797;
                                    } else {
                                        return 0.305068289855;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.582547971508;
                                    } else {
                                        return 0.445378763512;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1588.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.386440523471;
                                    } else {
                                        return 0.573271477247;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.245825102118;
                                    } else {
                                        return 0.098085271256;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[4] <= 22.5) {
                                        return 0.644587800866;
                                    } else {
                                        return 0.550131757387;
                                    }
                                } else {
                                    if (fs[72] <= 9972.0) {
                                        return 0.342483567277;
                                    } else {
                                        return 0.667219643102;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9468.0) {
                                    if (fs[4] <= 14.5) {
                                        return 0.268860565807;
                                    } else {
                                        return -0.0256791408861;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return 0.715460310565;
                                    } else {
                                        return 0.334537705743;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 14.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[47] <= -314.5) {
                                        return 0.283715922783;
                                    } else {
                                        return 0.656722575422;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0930103650245;
                                    } else {
                                        return 0.521839209683;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.546299777733;
                                    } else {
                                        return 0.61118309304;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.119514646643;
                                    } else {
                                        return 0.282810220377;
                                    }
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[4] <= 27.5) {
                                    if (fs[13] <= 0.5) {
                                        return 0.365625736586;
                                    } else {
                                        return 0.61608220748;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.53003252725;
                                    } else {
                                        return 0.0807440208626;
                                    }
                                }
                            } else {
                                if (fs[2] <= 12.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.739320699113;
                                    } else {
                                        return 0.444279569195;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.630768533797;
                                    } else {
                                        return 0.749950205745;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[59] <= 0.5) {
                        if (fs[64] <= -995.5) {
                            if (fs[58] <= 0.5) {
                                if (fs[49] <= -1.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.610585405064;
                                    } else {
                                        return 0.685692673905;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return 0.510590095594;
                                    } else {
                                        return 0.602417894717;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return 0.35971664875;
                                } else {
                                    return 0.572271896524;
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.461495375344;
                                    } else {
                                        return 0.542346012683;
                                    }
                                } else {
                                    if (fs[53] <= -2003.0) {
                                        return 0.721311152613;
                                    } else {
                                        return 0.340384543251;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.313025100888;
                                    } else {
                                        return 0.510523288887;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.607345943705;
                                    } else {
                                        return 0.737893278543;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -486.5) {
                            if (fs[4] <= 18.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.146622859085;
                                    } else {
                                        return 0.392285622284;
                                    }
                                } else {
                                    if (fs[72] <= 4967.5) {
                                        return 0.750428757214;
                                    } else {
                                        return 0.676456260197;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.541757252388;
                                } else {
                                    if (fs[47] <= -3.5) {
                                        return 0.205927482859;
                                    } else {
                                        return 0.0931868924499;
                                    }
                                }
                            }
                        } else {
                            return -0.118776795299;
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[88] <= 7.5) {
                    if (fs[105] <= 0.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[103] <= 1.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0520719329189;
                                    } else {
                                        return 0.103689114864;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return 0.210738977566;
                                    } else {
                                        return 0.772322890265;
                                    }
                                }
                            } else {
                                if (fs[58] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.193348769846;
                                    } else {
                                        return 0.125343304801;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.0114245302763;
                                    } else {
                                        return 0.369305776761;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0387131760333;
                                    } else {
                                        return -0.0480788641063;
                                    }
                                } else {
                                    if (fs[47] <= -31.0) {
                                        return 0.212340770926;
                                    } else {
                                        return -0.0238078060191;
                                    }
                                }
                            } else {
                                return 0.166865553583;
                            }
                        }
                    } else {
                        if (fs[72] <= 9985.5) {
                            if (fs[47] <= -6.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.20132757891;
                                    } else {
                                        return 0.0533503259784;
                                    }
                                } else {
                                    if (fs[24] <= 0.5) {
                                        return -0.0446101144483;
                                    } else {
                                        return 0.111303170541;
                                    }
                                }
                            } else {
                                if (fs[31] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.00793848291478;
                                    } else {
                                        return -0.0229949842542;
                                    }
                                } else {
                                    if (fs[53] <= -1363.0) {
                                        return 0.250815374508;
                                    } else {
                                        return 0.0185810575492;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.149479055312;
                                    } else {
                                        return -0.0125327984243;
                                    }
                                } else {
                                    if (fs[88] <= 3.5) {
                                        return 0.0462793280373;
                                    } else {
                                        return 0.13364224705;
                                    }
                                }
                            } else {
                                if (fs[88] <= 3.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.340329735334;
                                    } else {
                                        return 0.0414777557004;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0481943272402;
                                    } else {
                                        return 0.264762597321;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 75.0) {
                        if (fs[41] <= 0.5) {
                            if (fs[47] <= -1.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.194365628203;
                                    } else {
                                        return 0.0594990289343;
                                    }
                                } else {
                                    if (fs[53] <= -972.0) {
                                        return 0.0710998288817;
                                    } else {
                                        return 0.01614817257;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[53] <= -966.0) {
                                        return -0.0370592164031;
                                    } else {
                                        return 0.009851568387;
                                    }
                                } else {
                                    return 0.273854373546;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    return 0.224981080655;
                                } else {
                                    return 0.00700255396959;
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return 0.388320575763;
                                } else {
                                    return -0.00328737976278;
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[47] <= -61.0) {
                                        return 0.225757669416;
                                    } else {
                                        return 0.0191134339076;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.663798124901;
                                    } else {
                                        return 0.565951179752;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.160456035358;
                                    } else {
                                        return 0.619925270712;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.115345934482;
                                    } else {
                                        return -0.0874560354981;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[4] <= 5.5) {
                                    return -0.0563086964868;
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.695127718649;
                                    } else {
                                        return 0.768780817778;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.310116394359;
                                    } else {
                                        return 0.125552875135;
                                    }
                                } else {
                                    if (fs[72] <= 9109.5) {
                                        return 0.54229814239;
                                    } else {
                                        return 0.372684062143;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 5.5) {
                    if (fs[72] <= 9869.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0235843263683;
                                    } else {
                                        return -0.0375641432472;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return -0.0193089054468;
                                    } else {
                                        return 0.12057646539;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.0012946689587;
                                    } else {
                                        return -0.0238537766013;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0414763275416;
                                    } else {
                                        return -0.0315815781589;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1418.0) {
                                if (fs[94] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0591982703553;
                                    } else {
                                        return 0.121251745985;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0664773728715;
                                    } else {
                                        return 0.28024851589;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0247924969427;
                                    } else {
                                        return -0.039296942436;
                                    }
                                } else {
                                    if (fs[27] <= 0.5) {
                                        return -0.0240124217355;
                                    } else {
                                        return 0.0179767264498;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[53] <= -1108.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0271095449305;
                                    } else {
                                        return 0.124340777537;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.195317725711;
                                    } else {
                                        return 0.650347014702;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[76] <= 150.0) {
                                        return 0.0381565637965;
                                    } else {
                                        return -0.0314838551121;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0596692181204;
                                    } else {
                                        return -0.0484400848931;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 6.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.00739920530468;
                                    } else {
                                        return 0.0929859662622;
                                    }
                                } else {
                                    if (fs[72] <= 9988.5) {
                                        return -0.0524057471256;
                                    } else {
                                        return -0.0384029645171;
                                    }
                                }
                            } else {
                                if (fs[47] <= -368.0) {
                                    return 0.587270715873;
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.488983191422;
                                    } else {
                                        return 0.0965898423839;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9996.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[48] <= 0.5) {
                                if (fs[47] <= -7508.5) {
                                    if (fs[53] <= -1303.0) {
                                        return 0.410477639816;
                                    } else {
                                        return -0.0734144286532;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0216227746735;
                                    } else {
                                        return -0.0364691175784;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[72] <= 9860.5) {
                                        return -0.0383234408223;
                                    } else {
                                        return -0.0231482261965;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.000716110569004;
                                    } else {
                                        return -0.0397975310244;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 20.5) {
                                if (fs[76] <= 250.0) {
                                    if (fs[97] <= 0.5) {
                                        return -0.029574136127;
                                    } else {
                                        return 0.000109404479112;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0351747657546;
                                    } else {
                                        return -0.0407739104202;
                                    }
                                }
                            } else {
                                if (fs[0] <= 120.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0373263617229;
                                    } else {
                                        return -0.0405207818326;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.138661029318;
                                    } else {
                                        return -0.031177061709;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 5.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 6.5) {
                                        return 0.339218252227;
                                    } else {
                                        return 0.0750295132217;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.0465087121811;
                                    } else {
                                        return -0.0400405817507;
                                    }
                                }
                            } else {
                                return 0.592889730337;
                            }
                        } else {
                            if (fs[53] <= -1108.0) {
                                if (fs[47] <= -86.0) {
                                    if (fs[0] <= 29.0) {
                                        return 0.554065980245;
                                    } else {
                                        return 0.0300147877776;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.101954364095;
                                    } else {
                                        return 0.601848579065;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[47] <= -458.5) {
                                        return 0.319950109387;
                                    } else {
                                        return -0.0149672465203;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.0241954671273;
                                    } else {
                                        return -0.0406995167419;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
