/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree11 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[81] <= 0.5) {
                if (fs[4] <= 19.5) {
                    if (fs[53] <= -1138.5) {
                        if (fs[4] <= 9.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.388418888209;
                                    } else {
                                        return 0.471647151788;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.262838399582;
                                    } else {
                                        return 0.430550529141;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.539944365892;
                                    } else {
                                        return 0.520964112053;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.38031874247;
                                    } else {
                                        return 0.00606054718117;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.569891473999;
                                    } else {
                                        return 0.608201243739;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.554502071598;
                                    } else {
                                        return 0.543134319233;
                                    }
                                }
                            } else {
                                return 0.424610512457;
                            }
                        }
                    } else {
                        if (fs[60] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[53] <= -1033.5) {
                                    if (fs[53] <= -1123.5) {
                                        return 0.556508548158;
                                    } else {
                                        return 0.584592513509;
                                    }
                                } else {
                                    return 0.377896227924;
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[53] <= -1038.0) {
                                        return 0.540412315643;
                                    } else {
                                        return 0.4992920401;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.513590837632;
                                    } else {
                                        return 0.560082836771;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[53] <= -1033.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.549934442981;
                                    } else {
                                        return 0.531693309992;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.00892024384557;
                                    } else {
                                        return 0.499412613017;
                                    }
                                }
                            } else {
                                return 0.142153995717;
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1568.0) {
                        if (fs[79] <= 0.5) {
                            if (fs[4] <= 40.5) {
                                if (fs[4] <= 29.5) {
                                    return -0.0308996903753;
                                } else {
                                    return 0.183943779163;
                                }
                            } else {
                                return -0.0963982857328;
                            }
                        } else {
                            return 0.477077569353;
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[4] <= 37.5) {
                                if (fs[4] <= 29.0) {
                                    return -0.13200359092;
                                } else {
                                    return 0.00434145646736;
                                }
                            } else {
                                return 0.25363052935;
                            }
                        } else {
                            return -0.148834004937;
                        }
                    }
                }
            } else {
                if (fs[76] <= 25.0) {
                    if (fs[11] <= 0.5) {
                        if (fs[4] <= 2.5) {
                            if (fs[53] <= -1308.5) {
                                if (fs[88] <= 1.0) {
                                    if (fs[48] <= 0.5) {
                                        return 0.656724917136;
                                    } else {
                                        return -0.0313179254825;
                                    }
                                } else {
                                    return -0.273020435941;
                                }
                            } else {
                                if (fs[72] <= 9901.0) {
                                    if (fs[71] <= 0.5) {
                                        return 0.560109116685;
                                    } else {
                                        return 0.366518896927;
                                    }
                                } else {
                                    if (fs[88] <= 3.5) {
                                        return 0.596368083821;
                                    } else {
                                        return 0.426770860918;
                                    }
                                }
                            }
                        } else {
                            if (fs[95] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.259126618759;
                                    } else {
                                        return 0.418334467869;
                                    }
                                } else {
                                    if (fs[64] <= -995.5) {
                                        return 0.465426159659;
                                    } else {
                                        return 0.259933712961;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.539721993896;
                                    } else {
                                        return 0.304216906126;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.53485237214;
                                    } else {
                                        return 0.580494561786;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[22] <= 0.5) {
                            if (fs[53] <= -1078.5) {
                                if (fs[72] <= 9635.0) {
                                    if (fs[4] <= 18.5) {
                                        return 0.344727065095;
                                    } else {
                                        return 0.140899759293;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return 0.423387022726;
                                    } else {
                                        return 0.635401623532;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.223022730013;
                                    } else {
                                        return 0.101297919787;
                                    }
                                } else {
                                    if (fs[72] <= 9213.0) {
                                        return 0.26561166565;
                                    } else {
                                        return 0.36807540169;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9848.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[88] <= 6.0) {
                                        return -0.0284056577378;
                                    } else {
                                        return 0.504183948846;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.180477908318;
                                    } else {
                                        return 0.553240798515;
                                    }
                                }
                            } else {
                                if (fs[53] <= -476.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.268113562398;
                                    } else {
                                        return 0.369282932657;
                                    }
                                } else {
                                    if (fs[47] <= -36.5) {
                                        return 0.185104554446;
                                    } else {
                                        return -0.129910793712;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[53] <= -982.0) {
                                if (fs[18] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.529113030182;
                                    } else {
                                        return 0.469710830853;
                                    }
                                } else {
                                    if (fs[72] <= 9988.5) {
                                        return 0.438681077554;
                                    } else {
                                        return 0.139373958593;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.399151545626;
                                    } else {
                                        return 0.608594605431;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.448992283121;
                                    } else {
                                        return 0.243645381229;
                                    }
                                }
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.199855575404;
                                    } else {
                                        return 0.352487677614;
                                    }
                                } else {
                                    if (fs[88] <= 5.0) {
                                        return 0.519478799597;
                                    } else {
                                        return 0.390558327708;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    return -0.005079346419;
                                } else {
                                    if (fs[53] <= -1008.5) {
                                        return 0.409813880367;
                                    } else {
                                        return 0.0609183487438;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[22] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[6] <= 0.5) {
                                    if (fs[83] <= 0.5) {
                                        return 0.309582451321;
                                    } else {
                                        return -0.228905929371;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.532302339687;
                                    } else {
                                        return 0.488915641797;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.392536147688;
                                    } else {
                                        return 0.528693070263;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return 0.229872853876;
                                    } else {
                                        return 0.477112980085;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.542576003573;
                                    } else {
                                        return 0.455107034557;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return 0.399645305946;
                                    } else {
                                        return 0.0375612027933;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.241679773538;
                                    } else {
                                        return 0.543841923817;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.197540876402;
                                    } else {
                                        return 0.080131903059;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[11] <= 0.5) {
                if (fs[0] <= 2.5) {
                    if (fs[53] <= -1072.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[76] <= 75.0) {
                                if (fs[72] <= 9981.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0788001601425;
                                    } else {
                                        return 0.017176182809;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.361107824968;
                                    } else {
                                        return 0.0857435730504;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[4] <= 6.5) {
                                        return 0.300543485837;
                                    } else {
                                        return 0.110519409847;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0837100664036;
                                    } else {
                                        return -0.0470749924314;
                                    }
                                }
                            }
                        } else {
                            if (fs[64] <= -997.5) {
                                if (fs[27] <= 0.5) {
                                    return 0.537286147317;
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return 0.0207932096123;
                                    } else {
                                        return 0.404849195393;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[47] <= -10.5) {
                                        return 0.277852827172;
                                    } else {
                                        return 0.105798229041;
                                    }
                                } else {
                                    if (fs[4] <= 35.0) {
                                        return 0.403397931105;
                                    } else {
                                        return 0.0749166187985;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9992.5) {
                            if (fs[53] <= -16.0) {
                                if (fs[84] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0371746135142;
                                    } else {
                                        return -0.0575089563845;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.0306839782339;
                                    } else {
                                        return 0.017970944849;
                                    }
                                }
                            } else {
                                if (fs[53] <= 3.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.149256109737;
                                    } else {
                                        return 0.0491726270167;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return -0.0428942341008;
                                    } else {
                                        return 0.09715842278;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[6] <= 0.5) {
                                        return -0.0367625492322;
                                    } else {
                                        return 0.212134479758;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.0655510562835;
                                    } else {
                                        return -0.0684861248682;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0533558833186;
                                    } else {
                                        return 0.0298254904151;
                                    }
                                } else {
                                    if (fs[4] <= 14.0) {
                                        return 0.237195213405;
                                    } else {
                                        return -0.0714473643863;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -92.5) {
                        if (fs[60] <= 0.5) {
                            if (fs[47] <= -232.0) {
                                return 0.428503130789;
                            } else {
                                return 0.586468037493;
                            }
                        } else {
                            if (fs[47] <= -96.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[4] <= 21.0) {
                                        return -0.0116973224308;
                                    } else {
                                        return 0.083688951539;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0542355044698;
                                    } else {
                                        return 0.252340077121;
                                    }
                                }
                            } else {
                                if (fs[72] <= 4999.5) {
                                    return 0.0610707574481;
                                } else {
                                    return 0.615315909528;
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 1.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[72] <= 9995.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0314440591021;
                                    } else {
                                        return -0.00548475336742;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.262537480305;
                                    } else {
                                        return 0.0205414809054;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[72] <= 9978.5) {
                                        return -0.0220486478321;
                                    } else {
                                        return 0.0229276014519;
                                    }
                                } else {
                                    return 0.463522718111;
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[57] <= 0.5) {
                                    if (fs[0] <= 6.5) {
                                        return 0.0254329978363;
                                    } else {
                                        return -0.011062840381;
                                    }
                                } else {
                                    return 0.331585107341;
                                }
                            } else {
                                if (fs[2] <= 0.5) {
                                    return -0.0102812302873;
                                } else {
                                    if (fs[27] <= 0.5) {
                                        return -0.0359206753694;
                                    } else {
                                        return -0.0319325016739;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[72] <= 9835.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[0] <= 2.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00837909763376;
                                    } else {
                                        return 0.027403435795;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return -0.0275718093106;
                                    } else {
                                        return 0.0305296911881;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[53] <= -1588.0) {
                                        return 0.147058562569;
                                    } else {
                                        return -0.00992091773902;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0748230354831;
                                    } else {
                                        return 0.461266247531;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -3766.5) {
                                if (fs[53] <= -1293.0) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0869250722114;
                                    } else {
                                        return 0.32461327333;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.0495131236406;
                                    } else {
                                        return -0.0797089106392;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[47] <= -5.5) {
                                        return -0.00591155718648;
                                    } else {
                                        return -0.0256510806372;
                                    }
                                } else {
                                    if (fs[0] <= 18.5) {
                                        return -0.0310507649084;
                                    } else {
                                        return -0.0332960615693;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[4] <= 5.0) {
                                return 0.598950225662;
                            } else {
                                return 0.496291670463;
                            }
                        } else {
                            return 0.738704760724;
                        }
                    }
                } else {
                    if (fs[53] <= -1072.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[72] <= 9988.5) {
                                        return 0.00935338684251;
                                    } else {
                                        return 0.053914131678;
                                    }
                                } else {
                                    if (fs[53] <= -1413.0) {
                                        return 0.216439836107;
                                    } else {
                                        return 0.0913467344606;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.10722256748;
                                    } else {
                                        return 0.327885619348;
                                    }
                                } else {
                                    if (fs[47] <= -236.5) {
                                        return 0.536655119265;
                                    } else {
                                        return 0.307832689578;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 6.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.108840683074;
                                    } else {
                                        return 0.298768778562;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.181548635293;
                                    } else {
                                        return 0.515958970316;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    return 0.801400346334;
                                } else {
                                    return 0.484161428989;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[76] <= 250.0) {
                                if (fs[22] <= 0.5) {
                                    if (fs[72] <= 9838.5) {
                                        return 0.519408038375;
                                    } else {
                                        return 0.0642174196897;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0656893436036;
                                    } else {
                                        return 0.0180024272266;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[2] <= 5.5) {
                                        return 0.00104078373381;
                                    } else {
                                        return 0.191775847237;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0798880895381;
                                    } else {
                                        return -0.0363686616949;
                                    }
                                }
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0301325582239;
                                    } else {
                                        return -0.0184921421618;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.0413947257974;
                                    } else {
                                        return -0.0346708984873;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9971.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0145386785247;
                                    } else {
                                        return -0.0249565606952;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.100066579281;
                                    } else {
                                        return -0.00252002521224;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
