/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree55 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[2] <= 3.5) {
                    if (fs[53] <= -1498.5) {
                        if (fs[53] <= -1953.5) {
                            if (fs[53] <= -1988.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.126175362536;
                                    } else {
                                        return 0.121386014451;
                                    }
                                } else {
                                    if (fs[88] <= 1.0) {
                                        return 0.153910519825;
                                    } else {
                                        return 0.281314406365;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.106144169241;
                                    } else {
                                        return 0.205150967607;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.103225236181;
                                    } else {
                                        return 0.0727188747114;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.215958491005;
                                    } else {
                                        return 0.12546639403;
                                    }
                                } else {
                                    return 0.457854033392;
                                }
                            } else {
                                if (fs[62] <= -1.5) {
                                    return -0.0650997903807;
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.14123734221;
                                    } else {
                                        return -0.234781653846;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= -0.5) {
                            if (fs[53] <= -1128.0) {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -1458.5) {
                                        return -0.0406845063195;
                                    } else {
                                        return -0.146660897013;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.123373544005;
                                    } else {
                                        return -0.233421166724;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0771018874824;
                                    } else {
                                        return 0.139047510698;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0335800897941;
                                    } else {
                                        return -0.181280110311;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.066268590184;
                                    } else {
                                        return 0.0409577078459;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0359420387265;
                                    } else {
                                        return -0.0166670415992;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[53] <= -967.0) {
                                        return 0.05598957437;
                                    } else {
                                        return 0.012793335581;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.00584538505937;
                                    } else {
                                        return 0.219088956058;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 8.5) {
                        if (fs[8] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.117041603369;
                                    } else {
                                        return 0.158867709717;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.0654924153506;
                                    } else {
                                        return -0.189781394151;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[82] <= 0.5) {
                                        return -0.0160876963136;
                                    } else {
                                        return 0.259314565812;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0183796256554;
                                    } else {
                                        return 0.0954955570477;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 4998.5) {
                                if (fs[52] <= 0.5) {
                                    return -0.178814191647;
                                } else {
                                    return -0.39224150671;
                                }
                            } else {
                                return -0.0849943092104;
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[4] <= 10.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.0859385202954;
                                    } else {
                                        return 0.0194140696303;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.246724784376;
                                    } else {
                                        return 0.191294372145;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1438.0) {
                                    if (fs[4] <= 12.5) {
                                        return 0.251762101094;
                                    } else {
                                        return 0.166932970313;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return 0.0129769379348;
                                    } else {
                                        return 0.112805475791;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[52] <= 0.5) {
                                    return -0.167207824105;
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0596925690177;
                                    } else {
                                        return -0.0177478807492;
                                    }
                                }
                            } else {
                                return 0.218391572835;
                            }
                        }
                    }
                }
            } else {
                if (fs[101] <= 0.5) {
                    if (fs[91] <= 0.5) {
                        if (fs[47] <= -45.0) {
                            if (fs[88] <= 0.5) {
                                if (fs[47] <= -177.0) {
                                    return 0.425137180502;
                                } else {
                                    return 0.25566754738;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    return 0.236384037316;
                                } else {
                                    return -0.0190112051021;
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 21.5) {
                                        return 0.0342476025508;
                                    } else {
                                        return -0.164175394636;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return 0.12593877514;
                                    } else {
                                        return -0.00407416605248;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[4] <= 23.5) {
                                        return -0.16459941747;
                                    } else {
                                        return -0.0613353006928;
                                    }
                                } else {
                                    if (fs[53] <= -1398.0) {
                                        return 0.0780641882874;
                                    } else {
                                        return -0.103719209594;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9972.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[55] <= -0.5) {
                                    return -0.099565863643;
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return 0.153889104126;
                                    } else {
                                        return 0.0647437127078;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    return -0.277971873648;
                                } else {
                                    return -0.134295337591;
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[72] <= 9996.5) {
                                    return 0.193208403862;
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.00635813155232;
                                    } else {
                                        return 0.138053415218;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.310515866756;
                                } else {
                                    return 0.238184480361;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[83] <= 0.5) {
                        if (fs[18] <= -0.5) {
                            return -0.312663322772;
                        } else {
                            if (fs[76] <= 250.0) {
                                if (fs[53] <= -2008.0) {
                                    if (fs[60] <= 0.5) {
                                        return 0.212105862594;
                                    } else {
                                        return 0.119772599221;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.0753159591117;
                                    } else {
                                        return -0.0129187775959;
                                    }
                                }
                            } else {
                                if (fs[6] <= 0.5) {
                                    return -0.322100361578;
                                } else {
                                    if (fs[49] <= -3.5) {
                                        return -0.154207022993;
                                    } else {
                                        return 0.0530602551929;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.103928790258;
                                    } else {
                                        return -0.339708252515;
                                    }
                                } else {
                                    return 0.405005060115;
                                }
                            } else {
                                if (fs[4] <= 23.5) {
                                    return -0.413912604115;
                                } else {
                                    return -0.110040145388;
                                }
                            }
                        } else {
                            return 0.225045977336;
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[45] <= 0.5) {
                    if (fs[4] <= 12.5) {
                        if (fs[34] <= 0.5) {
                            if (fs[88] <= -0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[24] <= 0.5) {
                                        return -0.0200302295441;
                                    } else {
                                        return 0.0288493353169;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0040407899444;
                                    } else {
                                        return -0.0456865948277;
                                    }
                                }
                            } else {
                                if (fs[64] <= -997.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.151379228098;
                                    } else {
                                        return -0.0109191487107;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.00828035414553;
                                    } else {
                                        return 0.0308540930802;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -1.5) {
                                return 0.594228917346;
                            } else {
                                if (fs[72] <= 9964.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.184873472883;
                                    } else {
                                        return -0.0167989253156;
                                    }
                                } else {
                                    return 0.489721385445;
                                }
                            }
                        }
                    } else {
                        if (fs[105] <= 0.5) {
                            if (fs[94] <= 0.5) {
                                if (fs[4] <= 23.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.00708243675512;
                                    } else {
                                        return 0.161886910431;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.0201599211461;
                                    } else {
                                        return 0.0547993644367;
                                    }
                                }
                            } else {
                                if (fs[4] <= 34.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0745118881408;
                                    } else {
                                        return 0.307668079747;
                                    }
                                } else {
                                    return -0.0972199808729;
                                }
                            }
                        } else {
                            if (fs[50] <= 0.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[72] <= 9854.5) {
                                        return -0.0110651326655;
                                    } else {
                                        return -0.0654492086536;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0373218922038;
                                    } else {
                                        return 0.206518713393;
                                    }
                                }
                            } else {
                                if (fs[88] <= 4.0) {
                                    return 0.243836956516;
                                } else {
                                    return -0.0107214677245;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 11.5) {
                        if (fs[4] <= 7.5) {
                            if (fs[70] <= -3.5) {
                                if (fs[4] <= 5.5) {
                                    return -0.0709244509341;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0597712281289;
                                    } else {
                                        return -0.0476948666509;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[72] <= 9614.5) {
                                        return -0.0305546930022;
                                    } else {
                                        return -0.0843842067982;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0242926412877;
                                    } else {
                                        return 0.0156161407335;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[76] <= 250.0) {
                                        return -0.0282032649031;
                                    } else {
                                        return -0.0197338510023;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return -0.0412779098074;
                                    } else {
                                        return -0.0118169663259;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return 0.0859000421642;
                                } else {
                                    return 0.0515578649618;
                                }
                            }
                        }
                    } else {
                        return 0.139635237786;
                    }
                }
            } else {
                if (fs[0] <= 6.5) {
                    if (fs[101] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[53] <= -1883.0) {
                                        return 0.156016989829;
                                    } else {
                                        return 0.0106319272291;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return -0.00222104126205;
                                    } else {
                                        return 0.0274703354251;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.0246214297235;
                                    } else {
                                        return -0.0227140679919;
                                    }
                                } else {
                                    if (fs[53] <= -1098.0) {
                                        return -0.030992844663;
                                    } else {
                                        return -0.00828546556047;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[24] <= 0.5) {
                                        return -0.000340436918341;
                                    } else {
                                        return 0.0447572288391;
                                    }
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return 0.0400047273193;
                                    } else {
                                        return -0.00565568205721;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0122400588604;
                                    } else {
                                        return -0.00603110933799;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.00699837972749;
                                    } else {
                                        return 0.254635009258;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[76] <= 250.0) {
                                        return 0.00570537798119;
                                    } else {
                                        return -0.0141764383883;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.00894682885835;
                                    } else {
                                        return 0.0704043375346;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -1128.0) {
                                        return 0.116919170862;
                                    } else {
                                        return -0.0306098359892;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.4406573056;
                                    } else {
                                        return 0.193214511638;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[103] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0111647046872;
                                    } else {
                                        return -0.00791899031338;
                                    }
                                } else {
                                    if (fs[4] <= 30.5) {
                                        return -0.00470654087915;
                                    } else {
                                        return 0.00597551275101;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.172652730204;
                                    } else {
                                        return 0.00908335650447;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.00867810130651;
                                    } else {
                                        return 0.120917641422;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[52] <= 0.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[24] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.00707542400221;
                                    } else {
                                        return 0.00428905085553;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.109480943635;
                                    } else {
                                        return 0.000322002524999;
                                    }
                                }
                            } else {
                                if (fs[47] <= -177.0) {
                                    return 0.459168506061;
                                } else {
                                    if (fs[4] <= 26.5) {
                                        return -0.0210855756629;
                                    } else {
                                        return -0.0114778163811;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                if (fs[0] <= 50.5) {
                                    if (fs[64] <= -996.5) {
                                        return 0.0129140680701;
                                    } else {
                                        return -0.00500434908168;
                                    }
                                } else {
                                    return 0.27291141854;
                                }
                            } else {
                                if (fs[0] <= 118.5) {
                                    if (fs[72] <= 9868.5) {
                                        return -0.00416270375909;
                                    } else {
                                        return -0.0110029426157;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.000706219472262;
                                    } else {
                                        return 0.189229282067;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -41427.0) {
                            return 0.191169504148;
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[0] <= 25.5) {
                                    if (fs[4] <= 18.5) {
                                        return -0.00043662976925;
                                    } else {
                                        return -0.00399203255099;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return -0.00441949721289;
                                    } else {
                                        return 2.19517907612e-06;
                                    }
                                }
                            } else {
                                if (fs[47] <= -10383.5) {
                                    if (fs[47] <= -12740.0) {
                                        return -0.0448498764857;
                                    } else {
                                        return 0.368906229655;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0111917882871;
                                    } else {
                                        return -0.00397566572375;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
