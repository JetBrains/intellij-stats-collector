/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree3 {
    public double calcTree(double... fs) {
        if (fs[4] <= 7.5) {
            if (fs[2] <= 1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[53] <= -987.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[53] <= -1473.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[47] <= -10.5) {
                                        return 0.321977417503;
                                    } else {
                                        return 0.0501547083932;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.533926653962;
                                    } else {
                                        return 0.365355528871;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.725537588698;
                                    } else {
                                        return 0.387739720046;
                                    }
                                } else {
                                    return 0.0808294135286;
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.676958946699;
                                    } else {
                                        return 0.594583869508;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.745910919329;
                                    } else {
                                        return 0.819934454538;
                                    }
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.749594991437;
                                    } else {
                                        return 0.650368008065;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.277147122229;
                                    } else {
                                        return 0.431915674615;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[72] <= 9987.0) {
                                if (fs[49] <= -0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.622434472783;
                                    } else {
                                        return 0.760034962284;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.495367479214;
                                    } else {
                                        return 0.297688765562;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[76] <= 150.0) {
                                        return 0.661996041603;
                                    } else {
                                        return 0.371595671089;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.590944679717;
                                    } else {
                                        return 0.435025890327;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.303238800619;
                                    } else {
                                        return 0.213825820953;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0668440531229;
                                    } else {
                                        return 0.359193949354;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[53] <= -462.0) {
                                        return -0.0933988028777;
                                    } else {
                                        return 0.269285867347;
                                    }
                                } else {
                                    return 0.767874150428;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[59] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.175778829938;
                                    } else {
                                        return 0.0873157835759;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0219812939194;
                                    } else {
                                        return 0.120591624388;
                                    }
                                }
                            } else {
                                if (fs[72] <= 8823.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0273105264608;
                                    } else {
                                        return -0.010225889922;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.051005544327;
                                    } else {
                                        return 0.187086310014;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[47] <= -2.5) {
                                        return 0.122223633685;
                                    } else {
                                        return 0.011498592384;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.256928554839;
                                    } else {
                                        return -0.0394855419802;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[81] <= 0.5) {
                                        return -0.00533147239277;
                                    } else {
                                        return 0.0807997937495;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return 0.419041515601;
                                    } else {
                                        return 0.051756657089;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9981.5) {
                            if (fs[0] <= 4.5) {
                                if (fs[47] <= -322.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.107263106221;
                                    } else {
                                        return 0.451513154985;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0218184940169;
                                    } else {
                                        return 0.00539942022964;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3460.0) {
                                    if (fs[88] <= 7.5) {
                                        return -0.0158165128584;
                                    } else {
                                        return 0.257367165685;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return -0.00517774155593;
                                    } else {
                                        return -0.04456832638;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0895918433129;
                                    } else {
                                        return -0.0299001479867;
                                    }
                                } else {
                                    if (fs[72] <= 9993.5) {
                                        return 0.00121631228282;
                                    } else {
                                        return 0.13515034454;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1443.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.269942951421;
                                    } else {
                                        return 0.0621933010898;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.00875504323189;
                                    } else {
                                        return -0.052862776027;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[76] <= 75.0) {
                    if (fs[85] <= 0.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.78624691397;
                                    } else {
                                        return 0.798559906932;
                                    }
                                } else {
                                    return 0.557342266538;
                                }
                            } else {
                                if (fs[30] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.012454176432;
                                    } else {
                                        return 0.194600195496;
                                    }
                                } else {
                                    return 0.757137433984;
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[4] <= 2.5) {
                                    if (fs[7] <= 0.5) {
                                        return 0.488604701799;
                                    } else {
                                        return -0.018774306926;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.661997212567;
                                    } else {
                                        return 0.329722468142;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9985.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0356486448573;
                                    } else {
                                        return -0.0333615596319;
                                    }
                                } else {
                                    if (fs[74] <= 0.5) {
                                        return 0.101640967947;
                                    } else {
                                        return 0.464976692032;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9850.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[90] <= 0.5) {
                                    if (fs[47] <= -10.5) {
                                        return 0.0633438830909;
                                    } else {
                                        return -0.046104539532;
                                    }
                                } else {
                                    if (fs[53] <= -1468.0) {
                                        return 0.462635100083;
                                    } else {
                                        return -0.0645017362549;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.193134367987;
                                    } else {
                                        return 0.0758527222824;
                                    }
                                } else {
                                    if (fs[53] <= -1468.5) {
                                        return 0.601069869058;
                                    } else {
                                        return 0.0235480867158;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[88] <= 5.5) {
                                        return 0.578072519331;
                                    } else {
                                        return 0.803940889297;
                                    }
                                } else {
                                    if (fs[0] <= 13.5) {
                                        return 0.127095491011;
                                    } else {
                                        return -0.0293202933716;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[47] <= -36.5) {
                                        return 0.230033844521;
                                    } else {
                                        return -0.0371992266653;
                                    }
                                } else {
                                    return 0.477410303626;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[97] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.775673469506;
                                    } else {
                                        return 0.667247935164;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.633290587237;
                                    } else {
                                        return 0.768796521564;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.518397058375;
                                    } else {
                                        return 0.182218447492;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.41806517329;
                                    } else {
                                        return 0.738016872688;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 7.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.119070532183;
                                    } else {
                                        return -0.0248195081049;
                                    }
                                } else {
                                    if (fs[53] <= -1077.5) {
                                        return 0.236403834266;
                                    } else {
                                        return -0.0123861307176;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return 0.671597902802;
                                    } else {
                                        return 0.101192937399;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.051448887104;
                                    } else {
                                        return -0.0540642215198;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                return 0.723373008042;
                            } else {
                                if (fs[0] <= 0.5) {
                                    return 0.553946832428;
                                } else {
                                    return 0.0882722839756;
                                }
                            }
                        } else {
                            if (fs[57] <= 0.5) {
                                if (fs[53] <= -1053.0) {
                                    if (fs[2] <= 3.5) {
                                        return 0.165293143507;
                                    } else {
                                        return 0.397156302687;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.480053287874;
                                    } else {
                                        return -0.00523758137347;
                                    }
                                }
                            } else {
                                return 0.727344048033;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[103] <= 0.5) {
                    if (fs[44] <= 0.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[76] <= 100.0) {
                                if (fs[60] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.794962964959;
                                    } else {
                                        return 0.771640171804;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.79306831877;
                                    } else {
                                        return 0.470998908024;
                                    }
                                }
                            } else {
                                if (fs[4] <= 21.5) {
                                    return 0.368639476326;
                                } else {
                                    if (fs[53] <= -1328.0) {
                                        return 0.0367342543786;
                                    } else {
                                        return 0.257151042564;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[49] <= -0.5) {
                                    if (fs[72] <= 4995.5) {
                                        return 0.615361973016;
                                    } else {
                                        return 0.757436583538;
                                    }
                                } else {
                                    if (fs[53] <= -1448.0) {
                                        return 0.567381490244;
                                    } else {
                                        return 0.427905087315;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.316415272211;
                                    } else {
                                        return 0.575929061409;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.561400742703;
                                    } else {
                                        return 0.20551050312;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[102] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[4] <= 26.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.646699037668;
                                    } else {
                                        return 0.768675918302;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.27842283844;
                                    } else {
                                        return 0.582584441496;
                                    }
                                }
                            } else {
                                if (fs[93] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.301540211303;
                                    } else {
                                        return 0.586218311564;
                                    }
                                } else {
                                    if (fs[72] <= 9976.5) {
                                        return 0.133339067782;
                                    } else {
                                        return -0.0232600962232;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -490.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[72] <= 9983.5) {
                                        return 0.782417744323;
                                    } else {
                                        return 0.82193886672;
                                    }
                                } else {
                                    return 0.735316173423;
                                }
                            } else {
                                if (fs[72] <= 9995.5) {
                                    if (fs[72] <= 4967.5) {
                                        return 0.666110784054;
                                    } else {
                                        return 0.707147637322;
                                    }
                                } else {
                                    return 0.480935827474;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[103] <= 1.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[62] <= -0.5) {
                                if (fs[53] <= -1093.0) {
                                    if (fs[4] <= 11.5) {
                                        return 0.799180519818;
                                    } else {
                                        return 0.602688169374;
                                    }
                                } else {
                                    return 0.394087997656;
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.451402974532;
                                    } else {
                                        return 0.580554267168;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.281783896339;
                                    } else {
                                        return 0.521887820222;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 12.5) {
                                if (fs[63] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.745207326524;
                                    } else {
                                        return 0.659975186804;
                                    }
                                } else {
                                    return 0.183574224567;
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[4] <= 28.5) {
                                        return 0.611522233104;
                                    } else {
                                        return 0.367645607995;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.479881386535;
                                    } else {
                                        return 0.214559981636;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[64] <= -996.5) {
                            if (fs[64] <= -997.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.781110150616;
                                    } else {
                                        return 0.807663453225;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.811827792261;
                                    } else {
                                        return 0.751836835416;
                                    }
                                }
                            } else {
                                if (fs[49] <= -1.5) {
                                    if (fs[49] <= -2.5) {
                                        return 0.782528336826;
                                    } else {
                                        return 0.676694168768;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.785212054028;
                                    } else {
                                        return 0.818533293923;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 20.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.665902473468;
                                    } else {
                                        return 0.714423555042;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.405027613148;
                                    } else {
                                        return -0.0413986674178;
                                    }
                                }
                            } else {
                                if (fs[64] <= -995.5) {
                                    return 0.829358769866;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.50887762479;
                                    } else {
                                        return 0.39930294898;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[101] <= 0.5) {
                        if (fs[47] <= -2.5) {
                            if (fs[88] <= 4.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[72] <= 9877.5) {
                                        return 0.0834558476193;
                                    } else {
                                        return 0.180140545834;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.444283345263;
                                    } else {
                                        return 0.171675588874;
                                    }
                                }
                            } else {
                                if (fs[14] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.000471437824688;
                                    } else {
                                        return 0.206498128451;
                                    }
                                } else {
                                    return 0.479483548417;
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[72] <= 9987.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.0190316017463;
                                    } else {
                                        return 0.0529339579971;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.108148036385;
                                    } else {
                                        return 0.343535932701;
                                    }
                                }
                            } else {
                                if (fs[88] <= 1.5) {
                                    if (fs[72] <= 9993.5) {
                                        return 0.0460317326081;
                                    } else {
                                        return 0.14745522842;
                                    }
                                } else {
                                    if (fs[72] <= 9983.5) {
                                        return 0.00240896126133;
                                    } else {
                                        return 0.101822461906;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[23] <= 0.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0562474218961;
                                    } else {
                                        return 0.134856994508;
                                    }
                                } else {
                                    if (fs[53] <= -1283.0) {
                                        return 0.360991228717;
                                    } else {
                                        return 0.108878898793;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[53] <= -382.0) {
                                        return -0.023771404958;
                                    } else {
                                        return 0.216688894237;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0410899436244;
                                    } else {
                                        return -0.0164715849187;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[103] <= 1.0) {
                                        return -0.0332278814297;
                                    } else {
                                        return 0.0203665009265;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.107026133158;
                                    } else {
                                        return -0.0327177469524;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.123700008427;
                                    } else {
                                        return 0.0150761086555;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.283041221;
                                    } else {
                                        return -0.0135044572313;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[101] <= 0.5) {
                        if (fs[47] <= -2.5) {
                            if (fs[72] <= 9982.5) {
                                if (fs[0] <= 7.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.00658403185153;
                                    } else {
                                        return -0.0222498461535;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0426438969178;
                                    } else {
                                        return -0.0288290755848;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1408.0) {
                                    if (fs[88] <= 6.5) {
                                        return 0.19190291654;
                                    } else {
                                        return 0.579230334594;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.0625530870603;
                                    } else {
                                        return -0.0465155662114;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0488654480754;
                                    } else {
                                        return -0.0448777587952;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0218271583309;
                                    } else {
                                        return -0.0445146785565;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0138950260744;
                                    } else {
                                        return -0.0449231766921;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.032932369727;
                                    } else {
                                        return 0.505132269765;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= 3.5) {
                            if (fs[72] <= 9983.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.00153456547983;
                                    } else {
                                        return -0.0486368580374;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return -0.0302251169979;
                                    } else {
                                        return -0.0421709780391;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[53] <= -1277.5) {
                                        return 0.12027962641;
                                    } else {
                                        return -0.0115779573989;
                                    }
                                } else {
                                    if (fs[53] <= -1448.0) {
                                        return 0.184505124436;
                                    } else {
                                        return 0.0338380418507;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[83] <= 0.5) {
                                        return -0.0500161065726;
                                    } else {
                                        return -0.0467544870527;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.0497995965798;
                                    } else {
                                        return -0.0377254988156;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[72] <= 9920.0) {
                                        return -0.0506747471215;
                                    } else {
                                        return -0.0522329285926;
                                    }
                                } else {
                                    if (fs[64] <= -498.0) {
                                        return -0.0555016530852;
                                    } else {
                                        return -0.052215169168;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
