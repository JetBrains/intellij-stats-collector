/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree48 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[30] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 11.5) {
                        if (fs[2] <= 2.5) {
                            if (fs[88] <= -0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return -0.118501273421;
                                    } else {
                                        return -0.105516008562;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0986896772196;
                                    } else {
                                        return -0.269812082594;
                                    }
                                }
                            } else {
                                if (fs[74] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0819570728125;
                                    } else {
                                        return 0.0444997957253;
                                    }
                                } else {
                                    if (fs[53] <= -1123.5) {
                                        return -0.0645315639268;
                                    } else {
                                        return 0.198253453173;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return 0.0848629831993;
                                    } else {
                                        return 0.145912344348;
                                    }
                                } else {
                                    if (fs[47] <= -15304.5) {
                                        return -0.246498757745;
                                    } else {
                                        return 0.0798465387334;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0263438005296;
                                    } else {
                                        return 0.115837547436;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.023967962468;
                                    } else {
                                        return -0.0353748028028;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[105] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0157927261106;
                                    } else {
                                        return 0.0845853233724;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.149627064892;
                                    } else {
                                        return -0.0212733272886;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1618.0) {
                                    if (fs[44] <= 0.5) {
                                        return 0.154896341161;
                                    } else {
                                        return 0.27916854402;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0262086604467;
                                    } else {
                                        return 0.0402686491385;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[88] <= 0.5) {
                                    return -0.295514430818;
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.00537585870312;
                                    } else {
                                        return 0.152030223137;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[2] <= 8.5) {
                                        return -0.157548632015;
                                    } else {
                                        return 0.210950148108;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0444860758699;
                                    } else {
                                        return 0.130737383757;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[53] <= -1478.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0421705335499;
                                    } else {
                                        return 0.000304932007376;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return 0.0956398275695;
                                    } else {
                                        return -0.0558078913225;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.376163491812;
                                    } else {
                                        return 0.104845279212;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0379388254682;
                                    } else {
                                        return 0.302593743666;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.00864379168851;
                                    } else {
                                        return -0.0169865161424;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.0229144234933;
                                    } else {
                                        return 0.046733006441;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[72] <= 9899.5) {
                                        return -0.0101321368712;
                                    } else {
                                        return 0.0930766811943;
                                    }
                                } else {
                                    if (fs[64] <= -498.5) {
                                        return 0.379835386769;
                                    } else {
                                        return 0.0494943254684;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.00131375367735;
                                    } else {
                                        return -0.00784096976835;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return -0.0212644399006;
                                    } else {
                                        return -0.00690068183149;
                                    }
                                }
                            } else {
                                if (fs[88] <= 7.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.00518887764883;
                                    } else {
                                        return -0.00479936691447;
                                    }
                                } else {
                                    if (fs[53] <= -1448.0) {
                                        return 0.0776707594835;
                                    } else {
                                        return -0.00649907944651;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -3782.0) {
                                if (fs[88] <= 6.5) {
                                    if (fs[72] <= 9771.5) {
                                        return 0.0182922137258;
                                    } else {
                                        return 0.220780925256;
                                    }
                                } else {
                                    return 0.285956764761;
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[85] <= 0.5) {
                                        return 0.000484256655065;
                                    } else {
                                        return -0.00559876175041;
                                    }
                                } else {
                                    if (fs[53] <= -1067.5) {
                                        return 0.00618875951546;
                                    } else {
                                        return -0.00623489587462;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 7.5) {
                    if (fs[53] <= -1098.5) {
                        if (fs[68] <= 1.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0973854923191;
                                    } else {
                                        return 0.253717398031;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0864703666225;
                                    } else {
                                        return 0.287924992557;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[53] <= -1128.0) {
                                        return 0.0645292100555;
                                    } else {
                                        return 0.095746878588;
                                    }
                                } else {
                                    if (fs[53] <= -1118.0) {
                                        return 0.0923796392175;
                                    } else {
                                        return 0.125314571924;
                                    }
                                }
                            }
                        } else {
                            return 0.225964318296;
                        }
                    } else {
                        return 0.0182035240657;
                    }
                } else {
                    if (fs[53] <= -1138.0) {
                        if (fs[2] <= 2.5) {
                            return -0.231039982354;
                        } else {
                            return 0.128153499443;
                        }
                    } else {
                        return 0.112304752042;
                    }
                }
            }
        } else {
            if (fs[45] <= 0.5) {
                if (fs[0] <= 0.5) {
                    if (fs[71] <= 0.5) {
                        if (fs[18] <= -0.5) {
                            if (fs[76] <= 150.0) {
                                return -0.206000978996;
                            } else {
                                return -0.128467032443;
                            }
                        } else {
                            if (fs[4] <= 31.5) {
                                if (fs[53] <= -1513.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.201246870694;
                                    } else {
                                        return 0.105730790988;
                                    }
                                } else {
                                    if (fs[95] <= 0.5) {
                                        return 0.0941491475443;
                                    } else {
                                        return 0.311400704485;
                                    }
                                }
                            } else {
                                if (fs[47] <= -2.5) {
                                    return 0.254966151745;
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.145935402166;
                                    } else {
                                        return -0.522310169615;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[23] <= 0.5) {
                            if (fs[8] <= 0.5) {
                                if (fs[83] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0879762086802;
                                    } else {
                                        return -0.226633351228;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.258056941875;
                                    } else {
                                        return 0.229985977361;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    return -0.173695492302;
                                } else {
                                    return -0.245412066903;
                                }
                            }
                        } else {
                            if (fs[88] <= 1.0) {
                                if (fs[47] <= -5.5) {
                                    if (fs[47] <= -22.5) {
                                        return 0.0459047645274;
                                    } else {
                                        return 0.123526134558;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.000919994713313;
                                    } else {
                                        return 0.295865789743;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0794069760258;
                                    } else {
                                        return -0.000579296448152;
                                    }
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return 0.176745111517;
                                    } else {
                                        return 0.0949824579872;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9999.5) {
                        if (fs[2] <= 6.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 3.5) {
                                        return -0.059240431309;
                                    } else {
                                        return 0.0140857433813;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0483160783476;
                                    } else {
                                        return 0.0172553618995;
                                    }
                                }
                            } else {
                                if (fs[18] <= -0.5) {
                                    return -0.207500628841;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0164336976742;
                                    } else {
                                        return 0.0937767560766;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 9.5) {
                                if (fs[4] <= 14.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0974641984764;
                                    } else {
                                        return 0.339040492837;
                                    }
                                } else {
                                    if (fs[47] <= -3.5) {
                                        return 0.210967585225;
                                    } else {
                                        return -0.00461104497885;
                                    }
                                }
                            } else {
                                return 0.366880653524;
                            }
                        }
                    } else {
                        if (fs[70] <= -4.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    return -0.0196082185633;
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.106086649282;
                                    } else {
                                        return -0.159670149078;
                                    }
                                }
                            } else {
                                return -0.19244436998;
                            }
                        } else {
                            if (fs[55] <= 998.0) {
                                if (fs[53] <= -1268.0) {
                                    if (fs[41] <= 0.5) {
                                        return 0.105784636994;
                                    } else {
                                        return -0.185811167899;
                                    }
                                } else {
                                    if (fs[4] <= 18.5) {
                                        return 0.0433469672401;
                                    } else {
                                        return -0.068494488491;
                                    }
                                }
                            } else {
                                return 0.440478754467;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 13.5) {
                        return 0.324375340254;
                    } else {
                        return 0.0918629127975;
                    }
                } else {
                    if (fs[53] <= -1057.0) {
                        return -0.129138855305;
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[76] <= 75.0) {
                                if (fs[47] <= -1.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.049858588263;
                                    } else {
                                        return 0.0368749466536;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return -0.0508301520658;
                                    } else {
                                        return -0.0345743393608;
                                    }
                                }
                            } else {
                                if (fs[47] <= -297.5) {
                                    return -0.049415763709;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0271791896398;
                                    } else {
                                        return -0.013798146981;
                                    }
                                }
                            }
                        } else {
                            if (fs[91] <= 0.5) {
                                if (fs[67] <= 0.5) {
                                    if (fs[4] <= 16.5) {
                                        return -0.00971968083444;
                                    } else {
                                        return -0.000380907174884;
                                    }
                                } else {
                                    return 0.104163389562;
                                }
                            } else {
                                return -0.0623490123815;
                            }
                        }
                    }
                }
            }
        }
    }
}
