/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree86 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[53] <= -1988.5) {
                if (fs[52] <= 0.5) {
                    if (fs[85] <= 0.5) {
                        if (fs[4] <= 6.5) {
                            if (fs[71] <= 0.5) {
                                return -0.0125007530886;
                            } else {
                                return -0.123576129244;
                            }
                        } else {
                            if (fs[53] <= -2358.5) {
                                if (fs[53] <= -2458.0) {
                                    if (fs[4] <= 24.5) {
                                        return 0.0159101314351;
                                    } else {
                                        return 0.119027026251;
                                    }
                                } else {
                                    return -0.215380765771;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.229501756357;
                                    } else {
                                        return 0.107473837077;
                                    }
                                } else {
                                    if (fs[72] <= 9981.0) {
                                        return 0.128427873783;
                                    } else {
                                        return 0.0466938185297;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -2888.0) {
                            return 0.127674243999;
                        } else {
                            if (fs[72] <= 9905.5) {
                                if (fs[47] <= -4.5) {
                                    return -0.171608071413;
                                } else {
                                    return 0.152291755997;
                                }
                            } else {
                                return -0.281606614826;
                            }
                        }
                    }
                } else {
                    if (fs[70] <= -1.5) {
                        if (fs[85] <= 0.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[53] <= -2048.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0372830742528;
                                    } else {
                                        return -0.165628500953;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.200958743136;
                                    } else {
                                        return 0.100764676533;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    return 0.0889561730327;
                                } else {
                                    return 0.146321359995;
                                }
                            }
                        } else {
                            if (fs[4] <= 8.0) {
                                return -0.0890414698653;
                            } else {
                                if (fs[53] <= -2413.5) {
                                    if (fs[53] <= -2608.0) {
                                        return 0.209914482601;
                                    } else {
                                        return 0.0826281197315;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return 0.274514144352;
                                    } else {
                                        return 0.180986223619;
                                    }
                                }
                            }
                        }
                    } else {
                        return -0.252886822722;
                    }
                }
            } else {
                if (fs[2] <= 2.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[47] <= -84.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[47] <= -354.0) {
                                        return 0.0122260588469;
                                    } else {
                                        return 0.143015156363;
                                    }
                                } else {
                                    if (fs[47] <= -757.0) {
                                        return 0.0926396624275;
                                    } else {
                                        return 0.243787405853;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1478.0) {
                                    if (fs[44] <= 0.5) {
                                        return -0.160939831911;
                                    } else {
                                        return 0.0697078523425;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0126186724885;
                                    } else {
                                        return 0.161597773991;
                                    }
                                }
                            }
                        } else {
                            if (fs[74] <= 0.5) {
                                if (fs[92] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0903473615128;
                                    } else {
                                        return 0.0588380464092;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return -0.0986920871464;
                                    } else {
                                        return 0.0124732515593;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1123.5) {
                                    if (fs[72] <= 9902.0) {
                                        return -0.0638231767272;
                                    } else {
                                        return 0.0220787537952;
                                    }
                                } else {
                                    if (fs[72] <= 9991.0) {
                                        return 0.209579739088;
                                    } else {
                                        return 0.0140551362271;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[47] <= -528.0) {
                                if (fs[60] <= 0.5) {
                                    if (fs[47] <= -3110.5) {
                                        return 0.314822479131;
                                    } else {
                                        return 0.157391208077;
                                    }
                                } else {
                                    if (fs[47] <= -3058.0) {
                                        return -0.28941668383;
                                    } else {
                                        return 0.0842403262283;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1143.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.043101959748;
                                    } else {
                                        return 0.112684108729;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.0217404611483;
                                    } else {
                                        return 0.109565573079;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -947.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.00393098944674;
                                    } else {
                                        return 0.153463708491;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return -0.0530939020413;
                                    } else {
                                        return 0.0728352902505;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.0380733565849;
                                    } else {
                                        return 0.239230826961;
                                    }
                                } else {
                                    return -0.346246588055;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[32] <= 0.5) {
                        if (fs[8] <= 0.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[51] <= 0.5) {
                                        return 0.0168755077272;
                                    } else {
                                        return 0.166317585232;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.0123497958841;
                                    } else {
                                        return 0.0334316360253;
                                    }
                                }
                            } else {
                                if (fs[2] <= 10.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0408992505965;
                                    } else {
                                        return 0.00359840361661;
                                    }
                                } else {
                                    if (fs[88] <= 3.0) {
                                        return 0.0700509819776;
                                    } else {
                                        return 0.238493594252;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 250.0) {
                                if (fs[101] <= 1.0) {
                                    if (fs[2] <= 4.5) {
                                        return -0.159138667309;
                                    } else {
                                        return 0.043145206389;
                                    }
                                } else {
                                    return -0.446325021888;
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    return 0.134206826068;
                                } else {
                                    return -0.146912845816;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 12.5) {
                            return -0.312671992284;
                        } else {
                            return -0.222602377418;
                        }
                    }
                }
            }
        } else {
            if (fs[14] <= 0.5) {
                if (fs[4] <= 18.5) {
                    if (fs[105] <= 0.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.034328238495;
                                    } else {
                                        return 0.00233189201326;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return -0.00223492894873;
                                    } else {
                                        return -0.00701918337643;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9930.5) {
                                    if (fs[62] <= -2.5) {
                                        return 0.248923673992;
                                    } else {
                                        return 0.00266666228483;
                                    }
                                } else {
                                    if (fs[53] <= -1448.0) {
                                        return 0.144788588748;
                                    } else {
                                        return 0.00530501270038;
                                    }
                                }
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[0] <= 18.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.00223110167282;
                                    } else {
                                        return 0.00852755220933;
                                    }
                                } else {
                                    if (fs[0] <= 30.5) {
                                        return -0.000237910563535;
                                    } else {
                                        return -0.00194161961973;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.00287415412158;
                                    } else {
                                        return 0.133014564995;
                                    }
                                } else {
                                    if (fs[53] <= -1137.5) {
                                        return 0.0235572957295;
                                    } else {
                                        return 0.094209172565;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -3.5) {
                            if (fs[53] <= -1128.0) {
                                if (fs[88] <= 6.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.00819918471328;
                                    } else {
                                        return 0.21621125958;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0344544800724;
                                    } else {
                                        return 0.0557070948575;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[47] <= -5.5) {
                                        return -0.002161512407;
                                    } else {
                                        return 0.0158377050276;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0290783522025;
                                    } else {
                                        return -0.00732117564337;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.00576313517915;
                                    } else {
                                        return 0.0164972812358;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return 0.036984615118;
                                    } else {
                                        return 0.224887539561;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[72] <= 9534.5) {
                                        return -0.00269702537633;
                                    } else {
                                        return -0.0282388328584;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0015966516589;
                                    } else {
                                        return 0.0446761347843;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -3443.0) {
                        if (fs[71] <= 0.5) {
                            if (fs[72] <= 4949.5) {
                                if (fs[101] <= 0.5) {
                                    return -0.0109532540059;
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.224277537316;
                                    } else {
                                        return -0.00994367465307;
                                    }
                                }
                            } else {
                                return -0.104445665736;
                            }
                        } else {
                            if (fs[4] <= 21.5) {
                                return -0.0283514577257;
                            } else {
                                return 0.249390683217;
                            }
                        }
                    } else {
                        if (fs[97] <= 0.5) {
                            if (fs[29] <= 0.5) {
                                if (fs[2] <= 18.5) {
                                    if (fs[53] <= -1353.5) {
                                        return -0.000876486868824;
                                    } else {
                                        return -0.00199505397706;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return -0.131709287327;
                                    } else {
                                        return -0.0329458381714;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[47] <= -15.0) {
                                        return 0.266291181483;
                                    } else {
                                        return 0.0299320511214;
                                    }
                                } else {
                                    if (fs[0] <= 33.5) {
                                        return -0.00344435972489;
                                    } else {
                                        return 0.0189118472093;
                                    }
                                }
                            }
                        } else {
                            if (fs[94] <= 0.5) {
                                if (fs[53] <= -1042.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0279839425525;
                                    } else {
                                        return -0.00885113514582;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.00699703318221;
                                    } else {
                                        return -0.000670667497234;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0997012348618;
                                    } else {
                                        return 0.00733832295787;
                                    }
                                } else {
                                    if (fs[4] <= 24.5) {
                                        return 0.563170967942;
                                    } else {
                                        return -0.0305453010806;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 4.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[4] <= 5.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[53] <= -21.5) {
                                    return -0.147114083841;
                                } else {
                                    return 0.111318561524;
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    return 0.246034022427;
                                } else {
                                    return 0.550867824954;
                                }
                            }
                        } else {
                            if (fs[101] <= 1.5) {
                                if (fs[4] <= 37.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0157834078403;
                                    } else {
                                        return 0.022629820974;
                                    }
                                } else {
                                    return 0.108855645638;
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[53] <= -1133.0) {
                                        return 0.104793027579;
                                    } else {
                                        return -0.0483822334739;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return -0.00227905943925;
                                    } else {
                                        return 0.217393214697;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[26] <= 0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.316960340578;
                                    } else {
                                        return 0.102957636755;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.210099045651;
                                    } else {
                                        return 0.0159265224045;
                                    }
                                }
                            } else {
                                if (fs[4] <= 33.0) {
                                    if (fs[53] <= -1308.0) {
                                        return 0.129352188957;
                                    } else {
                                        return 0.00254184431596;
                                    }
                                } else {
                                    return -0.123809620093;
                                }
                            }
                        } else {
                            return 0.29160411136;
                        }
                    }
                } else {
                    if (fs[71] <= 0.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                return -0.0121273429886;
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[47] <= -22.0) {
                                        return -0.0395053807209;
                                    } else {
                                        return -0.0173724918335;
                                    }
                                } else {
                                    return -0.0374516412966;
                                }
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[0] <= 9.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0106447249086;
                                    } else {
                                        return -0.0250796335153;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.00226503245973;
                                    } else {
                                        return 6.66738204241e-05;
                                    }
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    return 0.073907562841;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.00222267580245;
                                    } else {
                                        return -0.0199017755722;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[47] <= -1.5) {
                                    return 0.184726288375;
                                } else {
                                    if (fs[72] <= 9988.5) {
                                        return 0.000586607111639;
                                    } else {
                                        return 0.121291909378;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9984.5) {
                                    if (fs[0] <= 6.5) {
                                        return 0.0729213951711;
                                    } else {
                                        return 0.00648941009966;
                                    }
                                } else {
                                    return 0.3366626382;
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                return -0.03312544102;
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[4] <= 17.5) {
                                        return -0.00819342729879;
                                    } else {
                                        return -0.0041921946525;
                                    }
                                } else {
                                    return -0.0189807079308;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
