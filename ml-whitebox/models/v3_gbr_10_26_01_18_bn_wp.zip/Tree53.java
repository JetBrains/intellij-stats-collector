/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree53 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[0] <= 0.5) {
                if (fs[22] <= 0.5) {
                    if (fs[53] <= -861.5) {
                        if (fs[74] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[32] <= 0.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.219557394163;
                                    } else {
                                        return 0.0995766530189;
                                    }
                                } else {
                                    return -0.387057704964;
                                }
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0590059817963;
                                    } else {
                                        return -0.165627069045;
                                    }
                                } else {
                                    if (fs[4] <= 15.0) {
                                        return 0.263331605451;
                                    } else {
                                        return -0.239827254204;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1123.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0487907308067;
                                    } else {
                                        return 0.0335701395621;
                                    }
                                } else {
                                    return 0.03947205781;
                                }
                            } else {
                                if (fs[53] <= -1118.5) {
                                    return 0.0968895519293;
                                } else {
                                    return 0.175024552384;
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.0374152678239;
                                    } else {
                                        return 0.270384923593;
                                    }
                                } else {
                                    if (fs[64] <= -497.5) {
                                        return 0.0811345629725;
                                    } else {
                                        return -0.0644390241113;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.11269372014;
                                    } else {
                                        return -0.00210555624177;
                                    }
                                } else {
                                    if (fs[88] <= 3.5) {
                                        return 0.0134258201902;
                                    } else {
                                        return 0.095366173003;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[47] <= -372.0) {
                                        return 0.153432734164;
                                    } else {
                                        return -0.0807970661136;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.127181630046;
                                    } else {
                                        return -0.00475710161193;
                                    }
                                }
                            } else {
                                if (fs[47] <= -181.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.157266255151;
                                    } else {
                                        return 0.355512144169;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.120702489552;
                                    } else {
                                        return 0.0726134607486;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[71] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[4] <= 16.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.176372751258;
                                    } else {
                                        return 0.115701123608;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0354518082972;
                                    } else {
                                        return 0.198597164828;
                                    }
                                }
                            } else {
                                if (fs[88] <= 7.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.288413956298;
                                    } else {
                                        return 0.244915126656;
                                    }
                                } else {
                                    return 0.209303133582;
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[88] <= 2.5) {
                                    if (fs[101] <= 1.5) {
                                        return -0.0558821939884;
                                    } else {
                                        return 0.0977732216247;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return 0.10078547825;
                                    } else {
                                        return -0.153655660162;
                                    }
                                }
                            } else {
                                if (fs[88] <= 4.5) {
                                    if (fs[53] <= -1803.5) {
                                        return 0.130027174644;
                                    } else {
                                        return -0.0166687739183;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.237644340865;
                                    } else {
                                        return -0.0762003628935;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -107.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[88] <= 0.5) {
                                    if (fs[47] <= -134.5) {
                                        return 0.154443034614;
                                    } else {
                                        return -0.0601507478285;
                                    }
                                } else {
                                    return -0.269363033811;
                                }
                            } else {
                                if (fs[47] <= -15304.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.661968704873;
                                    } else {
                                        return -0.144234311953;
                                    }
                                } else {
                                    if (fs[47] <= -139.5) {
                                        return 0.019513164475;
                                    } else {
                                        return 0.244035936222;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.0890562027463;
                                    } else {
                                        return 0.00222946331126;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.0928022593032;
                                    } else {
                                        return 0.101659126444;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.163646474136;
                                    } else {
                                        return 0.0766512697449;
                                    }
                                } else {
                                    if (fs[72] <= 9874.0) {
                                        return -0.0583111423495;
                                    } else {
                                        return 0.120637036062;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[30] <= 0.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[99] <= 0.5) {
                            if (fs[47] <= -119.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[72] <= 9944.5) {
                                        return 0.00704905595175;
                                    } else {
                                        return 0.157899310701;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.482651804614;
                                    } else {
                                        return 0.0594670184942;
                                    }
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0339850001737;
                                    } else {
                                        return -0.0231042313797;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.00332064820462;
                                    } else {
                                        return 0.00264440035739;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0155141939589;
                                    } else {
                                        return 0.0561348990052;
                                    }
                                } else {
                                    return 0.330887173885;
                                }
                            } else {
                                if (fs[53] <= -1098.0) {
                                    if (fs[0] <= 70.0) {
                                        return 0.00780379431607;
                                    } else {
                                        return 0.206764805233;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.00284251633589;
                                    } else {
                                        return -0.00915837557593;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[76] <= 250.0) {
                                if (fs[0] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0325827009401;
                                    } else {
                                        return -0.00597500392747;
                                    }
                                } else {
                                    if (fs[47] <= -2037.5) {
                                        return -0.0360493631188;
                                    } else {
                                        return -0.00475771205015;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[103] <= 1.5) {
                                        return -0.0189974604541;
                                    } else {
                                        return -0.00333596013664;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.00722505562097;
                                    } else {
                                        return -0.000274552857486;
                                    }
                                }
                            }
                        } else {
                            if (fs[90] <= 0.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0104996325782;
                                    } else {
                                        return -0.00357895517363;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.00366793804478;
                                    } else {
                                        return 0.12732305287;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.0287291964198;
                                    } else {
                                        return 0.00379662557184;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0174272257563;
                                    } else {
                                        return -0.00553857375731;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1138.0) {
                        return 0.146550057369;
                    } else {
                        return 0.263937537491;
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[105] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[4] <= 21.5) {
                                if (fs[47] <= -1476.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.134197716209;
                                    } else {
                                        return 0.239316625058;
                                    }
                                } else {
                                    if (fs[53] <= -1108.5) {
                                        return 0.0640646481457;
                                    } else {
                                        return -0.0259354070308;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return -0.0433621462819;
                                    } else {
                                        return -0.398222867914;
                                    }
                                } else {
                                    if (fs[53] <= -1468.0) {
                                        return -0.100735437883;
                                    } else {
                                        return 0.0796943256333;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= -0.5) {
                                if (fs[4] <= 15.5) {
                                    return -0.33886256833;
                                } else {
                                    return 0.0062720681379;
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[47] <= -15.5) {
                                        return 0.120608840557;
                                    } else {
                                        return 0.0701209771256;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.15277772271;
                                    } else {
                                        return -0.237781583771;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 5.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[47] <= -7.5) {
                                    if (fs[101] <= 0.5) {
                                        return 0.190624561482;
                                    } else {
                                        return 0.0709975208539;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0382688457666;
                                    } else {
                                        return 0.104943412551;
                                    }
                                }
                            } else {
                                return 0.306497509235;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[47] <= -6.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.0421125278526;
                                    } else {
                                        return 0.108252466339;
                                    }
                                } else {
                                    if (fs[92] <= 0.5) {
                                        return 0.27993489914;
                                    } else {
                                        return -0.0535116375639;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.115169434675;
                                    } else {
                                        return 0.0022661909379;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.161405221021;
                                    } else {
                                        return 0.0145218269879;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[92] <= 0.5) {
                        if (fs[88] <= 6.5) {
                            return 0.341412186885;
                        } else {
                            return 0.0658737254415;
                        }
                    } else {
                        if (fs[32] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.122364740233;
                                    } else {
                                        return 0.0808360421014;
                                    }
                                } else {
                                    return -0.178584974118;
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.0526929250373;
                                    } else {
                                        return 0.168823285528;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.099466279818;
                                    } else {
                                        return -0.176442993397;
                                    }
                                }
                            }
                        } else {
                            return 0.379421468404;
                        }
                    }
                }
            } else {
                if (fs[53] <= -1082.5) {
                    if (fs[53] <= -1138.0) {
                        if (fs[55] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[53] <= -2428.0) {
                                    return 0.500194849149;
                                } else {
                                    if (fs[18] <= -0.5) {
                                        return -0.223967847692;
                                    } else {
                                        return 0.0393565790546;
                                    }
                                }
                            } else {
                                if (fs[47] <= -8.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.176724242529;
                                    } else {
                                        return 0.0152197420157;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0572187208912;
                                    } else {
                                        return 0.00500312650396;
                                    }
                                }
                            }
                        } else {
                            return 0.300561829925;
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[53] <= -1117.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0261706769793;
                                    } else {
                                        return 0.147304014274;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.398100023951;
                                    } else {
                                        return 0.0231695914659;
                                    }
                                }
                            } else {
                                return 0.508134425999;
                            }
                        } else {
                            if (fs[53] <= -1128.0) {
                                return 0.270927254791;
                            } else {
                                return 0.494212126248;
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 75.0) {
                        if (fs[47] <= -1.5) {
                            if (fs[47] <= -22.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[24] <= 0.5) {
                                        return -0.0373694547236;
                                    } else {
                                        return 0.109130250401;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.217380452025;
                                    } else {
                                        return -0.0928349228503;
                                    }
                                }
                            } else {
                                if (fs[2] <= 5.5) {
                                    if (fs[24] <= 0.5) {
                                        return 0.0321522642726;
                                    } else {
                                        return 0.218021473106;
                                    }
                                } else {
                                    return 0.484905474531;
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0444220062231;
                                    } else {
                                        return 0.0474951272794;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.00959777267702;
                                    } else {
                                        return 0.247260799308;
                                    }
                                }
                            } else {
                                if (fs[2] <= 7.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0184161762643;
                                    } else {
                                        return -0.0281139306037;
                                    }
                                } else {
                                    return 0.205571296061;
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[103] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.0801612044293;
                                    } else {
                                        return -0.109733804997;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0306928839079;
                                    } else {
                                        return -0.00723873758662;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 6.5) {
                                        return -0.0394689282257;
                                    } else {
                                        return -0.0328012848266;
                                    }
                                } else {
                                    if (fs[53] <= -966.0) {
                                        return -0.01771901285;
                                    } else {
                                        return -0.0074698311467;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.028612868578;
                                    } else {
                                        return -0.00715549318402;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0740101200348;
                                    } else {
                                        return -0.039340868446;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    return 0.256932444352;
                                } else {
                                    return 0.0513160133824;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
