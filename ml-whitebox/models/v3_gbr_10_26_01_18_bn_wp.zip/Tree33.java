/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree33 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[53] <= -987.5) {
                if (fs[41] <= 0.5) {
                    if (fs[105] <= 0.5) {
                        if (fs[74] <= 0.5) {
                            if (fs[4] <= 18.5) {
                                if (fs[53] <= -1498.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.110221416243;
                                    } else {
                                        return 0.250400540657;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return 0.153546424914;
                                    } else {
                                        return 0.233287729579;
                                    }
                                }
                            } else {
                                if (fs[2] <= 10.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.10151945082;
                                    } else {
                                        return 0.0450433526329;
                                    }
                                } else {
                                    if (fs[47] <= -6.0) {
                                        return -0.119719791978;
                                    } else {
                                        return 0.27962879483;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[53] <= -1143.5) {
                                    if (fs[53] <= -1294.0) {
                                        return -0.0451068903044;
                                    } else {
                                        return -0.22324511885;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.000298703356349;
                                    } else {
                                        return 0.142371238553;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[72] <= 9902.0) {
                                        return -0.221054017755;
                                    } else {
                                        return 0.210261186944;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.211445395417;
                                    } else {
                                        return 0.191212062826;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9988.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0882927919634;
                                    } else {
                                        return -0.0711881995032;
                                    }
                                } else {
                                    if (fs[4] <= 23.5) {
                                        return 0.186426502702;
                                    } else {
                                        return -0.398499588319;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1133.5) {
                                    if (fs[88] <= 3.5) {
                                        return 0.0514141166966;
                                    } else {
                                        return 0.18968289401;
                                    }
                                } else {
                                    if (fs[53] <= -1088.5) {
                                        return 0.307565063281;
                                    } else {
                                        return -0.0238153774143;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[88] <= 5.5) {
                                    if (fs[88] <= -0.5) {
                                        return -0.171741351205;
                                    } else {
                                        return 0.184085166689;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.220748007801;
                                    } else {
                                        return -0.0863839302296;
                                    }
                                }
                            } else {
                                if (fs[28] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.244076522119;
                                    } else {
                                        return 0.193702027454;
                                    }
                                } else {
                                    return -0.0991868045594;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[60] <= 0.5) {
                        if (fs[88] <= 6.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.210944422393;
                                    } else {
                                        return 0.109384961116;
                                    }
                                } else {
                                    return -0.226995762764;
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0196395918589;
                                    } else {
                                        return 0.223491460287;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.00458627480117;
                                    } else {
                                        return -0.245790039494;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                return 0.289554637773;
                            } else {
                                return 0.199192340933;
                            }
                        }
                    } else {
                        if (fs[51] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.159739813777;
                                    } else {
                                        return -0.119412584554;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0141729149125;
                                    } else {
                                        return 0.0870900414806;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[47] <= -31.5) {
                                        return 0.0801602489956;
                                    } else {
                                        return -0.0220222950894;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.1684394452;
                                    } else {
                                        return 0.0595187731519;
                                    }
                                }
                            }
                        } else {
                            return 0.371161238272;
                        }
                    }
                }
            } else {
                if (fs[22] <= 0.5) {
                    if (fs[4] <= 5.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[15] <= 0.5) {
                                if (fs[103] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0681656842332;
                                    } else {
                                        return 0.146525941121;
                                    }
                                } else {
                                    return -0.270833839126;
                                }
                            } else {
                                return -0.411679480023;
                            }
                        } else {
                            if (fs[47] <= -2784.0) {
                                return -0.329081873783;
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.212212585301;
                                    } else {
                                        return 0.0918537132398;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0699162974558;
                                    } else {
                                        return -0.179970927542;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= -0.5) {
                            if (fs[62] <= -1.5) {
                                if (fs[47] <= -33.0) {
                                    if (fs[4] <= 9.5) {
                                        return 0.368550087188;
                                    } else {
                                        return 0.382709420891;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.322617489615;
                                    } else {
                                        return 0.225094353165;
                                    }
                                }
                            } else {
                                if (fs[64] <= -996.5) {
                                    if (fs[88] <= 5.5) {
                                        return 0.187760263837;
                                    } else {
                                        return 0.0679811796426;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.173680669847;
                                    } else {
                                        return 0.143926541611;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[47] <= -13.5) {
                                    if (fs[76] <= 150.0) {
                                        return 0.146907367063;
                                    } else {
                                        return -0.0913511031424;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.101566047916;
                                    } else {
                                        return 0.0226854404203;
                                    }
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.177230587491;
                                    } else {
                                        return 0.251295070149;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.322074578557;
                                    } else {
                                        return -0.00844932436076;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 6.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[72] <= 9986.0) {
                                if (fs[53] <= -431.5) {
                                    if (fs[53] <= -968.5) {
                                        return -0.0533839797971;
                                    } else {
                                        return -0.303456928601;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.233834165867;
                                    } else {
                                        return -0.0451328763137;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    return 0.326798843254;
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.1473944332;
                                    } else {
                                        return 0.245615853255;
                                    }
                                }
                            }
                        } else {
                            if (fs[90] <= 0.5) {
                                if (fs[72] <= 4273.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.134586125099;
                                    } else {
                                        return -0.00181361132735;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.0938268602854;
                                    } else {
                                        return -0.228358632508;
                                    }
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.184379743458;
                                    } else {
                                        return -0.167765130564;
                                    }
                                } else {
                                    return 0.244379057197;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            return 0.245733931909;
                        } else {
                            return 0.419850830692;
                        }
                    }
                }
            }
        } else {
            if (fs[72] <= 9868.5) {
                if (fs[81] <= 0.5) {
                    if (fs[4] <= 2.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[78] <= 0.5) {
                                return 0.0556282425242;
                            } else {
                                return 0.295773426771;
                            }
                        } else {
                            return -0.0214442654922;
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[53] <= -1053.0) {
                                    if (fs[63] <= 0.5) {
                                        return 0.193280522267;
                                    } else {
                                        return -0.0320992898759;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0637521655715;
                                    } else {
                                        return -0.0825256806726;
                                    }
                                }
                            } else {
                                if (fs[30] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0145250203626;
                                    } else {
                                        return 0.0219436858992;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.281701642218;
                                    } else {
                                        return 0.43855153462;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0555964899721;
                                    } else {
                                        return -0.0614945666485;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.0336302335467;
                                    } else {
                                        return -0.0378290856832;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0266294919345;
                                    } else {
                                        return 3.22968123365e-05;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.00226917212374;
                                    } else {
                                        return -0.0149098294894;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[76] <= 25.0) {
                            if (fs[85] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0280008317131;
                                    } else {
                                        return -0.0311174568737;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.00994873564698;
                                    } else {
                                        return 0.0681496025161;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0084361032149;
                                    } else {
                                        return 0.215808490555;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.0291469110884;
                                    } else {
                                        return 0.125128208736;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0335894710755;
                                    } else {
                                        return 0.00174052000011;
                                    }
                                } else {
                                    if (fs[49] <= -2.5) {
                                        return 0.0599931475772;
                                    } else {
                                        return -0.0214573881321;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.125846076769;
                                    } else {
                                        return 0.328407324809;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.104304679308;
                                    } else {
                                        return 0.0202194184426;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0105545382184;
                                    } else {
                                        return -0.00670816284564;
                                    }
                                } else {
                                    if (fs[53] <= -1438.0) {
                                        return 0.0337170497527;
                                    } else {
                                        return -0.00125565456907;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[4] <= 13.5) {
                                        return -0.0181609631342;
                                    } else {
                                        return -0.0152661596785;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.0136686143945;
                                    } else {
                                        return -0.0121803709679;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= 3.5) {
                                if (fs[53] <= -461.0) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0166203644876;
                                    } else {
                                        return 0.12933802241;
                                    }
                                } else {
                                    if (fs[88] <= 4.0) {
                                        return 0.0601198678122;
                                    } else {
                                        return 0.53689954335;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    return -0.0177006650801;
                                } else {
                                    if (fs[47] <= -7.5) {
                                        return -0.0180402899574;
                                    } else {
                                        return -0.013927894606;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 2.5) {
                    if (fs[45] <= 0.5) {
                        if (fs[53] <= -1408.0) {
                            if (fs[53] <= -1458.0) {
                                if (fs[0] <= 1.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0543142513282;
                                    } else {
                                        return 0.283342585266;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.00587440008865;
                                    } else {
                                        return 0.0726122464538;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9998.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.0884562832678;
                                    } else {
                                        return 0.232862647329;
                                    }
                                } else {
                                    return 0.289777049914;
                                }
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.0333938044813;
                                    } else {
                                        return -0.000962191068432;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0335613045769;
                                    } else {
                                        return 0.263066214636;
                                    }
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.039719140436;
                                    } else {
                                        return 0.187594002474;
                                    }
                                } else {
                                    if (fs[0] <= 16.5) {
                                        return 0.0239894748835;
                                    } else {
                                        return -0.00659943158338;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[106] <= 0.5) {
                            if (fs[63] <= 0.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[70] <= -3.5) {
                                        return -0.0386964010349;
                                    } else {
                                        return -0.0171432584009;
                                    }
                                } else {
                                    return -0.0809046982722;
                                }
                            } else {
                                return 0.0309524738677;
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0824840389372;
                                    } else {
                                        return -0.046259239657;
                                    }
                                } else {
                                    return -0.0737314800135;
                                }
                            } else {
                                return -0.0482839538501;
                            }
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[88] <= 6.5) {
                            if (fs[2] <= 6.5) {
                                if (fs[47] <= -5.5) {
                                    if (fs[47] <= -456.0) {
                                        return 0.153523134218;
                                    } else {
                                        return 0.0613106706767;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0133561746564;
                                    } else {
                                        return 0.117358715159;
                                    }
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.122382891781;
                                    } else {
                                        return 0.300882877961;
                                    }
                                } else {
                                    return -0.146348860464;
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.249208550158;
                                    } else {
                                        return 0.420223852891;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.25833757882;
                                    } else {
                                        return -0.0175882931357;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9983.5) {
                                    if (fs[47] <= -1.5) {
                                        return -0.0796545905686;
                                    } else {
                                        return -0.114631143048;
                                    }
                                } else {
                                    if (fs[72] <= 9986.5) {
                                        return 0.402031586033;
                                    } else {
                                        return 0.0756054781159;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9997.5) {
                            if (fs[47] <= -282.0) {
                                return 0.0752334302455;
                            } else {
                                if (fs[98] <= 0.5) {
                                    if (fs[53] <= -1067.0) {
                                        return -0.00788693145086;
                                    } else {
                                        return -0.0310753831631;
                                    }
                                } else {
                                    return -0.0869554950211;
                                }
                            }
                        } else {
                            if (fs[53] <= -7.0) {
                                if (fs[47] <= -32.0) {
                                    if (fs[47] <= -59.0) {
                                        return -0.0335485815558;
                                    } else {
                                        return 0.179254887394;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0437664338013;
                                    } else {
                                        return -0.0170807161511;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.277659386086;
                                    } else {
                                        return 0.0021797941533;
                                    }
                                } else {
                                    return -0.0275231473338;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
