/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree71 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[2] <= 3.5) {
                    if (fs[53] <= -1498.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[48] <= 0.5) {
                                    return -0.35864819998;
                                } else {
                                    if (fs[4] <= 2.5) {
                                        return -0.0448605383188;
                                    } else {
                                        return -0.0862093507673;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0265081272299;
                                    } else {
                                        return 0.191352972465;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return -0.0204470450769;
                                    } else {
                                        return 0.107773281743;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                if (fs[49] <= -1.5) {
                                    return -0.0253413991656;
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.062716257652;
                                    } else {
                                        return -0.292299122752;
                                    }
                                }
                            } else {
                                if (fs[29] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0845357578508;
                                    } else {
                                        return 0.115201586783;
                                    }
                                } else {
                                    return 0.26238887718;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[91] <= 0.5) {
                                        return 0.0205444730831;
                                    } else {
                                        return 0.0795668820204;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.0456041037018;
                                    } else {
                                        return -0.0076572639553;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9939.5) {
                                    if (fs[70] <= -4.0) {
                                        return 0.178575693818;
                                    } else {
                                        return 0.253006241781;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0731103251175;
                                    } else {
                                        return 0.148068719344;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.127962860477;
                                    } else {
                                        return 0.191845803447;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0542160400453;
                                    } else {
                                        return -0.0217832455176;
                                    }
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0219856584098;
                                    } else {
                                        return 0.0129466038935;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.123246814045;
                                    } else {
                                        return 0.210682361362;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[28] <= 0.5) {
                        if (fs[70] <= -3.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[53] <= -1283.0) {
                                        return 0.161343851136;
                                    } else {
                                        return 0.0956254750915;
                                    }
                                } else {
                                    return -0.108736042734;
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[47] <= -4.5) {
                                        return -0.373621224956;
                                    } else {
                                        return 0.0036904024601;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.175082054925;
                                    } else {
                                        return 0.28137249548;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 8.5) {
                                if (fs[8] <= 0.5) {
                                    if (fs[51] <= 0.5) {
                                        return 0.033696348845;
                                    } else {
                                        return 0.25231000142;
                                    }
                                } else {
                                    if (fs[72] <= 4998.5) {
                                        return -0.285083507755;
                                    } else {
                                        return -0.0182445253507;
                                    }
                                }
                            } else {
                                if (fs[8] <= 0.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.0462881972919;
                                    } else {
                                        return 0.12194449215;
                                    }
                                } else {
                                    return -0.113556251463;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 5.5) {
                            if (fs[88] <= 1.0) {
                                return 0.00947917598175;
                            } else {
                                return -0.270115127414;
                            }
                        } else {
                            return -0.201846546501;
                        }
                    }
                }
            } else {
                if (fs[53] <= -2008.0) {
                    if (fs[47] <= -5.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[72] <= 9998.0) {
                                return 0.236212144909;
                            } else {
                                return 0.10630015545;
                            }
                        } else {
                            if (fs[4] <= 34.0) {
                                return 0.133931299603;
                            } else {
                                return 0.0600349158901;
                            }
                        }
                    } else {
                        if (fs[105] <= 0.5) {
                            if (fs[76] <= 350.0) {
                                if (fs[4] <= 52.0) {
                                    if (fs[4] <= 19.5) {
                                        return -0.0785526428666;
                                    } else {
                                        return 0.128263219283;
                                    }
                                } else {
                                    return -0.226958318289;
                                }
                            } else {
                                return -0.142222058044;
                            }
                        } else {
                            return -0.269678303369;
                        }
                    }
                } else {
                    if (fs[4] <= 27.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[2] <= 12.5) {
                                if (fs[53] <= -1978.0) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0676402296048;
                                    } else {
                                        return -0.40332282719;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0345590753201;
                                    } else {
                                        return 0.0151582053;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1678.0) {
                                    return 0.314811712909;
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.133380978321;
                                    } else {
                                        return 0.0283600350518;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1463.0) {
                                if (fs[101] <= 1.5) {
                                    if (fs[4] <= 21.5) {
                                        return 0.0599732443682;
                                    } else {
                                        return -0.41821450181;
                                    }
                                } else {
                                    return -0.145973017141;
                                }
                            } else {
                                return 0.349995126954;
                            }
                        }
                    } else {
                        if (fs[86] <= 0.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[4] <= 28.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.260921560667;
                                    } else {
                                        return -0.00990364478014;
                                    }
                                } else {
                                    if (fs[47] <= -3.5) {
                                        return 0.0507949731802;
                                    } else {
                                        return -0.0952623816218;
                                    }
                                }
                            } else {
                                return 0.244128205959;
                            }
                        } else {
                            if (fs[72] <= 9976.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0215195928717;
                                    } else {
                                        return 0.207886631326;
                                    }
                                } else {
                                    return -0.129184249664;
                                }
                            } else {
                                if (fs[53] <= -1123.0) {
                                    return 0.0937914554764;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.219861411055;
                                    } else {
                                        return 0.379526015486;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[2] <= 6.5) {
                if (fs[62] <= -1.5) {
                    if (fs[53] <= -1093.0) {
                        if (fs[64] <= -996.5) {
                            if (fs[76] <= 100.0) {
                                if (fs[12] <= 0.5) {
                                    return 0.610534282029;
                                } else {
                                    return 0.100038271429;
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0651895085771;
                                    } else {
                                        return -0.148837148782;
                                    }
                                } else {
                                    if (fs[64] <= -997.5) {
                                        return 0.304672696799;
                                    } else {
                                        return 0.0866191792994;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[103] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0181351268986;
                                    } else {
                                        return -0.0951344050152;
                                    }
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return 0.123598372777;
                                    } else {
                                        return 0.267466185021;
                                    }
                                }
                            } else {
                                if (fs[4] <= 26.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0844405948319;
                                    } else {
                                        return 0.0347967567009;
                                    }
                                } else {
                                    return 0.178077344345;
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -11.5) {
                            if (fs[18] <= 0.5) {
                                return -0.0395942939996;
                            } else {
                                return 0.351383216345;
                            }
                        } else {
                            if (fs[62] <= -2.5) {
                                if (fs[90] <= 0.5) {
                                    return 0.152423706196;
                                } else {
                                    if (fs[76] <= 100.0) {
                                        return 0.0876720950939;
                                    } else {
                                        return 0.000590011831797;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[47] <= -5.5) {
                                        return -0.0866540389409;
                                    } else {
                                        return -0.0158606131889;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.00227251126676;
                                    } else {
                                        return -0.069932831185;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[51] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[53] <= -1478.5) {
                                        return 0.0456190587047;
                                    } else {
                                        return 0.0138318915595;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.0173140447574;
                                    } else {
                                        return 0.0626658370018;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0166137020559;
                                    } else {
                                        return 0.00274496581181;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.0104447865141;
                                    } else {
                                        return 0.0745167900975;
                                    }
                                }
                            }
                        } else {
                            if (fs[101] <= 0.5) {
                                if (fs[53] <= -1118.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.207685797631;
                                    } else {
                                        return -0.0141362240275;
                                    }
                                } else {
                                    if (fs[88] <= 2.0) {
                                        return 0.0967521186222;
                                    } else {
                                        return -0.0238563382027;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.0629329550249;
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return -0.0989654271558;
                                    } else {
                                        return -0.0555786914184;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[30] <= 0.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[88] <= 3.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.0312169538953;
                                    } else {
                                        return -0.00290642318893;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.026468498373;
                                    } else {
                                        return -0.0131038944164;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.00270521545177;
                                    } else {
                                        return 0.000333644997138;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.00156809290853;
                                    } else {
                                        return 0.00425807014606;
                                    }
                                }
                            }
                        } else {
                            return 0.252318278577;
                        }
                    }
                }
            } else {
                if (fs[0] <= 3.5) {
                    if (fs[62] <= -0.5) {
                        if (fs[4] <= 19.5) {
                            if (fs[99] <= 0.5) {
                                return 0.151812091797;
                            } else {
                                if (fs[4] <= 14.5) {
                                    return -0.108966593168;
                                } else {
                                    return -0.0377867060423;
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.175379536505;
                                    } else {
                                        return -0.14096073039;
                                    }
                                } else {
                                    return -0.0924269971018;
                                }
                            } else {
                                return -0.0584829004324;
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[47] <= -1.5) {
                                if (fs[53] <= -1488.0) {
                                    if (fs[47] <= -45.5) {
                                        return 0.088931504946;
                                    } else {
                                        return -0.0584861753977;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.00112179368739;
                                    } else {
                                        return 0.0867471240619;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.0541235709459;
                                    } else {
                                        return -0.019992474188;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.00269657022707;
                                    } else {
                                        return 0.0278059382884;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[47] <= -20.0) {
                                        return -0.0828074232195;
                                    } else {
                                        return 0.0935487671662;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0119203610463;
                                    } else {
                                        return 0.454715072756;
                                    }
                                }
                            } else {
                                if (fs[4] <= 25.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0151931835087;
                                    } else {
                                        return 0.0668902643703;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0261338866579;
                                    } else {
                                        return 0.0633342394734;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -542.5) {
                        if (fs[23] <= 0.5) {
                            return 0.5341311399;
                        } else {
                            return -0.0252652507591;
                        }
                    } else {
                        if (fs[88] <= 3.5) {
                            if (fs[103] <= 1.5) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[72] <= 9948.5) {
                                        return -0.000683201944166;
                                    } else {
                                        return 0.0293789486881;
                                    }
                                } else {
                                    if (fs[0] <= 22.0) {
                                        return -0.0155046942688;
                                    } else {
                                        return -0.145778688843;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1087.5) {
                                    return 0.132498456339;
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return -0.0214333674546;
                                    } else {
                                        return -0.00788496835183;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    return 0.51606696127;
                                } else {
                                    if (fs[47] <= -28.0) {
                                        return 0.249796544051;
                                    } else {
                                        return 0.00627199312652;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.00471448666685;
                                    } else {
                                        return -0.0104386446247;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0110576332526;
                                    } else {
                                        return 0.358987099714;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
