/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree57 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[33] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[27] <= 0.5) {
                                if (fs[72] <= 5000.0) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0640898215671;
                                    } else {
                                        return 0.0484909643995;
                                    }
                                } else {
                                    return 0.110722438792;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[72] <= 5000.0) {
                                        return 0.184719524814;
                                    } else {
                                        return 0.141778894552;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.192729825114;
                                    } else {
                                        return 0.0838929776899;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                return -0.0657002757298;
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 5.0) {
                                        return 0.229943906995;
                                    } else {
                                        return 0.119836867125;
                                    }
                                } else {
                                    return 0.272000502825;
                                }
                            }
                        }
                    } else {
                        if (fs[60] <= 0.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.101807603145;
                                    } else {
                                        return 0.0503498586891;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0437626832915;
                                    } else {
                                        return 0.0630262508013;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1053.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.110556902399;
                                    } else {
                                        return 0.55100236148;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.104600884246;
                                    } else {
                                        return -0.0363056245396;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0254612609166;
                                    } else {
                                        return 0.0931914933506;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.0189967346749;
                                    } else {
                                        return 0.0688942711814;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.201567231674;
                                    } else {
                                        return 0.1028414355;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.012872823763;
                                    } else {
                                        return -0.0058665405695;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[71] <= 0.5) {
                            return 0.0672524600965;
                        } else {
                            if (fs[0] <= 0.5) {
                                return -0.272864675133;
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0568591892309;
                                    } else {
                                        return -0.0956566788774;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0678065211072;
                                    } else {
                                        return -0.0420967189111;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -963.0) {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.01597025914;
                                    } else {
                                        return -0.00598776675125;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0132844147458;
                                    } else {
                                        return -0.000605763966871;
                                    }
                                }
                            } else {
                                return -0.0181061857409;
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 25.5) {
                                        return -0.00706305653648;
                                    } else {
                                        return -0.00220378775415;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.00225807782778;
                                    } else {
                                        return -0.00135521244988;
                                    }
                                }
                            } else {
                                return -0.0326648804424;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 19.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[59] <= 0.5) {
                                    return 0.148560728096;
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.177031547739;
                                    } else {
                                        return 0.106747316468;
                                    }
                                }
                            } else {
                                if (fs[4] <= 9.5) {
                                    if (fs[72] <= 9997.5) {
                                        return 0.0543168544899;
                                    } else {
                                        return 0.0950127549574;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return 0.0874437906643;
                                    } else {
                                        return 0.126286391132;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[2] <= 1.5) {
                                    return -0.121472588075;
                                } else {
                                    return -0.0821963592408;
                                }
                            } else {
                                return 0.0811105679703;
                            }
                        }
                    } else {
                        if (fs[71] <= 0.5) {
                            if (fs[4] <= 29.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 25.5) {
                                        return -0.0223551249249;
                                    } else {
                                        return -0.180550392582;
                                    }
                                } else {
                                    return -0.212560938061;
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[53] <= -1328.0) {
                                        return -0.0744774363852;
                                    } else {
                                        return 0.204883096725;
                                    }
                                } else {
                                    return 0.0937896754143;
                                }
                            }
                        } else {
                            return -0.24350335965;
                        }
                    }
                } else {
                    if (fs[76] <= 100.0) {
                        if (fs[70] <= -1.5) {
                            if (fs[53] <= -1128.0) {
                                if (fs[71] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0297171437145;
                                    } else {
                                        return 0.0114921941118;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0129050999962;
                                    } else {
                                        return -0.0451243881059;
                                    }
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.00203382085176;
                                    } else {
                                        return -0.034198726107;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.00760641298723;
                                    } else {
                                        return 0.0473676533663;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                return 0.0985176575855;
                            } else {
                                if (fs[0] <= 2.5) {
                                    return -0.033651979958;
                                } else {
                                    return -0.0174878488031;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 2.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[53] <= -1578.0) {
                                        return 0.0163760777422;
                                    } else {
                                        return -0.00782179937399;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.000690134300127;
                                    } else {
                                        return -0.000287487207389;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[72] <= 4847.0) {
                                        return 0.0552878891665;
                                    } else {
                                        return 0.0765970560622;
                                    }
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return -0.00785557200954;
                                    } else {
                                        return -0.0227675021121;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1578.0) {
                                if (fs[4] <= 34.5) {
                                    if (fs[4] <= 23.5) {
                                        return -0.0410613497996;
                                    } else {
                                        return -0.0242154124762;
                                    }
                                } else {
                                    return 0.185882156996;
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0453399527767;
                                    } else {
                                        return -0.0211749363389;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.0116482043502;
                                    } else {
                                        return -0.00402345814774;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[103] <= 1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[57] <= 0.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0355087164601;
                                    } else {
                                        return 0.0913736045344;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.0177511206891;
                                    } else {
                                        return -0.118094340953;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.00637032877959;
                                    } else {
                                        return 0.0590120326337;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.0185892684541;
                                    } else {
                                        return 0.154066233099;
                                    }
                                }
                            }
                        } else {
                            if (fs[32] <= 0.5) {
                                if (fs[2] <= 10.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.0646416235671;
                                    } else {
                                        return 0.0389648780365;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.163449141913;
                                    } else {
                                        return -0.101978489213;
                                    }
                                }
                            } else {
                                return -0.332794463342;
                            }
                        }
                    } else {
                        if (fs[64] <= -997.5) {
                            if (fs[101] <= 1.5) {
                                return -0.0262187411745;
                            } else {
                                if (fs[18] <= 0.5) {
                                    return 0.0362154941697;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.232059587941;
                                    } else {
                                        return 0.212290619949;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    return 0.185457702703;
                                } else {
                                    return -0.242197107455;
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.266476281952;
                                    } else {
                                        return 0.213535567739;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.149587344681;
                                    } else {
                                        return 0.254796571624;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9886.5) {
                        if (fs[0] <= 3.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[27] <= 0.5) {
                                        return 0.00223191194706;
                                    } else {
                                        return -0.0200114845878;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.0658377133168;
                                    } else {
                                        return 0.0119049261743;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.00602854064575;
                                    } else {
                                        return 0.0118421250065;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.00196939245613;
                                    } else {
                                        return 0.0195700170424;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -7508.5) {
                                if (fs[53] <= -1468.0) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.05581190911;
                                    } else {
                                        return 0.471609987378;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0175690150753;
                                    } else {
                                        return -0.0509696431941;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[49] <= -2.5) {
                                        return 0.165627342282;
                                    } else {
                                        return -0.00287857564882;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.00367257694095;
                                    } else {
                                        return -0.00517530035771;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[24] <= 0.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[0] <= 8.5) {
                                        return 0.0368642634737;
                                    } else {
                                        return -0.0108528847131;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.00832665744381;
                                    } else {
                                        return -0.00689923506651;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.196455218857;
                                    } else {
                                        return 0.0520119745668;
                                    }
                                } else {
                                    if (fs[47] <= -1176.5) {
                                        return 0.199984899099;
                                    } else {
                                        return 0.0125760963432;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1428.0) {
                                if (fs[60] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.00187184455006;
                                    } else {
                                        return 0.188297617545;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.110419931733;
                                    } else {
                                        return -0.33726022919;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0380508312995;
                                    } else {
                                        return 0.224089912096;
                                    }
                                } else {
                                    if (fs[72] <= 9983.5) {
                                        return -0.0208449197246;
                                    } else {
                                        return 0.0142707712842;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[97] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[53] <= -1128.5) {
                                        return 0.155256375196;
                                    } else {
                                        return 0.202505648527;
                                    }
                                } else {
                                    return 0.231078996002;
                                }
                            } else {
                                if (fs[53] <= -1318.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.208894614555;
                                    } else {
                                        return 0.122873502654;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0571036608939;
                                    } else {
                                        return 0.0283023322966;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[27] <= 0.5) {
                                    return -0.0741933746611;
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.114729353671;
                                    } else {
                                        return -0.235163746667;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    return 0.0173811530705;
                                } else {
                                    return -0.282651209926;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -970.5) {
                            if (fs[53] <= -1138.0) {
                                if (fs[4] <= 9.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.061532543844;
                                    } else {
                                        return -0.330417517908;
                                    }
                                } else {
                                    return 0.0478511173234;
                                }
                            } else {
                                if (fs[53] <= -1063.5) {
                                    return -0.244573288387;
                                } else {
                                    return -0.171285200793;
                                }
                            }
                        } else {
                            return 0.110384722133;
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[6] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                return 0.386960971135;
                            } else {
                                return -0.0107530034123;
                            }
                        } else {
                            if (fs[27] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 31.5) {
                                        return 0.0255452710368;
                                    } else {
                                        return 0.282825175703;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.00810246366904;
                                    } else {
                                        return -0.00269838481891;
                                    }
                                }
                            } else {
                                if (fs[0] <= 45.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0244643291948;
                                    } else {
                                        return 0.0853271728611;
                                    }
                                } else {
                                    return 0.28971612478;
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return -0.0493412739953;
                                    } else {
                                        return 0.185106348993;
                                    }
                                } else {
                                    return -0.112579669191;
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0129032392565;
                                    } else {
                                        return 0.130429885663;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0129952801426;
                                    } else {
                                        return -0.0352765260382;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -2.5) {
                                if (fs[11] <= 0.5) {
                                    return -0.0471682260295;
                                } else {
                                    return 0.177219255008;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[63] <= 0.5) {
                                        return -0.00834044395224;
                                    } else {
                                        return -0.017651825193;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.00633751637635;
                                    } else {
                                        return -0.00300673525936;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
