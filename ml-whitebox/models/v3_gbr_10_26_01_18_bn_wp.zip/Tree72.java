/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree72 {
    public double calcTree(double... fs) {
        if (fs[57] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[103] <= 1.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[53] <= -1138.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0579884967415;
                                    } else {
                                        return -0.0964425459168;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0329655448116;
                                    } else {
                                        return -0.01582723281;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[53] <= -1053.5) {
                                        return 0.0409275277038;
                                    } else {
                                        return -0.0595370153694;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.104309511531;
                                    } else {
                                        return 0.0281696885163;
                                    }
                                }
                            }
                        } else {
                            if (fs[92] <= 0.5) {
                                if (fs[74] <= 0.5) {
                                    if (fs[47] <= -233.0) {
                                        return -0.271769184858;
                                    } else {
                                        return 0.0637106482032;
                                    }
                                } else {
                                    if (fs[53] <= -1128.5) {
                                        return -0.0643757909107;
                                    } else {
                                        return 0.092709445397;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1503.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.0957260569703;
                                    } else {
                                        return 0.0282201121028;
                                    }
                                } else {
                                    if (fs[47] <= -6.5) {
                                        return 0.0282130658553;
                                    } else {
                                        return -0.0292299612022;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[49] <= -0.5) {
                                    if (fs[27] <= 0.5) {
                                        return 0.0784967631108;
                                    } else {
                                        return 0.0533002966379;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0376049798895;
                                    } else {
                                        return -0.0585672771663;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[53] <= -1128.5) {
                                        return 0.107294952158;
                                    } else {
                                        return 0.191466018445;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.00652176062154;
                                    } else {
                                        return 0.156789136286;
                                    }
                                }
                            }
                        } else {
                            if (fs[58] <= 0.5) {
                                return -0.211814771588;
                            } else {
                                return -0.0628362599736;
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 6.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[53] <= -987.0) {
                                if (fs[18] <= -0.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.311684655783;
                                    } else {
                                        return -0.0885146009922;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.030152941419;
                                    } else {
                                        return -0.0190843863352;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.0311293163944;
                                    } else {
                                        return 0.102209819865;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return -0.0236362563065;
                                    } else {
                                        return 0.0419887813311;
                                    }
                                }
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[47] <= -3.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.130479135551;
                                    } else {
                                        return 0.0431593053643;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.000168055190053;
                                    } else {
                                        return 0.0554426202507;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.114172379238;
                                    } else {
                                        return -0.0133999854256;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.321570070334;
                                    } else {
                                        return -0.0678632728802;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 24.0) {
                            if (fs[71] <= 0.5) {
                                if (fs[53] <= -1473.5) {
                                    if (fs[4] <= 10.5) {
                                        return 0.0627526464286;
                                    } else {
                                        return -0.0467958913551;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return 0.0923031118532;
                                    } else {
                                        return 0.370687803129;
                                    }
                                }
                            } else {
                                if (fs[88] <= 7.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.058429421428;
                                    } else {
                                        return -0.172059158537;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0351751323172;
                                    } else {
                                        return -0.0581611829848;
                                    }
                                }
                            }
                        } else {
                            return -0.364714302565;
                        }
                    }
                }
            } else {
                if (fs[72] <= 9999.5) {
                    if (fs[53] <= -4488.0) {
                        return 0.219079647866;
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[103] <= 1.5) {
                                        return -0.00516363291342;
                                    } else {
                                        return 0.0232404256617;
                                    }
                                } else {
                                    if (fs[47] <= -8.5) {
                                        return 0.0312128169813;
                                    } else {
                                        return 0.00661251497642;
                                    }
                                }
                            } else {
                                if (fs[2] <= 11.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00708161507825;
                                    } else {
                                        return -0.0165058179459;
                                    }
                                } else {
                                    return 0.137132749745;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[88] <= -0.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.00455738702488;
                                    } else {
                                        return -0.00178519853688;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return -0.0016526712461;
                                    } else {
                                        return 0.00893784151561;
                                    }
                                }
                            } else {
                                if (fs[47] <= -4651.5) {
                                    if (fs[47] <= -14256.0) {
                                        return -0.0102357687891;
                                    } else {
                                        return 0.295794451741;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.00183352449046;
                                    } else {
                                        return -0.00148300980668;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[8] <= 0.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[76] <= 250.0) {
                                if (fs[53] <= -1128.0) {
                                    if (fs[0] <= 16.5) {
                                        return 0.0782192522026;
                                    } else {
                                        return -0.047563673155;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return -0.0597403712002;
                                    } else {
                                        return 0.00517806352108;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[0] <= 58.0) {
                                        return -0.00361297262415;
                                    } else {
                                        return 0.210941343874;
                                    }
                                } else {
                                    return 0.218690138565;
                                }
                            }
                        } else {
                            if (fs[53] <= -1478.0) {
                                if (fs[101] <= 1.5) {
                                    return -0.292782566137;
                                } else {
                                    return -0.244055520777;
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    return 0.189069116814;
                                } else {
                                    return -0.10891562381;
                                }
                            }
                        }
                    } else {
                        return -0.194507283186;
                    }
                }
            }
        } else {
            if (fs[6] <= 0.5) {
                return -0.190236029443;
            } else {
                if (fs[2] <= 1.5) {
                    if (fs[76] <= 250.0) {
                        if (fs[18] <= 0.5) {
                            if (fs[88] <= 0.5) {
                                if (fs[101] <= 1.5) {
                                    return -0.00632071491919;
                                } else {
                                    return 0.0352161883043;
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    return -0.0219522791503;
                                } else {
                                    return -0.0626659239803;
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    return -0.0187005114697;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.108781712755;
                                    } else {
                                        return 0.180624532538;
                                    }
                                }
                            } else {
                                return 0.373211158649;
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[52] <= 0.5) {
                                    return 0.0102205299514;
                                } else {
                                    return -0.13034077837;
                                }
                            } else {
                                if (fs[53] <= -986.0) {
                                    return -0.0863032270281;
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.00502081046633;
                                    } else {
                                        return -0.0132561227338;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                return -0.0429035954184;
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[49] <= -1.5) {
                                        return 0.147896236894;
                                    } else {
                                        return 0.225465899198;
                                    }
                                } else {
                                    return -0.0303054498065;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[53] <= -1138.0) {
                            return -0.149670813737;
                        } else {
                            if (fs[0] <= 0.5) {
                                return 0.143724977998;
                            } else {
                                if (fs[4] <= 11.5) {
                                    return -0.0529557384325;
                                } else {
                                    return 0.107132452313;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[76] <= 100.0) {
                                if (fs[0] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0154756748879;
                                    } else {
                                        return 0.167954755661;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0872046805443;
                                    } else {
                                        return 0.0579638109028;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    return 0.157426327654;
                                } else {
                                    return 0.202720305397;
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[47] <= -4.0) {
                                    return 0.0441725817481;
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.148726313;
                                    } else {
                                        return 0.283895770953;
                                    }
                                }
                            } else {
                                return -0.0263462181389;
                            }
                        }
                    }
                }
            }
        }
    }
}
