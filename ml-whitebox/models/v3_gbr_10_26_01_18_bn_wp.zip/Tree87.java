/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree87 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[11] <= 0.5) {
                if (fs[28] <= 0.5) {
                    if (fs[74] <= 0.5) {
                        if (fs[102] <= 0.5) {
                            if (fs[50] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.0101646499248;
                                    } else {
                                        return 0.0473573762487;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.0764660140029;
                                    } else {
                                        return 0.0320400094579;
                                    }
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    if (fs[83] <= 0.5) {
                                        return -0.0834212513275;
                                    } else {
                                        return -0.463125481357;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0686062805105;
                                    } else {
                                        return -0.0672704446543;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 4.5) {
                                if (fs[55] <= -1.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.00231249292315;
                                    } else {
                                        return 0.056258773389;
                                    }
                                } else {
                                    if (fs[6] <= 0.5) {
                                        return 0.0573703426158;
                                    } else {
                                        return 0.100854171249;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1318.0) {
                                    return 0.130653964884;
                                } else {
                                    if (fs[55] <= -0.5) {
                                        return 0.0437570756866;
                                    } else {
                                        return 0.0165658904822;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.0454210369906;
                                    } else {
                                        return -0.0663244920309;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return -0.104898115201;
                                    } else {
                                        return 0.0772594260961;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9976.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0176263452103;
                                    } else {
                                        return 0.0822662205159;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return -0.335024530705;
                                    } else {
                                        return -0.183064795175;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9994.5) {
                                if (fs[68] <= 1.5) {
                                    return -0.0676841267448;
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0631028257774;
                                    } else {
                                        return 0.131671511538;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.0212464916152;
                                    } else {
                                        return 0.000176267002486;
                                    }
                                } else {
                                    return 0.0262137217337;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1283.0) {
                        if (fs[4] <= 4.5) {
                            if (fs[48] <= 0.5) {
                                return 0.0565483403151;
                            } else {
                                if (fs[105] <= 0.5) {
                                    return -0.503847359584;
                                } else {
                                    return -0.329272001591;
                                }
                            }
                        } else {
                            if (fs[47] <= -1.5) {
                                if (fs[47] <= -5.5) {
                                    return -0.190162055094;
                                } else {
                                    return -0.457779155814;
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.118523392713;
                                    } else {
                                        return 0.353518108186;
                                    }
                                } else {
                                    return -0.242710123706;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            return 0.130477143352;
                        } else {
                            return 0.142914134528;
                        }
                    }
                }
            } else {
                if (fs[24] <= 0.5) {
                    if (fs[53] <= -987.5) {
                        if (fs[84] <= 0.5) {
                            if (fs[47] <= -107.5) {
                                if (fs[92] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.462001475083;
                                    } else {
                                        return -0.100145230466;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0293778353727;
                                    } else {
                                        return 0.124859219753;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[88] <= 5.5) {
                                        return -0.0108116744057;
                                    } else {
                                        return -0.110093427108;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return 0.0230954542405;
                                    } else {
                                        return 0.061119772234;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1132.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.00472078688192;
                                    } else {
                                        return -0.0744532162174;
                                    }
                                } else {
                                    if (fs[53] <= -1398.0) {
                                        return 0.0886402094933;
                                    } else {
                                        return 0.013600543799;
                                    }
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.0278894758736;
                                    } else {
                                        return 0.0317402590393;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.069839091267;
                                    } else {
                                        return -0.102630041722;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[70] <= -1.5) {
                                        return -0.0769815958356;
                                    } else {
                                        return 0.13608901127;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return -0.306332902799;
                                    } else {
                                        return -0.148203263601;
                                    }
                                }
                            } else {
                                return 0.394024103014;
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0355062275338;
                                    } else {
                                        return 0.0528660667749;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.0417208883925;
                                    } else {
                                        return -0.00695996760696;
                                    }
                                }
                            } else {
                                if (fs[47] <= -2.5) {
                                    if (fs[76] <= 100.0) {
                                        return -0.0473500851107;
                                    } else {
                                        return -0.479994293387;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return 0.0661898343125;
                                    } else {
                                        return -0.193442734381;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1218.0) {
                        if (fs[88] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[76] <= 25.0) {
                                    return -0.33941741484;
                                } else {
                                    return 0.0497743256031;
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0818320953072;
                                    } else {
                                        return -0.071481563515;
                                    }
                                } else {
                                    return -0.302362803798;
                                }
                            }
                        } else {
                            if (fs[4] <= 24.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.158532490873;
                                    } else {
                                        return 0.316973557765;
                                    }
                                } else {
                                    if (fs[72] <= 9997.0) {
                                        return 0.111479560708;
                                    } else {
                                        return 0.0310806715237;
                                    }
                                }
                            } else {
                                return -0.300421852321;
                            }
                        }
                    } else {
                        if (fs[47] <= -0.5) {
                            if (fs[78] <= 0.5) {
                                if (fs[4] <= 17.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.151766897042;
                                    } else {
                                        return 0.0314061310212;
                                    }
                                } else {
                                    return -0.331856049081;
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[72] <= 9124.0) {
                                        return -0.0633330118501;
                                    } else {
                                        return 0.0508752310107;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.103161688898;
                                    } else {
                                        return 0.177807326479;
                                    }
                                }
                            }
                        } else {
                            return -0.314080971039;
                        }
                    }
                }
            }
        } else {
            if (fs[30] <= 0.5) {
                if (fs[14] <= 0.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[29] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.0968139746786;
                                    } else {
                                        return 0.00485148718314;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return -0.00568578968317;
                                    } else {
                                        return -0.0492472643272;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[53] <= -1488.5) {
                                        return 0.0293924438097;
                                    } else {
                                        return 0.00783922335987;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.00219433332246;
                                    } else {
                                        return -0.0119096016184;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[4] <= 21.5) {
                                    return 0.0778236297805;
                                } else {
                                    return -0.0763985171059;
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.197409185063;
                                    } else {
                                        return 0.342518187602;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.0108309728387;
                                    } else {
                                        return 0.206481936943;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 350.0) {
                            if (fs[57] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.00588346971476;
                                    } else {
                                        return -0.00350021827652;
                                    }
                                } else {
                                    if (fs[47] <= -14138.5) {
                                        return -0.0343542779564;
                                    } else {
                                        return -0.000704467718998;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.0547907507046;
                                    } else {
                                        return 0.204518789483;
                                    }
                                } else {
                                    if (fs[4] <= 7.0) {
                                        return -0.00583929854151;
                                    } else {
                                        return -0.0189453784882;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0417661208971;
                                    } else {
                                        return -0.010608114248;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.244232378848;
                                    } else {
                                        return -0.0145619164461;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.00125916208056;
                                    } else {
                                        return -0.0248549961187;
                                    }
                                } else {
                                    return -0.021672230041;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 5.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                return 0.00567478852417;
                            } else {
                                if (fs[48] <= 0.5) {
                                    return -0.0629842935901;
                                } else {
                                    return -0.0326190743533;
                                }
                            }
                        } else {
                            if (fs[4] <= 4.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.0290080393251;
                                    } else {
                                        return -0.0350605613523;
                                    }
                                } else {
                                    if (fs[53] <= -571.5) {
                                        return 0.138308625845;
                                    } else {
                                        return 0.155317162253;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[0] <= 10.5) {
                                        return 0.0467263941382;
                                    } else {
                                        return 0.282377565882;
                                    }
                                } else {
                                    return 0.440151962304;
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -7.5) {
                            if (fs[47] <= -15.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0944620832258;
                                    } else {
                                        return -0.0425448440184;
                                    }
                                } else {
                                    return 0.148160573475;
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[47] <= -10.5) {
                                        return 0.200954629085;
                                    } else {
                                        return 0.415227951922;
                                    }
                                } else {
                                    return -0.0697047847216;
                                }
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[62] <= -0.5) {
                                    return 0.186596113129;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0216119255521;
                                    } else {
                                        return 0.00118357308727;
                                    }
                                }
                            } else {
                                return 0.251209696608;
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 5.0) {
                    return 0.107011119131;
                } else {
                    if (fs[53] <= -1138.0) {
                        return 0.00594757351517;
                    } else {
                        return 0.215930715218;
                    }
                }
            }
        }
    }
}
