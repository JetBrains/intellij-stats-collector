/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree42 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[53] <= -1138.5) {
                    if (fs[53] <= -1438.5) {
                        if (fs[53] <= -1568.0) {
                            if (fs[4] <= 40.5) {
                                return 0.0477498525947;
                            } else {
                                return -0.153244366833;
                            }
                        } else {
                            if (fs[4] <= 40.0) {
                                return -0.190588502073;
                            } else {
                                return -0.260740207432;
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[30] <= 0.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0772129055279;
                                    } else {
                                        return -0.0468357346475;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.134304071288;
                                    } else {
                                        return 0.0873707445504;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.124552745347;
                                    } else {
                                        return 0.106852615228;
                                    }
                                } else {
                                    return -0.114877970385;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[60] <= 0.5) {
                                    return 0.262454100601;
                                } else {
                                    return 0.24359189902;
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.162637035155;
                                    } else {
                                        return 0.140414251813;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.0838599476466;
                                    } else {
                                        return 0.23100795093;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 100.0) {
                        if (fs[14] <= 0.5) {
                            if (fs[53] <= -988.0) {
                                if (fs[60] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.128905254042;
                                    } else {
                                        return 0.168101481851;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.118094971208;
                                    } else {
                                        return 0.157678057128;
                                    }
                                }
                            } else {
                                if (fs[15] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.139143108516;
                                    } else {
                                        return -0.00167925571374;
                                    }
                                } else {
                                    return -0.245288741672;
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.338791257964;
                            } else {
                                if (fs[72] <= 5000.0) {
                                    return 0.170787872428;
                                } else {
                                    return 0.171815353334;
                                }
                            }
                        }
                    } else {
                        return -0.200154301124;
                    }
                }
            } else {
                if (fs[4] <= 2.5) {
                    if (fs[53] <= -1063.0) {
                        if (fs[78] <= 0.5) {
                            return 0.076717583254;
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    return 0.17905021524;
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.33283465488;
                                    } else {
                                        return 0.235836412259;
                                    }
                                }
                            } else {
                                return -0.086243827981;
                            }
                        }
                    } else {
                        return -0.131953581519;
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[101] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00723622562225;
                                    } else {
                                        return 0.0326510158012;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0129794796552;
                                    } else {
                                        return -0.0256984865137;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0669314029783;
                                    } else {
                                        return -0.103817949456;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.071441137569;
                                    } else {
                                        return -0.0536403377007;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.21921957823;
                            } else {
                                return 0.274310322564;
                            }
                        }
                    } else {
                        if (fs[15] <= 0.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[4] <= 3.5) {
                                    if (fs[0] <= 3.5) {
                                        return 0.0584365131263;
                                    } else {
                                        return -0.00626741324509;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0162468841374;
                                    } else {
                                        return -0.0081757655331;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.0149152016193;
                                    } else {
                                        return -0.00964346228758;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.021480829504;
                                    } else {
                                        return -0.0505370650577;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    return -0.0728509235282;
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.129391033558;
                                    } else {
                                        return -0.0229134245284;
                                    }
                                }
                            } else {
                                return 0.0364617535456;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[74] <= 0.5) {
                            if (fs[100] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[4] <= 18.5) {
                                        return 0.0499602353288;
                                    } else {
                                        return -0.0740492278202;
                                    }
                                } else {
                                    if (fs[63] <= 0.5) {
                                        return 0.108526267233;
                                    } else {
                                        return -0.0929491351287;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.20430326121;
                                    } else {
                                        return 0.153259193372;
                                    }
                                } else {
                                    if (fs[53] <= -1128.5) {
                                        return 0.228218293295;
                                    } else {
                                        return -0.118755831078;
                                    }
                                }
                            }
                        } else {
                            return -0.0290342012551;
                        }
                    } else {
                        if (fs[90] <= 0.5) {
                            if (fs[53] <= -1543.5) {
                                if (fs[53] <= -1963.5) {
                                    if (fs[53] <= -2023.0) {
                                        return 0.162687514117;
                                    } else {
                                        return -0.0517634064505;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return 0.194955586366;
                                    } else {
                                        return -0.211124193032;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1483.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.131562348946;
                                    } else {
                                        return 0.0202602550524;
                                    }
                                } else {
                                    if (fs[72] <= 8622.0) {
                                        return -0.0430296992895;
                                    } else {
                                        return 0.0450704316891;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[83] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0959179509036;
                                    } else {
                                        return 0.0593197554817;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.048349216917;
                                    } else {
                                        return -0.238807738797;
                                    }
                                }
                            } else {
                                if (fs[97] <= 0.5) {
                                    if (fs[53] <= -1283.5) {
                                        return 0.1752212801;
                                    } else {
                                        return 0.0270624000155;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.197552706243;
                                    } else {
                                        return -0.0836958298884;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 25.0) {
                        if (fs[22] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[53] <= -1513.5) {
                                        return 0.245878924;
                                    } else {
                                        return 0.0775555018291;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.146594272302;
                                    } else {
                                        return -0.153285766586;
                                    }
                                }
                            } else {
                                if (fs[2] <= 10.5) {
                                    if (fs[4] <= 34.5) {
                                        return -0.00295153451416;
                                    } else {
                                        return 0.188325641218;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.0943392799151;
                                    } else {
                                        return 0.299949477547;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.0) {
                                if (fs[90] <= 0.5) {
                                    if (fs[72] <= 9838.5) {
                                        return -0.0809346136786;
                                    } else {
                                        return 0.0505182884941;
                                    }
                                } else {
                                    if (fs[72] <= 9339.0) {
                                        return 0.316884346666;
                                    } else {
                                        return 0.0606327688502;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.267926857738;
                                    } else {
                                        return 0.135206302466;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.245502664367;
                                    } else {
                                        return 0.305611562482;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= -0.5) {
                            if (fs[76] <= 150.0) {
                                if (fs[2] <= 3.5) {
                                    return -0.33477294432;
                                } else {
                                    return -0.229476310872;
                                }
                            } else {
                                return -0.148382001676;
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 27.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.121128998025;
                                    } else {
                                        return 0.0922370509054;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0478004912094;
                                    } else {
                                        return -0.0890026374587;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[26] <= 0.5) {
                                        return -0.0592400637454;
                                    } else {
                                        return 0.135740100579;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.0938161615229;
                                    } else {
                                        return -0.0238968192703;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[53] <= -1478.5) {
                        if (fs[88] <= 6.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[66] <= 5.0) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0593085647709;
                                    } else {
                                        return 0.116093371285;
                                    }
                                } else {
                                    return -0.164704703073;
                                }
                            } else {
                                if (fs[88] <= 5.5) {
                                    if (fs[47] <= -132.0) {
                                        return 0.115735391703;
                                    } else {
                                        return 0.0173347418148;
                                    }
                                } else {
                                    if (fs[47] <= -2851.5) {
                                        return 0.177846673172;
                                    } else {
                                        return -0.0367902186682;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.159689038094;
                                    } else {
                                        return -0.23724131438;
                                    }
                                } else {
                                    if (fs[18] <= -0.5) {
                                        return -0.319126922063;
                                    } else {
                                        return -0.0434694174409;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0991073805596;
                                    } else {
                                        return 0.178711968923;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.00817811134232;
                                    } else {
                                        return 0.159538359504;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.0174256442989;
                                    } else {
                                        return -0.00378872376745;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.121783924224;
                                    } else {
                                        return 0.0467544034513;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[72] <= 9997.5) {
                                        return -0.0264422573786;
                                    } else {
                                        return 0.220736034274;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return 0.0329391665475;
                                    } else {
                                        return -0.0270701823924;
                                    }
                                }
                            }
                        } else {
                            if (fs[89] <= 0.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.00983582187297;
                                    } else {
                                        return -0.0226967492704;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.244429147462;
                                    } else {
                                        return 0.0581379282498;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0616526250344;
                                    } else {
                                        return -0.0494634522074;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0263640835489;
                                    } else {
                                        return -0.038964315555;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9998.5) {
                        if (fs[47] <= -3731.5) {
                            if (fs[53] <= -1293.0) {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.201702106243;
                                    } else {
                                        return 0.511600748274;
                                    }
                                } else {
                                    if (fs[88] <= 0.5) {
                                        return 0.0795581129151;
                                    } else {
                                        return -0.115610360531;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    return 0.0664065229088;
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.0347669712895;
                                    } else {
                                        return -0.0646164857052;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 13.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[0] <= 6.5) {
                                        return -0.00352439550581;
                                    } else {
                                        return -0.00685315355384;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.00529085310256;
                                    } else {
                                        return -0.00959888048362;
                                    }
                                }
                            } else {
                                if (fs[49] <= -2.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0372307300924;
                                    } else {
                                        return 0.151689084537;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return -0.00650738811655;
                                    } else {
                                        return -0.00774058617449;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1072.5) {
                            if (fs[53] <= -1128.0) {
                                if (fs[0] <= 16.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.113578895265;
                                    } else {
                                        return 0.0112960342453;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.0234324492653;
                                    } else {
                                        return -0.164079304794;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    return 0.0486208887368;
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.178218831345;
                                    } else {
                                        return 0.505076278906;
                                    }
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0262363253156;
                                    } else {
                                        return -0.0123202046304;
                                    }
                                } else {
                                    if (fs[53] <= -967.0) {
                                        return -0.005347892263;
                                    } else {
                                        return 0.085555491281;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0947872540893;
                                    } else {
                                        return -0.0427910501189;
                                    }
                                } else {
                                    return 0.445567917493;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
