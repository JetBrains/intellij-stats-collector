/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree96 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[8] <= 0.5) {
                if (fs[4] <= 18.5) {
                    if (fs[53] <= -1498.5) {
                        if (fs[53] <= -1953.5) {
                            if (fs[53] <= -1999.0) {
                                if (fs[4] <= 6.5) {
                                    if (fs[88] <= 1.0) {
                                        return -0.0833046045513;
                                    } else {
                                        return 0.189697179065;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.12153739367;
                                    } else {
                                        return 0.0417266672874;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0105535703949;
                                    } else {
                                        return 0.118691917023;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.100918587869;
                                    } else {
                                        return -0.145418316764;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[101] <= 1.5) {
                                    if (fs[53] <= -1883.5) {
                                        return 0.0224997103541;
                                    } else {
                                        return 0.089188699315;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.0130674886112;
                                    } else {
                                        return -0.192135712185;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[88] <= 7.5) {
                                        return 0.0431407968454;
                                    } else {
                                        return 0.175210020498;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return 0.142962376972;
                                    } else {
                                        return 0.0561101657198;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 5.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[51] <= 0.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.00726687788004;
                                    } else {
                                        return 0.0734210936239;
                                    }
                                } else {
                                    if (fs[53] <= -1123.5) {
                                        return 0.114711157144;
                                    } else {
                                        return 0.206895593173;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.0104797436186;
                                    } else {
                                        return -0.0722747156596;
                                    }
                                } else {
                                    if (fs[53] <= -972.5) {
                                        return 0.0118740549844;
                                    } else {
                                        return -0.0192200564895;
                                    }
                                }
                            }
                        } else {
                            if (fs[81] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    return 0.0139328239008;
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.000745298622949;
                                    } else {
                                        return -0.156462624572;
                                    }
                                }
                            } else {
                                if (fs[72] <= 8960.0) {
                                    if (fs[4] <= 14.5) {
                                        return 0.0477789054657;
                                    } else {
                                        return 0.0041663512435;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.00462653037753;
                                    } else {
                                        return 0.0595567449146;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[55] <= 548.5) {
                        if (fs[88] <= 7.5) {
                            if (fs[53] <= -2428.0) {
                                if (fs[12] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.144925361175;
                                    } else {
                                        return -0.194077749305;
                                    }
                                } else {
                                    if (fs[4] <= 24.5) {
                                        return -0.153734858601;
                                    } else {
                                        return 0.0594848511191;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[53] <= -2343.0) {
                                        return -0.327755584012;
                                    } else {
                                        return -0.0315592769324;
                                    }
                                } else {
                                    if (fs[70] <= -3.5) {
                                        return 0.156750166825;
                                    } else {
                                        return -0.00589762348556;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                return 0.302589141618;
                            } else {
                                return -0.115226662522;
                            }
                        }
                    } else {
                        return 0.321749095858;
                    }
                }
            } else {
                if (fs[4] <= 13.5) {
                    if (fs[72] <= 9999.5) {
                        if (fs[103] <= 0.5) {
                            if (fs[4] <= 5.5) {
                                return -0.00146440076303;
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.418926481582;
                                    } else {
                                        return -0.3098884978;
                                    }
                                } else {
                                    return -0.100603152113;
                                }
                            }
                        } else {
                            return 0.256033603949;
                        }
                    } else {
                        return -0.331645938237;
                    }
                } else {
                    if (fs[79] <= 0.5) {
                        return -0.0958865184754;
                    } else {
                        return 0.211259553919;
                    }
                }
            }
        } else {
            if (fs[76] <= 250.0) {
                if (fs[99] <= 0.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[2] <= 6.5) {
                            if (fs[103] <= 0.5) {
                                if (fs[47] <= -3.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.00815406858772;
                                    } else {
                                        return -0.000504015659003;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.000711758225379;
                                    } else {
                                        return 0.00653969719372;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[53] <= -1128.0) {
                                        return -0.0622002983097;
                                    } else {
                                        return -0.024253974342;
                                    }
                                } else {
                                    if (fs[72] <= 9981.5) {
                                        return -0.00420065625441;
                                    } else {
                                        return -0.0297987332773;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[76] <= 25.0) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.000331372679869;
                                    } else {
                                        return -0.18749008663;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.0378836169877;
                                    } else {
                                        return 0.00486167412993;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[53] <= -1312.5) {
                                        return 0.389786794843;
                                    } else {
                                        return 0.0397107268139;
                                    }
                                } else {
                                    if (fs[47] <= -93.0) {
                                        return 0.234762499711;
                                    } else {
                                        return -0.000557709344166;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 1.5) {
                            if (fs[53] <= -1138.0) {
                                return 0.0949136860118;
                            } else {
                                return 0.0500420305811;
                            }
                        } else {
                            return 0.160442116061;
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[72] <= 9998.5) {
                            if (fs[94] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0186973313248;
                                    } else {
                                        return -0.00422295334162;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0145256378399;
                                    } else {
                                        return -0.000430086568822;
                                    }
                                }
                            } else {
                                if (fs[4] <= 35.5) {
                                    if (fs[53] <= -1488.0) {
                                        return 0.122012503585;
                                    } else {
                                        return 0.0222911922518;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.00946953910488;
                                    } else {
                                        return -0.132002991068;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 20.0) {
                                        return 0.295716647823;
                                    } else {
                                        return 0.00887351558054;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0742703851046;
                                    } else {
                                        return 0.0490263837418;
                                    }
                                }
                            } else {
                                if (fs[2] <= 6.5) {
                                    if (fs[4] <= 35.5) {
                                        return 0.0140285131119;
                                    } else {
                                        return -0.156479646812;
                                    }
                                } else {
                                    if (fs[53] <= -1308.0) {
                                        return 0.296584150955;
                                    } else {
                                        return 0.103184641204;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 5.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.251873445434;
                                    } else {
                                        return 0.00843926761432;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.036998106452;
                                    } else {
                                        return 0.253812074188;
                                    }
                                }
                            } else {
                                if (fs[47] <= -6.5) {
                                    return 0.175096785657;
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.116490016616;
                                    } else {
                                        return 0.0350359995808;
                                    }
                                }
                            }
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[50] <= 0.5) {
                                        return -0.00238543530316;
                                    } else {
                                        return 0.0434758460581;
                                    }
                                } else {
                                    return 0.168423079731;
                                }
                            } else {
                                if (fs[72] <= 9960.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.00481978183507;
                                    } else {
                                        return 0.0327612687799;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0226598983018;
                                    } else {
                                        return -0.0394302375212;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[18] <= 0.5) {
                    if (fs[48] <= 0.5) {
                        if (fs[53] <= -1133.5) {
                            if (fs[0] <= 2.5) {
                                if (fs[47] <= -1.5) {
                                    if (fs[78] <= 0.5) {
                                        return 0.0398043396742;
                                    } else {
                                        return -0.0604099397737;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.140286086658;
                                    } else {
                                        return -0.0601312986076;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[72] <= 9994.0) {
                                        return -0.0197050148725;
                                    } else {
                                        return -0.168322570763;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.00532375269837;
                                    } else {
                                        return 0.0774973900673;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[47] <= -3.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.0321989231875;
                                    } else {
                                        return 0.15275910534;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.18150137088;
                                    } else {
                                        return -0.00494047666002;
                                    }
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0214484341554;
                                    } else {
                                        return -0.00881108151457;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.00132406845368;
                                    } else {
                                        return -0.00837317267289;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[53] <= -1299.0) {
                                if (fs[52] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0915846770651;
                                    } else {
                                        return -0.0798920357009;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.589856971792;
                                    } else {
                                        return 0.19972466023;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[53] <= -1133.5) {
                                        return 0.0151700367097;
                                    } else {
                                        return 0.054550102797;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.00108760309096;
                                    } else {
                                        return -0.00718533111982;
                                    }
                                }
                            }
                        } else {
                            if (fs[8] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[103] <= 1.5) {
                                        return -0.0073574627536;
                                    } else {
                                        return 0.00533741443806;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0161693181962;
                                    } else {
                                        return -0.00275903834917;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.462554740478;
                                    } else {
                                        return 0.286963878564;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0186373149397;
                                    } else {
                                        return -0.0278760465987;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[2] <= 9.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[4] <= 16.5) {
                                        return 0.0226063651469;
                                    } else {
                                        return 0.169415436626;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0339102533236;
                                    } else {
                                        return -0.0807662606058;
                                    }
                                }
                            } else {
                                return 0.148230204237;
                            }
                        } else {
                            if (fs[62] <= -2.5) {
                                return 0.107529534501;
                            } else {
                                if (fs[2] <= 7.5) {
                                    if (fs[47] <= -0.5) {
                                        return -0.0111379144104;
                                    } else {
                                        return 0.00180754392431;
                                    }
                                } else {
                                    return -0.0434139633649;
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[53] <= -1478.0) {
                                    if (fs[52] <= 0.5) {
                                        return 0.343280581168;
                                    } else {
                                        return -0.00899094926924;
                                    }
                                } else {
                                    return -0.038466664102;
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.0371865113747;
                                    } else {
                                        return 0.0478944093097;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return -0.0121172067142;
                                    } else {
                                        return 0.0741796877177;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -2.5) {
                                if (fs[53] <= -956.0) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0322095327572;
                                    } else {
                                        return -0.0408342864438;
                                    }
                                } else {
                                    return -0.0106168058014;
                                }
                            } else {
                                if (fs[0] <= 5.5) {
                                    if (fs[4] <= 26.5) {
                                        return -0.00457633090836;
                                    } else {
                                        return 0.000346398437216;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.000324718450931;
                                    } else {
                                        return -0.00204567248199;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
