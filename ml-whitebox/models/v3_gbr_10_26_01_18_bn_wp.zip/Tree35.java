/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree35 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[76] <= 100.0) {
                if (fs[59] <= 0.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[12] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.130373817626;
                                    } else {
                                        return 0.179299587407;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0938157578375;
                                    } else {
                                        return -0.0348800923188;
                                    }
                                }
                            } else {
                                if (fs[53] <= -491.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.208480366148;
                                    } else {
                                        return 0.160589915575;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.246142622619;
                                    } else {
                                        return 0.182097092853;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return -0.040499851801;
                                    } else {
                                        return 0.0552159113488;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.149387568067;
                                    } else {
                                        return -0.00482175990681;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.255423481046;
                                    } else {
                                        return 0.0137429952492;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.259990584259;
                                    } else {
                                        return -0.0997913684757;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.180239330972;
                                    } else {
                                        return 0.304025023776;
                                    }
                                } else {
                                    if (fs[53] <= -1113.5) {
                                        return 0.153812368214;
                                    } else {
                                        return -0.0359477240471;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.148580431438;
                                    } else {
                                        return 0.482852432388;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.200093759838;
                                    } else {
                                        return 0.16700137634;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[53] <= -1138.0) {
                                    return -0.237462865559;
                                } else {
                                    return 0.151580921438;
                                }
                            } else {
                                return 0.166238197645;
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[79] <= 0.5) {
                            if (fs[4] <= 7.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0745602587225;
                                    } else {
                                        return 0.164572842883;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return 0.175190648874;
                                    } else {
                                        return 0.207339170578;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9997.5) {
                                    if (fs[72] <= 4914.0) {
                                        return 0.195257985628;
                                    } else {
                                        return 0.121020862021;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.26862422032;
                                    } else {
                                        return 0.205515557533;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                if (fs[4] <= 5.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.125203894684;
                                    } else {
                                        return 0.191737880334;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0269235848229;
                                    } else {
                                        return 0.17338766859;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[53] <= -1118.5) {
                                        return 0.145913864078;
                                    } else {
                                        return 0.0234340956771;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.159290120158;
                                    } else {
                                        return 0.17081223747;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[70] <= -1.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0977474037473;
                                    } else {
                                        return 0.301547243899;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.155447745616;
                                    } else {
                                        return 0.249890703317;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.121378788336;
                                    } else {
                                        return -0.0645604338454;
                                    }
                                } else {
                                    if (fs[0] <= 10.5) {
                                        return -0.0267502064957;
                                    } else {
                                        return 0.0345127925963;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 8.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[53] <= -1058.0) {
                                        return -0.0479634854156;
                                    } else {
                                        return -0.0239416885725;
                                    }
                                } else {
                                    return 0.0730901286274;
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[70] <= -1.5) {
                                        return -0.0226227916364;
                                    } else {
                                        return 0.0868008203283;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0338596663505;
                                    } else {
                                        return -0.0119498944454;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[2] <= 2.5) {
                    if (fs[78] <= 0.5) {
                        if (fs[0] <= 5.5) {
                            if (fs[4] <= 31.5) {
                                if (fs[53] <= -1188.0) {
                                    if (fs[53] <= -1558.0) {
                                        return 0.0160745523321;
                                    } else {
                                        return -0.110508239483;
                                    }
                                } else {
                                    if (fs[4] <= 25.5) {
                                        return 0.0723261756779;
                                    } else {
                                        return 0.221758796228;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1548.0) {
                                    return 0.0322573330148;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.108709527747;
                                    } else {
                                        return -0.0128676163219;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 20.5) {
                                    if (fs[0] <= 9.5) {
                                        return -0.0326055917551;
                                    } else {
                                        return -0.027064246094;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.0348709612669;
                                    } else {
                                        return -0.0159874679873;
                                    }
                                }
                            } else {
                                return -0.0082981325175;
                            }
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[4] <= 16.5) {
                                return 0.105316209165;
                            } else {
                                if (fs[53] <= -1478.0) {
                                    if (fs[4] <= 21.5) {
                                        return 0.00140844789093;
                                    } else {
                                        return -0.077199567674;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0240755257434;
                                    } else {
                                        return -0.0303382134986;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 6.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0179996329369;
                                    } else {
                                        return -0.0156583903267;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.00874352703572;
                                    } else {
                                        return -0.00931278835882;
                                    }
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.0123977411277;
                                    } else {
                                        return -0.0129426105552;
                                    }
                                } else {
                                    if (fs[53] <= -987.0) {
                                        return -0.0104115373676;
                                    } else {
                                        return -0.00675905242254;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1578.0) {
                        if (fs[2] <= 3.5) {
                            return 0.0558456817656;
                        } else {
                            return 0.000571287342411;
                        }
                    } else {
                        if (fs[53] <= -1548.0) {
                            if (fs[78] <= 0.5) {
                                return -0.00900917356046;
                            } else {
                                if (fs[4] <= 53.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0595959102246;
                                    } else {
                                        return -0.0168706663613;
                                    }
                                } else {
                                    return -0.102345050551;
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.060490016514;
                                    } else {
                                        return -0.0468522678124;
                                    }
                                } else {
                                    return -0.021803124468;
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    if (fs[2] <= 5.5) {
                                        return -0.0134614362916;
                                    } else {
                                        return 0.00607477209716;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0378686217257;
                                    } else {
                                        return -0.015062823928;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[90] <= 0.5) {
                if (fs[72] <= 9971.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[47] <= -1.5) {
                            if (fs[4] <= 11.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.144720995693;
                                    } else {
                                        return 0.231816963087;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.288748257841;
                                    } else {
                                        return 0.103347167069;
                                    }
                                }
                            } else {
                                if (fs[4] <= 22.5) {
                                    if (fs[88] <= 5.5) {
                                        return 0.112756417125;
                                    } else {
                                        return -0.0867380102299;
                                    }
                                } else {
                                    if (fs[47] <= -47.0) {
                                        return 0.171896236337;
                                    } else {
                                        return -0.0921840137725;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0303432742279;
                                    } else {
                                        return -0.0496285140276;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.0585559733438;
                                    } else {
                                        return 0.183175419222;
                                    }
                                }
                            } else {
                                if (fs[74] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return -0.0126523131715;
                                    } else {
                                        return 0.219257072957;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.066941356728;
                                    } else {
                                        return 0.179106402329;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 6.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.0107225949024;
                                    } else {
                                        return -0.00666917528197;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return -0.00116553384987;
                                    } else {
                                        return 0.0541237112888;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.011320727691;
                                    } else {
                                        return -0.00606296513806;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0117334377598;
                                    } else {
                                        return -0.00305952189946;
                                    }
                                }
                            }
                        } else {
                            if (fs[85] <= 0.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.00844526443258;
                                    } else {
                                        return 0.114922271279;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.00158760547398;
                                    } else {
                                        return 0.168761281071;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[53] <= -1458.0) {
                                        return 0.00881162011628;
                                    } else {
                                        return -0.0155396248033;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.0234973726705;
                                    } else {
                                        return 0.221193224901;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[72] <= 9999.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[34] <= 0.5) {
                                        return 0.0588690959978;
                                    } else {
                                        return 0.305132137471;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.149093925401;
                                    } else {
                                        return -0.321948162668;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0356385132569;
                                    } else {
                                        return 0.00469192457913;
                                    }
                                } else {
                                    if (fs[0] <= 9.5) {
                                        return 0.0832309747501;
                                    } else {
                                        return -0.00515620225827;
                                    }
                                }
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[66] <= 5.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.136628794984;
                                    } else {
                                        return 0.21228589714;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.0892028919059;
                                    } else {
                                        return -0.176053724383;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[105] <= 0.5) {
                                        return 0.189518330836;
                                    } else {
                                        return 0.119680841386;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.169970175396;
                                    } else {
                                        return 0.0577698134761;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[104] <= 0.5) {
                            if (fs[47] <= -2246.0) {
                                return 0.0770400053355;
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[68] <= 1.5) {
                                        return -0.0203687145887;
                                    } else {
                                        return 0.0114595390789;
                                    }
                                } else {
                                    return -0.0737843195629;
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[72] <= 9987.0) {
                                    return -0.0864890159669;
                                } else {
                                    return -0.0805515332044;
                                }
                            } else {
                                return -0.0495595586331;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[72] <= 9950.5) {
                        if (fs[53] <= -1493.5) {
                            if (fs[4] <= 18.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.213577982952;
                                    } else {
                                        return 0.297316172709;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.304705417824;
                                    } else {
                                        return 0.191912055829;
                                    }
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[4] <= 30.5) {
                                        return 0.149191179427;
                                    } else {
                                        return 0.365537950862;
                                    }
                                } else {
                                    return -0.293805879065;
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.152515416794;
                                    } else {
                                        return 0.088431013365;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.159131065026;
                                    } else {
                                        return 0.0725956780514;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[103] <= 0.5) {
                                        return 0.145901210325;
                                    } else {
                                        return 0.0428287127057;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0903311793911;
                                    } else {
                                        return -0.0705208628652;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 250.0) {
                            if (fs[53] <= -1273.0) {
                                if (fs[53] <= -1473.5) {
                                    if (fs[4] <= 15.5) {
                                        return 0.136333774409;
                                    } else {
                                        return -0.00360065355895;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.102197283204;
                                    } else {
                                        return 0.324177279493;
                                    }
                                }
                            } else {
                                if (fs[64] <= -997.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.258630329817;
                                    } else {
                                        return 0.243610584308;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0122907056038;
                                    } else {
                                        return 0.393864758708;
                                    }
                                }
                            }
                        } else {
                            if (fs[13] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -988.5) {
                                        return 0.106270441891;
                                    } else {
                                        return -0.0585460783348;
                                    }
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return 0.155502283547;
                                    } else {
                                        return -0.164283367009;
                                    }
                                }
                            } else {
                                return -0.302324344202;
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1418.0) {
                        if (fs[4] <= 11.5) {
                            if (fs[48] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[47] <= -7.5) {
                                        return 0.0667030562824;
                                    } else {
                                        return -0.015953761346;
                                    }
                                } else {
                                    if (fs[0] <= 14.5) {
                                        return 0.146645289915;
                                    } else {
                                        return 0.46410244071;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.129774323515;
                                    } else {
                                        return -0.0190484578571;
                                    }
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return 0.20840203278;
                                    } else {
                                        return 0.0486998450788;
                                    }
                                }
                            }
                        } else {
                            if (fs[83] <= 0.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.05886778203;
                                    } else {
                                        return 0.00755890165474;
                                    }
                                } else {
                                    if (fs[47] <= -5.5) {
                                        return 0.472242568638;
                                    } else {
                                        return 0.120470279816;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[0] <= 30.5) {
                                        return -0.0612941045432;
                                    } else {
                                        return 0.0694379475263;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0235042464685;
                                    } else {
                                        return 0.163499266851;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1082.5) {
                            if (fs[103] <= 1.5) {
                                if (fs[47] <= -0.5) {
                                    if (fs[0] <= 66.5) {
                                        return -0.00637899820897;
                                    } else {
                                        return 0.27493290282;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return 0.277458005353;
                                    } else {
                                        return -0.0399048735266;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[0] <= 13.5) {
                                        return 0.0553774876424;
                                    } else {
                                        return 0.430971546604;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.042701527255;
                                    } else {
                                        return 0.0154884483244;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[8] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00513491702914;
                                    } else {
                                        return 0.0143659558744;
                                    }
                                } else {
                                    if (fs[76] <= 100.0) {
                                        return -0.0281538177139;
                                    } else {
                                        return 0.364736966322;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[53] <= -1011.5) {
                                        return 0.0256856742448;
                                    } else {
                                        return -0.019380029836;
                                    }
                                } else {
                                    if (fs[26] <= 0.5) {
                                        return -0.0120281082737;
                                    } else {
                                        return -0.010526574553;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
