/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree90 {
    public double calcTree(double... fs) {
        if (fs[57] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[41] <= 0.5) {
                    if (fs[4] <= 15.5) {
                        if (fs[93] <= 0.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 3.1416650359e-05;
                                    } else {
                                        return 0.0131483408603;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0626075236826;
                                    } else {
                                        return 0.16512484824;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.187538939888;
                                    } else {
                                        return -0.101205778662;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return -0.303757927388;
                                    } else {
                                        return -0.185458063351;
                                    }
                                }
                            }
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[47] <= -38.0) {
                                    return -0.334081599542;
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.28090113086;
                                    } else {
                                        return -0.08705309949;
                                    }
                                }
                            } else {
                                return 0.0906589514264;
                            }
                        }
                    } else {
                        if (fs[2] <= 10.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return -0.0439265694171;
                                    } else {
                                        return -0.190294104245;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.062402996102;
                                    } else {
                                        return -0.0179546072721;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    if (fs[53] <= -2018.0) {
                                        return 0.0686187457565;
                                    } else {
                                        return -0.0423154711792;
                                    }
                                } else {
                                    if (fs[92] <= 0.5) {
                                        return 0.123308456907;
                                    } else {
                                        return 0.00657128281268;
                                    }
                                }
                            }
                        } else {
                            if (fs[76] <= 75.0) {
                                if (fs[99] <= 0.5) {
                                    if (fs[77] <= 0.5) {
                                        return 0.19243801773;
                                    } else {
                                        return -0.029363331329;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.235345384392;
                                    } else {
                                        return 0.116682804126;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.188412083408;
                                    } else {
                                        return 0.0456400222221;
                                    }
                                } else {
                                    return 0.134152765988;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[71] <= 0.5) {
                        if (fs[4] <= 14.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[72] <= 9971.0) {
                                    if (fs[43] <= 0.5) {
                                        return 0.00497691795656;
                                    } else {
                                        return -0.109957029057;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0878079745733;
                                    } else {
                                        return 0.272609024658;
                                    }
                                }
                            } else {
                                if (fs[72] <= 4719.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0742088961619;
                                    } else {
                                        return 0.24910109507;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.111835379317;
                                    } else {
                                        return -0.146437539712;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 15.5) {
                                if (fs[2] <= 2.5) {
                                    return -0.152693682327;
                                } else {
                                    return -0.36157206923;
                                }
                            } else {
                                if (fs[83] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0755321957555;
                                    } else {
                                        return -0.0951089116293;
                                    }
                                } else {
                                    return -0.248399114017;
                                }
                            }
                        }
                    } else {
                        if (fs[60] <= 0.5) {
                            if (fs[89] <= 0.5) {
                                if (fs[59] <= 0.5) {
                                    return -0.149485224872;
                                } else {
                                    return -0.323011979465;
                                }
                            } else {
                                return 0.0169186721639;
                            }
                        } else {
                            if (fs[90] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0921182292454;
                                    } else {
                                        return -0.0203150398731;
                                    }
                                } else {
                                    if (fs[72] <= 9857.0) {
                                        return -0.250299299814;
                                    } else {
                                        return -0.0981130041475;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0529493989502;
                                    } else {
                                        return -0.15446740421;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.142016136944;
                                    } else {
                                        return 0.0178439027637;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 3.5) {
                    if (fs[88] <= 3.5) {
                        if (fs[26] <= 0.5) {
                            if (fs[27] <= 0.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.0781239601468;
                                    } else {
                                        return 0.0029461290823;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0056864559134;
                                    } else {
                                        return 0.00194463123424;
                                    }
                                }
                            } else {
                                if (fs[4] <= 2.5) {
                                    if (fs[14] <= 0.5) {
                                        return 0.0335704873547;
                                    } else {
                                        return 0.0749796542355;
                                    }
                                } else {
                                    return 0.142413154606;
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[78] <= 0.5) {
                                        return -0.0451785694285;
                                    } else {
                                        return 0.135909655571;
                                    }
                                } else {
                                    return 0.244237164544;
                                }
                            } else {
                                if (fs[53] <= -566.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0418101071541;
                                    } else {
                                        return 0.150229607631;
                                    }
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return 0.0173190776465;
                                    } else {
                                        return -0.0160838604882;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 16.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[53] <= -1478.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0402245402538;
                                    } else {
                                        return 0.311231006013;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0460256994316;
                                    } else {
                                        return 0.0319697000781;
                                    }
                                }
                            } else {
                                return -0.0228974090433;
                            }
                        } else {
                            if (fs[0] <= 32.5) {
                                if (fs[0] <= 19.5) {
                                    if (fs[4] <= 2.5) {
                                        return -0.044340160493;
                                    } else {
                                        return 0.0142686257592;
                                    }
                                } else {
                                    if (fs[0] <= 26.5) {
                                        return -0.01509962746;
                                    } else {
                                        return -0.00103575802452;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[0] <= 34.5) {
                                        return 0.314815061958;
                                    } else {
                                        return -0.00806211161285;
                                    }
                                } else {
                                    if (fs[47] <= -22.5) {
                                        return -0.0454124307807;
                                    } else {
                                        return -0.0207278085193;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 5.5) {
                        if (fs[47] <= -15883.5) {
                            if (fs[47] <= -20361.0) {
                                if (fs[53] <= -1488.0) {
                                    return 0.077508322396;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0183627507939;
                                    } else {
                                        return -0.123030156017;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return -0.242933118907;
                                } else {
                                    return -0.132722158759;
                                }
                            }
                        } else {
                            if (fs[47] <= -4634.0) {
                                if (fs[0] <= 5.5) {
                                    if (fs[72] <= 9755.0) {
                                        return 0.125810994326;
                                    } else {
                                        return 0.249264025417;
                                    }
                                } else {
                                    if (fs[53] <= -1458.0) {
                                        return 0.0246447528955;
                                    } else {
                                        return -0.0327073170889;
                                    }
                                }
                            } else {
                                if (fs[64] <= -997.5) {
                                    if (fs[47] <= -126.5) {
                                        return 0.299944622716;
                                    } else {
                                        return 0.0166239036434;
                                    }
                                } else {
                                    if (fs[47] <= -2099.5) {
                                        return -0.0373399618329;
                                    } else {
                                        return -0.000335525813651;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 6.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[47] <= -7940.0) {
                                    if (fs[72] <= 4879.0) {
                                        return 0.162016484209;
                                    } else {
                                        return -0.0450825124878;
                                    }
                                } else {
                                    if (fs[93] <= 0.5) {
                                        return 0.00049379849239;
                                    } else {
                                        return -0.0674908751508;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0512046465135;
                                    } else {
                                        return 0.135086489557;
                                    }
                                } else {
                                    if (fs[47] <= -8.5) {
                                        return 0.0761604578419;
                                    } else {
                                        return 0.00507450127311;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -3924.0) {
                                if (fs[53] <= -1478.0) {
                                    if (fs[4] <= 10.5) {
                                        return -0.193091884537;
                                    } else {
                                        return -0.0923481055283;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0314221888121;
                                    } else {
                                        return -0.098125896679;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.00134305719508;
                                    } else {
                                        return -0.0294578434274;
                                    }
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.00607447931318;
                                    } else {
                                        return -0.00179345718649;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[72] <= 9999.5) {
                if (fs[0] <= 0.5) {
                    if (fs[72] <= 4995.0) {
                        if (fs[12] <= 0.5) {
                            if (fs[48] <= 0.5) {
                                return 0.0495594334945;
                            } else {
                                if (fs[88] <= 1.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.219871782827;
                                    } else {
                                        return 0.144581030224;
                                    }
                                } else {
                                    return 0.0953421243168;
                                }
                            }
                        } else {
                            if (fs[101] <= 0.5) {
                                if (fs[4] <= 7.5) {
                                    return -0.095387830206;
                                } else {
                                    if (fs[4] <= 10.0) {
                                        return 0.0633518216786;
                                    } else {
                                        return 0.125405482743;
                                    }
                                }
                            } else {
                                if (fs[64] <= -994.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.0869651484746;
                                    } else {
                                        return 0.00952316315525;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.254155150392;
                                    } else {
                                        return 0.128405901965;
                                    }
                                }
                            }
                        }
                    } else {
                        return -0.115881072704;
                    }
                } else {
                    if (fs[88] <= 7.5) {
                        if (fs[47] <= -4.5) {
                            if (fs[45] <= 0.5) {
                                return -0.118601106535;
                            } else {
                                return -0.0142553937999;
                            }
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[47] <= -0.5) {
                                        return -0.130636745491;
                                    } else {
                                        return -0.0327838714514;
                                    }
                                } else {
                                    if (fs[53] <= -1268.0) {
                                        return -0.0508239957102;
                                    } else {
                                        return 0.0114150593852;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.0769135803398;
                                    } else {
                                        return 0.23325755809;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.169365084355;
                                    } else {
                                        return -0.0112359085249;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            return 0.0895969484669;
                        } else {
                            return 0.207106072873;
                        }
                    }
                }
            } else {
                if (fs[62] <= -0.5) {
                    return 0.0521681466118;
                } else {
                    if (fs[4] <= 9.5) {
                        if (fs[90] <= 0.5) {
                            return 0.138005104683;
                        } else {
                            return 0.252167575722;
                        }
                    } else {
                        return 0.0970419984463;
                    }
                }
            }
        }
    }
}
