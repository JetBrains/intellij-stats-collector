/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree27 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 19.5) {
                    if (fs[53] <= -1138.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[72] <= 9983.0) {
                                    if (fs[71] <= 0.5) {
                                        return 0.132764946612;
                                    } else {
                                        return 0.0927773210076;
                                    }
                                } else {
                                    return 0.38432374196;
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.232723814674;
                                    } else {
                                        return 0.283812165952;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0134193602904;
                                    } else {
                                        return 0.234326188961;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.217142672914;
                                    } else {
                                        return 0.292104915255;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.200510322109;
                                    } else {
                                        return 0.262871551176;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.243890175417;
                                    } else {
                                        return 0.246019101597;
                                    }
                                } else {
                                    return 0.213181970929;
                                }
                            }
                        }
                    } else {
                        if (fs[59] <= 0.5) {
                            if (fs[27] <= 0.5) {
                                if (fs[53] <= -983.0) {
                                    if (fs[53] <= -1128.5) {
                                        return 0.236853416146;
                                    } else {
                                        return 0.252817380583;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.230062595142;
                                    } else {
                                        return -0.280761107094;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[72] <= 5000.0) {
                                        return 0.378548668664;
                                    } else {
                                        return 0.446293724324;
                                    }
                                } else {
                                    return 0.299437799722;
                                }
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.200584196686;
                                    } else {
                                        return 0.24249796911;
                                    }
                                } else {
                                    return 0.248374423969;
                                }
                            } else {
                                if (fs[72] <= 9990.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.255515941249;
                                    } else {
                                        return 0.319066888266;
                                    }
                                } else {
                                    return 0.197802987168;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[78] <= 0.5) {
                        return 0.113377480599;
                    } else {
                        if (fs[53] <= -1313.0) {
                            if (fs[53] <= -1578.0) {
                                if (fs[4] <= 39.5) {
                                    return -0.13484321348;
                                } else {
                                    return -0.0221845021155;
                                }
                            } else {
                                return -0.196975891285;
                            }
                        } else {
                            if (fs[4] <= 29.0) {
                                return -0.247364393779;
                            } else {
                                return 0.105316950636;
                            }
                        }
                    }
                }
            } else {
                if (fs[4] <= 2.5) {
                    if (fs[0] <= 1.5) {
                        if (fs[41] <= 0.5) {
                            return 0.245296190418;
                        } else {
                            return 0.136589271133;
                        }
                    } else {
                        if (fs[0] <= 4.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[0] <= 2.5) {
                                    return 0.379761466534;
                                } else {
                                    return 0.412523750833;
                                }
                            } else {
                                return 0.522512289282;
                            }
                        } else {
                            return 0.285294498478;
                        }
                    }
                } else {
                    if (fs[4] <= 7.5) {
                        if (fs[59] <= 0.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[30] <= 0.5) {
                                        return 0.0381344559195;
                                    } else {
                                        return 0.358684426035;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0443220012945;
                                    } else {
                                        return 0.206805297558;
                                    }
                                }
                            } else {
                                if (fs[30] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0623884841603;
                                    } else {
                                        return -0.0155736904611;
                                    }
                                } else {
                                    return 0.523079887905;
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.074427215064;
                                    } else {
                                        return 0.700340279024;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.209132611155;
                                    } else {
                                        return 0.301878305281;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1048.0) {
                                    if (fs[0] <= 8.5) {
                                        return 0.19517710124;
                                    } else {
                                        return 0.438801092187;
                                    }
                                } else {
                                    if (fs[53] <= -486.5) {
                                        return -0.0704044663381;
                                    } else {
                                        return -0.0389661425762;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[78] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0367581188715;
                                    } else {
                                        return 0.0292629696181;
                                    }
                                } else {
                                    if (fs[4] <= 31.5) {
                                        return 0.0307069764346;
                                    } else {
                                        return -0.027230978186;
                                    }
                                }
                            } else {
                                if (fs[4] <= 46.5) {
                                    if (fs[4] <= 22.5) {
                                        return -0.0403063424017;
                                    } else {
                                        return -0.0312430557392;
                                    }
                                } else {
                                    return -0.0443139378576;
                                }
                            }
                        } else {
                            if (fs[0] <= 3.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0519386721851;
                                    } else {
                                        return -0.0585665873919;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return -0.0246227350078;
                                    } else {
                                        return -0.034414983816;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[0] <= 6.5) {
                                        return -0.021295035732;
                                    } else {
                                        return -0.0167191296546;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.043549222576;
                                    } else {
                                        return 0.026562327074;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 17.5) {
                    if (fs[12] <= 0.5) {
                        if (fs[88] <= -0.5) {
                            if (fs[2] <= 4.5) {
                                if (fs[78] <= 0.5) {
                                    return 0.0934087949062;
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return -0.465740813181;
                                    } else {
                                        return -0.183554275386;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1288.0) {
                                    return -0.0388247850289;
                                } else {
                                    return 0.300431520966;
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.106895959399;
                                    } else {
                                        return 0.206683002901;
                                    }
                                } else {
                                    if (fs[8] <= 0.5) {
                                        return 0.191554237821;
                                    } else {
                                        return -0.215705296501;
                                    }
                                }
                            } else {
                                if (fs[51] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0470741663686;
                                    } else {
                                        return -0.0318933002985;
                                    }
                                } else {
                                    return 0.350852856059;
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[47] <= -17.5) {
                                if (fs[53] <= -1538.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.260452864452;
                                    } else {
                                        return 0.401507293536;
                                    }
                                } else {
                                    if (fs[28] <= 0.5) {
                                        return 0.261851547607;
                                    } else {
                                        return -0.159498595749;
                                    }
                                }
                            } else {
                                if (fs[64] <= -498.0) {
                                    if (fs[70] <= -4.0) {
                                        return 0.157840136285;
                                    } else {
                                        return 0.263531335737;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0733904314583;
                                    } else {
                                        return 0.183167859207;
                                    }
                                }
                            }
                        } else {
                            if (fs[44] <= 0.5) {
                                if (fs[103] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.24049858764;
                                    } else {
                                        return 0.111129154988;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.2338605173;
                                    } else {
                                        return 0.330376828271;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1948.0) {
                                    return 0.129030236246;
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return 0.35667062124;
                                    } else {
                                        return 0.282863658714;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[101] <= 0.5) {
                        if (fs[65] <= 0.5) {
                            if (fs[24] <= 0.5) {
                                if (fs[72] <= 9803.0) {
                                    if (fs[105] <= 0.5) {
                                        return -0.0319347451184;
                                    } else {
                                        return -0.100990117553;
                                    }
                                } else {
                                    if (fs[29] <= 0.5) {
                                        return 0.122161446601;
                                    } else {
                                        return -0.247660304603;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.336483865319;
                                    } else {
                                        return 0.0158650404254;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.0212941830848;
                                    } else {
                                        return 0.146520278572;
                                    }
                                }
                            }
                        } else {
                            if (fs[89] <= 0.5) {
                                return -0.291627535357;
                            } else {
                                return 0.254298783608;
                            }
                        }
                    } else {
                        if (fs[53] <= -2008.0) {
                            if (fs[60] <= 0.5) {
                                if (fs[76] <= 150.0) {
                                    if (fs[47] <= -1.5) {
                                        return 0.391475536535;
                                    } else {
                                        return 0.474726782334;
                                    }
                                } else {
                                    return 0.252188020387;
                                }
                            } else {
                                if (fs[53] <= -2048.0) {
                                    if (fs[53] <= -9088.5) {
                                        return 0.430825498998;
                                    } else {
                                        return 0.241738572443;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.421790175518;
                                    } else {
                                        return 0.467623209165;
                                    }
                                }
                            }
                        } else {
                            if (fs[26] <= 0.5) {
                                if (fs[2] <= 13.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.105072187319;
                                    } else {
                                        return 0.00491799577449;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.470601090043;
                                    } else {
                                        return 0.327111019666;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1118.0) {
                                    if (fs[97] <= 0.5) {
                                        return -0.119655578512;
                                    } else {
                                        return 0.183767378352;
                                    }
                                } else {
                                    if (fs[53] <= -437.0) {
                                        return 0.358267223028;
                                    } else {
                                        return 0.191168328787;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[76] <= 25.0) {
                        if (fs[72] <= 9931.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[104] <= 0.5) {
                                        return -0.0190672678162;
                                    } else {
                                        return 0.0212437641355;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.014849081236;
                                    } else {
                                        return 0.0840680048194;
                                    }
                                }
                            } else {
                                if (fs[49] <= -1.5) {
                                    return 0.455099416252;
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0595535276161;
                                    } else {
                                        return 0.19729568344;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0775413429919;
                                    } else {
                                        return 0.0101062245867;
                                    }
                                } else {
                                    return 0.331555209076;
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.0790233230174;
                                    } else {
                                        return 0.269617838551;
                                    }
                                } else {
                                    return 0.443559303598;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 8.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.101727379719;
                                    } else {
                                        return 0.0615504109164;
                                    }
                                } else {
                                    if (fs[88] <= 5.5) {
                                        return -0.0269357553051;
                                    } else {
                                        return 0.0136561615733;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0735569829389;
                                    } else {
                                        return -0.013471320219;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0262745742662;
                                    } else {
                                        return 0.242065765594;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 4.5) {
                                if (fs[53] <= -1398.0) {
                                    if (fs[83] <= 0.5) {
                                        return 0.0788591103885;
                                    } else {
                                        return -0.0394914870343;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.00346969039288;
                                    } else {
                                        return 0.0417905161344;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[53] <= -1413.5) {
                                        return 0.0433250521373;
                                    } else {
                                        return -0.0616439286926;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return -0.045012885102;
                                    } else {
                                        return 0.127957450172;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 5.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[47] <= -2.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.00839147055173;
                                    } else {
                                        return 0.0576669043358;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return -0.0114940595881;
                                    } else {
                                        return 0.00607483575139;
                                    }
                                }
                            } else {
                                if (fs[4] <= 15.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.00920319970025;
                                    } else {
                                        return 0.0300597085058;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.00235339461057;
                                    } else {
                                        return 0.0749754933146;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[4] <= 13.5) {
                                        return -0.0351792739662;
                                    } else {
                                        return 0.0373848548969;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.0240557823802;
                                    } else {
                                        return -0.0023650363522;
                                    }
                                }
                            } else {
                                if (fs[70] <= -1.5) {
                                    if (fs[62] <= -2.5) {
                                        return 0.0238771042065;
                                    } else {
                                        return -0.0186101644868;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.00648858428515;
                                    } else {
                                        return 0.0777436981913;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 11.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[47] <= -40706.5) {
                                    return 0.205879564938;
                                } else {
                                    if (fs[25] <= 0.5) {
                                        return -0.0124282041048;
                                    } else {
                                        return -0.00143410773666;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.191608604781;
                                    } else {
                                        return 0.0546777853578;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.032523006919;
                                    } else {
                                        return -0.0201544508966;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[0] <= 20.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.00983356492588;
                                    } else {
                                        return -0.0144825580244;
                                    }
                                } else {
                                    if (fs[27] <= 0.5) {
                                        return -0.015197821108;
                                    } else {
                                        return 0.00607959466332;
                                    }
                                }
                            } else {
                                if (fs[47] <= -94.0) {
                                    if (fs[47] <= -97.0) {
                                        return 0.0776400612412;
                                    } else {
                                        return 0.467478120504;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0302313031587;
                                    } else {
                                        return -0.0236346812837;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
