/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree43 {
    public double calcTree(double... fs) {
        if (fs[27] <= 0.5) {
            if (fs[72] <= 9996.5) {
                if (fs[0] <= 0.5) {
                    if (fs[22] <= 0.5) {
                        if (fs[53] <= -977.0) {
                            if (fs[34] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[74] <= 0.5) {
                                        return 0.0886716911923;
                                    } else {
                                        return -0.0483274024922;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.120766274029;
                                    } else {
                                        return -0.0151366802306;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.290416597765;
                                    } else {
                                        return 0.400110912916;
                                    }
                                } else {
                                    return -0.0244536362266;
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[62] <= -0.5) {
                                    if (fs[49] <= -1.5) {
                                        return 0.221381607181;
                                    } else {
                                        return 0.0981545496766;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.072392825632;
                                    } else {
                                        return -0.0350715278262;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.152996317933;
                                    } else {
                                        return 0.00991246035134;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0974002453432;
                                    } else {
                                        return 0.011263754752;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[47] <= -60.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 6.5) {
                                        return 0.167383346867;
                                    } else {
                                        return 0.302772431352;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.144018115026;
                                    } else {
                                        return 0.0527481051149;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[88] <= 6.0) {
                                        return -0.077780103105;
                                    } else {
                                        return 0.207799134042;
                                    }
                                } else {
                                    if (fs[47] <= -3.5) {
                                        return 0.172132809053;
                                    } else {
                                        return 0.263807472681;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 8.5) {
                                    if (fs[72] <= 9438.0) {
                                        return 0.118388634833;
                                    } else {
                                        return 0.00136711919521;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0609792916518;
                                    } else {
                                        return 0.133667986824;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[72] <= 8954.0) {
                                        return 0.102139658329;
                                    } else {
                                        return 0.0118715542063;
                                    }
                                } else {
                                    if (fs[53] <= -1468.5) {
                                        return 0.141527430974;
                                    } else {
                                        return -0.0524644729703;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0392754136058;
                                    } else {
                                        return -0.0244870892326;
                                    }
                                } else {
                                    if (fs[53] <= -1488.5) {
                                        return 0.0290068480724;
                                    } else {
                                        return 0.00288863976163;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1588.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0136105661689;
                                    } else {
                                        return 0.180294526141;
                                    }
                                } else {
                                    if (fs[4] <= 19.5) {
                                        return 0.00443430226922;
                                    } else {
                                        return -0.0228516518122;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[47] <= -34.5) {
                                        return 0.165920247991;
                                    } else {
                                        return 0.0018372753486;
                                    }
                                } else {
                                    if (fs[72] <= 9993.5) {
                                        return 0.0497796041553;
                                    } else {
                                        return 0.400604140981;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.139679994106;
                                    } else {
                                        return 0.321917740542;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.00583747414628;
                                    } else {
                                        return 0.15710448956;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 7.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.000406331783956;
                                    } else {
                                        return 0.00801911448093;
                                    }
                                } else {
                                    if (fs[72] <= 9450.0) {
                                        return -0.0101758506308;
                                    } else {
                                        return -0.0186605068084;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return -0.0110012160856;
                                    } else {
                                        return 0.0197621303758;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return 0.000868421751992;
                                    } else {
                                        return -0.0187416533372;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= 3.0) {
                                if (fs[47] <= -9727.5) {
                                    if (fs[53] <= -1478.0) {
                                        return 0.193277351833;
                                    } else {
                                        return -0.0270435517241;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.00655795281141;
                                    } else {
                                        return 0.0128155330764;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[72] <= 9598.0) {
                                        return -0.00891247134431;
                                    } else {
                                        return -0.0165798396292;
                                    }
                                } else {
                                    if (fs[72] <= 9731.5) {
                                        return -0.0075946843182;
                                    } else {
                                        return -0.0114904579754;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1052.5) {
                    if (fs[41] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[18] <= -0.5) {
                                if (fs[4] <= 15.5) {
                                    return -0.327032490355;
                                } else {
                                    return -0.115600078099;
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.120695201786;
                                    } else {
                                        return 0.0628070062721;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.126757308256;
                                    } else {
                                        return -0.030271727075;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0245856358371;
                                    } else {
                                        return -0.0164928235564;
                                    }
                                } else {
                                    if (fs[47] <= -16.5) {
                                        return 0.460918557235;
                                    } else {
                                        return 0.155472281493;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[0] <= 16.5) {
                                        return 0.0634552465412;
                                    } else {
                                        return -0.02735363344;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.197986598608;
                                    } else {
                                        return 0.0813559590862;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[84] <= 0.5) {
                            if (fs[60] <= 0.5) {
                                if (fs[72] <= 9997.5) {
                                    return -0.167233923944;
                                } else {
                                    if (fs[43] <= 0.5) {
                                        return 0.409365932252;
                                    } else {
                                        return 0.00560251779823;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[88] <= 0.5) {
                                        return -0.0568351288663;
                                    } else {
                                        return -0.277416489111;
                                    }
                                } else {
                                    if (fs[72] <= 9998.5) {
                                        return -0.351136610626;
                                    } else {
                                        return -0.216857427937;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                return 0.21285172428;
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[72] <= 9998.5) {
                                        return 0.0838949127917;
                                    } else {
                                        return -0.163109566941;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.0665056491855;
                                    } else {
                                        return 0.183212932055;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 9.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[6] <= 0.5) {
                                    if (fs[72] <= 9999.5) {
                                        return -0.0923161909243;
                                    } else {
                                        return -0.387168681843;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.158589286745;
                                    } else {
                                        return 0.0819757539197;
                                    }
                                }
                            } else {
                                if (fs[76] <= 150.0) {
                                    if (fs[72] <= 9999.5) {
                                        return 0.13893441322;
                                    } else {
                                        return 0.00747245119081;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return -0.141564763862;
                                    } else {
                                        return -0.360323892058;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.00957846212766;
                                    } else {
                                        return -0.0408042624382;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.0853393461829;
                                    } else {
                                        return 0.0172410605792;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.116288208194;
                                    } else {
                                        return -0.0739800186427;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return -0.0735180675398;
                                    } else {
                                        return 0.0809656409636;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[79] <= 0.5) {
                            if (fs[32] <= 0.5) {
                                if (fs[62] <= -0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.205824639108;
                                    } else {
                                        return -0.00885541093862;
                                    }
                                } else {
                                    if (fs[50] <= 0.5) {
                                        return -0.00547061988992;
                                    } else {
                                        return -0.146234975538;
                                    }
                                }
                            } else {
                                return 0.453163311173;
                            }
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[88] <= 6.0) {
                                    if (fs[0] <= 0.5) {
                                        return 0.132327733555;
                                    } else {
                                        return -0.000116594262752;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.288145557075;
                                    } else {
                                        return 0.20974781544;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return -0.0254264445704;
                                    } else {
                                        return 0.105663074483;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.17850560802;
                                    } else {
                                        return -0.0344877005658;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[103] <= 1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[49] <= -2.5) {
                        if (fs[53] <= -1118.0) {
                            return -0.3630816903;
                        } else {
                            return 0.198383256366;
                        }
                    } else {
                        if (fs[4] <= 22.5) {
                            if (fs[4] <= 21.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 12.0) {
                                        return 0.198433790257;
                                    } else {
                                        return -0.0242976780934;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0780151091341;
                                    } else {
                                        return 0.13707541377;
                                    }
                                }
                            } else {
                                return 0.273463619016;
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return -0.330757159328;
                            } else {
                                return -0.00471929818934;
                            }
                        }
                    }
                } else {
                    if (fs[62] <= -2.5) {
                        return 0.140737674991;
                    } else {
                        if (fs[6] <= 0.5) {
                            return 0.234881891947;
                        } else {
                            if (fs[4] <= 2.5) {
                                return 0.161790892569;
                            } else {
                                if (fs[64] <= -998.5) {
                                    return 0.115942976393;
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.0458280101926;
                                    } else {
                                        return -0.0186347247684;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[45] <= 0.5) {
                    if (fs[41] <= 0.5) {
                        if (fs[64] <= -996.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[53] <= -1138.5) {
                                    if (fs[58] <= 0.5) {
                                        return 0.123091554421;
                                    } else {
                                        return 0.0396746322463;
                                    }
                                } else {
                                    if (fs[53] <= -1028.5) {
                                        return 0.136794291333;
                                    } else {
                                        return 0.196213391316;
                                    }
                                }
                            } else {
                                return 0.367426096802;
                            }
                        } else {
                            if (fs[0] <= 5.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.00505934681447;
                                    } else {
                                        return 0.108173915331;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0430038854843;
                                    } else {
                                        return 0.151494532181;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.163415926622;
                                } else {
                                    return 0.480300802905;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 11.5) {
                            if (fs[0] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    return -0.120255047519;
                                } else {
                                    return 0.00123162122044;
                                }
                            } else {
                                return 0.139258919524;
                            }
                        } else {
                            return -0.346119789605;
                        }
                    }
                } else {
                    if (fs[53] <= 17.5) {
                        if (fs[62] <= -2.5) {
                            return 0.0564392569538;
                        } else {
                            if (fs[53] <= -986.5) {
                                if (fs[78] <= 0.5) {
                                    return 0.058562714554;
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return 0.026765516291;
                                    } else {
                                        return -0.0187633590525;
                                    }
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0382377921223;
                                    } else {
                                        return -0.01182615609;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return -0.00726665338118;
                                    } else {
                                        return 0.0063126369417;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            return 0.130809054632;
                        } else {
                            if (fs[4] <= 14.5) {
                                return -0.0177081977148;
                            } else {
                                return 0.0657638356995;
                            }
                        }
                    }
                }
            }
        }
    }
}
