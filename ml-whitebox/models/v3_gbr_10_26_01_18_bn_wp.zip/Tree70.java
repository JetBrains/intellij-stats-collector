/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree70 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9999.5) {
            if (fs[103] <= 1.5) {
                if (fs[4] <= 7.5) {
                    if (fs[76] <= 75.0) {
                        if (fs[49] <= -0.5) {
                            if (fs[70] <= -4.0) {
                                if (fs[4] <= 5.5) {
                                    return 0.032810807172;
                                } else {
                                    return -0.202168525764;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.201772548332;
                                    } else {
                                        return 0.131789543749;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.0581823971367;
                                    } else {
                                        return -0.0143636677026;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[88] <= -0.5) {
                                        return -0.209901454009;
                                    } else {
                                        return 0.0267595121078;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.00367032197247;
                                    } else {
                                        return -0.0777613605273;
                                    }
                                }
                            } else {
                                if (fs[81] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 4.60897937251e-05;
                                    } else {
                                        return 0.0523837763337;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return -0.00188809322145;
                                    } else {
                                        return 0.0378728235621;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[24] <= 0.5) {
                                if (fs[72] <= 9390.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0580905013501;
                                    } else {
                                        return 0.00470296471882;
                                    }
                                } else {
                                    if (fs[53] <= -1488.0) {
                                        return -0.0387335134805;
                                    } else {
                                        return -0.00425231173161;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.118513786656;
                                    } else {
                                        return 0.043606141961;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0844109696273;
                                    } else {
                                        return 0.359861209283;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[47] <= -0.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.14765996197;
                                    } else {
                                        return 0.0768263062852;
                                    }
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.0542782896514;
                                    } else {
                                        return -0.245534817232;
                                    }
                                }
                            } else {
                                if (fs[47] <= -15304.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.334565227721;
                                    } else {
                                        return -0.121094104635;
                                    }
                                } else {
                                    if (fs[53] <= -992.0) {
                                        return 0.0466683931229;
                                    } else {
                                        return -0.00821996272829;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[62] <= -1.5) {
                        if (fs[53] <= -1108.0) {
                            if (fs[41] <= 0.5) {
                                if (fs[2] <= 4.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0189379977501;
                                    } else {
                                        return 0.104746194378;
                                    }
                                } else {
                                    if (fs[64] <= -993.0) {
                                        return 0.0210438627993;
                                    } else {
                                        return -0.0315986264363;
                                    }
                                }
                            } else {
                                return 0.434330681792;
                            }
                        } else {
                            if (fs[47] <= -11.5) {
                                if (fs[23] <= 0.5) {
                                    return -0.0478344239897;
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.306663040296;
                                    } else {
                                        return -0.0265982249634;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.180628435802;
                                    } else {
                                        return 0.0483517386354;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return 0.214873722427;
                                    } else {
                                        return -0.00306283270417;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 5.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[34] <= 0.5) {
                                        return -0.00200180023626;
                                    } else {
                                        return 0.0422638725136;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.00690957893628;
                                    } else {
                                        return -0.00135073351077;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0802018447456;
                                    } else {
                                        return 0.0857393653565;
                                    }
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return -0.155284524104;
                                    } else {
                                        return 0.183013663208;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9998.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0230081374383;
                                    } else {
                                        return -0.0042132098201;
                                    }
                                } else {
                                    if (fs[2] <= 9.5) {
                                        return 0.0323303502683;
                                    } else {
                                        return 0.109876698358;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[22] <= 0.5) {
                                        return -0.0402890951806;
                                    } else {
                                        return 0.052202125576;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.204134747838;
                                    } else {
                                        return -0.0343665941117;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[45] <= 0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[53] <= -1014.0) {
                            if (fs[0] <= 13.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0194441018342;
                                    } else {
                                        return 0.120298993229;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return 0.037187826626;
                                    } else {
                                        return 0.162490473018;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.426026139692;
                                    } else {
                                        return 0.325851132706;
                                    }
                                } else {
                                    if (fs[0] <= 36.5) {
                                        return 0.106903870906;
                                    } else {
                                        return 0.308537096025;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -0.5) {
                                return 0.0864687502472;
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return -0.141960217999;
                                    } else {
                                        return -0.0482349939319;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.00797513482761;
                                    } else {
                                        return -0.0483107557134;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[4] <= 12.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.193577285101;
                                    } else {
                                        return -0.325649396221;
                                    }
                                } else {
                                    return -0.133666777733;
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    return 0.0721098861878;
                                } else {
                                    return -0.18903199652;
                                }
                            }
                        } else {
                            if (fs[2] <= 7.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.0304219906719;
                                    } else {
                                        return 0.0114126913951;
                                    }
                                } else {
                                    return -0.102743976395;
                                }
                            } else {
                                return 0.181500732503;
                            }
                        }
                    }
                } else {
                    if (fs[49] <= -2.5) {
                        if (fs[0] <= 1.5) {
                            return 0.100710958579;
                        } else {
                            if (fs[0] <= 4.5) {
                                return -0.0499640632566;
                            } else {
                                return 0.00216300993012;
                            }
                        }
                    } else {
                        if (fs[64] <= -994.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[27] <= 0.5) {
                                        return -0.00438544200325;
                                    } else {
                                        return -0.00888650125196;
                                    }
                                } else {
                                    if (fs[27] <= 0.5) {
                                        return -0.00858025008832;
                                    } else {
                                        return -0.0622976082211;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0629149032318;
                                    } else {
                                        return -0.00715322339844;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0119513924136;
                                    } else {
                                        return 0.000110657178572;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[53] <= -981.5) {
                                        return -0.00422279544297;
                                    } else {
                                        return -0.00193486662508;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.0294897786717;
                                    } else {
                                        return -0.00781665419379;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0218204246823;
                                    } else {
                                        return -0.0184566115149;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.010172440492;
                                    } else {
                                        return -0.00330453198668;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[71] <= 0.5) {
                if (fs[4] <= 32.5) {
                    if (fs[4] <= 23.5) {
                        if (fs[4] <= 17.5) {
                            if (fs[4] <= 12.5) {
                                if (fs[93] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0442612102186;
                                    } else {
                                        return -0.0040144983713;
                                    }
                                } else {
                                    return -0.199962907133;
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0365508354023;
                                    } else {
                                        return 0.187438242013;
                                    }
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return -0.0890559162983;
                                    } else {
                                        return 0.200917930314;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[53] <= -1513.0) {
                                    return 0.219992129521;
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0569986713463;
                                    } else {
                                        return -0.135381522844;
                                    }
                                }
                            } else {
                                if (fs[47] <= -2.5) {
                                    if (fs[4] <= 19.5) {
                                        return -0.425790015309;
                                    } else {
                                        return -0.21426366739;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0274785341244;
                                    } else {
                                        return -0.312613461849;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 3.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[4] <= 29.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.119955069054;
                                    } else {
                                        return -0.068196045105;
                                    }
                                } else {
                                    return 0.277691902565;
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[92] <= 0.5) {
                                        return 0.00555533358832;
                                    } else {
                                        return 0.234908696036;
                                    }
                                } else {
                                    return 0.373541618443;
                                }
                            }
                        } else {
                            return -0.0705938945037;
                        }
                    }
                } else {
                    if (fs[22] <= 0.5) {
                        return -0.0654252099596;
                    } else {
                        return -0.359265474519;
                    }
                }
            } else {
                if (fs[18] <= 0.5) {
                    if (fs[8] <= 0.5) {
                        if (fs[53] <= -1047.5) {
                            if (fs[83] <= 0.5) {
                                if (fs[4] <= 18.5) {
                                    if (fs[88] <= -0.5) {
                                        return -0.367321510496;
                                    } else {
                                        return 0.0590256900998;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.10152673401;
                                    } else {
                                        return -0.0844150137905;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.0) {
                                    return -0.326929674572;
                                } else {
                                    return -0.076109582181;
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0239355509217;
                                    } else {
                                        return -0.07324082315;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.147232548547;
                                    } else {
                                        return 0.000927307877065;
                                    }
                                }
                            } else {
                                if (fs[27] <= 0.5) {
                                    if (fs[47] <= -4.5) {
                                        return -0.055881692508;
                                    } else {
                                        return 0.1196311965;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.156100674232;
                                    } else {
                                        return -0.0240423789675;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[26] <= 0.5) {
                            return 0.00117371632641;
                        } else {
                            return -0.370569773434;
                        }
                    }
                } else {
                    if (fs[101] <= 1.5) {
                        if (fs[78] <= 0.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[47] <= -2.5) {
                                    return -0.202466961404;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.192545811885;
                                    } else {
                                        return -0.024087637727;
                                    }
                                }
                            } else {
                                if (fs[4] <= 12.0) {
                                    if (fs[4] <= 6.5) {
                                        return 0.00521590890373;
                                    } else {
                                        return -0.23610723743;
                                    }
                                } else {
                                    return 0.179791794173;
                                }
                            }
                        } else {
                            if (fs[47] <= -394.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[47] <= -2365.5) {
                                        return 0.209259582288;
                                    } else {
                                        return 0.0273701425669;
                                    }
                                } else {
                                    if (fs[4] <= 8.0) {
                                        return 0.17153111818;
                                    } else {
                                        return 0.293057441165;
                                    }
                                }
                            } else {
                                if (fs[4] <= 5.5) {
                                    if (fs[47] <= -46.0) {
                                        return -0.13366432933;
                                    } else {
                                        return 0.0432346916023;
                                    }
                                } else {
                                    if (fs[88] <= 1.5) {
                                        return -0.0238699981719;
                                    } else {
                                        return 0.0179216216654;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -5.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[53] <= -1108.0) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0118037117463;
                                    } else {
                                        return 0.139600706657;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0638919290609;
                                    } else {
                                        return 0.284219089744;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return -0.0127392708549;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.00973027849929;
                                    } else {
                                        return -0.0144548207019;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -0.5) {
                                if (fs[76] <= 250.0) {
                                    if (fs[53] <= -1128.0) {
                                        return 0.323873790681;
                                    } else {
                                        return 0.153061387794;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.165049581494;
                                    } else {
                                        return -0.0444795117346;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[53] <= -1128.0) {
                                        return -0.260684533012;
                                    } else {
                                        return -0.063844155675;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return -0.0013544178104;
                                    } else {
                                        return 0.269336206454;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
