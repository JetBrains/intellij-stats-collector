/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree77 {
    public double calcTree(double... fs) {
        if (fs[57] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[53] <= -1498.5) {
                    if (fs[2] <= 0.5) {
                        return -0.242211892681;
                    } else {
                        if (fs[4] <= 18.5) {
                            if (fs[85] <= 0.5) {
                                if (fs[76] <= 250.0) {
                                    if (fs[99] <= 0.5) {
                                        return 0.122019685811;
                                    } else {
                                        return 0.0457802992713;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0815616321912;
                                    } else {
                                        return 0.0322027563538;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[47] <= -1.5) {
                                        return 0.174563420708;
                                    } else {
                                        return -0.0880917202927;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.103085415001;
                                    } else {
                                        return 0.0214768862165;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -1.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.0166339418774;
                                    } else {
                                        return -0.0992226759469;
                                    }
                                } else {
                                    if (fs[4] <= 41.5) {
                                        return 0.0997772798176;
                                    } else {
                                        return -0.101526129997;
                                    }
                                }
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0412796030966;
                                    } else {
                                        return -0.266046904798;
                                    }
                                } else {
                                    if (fs[76] <= 100.0) {
                                        return -0.253294051769;
                                    } else {
                                        return -0.16129030062;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 1.5) {
                        if (fs[47] <= -3436.0) {
                            if (fs[101] <= 0.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.253396564561;
                                    } else {
                                        return -0.0867009446633;
                                    }
                                } else {
                                    if (fs[47] <= -15379.5) {
                                        return -0.310683345249;
                                    } else {
                                        return 0.103672918401;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return 0.168597109422;
                                } else {
                                    return 0.322345463862;
                                }
                            }
                        } else {
                            if (fs[53] <= -1483.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.00730417478487;
                                    } else {
                                        return -0.0717415329554;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.20617403527;
                                    } else {
                                        return 0.0268113560409;
                                    }
                                }
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[53] <= -987.5) {
                                        return 0.0141822778195;
                                    } else {
                                        return -0.0181160827149;
                                    }
                                } else {
                                    if (fs[47] <= -24.5) {
                                        return 0.222738522232;
                                    } else {
                                        return 0.0927234402102;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[41] <= 0.5) {
                            if (fs[4] <= 26.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[88] <= -0.5) {
                                        return -0.0863465255258;
                                    } else {
                                        return 0.0209125006191;
                                    }
                                } else {
                                    if (fs[64] <= -997.5) {
                                        return 0.183634271297;
                                    } else {
                                        return -0.165861341825;
                                    }
                                }
                            } else {
                                if (fs[86] <= 0.5) {
                                    if (fs[47] <= -11.5) {
                                        return 0.113937449763;
                                    } else {
                                        return -0.0772920309364;
                                    }
                                } else {
                                    if (fs[53] <= -1133.0) {
                                        return -0.13995652815;
                                    } else {
                                        return 0.290982839301;
                                    }
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[47] <= -363.5) {
                                    if (fs[47] <= -2335.5) {
                                        return 0.0107506075616;
                                    } else {
                                        return 0.198876743853;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.0199655296234;
                                    } else {
                                        return 0.162327200399;
                                    }
                                }
                            } else {
                                if (fs[51] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0303914995531;
                                    } else {
                                        return -0.0921758044521;
                                    }
                                } else {
                                    return 0.201230766528;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[4] <= 16.5) {
                        if (fs[53] <= -1478.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[2] <= 6.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.00277974874475;
                                    } else {
                                        return 0.0207467834461;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0103050967804;
                                    } else {
                                        return 0.301536851576;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.122740085164;
                                    } else {
                                        return 0.286733504557;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0975351051435;
                                    } else {
                                        return -0.00118341522627;
                                    }
                                }
                            }
                        } else {
                            if (fs[105] <= 0.5) {
                                if (fs[52] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0120219497148;
                                    } else {
                                        return -0.0132589251513;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.0164730712717;
                                    } else {
                                        return -0.0194726803665;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9981.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.0135723529216;
                                    } else {
                                        return 0.0145685755691;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.0703181364725;
                                    } else {
                                        return 0.0492421757157;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -4488.0) {
                            return 0.37409674194;
                        } else {
                            if (fs[83] <= 0.5) {
                                if (fs[31] <= 0.5) {
                                    if (fs[4] <= 30.5) {
                                        return -0.00328537572725;
                                    } else {
                                        return -0.0239501979511;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.212859095945;
                                    } else {
                                        return 0.0895486279632;
                                    }
                                }
                            } else {
                                if (fs[4] <= 33.5) {
                                    if (fs[47] <= -17.5) {
                                        return -0.160652654812;
                                    } else {
                                        return -0.0567794717745;
                                    }
                                } else {
                                    return 0.0602843247303;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 11.5) {
                        if (fs[53] <= -56.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[53] <= -987.0) {
                                    if (fs[4] <= 24.5) {
                                        return -0.000538192860301;
                                    } else {
                                        return -0.00462643233339;
                                    }
                                } else {
                                    if (fs[72] <= 9055.0) {
                                        return -0.00632666193017;
                                    } else {
                                        return -0.022602771024;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.0238372737928;
                                    } else {
                                        return -0.00797399614485;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.000886303568664;
                                    } else {
                                        return 0.213052549027;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.00133695097676;
                                    } else {
                                        return 0.00350223181166;
                                    }
                                } else {
                                    if (fs[72] <= 9904.0) {
                                        return 0.0205462999226;
                                    } else {
                                        return 0.204158055525;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0179129473863;
                                    } else {
                                        return -0.0148650672038;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.00224341526961;
                                    } else {
                                        return 0.0130564678022;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[72] <= 9996.5) {
                                        return -0.00221104480802;
                                    } else {
                                        return -0.0308763078374;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return 0.0261599623257;
                                    } else {
                                        return -0.00208823191445;
                                    }
                                }
                            } else {
                                if (fs[94] <= 0.5) {
                                    if (fs[47] <= -160.5) {
                                        return -0.0146921899584;
                                    } else {
                                        return -0.00419178565922;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0680359048789;
                                    } else {
                                        return -0.00463838115045;
                                    }
                                }
                            }
                        } else {
                            if (fs[25] <= 0.5) {
                                if (fs[72] <= 9997.5) {
                                    if (fs[15] <= 0.5) {
                                        return -0.00120276873433;
                                    } else {
                                        return 0.0390599787953;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.140347762685;
                                    } else {
                                        return 0.00341631065759;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[72] <= 9998.5) {
                                        return -0.00261591340712;
                                    } else {
                                        return -0.0390573666296;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.00262288368254;
                                    } else {
                                        return 0.152349036691;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[6] <= 0.5) {
                return -0.170249122838;
            } else {
                if (fs[103] <= 0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[4] <= 14.5) {
                            if (fs[72] <= 9989.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0567484456847;
                                    } else {
                                        return 0.20400246866;
                                    }
                                } else {
                                    if (fs[53] <= -476.5) {
                                        return -0.0613683136159;
                                    } else {
                                        return 0.0129407046002;
                                    }
                                }
                            } else {
                                return -0.267178275062;
                            }
                        } else {
                            if (fs[0] <= 3.0) {
                                return -0.171297157458;
                            } else {
                                return -0.0442448197362;
                            }
                        }
                    } else {
                        if (fs[79] <= 0.5) {
                            if (fs[47] <= -4.0) {
                                if (fs[12] <= 0.5) {
                                    return -0.162792650816;
                                } else {
                                    return 0.13142532282;
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.167248909396;
                                    } else {
                                        return 0.0441625554367;
                                    }
                                } else {
                                    return -0.113119191787;
                                }
                            }
                        } else {
                            return -0.102679485978;
                        }
                    }
                } else {
                    if (fs[49] <= -2.5) {
                        return 0.134530279088;
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0532123114355;
                                    } else {
                                        return 0.123452041725;
                                    }
                                } else {
                                    if (fs[4] <= 15.5) {
                                        return -0.0819141317555;
                                    } else {
                                        return 0.0524994839299;
                                    }
                                }
                            } else {
                                if (fs[49] <= -0.5) {
                                    return 0.0652351039157;
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.144150679203;
                                    } else {
                                        return 0.19827785081;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    return -0.0258681488653;
                                } else {
                                    if (fs[47] <= -2.5) {
                                        return -0.0061826143185;
                                    } else {
                                        return -0.0105483815862;
                                    }
                                }
                            } else {
                                if (fs[53] <= -981.5) {
                                    return -0.032825458984;
                                } else {
                                    return -0.0249271183842;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
