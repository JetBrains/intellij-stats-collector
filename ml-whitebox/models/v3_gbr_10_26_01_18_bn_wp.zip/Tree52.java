/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree52 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[4] <= 7.5) {
                if (fs[0] <= 1.5) {
                    if (fs[53] <= -1138.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.0951379649869;
                                    } else {
                                        return -0.0301286586681;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.0873130481217;
                                    } else {
                                        return -0.0488270694255;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return -0.00165778442568;
                                    } else {
                                        return 0.127809839885;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.0210467173864;
                                    } else {
                                        return 0.0192521309632;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[78] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0438869145653;
                                    } else {
                                        return 0.0484923356557;
                                    }
                                } else {
                                    if (fs[33] <= 0.5) {
                                        return 0.0613088169564;
                                    } else {
                                        return -0.0795339805428;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.0700194092573;
                                    } else {
                                        return 0.0122157865086;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0718344075813;
                                    } else {
                                        return 0.0846674727727;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1038.5) {
                            if (fs[4] <= 5.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.0878911149178;
                                    } else {
                                        return 0.0732240835738;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.119234311719;
                                    } else {
                                        return 0.0681240261182;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0910096768273;
                                    } else {
                                        return 0.0646828662583;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0290228534721;
                                    } else {
                                        return -0.0976135728442;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return 0.206814904297;
                                    } else {
                                        return 0.103370970271;
                                    }
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return 0.0397301629226;
                                    } else {
                                        return -0.0845436517746;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return -0.054393982852;
                                    } else {
                                        return 0.0505838725575;
                                    }
                                } else {
                                    return 0.111694474806;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[60] <= 0.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[53] <= -1053.0) {
                                return 0.0950620109549;
                            } else {
                                if (fs[78] <= 0.5) {
                                    return -0.0411412039876;
                                } else {
                                    if (fs[0] <= 3.5) {
                                        return -0.121511689042;
                                    } else {
                                        return -0.0400617485479;
                                    }
                                }
                            }
                        } else {
                            return -0.106493006098;
                        }
                    } else {
                        if (fs[30] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0143022028104;
                                    } else {
                                        return -0.00711012426141;
                                    }
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return -0.0210577087358;
                                    } else {
                                        return 0.100310961625;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return 0.0106563054913;
                                } else {
                                    return 0.220838570976;
                                }
                            }
                        } else {
                            return 0.354850015136;
                        }
                    }
                }
            } else {
                if (fs[70] <= -1.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 8.5) {
                                        return 0.219771910865;
                                    } else {
                                        return 0.148984348838;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.0663104864062;
                                    } else {
                                        return 0.10568745178;
                                    }
                                }
                            } else {
                                return -0.28606869478;
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[2] <= 1.5) {
                                    return -0.148058758563;
                                } else {
                                    return -0.124206715619;
                                }
                            } else {
                                return 0.0989689244201;
                            }
                        }
                    } else {
                        if (fs[0] <= 7.5) {
                            if (fs[4] <= 8.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0414440235359;
                                    } else {
                                        return -0.0495844305715;
                                    }
                                } else {
                                    return -0.0540372802761;
                                }
                            } else {
                                if (fs[4] <= 90.5) {
                                    if (fs[53] <= -1288.0) {
                                        return -0.0513420156619;
                                    } else {
                                        return -0.0266279289581;
                                    }
                                } else {
                                    return 0.040789096904;
                                }
                            }
                        } else {
                            if (fs[0] <= 9.5) {
                                if (fs[11] <= 0.5) {
                                    return -0.0265682281649;
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return 0.146246883541;
                                    } else {
                                        return 0.174700838787;
                                    }
                                }
                            } else {
                                if (fs[0] <= 14.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0120601012906;
                                    } else {
                                        return -0.0343948658298;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.0179312419902;
                                    } else {
                                        return -0.00279112079533;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[76] <= 100.0) {
                        if (fs[53] <= 3.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[72] <= 9997.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.089600482946;
                                    } else {
                                        return 0.0998880054829;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.192078696203;
                                    } else {
                                        return 0.110596753829;
                                    }
                                }
                            } else {
                                return -0.046630432342;
                            }
                        } else {
                            if (fs[4] <= 12.0) {
                                return -0.0262718105836;
                            } else {
                                return -0.0219619913166;
                            }
                        }
                    } else {
                        if (fs[72] <= 4847.0) {
                            if (fs[0] <= 2.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[53] <= -1328.0) {
                                        return -0.0865465991245;
                                    } else {
                                        return 0.057217542799;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.019880149741;
                                    } else {
                                        return 0.00797015913579;
                                    }
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return -0.00726731013885;
                                    } else {
                                        return -0.00136134213649;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.0254228766455;
                                    } else {
                                        return 0.00897866924795;
                                    }
                                }
                            }
                        } else {
                            return 0.0778896471998;
                        }
                    }
                }
            }
        } else {
            if (fs[103] <= 1.5) {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[53] <= -967.0) {
                                if (fs[74] <= 0.5) {
                                    if (fs[95] <= 0.5) {
                                        return 0.0523222408672;
                                    } else {
                                        return 0.121719945435;
                                    }
                                } else {
                                    if (fs[53] <= -1138.5) {
                                        return -0.0832839766629;
                                    } else {
                                        return 0.0789846134762;
                                    }
                                }
                            } else {
                                if (fs[47] <= -17.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.132421086654;
                                    } else {
                                        return -0.199610374417;
                                    }
                                } else {
                                    if (fs[72] <= 9988.0) {
                                        return -0.0277339382792;
                                    } else {
                                        return 0.0576720158619;
                                    }
                                }
                            }
                        } else {
                            if (fs[34] <= 0.5) {
                                if (fs[53] <= -1513.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.12671519342;
                                    } else {
                                        return 0.122521228351;
                                    }
                                } else {
                                    if (fs[53] <= -1488.5) {
                                        return -0.0593552359145;
                                    } else {
                                        return -0.0045208535434;
                                    }
                                }
                            } else {
                                if (fs[53] <= -546.5) {
                                    if (fs[47] <= -0.5) {
                                        return 0.239410026117;
                                    } else {
                                        return 0.00336031267881;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.165047058089;
                                    } else {
                                        return -0.0769796158739;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[22] <= 0.5) {
                                if (fs[88] <= 5.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.0272482716786;
                                    } else {
                                        return 0.0735263691048;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0593179286957;
                                    } else {
                                        return 0.13220037488;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.0) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0517030642545;
                                    } else {
                                        return 0.081543925603;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.249260395839;
                                    } else {
                                        return 0.101703372922;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 27.5) {
                                if (fs[43] <= 0.5) {
                                    if (fs[18] <= -0.5) {
                                        return -0.220398075181;
                                    } else {
                                        return 0.0751762806105;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return -0.201298741825;
                                    } else {
                                        return -0.0102871349111;
                                    }
                                }
                            } else {
                                if (fs[53] <= -2233.0) {
                                    if (fs[12] <= 0.5) {
                                        return 0.248601040432;
                                    } else {
                                        return 0.0495503826692;
                                    }
                                } else {
                                    if (fs[47] <= -12.5) {
                                        return 0.192768250355;
                                    } else {
                                        return -0.0928772380098;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[72] <= 9897.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.000716863919398;
                                    } else {
                                        return -0.0108971772856;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0113153810367;
                                    } else {
                                        return 0.130542088053;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0187878976145;
                                    } else {
                                        return 0.0052101079224;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0721023737721;
                                    } else {
                                        return 0.0954051450816;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1478.5) {
                                if (fs[76] <= 75.0) {
                                    if (fs[29] <= 0.5) {
                                        return 0.0161964576203;
                                    } else {
                                        return 0.108822951579;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.0377111604978;
                                    } else {
                                        return 0.110527165054;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0287959600419;
                                    } else {
                                        return 0.0774021026416;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.0175822481434;
                                    } else {
                                        return -0.0101740120293;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[72] <= 9998.5) {
                                if (fs[4] <= 21.5) {
                                    if (fs[0] <= 7.5) {
                                        return -0.00157632572222;
                                    } else {
                                        return -0.00415423475904;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return -0.00537563263488;
                                    } else {
                                        return -0.0200419144404;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 21.5) {
                                        return 0.0318750150219;
                                    } else {
                                        return -0.013857096511;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.0148650614719;
                                    } else {
                                        return -0.00793323081288;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= 3.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[72] <= 9995.5) {
                                        return 0.0316700573037;
                                    } else {
                                        return 0.212580293551;
                                    }
                                } else {
                                    return 0.507007431559;
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.00795242808757;
                                    } else {
                                        return -0.0211092279306;
                                    }
                                } else {
                                    if (fs[53] <= 7.5) {
                                        return -0.00788014926773;
                                    } else {
                                        return -0.00958073197466;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1033.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[0] <= 13.5) {
                            if (fs[64] <= -996.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0867436218202;
                                    } else {
                                        return 0.290116834449;
                                    }
                                } else {
                                    return -0.0656415561303;
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[44] <= 0.5) {
                                        return 0.0546292863891;
                                    } else {
                                        return 0.217402645844;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.205395046899;
                                    } else {
                                        return -0.0075031813296;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 1.5) {
                                return 0.262237744498;
                            } else {
                                if (fs[2] <= 3.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.495129710423;
                                    } else {
                                        return 0.318440616428;
                                    }
                                } else {
                                    return 0.498528186141;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 8.5) {
                            if (fs[72] <= 9989.5) {
                                if (fs[62] <= -2.5) {
                                    return -0.177040242735;
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0457620980062;
                                    } else {
                                        return -0.000443549195626;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    return -0.313165974667;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0881252122634;
                                    } else {
                                        return -0.0320513666928;
                                    }
                                }
                            }
                        } else {
                            return 0.216594632597;
                        }
                    }
                } else {
                    if (fs[53] <= -993.5) {
                        return -0.0973138525101;
                    } else {
                        if (fs[4] <= 4.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[53] <= -491.5) {
                                    return 0.0676740700505;
                                } else {
                                    if (fs[0] <= 0.5) {
                                        return -0.313133831149;
                                    } else {
                                        return -0.0499561790716;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0122112065822;
                                    } else {
                                        return -0.00699350871755;
                                    }
                                } else {
                                    if (fs[58] <= 0.5) {
                                        return -0.00538385846173;
                                    } else {
                                        return 0.000570100204232;
                                    }
                                }
                            }
                        } else {
                            if (fs[49] <= -2.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0732940354933;
                                    } else {
                                        return 0.143487593705;
                                    }
                                } else {
                                    return 0.133490422589;
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0421815948966;
                                    } else {
                                        return -0.0360263319903;
                                    }
                                } else {
                                    if (fs[72] <= 9983.5) {
                                        return -0.00414184649295;
                                    } else {
                                        return -0.0160575869731;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
