/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree67 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[41] <= 0.5) {
                if (fs[24] <= 0.5) {
                    if (fs[88] <= -0.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[4] <= 5.0) {
                                    return 0.0944139449165;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.232368099756;
                                    } else {
                                        return 0.104907125823;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[72] <= 9834.0) {
                                        return -0.0898261654112;
                                    } else {
                                        return -0.37040631465;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0678283911014;
                                    } else {
                                        return -0.245820976761;
                                    }
                                }
                            }
                        } else {
                            return 0.247071629611;
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[53] <= -977.5) {
                                if (fs[53] <= -1138.0) {
                                    if (fs[53] <= -1498.5) {
                                        return 0.0670815582358;
                                    } else {
                                        return 0.0177663191066;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0481422389329;
                                    } else {
                                        return 0.0993251023121;
                                    }
                                }
                            } else {
                                if (fs[2] <= 4.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0403079856447;
                                    } else {
                                        return -0.0163132101231;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.0627735724483;
                                    } else {
                                        return -0.128566687917;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.142835630195;
                                    } else {
                                        return 0.0282817825476;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return -0.112611501287;
                                    } else {
                                        return 0.142038845053;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    return -0.0511894391564;
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.141674016132;
                                    } else {
                                        return 0.243722808194;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 7.5) {
                        if (fs[101] <= 0.5) {
                            if (fs[47] <= -0.5) {
                                if (fs[53] <= -1948.0) {
                                    if (fs[4] <= 8.5) {
                                        return 0.0884308409569;
                                    } else {
                                        return 0.206557866329;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.020498779701;
                                    } else {
                                        return 0.0574664281056;
                                    }
                                }
                            } else {
                                return -0.214882225157;
                            }
                        } else {
                            if (fs[101] <= 1.5) {
                                if (fs[72] <= 9982.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.334773130719;
                                    } else {
                                        return 0.223163325792;
                                    }
                                } else {
                                    if (fs[47] <= -167.5) {
                                        return 0.110295941549;
                                    } else {
                                        return 0.178370226284;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.0) {
                                    if (fs[53] <= -491.5) {
                                        return 0.234641135043;
                                    } else {
                                        return 0.0399512304279;
                                    }
                                } else {
                                    if (fs[72] <= 9990.0) {
                                        return -0.010419113738;
                                    } else {
                                        return -0.144403708095;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[14] <= 0.5) {
                                if (fs[48] <= 0.5) {
                                    return 0.292443745248;
                                } else {
                                    return 0.363809973434;
                                }
                            } else {
                                return 0.148239669289;
                            }
                        } else {
                            if (fs[47] <= -75.0) {
                                if (fs[52] <= 0.5) {
                                    return 0.000543491752661;
                                } else {
                                    return 0.0740546162447;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[52] <= 0.5) {
                                        return 0.124564958259;
                                    } else {
                                        return 0.206088763641;
                                    }
                                } else {
                                    if (fs[72] <= 9815.0) {
                                        return 0.167212177524;
                                    } else {
                                        return 0.102764394126;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1928.0) {
                    if (fs[99] <= 0.5) {
                        if (fs[72] <= 9837.5) {
                            if (fs[4] <= 8.5) {
                                return -0.119247534952;
                            } else {
                                if (fs[71] <= 0.5) {
                                    return 0.295443253433;
                                } else {
                                    return -0.00861478016359;
                                }
                            }
                        } else {
                            return -0.257857287611;
                        }
                    } else {
                        return 0.380039720405;
                    }
                } else {
                    if (fs[71] <= 0.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[101] <= 0.5) {
                                    return 0.079622897121;
                                } else {
                                    return 0.239179430541;
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.266786277824;
                                    } else {
                                        return -0.104988784849;
                                    }
                                } else {
                                    if (fs[53] <= -1448.5) {
                                        return 0.0112504499744;
                                    } else {
                                        return -0.169907730275;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    return 0.13770910249;
                                } else {
                                    return 0.103588312488;
                                }
                            } else {
                                if (fs[79] <= 0.5) {
                                    return 0.0577832967807;
                                } else {
                                    return 0.0679908160039;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    return -0.264763997708;
                                } else {
                                    return -0.204136346196;
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[53] <= -1478.0) {
                                        return -0.0800178152113;
                                    } else {
                                        return 0.12185216389;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.187586136749;
                                    } else {
                                        return -0.0891762856011;
                                    }
                                }
                            }
                        } else {
                            if (fs[51] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.0389805656879;
                                    } else {
                                        return 0.13585562745;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return -0.212978237404;
                                    } else {
                                        return -0.0325590020164;
                                    }
                                }
                            } else {
                                return 0.154016472999;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[72] <= 9999.5) {
                if (fs[55] <= 0.5) {
                    if (fs[45] <= 0.5) {
                        if (fs[103] <= 1.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[47] <= -364.5) {
                                        return 0.0132489648299;
                                    } else {
                                        return -0.00140174887992;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.134429470941;
                                    } else {
                                        return 0.0270463025577;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3.5) {
                                    return -0.132398077694;
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0349998180337;
                                    } else {
                                        return 0.20801534878;
                                    }
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[0] <= 31.5) {
                                    if (fs[6] <= 0.5) {
                                        return 0.255068924506;
                                    } else {
                                        return 0.0263858669915;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.053410264501;
                                    } else {
                                        return 0.427403916676;
                                    }
                                }
                            } else {
                                if (fs[4] <= 17.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.132805716984;
                                    } else {
                                        return -0.0365299279442;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.0832448462649;
                                    } else {
                                        return -0.0187615766453;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[27] <= 0.5) {
                                    if (fs[72] <= 9614.5) {
                                        return -0.025778680587;
                                    } else {
                                        return -0.0757818419533;
                                    }
                                } else {
                                    return 0.0924886578263;
                                }
                            } else {
                                if (fs[47] <= -1886.0) {
                                    if (fs[59] <= 0.5) {
                                        return -0.0219322332913;
                                    } else {
                                        return -0.0536458230261;
                                    }
                                } else {
                                    if (fs[81] <= 0.5) {
                                        return -0.0375591685369;
                                    } else {
                                        return -0.00498055625298;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9862.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[72] <= 4346.0) {
                                        return -0.0102351987246;
                                    } else {
                                        return 0.12304419617;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return -0.00316175925745;
                                    } else {
                                        return -0.00218847197358;
                                    }
                                }
                            } else {
                                if (fs[91] <= 0.5) {
                                    if (fs[47] <= -2388.5) {
                                        return 0.0675078941983;
                                    } else {
                                        return -0.00777027243477;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0456753504027;
                                    } else {
                                        return -0.0812245662077;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 5.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 12.5) {
                                return 0.188094922422;
                            } else {
                                return 0.267048464495;
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                return 0.109151550105;
                            } else {
                                return 0.0112440603914;
                            }
                        }
                    } else {
                        if (fs[53] <= -1262.5) {
                            return 0.105343355043;
                        } else {
                            if (fs[88] <= 3.5) {
                                if (fs[13] <= 0.5) {
                                    if (fs[55] <= 994.5) {
                                        return -0.00832130338169;
                                    } else {
                                        return -0.0133154538059;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.0149476862858;
                                    } else {
                                        return -0.0155851668196;
                                    }
                                }
                            } else {
                                return 0.0315805257274;
                            }
                        }
                    }
                }
            } else {
                if (fs[53] <= -1418.0) {
                    if (fs[66] <= 5.0) {
                        if (fs[47] <= -1.5) {
                            if (fs[90] <= 0.5) {
                                if (fs[47] <= -85.5) {
                                    if (fs[4] <= 7.5) {
                                        return -0.0856041903501;
                                    } else {
                                        return 0.162008542977;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.147263792265;
                                    } else {
                                        return 0.243740730853;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[47] <= -14.5) {
                                        return 0.428189791533;
                                    } else {
                                        return 0.317381266814;
                                    }
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return 0.0994738576133;
                                    } else {
                                        return -0.187600655195;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 30.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.258984197684;
                                    } else {
                                        return 0.0975489090168;
                                    }
                                } else {
                                    return -0.273414926926;
                                }
                            } else {
                                return -0.148704361962;
                            }
                        }
                    } else {
                        return -0.198944869241;
                    }
                } else {
                    if (fs[4] <= 17.5) {
                        if (fs[64] <= -996.5) {
                            if (fs[103] <= 0.5) {
                                return 0.400763961884;
                            } else {
                                return 0.0670196406186;
                            }
                        } else {
                            if (fs[47] <= -19.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.204779140263;
                                    } else {
                                        return -0.0143771267909;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.110339645272;
                                    } else {
                                        return -0.0407806789816;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1108.0) {
                                    if (fs[53] <= -1123.5) {
                                        return 0.0242432037928;
                                    } else {
                                        return 0.27540038325;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0358102116044;
                                    } else {
                                        return -0.00924832168557;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[4] <= 26.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.154632540703;
                                    } else {
                                        return -0.0774967836606;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return 0.0244674999286;
                                    } else {
                                        return -0.0683817042445;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    return -0.107781018693;
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.141084297104;
                                    } else {
                                        return -0.0472605572804;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -970.5) {
                                if (fs[76] <= 75.0) {
                                    return -0.0608584949184;
                                } else {
                                    if (fs[76] <= 250.0) {
                                        return -0.0228156260563;
                                    } else {
                                        return -0.0089285356903;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0398887026258;
                                    } else {
                                        return -0.0122379387167;
                                    }
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return 0.0729570395042;
                                    } else {
                                        return 0.00543758021849;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
