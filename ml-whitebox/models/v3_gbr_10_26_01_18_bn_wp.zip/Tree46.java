/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree46 {
    public double calcTree(double... fs) {
        if (fs[72] <= 9996.5) {
            if (fs[0] <= 0.5) {
                if (fs[41] <= 0.5) {
                    if (fs[4] <= 11.5) {
                        if (fs[47] <= -0.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.0936170754184;
                                    } else {
                                        return 0.0722301806638;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.124527909219;
                                    } else {
                                        return 0.213977972356;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1123.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0694963226521;
                                    } else {
                                        return 0.116234468903;
                                    }
                                } else {
                                    return 0.17608895676;
                                }
                            }
                        } else {
                            if (fs[14] <= 0.5) {
                                if (fs[53] <= -1563.5) {
                                    return 0.317481815303;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.0657228512954;
                                    } else {
                                        return 0.131394873795;
                                    }
                                }
                            } else {
                                return 0.346399165505;
                            }
                        }
                    } else {
                        if (fs[105] <= 0.5) {
                            if (fs[4] <= 27.5) {
                                if (fs[53] <= -1493.5) {
                                    if (fs[81] <= 0.5) {
                                        return -0.0381868756992;
                                    } else {
                                        return 0.155383259639;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return 0.0448475715411;
                                    } else {
                                        return 0.263696199239;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1978.0) {
                                    if (fs[11] <= 0.5) {
                                        return 0.138056103288;
                                    } else {
                                        return 0.288895119485;
                                    }
                                } else {
                                    if (fs[82] <= 0.5) {
                                        return -0.0932634511473;
                                    } else {
                                        return 0.103998029378;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.270058396749;
                                    } else {
                                        return -0.134125817815;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.247438095895;
                                    } else {
                                        return -0.335810374494;
                                    }
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[53] <= -970.5) {
                                        return 0.107925367753;
                                    } else {
                                        return -0.0387908288742;
                                    }
                                } else {
                                    if (fs[2] <= 5.5) {
                                        return -0.0858846444274;
                                    } else {
                                        return 0.150547199533;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[71] <= 0.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[47] <= -820.0) {
                                if (fs[72] <= 4872.0) {
                                    if (fs[105] <= 0.5) {
                                        return 0.33492171429;
                                    } else {
                                        return 0.17026793676;
                                    }
                                } else {
                                    return 0.0693534353134;
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[4] <= 14.5) {
                                        return 0.288279916942;
                                    } else {
                                        return 0.153643890236;
                                    }
                                } else {
                                    if (fs[88] <= 2.5) {
                                        return -0.0171009693557;
                                    } else {
                                        return 0.114208045966;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 1.0) {
                                if (fs[59] <= 0.5) {
                                    return 0.126858626436;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.113458618235;
                                    } else {
                                        return 0.0903106388594;
                                    }
                                }
                            } else {
                                return 0.366404974383;
                            }
                        }
                    } else {
                        if (fs[51] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.183791733411;
                                    } else {
                                        return -0.0811983307772;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0469832039967;
                                    } else {
                                        return -0.0562830888404;
                                    }
                                }
                            } else {
                                if (fs[89] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.252634413947;
                                    } else {
                                        return -0.0205945184904;
                                    }
                                } else {
                                    return 0.189556877561;
                                }
                            }
                        } else {
                            return 0.241267168397;
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[41] <= 0.5) {
                        if (fs[105] <= 0.5) {
                            if (fs[53] <= -1478.5) {
                                if (fs[4] <= 13.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.078422346335;
                                    } else {
                                        return 0.0393907150643;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.0751094209919;
                                    } else {
                                        return -0.00815472339444;
                                    }
                                }
                            } else {
                                if (fs[4] <= 19.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.0160779464901;
                                    } else {
                                        return -0.0180249428202;
                                    }
                                } else {
                                    if (fs[53] <= -921.5) {
                                        return -0.0247758743448;
                                    } else {
                                        return 0.00881600165049;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -388.0) {
                                if (fs[47] <= -412.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0140732364532;
                                    } else {
                                        return 0.123167824766;
                                    }
                                } else {
                                    return 0.439111634681;
                                }
                            } else {
                                if (fs[72] <= 9989.5) {
                                    if (fs[31] <= 0.5) {
                                        return -0.0125634195385;
                                    } else {
                                        return 0.118545921547;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0341208518993;
                                    } else {
                                        return 0.110463002214;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[85] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1098.0) {
                                        return 0.0340745458453;
                                    } else {
                                        return -0.0365595472296;
                                    }
                                } else {
                                    if (fs[64] <= -498.5) {
                                        return 0.438862322124;
                                    } else {
                                        return 0.0842456311161;
                                    }
                                }
                            } else {
                                if (fs[47] <= -34.5) {
                                    if (fs[47] <= -93.0) {
                                        return -0.0193039190677;
                                    } else {
                                        return 0.360059392831;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.0202398210794;
                                    } else {
                                        return 0.0418778428887;
                                    }
                                }
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                if (fs[2] <= 3.5) {
                                    if (fs[103] <= 1.5) {
                                        return 0.0265066835892;
                                    } else {
                                        return -0.0319553965228;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0818152950633;
                                    } else {
                                        return 0.275984438547;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.0658460934777;
                                    } else {
                                        return 0.159146223926;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return 0.257191403871;
                                    } else {
                                        return -0.404190162955;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 3.5) {
                        if (fs[88] <= 6.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.00594649263523;
                                    } else {
                                        return -0.0163684566621;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return -0.0114719117675;
                                    } else {
                                        return 0.0176855116108;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[53] <= -1428.5) {
                                        return -0.00761956362639;
                                    } else {
                                        return -0.0187427250736;
                                    }
                                } else {
                                    if (fs[72] <= 4329.5) {
                                        return 0.053151896907;
                                    } else {
                                        return -0.033583746968;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1383.0) {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.00872628292511;
                                    } else {
                                        return 0.149333039469;
                                    }
                                } else {
                                    if (fs[2] <= 8.5) {
                                        return 0.000590791327011;
                                    } else {
                                        return 0.275971337212;
                                    }
                                }
                            } else {
                                if (fs[57] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.00166128332868;
                                    } else {
                                        return -0.0461098975816;
                                    }
                                } else {
                                    return 0.432491125533;
                                }
                            }
                        }
                    } else {
                        if (fs[14] <= 0.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[103] <= 1.5) {
                                    if (fs[57] <= 0.5) {
                                        return -0.00525856557721;
                                    } else {
                                        return 0.0932633642303;
                                    }
                                } else {
                                    if (fs[2] <= 4.5) {
                                        return 0.0171271976712;
                                    } else {
                                        return 0.13372946385;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.00823904596141;
                                    } else {
                                        return -0.00673652601379;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.00875309942471;
                                    } else {
                                        return -0.0167059236042;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 5.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.000259145650099;
                                    } else {
                                        return -0.0181587152933;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.477486520184;
                                    } else {
                                        return 0.0581243259475;
                                    }
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.0091062232469;
                                    } else {
                                        return 0.0470077130926;
                                    }
                                } else {
                                    if (fs[72] <= 9988.5) {
                                        return -0.00682087232978;
                                    } else {
                                        return 0.0597631448381;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[53] <= -1052.5) {
                if (fs[0] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[18] <= -0.5) {
                            if (fs[4] <= 15.5) {
                                return -0.296454812502;
                            } else {
                                return -0.0635196763037;
                            }
                        } else {
                            if (fs[88] <= -0.5) {
                                return -0.358451174367;
                            } else {
                                if (fs[4] <= 35.5) {
                                    if (fs[53] <= -1478.5) {
                                        return 0.0877095576089;
                                    } else {
                                        return 0.126600554295;
                                    }
                                } else {
                                    if (fs[53] <= -1733.0) {
                                        return 0.131559041725;
                                    } else {
                                        return -0.363671197499;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[99] <= 0.5) {
                            if (fs[4] <= 15.5) {
                                if (fs[47] <= -120.0) {
                                    if (fs[72] <= 9998.5) {
                                        return 0.0329343356808;
                                    } else {
                                        return 0.209684535558;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.11486653475;
                                    } else {
                                        return 0.0109138165792;
                                    }
                                }
                            } else {
                                if (fs[88] <= 1.5) {
                                    if (fs[47] <= -8.0) {
                                        return 0.238938904972;
                                    } else {
                                        return -0.0455591934871;
                                    }
                                } else {
                                    return -0.390981341998;
                                }
                            }
                        } else {
                            if (fs[76] <= 250.0) {
                                if (fs[4] <= 24.0) {
                                    if (fs[47] <= -31.0) {
                                        return 0.248758680854;
                                    } else {
                                        return -0.12732451639;
                                    }
                                } else {
                                    if (fs[4] <= 30.5) {
                                        return 0.249357835902;
                                    } else {
                                        return 0.182001034007;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0194974685926;
                                    } else {
                                        return 0.171383005343;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0268546026899;
                                    } else {
                                        return 0.138390861797;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[55] <= 546.5) {
                        if (fs[2] <= 3.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.021024084592;
                                    } else {
                                        return -0.0192833898165;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0102464879453;
                                    } else {
                                        return 0.160186096292;
                                    }
                                }
                            } else {
                                if (fs[53] <= -2423.0) {
                                    return 0.301681635396;
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0554909491349;
                                    } else {
                                        return -0.171186698955;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1128.0) {
                                if (fs[0] <= 20.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0824200538061;
                                    } else {
                                        return -0.350017866364;
                                    }
                                } else {
                                    return -0.167510514602;
                                }
                            } else {
                                return 0.44276193696;
                            }
                        }
                    } else {
                        return 0.424082377377;
                    }
                }
            } else {
                if (fs[4] <= 5.5) {
                    if (fs[71] <= 0.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[22] <= 0.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.00446183826676;
                                    } else {
                                        return 0.169834289155;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.18813019821;
                                    } else {
                                        return 0.305162601102;
                                    }
                                }
                            } else {
                                if (fs[47] <= -18.5) {
                                    return 0.152679313038;
                                } else {
                                    return -0.0398130526995;
                                }
                            }
                        } else {
                            if (fs[23] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[72] <= 9998.5) {
                                        return -0.169652795284;
                                    } else {
                                        return -0.0984765928243;
                                    }
                                } else {
                                    return -0.0883313231324;
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    return 0.257620823992;
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.233943043682;
                                    } else {
                                        return 0.028059122606;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[57] <= 0.5) {
                                if (fs[64] <= -499.0) {
                                    return 0.151597263388;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.080259033222;
                                    } else {
                                        return 0.0145684559905;
                                    }
                                }
                            } else {
                                return 0.227138784367;
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[88] <= 6.5) {
                                        return 0.128139648697;
                                    } else {
                                        return 0.077546887272;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.421920059829;
                                    } else {
                                        return 0.239504960102;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.0274229028539;
                                    } else {
                                        return -0.0627897317113;
                                    }
                                } else {
                                    return 0.170056328673;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[88] <= 4.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[62] <= -0.5) {
                                if (fs[4] <= 15.5) {
                                    if (fs[103] <= 0.5) {
                                        return 0.149491771088;
                                    } else {
                                        return 0.0184451084246;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.228584259911;
                                    } else {
                                        return -0.0976765225576;
                                    }
                                }
                            } else {
                                if (fs[47] <= -3.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.0417607650375;
                                    } else {
                                        return -0.00804858303372;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0127810758428;
                                    } else {
                                        return 0.0311715145783;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -38.0) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[47] <= -164.0) {
                                        return -0.0158113726411;
                                    } else {
                                        return -0.249191072913;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.174121572393;
                                    } else {
                                        return -0.231267642087;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[4] <= 13.5) {
                                        return 0.110209835498;
                                    } else {
                                        return 0.321955446724;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.131851334183;
                                    } else {
                                        return -0.0576130412086;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[47] <= -86.5) {
                                        return 0.0643703100241;
                                    } else {
                                        return 0.182473197442;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.134769821843;
                                    } else {
                                        return -0.0257544813977;
                                    }
                                }
                            } else {
                                if (fs[70] <= -4.0) {
                                    return 0.247168606894;
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.211378229599;
                                    } else {
                                        return 0.0419756452303;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 10.5) {
                                if (fs[12] <= 0.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.0524828727831;
                                    } else {
                                        return -0.0349381951956;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.113869544947;
                                    } else {
                                        return 0.0200175233648;
                                    }
                                }
                            } else {
                                if (fs[88] <= 5.5) {
                                    return 0.175236575313;
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.0612265662994;
                                    } else {
                                        return -0.00379378849248;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
