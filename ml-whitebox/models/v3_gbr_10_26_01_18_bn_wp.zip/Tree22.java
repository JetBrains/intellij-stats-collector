/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree22 {
    public double calcTree(double... fs) {
        if (fs[103] <= 1.5) {
            if (fs[4] <= 7.5) {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[81] <= 0.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[4] <= 5.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.183090171867;
                                    } else {
                                        return 0.30677884388;
                                    }
                                } else {
                                    if (fs[30] <= 0.5) {
                                        return 0.345682689521;
                                    } else {
                                        return 0.273924130633;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.143399124243;
                                    } else {
                                        return -0.0295997157193;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.333827048172;
                                    } else {
                                        return 0.361403173055;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -987.5) {
                                if (fs[53] <= -1473.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.100048051332;
                                    } else {
                                        return 0.244426531412;
                                    }
                                } else {
                                    if (fs[74] <= 0.5) {
                                        return 0.279572712574;
                                    } else {
                                        return 0.069275052129;
                                    }
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.385467922142;
                                    } else {
                                        return 0.209029566408;
                                    }
                                } else {
                                    if (fs[47] <= -5.5) {
                                        return 0.182727674895;
                                    } else {
                                        return 0.066964741342;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= -0.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[53] <= -1473.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.165074023251;
                                    } else {
                                        return 0.106335582306;
                                    }
                                } else {
                                    return 0.230486682305;
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    return -0.0863047269934;
                                } else {
                                    return -0.304525623671;
                                }
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                if (fs[53] <= -1143.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.2798581387;
                                    } else {
                                        return -0.0613016531869;
                                    }
                                } else {
                                    if (fs[85] <= 0.5) {
                                        return 0.292562626947;
                                    } else {
                                        return 0.0280841734855;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.274042992546;
                                    } else {
                                        return 0.30688311465;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.0664281067995;
                                    } else {
                                        return 0.237224850282;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 1.5) {
                        if (fs[76] <= 75.0) {
                            if (fs[30] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[100] <= 0.5) {
                                        return -0.0229480018924;
                                    } else {
                                        return 0.0595728330457;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.185080857201;
                                    } else {
                                        return 0.0272519595071;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    return 0.387755812686;
                                } else {
                                    return 0.464201272885;
                                }
                            }
                        } else {
                            if (fs[47] <= -318.0) {
                                if (fs[59] <= 0.5) {
                                    if (fs[47] <= -16957.0) {
                                        return -0.0548498744775;
                                    } else {
                                        return 0.232779717106;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.275131774906;
                                    } else {
                                        return 0.440177852616;
                                    }
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[68] <= 1.5) {
                                        return 0.126411196928;
                                    } else {
                                        return 0.343645473574;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0944872179132;
                                    } else {
                                        return 0.00675924552311;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 4.5) {
                            if (fs[88] <= 7.5) {
                                if (fs[72] <= 9995.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0061729514883;
                                    } else {
                                        return 0.0241911290326;
                                    }
                                } else {
                                    if (fs[53] <= -1082.5) {
                                        return 0.167124316693;
                                    } else {
                                        return 0.0295680641041;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1303.0) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0786512253374;
                                    } else {
                                        return 0.43945298746;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.00447465826946;
                                    } else {
                                        return -0.0327395043612;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -3462.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.358354006378;
                                    } else {
                                        return -0.0810929423932;
                                    }
                                } else {
                                    if (fs[53] <= -1478.0) {
                                        return 0.13876880475;
                                    } else {
                                        return -0.0495856649549;
                                    }
                                }
                            } else {
                                if (fs[99] <= 0.5) {
                                    if (fs[0] <= 18.5) {
                                        return -0.01354805725;
                                    } else {
                                        return -0.0187708388837;
                                    }
                                } else {
                                    if (fs[0] <= 115.0) {
                                        return -0.00467836434789;
                                    } else {
                                        return 0.346430373489;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 4.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[59] <= 0.5) {
                                if (fs[64] <= -995.5) {
                                    if (fs[49] <= -1.5) {
                                        return 0.357590987113;
                                    } else {
                                        return 0.26030041685;
                                    }
                                } else {
                                    if (fs[53] <= -1503.0) {
                                        return 0.324585036973;
                                    } else {
                                        return 0.157654927667;
                                    }
                                }
                            } else {
                                if (fs[53] <= -507.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.343762337515;
                                    } else {
                                        return 0.0703511358689;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.212653493816;
                                    } else {
                                        return -0.157813137292;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1588.0) {
                                if (fs[76] <= 25.0) {
                                    if (fs[84] <= 0.5) {
                                        return 0.104108150752;
                                    } else {
                                        return 0.355661535262;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.415942298017;
                                    } else {
                                        return 0.330127687591;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.112132684847;
                                    } else {
                                        return -0.000242540109442;
                                    }
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.304074393971;
                                    } else {
                                        return 0.183401064698;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 10.5) {
                            if (fs[4] <= 14.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.305276669058;
                                    } else {
                                        return -0.0310925751447;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0298071631111;
                                    } else {
                                        return 0.288050923278;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    if (fs[47] <= -122.5) {
                                        return 0.447302159617;
                                    } else {
                                        return 0.177108354022;
                                    }
                                } else {
                                    if (fs[14] <= 0.5) {
                                        return 0.0430360648333;
                                    } else {
                                        return 0.400623763818;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 27.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[53] <= -1468.0) {
                                        return 0.451097294874;
                                    } else {
                                        return 0.352634463885;
                                    }
                                } else {
                                    return 0.20398097062;
                                }
                            } else {
                                return 0.116070369181;
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 2.5) {
                        if (fs[45] <= 0.5) {
                            if (fs[101] <= 0.5) {
                                if (fs[72] <= 9534.5) {
                                    if (fs[18] <= 0.5) {
                                        return -0.014053549095;
                                    } else {
                                        return 0.0113324231531;
                                    }
                                } else {
                                    if (fs[2] <= 6.5) {
                                        return 0.0310873454939;
                                    } else {
                                        return 0.213550693446;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0496569015344;
                                    } else {
                                        return 0.106727925705;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.00886673475802;
                                    } else {
                                        return 0.0307318806547;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -356.5) {
                                return 0.0915497536982;
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0278559177833;
                                    } else {
                                        return -0.0365425502165;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return 0.0392162120005;
                                    } else {
                                        return 0.231803781114;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[70] <= -3.5) {
                                        return -0.0102376475055;
                                    } else {
                                        return -0.0193748092964;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return -0.0175142154355;
                                    } else {
                                        return -0.00546036042174;
                                    }
                                }
                            } else {
                                if (fs[0] <= 4.5) {
                                    if (fs[76] <= 250.0) {
                                        return 0.00721501276448;
                                    } else {
                                        return -0.0192026138758;
                                    }
                                } else {
                                    if (fs[67] <= 0.5) {
                                        return -0.0164387461294;
                                    } else {
                                        return 0.0379026809254;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[88] <= 7.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.330862356734;
                                    } else {
                                        return 0.0422088845167;
                                    }
                                } else {
                                    return 0.800617881834;
                                }
                            } else {
                                if (fs[53] <= -966.0) {
                                    if (fs[105] <= 0.5) {
                                        return -0.0274025245552;
                                    } else {
                                        return -0.0310412142;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0264309259482;
                                    } else {
                                        return -0.0217975802398;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[52] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[4] <= 20.5) {
                            if (fs[64] <= -996.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.250645026551;
                                    } else {
                                        return 0.323972565868;
                                    }
                                } else {
                                    return 0.153439538715;
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[53] <= -1018.5) {
                                        return 0.29248760368;
                                    } else {
                                        return 0.0349162860007;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0479053568774;
                                    } else {
                                        return 0.213162776772;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 24.5) {
                                if (fs[4] <= 23.5) {
                                    if (fs[64] <= -498.0) {
                                        return 0.317418318821;
                                    } else {
                                        return 0.089388295425;
                                    }
                                } else {
                                    return -0.0113256176051;
                                }
                            } else {
                                if (fs[4] <= 26.5) {
                                    if (fs[26] <= 0.5) {
                                        return 0.402190646412;
                                    } else {
                                        return 0.337040684336;
                                    }
                                } else {
                                    return 0.140955408085;
                                }
                            }
                        }
                    } else {
                        if (fs[49] <= -0.5) {
                            return 0.172965140278;
                        } else {
                            if (fs[60] <= 0.5) {
                                return 0.0565497140223;
                            } else {
                                if (fs[4] <= 10.5) {
                                    return -0.0564579728725;
                                } else {
                                    return -0.270943299044;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[23] <= 0.5) {
                        if (fs[97] <= 0.5) {
                            if (fs[79] <= 0.5) {
                                if (fs[53] <= -1138.0) {
                                    return 0.320635665854;
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.422244699122;
                                    } else {
                                        return 0.363089285427;
                                    }
                                }
                            } else {
                                return 0.456249320794;
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[4] <= 1.5) {
                                        return 0.167060565267;
                                    } else {
                                        return 0.27575529355;
                                    }
                                } else {
                                    if (fs[53] <= -1318.0) {
                                        return 0.386875002136;
                                    } else {
                                        return 0.226978448837;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0585204597336;
                                    } else {
                                        return -0.0247458182763;
                                    }
                                } else {
                                    return 0.0467541596974;
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 4995.0) {
                            if (fs[2] <= 2.5) {
                                return -0.0422343916119;
                            } else {
                                return 0.226354998702;
                            }
                        } else {
                            return -0.20786698209;
                        }
                    }
                }
            } else {
                if (fs[45] <= 0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[49] <= -0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[62] <= -1.5) {
                                        return 0.311906730404;
                                    } else {
                                        return 0.220672180871;
                                    }
                                } else {
                                    return 0.593781125276;
                                }
                            } else {
                                return 0.243021412657;
                            }
                        } else {
                            if (fs[0] <= 32.5) {
                                if (fs[62] <= -0.5) {
                                    if (fs[4] <= 15.5) {
                                        return -0.0615608685881;
                                    } else {
                                        return 0.0753754652103;
                                    }
                                } else {
                                    if (fs[53] <= -992.0) {
                                        return 0.094534456231;
                                    } else {
                                        return -0.0359973009548;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.352211217828;
                                    } else {
                                        return 0.115591600276;
                                    }
                                } else {
                                    return 0.597825790088;
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[0] <= 3.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[62] <= -1.5) {
                                        return 0.095233671708;
                                    } else {
                                        return -0.0781652910135;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0918707774838;
                                    } else {
                                        return -0.0536127499701;
                                    }
                                }
                            } else {
                                if (fs[4] <= 24.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.0336403030203;
                                    } else {
                                        return 0.000777273362906;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0135259756316;
                                    } else {
                                        return 0.115681910846;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                return 0.0153963698881;
                            } else {
                                return 0.491334670644;
                            }
                        }
                    }
                } else {
                    if (fs[49] <= -2.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[4] <= 17.5) {
                                return 0.107574265294;
                            } else {
                                return -0.0463889251654;
                            }
                        } else {
                            return 0.167729052178;
                        }
                    } else {
                        if (fs[23] <= 0.5) {
                            if (fs[4] <= 2.5) {
                                return 0.0202587930152;
                            } else {
                                if (fs[2] <= 0.5) {
                                    if (fs[0] <= 11.5) {
                                        return -0.0222022945607;
                                    } else {
                                        return 0.0158368081816;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return -0.0154771964184;
                                    } else {
                                        return -0.0200076232024;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 1.5) {
                                    if (fs[64] <= -996.5) {
                                        return -0.0374995302181;
                                    } else {
                                        return -0.0341826258722;
                                    }
                                } else {
                                    if (fs[62] <= -0.5) {
                                        return -0.0251646335994;
                                    } else {
                                        return -0.0226547950641;
                                    }
                                }
                            } else {
                                if (fs[4] <= 32.5) {
                                    if (fs[58] <= 0.5) {
                                        return -0.0235076384381;
                                    } else {
                                        return -0.0219895763298;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0227175711912;
                                    } else {
                                        return 0.000910843061959;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
