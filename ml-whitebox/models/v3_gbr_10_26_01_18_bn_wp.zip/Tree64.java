/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree64 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[76] <= 100.0) {
                if (fs[0] <= 0.5) {
                    if (fs[4] <= 9.5) {
                        if (fs[53] <= -1138.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0098322927554;
                                    } else {
                                        return 0.0916126160475;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.0976861238265;
                                    } else {
                                        return 0.0119134436419;
                                    }
                                }
                            } else {
                                if (fs[33] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0506007385452;
                                    } else {
                                        return 0.0339533758399;
                                    }
                                } else {
                                    return -0.106418235192;
                                }
                            }
                        } else {
                            if (fs[14] <= 0.5) {
                                if (fs[53] <= -983.0) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0516605515776;
                                    } else {
                                        return 0.0333295350085;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.0366598533381;
                                    } else {
                                        return -0.241570181735;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.245342047111;
                                } else {
                                    return 0.0729674596459;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 13.5) {
                            if (fs[72] <= 4914.0) {
                                if (fs[78] <= 0.5) {
                                    if (fs[2] <= 4.5) {
                                        return 0.105305382901;
                                    } else {
                                        return 0.0444155191094;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0952832631359;
                                    } else {
                                        return 0.123610757416;
                                    }
                                }
                            } else {
                                return 0.0771037204769;
                            }
                        } else {
                            return -0.232208333571;
                        }
                    }
                } else {
                    if (fs[52] <= 0.5) {
                        if (fs[15] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.0585045897463;
                                    } else {
                                        return 0.363826271573;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return 0.0653399258634;
                                    } else {
                                        return -0.0354843208582;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1128.0) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0227952388876;
                                    } else {
                                        return -0.0575807231781;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.014195339073;
                                    } else {
                                        return 0.109077927201;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[0] <= 24.5) {
                                    if (fs[0] <= 4.5) {
                                        return -0.0160270384949;
                                    } else {
                                        return -0.103161892159;
                                    }
                                } else {
                                    return 0.166786098257;
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[53] <= -983.0) {
                                        return 0.0595936371717;
                                    } else {
                                        return -0.0814959097342;
                                    }
                                } else {
                                    return 0.171471453619;
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 7.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[59] <= 0.5) {
                                    if (fs[33] <= 0.5) {
                                        return 0.0540728721671;
                                    } else {
                                        return -0.107456524753;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.10051429093;
                                    } else {
                                        return 0.286021675209;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.137400601434;
                                    } else {
                                        return -0.00300329395214;
                                    }
                                } else {
                                    if (fs[53] <= -1053.0) {
                                        return 0.0776290798935;
                                    } else {
                                        return -0.0513427918573;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 7.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0388283550209;
                                    } else {
                                        return -0.0216452559178;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0118608970692;
                                    } else {
                                        return -0.0424987020972;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 13.0) {
                                        return -0.023917697864;
                                    } else {
                                        return -0.00578720673623;
                                    }
                                } else {
                                    return 0.05418020308;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[79] <= 0.5) {
                    if (fs[11] <= 0.5) {
                        return -0.120517630306;
                    } else {
                        if (fs[2] <= 7.5) {
                            if (fs[4] <= 39.5) {
                                if (fs[53] <= -1548.0) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0397965152489;
                                    } else {
                                        return -0.0552627262778;
                                    }
                                } else {
                                    if (fs[0] <= 5.5) {
                                        return -0.0114617407877;
                                    } else {
                                        return -0.00198242943987;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1578.0) {
                                    return 0.144998172302;
                                } else {
                                    if (fs[53] <= -1533.0) {
                                        return -0.0475119819926;
                                    } else {
                                        return -0.00499662809268;
                                    }
                                }
                            }
                        } else {
                            return -0.0326903883715;
                        }
                    }
                } else {
                    if (fs[53] <= -1568.0) {
                        if (fs[0] <= 0.5) {
                            return 0.209446479055;
                        } else {
                            return -0.0603530717042;
                        }
                    } else {
                        if (fs[0] <= 0.5) {
                            return -0.164434661281;
                        } else {
                            if (fs[4] <= 31.5) {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 5.5) {
                                        return 0.0471618060438;
                                    } else {
                                        return -0.00708483848424;
                                    }
                                } else {
                                    return -0.0266280809895;
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[2] <= 2.5) {
                                        return -0.0475082407147;
                                    } else {
                                        return -0.0390802419849;
                                    }
                                } else {
                                    if (fs[4] <= 48.5) {
                                        return -0.0190677705431;
                                    } else {
                                        return 0.0407618232261;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[64] <= -996.5) {
                if (fs[53] <= -1098.5) {
                    if (fs[4] <= 22.5) {
                        if (fs[103] <= 0.5) {
                            if (fs[62] <= -1.5) {
                                if (fs[12] <= 0.5) {
                                    return 0.515946630477;
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.262301634259;
                                    } else {
                                        return 0.10339096408;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[76] <= 300.0) {
                                        return 0.120785337583;
                                    } else {
                                        return -0.0657153285944;
                                    }
                                } else {
                                    if (fs[0] <= 12.5) {
                                        return 0.0112232242778;
                                    } else {
                                        return 0.106225440022;
                                    }
                                }
                            }
                        } else {
                            if (fs[58] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[18] <= 0.5) {
                                        return 0.056460833035;
                                    } else {
                                        return 0.102209550464;
                                    }
                                } else {
                                    return 0.244552808181;
                                }
                            } else {
                                if (fs[4] <= 12.5) {
                                    if (fs[49] <= -1.5) {
                                        return -0.132803631913;
                                    } else {
                                        return 0.0158881258694;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.151112627542;
                                    } else {
                                        return 0.00292922060135;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -2.5) {
                            return -0.254217536755;
                        } else {
                            if (fs[4] <= 25.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[0] <= 0.5) {
                                        return -0.345438712043;
                                    } else {
                                        return -0.0198645318722;
                                    }
                                } else {
                                    if (fs[53] <= -1333.0) {
                                        return 0.123310639207;
                                    } else {
                                        return -0.0252481754235;
                                    }
                                }
                            } else {
                                return 0.0632359575756;
                            }
                        }
                    }
                } else {
                    if (fs[11] <= 0.5) {
                        if (fs[0] <= 0.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[48] <= 0.5) {
                                    if (fs[72] <= 5000.0) {
                                        return 0.131898242318;
                                    } else {
                                        return 0.0596762022781;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.0428639543857;
                                    } else {
                                        return -0.0374318837214;
                                    }
                                }
                            } else {
                                if (fs[47] <= -7.5) {
                                    if (fs[76] <= 100.0) {
                                        return 0.0595931121701;
                                    } else {
                                        return -0.299642640124;
                                    }
                                } else {
                                    if (fs[4] <= 17.5) {
                                        return 0.101558956118;
                                    } else {
                                        return 0.221269735889;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -942.0) {
                                if (fs[45] <= 0.5) {
                                    if (fs[53] <= -976.0) {
                                        return -0.0378685301302;
                                    } else {
                                        return -0.0846999941383;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.0139708933011;
                                    } else {
                                        return 0.00944750244561;
                                    }
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.231157341437;
                                    } else {
                                        return 0.0152542198672;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.00818008258004;
                                    } else {
                                        return 0.0835730382133;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 4998.0) {
                            if (fs[4] <= 4.5) {
                                return 0.150746387564;
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.14168444184;
                                    } else {
                                        return 0.0288223047818;
                                    }
                                } else {
                                    if (fs[49] <= -1.5) {
                                        return 0.0236664547122;
                                    } else {
                                        return -0.00955085849111;
                                    }
                                }
                            }
                        } else {
                            if (fs[48] <= 0.5) {
                                return 0.259521350801;
                            } else {
                                return 0.151926826076;
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[44] <= 0.5) {
                                if (fs[72] <= 9989.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.00655752275698;
                                    } else {
                                        return -0.074742904945;
                                    }
                                } else {
                                    if (fs[70] <= -4.5) {
                                        return 0.0716880850129;
                                    } else {
                                        return 0.0060283538303;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[74] <= 0.5) {
                                        return 0.0659592505342;
                                    } else {
                                        return -0.01767925752;
                                    }
                                } else {
                                    return -0.319907415094;
                                }
                            }
                        } else {
                            if (fs[53] <= -1493.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.114360681885;
                                    } else {
                                        return 0.0490156477154;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.0540335375124;
                                    } else {
                                        return 0.139877039585;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0191091067315;
                                    } else {
                                        return -0.0219864283981;
                                    }
                                } else {
                                    if (fs[53] <= -457.0) {
                                        return 0.0646679763118;
                                    } else {
                                        return -0.013423448543;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[57] <= 0.5) {
                            if (fs[2] <= 5.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.04795678385;
                                    } else {
                                        return -0.0114168825257;
                                    }
                                } else {
                                    if (fs[53] <= -1588.0) {
                                        return 0.0898164547096;
                                    } else {
                                        return 0.0110087709869;
                                    }
                                }
                            } else {
                                if (fs[4] <= 14.5) {
                                    if (fs[53] <= -1913.5) {
                                        return -0.0644980966372;
                                    } else {
                                        return 0.0756439269413;
                                    }
                                } else {
                                    if (fs[2] <= 11.5) {
                                        return 0.011824892834;
                                    } else {
                                        return 0.139335172449;
                                    }
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                return -0.0412506144331;
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[2] <= 3.5) {
                                        return 0.190763621859;
                                    } else {
                                        return 0.0119896381249;
                                    }
                                } else {
                                    if (fs[64] <= -995.0) {
                                        return 0.138668062367;
                                    } else {
                                        return 0.261570142775;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[55] <= 0.5) {
                        if (fs[57] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[45] <= 0.5) {
                                        return 0.000627955266781;
                                    } else {
                                        return -0.0058748917493;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return -0.00262897479539;
                                    } else {
                                        return 0.0231670473362;
                                    }
                                }
                            } else {
                                if (fs[53] <= -57.0) {
                                    if (fs[47] <= -79.5) {
                                        return 0.0251353593758;
                                    } else {
                                        return -0.00144763768613;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.0213202949988;
                                    } else {
                                        return 0.00171662227002;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[72] <= 9998.5) {
                                    if (fs[47] <= -3.5) {
                                        return -0.138529357586;
                                    } else {
                                        return 0.0794496101611;
                                    }
                                } else {
                                    return 0.360450586698;
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.00866481661241;
                                    } else {
                                        return -0.0153794222806;
                                    }
                                } else {
                                    return -0.0245362569019;
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 75.0) {
                            if (fs[0] <= 5.5) {
                                if (fs[65] <= 0.5) {
                                    return -0.0384900812283;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.146913061387;
                                    } else {
                                        return 0.0928934502159;
                                    }
                                }
                            } else {
                                if (fs[12] <= 0.5) {
                                    if (fs[4] <= 9.5) {
                                        return 0.0275193877959;
                                    } else {
                                        return -0.0148461264325;
                                    }
                                } else {
                                    return 0.0529141686039;
                                }
                            }
                        } else {
                            if (fs[53] <= -1468.0) {
                                return 0.421934694498;
                            } else {
                                return -0.019774432823;
                            }
                        }
                    }
                }
            }
        }
    }
}
