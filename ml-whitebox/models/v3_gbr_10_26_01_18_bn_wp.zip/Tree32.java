/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree32 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[76] <= 100.0) {
                if (fs[0] <= 0.5) {
                    if (fs[27] <= 0.5) {
                        if (fs[2] <= 1.5) {
                            if (fs[53] <= -1138.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.111078533445;
                                    } else {
                                        return 0.0846351653505;
                                    }
                                } else {
                                    return 0.318943309271;
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.197632774694;
                                    } else {
                                        return 0.164089992968;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return 0.172114500457;
                                    } else {
                                        return 0.227602636419;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[33] <= 0.5) {
                                    if (fs[4] <= 12.5) {
                                        return 0.186005227705;
                                    } else {
                                        return -0.0346520548385;
                                    }
                                } else {
                                    return -0.0143677477239;
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[15] <= 0.5) {
                                        return 0.017603722855;
                                    } else {
                                        return -0.108631584809;
                                    }
                                } else {
                                    return 0.19916756011;
                                }
                            }
                        }
                    } else {
                        if (fs[14] <= 0.5) {
                            if (fs[2] <= 2.5) {
                                return 0.263260884418;
                            } else {
                                return 0.224187283691;
                            }
                        } else {
                            return 0.299314442607;
                        }
                    }
                } else {
                    if (fs[33] <= 0.5) {
                        if (fs[30] <= 0.5) {
                            if (fs[4] <= 2.5) {
                                if (fs[53] <= -1068.0) {
                                    if (fs[79] <= 0.5) {
                                        return 0.325097169585;
                                    } else {
                                        return 0.0875025213269;
                                    }
                                } else {
                                    return -0.0702709754236;
                                }
                            } else {
                                if (fs[4] <= 7.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.00960692027914;
                                    } else {
                                        return 0.122845496496;
                                    }
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0350268098379;
                                    } else {
                                        return 0.0047905773685;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1138.0) {
                                if (fs[4] <= 5.0) {
                                    return 0.391528539714;
                                } else {
                                    return 0.146149924424;
                                }
                            } else {
                                return 0.341717124299;
                            }
                        }
                    } else {
                        if (fs[53] <= -953.5) {
                            if (fs[52] <= 0.5) {
                                if (fs[2] <= 1.5) {
                                    if (fs[4] <= 5.5) {
                                        return -0.0425282972669;
                                    } else {
                                        return -0.0584952394215;
                                    }
                                } else {
                                    if (fs[0] <= 2.5) {
                                        return -0.0855306448968;
                                    } else {
                                        return -0.0312406782332;
                                    }
                                }
                            } else {
                                return -0.0796001580566;
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                return -0.0588500473115;
                            } else {
                                if (fs[53] <= 3.5) {
                                    if (fs[4] <= 8.0) {
                                        return -0.022415514265;
                                    } else {
                                        return -0.0261403258784;
                                    }
                                } else {
                                    return -0.0190724370585;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[79] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        return 0.0230946439551;
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[0] <= 1.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[53] <= -1328.0) {
                                        return -0.112421679734;
                                    } else {
                                        return 0.0844353078788;
                                    }
                                } else {
                                    if (fs[53] <= -1578.0) {
                                        return 0.0485189487713;
                                    } else {
                                        return -0.0440477446348;
                                    }
                                }
                            } else {
                                if (fs[53] <= -992.0) {
                                    if (fs[53] <= -1568.0) {
                                        return -0.032982238872;
                                    } else {
                                        return -0.0287901596277;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return -0.0168207157112;
                                    } else {
                                        return -0.0138015233346;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 3.5) {
                                if (fs[45] <= 0.5) {
                                    return -0.0154905226686;
                                } else {
                                    if (fs[0] <= 6.5) {
                                        return -0.0114285912342;
                                    } else {
                                        return -0.0094493896668;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[41] <= 0.5) {
                                        return -0.0192734734222;
                                    } else {
                                        return -0.0197981525018;
                                    }
                                } else {
                                    return -0.0133396408914;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 3.5) {
                        if (fs[53] <= -1568.0) {
                            if (fs[0] <= 0.5) {
                                return 0.303000319734;
                            } else {
                                return -0.0611717456329;
                            }
                        } else {
                            if (fs[53] <= -1188.0) {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 27.0) {
                                        return -0.118472063764;
                                    } else {
                                        return -0.160142644405;
                                    }
                                } else {
                                    return -0.030571972179;
                                }
                            } else {
                                if (fs[4] <= 31.5) {
                                    if (fs[4] <= 20.5) {
                                        return -0.00845047637032;
                                    } else {
                                        return 0.0390028510564;
                                    }
                                } else {
                                    if (fs[4] <= 48.5) {
                                        return -0.0299196258703;
                                    } else {
                                        return 0.0117061044745;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 4.5) {
                            if (fs[53] <= -1538.0) {
                                return -0.0515804056935;
                            } else {
                                if (fs[0] <= 4.5) {
                                    return -0.0460005639129;
                                } else {
                                    return -0.0207668709882;
                                }
                            }
                        } else {
                            if (fs[53] <= -1538.0) {
                                return -0.0379029482144;
                            } else {
                                if (fs[0] <= 3.5) {
                                    return -0.0503829714005;
                                } else {
                                    if (fs[0] <= 7.5) {
                                        return -0.0261396781568;
                                    } else {
                                        return -0.019050483651;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 2.5) {
                    if (fs[76] <= 250.0) {
                        if (fs[11] <= 0.5) {
                            if (fs[74] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[47] <= -1.5) {
                                        return 0.156412237327;
                                    } else {
                                        return 0.0792055233879;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return 0.238350850666;
                                    } else {
                                        return -0.0634109467083;
                                    }
                                }
                            } else {
                                if (fs[68] <= 1.5) {
                                    if (fs[53] <= -1138.5) {
                                        return -0.0635864873573;
                                    } else {
                                        return 0.15385883439;
                                    }
                                } else {
                                    if (fs[53] <= -1318.0) {
                                        return -0.076065843487;
                                    } else {
                                        return 0.0245308006196;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9969.5) {
                                if (fs[53] <= -1543.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.197374229053;
                                    } else {
                                        return -0.195734803795;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.0592129980636;
                                    } else {
                                        return -0.054205564183;
                                    }
                                }
                            } else {
                                if (fs[34] <= 0.5) {
                                    if (fs[53] <= -1588.5) {
                                        return 0.246641455601;
                                    } else {
                                        return 0.0800177836342;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.2168176708;
                                    } else {
                                        return 0.319359468867;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[12] <= 0.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 11.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.158889022757;
                                    } else {
                                        return -0.00304078199354;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0628361409393;
                                    } else {
                                        return 0.125845366984;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1303.5) {
                                    if (fs[72] <= 9989.0) {
                                        return 0.357994078506;
                                    } else {
                                        return 0.250626235971;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.124107907648;
                                    } else {
                                        return 0.0327328455524;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[58] <= 0.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.209594598755;
                                    } else {
                                        return 0.17509207176;
                                    }
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return -0.0244768011815;
                                    } else {
                                        return 0.136565280129;
                                    }
                                }
                            } else {
                                if (fs[26] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.138597077934;
                                    } else {
                                        return -0.045707183155;
                                    }
                                } else {
                                    return 0.154109764326;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[22] <= 0.5) {
                        if (fs[2] <= 4.5) {
                            if (fs[4] <= 6.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.200740337446;
                                    } else {
                                        return -0.103882240154;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.0529130584412;
                                    } else {
                                        return 0.263905896007;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.180448892465;
                                    } else {
                                        return 0.0888647655691;
                                    }
                                } else {
                                    if (fs[88] <= 3.5) {
                                        return 0.068198518404;
                                    } else {
                                        return 0.184652602114;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 17.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.217153034471;
                                    } else {
                                        return 0.0897011052242;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.275440438737;
                                    } else {
                                        return 0.0278551613457;
                                    }
                                }
                            } else {
                                if (fs[62] <= -0.5) {
                                    if (fs[4] <= 23.5) {
                                        return 0.139091294568;
                                    } else {
                                        return 0.320760746436;
                                    }
                                } else {
                                    if (fs[2] <= 9.5) {
                                        return 0.0833767497837;
                                    } else {
                                        return 0.273508088488;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[76] <= 25.0) {
                            if (fs[99] <= 0.5) {
                                if (fs[72] <= 9847.0) {
                                    if (fs[47] <= -136.0) {
                                        return 0.334396909063;
                                    } else {
                                        return -0.0582253558557;
                                    }
                                } else {
                                    if (fs[4] <= 22.5) {
                                        return 0.0819866535912;
                                    } else {
                                        return 0.341194938356;
                                    }
                                }
                            } else {
                                if (fs[4] <= 26.5) {
                                    if (fs[43] <= 0.5) {
                                        return 0.233207063482;
                                    } else {
                                        return -0.0718569160405;
                                    }
                                } else {
                                    return -0.188059211337;
                                }
                            }
                        } else {
                            if (fs[71] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.25343322139;
                                    } else {
                                        return 0.142295841289;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return 0.247305998882;
                                    } else {
                                        return 0.0335602562634;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1077.5) {
                                    if (fs[72] <= 9888.5) {
                                        return 0.0909341885395;
                                    } else {
                                        return 0.17251317066;
                                    }
                                } else {
                                    if (fs[47] <= -5.0) {
                                        return -0.317046610563;
                                    } else {
                                        return -0.108171644645;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[47] <= -3640.5) {
                    if (fs[4] <= 6.5) {
                        if (fs[4] <= 5.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[88] <= 1.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.114399419395;
                                    } else {
                                        return -0.0264782292486;
                                    }
                                } else {
                                    if (fs[53] <= -1228.0) {
                                        return 0.215435407346;
                                    } else {
                                        return -0.0632227318343;
                                    }
                                }
                            } else {
                                return -0.210189201257;
                            }
                        } else {
                            if (fs[59] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[76] <= 75.0) {
                                        return -0.037222363258;
                                    } else {
                                        return -0.126574503707;
                                    }
                                } else {
                                    if (fs[47] <= -12712.5) {
                                        return -0.0185973315097;
                                    } else {
                                        return 0.262168689537;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    return -0.096647698669;
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.282596830535;
                                    } else {
                                        return 0.332501284148;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 0.5) {
                            if (fs[47] <= -15883.5) {
                                if (fs[47] <= -20361.0) {
                                    if (fs[53] <= -471.5) {
                                        return -0.0674963996003;
                                    } else {
                                        return -0.00137976804537;
                                    }
                                } else {
                                    return -0.16490339019;
                                }
                            } else {
                                if (fs[53] <= -1438.0) {
                                    if (fs[0] <= 1.5) {
                                        return 0.384373906303;
                                    } else {
                                        return 0.15256533644;
                                    }
                                } else {
                                    if (fs[72] <= 9992.0) {
                                        return -0.0193774496802;
                                    } else {
                                        return 0.237300608247;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9990.5) {
                                if (fs[0] <= 1.5) {
                                    return -0.172945122755;
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.0966291500136;
                                    } else {
                                        return -0.0448299679687;
                                    }
                                }
                            } else {
                                return 0.361391934761;
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9886.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[22] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.00624040878711;
                                    } else {
                                        return 0.0589209334486;
                                    }
                                } else {
                                    if (fs[47] <= -27.5) {
                                        return 0.0309475875697;
                                    } else {
                                        return -0.0283611365412;
                                    }
                                }
                            } else {
                                if (fs[88] <= 6.5) {
                                    if (fs[88] <= 5.5) {
                                        return 0.0309708455546;
                                    } else {
                                        return -0.0342069752977;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return 0.0214704284199;
                                    } else {
                                        return 0.152533397105;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0098695060194;
                                    } else {
                                        return -0.0122914888496;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.00496089233047;
                                    } else {
                                        return -0.0134060830978;
                                    }
                                }
                            } else {
                                if (fs[0] <= 7.5) {
                                    if (fs[22] <= 0.5) {
                                        return 0.00653650654431;
                                    } else {
                                        return -0.00624474810939;
                                    }
                                } else {
                                    if (fs[57] <= 0.5) {
                                        return -0.0108889085584;
                                    } else {
                                        return 0.101284969382;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1418.0) {
                            if (fs[88] <= 6.5) {
                                if (fs[72] <= 9999.5) {
                                    if (fs[2] <= 6.5) {
                                        return 0.0223003630777;
                                    } else {
                                        return 0.135284953063;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0760188661506;
                                    } else {
                                        return 0.201747213721;
                                    }
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    if (fs[93] <= 0.5) {
                                        return 0.101064508046;
                                    } else {
                                        return -0.173745036;
                                    }
                                } else {
                                    if (fs[4] <= 14.5) {
                                        return 0.305355545185;
                                    } else {
                                        return -0.0832011006449;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 2.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return 0.0415102608527;
                                    } else {
                                        return -0.0130466827366;
                                    }
                                } else {
                                    if (fs[53] <= -1037.0) {
                                        return 0.16760673653;
                                    } else {
                                        return -0.0614380224066;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0052260506921;
                                    } else {
                                        return -0.0240920504788;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return 0.00566734918218;
                                    } else {
                                        return 0.0435405242828;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
