/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree81 {
    public double calcTree(double... fs) {
        if (fs[57] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[4] <= 18.5) {
                    if (fs[47] <= -6.5) {
                        if (fs[93] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[29] <= 0.5) {
                                        return 0.0599195404572;
                                    } else {
                                        return -0.100151970966;
                                    }
                                } else {
                                    if (fs[88] <= 3.0) {
                                        return -0.017457125642;
                                    } else {
                                        return -0.338244363153;
                                    }
                                }
                            } else {
                                if (fs[72] <= 4229.0) {
                                    if (fs[59] <= 0.5) {
                                        return 0.019310857288;
                                    } else {
                                        return 0.0729200807401;
                                    }
                                } else {
                                    if (fs[47] <= -187.5) {
                                        return 0.037203237359;
                                    } else {
                                        return -0.000656875404123;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 12.5) {
                                return -0.232831813809;
                            } else {
                                return -0.297782062091;
                            }
                        }
                    } else {
                        if (fs[94] <= 0.5) {
                            if (fs[2] <= 3.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0166015031612;
                                    } else {
                                        return 0.00203095164073;
                                    }
                                } else {
                                    if (fs[76] <= 25.0) {
                                        return -0.0791441296485;
                                    } else {
                                        return -0.00667277975837;
                                    }
                                }
                            } else {
                                if (fs[32] <= 0.5) {
                                    if (fs[8] <= 0.5) {
                                        return 0.0216786052771;
                                    } else {
                                        return -0.17045979189;
                                    }
                                } else {
                                    return -0.314801582655;
                                }
                            }
                        } else {
                            if (fs[4] <= 11.5) {
                                if (fs[53] <= -1468.5) {
                                    if (fs[83] <= 0.5) {
                                        return 0.0989505494718;
                                    } else {
                                        return -0.0632791184603;
                                    }
                                } else {
                                    return -0.150709196052;
                                }
                            } else {
                                if (fs[4] <= 13.5) {
                                    if (fs[72] <= 9492.0) {
                                        return 0.145821888789;
                                    } else {
                                        return 0.351416262301;
                                    }
                                } else {
                                    if (fs[53] <= -1968.0) {
                                        return 0.000492496498864;
                                    } else {
                                        return 0.196602692066;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 9.5) {
                        if (fs[47] <= -248.5) {
                            if (fs[72] <= 9966.0) {
                                if (fs[101] <= 0.5) {
                                    return 0.359386577977;
                                } else {
                                    return 0.117296727661;
                                }
                            } else {
                                return 0.0303822122218;
                            }
                        } else {
                            if (fs[62] <= -1.5) {
                                if (fs[4] <= 19.5) {
                                    if (fs[64] <= -995.5) {
                                        return -0.0676419743788;
                                    } else {
                                        return -0.274569247532;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.19429759527;
                                    } else {
                                        return 0.0304701817745;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[72] <= 9799.5) {
                                        return -0.0627266833354;
                                    } else {
                                        return 9.69795695415e-05;
                                    }
                                } else {
                                    if (fs[4] <= 35.5) {
                                        return 0.00359418941146;
                                    } else {
                                        return -0.123109740099;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -6.5) {
                            return -0.131420689763;
                        } else {
                            if (fs[78] <= 0.5) {
                                if (fs[50] <= 0.5) {
                                    return -0.128606511078;
                                } else {
                                    return 0.0476251157378;
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[53] <= -1458.0) {
                                        return 0.157246389376;
                                    } else {
                                        return 0.355704463241;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.147654824892;
                                    } else {
                                        return 0.0406882524973;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[55] <= 0.5) {
                    if (fs[0] <= 2.5) {
                        if (fs[18] <= -0.5) {
                            if (fs[47] <= -8.5) {
                                if (fs[4] <= 6.5) {
                                    return -0.280966249645;
                                } else {
                                    if (fs[72] <= 9988.5) {
                                        return -0.0906109013288;
                                    } else {
                                        return -0.200440355579;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.070878513837;
                                    } else {
                                        return -0.0231126701951;
                                    }
                                } else {
                                    if (fs[0] <= 1.5) {
                                        return -0.176733324535;
                                    } else {
                                        return -0.0947590115933;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00746319880248;
                                    } else {
                                        return 0.00182355107477;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0157010030992;
                                    } else {
                                        return 0.0264913156459;
                                    }
                                }
                            } else {
                                if (fs[64] <= -998.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0776416423594;
                                    } else {
                                        return 0.197340773923;
                                    }
                                } else {
                                    if (fs[53] <= -1478.5) {
                                        return 0.0353903371255;
                                    } else {
                                        return 0.00420788812296;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 22.5) {
                            if (fs[28] <= 0.5) {
                                if (fs[14] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.000278105214518;
                                    } else {
                                        return -0.00137492640432;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.076208671919;
                                    } else {
                                        return 0.00775227503512;
                                    }
                                }
                            } else {
                                if (fs[90] <= 0.5) {
                                    if (fs[72] <= 9997.0) {
                                        return -0.00765942650534;
                                    } else {
                                        return -0.137182071556;
                                    }
                                } else {
                                    if (fs[4] <= 10.5) {
                                        return -0.0830365928853;
                                    } else {
                                        return -0.0115594480505;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[26] <= 0.5) {
                                        return -0.0127740104421;
                                    } else {
                                        return 0.126004398641;
                                    }
                                } else {
                                    if (fs[58] <= 0.5) {
                                        return -0.00341627045637;
                                    } else {
                                        return 0.0578121980667;
                                    }
                                }
                            } else {
                                if (fs[0] <= 8.5) {
                                    if (fs[29] <= 0.5) {
                                        return -0.00373390700347;
                                    } else {
                                        return 0.0976118042099;
                                    }
                                } else {
                                    if (fs[72] <= 9870.5) {
                                        return -0.00127869246348;
                                    } else {
                                        return -0.0122941525334;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 5.5) {
                        if (fs[53] <= -1488.0) {
                            if (fs[4] <= 11.5) {
                                return 0.117287331489;
                            } else {
                                if (fs[101] <= 0.5) {
                                    return 0.268289044822;
                                } else {
                                    return 0.227191453677;
                                }
                            }
                        } else {
                            if (fs[88] <= 1.5) {
                                if (fs[4] <= 13.0) {
                                    return 0.278733535963;
                                } else {
                                    return -0.0238543338928;
                                }
                            } else {
                                return 0.0397268469979;
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            return 0.0516690659056;
                        } else {
                            if (fs[76] <= 25.0) {
                                if (fs[22] <= 0.5) {
                                    if (fs[0] <= 15.5) {
                                        return -0.0256573388489;
                                    } else {
                                        return 0.0146578353473;
                                    }
                                } else {
                                    return -0.00728198893916;
                                }
                            } else {
                                return 0.0184607195526;
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[11] <= 0.5) {
                    if (fs[78] <= 0.5) {
                        return -0.175698236438;
                    } else {
                        if (fs[23] <= 0.5) {
                            return 0.014214085656;
                        } else {
                            if (fs[101] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    return -0.0636422421093;
                                } else {
                                    if (fs[88] <= 7.5) {
                                        return 0.115215628657;
                                    } else {
                                        return 0.128037032977;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    return -0.0433468169016;
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.164847208556;
                                    } else {
                                        return 0.102879116943;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 6.5) {
                        if (fs[53] <= -1138.0) {
                            return -0.0448301529115;
                        } else {
                            if (fs[72] <= 9999.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.186990508032;
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.109541184928;
                                    } else {
                                        return 0.0453461472366;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.256242412083;
                                } else {
                                    return 0.101988524059;
                                }
                            }
                        }
                    } else {
                        if (fs[48] <= 0.5) {
                            return 0.0854311234198;
                        } else {
                            if (fs[97] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    return 0.257785221085;
                                } else {
                                    return 0.361221057252;
                                }
                            } else {
                                return 0.194951485439;
                            }
                        }
                    }
                }
            } else {
                if (fs[88] <= 7.5) {
                    if (fs[53] <= -1068.0) {
                        if (fs[101] <= 0.5) {
                            if (fs[53] <= -1268.0) {
                                if (fs[0] <= 13.5) {
                                    return -0.0886960978286;
                                } else {
                                    return -0.0369104823521;
                                }
                            } else {
                                return 0.00327578081919;
                            }
                        } else {
                            if (fs[47] <= -1.5) {
                                return -0.0799972470496;
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0479088574766;
                                    } else {
                                        return 0.290556076941;
                                    }
                                } else {
                                    return 0.439007100316;
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 3.0) {
                            if (fs[76] <= 100.0) {
                                if (fs[4] <= 9.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.076310593499;
                                    } else {
                                        return -0.018552018687;
                                    }
                                } else {
                                    if (fs[62] <= -0.5) {
                                        return -0.115440329154;
                                    } else {
                                        return 0.172423015357;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0351342617409;
                                    } else {
                                        return 0.256636782604;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0132702535761;
                                    } else {
                                        return -0.0810536888652;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -4.0) {
                                return -0.0311437627186;
                            } else {
                                return 0.301467390619;
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        return 0.212541712856;
                    } else {
                        return 0.127137894427;
                    }
                }
            }
        }
    }
}
