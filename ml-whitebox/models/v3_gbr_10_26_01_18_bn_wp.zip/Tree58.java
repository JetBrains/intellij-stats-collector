/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree58 {
    public double calcTree(double... fs) {
        if (fs[64] <= -996.5) {
            if (fs[45] <= 0.5) {
                if (fs[0] <= 2.5) {
                    if (fs[4] <= 22.5) {
                        if (fs[48] <= 0.5) {
                            if (fs[53] <= -1128.0) {
                                if (fs[12] <= 0.5) {
                                    return 0.390325741632;
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0359385216554;
                                    } else {
                                        return 0.172109730154;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[88] <= 1.0) {
                                        return 0.100947385706;
                                    } else {
                                        return 0.20491978701;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0261671458506;
                                    } else {
                                        return 0.0507718467911;
                                    }
                                }
                            }
                        } else {
                            if (fs[62] <= -1.5) {
                                if (fs[23] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.211598123215;
                                    } else {
                                        return 0.0763286694484;
                                    }
                                } else {
                                    if (fs[64] <= -997.5) {
                                        return 0.0634785996189;
                                    } else {
                                        return 0.204124308244;
                                    }
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.0688661821033;
                                    } else {
                                        return -0.0265482132389;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0637346289259;
                                    } else {
                                        return -0.0291498738777;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 25.5) {
                            if (fs[18] <= 0.5) {
                                return -0.333553893703;
                            } else {
                                return -0.0749442350539;
                            }
                        } else {
                            return 0.125707280728;
                        }
                    }
                } else {
                    if (fs[103] <= 0.5) {
                        if (fs[53] <= -1128.0) {
                            if (fs[47] <= -15.0) {
                                return 0.148343799516;
                            } else {
                                if (fs[0] <= 12.5) {
                                    if (fs[101] <= 0.5) {
                                        return -0.0110855956143;
                                    } else {
                                        return 0.0478321625028;
                                    }
                                } else {
                                    if (fs[0] <= 13.5) {
                                        return 0.351812175259;
                                    } else {
                                        return 0.0171590079097;
                                    }
                                }
                            }
                        } else {
                            if (fs[47] <= -1.5) {
                                if (fs[0] <= 4.5) {
                                    if (fs[99] <= 0.5) {
                                        return -0.0450764046075;
                                    } else {
                                        return -0.0657930146913;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0473508303805;
                                    } else {
                                        return -0.0153193410396;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[64] <= -998.5) {
                                        return -0.0258950201707;
                                    } else {
                                        return 0.121603429472;
                                    }
                                } else {
                                    if (fs[64] <= -997.5) {
                                        return 0.00292980460944;
                                    } else {
                                        return -0.025560874068;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[103] <= 1.5) {
                                if (fs[4] <= 11.5) {
                                    return 0.474767519447;
                                } else {
                                    if (fs[53] <= -1738.0) {
                                        return 0.192289607399;
                                    } else {
                                        return -0.00416697364457;
                                    }
                                }
                            } else {
                                return 0.369423727753;
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[11] <= 0.5) {
                                    return -0.089098302469;
                                } else {
                                    return -0.0342980546683;
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    if (fs[12] <= 0.5) {
                                        return -0.0222144266526;
                                    } else {
                                        return 0.390164988526;
                                    }
                                } else {
                                    return -0.0452331924273;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[103] <= 0.5) {
                    if (fs[4] <= 28.5) {
                        if (fs[23] <= 0.5) {
                            if (fs[0] <= 2.5) {
                                return -0.0370151425873;
                            } else {
                                if (fs[4] <= 11.5) {
                                    return -0.0173230341288;
                                } else {
                                    if (fs[0] <= 10.0) {
                                        return -0.013409870852;
                                    } else {
                                        return -0.00582677748222;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 1.5) {
                                if (fs[99] <= 0.5) {
                                    return 0.00916045958167;
                                } else {
                                    return 0.081876641872;
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[48] <= 0.5) {
                                        return -0.0281267760514;
                                    } else {
                                        return -0.0199161513327;
                                    }
                                } else {
                                    if (fs[47] <= -10.5) {
                                        return 0.0121072670825;
                                    } else {
                                        return -0.00804420674342;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 31.5) {
                            return 0.211811411307;
                        } else {
                            return -0.00837256179387;
                        }
                    }
                } else {
                    if (fs[60] <= 0.5) {
                        if (fs[0] <= 1.5) {
                            if (fs[64] <= -997.5) {
                                if (fs[103] <= 1.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.0243573855988;
                                    } else {
                                        return -0.0249476765738;
                                    }
                                } else {
                                    return -0.0136893688421;
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    return -0.0231426241738;
                                } else {
                                    return -0.0517160784953;
                                }
                            }
                        } else {
                            if (fs[18] <= 0.5) {
                                if (fs[0] <= 6.5) {
                                    return -0.0212738688331;
                                } else {
                                    return -0.0157588966994;
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0137101933372;
                                    } else {
                                        return -0.0177648618048;
                                    }
                                } else {
                                    if (fs[62] <= -1.5) {
                                        return -0.0107409582509;
                                    } else {
                                        return -0.00726035416663;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[0] <= 3.5) {
                                        return -0.0202324810232;
                                    } else {
                                        return -0.0102641096358;
                                    }
                                } else {
                                    if (fs[0] <= 11.0) {
                                        return -0.00727079320687;
                                    } else {
                                        return -0.00346856587852;
                                    }
                                }
                            } else {
                                if (fs[103] <= 1.5) {
                                    if (fs[11] <= 0.5) {
                                        return -0.0213746612993;
                                    } else {
                                        return -0.0115319012211;
                                    }
                                } else {
                                    return -0.0445135459487;
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[49] <= -1.5) {
                                    if (fs[27] <= 0.5) {
                                        return -0.00264968513023;
                                    } else {
                                        return 0.023888027611;
                                    }
                                } else {
                                    if (fs[27] <= 0.5) {
                                        return -0.00750100918562;
                                    } else {
                                        return -0.016352039996;
                                    }
                                }
                            } else {
                                if (fs[27] <= 0.5) {
                                    return -0.00803094671549;
                                } else {
                                    return 0.0516814718893;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[57] <= 0.5) {
                    if (fs[2] <= 1.5) {
                        if (fs[4] <= 8.5) {
                            if (fs[23] <= 0.5) {
                                if (fs[47] <= -3550.5) {
                                    if (fs[60] <= 0.5) {
                                        return 0.233239420414;
                                    } else {
                                        return 0.0252066938851;
                                    }
                                } else {
                                    if (fs[34] <= 0.5) {
                                        return 0.0323336428522;
                                    } else {
                                        return 0.173667965067;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1078.5) {
                                    if (fs[53] <= -1138.5) {
                                        return -0.00616830394574;
                                    } else {
                                        return 0.0744764004248;
                                    }
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return -0.00344544266064;
                                    } else {
                                        return -0.400106868608;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1493.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 0.5) {
                                        return -0.171992797538;
                                    } else {
                                        return 0.0974957381896;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.296469229838;
                                    } else {
                                        return 0.152528034208;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[53] <= -1488.5) {
                                        return -0.0884261684954;
                                    } else {
                                        return -0.0112506091139;
                                    }
                                } else {
                                    if (fs[83] <= 0.5) {
                                        return 0.0626787023541;
                                    } else {
                                        return -0.111912421187;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 9.5) {
                            if (fs[88] <= 5.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.0502655735031;
                                    } else {
                                        return -0.171544903954;
                                    }
                                } else {
                                    if (fs[76] <= 75.0) {
                                        return -0.0466748030763;
                                    } else {
                                        return 0.0608844799417;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.132282478924;
                                    } else {
                                        return 0.0938762356908;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return 0.0345952537444;
                                    } else {
                                        return 0.0986479332008;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 4.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[47] <= -43.5) {
                                        return 0.117499481866;
                                    } else {
                                        return -0.0016053690938;
                                    }
                                } else {
                                    if (fs[47] <= -880.0) {
                                        return 0.203041840735;
                                    } else {
                                        return 0.0496122021779;
                                    }
                                }
                            } else {
                                if (fs[22] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.117986869691;
                                    } else {
                                        return 0.00894194443461;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.135695321533;
                                    } else {
                                        return 0.215048940578;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= 0.5) {
                        if (fs[53] <= -561.5) {
                            return -0.0481269529622;
                        } else {
                            return 0.103406188355;
                        }
                    } else {
                        if (fs[4] <= 26.0) {
                            if (fs[103] <= 0.5) {
                                if (fs[79] <= 0.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.309098987248;
                                    } else {
                                        return 0.232782068357;
                                    }
                                } else {
                                    return 0.130383671182;
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.238804923046;
                                    } else {
                                        return 0.201328435603;
                                    }
                                } else {
                                    return 0.0203687924307;
                                }
                            }
                        } else {
                            return 0.113313360546;
                        }
                    }
                }
            } else {
                if (fs[72] <= 9985.5) {
                    if (fs[30] <= 0.5) {
                        if (fs[90] <= 0.5) {
                            if (fs[47] <= -320.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[53] <= -1458.0) {
                                        return 0.0211011585366;
                                    } else {
                                        return -0.0106853048344;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.105897192025;
                                    } else {
                                        return -0.00173689642212;
                                    }
                                }
                            } else {
                                if (fs[18] <= 0.5) {
                                    if (fs[70] <= -3.5) {
                                        return 0.00972755937541;
                                    } else {
                                        return -0.00333461617726;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return 0.00642455290895;
                                    } else {
                                        return -0.00235940086182;
                                    }
                                }
                            }
                        } else {
                            if (fs[94] <= 0.5) {
                                if (fs[103] <= 0.5) {
                                    if (fs[53] <= -1282.5) {
                                        return 0.0381162335172;
                                    } else {
                                        return 0.0052930270535;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.00379737983946;
                                    } else {
                                        return -0.00788802898705;
                                    }
                                }
                            } else {
                                if (fs[47] <= -8.0) {
                                    return 0.337211446679;
                                } else {
                                    if (fs[4] <= 34.5) {
                                        return 0.178835058793;
                                    } else {
                                        return -0.0526165045516;
                                    }
                                }
                            }
                        }
                    } else {
                        return 0.146599070712;
                    }
                } else {
                    if (fs[4] <= 4.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[28] <= 0.5) {
                                    if (fs[88] <= 1.5) {
                                        return -0.052909954422;
                                    } else {
                                        return 0.00636123472993;
                                    }
                                } else {
                                    return -0.276155967352;
                                }
                            } else {
                                if (fs[23] <= 0.5) {
                                    if (fs[53] <= -1067.5) {
                                        return 0.271809467778;
                                    } else {
                                        return 0.00614712922527;
                                    }
                                } else {
                                    if (fs[103] <= 0.5) {
                                        return 0.055059337423;
                                    } else {
                                        return -0.0660829901527;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[70] <= -3.5) {
                                    return 0.315953449742;
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return 0.0926016996356;
                                    } else {
                                        return -0.15457494343;
                                    }
                                }
                            } else {
                                if (fs[59] <= 0.5) {
                                    if (fs[53] <= -587.5) {
                                        return -0.135334809471;
                                    } else {
                                        return -0.0160349053753;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0189097420652;
                                    } else {
                                        return 0.256362051735;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1418.0) {
                            if (fs[4] <= 30.5) {
                                if (fs[53] <= -1488.0) {
                                    if (fs[47] <= -1.5) {
                                        return -0.017673728402;
                                    } else {
                                        return 0.0540353160987;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0719968354115;
                                    } else {
                                        return 0.243092825024;
                                    }
                                }
                            } else {
                                if (fs[101] <= 1.5) {
                                    if (fs[72] <= 9998.5) {
                                        return 0.0959267307663;
                                    } else {
                                        return -0.196890888121;
                                    }
                                } else {
                                    if (fs[4] <= 37.0) {
                                        return -0.0678455241591;
                                    } else {
                                        return -0.137952662969;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[7] <= 0.5) {
                                    if (fs[97] <= 0.5) {
                                        return -0.000597201205566;
                                    } else {
                                        return -0.0122273852477;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.0302408281595;
                                    } else {
                                        return -0.121714336954;
                                    }
                                }
                            } else {
                                if (fs[76] <= 25.0) {
                                    if (fs[74] <= 0.5) {
                                        return 0.0267440763886;
                                    } else {
                                        return 0.178517733939;
                                    }
                                } else {
                                    if (fs[47] <= -172.0) {
                                        return 0.222537115229;
                                    } else {
                                        return -0.0114398194676;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
