/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model.old;

public class Tree69 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 0.5) {
                    return -0.210141243318;
                } else {
                    if (fs[33] <= 0.5) {
                        if (fs[4] <= 21.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[53] <= -1128.5) {
                                    if (fs[23] <= 0.5) {
                                        return 0.0308278131145;
                                    } else {
                                        return 0.0227712081549;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0505869318866;
                                    } else {
                                        return 0.028739186118;
                                    }
                                }
                            } else {
                                if (fs[72] <= 4914.0) {
                                    if (fs[2] <= 1.5) {
                                        return 0.129051551355;
                                    } else {
                                        return 0.0604335213634;
                                    }
                                } else {
                                    return 0.04021725803;
                                }
                            }
                        } else {
                            if (fs[4] <= 29.5) {
                                return -0.133903322741;
                            } else {
                                if (fs[4] <= 32.5) {
                                    return 0.186066136898;
                                } else {
                                    if (fs[4] <= 39.5) {
                                        return -0.186404447443;
                                    } else {
                                        return -0.00983619667371;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 3.5) {
                            return 0.0749274903622;
                        } else {
                            return -0.233125236121;
                        }
                    }
                }
            } else {
                if (fs[4] <= 2.5) {
                    if (fs[79] <= 0.5) {
                        if (fs[41] <= 0.5) {
                            return 0.120679815059;
                        } else {
                            return -0.224036235545;
                        }
                    } else {
                        return -0.0831207933384;
                    }
                } else {
                    if (fs[4] <= 7.5) {
                        if (fs[71] <= 0.5) {
                            if (fs[41] <= 0.5) {
                                if (fs[53] <= -1053.0) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0709191405767;
                                    } else {
                                        return 0.574888396187;
                                    }
                                } else {
                                    if (fs[12] <= 0.5) {
                                        return -0.0275839499878;
                                    } else {
                                        return 0.0818411903354;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    return 0.366048013116;
                                } else {
                                    return 0.0270806987275;
                                }
                            }
                        } else {
                            if (fs[68] <= 1.5) {
                                if (fs[2] <= 2.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.00920870667335;
                                    } else {
                                        return 0.0313338973388;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return 0.0755385582075;
                                    } else {
                                        return 0.381732505401;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    return 0.258134538074;
                                } else {
                                    if (fs[4] <= 4.5) {
                                        return 0.125920246882;
                                    } else {
                                        return 0.0968708894322;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[4] <= 12.5) {
                            if (fs[0] <= 7.5) {
                                if (fs[52] <= 0.5) {
                                    return 0.0190976149887;
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return -0.022966870864;
                                    } else {
                                        return -0.0178179236702;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[0] <= 12.5) {
                                        return -0.0254747910611;
                                    } else {
                                        return -0.00563522894851;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.0118499967309;
                                    } else {
                                        return 0.0570489550872;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 13.5) {
                                return 0.141299604581;
                            } else {
                                if (fs[72] <= 9713.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.0051896132964;
                                    } else {
                                        return 0.00827625232988;
                                    }
                                } else {
                                    return -0.0630603136677;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[57] <= 0.5) {
                if (fs[76] <= 25.0) {
                    if (fs[72] <= 9981.5) {
                        if (fs[18] <= 0.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[0] <= 2.5) {
                                        return -0.0114260265867;
                                    } else {
                                        return -0.00210444588167;
                                    }
                                } else {
                                    if (fs[2] <= 2.5) {
                                        return 0.00021296461636;
                                    } else {
                                        return 0.03558593688;
                                    }
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    if (fs[4] <= 15.0) {
                                        return 0.196492810873;
                                    } else {
                                        return -0.161006627493;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.0346891341743;
                                    } else {
                                        return -0.0157229840188;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 4.5) {
                                if (fs[49] <= -1.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.0707792789933;
                                    } else {
                                        return 0.216187891341;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.00340689314721;
                                    } else {
                                        return 0.0227307986728;
                                    }
                                }
                            } else {
                                if (fs[0] <= 20.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00199960101447;
                                    } else {
                                        return 0.00253445551948;
                                    }
                                } else {
                                    if (fs[4] <= 16.5) {
                                        return -0.00376867448223;
                                    } else {
                                        return -0.000395488353386;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 1.5) {
                            if (fs[34] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.0550462234739;
                                    } else {
                                        return 0.0103233292911;
                                    }
                                } else {
                                    if (fs[47] <= -1.5) {
                                        return 0.016652197841;
                                    } else {
                                        return -0.00826481438532;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[72] <= 9993.5) {
                                        return 0.311920071314;
                                    } else {
                                        return 0.103196284703;
                                    }
                                } else {
                                    if (fs[53] <= -1052.0) {
                                        return 0.176239368466;
                                    } else {
                                        return -0.025013155893;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[67] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.0382904619228;
                                    } else {
                                        return 0.0106135994657;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.097197639158;
                                    } else {
                                        return -0.183958813093;
                                    }
                                }
                            } else {
                                if (fs[4] <= 24.5) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0628014241802;
                                    } else {
                                        return 0.522553407429;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.261231860343;
                                    } else {
                                        return 0.0715227466457;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[0] <= 0.5) {
                        if (fs[18] <= -0.5) {
                            if (fs[4] <= 11.5) {
                                return -0.330136044586;
                            } else {
                                if (fs[48] <= 0.5) {
                                    return -0.254358292846;
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.0927279205942;
                                    } else {
                                        return -0.038469182912;
                                    }
                                }
                            }
                        } else {
                            if (fs[24] <= 0.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[2] <= 7.5) {
                                        return 0.0213106369254;
                                    } else {
                                        return 0.0770946223237;
                                    }
                                } else {
                                    if (fs[47] <= -37.5) {
                                        return -0.116678406542;
                                    } else {
                                        return 0.138863657228;
                                    }
                                }
                            } else {
                                if (fs[53] <= -481.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.0401140659588;
                                    } else {
                                        return 0.133877313136;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0528589983347;
                                    } else {
                                        return -0.218681936678;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 7.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[94] <= 0.5) {
                                    if (fs[4] <= 11.5) {
                                        return 0.00976496967325;
                                    } else {
                                        return -0.00345385406245;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0173384181825;
                                    } else {
                                        return 0.141409339765;
                                    }
                                }
                            } else {
                                if (fs[0] <= 3.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.00544482732349;
                                    } else {
                                        return -0.0103811295234;
                                    }
                                } else {
                                    if (fs[47] <= -33.5) {
                                        return -0.00785416451192;
                                    } else {
                                        return -0.00224222615618;
                                    }
                                }
                            }
                        } else {
                            if (fs[52] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[47] <= -14011.0) {
                                        return -0.146103622303;
                                    } else {
                                        return -0.0185880977203;
                                    }
                                } else {
                                    if (fs[47] <= -7620.0) {
                                        return -0.355292438034;
                                    } else {
                                        return -0.0557079483894;
                                    }
                                }
                            } else {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0120397266149;
                                    } else {
                                        return 0.0624088546753;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.109198106151;
                                    } else {
                                        return 0.218918129442;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 0.5) {
                    if (fs[70] <= -4.0) {
                        return 0.348140276885;
                    } else {
                        if (fs[18] <= 0.5) {
                            if (fs[105] <= 0.5) {
                                if (fs[103] <= 0.5) {
                                    return 0.14363428185;
                                } else {
                                    return -0.00945933875659;
                                }
                            } else {
                                return -0.244257111409;
                            }
                        } else {
                            if (fs[78] <= 0.5) {
                                return -0.0110003613506;
                            } else {
                                if (fs[4] <= 25.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.106301887487;
                                    } else {
                                        return 0.1844272731;
                                    }
                                } else {
                                    return 0.030996797795;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[45] <= 0.5) {
                        if (fs[47] <= -3.5) {
                            return -0.122939446966;
                        } else {
                            if (fs[99] <= 0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[88] <= 4.0) {
                                        return -0.0501049260691;
                                    } else {
                                        return 0.000688948908502;
                                    }
                                } else {
                                    if (fs[88] <= 1.0) {
                                        return -0.0407851150852;
                                    } else {
                                        return 0.202172651374;
                                    }
                                }
                            } else {
                                if (fs[78] <= 0.5) {
                                    return -0.136402081621;
                                } else {
                                    if (fs[4] <= 9.5) {
                                        return 0.124875919516;
                                    } else {
                                        return 0.27586188838;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[11] <= 0.5) {
                            if (fs[49] <= -0.5) {
                                return -0.0344005184628;
                            } else {
                                return -0.0268153902308;
                            }
                        } else {
                            if (fs[53] <= -966.0) {
                                if (fs[48] <= 0.5) {
                                    return -0.02258221889;
                                } else {
                                    return -0.0178362078256;
                                }
                            } else {
                                if (fs[4] <= 11.5) {
                                    if (fs[0] <= 5.5) {
                                        return -0.00846782515365;
                                    } else {
                                        return -0.00677790871976;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0110515051527;
                                    } else {
                                        return -0.0152184945919;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
