/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree37 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[2] <= 1.5) {
                if (fs[22] <= 0.5) {
                    if (fs[23] <= 0.5) {
                        if (fs[53] <= -457.0) {
                            if (fs[74] <= 0.5) {
                                if (fs[34] <= 0.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.204696356955;
                                    } else {
                                        return 0.117601755223;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return 0.339919627712;
                                    } else {
                                        return 0.321505384926;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[72] <= 9893.0) {
                                        return -0.0512526642903;
                                    } else {
                                        return 0.21570274494;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.350673168311;
                                    } else {
                                        return -0.0910962006912;
                                    }
                                }
                            }
                        } else {
                            if (fs[82] <= 0.5) {
                                if (fs[72] <= 9980.5) {
                                    if (fs[4] <= 8.5) {
                                        return -0.0183090744708;
                                    } else {
                                        return -0.175562630365;
                                    }
                                } else {
                                    if (fs[4] <= 8.5) {
                                        return 0.118245913683;
                                    } else {
                                        return -0.0820517421882;
                                    }
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[72] <= 9987.0) {
                                        return 0.140396634084;
                                    } else {
                                        return 0.353272126474;
                                    }
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return -0.0344014546804;
                                    } else {
                                        return 0.138669692392;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[105] <= 0.5) {
                            if (fs[4] <= 4.5) {
                                if (fs[60] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return 0.210066476122;
                                    } else {
                                        return 0.175414515349;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return 0.115392014783;
                                    } else {
                                        return 0.18563433423;
                                    }
                                }
                            } else {
                                if (fs[64] <= -995.5) {
                                    if (fs[53] <= -2253.0) {
                                        return -0.0366084498963;
                                    } else {
                                        return 0.160289536693;
                                    }
                                } else {
                                    if (fs[53] <= -1553.5) {
                                        return 0.173705855504;
                                    } else {
                                        return 0.0379410090742;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1598.5) {
                                if (fs[53] <= -1904.0) {
                                    return 0.119183003065;
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return 0.385276515493;
                                    } else {
                                        return 0.193769798566;
                                    }
                                }
                            } else {
                                if (fs[88] <= 0.5) {
                                    if (fs[49] <= -0.5) {
                                        return 0.0899692892868;
                                    } else {
                                        return -0.227527276372;
                                    }
                                } else {
                                    if (fs[72] <= 9978.0) {
                                        return -0.00681069416639;
                                    } else {
                                        return 0.0708862262437;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9999.5) {
                        if (fs[12] <= 0.5) {
                            if (fs[59] <= 0.5) {
                                if (fs[84] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.189841513317;
                                    } else {
                                        return -0.0474821695985;
                                    }
                                } else {
                                    return 0.294792104538;
                                }
                            } else {
                                if (fs[4] <= 10.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.105450763927;
                                    } else {
                                        return 0.0889911851696;
                                    }
                                } else {
                                    if (fs[94] <= 0.5) {
                                        return -0.0974921408474;
                                    } else {
                                        return 0.231063391138;
                                    }
                                }
                            }
                        } else {
                            if (fs[101] <= 0.5) {
                                if (fs[44] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.254553168981;
                                    } else {
                                        return 0.0402018846611;
                                    }
                                } else {
                                    if (fs[47] <= -4.5) {
                                        return 0.333789918484;
                                    } else {
                                        return 0.186992362606;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.282490565288;
                                    } else {
                                        return 0.174123955509;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.00540219155053;
                                    } else {
                                        return 0.158035730917;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[4] <= 10.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[99] <= 0.5) {
                                        return 0.259315828609;
                                    } else {
                                        return 0.161231291656;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return 0.224753682141;
                                    } else {
                                        return 0.144212075694;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[47] <= -2.5) {
                                        return 0.113559699074;
                                    } else {
                                        return 0.27748003424;
                                    }
                                } else {
                                    if (fs[47] <= -4.5) {
                                        return 0.195547107891;
                                    } else {
                                        return 0.0077130842857;
                                    }
                                }
                            }
                        } else {
                            if (fs[94] <= 0.5) {
                                if (fs[47] <= -160.0) {
                                    if (fs[47] <= -2210.0) {
                                        return 0.327998606907;
                                    } else {
                                        return 0.222480320472;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return 0.0721538787388;
                                    } else {
                                        return -0.0438485761505;
                                    }
                                }
                            } else {
                                return 0.298807155347;
                            }
                        }
                    }
                }
            } else {
                if (fs[88] <= -0.5) {
                    if (fs[18] <= 0.5) {
                        if (fs[72] <= 9999.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[23] <= 0.5) {
                                    return 0.0214834395291;
                                } else {
                                    return 0.22157062808;
                                }
                            } else {
                                if (fs[85] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return -0.282632762528;
                                    } else {
                                        return 0.1100702004;
                                    }
                                } else {
                                    if (fs[53] <= -928.0) {
                                        return -0.110116826758;
                                    } else {
                                        return 0.20542055169;
                                    }
                                }
                            }
                        } else {
                            return -0.483592511713;
                        }
                    } else {
                        return 0.245651566923;
                    }
                } else {
                    if (fs[4] <= 17.5) {
                        if (fs[2] <= 5.5) {
                            if (fs[4] <= 9.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[28] <= 0.5) {
                                        return 0.13864904675;
                                    } else {
                                        return -0.108864701201;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.0137949634628;
                                    } else {
                                        return 0.0527714095543;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1513.0) {
                                    if (fs[22] <= 0.5) {
                                        return 0.256585132719;
                                    } else {
                                        return 0.165431246446;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0598325590299;
                                    } else {
                                        return 0.117282345797;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    return -0.188487488529;
                                } else {
                                    if (fs[2] <= 10.5) {
                                        return 0.171782439082;
                                    } else {
                                        return 0.261022673137;
                                    }
                                }
                            } else {
                                if (fs[88] <= 7.5) {
                                    if (fs[53] <= -1538.0) {
                                        return 0.339873724421;
                                    } else {
                                        return 0.00904617892196;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.0976144569871;
                                    } else {
                                        return 0.212616549978;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 0.5) {
                            if (fs[59] <= 0.5) {
                                if (fs[47] <= -70.5) {
                                    return 0.39292126924;
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.125189701439;
                                    } else {
                                        return -0.00277129000074;
                                    }
                                }
                            } else {
                                if (fs[48] <= 0.5) {
                                    if (fs[4] <= 27.5) {
                                        return 0.244902340861;
                                    } else {
                                        return -0.11314255077;
                                    }
                                } else {
                                    if (fs[77] <= 0.5) {
                                        return -0.0132419184897;
                                    } else {
                                        return 0.155017139606;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1988.0) {
                                if (fs[76] <= 150.0) {
                                    if (fs[4] <= 42.0) {
                                        return 0.310588014964;
                                    } else {
                                        return -0.152634467591;
                                    }
                                } else {
                                    if (fs[60] <= 0.5) {
                                        return -0.111349026056;
                                    } else {
                                        return 0.23374462689;
                                    }
                                }
                            } else {
                                if (fs[4] <= 27.5) {
                                    if (fs[62] <= -3.5) {
                                        return -0.276353714726;
                                    } else {
                                        return 0.0889643734626;
                                    }
                                } else {
                                    if (fs[4] <= 29.5) {
                                        return -0.12004114794;
                                    } else {
                                        return 0.0250763289785;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[0] <= 1.5) {
                if (fs[11] <= 0.5) {
                    if (fs[14] <= 0.5) {
                        if (fs[4] <= 4.5) {
                            if (fs[4] <= 3.5) {
                                if (fs[70] <= -3.5) {
                                    if (fs[2] <= 1.5) {
                                        return 0.242459525529;
                                    } else {
                                        return -0.0204290060809;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0201740894666;
                                    } else {
                                        return 0.0410195645591;
                                    }
                                }
                            } else {
                                if (fs[95] <= 0.5) {
                                    if (fs[81] <= 0.5) {
                                        return 0.115647661551;
                                    } else {
                                        return 0.0391989427948;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0137358058663;
                                    } else {
                                        return 0.187911806151;
                                    }
                                }
                            }
                        } else {
                            if (fs[45] <= 0.5) {
                                if (fs[47] <= -1.5) {
                                    if (fs[64] <= -997.5) {
                                        return 0.338341681491;
                                    } else {
                                        return 0.0504438720697;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return 0.0146765560043;
                                    } else {
                                        return 0.0591112379702;
                                    }
                                }
                            } else {
                                if (fs[104] <= 0.5) {
                                    if (fs[4] <= 5.5) {
                                        return 0.0706323626875;
                                    } else {
                                        return -0.0167878086465;
                                    }
                                } else {
                                    return -0.0392503603686;
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9902.0) {
                            if (fs[27] <= 0.5) {
                                if (fs[26] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return 0.00842654323704;
                                    } else {
                                        return 0.0958267175872;
                                    }
                                } else {
                                    return 0.310766585815;
                                }
                            } else {
                                return 0.233117937026;
                            }
                        } else {
                            if (fs[85] <= 0.5) {
                                if (fs[4] <= 8.5) {
                                    return 0.383116136718;
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return -0.0866253133404;
                                    } else {
                                        return 0.168291916195;
                                    }
                                }
                            } else {
                                if (fs[105] <= 0.5) {
                                    return 0.538537984934;
                                } else {
                                    return 0.235962115344;
                                }
                            }
                        }
                    }
                } else {
                    if (fs[47] <= -10.5) {
                        if (fs[88] <= 7.5) {
                            if (fs[72] <= 9915.5) {
                                if (fs[53] <= -1478.0) {
                                    if (fs[41] <= 0.5) {
                                        return 0.0309018469295;
                                    } else {
                                        return 0.0909190374411;
                                    }
                                } else {
                                    if (fs[53] <= -452.5) {
                                        return -0.0293433452675;
                                    } else {
                                        return 0.0317700132695;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[76] <= 25.0) {
                                        return 0.225489274351;
                                    } else {
                                        return 0.0685669756133;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.0778725985736;
                                    } else {
                                        return -0.0378524738083;
                                    }
                                }
                            }
                        } else {
                            if (fs[4] <= 6.5) {
                                if (fs[92] <= 0.5) {
                                    return -0.342178363248;
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return -0.123312326006;
                                    } else {
                                        return 0.213183439887;
                                    }
                                }
                            } else {
                                if (fs[47] <= -24.5) {
                                    if (fs[4] <= 9.5) {
                                        return -0.176775382857;
                                    } else {
                                        return -0.0629081413519;
                                    }
                                } else {
                                    return 0.0528037655653;
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[81] <= 0.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[23] <= 0.5) {
                                        return -0.0904538541227;
                                    } else {
                                        return -0.0221655265454;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return -0.0400648238482;
                                    } else {
                                        return -0.096125614756;
                                    }
                                }
                            } else {
                                if (fs[51] <= 0.5) {
                                    if (fs[4] <= 20.5) {
                                        return -0.00928010516723;
                                    } else {
                                        return -0.0355951240677;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0475141882237;
                                    } else {
                                        return 0.200805280511;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 7.5) {
                                if (fs[105] <= 0.5) {
                                    if (fs[53] <= 3.5) {
                                        return 0.0237470125927;
                                    } else {
                                        return -0.0331038319255;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return -0.0206063640788;
                                    } else {
                                        return 0.0379964178787;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1458.0) {
                                    if (fs[4] <= 5.5) {
                                        return -0.288173795655;
                                    } else {
                                        return 0.165255775201;
                                    }
                                } else {
                                    if (fs[72] <= 9992.0) {
                                        return -0.0288148846789;
                                    } else {
                                        return 0.131632690954;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 5.5) {
                    if (fs[11] <= 0.5) {
                        if (fs[72] <= 9999.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[101] <= 1.5) {
                                    if (fs[72] <= 9196.0) {
                                        return 0.00344529320941;
                                    } else {
                                        return 0.031727253283;
                                    }
                                } else {
                                    if (fs[72] <= 9994.5) {
                                        return 0.0299714539842;
                                    } else {
                                        return -0.0421507835197;
                                    }
                                }
                            } else {
                                if (fs[62] <= -2.5) {
                                    if (fs[4] <= 19.5) {
                                        return 0.134157726332;
                                    } else {
                                        return -0.0335861944125;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return -0.010983078007;
                                    } else {
                                        return -0.0162366280803;
                                    }
                                }
                            }
                        } else {
                            if (fs[74] <= 0.5) {
                                if (fs[85] <= 0.5) {
                                    if (fs[53] <= -992.5) {
                                        return 0.119390739784;
                                    } else {
                                        return -0.0238161098508;
                                    }
                                } else {
                                    if (fs[97] <= 0.5) {
                                        return 0.0500861383022;
                                    } else {
                                        return 0.519295763665;
                                    }
                                }
                            } else {
                                if (fs[2] <= 1.5) {
                                    return 0.41191871616;
                                } else {
                                    return 0.324836373159;
                                }
                            }
                        }
                    } else {
                        if (fs[47] <= -367.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.123216192609;
                                    } else {
                                        return 0.0352321209135;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return 0.050892623575;
                                    } else {
                                        return 0.378367469798;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9998.5) {
                                    if (fs[53] <= -1133.5) {
                                        return -0.0468686287921;
                                    } else {
                                        return -0.0170963226907;
                                    }
                                } else {
                                    return -0.10841095552;
                                }
                            }
                        } else {
                            if (fs[4] <= 2.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.183500609097;
                                    } else {
                                        return 0.00128204601136;
                                    }
                                } else {
                                    if (fs[4] <= 1.5) {
                                        return -0.0344020152382;
                                    } else {
                                        return 0.0102008637675;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[2] <= 3.5) {
                                        return -0.0141971885677;
                                    } else {
                                        return 0.00236347499171;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return -0.0054060081006;
                                    } else {
                                        return 0.00519877435;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9999.5) {
                        if (fs[47] <= -9750.0) {
                            if (fs[59] <= 0.5) {
                                if (fs[4] <= 6.5) {
                                    if (fs[47] <= -17976.5) {
                                        return -0.0440642900475;
                                    } else {
                                        return 0.202065899337;
                                    }
                                } else {
                                    if (fs[47] <= -14075.5) {
                                        return -0.0556202500301;
                                    } else {
                                        return -0.00208480938006;
                                    }
                                }
                            } else {
                                if (fs[4] <= 6.5) {
                                    if (fs[47] <= -14651.0) {
                                        return 0.197068200979;
                                    } else {
                                        return 0.480001286456;
                                    }
                                } else {
                                    return -0.0778850349351;
                                }
                            }
                        } else {
                            if (fs[4] <= 3.5) {
                                if (fs[81] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0703722592809;
                                    } else {
                                        return 0.0132624805253;
                                    }
                                } else {
                                    if (fs[88] <= 6.5) {
                                        return -0.00712819272862;
                                    } else {
                                        return 0.0337085978317;
                                    }
                                }
                            } else {
                                if (fs[0] <= 11.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.00605436805777;
                                    } else {
                                        return -0.00957241759231;
                                    }
                                } else {
                                    if (fs[47] <= -2396.0) {
                                        return -0.034908733635;
                                    } else {
                                        return -0.00922721435425;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 3.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[0] <= 16.5) {
                                    if (fs[53] <= -1103.0) {
                                        return 0.140938617653;
                                    } else {
                                        return 0.00345597284841;
                                    }
                                } else {
                                    if (fs[90] <= 0.5) {
                                        return -0.02564336396;
                                    } else {
                                        return 0.20773761939;
                                    }
                                }
                            } else {
                                if (fs[0] <= 6.5) {
                                    if (fs[4] <= 19.5) {
                                        return -0.0034865005566;
                                    } else {
                                        return 0.128640464732;
                                    }
                                } else {
                                    if (fs[76] <= 150.0) {
                                        return -0.0250627278481;
                                    } else {
                                        return -0.0116390796966;
                                    }
                                }
                            }
                        } else {
                            if (fs[60] <= 0.5) {
                                if (fs[76] <= 75.0) {
                                    return 0.0391699452701;
                                } else {
                                    if (fs[99] <= 0.5) {
                                        return -0.166106631124;
                                    } else {
                                        return -0.0138776338699;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0231949625903;
                                    } else {
                                        return 0.374740128305;
                                    }
                                } else {
                                    if (fs[4] <= 12.5) {
                                        return -0.0442323232043;
                                    } else {
                                        return -0.0313721361047;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
