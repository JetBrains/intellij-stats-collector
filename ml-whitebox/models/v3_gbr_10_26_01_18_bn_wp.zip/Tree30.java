/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree30 {
    public double calcTree(double... fs) {
        if (fs[81] <= 0.5) {
            if (fs[101] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[0] <= 0.5) {
                        if (fs[11] <= 0.5) {
                            if (fs[53] <= -1138.0) {
                                if (fs[4] <= 3.5) {
                                    return 0.0704566195885;
                                } else {
                                    if (fs[15] <= 0.5) {
                                        return 0.158559592508;
                                    } else {
                                        return 0.224859818288;
                                    }
                                }
                            } else {
                                if (fs[4] <= 4.5) {
                                    if (fs[53] <= -1053.5) {
                                        return 0.221712014684;
                                    } else {
                                        return -0.432512753111;
                                    }
                                } else {
                                    if (fs[4] <= 5.5) {
                                        return 0.258879420011;
                                    } else {
                                        return 0.360121996133;
                                    }
                                }
                            }
                        } else {
                            if (fs[41] <= 0.5) {
                                if (fs[4] <= 9.5) {
                                    if (fs[53] <= -1138.5) {
                                        return 0.0952606512737;
                                    } else {
                                        return 0.208738232239;
                                    }
                                } else {
                                    return 0.330924041926;
                                }
                            } else {
                                return 0.262153504676;
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[15] <= 0.5) {
                                if (fs[11] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return 0.124267842075;
                                    } else {
                                        return 0.0246520271003;
                                    }
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return -0.0447630535844;
                                    } else {
                                        return 0.0784252351912;
                                    }
                                }
                            } else {
                                if (fs[4] <= 3.5) {
                                    if (fs[0] <= 24.5) {
                                        return 0.00485575939606;
                                    } else {
                                        return 0.240500921702;
                                    }
                                } else {
                                    if (fs[78] <= 0.5) {
                                        return -0.0430465169839;
                                    } else {
                                        return 0.0997090893028;
                                    }
                                }
                            }
                        } else {
                            if (fs[53] <= -1108.0) {
                                if (fs[0] <= 2.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.105807048869;
                                    } else {
                                        return -0.0323920043652;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return 0.0297755192697;
                                    } else {
                                        return -0.0100962766085;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[0] <= 1.5) {
                                        return -0.0558276170245;
                                    } else {
                                        return -0.0914142033844;
                                    }
                                } else {
                                    if (fs[0] <= 20.5) {
                                        return -0.0248686843447;
                                    } else {
                                        return -0.0421301185785;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[2] <= 2.5) {
                        if (fs[53] <= -988.0) {
                            if (fs[11] <= 0.5) {
                                if (fs[0] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.219233155105;
                                    } else {
                                        return 0.208325690483;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.0130503079535;
                                    } else {
                                        return 0.176485593991;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0365931110719;
                                    } else {
                                        return 0.14176219014;
                                    }
                                } else {
                                    if (fs[68] <= 1.5) {
                                        return 0.155985453164;
                                    } else {
                                        return 0.322134150264;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[72] <= 9987.0) {
                                    if (fs[0] <= 0.5) {
                                        return 0.120033854566;
                                    } else {
                                        return -0.0390820951159;
                                    }
                                } else {
                                    return 0.290467277623;
                                }
                            } else {
                                if (fs[0] <= 0.5) {
                                    return 0.245001666571;
                                } else {
                                    return 0.344305578116;
                                }
                            }
                        }
                    } else {
                        if (fs[0] <= 4.5) {
                            if (fs[33] <= 0.5) {
                                if (fs[53] <= -477.0) {
                                    if (fs[4] <= 3.5) {
                                        return 0.159064952811;
                                    } else {
                                        return 0.210025414608;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.258793201532;
                                    } else {
                                        return 0.230096701928;
                                    }
                                }
                            } else {
                                return -0.0128091404478;
                            }
                        } else {
                            if (fs[53] <= -968.0) {
                                return 0.0670535895094;
                            } else {
                                return -0.0214687543579;
                            }
                        }
                    }
                }
            } else {
                if (fs[72] <= 9745.0) {
                    if (fs[78] <= 0.5) {
                        if (fs[72] <= 4847.0) {
                            if (fs[4] <= 32.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[0] <= 0.5) {
                                        return 0.192601567939;
                                    } else {
                                        return 0.0740602287898;
                                    }
                                } else {
                                    if (fs[4] <= 20.5) {
                                        return -0.0335588043641;
                                    } else {
                                        return 0.00938543288623;
                                    }
                                }
                            } else {
                                if (fs[0] <= 1.5) {
                                    if (fs[4] <= 35.0) {
                                        return -0.134755801785;
                                    } else {
                                        return -0.0697446806031;
                                    }
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return -0.0131552518073;
                                    } else {
                                        return -0.0278246308212;
                                    }
                                }
                            }
                        } else {
                            return 0.157951582592;
                        }
                    } else {
                        if (fs[0] <= 2.5) {
                            if (fs[4] <= 19.5) {
                                if (fs[2] <= 1.5) {
                                    return 0.0990003200333;
                                } else {
                                    if (fs[53] <= -1138.0) {
                                        return 0.0685912963288;
                                    } else {
                                        return -0.0377802884534;
                                    }
                                }
                            } else {
                                if (fs[65] <= 0.5) {
                                    if (fs[71] <= 0.5) {
                                        return -0.0418598410468;
                                    } else {
                                        return -0.0635891906977;
                                    }
                                } else {
                                    return -0.13632583013;
                                }
                            }
                        } else {
                            if (fs[0] <= 6.5) {
                                if (fs[53] <= -1578.0) {
                                    return -1.06100015467e-05;
                                } else {
                                    if (fs[70] <= -1.5) {
                                        return -0.0330252768164;
                                    } else {
                                        return -0.0203812601983;
                                    }
                                }
                            } else {
                                if (fs[52] <= 0.5) {
                                    if (fs[0] <= 9.5) {
                                        return -0.0420999672866;
                                    } else {
                                        return -0.0358917703662;
                                    }
                                } else {
                                    if (fs[0] <= 8.5) {
                                        return -0.0162827067383;
                                    } else {
                                        return -0.0138074328853;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    return -0.116333343549;
                }
            }
        } else {
            if (fs[0] <= 0.5) {
                if (fs[2] <= 1.5) {
                    if (fs[53] <= -987.5) {
                        if (fs[85] <= 0.5) {
                            if (fs[53] <= -1498.5) {
                                if (fs[70] <= -1.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.282193180462;
                                    } else {
                                        return 0.192976653814;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.197590160427;
                                    } else {
                                        return -0.307047856619;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1238.5) {
                                    if (fs[4] <= 18.5) {
                                        return 0.0364159101053;
                                    } else {
                                        return -0.126738644357;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.174854365141;
                                    } else {
                                        return 0.060544959076;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[24] <= 0.5) {
                                    if (fs[90] <= 0.5) {
                                        return -0.000563000660649;
                                    } else {
                                        return 0.174545629606;
                                    }
                                } else {
                                    if (fs[53] <= -1468.5) {
                                        return 0.250541682673;
                                    } else {
                                        return 0.433413053866;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[47] <= -3.5) {
                                        return 0.179262527111;
                                    } else {
                                        return 0.0496800531058;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.213500273883;
                                    } else {
                                        return 0.286740931179;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[72] <= 9997.5) {
                            if (fs[62] <= -0.5) {
                                if (fs[18] <= 0.5) {
                                    if (fs[103] <= 1.5) {
                                        return 0.033646704171;
                                    } else {
                                        return 0.338007796331;
                                    }
                                } else {
                                    if (fs[70] <= -4.0) {
                                        return 0.0841251218502;
                                    } else {
                                        return 0.240735300022;
                                    }
                                }
                            } else {
                                if (fs[47] <= -1.5) {
                                    if (fs[76] <= 150.0) {
                                        return 0.0249719900893;
                                    } else {
                                        return 0.185953931794;
                                    }
                                } else {
                                    if (fs[44] <= 0.5) {
                                        return -0.0632641712742;
                                    } else {
                                        return 0.119527156408;
                                    }
                                }
                            }
                        } else {
                            if (fs[70] <= -4.5) {
                                if (fs[4] <= 4.5) {
                                    if (fs[101] <= 1.5) {
                                        return 0.248616981411;
                                    } else {
                                        return 0.404911058262;
                                    }
                                } else {
                                    if (fs[4] <= 7.5) {
                                        return 0.045676401151;
                                    } else {
                                        return 0.177717998511;
                                    }
                                }
                            } else {
                                if (fs[11] <= 0.5) {
                                    if (fs[47] <= -7.5) {
                                        return 0.236035337485;
                                    } else {
                                        return 0.0938855810272;
                                    }
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0410301233112;
                                    } else {
                                        return 0.0527391538064;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[4] <= 17.5) {
                        if (fs[41] <= 0.5) {
                            if (fs[76] <= 25.0) {
                                if (fs[22] <= 0.5) {
                                    if (fs[88] <= -0.5) {
                                        return -0.105219275638;
                                    } else {
                                        return 0.163136662294;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.00798820770537;
                                    } else {
                                        return 0.241348500448;
                                    }
                                }
                            } else {
                                if (fs[24] <= 0.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.219621774014;
                                    } else {
                                        return 0.174957334793;
                                    }
                                } else {
                                    if (fs[88] <= 1.5) {
                                        return 0.250132322139;
                                    } else {
                                        return 0.289588734755;
                                    }
                                }
                            }
                        } else {
                            if (fs[88] <= 6.5) {
                                if (fs[51] <= 0.5) {
                                    if (fs[101] <= 1.5) {
                                        return -0.0253580029385;
                                    } else {
                                        return 0.062786047046;
                                    }
                                } else {
                                    return 0.319056850559;
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0372712683926;
                                    } else {
                                        return 0.267854663244;
                                    }
                                } else {
                                    return -0.160852268176;
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 0.5) {
                            if (fs[72] <= 9823.5) {
                                if (fs[7] <= 0.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.118276424252;
                                    } else {
                                        return -0.0836545458518;
                                    }
                                } else {
                                    if (fs[53] <= -1708.0) {
                                        return 0.384195961486;
                                    } else {
                                        return 0.165324667352;
                                    }
                                }
                            } else {
                                if (fs[102] <= 0.5) {
                                    if (fs[72] <= 9983.5) {
                                        return 0.289613080509;
                                    } else {
                                        return 0.0644516266305;
                                    }
                                } else {
                                    if (fs[23] <= 0.5) {
                                        return 0.20881397538;
                                    } else {
                                        return 0.363683468156;
                                    }
                                }
                            }
                        } else {
                            if (fs[83] <= 0.5) {
                                if (fs[2] <= 12.5) {
                                    if (fs[53] <= -1988.0) {
                                        return 0.29687268449;
                                    } else {
                                        return 0.109188565299;
                                    }
                                } else {
                                    if (fs[4] <= 21.5) {
                                        return 0.425869100553;
                                    } else {
                                        return 0.295520753364;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[60] <= 0.5) {
                                        return -0.0597914832573;
                                    } else {
                                        return 0.353950070947;
                                    }
                                } else {
                                    return -0.284475480681;
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[0] <= 1.5) {
                    if (fs[47] <= -13.5) {
                        if (fs[53] <= -1478.5) {
                            if (fs[88] <= 6.5) {
                                if (fs[4] <= 10.5) {
                                    if (fs[2] <= 2.5) {
                                        return 0.0923937104197;
                                    } else {
                                        return 0.221729957623;
                                    }
                                } else {
                                    if (fs[105] <= 0.5) {
                                        return 0.0458013314854;
                                    } else {
                                        return -0.0458633269534;
                                    }
                                }
                            } else {
                                if (fs[4] <= 8.5) {
                                    if (fs[92] <= 0.5) {
                                        return -0.356134436821;
                                    } else {
                                        return 0.272730348169;
                                    }
                                } else {
                                    if (fs[71] <= 0.5) {
                                        return 0.0609598254593;
                                    } else {
                                        return -0.0682799965148;
                                    }
                                }
                            }
                        } else {
                            if (fs[72] <= 9923.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.035428081947;
                                    } else {
                                        return -0.00701327548757;
                                    }
                                } else {
                                    if (fs[4] <= 3.5) {
                                        return 0.312145365228;
                                    } else {
                                        return 0.0630611122223;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1138.0) {
                                    if (fs[47] <= -25.5) {
                                        return 0.140288401351;
                                    } else {
                                        return 0.476910652243;
                                    }
                                } else {
                                    if (fs[22] <= 0.5) {
                                        return 0.097301153405;
                                    } else {
                                        return -0.0839736192793;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[45] <= 0.5) {
                            if (fs[99] <= 0.5) {
                                if (fs[72] <= 9990.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.000914817968053;
                                    } else {
                                        return 0.0299449470651;
                                    }
                                } else {
                                    if (fs[11] <= 0.5) {
                                        return 0.112765098812;
                                    } else {
                                        return 0.0406203178093;
                                    }
                                }
                            } else {
                                if (fs[53] <= -2468.0) {
                                    if (fs[103] <= 0.5) {
                                        return 0.336002344967;
                                    } else {
                                        return 0.184545450444;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.0103225452265;
                                    } else {
                                        return 0.0459318999638;
                                    }
                                }
                            }
                        } else {
                            if (fs[79] <= 0.5) {
                                if (fs[49] <= -2.5) {
                                    if (fs[103] <= 1.5) {
                                        return -0.00807770386753;
                                    } else {
                                        return 0.112271565781;
                                    }
                                } else {
                                    if (fs[2] <= 0.5) {
                                        return 0.0940218829606;
                                    } else {
                                        return -0.0223717147221;
                                    }
                                }
                            } else {
                                if (fs[76] <= 250.0) {
                                    if (fs[72] <= 9783.0) {
                                        return -0.040008747636;
                                    } else {
                                        return -0.0873229333182;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return -0.0191883273675;
                                    } else {
                                        return -0.030248349789;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[57] <= 0.5) {
                        if (fs[47] <= -3731.5) {
                            if (fs[84] <= 0.5) {
                                if (fs[53] <= -1242.5) {
                                    if (fs[4] <= 6.5) {
                                        return 0.280331793394;
                                    } else {
                                        return 0.0666396748629;
                                    }
                                } else {
                                    if (fs[79] <= 0.5) {
                                        return -0.0652135748567;
                                    } else {
                                        return 0.0276731787295;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    return 0.107100805484;
                                } else {
                                    if (fs[52] <= 0.5) {
                                        return -0.0215389054591;
                                    } else {
                                        return -0.0426549614635;
                                    }
                                }
                            }
                        } else {
                            if (fs[12] <= 0.5) {
                                if (fs[76] <= 25.0) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0105981590926;
                                    } else {
                                        return -0.0134438817834;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.00478529855622;
                                    } else {
                                        return -0.0149433455408;
                                    }
                                }
                            } else {
                                if (fs[45] <= 0.5) {
                                    if (fs[0] <= 4.5) {
                                        return 0.0143299752162;
                                    } else {
                                        return -0.0087753572994;
                                    }
                                } else {
                                    if (fs[103] <= 1.5) {
                                        return -0.0159106428923;
                                    } else {
                                        return -0.011878596214;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 7.5) {
                            if (fs[45] <= 0.5) {
                                if (fs[99] <= 0.5) {
                                    if (fs[88] <= 3.0) {
                                        return -0.0201786801864;
                                    } else {
                                        return 0.148778402403;
                                    }
                                } else {
                                    if (fs[4] <= 11.5) {
                                        return 0.115911382306;
                                    } else {
                                        return 0.38104819545;
                                    }
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    if (fs[105] <= 0.5) {
                                        return -0.02278494475;
                                    } else {
                                        return -0.0285873805503;
                                    }
                                } else {
                                    if (fs[0] <= 4.5) {
                                        return -0.0222282299468;
                                    } else {
                                        return -0.015445605275;
                                    }
                                }
                            }
                        } else {
                            return 0.558023960833;
                        }
                    }
                }
            }
        }
    }
}
