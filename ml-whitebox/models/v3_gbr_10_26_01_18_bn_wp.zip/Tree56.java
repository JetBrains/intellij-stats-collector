/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.completion.ranker.model;

public class Tree56 {
    public double calcTree(double... fs) {
        if (fs[0] <= 0.5) {
            if (fs[4] <= 18.5) {
                if (fs[34] <= 0.5) {
                    if (fs[2] <= 3.5) {
                        if (fs[53] <= -1498.5) {
                            if (fs[48] <= 0.5) {
                                if (fs[90] <= 0.5) {
                                    if (fs[4] <= 3.5) {
                                        return -0.219115608547;
                                    } else {
                                        return 0.180654082217;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.0641263312739;
                                    } else {
                                        return 0.143045862872;
                                    }
                                }
                            } else {
                                if (fs[84] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0986666058449;
                                    } else {
                                        return 0.0633943859547;
                                    }
                                } else {
                                    if (fs[49] <= -0.5) {
                                        return 0.0103671786929;
                                    } else {
                                        return 0.147261478185;
                                    }
                                }
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[64] <= -996.5) {
                                    if (fs[48] <= 0.5) {
                                        return 0.128034303806;
                                    } else {
                                        return 0.0711927345279;
                                    }
                                } else {
                                    if (fs[53] <= -977.0) {
                                        return 0.0431371565634;
                                    } else {
                                        return 0.0152110132831;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[76] <= 25.0) {
                                        return -0.100370579834;
                                    } else {
                                        return 0.0116710710218;
                                    }
                                } else {
                                    if (fs[18] <= -0.5) {
                                        return -0.191675410023;
                                    } else {
                                        return 0.106926775293;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[2] <= 6.5) {
                            if (fs[24] <= 0.5) {
                                if (fs[8] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return 0.0630385957109;
                                    } else {
                                        return 0.0352612161568;
                                    }
                                } else {
                                    if (fs[72] <= 4999.0) {
                                        return -0.357245717519;
                                    } else {
                                        return -0.0285528458577;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1488.0) {
                                    if (fs[4] <= 4.5) {
                                        return -0.073322443539;
                                    } else {
                                        return 0.177820065114;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.110334186088;
                                    } else {
                                        return -0.133255326474;
                                    }
                                }
                            }
                        } else {
                            if (fs[28] <= 0.5) {
                                if (fs[41] <= 0.5) {
                                    if (fs[2] <= 10.5) {
                                        return 0.0951561753405;
                                    } else {
                                        return 0.159639889634;
                                    }
                                } else {
                                    if (fs[84] <= 0.5) {
                                        return -0.00404897595504;
                                    } else {
                                        return 0.167502745184;
                                    }
                                }
                            } else {
                                return -0.190234747619;
                            }
                        }
                    }
                } else {
                    if (fs[72] <= 9931.5) {
                        if (fs[53] <= -546.5) {
                            if (fs[4] <= 12.5) {
                                if (fs[4] <= 7.5) {
                                    if (fs[59] <= 0.5) {
                                        return 0.302003727477;
                                    } else {
                                        return 0.217232100893;
                                    }
                                } else {
                                    if (fs[2] <= 1.5) {
                                        return 0.396171870618;
                                    } else {
                                        return 0.348344969812;
                                    }
                                }
                            } else {
                                return 0.150595296671;
                            }
                        } else {
                            if (fs[72] <= 4692.5) {
                                return 0.197438469988;
                            } else {
                                return 0.0786071989431;
                            }
                        }
                    } else {
                        if (fs[47] <= -0.5) {
                            if (fs[47] <= -24.0) {
                                return 0.253467916317;
                            } else {
                                if (fs[53] <= -546.5) {
                                    if (fs[4] <= 4.5) {
                                        return 0.153306330878;
                                    } else {
                                        return 0.21201007355;
                                    }
                                } else {
                                    return 0.0389002988965;
                                }
                            }
                        } else {
                            return -0.0588301005303;
                        }
                    }
                }
            } else {
                if (fs[101] <= 0.5) {
                    if (fs[59] <= 0.5) {
                        if (fs[72] <= 9754.0) {
                            if (fs[88] <= 7.5) {
                                if (fs[47] <= -72.5) {
                                    return 0.225413957335;
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0234751582837;
                                    } else {
                                        return -0.139847874798;
                                    }
                                }
                            } else {
                                if (fs[70] <= -3.5) {
                                    return 0.49602775952;
                                } else {
                                    return -0.014990376282;
                                }
                            }
                        } else {
                            if (fs[106] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[53] <= -1418.0) {
                                        return -0.106304654947;
                                    } else {
                                        return 0.0309825794189;
                                    }
                                } else {
                                    return 0.352176346758;
                                }
                            } else {
                                if (fs[2] <= 2.5) {
                                    return 0.120302072331;
                                } else {
                                    return 0.374193500067;
                                }
                            }
                        }
                    } else {
                        if (fs[52] <= 0.5) {
                            if (fs[4] <= 29.5) {
                                if (fs[4] <= 28.5) {
                                    if (fs[72] <= 9991.0) {
                                        return 0.210415049022;
                                    } else {
                                        return -0.0283052003753;
                                    }
                                } else {
                                    return 0.363273449415;
                                }
                            } else {
                                return -0.160137761002;
                            }
                        } else {
                            if (fs[84] <= 0.5) {
                                if (fs[22] <= 0.5) {
                                    if (fs[4] <= 23.5) {
                                        return 0.120971243863;
                                    } else {
                                        return 0.0155515607014;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.0348674640952;
                                    } else {
                                        return -0.0431371014538;
                                    }
                                }
                            } else {
                                if (fs[53] <= -1318.0) {
                                    if (fs[2] <= 1.5) {
                                        return -0.170726645215;
                                    } else {
                                        return -0.250759126088;
                                    }
                                } else {
                                    if (fs[72] <= 9015.5) {
                                        return -0.126494283046;
                                    } else {
                                        return -0.054212063792;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[18] <= -0.5) {
                        if (fs[90] <= 0.5) {
                            return -0.281921541954;
                        } else {
                            return -0.202871083628;
                        }
                    } else {
                        if (fs[53] <= -2008.0) {
                            if (fs[18] <= 0.5) {
                                if (fs[4] <= 22.5) {
                                    if (fs[76] <= 75.0) {
                                        return 0.090788556619;
                                    } else {
                                        return -0.146897002847;
                                    }
                                } else {
                                    if (fs[4] <= 45.0) {
                                        return 0.181487090488;
                                    } else {
                                        return -0.20889300273;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9993.5) {
                                    if (fs[90] <= 0.5) {
                                        return 0.278853804253;
                                    } else {
                                        return 0.17603974319;
                                    }
                                } else {
                                    return 0.0274009033389;
                                }
                            }
                        } else {
                            if (fs[53] <= -1478.0) {
                                if (fs[11] <= 0.5) {
                                    if (fs[85] <= 0.5) {
                                        return -0.0313315212527;
                                    } else {
                                        return 0.0750117844441;
                                    }
                                } else {
                                    if (fs[59] <= 0.5) {
                                        return 0.00850287178331;
                                    } else {
                                        return -0.0968033227977;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[79] <= 0.5) {
                                        return 0.124283349504;
                                    } else {
                                        return -0.239515535633;
                                    }
                                } else {
                                    if (fs[101] <= 1.5) {
                                        return -0.0562130848553;
                                    } else {
                                        return 0.0282559467625;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (fs[4] <= 11.5) {
                if (fs[76] <= 25.0) {
                    if (fs[81] <= 0.5) {
                        if (fs[52] <= 0.5) {
                            if (fs[11] <= 0.5) {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 4.5) {
                                        return -0.0846142098935;
                                    } else {
                                        return 0.163942133382;
                                    }
                                } else {
                                    if (fs[0] <= 25.5) {
                                        return 0.0316735903797;
                                    } else {
                                        return -0.073605754273;
                                    }
                                }
                            } else {
                                if (fs[0] <= 2.5) {
                                    if (fs[2] <= 1.5) {
                                        return -0.0502258623105;
                                    } else {
                                        return -0.0598131963064;
                                    }
                                } else {
                                    if (fs[4] <= 6.5) {
                                        return -0.00936857407666;
                                    } else {
                                        return 0.006992135715;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[30] <= 0.5) {
                                    if (fs[4] <= 2.5) {
                                        return 0.1606821774;
                                    } else {
                                        return 0.0103531714227;
                                    }
                                } else {
                                    if (fs[4] <= 5.0) {
                                        return 0.186974189676;
                                    } else {
                                        return 0.182945960794;
                                    }
                                }
                            } else {
                                if (fs[71] <= 0.5) {
                                    if (fs[4] <= 7.5) {
                                        return 0.181374357288;
                                    } else {
                                        return -0.000477205356103;
                                    }
                                } else {
                                    if (fs[53] <= -1128.0) {
                                        return 0.222368882104;
                                    } else {
                                        return -0.123809003875;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[101] <= 1.5) {
                            if (fs[18] <= 0.5) {
                                if (fs[88] <= 6.5) {
                                    if (fs[72] <= 9973.5) {
                                        return -0.00474533351431;
                                    } else {
                                        return 0.0159860572728;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return 0.018034675964;
                                    } else {
                                        return -0.00783391745569;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9989.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.00561358961674;
                                    } else {
                                        return -0.00267880446908;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return 0.0148266775083;
                                    } else {
                                        return 0.0985738742426;
                                    }
                                }
                            }
                        } else {
                            if (fs[2] <= 2.5) {
                                if (fs[53] <= -1608.0) {
                                    if (fs[90] <= 0.5) {
                                        return 0.0352740915863;
                                    } else {
                                        return 0.205934196145;
                                    }
                                } else {
                                    if (fs[72] <= 9999.5) {
                                        return 0.000873278506354;
                                    } else {
                                        return 0.119811351736;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[0] <= 1.5) {
                                        return 0.0557843607731;
                                    } else {
                                        return 0.0169716877447;
                                    }
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return 0.192254598216;
                                    } else {
                                        return 0.0465699408486;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[53] <= -1418.0) {
                        if (fs[0] <= 2.5) {
                            if (fs[2] <= 1.5) {
                                if (fs[68] <= 1.5) {
                                    if (fs[88] <= 5.5) {
                                        return 0.0624383692646;
                                    } else {
                                        return -0.0152942911244;
                                    }
                                } else {
                                    if (fs[72] <= 9797.5) {
                                        return 0.262943546828;
                                    } else {
                                        return 0.0672846228118;
                                    }
                                }
                            } else {
                                if (fs[88] <= 7.5) {
                                    if (fs[88] <= 4.5) {
                                        return 0.0993767336896;
                                    } else {
                                        return 0.0192416840377;
                                    }
                                } else {
                                    if (fs[47] <= -0.5) {
                                        return 0.155934987958;
                                    } else {
                                        return -0.314465615213;
                                    }
                                }
                            }
                        } else {
                            if (fs[90] <= 0.5) {
                                if (fs[47] <= -436.5) {
                                    if (fs[88] <= 7.5) {
                                        return 0.0177249285611;
                                    } else {
                                        return 0.22786336305;
                                    }
                                } else {
                                    if (fs[2] <= 3.5) {
                                        return 0.00302560237749;
                                    } else {
                                        return 0.0543613842914;
                                    }
                                }
                            } else {
                                if (fs[60] <= 0.5) {
                                    if (fs[52] <= 0.5) {
                                        return -0.0506612490315;
                                    } else {
                                        return 0.16439818904;
                                    }
                                } else {
                                    if (fs[72] <= 9997.5) {
                                        return 0.0535394081127;
                                    } else {
                                        return 0.256440923698;
                                    }
                                }
                            }
                        }
                    } else {
                        if (fs[88] <= 1.5) {
                            if (fs[24] <= 0.5) {
                                if (fs[53] <= -1072.5) {
                                    if (fs[84] <= 0.5) {
                                        return 0.387241306645;
                                    } else {
                                        return 0.00812066689073;
                                    }
                                } else {
                                    if (fs[53] <= -6.5) {
                                        return -0.01627147965;
                                    } else {
                                        return -0.00112028935575;
                                    }
                                }
                            } else {
                                if (fs[76] <= 75.0) {
                                    if (fs[0] <= 6.5) {
                                        return 0.0316177459226;
                                    } else {
                                        return -0.00281789366077;
                                    }
                                } else {
                                    if (fs[101] <= 0.5) {
                                        return 0.0988641052521;
                                    } else {
                                        return -0.0272238020477;
                                    }
                                }
                            }
                        } else {
                            if (fs[22] <= 0.5) {
                                if (fs[47] <= -2386.5) {
                                    return 0.288412584405;
                                } else {
                                    if (fs[48] <= 0.5) {
                                        return -0.0190278333799;
                                    } else {
                                        return -0.00164191250356;
                                    }
                                }
                            } else {
                                if (fs[44] <= 0.5) {
                                    if (fs[47] <= -1348.0) {
                                        return -0.0622079128033;
                                    } else {
                                        return -0.0126480896041;
                                    }
                                } else {
                                    if (fs[47] <= -59.5) {
                                        return -0.0244957524545;
                                    } else {
                                        return -0.00636553798653;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (fs[83] <= 0.5) {
                    if (fs[53] <= -4913.0) {
                        return 0.186519019048;
                    } else {
                        if (fs[88] <= 5.5) {
                            if (fs[72] <= 9999.5) {
                                if (fs[0] <= 3.5) {
                                    if (fs[70] <= -1.5) {
                                        return 0.002152942841;
                                    } else {
                                        return -0.0181716747145;
                                    }
                                } else {
                                    if (fs[47] <= -7494.0) {
                                        return 0.200326222218;
                                    } else {
                                        return -0.00355321379775;
                                    }
                                }
                            } else {
                                if (fs[101] <= 0.5) {
                                    if (fs[47] <= -79.5) {
                                        return 0.126041877131;
                                    } else {
                                        return -0.051467306698;
                                    }
                                } else {
                                    if (fs[18] <= 0.5) {
                                        return 0.0490831821089;
                                    } else {
                                        return -0.015386667461;
                                    }
                                }
                            }
                        } else {
                            if (fs[0] <= 6.5) {
                                if (fs[47] <= -1.5) {
                                    if (fs[70] <= -4.0) {
                                        return 0.0632796502149;
                                    } else {
                                        return -0.0318556843511;
                                    }
                                } else {
                                    if (fs[31] <= 0.5) {
                                        return -0.0122353775725;
                                    } else {
                                        return 0.0329653521092;
                                    }
                                }
                            } else {
                                if (fs[47] <= -180.5) {
                                    if (fs[11] <= 0.5) {
                                        return 0.322322207966;
                                    } else {
                                        return -0.00769228404189;
                                    }
                                } else {
                                    if (fs[72] <= 9989.5) {
                                        return -0.00501307951714;
                                    } else {
                                        return -0.0244846193405;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fs[78] <= 0.5) {
                        if (fs[4] <= 15.5) {
                            if (fs[71] <= 0.5) {
                                if (fs[47] <= -1.5) {
                                    return -0.029498829222;
                                } else {
                                    if (fs[4] <= 13.5) {
                                        return 0.282932947527;
                                    } else {
                                        return -0.107074274007;
                                    }
                                }
                            } else {
                                return -0.0459199388509;
                            }
                        } else {
                            if (fs[53] <= -1488.0) {
                                if (fs[4] <= 17.5) {
                                    return 0.511345358628;
                                } else {
                                    return 0.0867206033962;
                                }
                            } else {
                                if (fs[103] <= 0.5) {
                                    return 0.128540180758;
                                } else {
                                    return -0.03751531373;
                                }
                            }
                        }
                    } else {
                        if (fs[53] <= -1488.0) {
                            if (fs[48] <= 0.5) {
                                if (fs[0] <= 2.5) {
                                    if (fs[76] <= 250.0) {
                                        return -0.0791057643868;
                                    } else {
                                        return -0.106504474011;
                                    }
                                } else {
                                    if (fs[72] <= 9980.0) {
                                        return -0.0423373665704;
                                    } else {
                                        return -0.13065777633;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9962.0) {
                                    if (fs[71] <= 0.5) {
                                        return -0.00256093046979;
                                    } else {
                                        return -0.0516492631706;
                                    }
                                } else {
                                    if (fs[41] <= 0.5) {
                                        return -0.0990937453617;
                                    } else {
                                        return -0.157619601305;
                                    }
                                }
                            }
                        } else {
                            if (fs[11] <= 0.5) {
                                if (fs[53] <= -1247.5) {
                                    return 0.284164326881;
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0552173462658;
                                    } else {
                                        return -0.00944190044405;
                                    }
                                }
                            } else {
                                if (fs[72] <= 9942.5) {
                                    if (fs[4] <= 19.5) {
                                        return -0.0159492002007;
                                    } else {
                                        return 0.00157297624933;
                                    }
                                } else {
                                    if (fs[45] <= 0.5) {
                                        return -0.0647022397501;
                                    } else {
                                        return -0.0103380309113;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
